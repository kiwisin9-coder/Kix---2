# Kix — assets privados e atualização remota

## Comportamento nativo

- No primeiro início do editor, `app/src/main/assets/kix/` é copiado para `filesDir/kix`, no espaço privado do aplicativo.
- O `WebViewAssetLoader` serve o editor pela origem HTTPS local `https://appassets.androidplatform.net/kix/`; não é usado `file://` nem habilitado acesso irrestrito a arquivos locais. O handler força `application/javascript; UTF-8` para os módulos `.mjs`, cujo MIME por extensão não é garantido pelo detector padrão.
- A cópia do APK é repetida somente quando muda a versão do APK. Isso evita sobrescrever alterações remotas em toda abertura; ao atualizar o APK, uma base assinada nova é instalada e a versão remota ativa volta a zero.
- A verificação remota ocorre na inicialização do editor. Só são aceitos manifesto e arquivos por HTTPS, limites de tamanho, caminhos relativos seguros, hash SHA-256 verificado e ativação por troca de diretórios com tentativa de rollback.
- Aplicativos exportados (`kix/exported.flag`) continuam carregando `runtime.html` dos assets embutidos e não recebem a atualização do editor.

## Configurar um endpoint real

O projeto não contém um domínio/API de atualização previamente configurado. Sem configuração, a verificação remota fica desativada de forma explícita; a cópia privada local continua funcionando.

1. Gere o manifesto completo (não diferencial) a partir dos assets que serão publicados:

   ```sh
   npm install
   npm run manifest:assets -- --version 1 --base-url https://SEU-DOMINIO/kix-assets/ --output update-manifest.json
   ```

2. Publique `app/src/main/assets/kix/` no caminho base informado e publique `update-manifest.json` em um endereço HTTPS estável. A cada release de assets, incremente `--version`, publique os arquivos primeiro e o manifesto por último.

3. Compile passando o endereço real do manifesto:

   ```sh
   KIX_UPDATE_MANIFEST_URL=https://SEU-DOMINIO/kix-assets/update-manifest.json gradle clean assembleDebug --no-daemon
   ```

   Também pode ser usado o argumento Gradle `-PkixUpdateManifestUrl=https://...`.

O gerador inclui todos os arquivos regulares de forma determinística e calcula `size` e `sha256`. O atualizador rejeita qualquer caminho não relativo, hash inválido, transferência acima dos limites, redirect HTTP ou conteúdo cujo SHA-256 não corresponda ao manifesto. O manifesto não é uma assinatura digital: o endpoint deve ser protegido (HTTPS, controle de acesso e processo seguro de publicação); para modelo de ameaça que inclua comprometimento do servidor/CDN, acrescente assinatura Ed25519 verificada no aplicativo.

## Build do Paint com Esbuild

A fonte canônica fica em `src/paint/`: `kix-paint.js`, `kix-paint-algorithms.mjs`, `kix-paint-brush.js` e `kix-paint.css`. O `index.html` da raiz importa esses arquivos durante o desenvolvimento; `DEVELOPMENT/index.html` apenas redireciona para ele, sem duplicar a página. Não mantenha cópias editáveis em `DEVELOPMENT/` ou `app/src/main/assets/kix/`.

```sh
npm install --no-audit --no-fund
npm run build:paint
npm test
```

O build gera `app/src/main/assets/kix/kix-paint.bundle.js`, copia o CSS e os scripts usados pelo editor, e produz o `index.html` Android com caminhos relativos à pasta de assets. A pasta `app/src/main/assets/kix/` é uma saída gerada; altere os arquivos em `src/paint/` e rode o build para atualizá-la. O teste de integração verifica essa regra.

## Verificação

- `npm run test:paint`: testes do algoritmo real do flood fill (4-connected), da expansão pós-máscara e da seleção global separada.
- O APK precisa ser compilado e executado em Android para validar a integração WebView e o endpoint no dispositivo. Essa compilação não é declarada como aprovada até ser executada em ambiente com SDK Android e Gradle.

## Build rápido no Termux

Depois de extrair o ZIP e garantir que o projeto Android já tem acesso ao SDK/Gradle, execute:

```sh
bash BUILD_KIX_DEBUG_TERMUX.sh
```

O script instala esbuild, gera o bundle, executa testes/paridade/paleta, compila `assembleDebug` e copia o APK para `~/storage/downloads/KixV33_NATIVE_EXPORT_paint_FIXED-debug.apk`. Se estiver usando outro `aapt2`, defina `KIX_AAPT2=/caminho/para/aapt2` antes do comando. Para habilitar atualização remota no APK, defina `KIX_UPDATE_MANIFEST_URL=https://SEU-DOMINIO/manifest.json` antes do build; a URL precisa apontar para um manifesto real publicado em HTTPS.
