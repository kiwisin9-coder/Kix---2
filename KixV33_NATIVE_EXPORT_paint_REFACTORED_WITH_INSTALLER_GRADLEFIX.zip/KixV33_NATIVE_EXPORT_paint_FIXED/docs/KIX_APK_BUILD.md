# KixV33 — Pipeline de APK

## Fluxo

`Editor → contrato kix-apk-build-request-v1 → worker local autenticado → compilador → Gradle/Android SDK → APK`

O worker aceita `debug` e `release`, processa cada job em diretório descartável, aplica timeout e limites CPU/memória quando o host fornece `prlimit`, e devolve eventos de progresso + artefato quando o build termina. A chave de assinatura nunca é embutida no projeto nem recebida no JSON do job.

## Comandos

```bash
node tools/kix-apk-compiler.mjs doctor
node tools/kix-apk-compiler.mjs build projeto.kix --manifest projeto-apk-build.json --out projeto-debug.apk
node tools/kix-apk-compiler.mjs build projeto.kix --manifest projeto-apk-build.json --out projeto-release.apk --release
node tools/kix-apk-builder-server.mjs
```

## Requisitos verificados pelo compiler

- Node.js 18+
- JDK 17+ com `javac`
- Android SDK API 35
- Build Tools 35.0.0
- Gradle 9.6.0 ou wrapper presente no diretório gerado
- ferramentas de inspeção: `aapt2`, `apkanalyzer`, `apksigner`

Neste ambiente, Node 22.16.0, Java/Javac 21.0.11 e keytool estão presentes; Gradle, Android SDK, adb, aapt2, apkanalyzer e apksigner estão ausentes. Portanto o pipeline foi preparado e testado até `--prepare-only`, mas APK real permanece **NÃO VERIFICADO**.

## Assinatura

Release exige exclusivamente as variáveis de ambiente:

```text
KIX_KEYSTORE
KIX_STORE_PASSWORD
KIX_KEY_ALIAS
KIX_KEY_PASSWORD
```

`tools/kix-signing.mjs` cria/consulta keystore usando segredos do ambiente. Não existe arquivo lateral de senha e o compiler não deriva senha do `applicationId`.

## Atualização

`versionCode` é persistido por projeto/package ID após build bem-sucedido. Um `versionCode` explícito menor ou igual ao histórico é bloqueado antes da compilação. Mudança de certificado em relação ao histórico release também é bloqueada antes do build.

## Conteúdo do APK

O template copia somente:

- `project.json`
- `project.sha256`
- `format.json`
- `runtime.html`
- `runtime.js` (runtime canônico)
- `kix-runtime-services.js`
- `kix-data-format.js`
- `kix-phase3-runtime.js`
- `MainActivity.java` compilado

Não são copiados `app.js`, `kix-phase2.js`, `kix-quality.js`, editor visual, compilador ou arquivos equivalentes.

## Inspeção obrigatória

O compiler só declara sucesso depois de executar:

```bash
aapt2 dump badging app.apk
apkanalyzer manifest print app.apk
apkanalyzer files list app.apk
apksigner verify --verbose --print-certs app.apk
```

Sem essas ferramentas, o processo termina como falha de verificação, não como sucesso presumido.

---

# Exportação nativa (no aparelho) — modo padrão no app Android

Dentro do app Kix, **Exportar APK** não usa servidor, Node, Gradle nem rede. O próprio APK do editor serve de modelo:

`Editor → Android.startBuild (ponte) → ApkExporter → AxmlPatcher → ApkPackager (ZIP + assinatura v2) → Downloads/Kix`

- Remove os assets do editor; mantém `runtime.html`, `runtime.js` e serviços; grava `project.json`, `project.sha256`, `format.json` e `exported.flag`.
- Edita o `AndroidManifest.xml` binário: package, versionCode/Name, label, orientação, min/target SDK, permissões (só as marcadas) e remove `<permission>`/`<provider>` herdados de bibliotecas (conflitariam com o editor na instalação).
- Substitui os ícones `res/mipmap-*/ic_launcher.png`.
- Assina com APK Signature Scheme v2 (suficiente para minSdk ≥ 24). A chave RSA-2048 é criada uma vez por aparelho, guardada cifrada (AES-GCM com chave no Android Keystore). O fingerprint e o versionCode ficam registrados por package; troca de chave ou versionCode ≤ anterior bloqueia a exportação.
- Verifica a própria assinatura/digest antes de declarar sucesso.
- Um APK exportado (`exported.flag`) abre direto o `runtime.html` e não expõe a ponte de build.

**Limites conhecidos:** “Minha chave” ainda não existe no app (usa a chave gerenciada); sem v1/v3; em Android < 10 o APK vai para a pasta de downloads do app, sem botão Instalar; ícone adaptativo não é gerado.

Teste do núcleo em PC: `tools/native-export-selftest/run.sh`.
O worker Node (acima) continua existindo apenas como modo desenvolvedor/navegador.
