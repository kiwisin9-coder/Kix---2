# Relatório da auditoria — Kix Paint

## Alterações

### Conta-gotas

- Lupa de leitura em camada DOM independente do canvas editável.
- Prévia de até 11 × 11 pixels com interpolação desligada e célula selecionada marcada com contorno preto/branco.
- Amostra de cor e HEX; HEX ocultado em palco estreito.
- Arrastar atualiza a amostra; a cor é aplicada no `pointerup`. `pointercancel` cancela a captura.
- Ao concluir, restaura a ferramenta anterior; usa pincel como fallback.
- O overlay tem `pointer-events: none`; não escreve no canvas principal.

### Balde

- `fillRgba()` calcula a região conectada por quatro vizinhos a partir do pixel tocado; não existe modo global de cores semelhantes no balde.
- A tolerância compara cada vizinho com a cor do pixel inicial. A implementação é iterativa para não depender da pilha de recursão.
- Pixel Art força tolerância 0 e expansão 0. A expansão normal é uma fase posterior à máscara e começa desativada (0 px).
- A seleção global por cor continua separada para a varinha mágica.

### Android e assets

- Os assets do editor são copiados para `filesDir/kix` na primeira execução e quando muda a versão do APK.
- O editor normal usa `WebViewAssetLoader` e uma pasta privada dedicada. O caminho `.mjs` recebe MIME JavaScript explícito.
- O cliente de atualização aceita apenas HTTPS, valida caminhos, tamanhos e SHA-256, instala uma árvore completa preparada e preserva o backup quando um rollback falha.
- O endpoint remoto não foi fornecido e não foi inventado; sem `KIX_UPDATE_MANIFEST_URL`, o check remoto fica desativado.
- Os APKs exportados com `kix/exported.flag` continuam usando o `runtime.html` embutido.

## Verificações desta refatoração estrutural

| Verificação executada | Resultado |
|---|---:|
| Testes puros de flood fill / máscara | 9/9 PASS |
| Testes de integração selecionados (conta-gotas, balde, Android, manifesto) | 4/4 PASS |
| Parse sintático dos módulos JS/MJS alterados | PASS |
| Auditoria de paleta do Kix Paint | 0 violações |
| `engine.js` vs `runtime/kix-runtime.js` | Hash idêntico |
| Paridade de runtime | PASS |
| Auditoria estrutural da Fase 2 | 27 verificações PASS |
| Bundle real com Esbuild + suíte completa de integração | Pendente |

Os quatro testes de integração foram executados com filtro porque a dependência `esbuild` não pôde ser instalada neste ambiente. A suíte completa valida o bundle gerado e deve ser executada pelo script Termux, que instala a dependência antes de compilar.

## Itens não verificados

- **❓ NÃO VERIFICADO:** compilação real do APK, pois o ambiente da auditoria não possui Gradle, Android SDK, `adb` ou `aapt2`.
- **❓ NÃO VERIFICADO:** build do bundle Esbuild e suíte completa de integração. A instalação da dependência expirou por falta de acesso ao registro npm nesta execução. O APK pode ser compilado pelo script Termux após a instalação bem-sucedida; o script gera os assets antes do Gradle.
- **❓ NÃO VERIFICADO:** atualização remota em dispositivo, porque nenhum manifesto/servidor HTTPS real foi configurado.
- **❓ NÃO VERIFICADO:** interação visual/táctil em aparelho Android real. Os testes do conta-gotas são estáticos/de integração de fonte; os seis cenários de flood fill exercitam o algoritmo e os buffers RGBA reais.

## Referências técnicas

- Esbuild API: https://esbuild.github.io/api/
- `WebViewAssetLoader.InternalStoragePathHandler`: https://developer.android.com/reference/androidx/webkit/WebViewAssetLoader.InternalStoragePathHandler
- Armazenamento específico do app: https://developer.android.com/training/data-storage/app-specific
