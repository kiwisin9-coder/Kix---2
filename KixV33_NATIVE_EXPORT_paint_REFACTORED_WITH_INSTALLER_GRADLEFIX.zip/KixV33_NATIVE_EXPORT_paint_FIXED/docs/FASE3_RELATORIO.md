# Relatório Fase 3 — Catrobat + Runtime

**Data:** 2026-10-02

## Gate comportamental

Comando:

```bash
KIX_PHASE3_RESULTS=build/phase3-test-results.json node tools/kix-phase3-tests.mjs
```

Resultado executado: **18/18 testes passando; 0 falhas**. Hash do trace do projeto-demo: **54b91831**. A rotina de demo é executada três vezes e os traces/estado são comparados byte a byte por JSON; o hash permaneceu idêntico.

## Testes cobertos

| Item | Estado | Evidência |
|---|---|---|
| Parser de fórmulas | COMPLETO | precedência, associatividade, parênteses e avaliação reais; suíte verde |
| Strings/booleanos/listas em fórmulas | COMPLETO | casos comportamentais |
| Divisão por zero/diagnóstico | COMPLETO | `FORMULA_DIV_ZERO` verificado |
| Fuzz de fórmulas | COMPLETO | 250 casos × 5 famílias de expressões, sem exceção não tratada/NaN |
| Relógio/PRNG injetáveis | COMPLETO | resultado determinístico no harness |
| Listas 1-based | COMPLETO | CRUD + limites + diagnóstico |
| Undo/redo | COMPLETO | mutação de lista + undo + redo auditados |
| Broadcast / Broadcast and Wait | COMPLETO | ordem e espera real de receivers |
| Ciclo de broadcast | COMPLETO | diagnóstico `BROADCAST_CYCLE` |
| Receiver runtime | COMPLETO | registro, dispatch determinístico, isolamento de erro e limpeza |
| Sensores determinísticos | COMPLETO | GPS/acelerômetro/loudness com permissão/fallback no harness |
| Provider Android real | PARCIAL | bridge Android implementada; execução física não verificada |
| Clones | COMPLETO | criação, limite, clone de clone, deleção e limpeza |
| UserDefinedBrick | COMPLETO | parâmetros tipados, chamada e retorno de controle |
| Recursão UserDefinedBrick | COMPLETO | limite + diagnóstico `USER_BRICK_RECURSION` |
| Persistência N-1 → N | COMPLETO | migração format 1 → 2 sem perda de globals/lists |
| Stop/cleanup | COMPLETO | timers, receivers e clones zerados |
| Paridade editor/runtime | COMPLETO | `tools/kix-runtime-parity.mjs`, hashes/traces iguais |

## Coverage Matrix

Gerados automaticamente a partir do catálogo Catrobat real em `app.js` + IDs de teste:

- 32 entradas catalogadas.
- 13 marcadas `COMPLETO`.
- 19 marcadas `PARCIAL`.
- Cobertura literal da matriz: **40,63%**.
- Suíte comportamental: **18/18**.

A diferença entre os números é intencional: a matriz inclui o catálogo Catrobat encontrado no projeto, enquanto o escopo operacional da Fase 3 cobre fórmulas, broadcasts, listas, clones, sensores, UserDefinedBrick e Receiver runtime. Os demais bricks permanecem listados como PARCIAL e não foram promovidos sem teste comportamental dedicado.

Arquivo: `brick_coverage.json`. Tabela legível: `docs/BRICK_COVERAGE_MATRIX.md`.

## Fontes Catrobat

A matriz usa como referência a documentação oficial do Catrobat: Brick Documentation, Control, Event, Data, Motion, Sound e YourBricks, consultadas em 2026-10-02.

## Demo determinística

`tools/kix-runtime-parity.mjs` executa o mesmo projeto-demo com `engine.js` e `runtime/kix-runtime.js`. O resultado final teve `ok: true` e os traces foram equivalentes.

## Lacunas Fase 3

A execução de sensores físicos Android ainda não pode ser certificada aqui porque não há APK instalado nem dispositivo/emulador. Microfone/loudness e face detection possuem modelo de permissão/fallback; o provider físico correspondente permanece **PARCIAL / NÃO VERIFICADO** neste ambiente.
