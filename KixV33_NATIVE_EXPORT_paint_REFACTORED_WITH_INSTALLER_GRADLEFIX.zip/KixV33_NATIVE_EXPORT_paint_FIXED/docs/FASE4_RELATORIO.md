# Relatório Fase 4 — Kix Android Runtime + Pipeline de APK

**Data:** 2026-10-02

## 1. Ambiente

`node tools/kix-apk-compiler.mjs doctor` retornou:

```json
{
  "node":"v22.16.0",
  "java":true,
  "javac":true,
  "keytool":true,
  "gradle":false,
  "adb":false,
  "aapt2":false,
  "apkanalyzer":false,
  "apksigner":false,
  "androidSdk":null,
  "compileSdk":35,
  "buildTools":"35.0.0",
  "agp":"9.4.0",
  "gradleVersion":"9.6.0",
  "webkit":"1.17.0"
}
```

Conclusão factual: o ambiente não possui os binários necessários para produzir e verificar APK real.

## 2. Template Android

| Item | Estado | Evidência |
|---|---|---|
| applicationId validado | COMPLETO | validação no compiler + teste de preparação |
| nome/ícone/orientação | COMPLETO | template parametrizado |
| permissões derivadas | COMPLETO | `derivePermissions()` + manifest gerado mínimo |
| WebViewAssetLoader | COMPLETO | `MainActivity.java` usa `appassets.androidplatform.net` |
| file access inseguro | COMPLETO | file/content/universal file access desativados |
| PermissionRequest | COMPLETO | somente áudio/vídeo correspondentes a permissões concedidas |
| lifecycle | COMPLETO estrutural | onCreate/Start/Resume/Pause/Stop/Destroy + save state |
| multi-window/back | COMPLETO estrutural | callbacks implementados |
| hash de projeto | COMPLETO estrutural | `project.sha256` + Web Crypto no runtime |
| migração de save | COMPLETO headless | teste N-1 → N |

## 3. Build real

| Artefato | Status | Evidência |
|---|---|---|
| APK debug | **NÃO VERIFICADO** | Gradle/SDK ausentes |
| APK release | **NÃO VERIFICADO** | Gradle/SDK ausentes |
| inspeção aapt2 | **NÃO VERIFICADO** | `aapt2` ausente |
| inspeção apkanalyzer | **NÃO VERIFICADO** | `apkanalyzer` ausente |
| assinatura/apksigner | **NÃO VERIFICADO** | `apksigner` ausente |
| instalação adb | **NÃO VERIFICADO** | `adb` ausente |
| smoke test físico | **NÃO VERIFICADO** | sem emulador/dispositivo |

## 4. Release/R8/assinatura

O compiler agora gera `minifyEnabled true` e `shrinkResources true` para release e mantém regras para `JavascriptInterface`, AndroidX WebKit e classes `com.kix.runtime`.

A assinatura exige `KIX_KEYSTORE`, `KIX_STORE_PASSWORD`, `KIX_KEY_ALIAS` e `KIX_KEY_PASSWORD` no ambiente. `tools/kix-signing.mjs` cria/consulta keystores sem senha em arquivo lateral.

A validação de atualização usa histórico persistente de `versionCode` e fingerprint. O teste `tools/kix-update-policy.test.mjs` executou **2/2** checks: regressão bloqueada; incremento aceito.

Fingerprint SHA-256 de um APK release: **NÃO DISPONÍVEL**, porque nenhum APK release foi produzido neste ambiente.

## 5. Worker isolado

Comando:

```bash
node tools/kix-apk-builder-server.test.mjs
```

Resultado: **8/8 checks verdes**.

Cobertura:

- origem CORS restrita;
- autenticação obrigatória;
- job debug preparado;
- fila/concor­rência;
- rejeição de path traversal;
- timeout;
- cancelamento;
- crash do filho isolado.

O worker usa `spawn` assíncrono, diretório temporário por job, limite de corpo, fila configurável, timeout, cancelamento, limites CPU/memória via `prlimit` quando disponível, SSE de eventos e token de sessão aleatório. O CORS deixa de usar wildcard e é restrito à origem configurada.

## 6. Runtime Android

`MainActivity` agora usa WebViewAssetLoader, lifecycle explícito, restauração de WebView/estado, filtro de `PermissionRequest`, bridge para estado persistente e leitura de sensores físicos básicos (acelerômetro, giroscópio, magnetômetro/compass e localização last-known).

A execução desse código Java dentro de um APK permanece **NÃO VERIFICADA** por falta de SDK/Gradle.

## 7. Paridade debug/release

**NÃO VERIFICADO** em APK porque os builds não foram possíveis neste ambiente. A paridade do runtime JavaScript foi verificada separadamente por `tools/kix-runtime-parity.mjs`.

## 8. Atualização v1 → v2

**NÃO VERIFICADO** no dispositivo. O mecanismo de versionCode e migração foi testado em Node; o teste real de `adb install -r` e restauração em app instalado depende de ADB + APK.

## 9. Integridade do APK

O compiler não declara sucesso sem executar `aapt2`, `apkanalyzer` e `apksigner`. Como essas ferramentas estão ausentes, nenhum APK foi anexado como supostamente verificado.

## 10. Lacunas e riscos

1. Build/inspeção/instalação de APK: NÃO VERIFICADO.
2. Provider físico de microfone/loudness e face detection: PARCIAL/NÃO VERIFICADO.
3. Execução em rotação/process death real: código presente, teste físico NÃO VERIFICADO.
4. Atualização real v1 → v2 com persistência: NÃO VERIFICADO.
5. Fingerprint real de release: NÃO VERIFICADO.
6. Regras R8 em APK real: NÃO VERIFICADO.

Para fechar esses pontos em outra máquina, instalar Node/JDK 17+, Android SDK API 35 + Build Tools 35.0.0, Gradle 9.6.0, `aapt2`, `apkanalyzer`, `apksigner`, ADB e um emulador/dispositivo; então executar a suíte da seção 11 abaixo.

## 11. Sequência de verificação externa

```bash
node tools/kix-apk-compiler.mjs doctor
node tools/kix-apk-compiler.test.mjs
node tools/kix-update-policy.test.mjs
node tools/kix-apk-builder-server.test.mjs
node tools/kix-phase3-tests.mjs
node tools/kix-runtime-parity.mjs
node tools/kix-apk-compiler.mjs build examples/fase3-demo.kix.json --manifest examples/fase3-demo-build.json --out build/kix-demo-debug.apk
node tools/kix-apk-compiler.mjs build examples/fase3-demo.kix.json --manifest examples/fase3-demo-build.json --out build/kix-demo-release.apk --release
adb devices
aapt2 dump badging build/kix-demo-debug.apk
apkanalyzer manifest print build/kix-demo-debug.apk
apkanalyzer files list build/kix-demo-debug.apk
apksigner verify --verbose --print-certs build/kix-demo-release.apk
adb install -r build/kix-demo-debug.apk
adb install -r build/kix-demo-release.apk
```
