# Brick Coverage Matrix

Gerado automaticamente em 2026-10-02T18:32:31.634Z.
Fonte efetiva do registry: app.js:KIX_CATROBAT_CATEGORIES. Testes: tools/kix-phase3-tests.mjs.
Cobertura real da matriz: **40.63%** (13/32); suíte comportamental: **18/18** passando.

| Brick | Categoria | Parâmetros | Estado | Teste(s) | Runtime/arquivo | Observações |
|---|---|---|---|---|---|---|
| event.when_background_changes — When background changes to | Event | "[{\"name\":\"background\",\"type\":\"text\",\"default\":\"\"\"\"}]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| event.when_scene_starts — When scene starts | Event | "[]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| event.when_stage_tapped — When stage is tapped | Event | "[]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| event.when_tapped — When tapped | Event | "[]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| event.when_receive — When you receive | Event | "[{\"name\":\"message\",\"type\":\"text\",\"default\":\"\"\"\"}]" | COMPLETO | broadcast receiver filtering and cycle diagnostic, broadcast and wait waits for all receivers | runtime/kix-phase3-runtime.js / engine.js | Execução real no harness; cobertura marcada completa segundo escopo Phase3 testado. |
| event.when_clone_starts — When you start as a clone | Event | "[]" | COMPLETO | clone create/delete lifecycle | runtime/kix-phase3-runtime.js / engine.js | Execução real no harness; cobertura marcada completa segundo escopo Phase3 testado. |
| event.when_condition_true — When(…) becomes true | Event | "[\"condition\"]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| control.broadcast — Broadcast | Control | "[\"message\"]" | COMPLETO | broadcast receiver filtering and cycle diagnostic, demo trace deterministic across three runs | runtime/kix-phase3-runtime.js / engine.js | Execução real no harness; cobertura marcada completa segundo escopo Phase3 testado. |
| control.broadcast_wait — Broadcast and wait | Control | "[\"message\"]" | COMPLETO | broadcast and wait waits for all receivers | runtime/kix-phase3-runtime.js / engine.js | Execução real no harness; cobertura marcada completa segundo escopo Phase3 testado. |
| control.continue_scene — Continue scene | Control | "[]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| control.create_clone — Create clone of | Control | "[\"object\"]" | COMPLETO | clone create/delete lifecycle, demo trace deterministic across three runs | runtime/kix-phase3-runtime.js / engine.js | Execução real no harness; cobertura marcada completa segundo escopo Phase3 testado. |
| control.delete_clone — Delete this clone | Control | "[]" | COMPLETO | clone create/delete lifecycle | runtime/kix-phase3-runtime.js / engine.js | Execução real no harness; cobertura marcada completa segundo escopo Phase3 testado. |
| control.finish_stage — Finish stage | Control | "[]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| control.for_each — For each value from .. in .. | Control | "[\"value\",\"source\"]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| control.for_range — For values from 1 to 10 in | Control | "[\"from\",\"to\",\"value\"]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| control.forever — Forever | Control | "[]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| control.if_else — If … Then … Else … | Control | "[\"condition\"]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| control.if — If(…) is true then | Control | "[\"condition\"]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| control.note — Note | Control | "[\"text\"]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| control.repeat — Repeat … times | Control | "[\"times\"]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| control.repeat_until — Repeat until … | Control | "[\"condition\"]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| control.start_scene — Start scene | Control | "[\"scene\"]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| control.stop — Stop | Control | "[]" | COMPLETO | stop clears timers receivers and clones | runtime/kix-phase3-runtime.js / engine.js | Execução real no harness; cobertura marcada completa segundo escopo Phase3 testado. |
| control.wait — Wait | Control | "[\"seconds\"]" | COMPLETO | broadcast and wait waits for all receivers | runtime/kix-phase3-runtime.js / engine.js | Execução real no harness; cobertura marcada completa segundo escopo Phase3 testado. |
| control.wait_until — Wait until … is true | Control | "[\"condition\"]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| control.wait_until_scripts_stopped — Wait until all other scripts have stopped | Control | "[]" | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Registro Catrobat presente, mas execução completa/undo-redo ainda não cobertos pelo escopo Phase3. |
| phase3.sensor.gps — GPS latitude/longitude/precisão | Device/Sensors | number + permission:location | COMPLETO | deterministic sensors + permission fallback | runtime/kix-phase3-runtime.js / engine.js | SensorHub determinístico, permissão e fallback testados. |
| phase3.sensor.accelerometer — Acelerômetro X/Y/Z | Device/Sensors | number | COMPLETO | deterministic sensors + permission fallback | runtime/kix-phase3-runtime.js / engine.js | Provider determinístico e leitura por fórmula testados. |
| phase3.sensor.microphone — Loudness | Device/Sensors | normalized + permission:microphone | PARCIAL | — | runtime/kix-phase3-runtime.js / engine.js | Fallback e permission model existem; provider Android real não foi executado sem APK. |
| phase3.user_defined_brick — UserDefinedBrick | User Bricks | typed positional parameters, return/control | COMPLETO | typed UserDefinedBrick invocation and recursion guard, recursion diagnosis | runtime/kix-phase3-runtime.js / engine.js | Definição, parâmetros tipados, chamada e limite de recursão testados no runtime. |
| phase3.receiver.runtime — Receiver runtime | Event | owner,type,eventId | COMPLETO | broadcast and wait waits for all receivers, stop clears timers receivers and clones | runtime/kix-phase3-runtime.js / engine.js | Registro, dispatch determinístico, isolamento e limpeza testados. |
| phase3.formula.engine — Formula parser/runtime | Formula | numeric,string,boolean,list,sensors | COMPLETO | formula precedence and associativity, formula strings/booleans/list functions, formula property fuzz seeded | runtime/kix-phase3-runtime.js / engine.js | Precedência, unário, overflow/div0 diagnóstico, strings/listas e fuzz semeado testados. |

## Critério de COMPLETO
Parse/representação válida + execução no runtime + serialização/estado + undo/redo quando houver estado mutável + teste comportamental verde. Para eventos sem mutação, a auditoria considera preservação de estado.

## Escopo excluído
Os bricks restantes do catálogo oficial permanecem PARCIAL e são listados explicitamente; eles não são promovidos a COMPLETO por inferência textual.

## Referências oficiais
- Catrobat Brick Documentation
- Control / Event / Data / Motion / Sound / YourBricks
