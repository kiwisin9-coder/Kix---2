# Auditoria da Fase 2 — KixV33

**Data:** 2026-10-02  
**Fonte de verdade:** ZIP enviado para a tarefa, extraído em `/mnt/data/kixv33_work/kixapk`.  
**Regra:** afirmações de runtime são aceitas somente com execução ou evidência estrutural identificável.

## 1. Baseline executado antes das alterações desta fase

| Item | Resultado observado no baseline | Estado da afirmação |
|---|---|---|
| `node tools/kix-apk-compiler.mjs doctor` | Node 22.16.0; Java/Javac/keytool presentes; Gradle, SDK e ferramentas Android ausentes | CONFIRMADO |
| `node phase2-audit.mjs` original | `checks:71` | CONFIRMADO como auditoria estrutural/regex; não prova comportamento |
| `node tools/kix-apk-compiler.test.mjs` original | `checks:14` | CONFIRMADO; era teste de preparação, não build real |
| `runtime/kix-runtime.js` vs `engine.js` | byte-idênticos; SHA-256 baseline `78aec3ec6c1b587be2494515ffdc096f8eb38fc8644d0838e154b3626cc843b0` | CONFIRMADO |
| `runtime.html` | continha implementações no-op para Lifecycle/Profiler/Debugger/PluginRuntime/CatroidCompatibility | CONFIRMADO |
| APK real | não havia build/inspeção real disponível no ambiente | CONFIRMADO como NÃO VERIFICADO |
| worker | `spawnSync`, sem fila/cancelamento/timeout/autenticação robusta no baseline | CONFIRMADO |
| MainActivity | acesso `file://`/permissões incondicionais/aceitação ampla de `PermissionRequest` no baseline | CONFIRMADO |
| versionCode | derivação direta do semver no baseline | CONFIRMADO |
| release R8 | `minifyEnabled false` no baseline | CONFIRMADO |
| senha de keystore | derivada do package ID + arquivo lateral no baseline | CONFIRMADO |

## 2. Arquitetura real encontrada

`index.html` carrega a superfície de edição (`app.js`) e o runtime. A execução principal continua sendo JavaScript no navegador/WebView. O runtime canônico agora é `runtime/kix-runtime.js`; `engine.js` é uma cópia sincronizada para manter compatibilidade com o editor.

O registro Catrobat real está em `app.js`, em `KIX_CATROBAT_CATEGORIES` e no instalador que expõe `window.KixCatrobatBrickRegistry`, `window.KixCatrobatBrickAliases` e `window.KixCatrobatCompatCatalog`. `kix-plugins.js` é o subsistema genérico de plugins e não é a fonte primária desse catálogo.

## 3. Mapa de responsabilidades

| Área | Editor | Runtime | Plugins | Fase 3/4 |
|---|---|---|---|---|
| UI/edição de blocos | `app.js` | — | `kix-plugins.js` | fora do APK |
| execução de scripts | `app.js` + `engine.js` | `runtime/kix-runtime.js` | handlers opcionais | migrado para runtime |
| lifecycle/timers | `kix-phase2.js`/engine | `kix-runtime-services.js` | — | real |
| diagnóstico/profiler/debugger | `kix-phase2.js` | `kix-runtime-services.js` | — | runtime real, sem UI de editor |
| broadcasts/receivers | parcialmente no engine baseline | `kix-phase3-runtime.js` + `ReceiverRegistry` | — | coberto por testes |
| listas | parte no editor + engine | runtime | — | execução + persistência + undo/redo |
| clones | editor + engine baseline | runtime | — | lifecycle/limite/limpeza |
| UserDefinedBrick | majoritariamente `app.js` no baseline | runtime | — | definição/chamada/recursão |
| APK | compiler/server baseline | Android runtime novo | — | template isolado |

## 4. Dívidas que bloqueavam a Fase 3/4

1. Runtime duplicado como arquivo do editor.
2. Serviços Android/runtime no-op.
3. Falta de harness headless executando o engine real.
4. Cobertura de broadcasts/listas/clones/sensores/UserDefinedBrick não demonstrada por comportamento.
5. Pipeline Android sem inspeção obrigatória do APK.
6. Assinatura e versionCode inseguros/não auditados.
7. Worker síncrono e sem isolamento suficiente.

## 5. Estado após a implementação

A auditoria estrutural atual foi executada por `node phase2-audit.mjs`: **26 verificações estruturais verdes**. Ela consulta também o `doctor`; não substitui os testes comportamentais.

Separação foi verificada com `node tools/sync-runtime.mjs`: `engine.js` e `runtime/kix-runtime.js` continuam byte-idênticos, SHA-256 final `c3c0d9a570e9b222bb7691e7005936b756734c626fea49f301f4cd6f5217df1a`.

Busca no runtime canônico não encontra `app.js`, `editor`, `inspector`, `KixPhase2`, `KixQuality` ou `KixBrickHistory`.

## 6. Limitações

A ausência de Gradle/Android SDK/ADB/aapt2/apkanalyzer/apksigner impede construir e abrir/inspecionar APK real neste ambiente. Todo item dependente desses binários fica **NÃO VERIFICADO**, mesmo com scripts prontos.
