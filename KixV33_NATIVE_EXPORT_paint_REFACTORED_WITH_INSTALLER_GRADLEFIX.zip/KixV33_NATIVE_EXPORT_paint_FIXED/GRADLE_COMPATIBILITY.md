# Gradle/AGP compatibility

The build uses **Android Gradle Plugin 9.4.0** and is intended to run with **Gradle 9.6.0**.

Reason: AGP 8.x cannot run on Gradle 9.6 because Gradle 9.6 removed internal Problems API classes used by AGP 8.x. AGP 9.4.0 officially requires Gradle 9.6.0.

The project intentionally produces APKs only. No AAB/bundle workflow is configured.

Recommended environment:
- Gradle 9.6.0
- JDK 17
- Android SDK platform 35
- Android SDK Build Tools 35.0.0 (explicitly configured)
