#!/usr/bin/env node
import fs from 'node:fs';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';

const root = new URL('../', import.meta.url).pathname;
const required = ['index.html','app.js','engine.js','kix-phase2.js','kix-quality.js','kix-drag-model.js','kix-sortable-lite.js','runtime/kix-runtime.js','runtime/kix-runtime-services.js','runtime/kix-phase3-runtime.js','runtime/kix-data-format.js'];
for (const file of required) assert.ok(fs.existsSync(root + file), `missing ${file}`);
const phase2 = fs.readFileSync(root+'kix-phase2.js','utf8');
const quality = fs.readFileSync(root+'kix-quality.js','utf8');
const index = fs.readFileSync(root+'index.html','utf8');
const app = fs.readFileSync(root+'app.js','utf8');
const engine = fs.readFileSync(root+'engine.js','utf8');
const runtimeSource = fs.readFileSync(root+'runtime/kix-runtime.js','utf8');
const services = fs.readFileSync(root+'runtime/kix-runtime-services.js','utf8');
const phase3 = fs.readFileSync(root+'runtime/kix-phase3-runtime.js','utf8');
const compiler = fs.readFileSync(root+'tools/kix-apk-compiler.mjs','utf8');
const worker = fs.readFileSync(root+'tools/kix-apk-builder-server.mjs','utf8');
const runtimeTemplate = fs.readFileSync(root+'android-runtime/src/main/assets/kix/runtime.html','utf8');
const activity = fs.readFileSync(root+'android-runtime/src/main/java/com/kix/runtime/MainActivity.java','utf8');
const checks = [
  ['Phase2 router',/class DeterministicRouter/.test(phase2)],
  ['Phase2 lifecycle',/class Lifecycle/.test(phase2)&&/clearAll\(\)/.test(phase2)],
  ['Phase2 profiler',/measureAsync\(name,fn\)/.test(phase2)&&/record\(name,ms\)/.test(phase2)],
  ['Phase2 debugger',/debugEmit/.test(phase2)&&/KixDebugger/.test(engine)],
  ['Phase2 history',/KixHistoryAudit/.test(phase2)&&/history\.undo/.test(phase2)&&/history\.redo/.test(phase2)],
  ['Phase2 quality',/KixQuality/.test(quality)&&/analyze\(project\)/.test(quality)],
  ['Headless script path',/kix-headless-harness\.mjs/.test(fs.readFileSync(root+'tools/kix-phase3-tests.mjs','utf8'))],
  ['Runtime services real',/class Lifecycle/.test(services)&&/const profiler/.test(services)&&/const debuggerApi/.test(services)],
  ['Event router real',/class EventRouter/.test(services)&&/class ReceiverRegistry/.test(services)],
  ['Undo redo real',/class UndoRedo/.test(services)&&/function undo\(/.test(phase3)&&/function redo\(/.test(phase3)],
  ['No editor runtime copy',!runtimeSource.includes('KixBrickHistory')&&!runtimeSource.includes('KixPhase2')&&!runtimeSource.includes('KixQuality')],
  ['No editor module asset',!compiler.includes('app.js')&&!compiler.includes('kix-phase2.js')&&!compiler.includes('kix-quality.js')],
  ['Runtime integrity assets',/project\.sha256/.test(runtimeTemplate)&&/sha256Json/.test(runtimeTemplate)],
  ['WebViewAssetLoader',/WebViewAssetLoader/.test(activity)&&/appassets\.androidplatform\.net/.test(activity)],
  ['WebView file access disabled',/setAllowFileAccess\(false\)/.test(activity)&&/setAllowUniversalAccessFromFileURLs\(false\)/.test(activity)],
  ['Permission filtering',/declaredGranted/.test(activity)&&/PermissionRequest/.test(activity)],
  ['Async worker',/spawn\(/.test(worker)&&!worker.includes('spawnSync(')],
  ['Worker resource limits',/CPU_SEC/.test(worker)&&/AS_MB/.test(worker)&&/prlimit/.test(worker)],
  ['Worker queue',/CONCURRENCY/.test(worker)&&/queue/.test(worker)],
  ['Worker auth',/X-Kix-Session/.test(worker)&&/randomBytes\(32\)/.test(worker)],
  ['Release R8',/minifyEnabled true/.test(compiler)&&/shrinkResources true/.test(compiler)],
  ['External signing secrets',/KIX_STORE_PASSWORD/.test(compiler)&&!/\.password/.test(compiler)],
  ['Version history',/chooseVersionCode/.test(compiler)&&/persistVersion/.test(compiler)],
  ['Only APK tasks',/assembleDebug/.test(compiler)&&/assembleRelease/.test(compiler)],
  ['Format migration',/CURRENT_FORMAT = 2/.test(fs.readFileSync(root+'runtime/kix-data-format.js','utf8'))&&/version === 1/.test(fs.readFileSync(root+'runtime/kix-data-format.js','utf8'))&&/data.vars/.test(fs.readFileSync(root+'runtime/kix-data-format.js','utf8'))],
  ['Deterministic providers',/KixDeterminism/.test(services)&&/KixSensorHub/.test(services)],
  ['No placeholder tokens',!new RegExp('TODO IMPLEMENT|PLACEHOLDER_IMPLEMENTATION|fake implementation','i').test(phase2+runtimeSource+services+phase3+compiler+worker)],
];
for (const [name,ok] of checks) assert.ok(ok,name);
const structural = checks.length;
const doctor = JSON.parse(spawnSync(process.execPath,['tools/kix-apk-compiler.mjs','doctor'],{cwd:root,encoding:'utf8'}).stdout);
console.log(JSON.stringify({ok:true,checks:structural,doctor,legacyStaticAudit:'replaced-by-real-structural-audit'},null,2));
