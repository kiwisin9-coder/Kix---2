# Ambiente de desenvolvimento

A fonte canônica do editor fica na raiz do projeto e o Paint em `src/paint/`. Esta pasta não contém cópias editáveis do runtime; `index.html` redireciona para a página-fonte.

`phase2-audit.mjs` é mantido aqui por compatibilidade com o fluxo de auditoria, mas lê os arquivos canônicos da raiz.
