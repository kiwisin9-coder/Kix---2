# KixV33 — teste no navegador e compilação Android

## Fase 3 no navegador/headless
A execução comportamental da Fase 3 pode ser validada sem APK porque o runtime é JavaScript e o harness usa relógio e PRNG injetáveis.

```sh
node tools/kix-phase3-tests.mjs
```

Para abrir o runtime diretamente no navegador, sirva os assets por HTTP:

```sh
python3 -m http.server 8080 --directory app/src/main/assets/kix
```

Abra `http://127.0.0.1:8080/runtime.html`.

## Fase 4 / APK
A compilação e a validação Android exigem Gradle real, JDK 17, Android SDK API 35 e Build Tools 35.0.0. O APK precisa ser inspecionado pelas ferramentas Android e, para smoke test, instalado em emulador/dispositivo.

O ZIP foi estruturado com `settings.gradle` na raiz e `app/` como módulo Android.
