#!/usr/bin/env node
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import http from 'node:http';import {spawn} from 'node:child_process';
const root=process.cwd();
const icon='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=';
const project={name:'Worker Test',scenes:[{name:'Cena',actors:[]}],icon};
const manifest={project:{id:'worker-test',name:'Worker Test',version:'1.0.0'},android:{packageId:'com.kix.worker.test',minSdk:24,targetSdk:35},permissions:{internet:false,microphone:false,camera:false,location:false},icon:{dataUrl:icon}};
function request(port,token,method,url,body,headers={}){return new Promise((resolve,reject)=>{const data=body?JSON.stringify(body):null;const req=http.request({hostname:'127.0.0.1',port,method,path:url,headers:{'Content-Type':'application/json','Origin':'http://localhost','X-Kix-Session':token,...headers}},res=>{const chunks=[];res.on('data',c=>chunks.push(c));res.on('end',()=>{const text=Buffer.concat(chunks).toString();resolve({status:res.statusCode,headers:res.headers,text,json:()=>JSON.parse(text)})})});req.on('error',reject);if(data)req.write(data);req.end()})}
async function waitJob(port,token,id,limit=100){for(let i=0;i<limit;i++){const r=await request(port,token,'GET',`/jobs/${id}`);const j=r.json();if(['complete','failed','cancelled'].includes(j.status))return j;await new Promise(x=>setTimeout(x,20));}throw new Error('job timeout')}
async function start(env={}){const tokenFile=path.join(os.tmpdir(),`kix-worker-token-${process.pid}-${Math.random().toString(16).slice(2)}.txt`);const child=spawn(process.execPath,['tools/kix-apk-builder-server.mjs'],{cwd:root,env:{...process.env,KIX_APK_BUILDER_PORT:'0',KIX_APK_BUILDER_TOKEN_FILE:tokenFile,KIX_APK_BUILDER_TEST_PREPARE_ONLY:'1',KIX_APK_BUILDER_DISABLE_RLIMIT:'1',...env},stdio:['ignore','pipe','pipe']});let port;const all=[];child.stderr.on('data',c=>{const t=c.toString();all.push(t);const m=t.match(/listening on 127\.0\.0\.1:(\d+)/);if(m)port=Number(m[1])});for(let i=0;i<100&&!port;i++)await new Promise(x=>setTimeout(x,10));assert.ok(port,'worker não iniciou');const token=fs.readFileSync(tokenFile,'utf8').trim();return {child,port,token,tokenFile,logs:all}}
async function stop(s){s.child.kill('SIGTERM');await new Promise(r=>s.child.once('exit',r));try{fs.unlinkSync(s.tokenFile)}catch(_){} }
const results=[];const t=async(name,fn)=>{try{await fn();results.push({name,ok:true})}catch(e){results.push({name,ok:false,error:e.stack||String(e)})}};
let s=await start();
await t('origin restricted',async()=>{const r=await request(s.port,s.token,'GET','/session',null,{Origin:'https://evil.example'});assert.equal(r.status,403)});
await t('auth required',async()=>{const r=await request(s.port,'bad','GET','/session');assert.equal(r.status,401)});
await t('prepare debug job',async()=>{const r=await request(s.port,s.token,'POST','/build',{schema:'kix-apk-build-request-v1',project,manifest,variant:'debug'});assert.equal(r.status,202);const j=await waitJob(s.port,s.token,r.json().jobId);assert.equal(j.status,'complete');});
await t('concurrent jobs queue',async()=>{const rs=await Promise.all([request(s.port,s.token,'POST','/build',{schema:'kix-apk-build-request-v1',project,manifest,variant:'debug'}),request(s.port,s.token,'POST','/build',{schema:'kix-apk-build-request-v1',project,manifest,variant:'debug'})]);const js=await Promise.all(rs.map(r=>waitJob(s.port,s.token,r.json().jobId)));assert.ok(js.every(x=>x.status==='complete'));});
await t('malicious path rejected',async()=>{const bad=structuredClone(manifest);bad.project.name='../../evil';const r=await request(s.port,s.token,'POST','/build',{schema:'kix-apk-build-request-v1',project,manifest:bad,variant:'debug'});assert.equal(r.status,400);});
await stop(s);
s=await start({KIX_APK_BUILDER_TEST_SLEEP_MS:'500',KIX_APK_BUILDER_TIMEOUT_MS:'80',KIX_APK_BUILDER_TEST_PREPARE_ONLY:'0'});
await t('timeout',async()=>{const r=await request(s.port,s.token,'POST','/build',{schema:'kix-apk-build-request-v1',project,manifest,variant:'debug'});assert.equal(r.status,202);const j=await waitJob(s.port,s.token,r.json().jobId);assert.equal(j.status,'failed');assert.match(j.error,/timeout/i)});
await t('cancel running job',async()=>{const r=await request(s.port,s.token,'POST','/build',{schema:'kix-apk-build-request-v1',project,manifest,variant:'debug'});const cr=await request(s.port,s.token,'POST',`/jobs/${r.json().jobId}`,null,{'X-Kix-Action':'cancel'});assert.equal(cr.status,202);const j=await waitJob(s.port,s.token,r.json().jobId);assert.equal(j.status,'cancelled')});
await stop(s);
s=await start({KIX_APK_BUILDER_TEST_CRASH:'1'});
await t('worker child crash isolated',async()=>{const r=await request(s.port,s.token,'POST','/build',{schema:'kix-apk-build-request-v1',project,manifest,variant:'debug'});const j=await waitJob(s.port,s.token,r.json().jobId);assert.equal(j.status,'failed')});
await stop(s);
const ok=results.every(x=>x.ok);console.log(JSON.stringify({ok,total:results.length,passed:results.filter(x=>x.ok).length,failed:results.filter(x=>!x.ok).length,results},null,2));process.exitCode=ok?0:1;
