#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const src=path.join(ROOT,'runtime','kix-runtime.js');
const dst=path.join(ROOT,'engine.js');
if(!fs.existsSync(src)) throw new Error('runtime/kix-runtime.js ausente');
const b=fs.readFileSync(src);
if(process.argv.includes('--write')) fs.copyFileSync(src,dst);
const a=fs.readFileSync(dst);
if(!a.equals(b)) { console.error('engine.js e runtime/kix-runtime.js divergentes'); process.exit(2); }
console.log(JSON.stringify({ok:true,identical:true,sha256:crypto.createHash('sha256').update(b).digest('hex')}));
