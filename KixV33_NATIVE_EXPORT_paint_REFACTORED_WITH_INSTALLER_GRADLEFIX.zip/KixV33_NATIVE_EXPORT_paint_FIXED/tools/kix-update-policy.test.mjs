#!/usr/bin/env node
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import crypto from 'node:crypto';
const root=process.cwd();
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'kix-version-test-'));
const icon='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=';
const project={name:'Update Test',scenes:[{name:'Cena',actors:[]}],icon};
const manifest={project:{id:'update-test',name:'Update Test',version:'2.0.0'},android:{packageId:'com.kix.update.test',minSdk:24,targetSdk:35},permissions:{internet:false,microphone:false,camera:false,location:false},icon:{dataUrl:icon}};
function run(m){return spawnSync(process.execPath,['tools/kix-apk-compiler.mjs','build',path.join(tmp,'project.json'),'--manifest',path.join(tmp,'manifest.json'),'--out',path.join(tmp,`${m}.apk`),'--prepare-only'],{cwd:root,env:{...process.env,KIX_STATE_DIR:tmp},encoding:'utf8'});}
fs.writeFileSync(path.join(tmp,'project.json'),JSON.stringify(project));fs.writeFileSync(path.join(tmp,'manifest.json'),JSON.stringify(manifest));
const seed=JSON.stringify({lastVersionCode:7,variants:{release:{versionCode:7,signingFingerprint:'AA:BB'}}},null,2);
const key=crypto.createHash('sha256').update(JSON.stringify({project:manifest.project.id,packageId:manifest.android.packageId})).digest('hex').slice(0,32);
fs.writeFileSync(path.join(tmp,`${key}.json`),seed,{mode:0o600});
manifest.android.versionCode=7;fs.writeFileSync(path.join(tmp,'manifest.json'),JSON.stringify(manifest));const r1=run('regress');assert.notEqual(r1.status,0);assert.match(r1.stderr,/não é maior que o último 7|não é maior/i);
manifest.android.versionCode=8;fs.writeFileSync(path.join(tmp,'manifest.json'),JSON.stringify(manifest));const r2=run('forward');assert.equal(r2.status,0);assert.match(r2.stdout,/"versionCode": 8/);
console.log(JSON.stringify({ok:true,checks:2,blockedRegression:true,acceptedForward:true},null,2));
