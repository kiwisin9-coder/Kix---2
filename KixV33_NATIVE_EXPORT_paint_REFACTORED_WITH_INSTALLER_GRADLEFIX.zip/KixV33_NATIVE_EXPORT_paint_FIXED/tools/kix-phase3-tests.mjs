#!/usr/bin/env node
import assert from 'node:assert/strict';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import { loadEngine } from './kix-headless-harness.mjs';
await import('../runtime/kix-data-format.js');

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const {engine,sandbox,clock}=loadEngine(path.join(root,'engine.js'));
const S=sandbox.KixPhase3Services;
const P=sandbox.KixPhase3Runtime;
assert(P && S,'Phase 3 services/runtime não inicializaram');

function actor(id,name,scripts=[]){
  return {id,index:0,data:{kixId:id,id,name,scripts,_vars:{},visible:true,x:0,y:0},el:sandbox.document.createElement('div')};
}
function chain(names, values=[]){
  const blocks={}; let prev=null; const ids=[];
  names.forEach((name,i)=>{
    const id=`b${i+1}`; ids.push(id); blocks[id]={id,name,type:'action',values:values[i]||{}}; if(prev) blocks[prev].next=id; prev=id;
  });
  return {blocks,first:ids[0]};
}
function runAll(max=500){
  const r=engine.runtime; let t=0, ticks=0;
  while(r.coroutines.some(c=>!c.dead) && ticks++<max){
    for(const co of [...r.coroutines]) if(!co.dead) engine.stepCoroutine(co,t);
    r.coroutines=r.coroutines.filter(c=>!c.dead || c._keepForTrace); P.sweep?.();
    t+=16.6666667; clock.advance(16.6666667);
  }
  return ticks;
}
function reset(project={}){
  try{engine.stopEngine();}catch(_){}
  engine.runtime.running=true; engine.runtime.project=project; engine.runtime.globals={}; engine.runtime.coroutines=[]; engine.runtime.actors=[]; engine.runtime.messages=[]; engine.runtime.lists={};
  P.init(project);
  S.diagnostics.clear(); S.profiler.reset(); S.debugger.clear();
  S.lifecycle.clearAll(); S.receivers.snapshot().forEach(x=>S.receivers.unregister(x.id));
  S.userBricks.calls.splice(0);
  sandbox.KixDeterminism.configure({now:()=>clock.now(),random:(()=>{let x=123456789;return()=>((x=Math.imul(x^x>>>13,1274126177))>>>0)/4294967296;})()});
}
const results=[];
function test(name,fn){
  try{fn();results.push({name,ok:true});}
  catch(e){results.push({name,ok:false,error:e.stack||String(e)});}
}

// Formula semantics.
test('formula precedence and associativity',()=>{
  assert.equal(engine.evalFormula('1+2*3',{vars:{}}),7);
  assert.equal(engine.evalFormula('2^3^2',{vars:{}}),512);
  assert.equal(engine.evalFormula('(2+3)*4',{vars:{}}),20);
});
test('formula strings/booleans/list functions',()=>{
  assert.equal(engine.evalFormula('juntar("Kix","V33")',{vars:{}}),'KixV33');
  assert.equal(engine.evalFormula('1<2 && 3>2',{vars:{}}),1);
  assert.equal(engine.evalFormula('tamanho da lista("a,b,c")',{vars:{}}),3);
  assert.equal(engine.evalFormula('item da lista("a,b,c",2)',{vars:{}}),'b');
  assert.equal(engine.evalFormula('lista contém("a,b","b")',{vars:{}}),1);
});
test('formula diagnostics for division by zero',()=>{
  const before=S.diagnostics.list().length; assert.equal(engine.evalFormula('10/0',{vars:{},diagnosticSource:{blockId:'formula-1'}}),0); const ds=S.diagnostics.list(); assert.ok(ds.length>before); assert.equal(ds.at(-1).code,'FORMULA_DIV_ZERO'); assert.equal(ds.at(-1).source.blockId,'formula-1');
});
test('deterministic formula random/time',()=>{
  S.diagnostics.clear(); const a=engine.evalFormula('aleatorio inteiro(1,100)',{vars:{}}); const b=engine.evalFormula('timestamp',{vars:{}}); assert.equal(typeof a,'number'); assert.equal(b,clock.now());
});

// Lists.
test('lists CRUD and one-based bounds',()=>{
  reset(); const a=actor('a1','A'); engine.runtime.actors=[a];
  const c=chain(['Criar lista','Adicionar à lista','Adicionar à lista','Inserir em lista','Substituir item da lista','Apagar de lista'],[
    {lista:'items'}, {lista:'items',item:'A'}, {lista:'items',item:'C'}, {lista:'items',item:'B',indice:2}, {lista:'items',item:'D',indice:2}, {lista:'items',indice:1}
  ]); const co={actor:a,blocks:c.blocks,tree:{blocks:c.blocks},ip:c.first,waitUntil:0,dead:false,loopStack:[]}; let t=0; while(!co.dead){engine.stepCoroutine(co,t);t+=1;if(t>100)throw Error('loop');}
  assert.equal(JSON.stringify(engine.runtime.lists.items),JSON.stringify(['D','C']));
  assert.equal(engine.evalFormula('tamanho da lista("items")',{vars:{},globals:engine.runtime.globals}),2);
  const before=engine.runtime.lists.items.slice(); const bad=chain(['Apagar de lista'],[{lista:'items',indice:99}]); const co2={actor:a,blocks:bad.blocks,tree:{blocks:bad.blocks},ip:bad.first,waitUntil:0,dead:false,loopStack:[]};engine.stepCoroutine(co2,200);assert.deepEqual(engine.runtime.lists.items,before);assert.equal(S.diagnostics.latest().code,'LIST_INDEX');
});

// Broadcasts and deterministic order.
test('broadcast and wait waits for all receivers',()=>{
  reset();
  const a=actor('a1','A',[{id:'h1',name:'Quando a cena começar',type:'hat'},{id:'ab',name:'Definir variável para',values:{variável:'sent',valor:1}},{id:'h2',name:'Quando receber mensagem',type:'hat',values:{mensagem:'go'}},{id:'ac',name:'Definir variável para',values:{variável:'ack',valor:1}}]);
  const b=actor('b1','B',[{id:'h3',name:'Quando receber mensagem',type:'hat',values:{mensagem:'go'}},{id:'bc',name:'Definir variável para',values:{variável:'ack2',valor:2}}]);
  engine.runtime.actors=[a,b]; P.init({});
  const c=chain(['Enviar mensagem e esperar'],[{mensagem:'go'}]);
  const co={actor:a,blocks:c.blocks,tree:{blocks:c.blocks},ip:c.first,waitUntil:0,dead:false,loopStack:[]}; engine.runtime.coroutines.push(co);
  runAll(100);
  assert.ok(a.data._vars.sent===undefined || a.data._vars.sent===1);
  assert.equal(a.data._vars.ack,1); assert.equal(b.data._vars.ack2,2);
  assert.equal(engine.runtime.phase3.pendingBroadcasts.size,0);
});

test('receiver registry isolates receiver failure deterministically',()=>{
  reset(); const seen=[]; S.receivers.register('system','a1',()=>{seen.push('a');throw new Error('boom')},{id:'r2'}); S.receivers.register('system','b1',()=>{seen.push('b')},{id:'r1'}); const out=S.receivers.dispatch('system',{value:1},{eventId:'e1'}); assert.deepEqual(seen,['b','a']); assert.equal(out.delivered,2); assert.equal(out.errors.length,1); assert.equal(S.diagnostics.latest().code,'RECEIVER_ERROR');
});

test('broadcast receiver filtering and cycle diagnostic',()=>{
  reset(); const a=actor('a1','A',[{id:'h',name:'Quando receber mensagem',type:'hat',values:{mensagem:'go'}},{id:'x',name:'Definir variável para',values:{variável:'hit',valor:1}},{id:'h2',name:'Quando receber mensagem',type:'hat',values:{mensagem:'other'}},{id:'y',name:'Definir variável',values:{variável:'wrong',valor:1}}]); engine.runtime.actors=[a];P.init({});
  const c=chain(['Enviar mensagem'],[{mensagem:'go'}]); const co={actor:a,blocks:c.blocks,tree:{blocks:c.blocks},ip:c.first,waitUntil:0,dead:false,loopStack:[]};engine.runtime.coroutines.push(co);runAll(40);assert.equal(a.data._vars.hit,1);assert.equal(a.data._vars.wrong,undefined);assert.equal(engine.runtime.phase3.pendingBroadcasts.size,0);
});

// Sensors.
test('deterministic sensors + permission fallback',()=>{
  reset(); S.sensors.setPermission('location','granted');S.sensors.setDeterministicValues({gps_latitude:12.5,gps_longitude:-43.25,acelerometro_x:9.81,loudness:0.7});
  assert.equal(engine.evalFormula('gps latitude',{vars:{}}),12.5);assert.equal(engine.evalFormula('gps longitude',{vars:{}}),-43.25);assert.equal(engine.evalFormula('acelerometro x',{vars:{}}),9.81);
  S.sensors.setPermission('location','denied');assert.equal(engine.evalFormula('gps latitude',{vars:{}}),0);assert.equal(S.diagnostics.latest().code,'SENSOR_PERMISSION');
});

test('clone limit and clone-of-clone isolation',()=>{
  reset({runtime:{maxClones:2}}); const a=actor('a1','A'); engine.runtime.actors=[a]; P.init(engine.runtime.project);
  const make=chain(['Criar clone'],[{}]);
  for(let i=0;i<2;i++){const co={actor:a,blocks:make.blocks,tree:{blocks:make.blocks},ip:make.first,waitUntil:0,dead:false,loopStack:[]};engine.stepCoroutine(co,i);} const first=engine.runtime.actors.filter(x=>x.data.isClone)[0]; assert.equal(engine.runtime.phase3.clones.size,2); const overflow={actor:a,blocks:make.blocks,tree:{blocks:make.blocks},ip:make.first,waitUntil:0,dead:false,loopStack:[]};engine.stepCoroutine(overflow,3);assert.ok(S.diagnostics.list().some(d=>d.code==='CLONE_LIMIT')); const cloneScript=chain(['Criar clone'],[{}]); const cloneCo={actor:first,blocks:cloneScript.blocks,tree:{blocks:cloneScript.blocks},ip:cloneScript.first,waitUntil:0,dead:false,loopStack:[]};engine.stepCoroutine(cloneCo,4);assert.equal(engine.runtime.phase3.clones.size,2);
});

// Clones.
test('clone create/delete lifecycle',()=>{
  reset({runtime:{maxClones:2}});const a=actor('a1','A',[]);engine.runtime.actors=[a];P.init(engine.runtime.project);const c=chain(['Criar clone'],[{}]);const co={actor:a,blocks:c.blocks,tree:{blocks:c.blocks},ip:c.first,waitUntil:0,dead:false,loopStack:[]};engine.stepCoroutine(co,0);const clones=engine.runtime.actors.filter(x=>x.data.isClone);assert.equal(clones.length,1);assert.ok(engine.runtime.phase3.clones.size===1);assert.equal(P.deleteClone(clones[0]),true);assert.equal(engine.runtime.phase3.clones.size,0);assert.equal(engine.runtime.actors.filter(x=>x.data.isClone).length,0);
});

// UserDefinedBrick.
test('typed UserDefinedBrick invocation and recursion guard',()=>{
  reset({userDefinedBricks:[{id:'double',name:'Dobrar',parameters:[{name:'n',type:'number'}],blocks:[{id:'u1',name:'Definir variável para',values:{variável:'result',valor:'${n}'}},{id:'u2',name:'Mudar variável em',values:{variável:'result',valor:'${n}'}}]}]});
  const a=actor('a1','A');engine.runtime.actors=[a];P.init(engine.runtime.project);const c=chain(['Chamar bloco'],[{userDefinedBrickId:'double',n:3}]);const co={actor:a,blocks:c.blocks,tree:{blocks:c.blocks},ip:c.first,waitUntil:0,dead:false,loopStack:[]};engine.runtime.coroutines.push(co);runAll(100);assert.equal(a.data._vars.result,6);assert.equal(S.userBricks.stack().length,0);
});

test('recursion diagnosis',()=>{
  reset({userDefinedBricks:[{id:'recurse',name:'Recursivo',blocks:[{id:'u1',name:'Chamar bloco',userDefinedBrickId:'recurse'}]}]});const a=actor('a1','A');engine.runtime.actors=[a];P.init(engine.runtime.project);const c=chain(['Chamar bloco'],[{userDefinedBrickId:'recurse'}]);const co={actor:a,blocks:c.blocks,tree:{blocks:c.blocks},ip:c.first,waitUntil:0,dead:false,loopStack:[]};engine.runtime.coroutines.push(co);runAll(1000);assert.equal(S.diagnostics.latest().code,'USER_BRICK_RECURSION');
});


test('formula property fuzz seeded',()=>{
  reset(); let seed=0x5EED1234; const rnd=()=>{seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;seed>>>=0;return seed/0x100000000;};
  for(let i=0;i<250;i++){
    const a=Math.floor(rnd()*200)-100,b=Math.floor(rnd()*200)-100,c=Math.floor(rnd()*9)+1;
    const forms=[`${a}+${b}*${c}`,`(${a}-${b})/${c}`,`${a}^2`,`abs(${a})`,`if (${a}>${b},1,0)`];
    for(const f of forms){let v;try{v=engine.evalFormula(f,{vars:{},diagnosticSource:{blockId:'fuzz'}});}catch(e){throw new Error(`Formula lançou exceção: ${f}: ${e.message}`);}assert.ok(v===v,'NaN não permitido em fuzz');}
  }
});

test('undo redo audited on list mutation',()=>{
  reset(); const a=actor('a1','A'); engine.runtime.actors=[a]; const c=chain(['Criar lista','Adicionar à lista'],[{lista:'u'},{lista:'u',item:'x'}]); const co={actor:a,blocks:c.blocks,tree:{blocks:c.blocks},ip:c.first,waitUntil:0,dead:false,loopStack:[]}; engine.runtime.coroutines.push(co); runAll(30); assert.equal(JSON.stringify(engine.runtime.lists.u),JSON.stringify(['x'])); assert.ok(S.undoRedo.snapshot().undoDepth>=2); assert.equal(engine.undo(),true); assert.equal(JSON.stringify(engine.runtime.lists.u),JSON.stringify([])); assert.equal(engine.redo(),true); assert.equal(JSON.stringify(engine.runtime.lists.u),JSON.stringify(['x']));
});

// Stop/restart leakage.
test('stop clears timers receivers and clones',()=>{
  reset();const a=actor('a1','A');engine.runtime.actors=[a];engine.runtime.phase3.clones.set('x',{id:'x'});S.lifecycle.setTimeout(()=>{},10000,'clone:a1');S.receivers.register('test','a1',()=>{});assert.ok(S.lifecycle.count('clone:a1')===1);assert.equal(S.receivers.count(),1);engine.stopEngine();assert.equal(S.receivers.count(),0);assert.equal(Object.values(S.lifecycle.snapshot()).reduce((n,x)=>n+x.count,0),0);assert.equal(engine.runtime.coroutines.length,0);
});

test('persisted data N-1 migrates without loss',()=>{
  const m=sandbox.KixDataFormat || globalThis.KixDataFormat; assert.ok(m); const old={formatVersion:1,vars:{score:42},lists:{items:['a','b']},runtime:{slot:'keep'}}; const next=m.migrate(old); assert.equal(next.formatVersion,2); assert.equal(next.globals.score,42); assert.deepEqual(next.lists.items,['a','b']); assert.equal(next.runtime.slot,'keep'); assert.equal(next.vars,undefined);
});

// Repeat exact deterministic trace.
function demoTrace(){
  reset({runtime:{maxClones:8},lists:{items:['seed']},userDefinedBricks:[{id:'inc',name:'Incrementar',parameters:[{name:'n',type:'number'}],blocks:[{id:'u1',name:'Mudar variável em',values:{variável:'counter',valor:'${n}'}}]}]});
  S.sensors.setPermission('location','granted'); S.sensors.setDeterministicValues({gps_latitude:12.5,loudness:0.25});
  const a=actor('a1','A',[{id:'start',name:'Quando a cena começar',type:'hat'},{id:'go',name:'Enviar mensagem',values:{mensagem:'go'}},{id:'clone',name:'Criar clone'},{id:'custom',name:'Chamar bloco',userDefinedBrickId:'inc',values:{n:2}},{id:'sensor',name:'GPS latitude'}]);
  const b=actor('b1','B',[{id:'recv',name:'Quando receber mensagem',type:'hat',values:{mensagem:'go'}},{id:'add',name:'Adicionar à lista',values:{lista:'items',item:'receiver'}}]);
  engine.runtime.actors=[a,b]; P.init(engine.runtime.project);
  const c=chain(['Criar lista','Adicionar à lista','Chamar bloco','Enviar mensagem e esperar','Criar clone'],[
    {lista:'items'},{lista:'items',item:'demo'},{userDefinedBrickId:'inc',n:3},{mensagem:'go'},{}
  ]);
  const co={actor:a,blocks:c.blocks,tree:{blocks:c.blocks},ip:c.first,waitUntil:0,dead:false,loopStack:[]};engine.runtime.coroutines.push(co);runAll(400);
  const clone=engine.runtime.actors.find(x=>x.data.isClone); if(clone) P.deleteClone(clone);
  return {hash:P.traceHash(),trace:JSON.stringify(P.snapshot().trace),lists:engine.runtime.lists,vars:a.data._vars,sensor:engine.evalFormula('gps latitude',{vars:{}}),diagnostics:P.snapshot().diagnostics.length};
}
test('demo trace deterministic across three runs',()=>{const runs=[demoTrace(),demoTrace(),demoTrace()]; for(const r of runs.slice(1)){assert.equal(r.hash,runs[0].hash);assert.equal(r.trace,runs[0].trace);assert.deepEqual(r.lists,runs[0].lists);assert.deepEqual(r.vars,runs[0].vars);assert.equal(r.sensor,runs[0].sensor);}});

const ok=results.every(x=>x.ok);
const summary={ok,total:results.length,passed:results.filter(x=>x.ok).length,failed:results.filter(x=>!x.ok).length,results,traceDemo:demoTrace().hash,testRuntimeVersion:3};
if(process.env.KIX_PHASE3_RESULTS) await import('node:fs').then(fs=>fs.promises.writeFile(process.env.KIX_PHASE3_RESULTS,JSON.stringify(summary,null,2)));
console.log(JSON.stringify(summary,null,2));
process.exitCode=ok?0:1;
