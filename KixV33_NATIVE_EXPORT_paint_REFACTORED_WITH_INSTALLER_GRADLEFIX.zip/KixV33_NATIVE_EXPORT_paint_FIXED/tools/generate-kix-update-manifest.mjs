import { createHash } from 'node:crypto';
import { readdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function option(name, fallback = undefined) {
  const i = process.argv.indexOf(name);
  return i >= 0 ? process.argv[i + 1] : fallback;
}

async function listFiles(directory, relative = '') {
  const entries = (await readdir(path.join(directory, relative), { withFileTypes: true }))
    .sort((a, b) => a.name.localeCompare(b.name));
  const output = [];
  for (const entry of entries) {
    const rel = relative ? `${relative}/${entry.name}` : entry.name;
    if (entry.isSymbolicLink()) throw new Error(`Links simbólicos não são aceitos: ${rel}`);
    if (entry.isDirectory()) output.push(...await listFiles(directory, rel));
    else if (entry.isFile()) output.push(rel);
  }
  return output;
}

export async function createManifest({ sourceDirectory, baseUrl, version }) {
  const parsedBase = new URL(baseUrl);
  if (parsedBase.protocol !== 'https:' || parsedBase.username || parsedBase.password)
    throw new Error('--base-url deve ser HTTPS e não pode conter credenciais.');
  if (!Number.isSafeInteger(version) || version < 1)
    throw new Error('--version deve ser um inteiro seguro maior que zero.');
  const base = parsedBase.href.endsWith('/') ? parsedBase.href : `${parsedBase.href}/`;
  const paths = await listFiles(sourceDirectory);
  if (!paths.includes('index.html')) throw new Error('A pasta de assets precisa conter index.html.');
  const files = [];
  for (const relativePath of paths) {
    const absolute = path.join(sourceDirectory, ...relativePath.split('/'));
    const bytes = await readFile(absolute);
    const url = new URL(relativePath.split('/').map(encodeURIComponent).join('/'), base).href;
    files.push({
      path: relativePath,
      url,
      size: bytes.length,
      sha256: createHash('sha256').update(bytes).digest('hex'),
    });
  }
  return { version, files };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const versionText = option('--version');
  const baseUrl = option('--base-url');
  const sourceDirectory = path.resolve(option('--source', path.join(ROOT, 'app/src/main/assets/kix')));
  const outputPath = path.resolve(option('--output', path.join(ROOT, 'update-manifest.json')));
  if (!versionText || !baseUrl) {
    throw new Error('Uso: npm run manifest:assets -- --version 1 --base-url https://seu-host/caminho/ [--output update-manifest.json]');
  }
  const manifest = await createManifest({ sourceDirectory, baseUrl, version: Number(versionText) });
  await writeFile(outputPath, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
  process.stdout.write(`Manifesto criado: ${outputPath} (${manifest.files.length} arquivos)\n`);
}
