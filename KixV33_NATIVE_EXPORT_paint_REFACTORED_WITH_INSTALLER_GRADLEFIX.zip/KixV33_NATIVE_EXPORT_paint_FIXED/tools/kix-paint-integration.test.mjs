import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { createHash } from 'node:crypto';
import { createManifest } from './generate-kix-update-manifest.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (relative) => readFile(path.join(ROOT, relative), 'utf8');
const exists = async (relative) => { try { await readFile(path.join(ROOT, relative)); return true; } catch { return false; } };
const SOURCE_PAINT = 'src/paint';
const ANDROID_ASSETS = 'app/src/main/assets/kix';

test('Paint has one canonical source and Android assets are generated from it', async () => {
  const js = await read(`${SOURCE_PAINT}/kix-paint.js`);
  const algorithms = await read(`${SOURCE_PAINT}/kix-paint-algorithms.mjs`);
  const css = await read(`${SOURCE_PAINT}/kix-paint.css`);
  const html = await read('index.html');
  assert.match(html, /href="src\/paint\/kix-paint\.css"/);
  assert.match(html, /type="module" src="src\/paint\/kix-paint\.js"/);
  assert.match(js, /from '\.\/kix-paint-algorithms\.mjs'/);
  assert.ok(algorithms.includes('export function fillRgba('));
  const brush = await read(`${SOURCE_PAINT}/kix-paint-brush.js`);
  assert.ok(css.includes('.kp-eyedropper-loupe'));
  assert.equal(await exists('kix-paint.js'), false, 'no editable Paint copy should remain at the project root');
  assert.equal(await exists('DEVELOPMENT/kix-paint.js'), false, 'development must not carry a second Paint source');
  assert.equal(await exists(`${ANDROID_ASSETS}/kix-paint.bundle.js`), true, 'run npm run build:paint before checking generated APK assets');
  assert.equal(await read(`${ANDROID_ASSETS}/kix-paint.css`), css);
  assert.equal(await read(`${ANDROID_ASSETS}/kix-paint-brush.js`), brush);
  const androidHtml = await read(`${ANDROID_ASSETS}/index.html`);
  assert.match(androidHtml, /src="kix-paint\.bundle\.js"/);
  assert.doesNotMatch(androidHtml, /src="src\/paint\/kix-paint\.js"/);
  assert.match(androidHtml, /src="kix-paint-brush\.js"/);
  const bundle = await read(`${ANDROID_ASSETS}/kix-paint.bundle.js`);
  assert.doesNotMatch(bundle, /from\s+["']\.\/kix-paint-algorithms\.mjs["']/);
});

test('eyedropper uses pointer tracking, samples on release, returns to previous tool, and loupe cannot intercept input', async () => {
  const js = await read(`${SOURCE_PAINT}/kix-paint.js`);
  const css = await read(`${SOURCE_PAINT}/kix-paint.css`);
  assert.match(js, /function updateEyedropperLoupe\(/);
  assert.match(js, /ctx\.imageSmoothingEnabled\s*=\s*false/);
  assert.match(js, /function moveEyedropper\(/);
  assert.match(js, /function finishEyedropper\(e, commit\)/);
  assert.match(js, /setTool\(KP\.prevTool[^;]*'brush'\)/);
  assert.match(js, /finishEyedropper\(e, e\.type !== 'pointercancel'\)/);
  assert.match(css, /\.kp-eyedropper-loupe\{[^}]*pointer-events:none/s);
  assert.match(js, /elEyeCanvas\.getContext\('2d'\)/);
  assert.doesNotMatch(js.slice(js.indexOf('function updateEyedropperLoupe'), js.indexOf('function beginEyedropper')), /putImageData|drawImage\([^)]*elMain[^)]*,\s*[^)]*\)/);
});

test('bucket always calls the connected-component fill; global similarity mode remains only in wand selection', async () => {
  const js = await read(`${SOURCE_PAINT}/kix-paint.js`);
  const start = js.indexOf('function floodFill(layer, x, y, fillColor, o)');
  const end = js.indexOf('function gradStop(', start);
  assert.ok(start >= 0 && end > start);
  const bucket = js.slice(start, end);
  assert.match(bucket, /fillRgba\(/);
  assert.match(bucket, /pixelArt:\s*!!\(o\.pixelArt\s*\|\|\s*KP\.doc\.pixelArt\)/);
  assert.match(js, /fill:\s*\{\s*mode:\s*'fill',\s*tol:\s*10,\s*opacity:\s*100,\s*grow:\s*0\s*\}/);
  assert.doesNotMatch(bucket, /computeSelectionMask|contiguous\s*=\s*false|Todas as parecidas/);
  assert.match(js, /computeSelectionMask\(d, W, H, x, y, KP\.wandTol, KP\.wandContiguous\)/);
  const uiStart = js.indexOf('function renderFillSheet(inner)');
  const uiEnd = js.indexOf('// --- formas desenhadas', uiStart);
  assert.doesNotMatch(js.slice(uiStart, uiEnd), /Todas as parecidas/);
});

test('Android config uses private app storage and remote updates require a supplied HTTPS endpoint', async () => {
  const main = await read('app/src/main/java/com/kix/engine/MainActivity.java');
  const store = await read('app/src/main/java/com/kix/engine/KixAssetStore.java');
  const gradle = await read('app/build.gradle');
  assert.match(main, /new WebViewAssetLoader\.InternalStoragePathHandler\(this,new java\.io\.File\(getFilesDir\(\),"kix"\)\)/);
  assert.match(main, /prepareFromApk\(BuildConfig\.VERSION_CODE\)/);
  assert.match(main, /checkForUpdate\(/);
  assert.match(main, /webView\.clearCache\(true\)/);
  assert.match(main, /onPageFinished\(WebView v,String url\)/);
  assert.match(main, /url\.startsWith\("https:\/\/appassets\.androidplatform\.net\/assets\/kix\/index\.html"\)/);
  assert.match(main, /application\/javascript/);
  assert.match(main, /endsWith\(\"\.mjs\"\)/);
  assert.match(gradle, /KIX_UPDATE_MANIFEST_URL/);
  assert.match(store, /requireHttps\(/);
  assert.match(store, /sha256\(payload\)/);
  assert.match(store, /MAX_TOTAL_BYTES/);
  assert.match(store, /swapDirectories\(/);
  assert.match(store, /if \(root\.exists\(\)\) deleteRecursively\(backup\)/);
  assert.match(store, /Preserve the previous tree if rollback failed/);
});

test('asset manifest generator pins HTTPS, includes every asset and calculates exact byte size/hash', async () => {
  const dir = await mkdtemp(path.join(tmpdir(), 'kix-assets-test-'));
  try {
    await mkdir(path.join(dir, 'nested'));
    await writeFile(path.join(dir, 'index.html'), '<!doctype html>');
    const nestedBytes = Buffer.from('test-asset\n');
    await writeFile(path.join(dir, 'nested', 'sample.js'), nestedBytes);
    const manifest = await createManifest({ sourceDirectory: dir, baseUrl: 'https://example.invalid/kix/', version: 7 });
    assert.equal(manifest.version, 7);
    assert.equal(manifest.files.length, 2);
    const item = manifest.files.find((file) => file.path === 'nested/sample.js');
    assert.ok(item);
    assert.equal(item.size, nestedBytes.length);
    assert.equal(item.sha256, createHash('sha256').update(nestedBytes).digest('hex'));
    assert.equal(item.url, 'https://example.invalid/kix/nested/sample.js');
    await assert.rejects(() => createManifest({ sourceDirectory: dir, baseUrl: 'http://example.invalid/kix/', version: 8 }), /HTTPS/);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});
