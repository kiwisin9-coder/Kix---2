#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { loadEngine } from './kix-headless-harness.mjs';
const root=process.cwd();
const project=JSON.parse(fs.readFileSync(path.join(root,'examples/fase3-demo.kix.json'),'utf8'));
function run(runtimePath){
  const {engine,sandbox,clock}=loadEngine(runtimePath,{servicesFile:path.join(root,'runtime/kix-runtime-services.js'),phase3File:path.join(root,'runtime/kix-phase3-runtime.js')}); const P=sandbox.KixPhase3Runtime,S=sandbox.KixPhase3Services; engine.runtime.running=true; engine.runtime.project=project; engine.runtime.globals={};engine.runtime.lists={};engine.runtime.actors=[];engine.runtime.coroutines=[];engine.runtime.messages=[];P.init(project);sandbox.KixDeterminism.configure({now:()=>clock.now(),random:()=>0.25});
  const actors=project.scenes[0].actors.map(a=>({...a,index:0,data:{kixId:a.id,id:a.id,name:a.name,scripts:a.scripts,_vars:{},visible:true,x:0,y:0},el:sandbox.document.createElement('div')})); engine.runtime.actors=actors;
  const start=actors[0]; const blocks={}; let prev=null; for(const b of start.data.scripts){blocks[b.id]={...b};if(prev)blocks[prev].next=b.id;prev=b.id;} const co={actor:start,blocks,tree:{blocks},ip:start.data.scripts[0].id,waitUntil:0,dead:false,loopStack:[]};engine.runtime.coroutines.push(co);
  let ticks=0,t=0;while(engine.runtime.coroutines.some(c=>!c.dead)&&ticks++<600){for(const c of [...engine.runtime.coroutines])if(!c.dead)engine.stepCoroutine(c,t);engine.runtime.coroutines=engine.runtime.coroutines.filter(c=>!c.dead);P.sweep?.();t+=16.6666667;clock.advance(16.6666667);}
  if(ticks>=600)throw new Error('Parity demo não terminou.');
  return {hash:P.traceHash(),trace:P.snapshot().trace,lists:engine.runtime.lists,globals:engine.runtime.globals,diagnostics:P.snapshot().diagnostics.length};
}
const a=run(path.join(root,'engine.js')); const b=run(path.join(root,'runtime/kix-runtime.js'));
const ok=a.hash===b.hash&&JSON.stringify(a.trace)===JSON.stringify(b.trace)&&JSON.stringify(a.lists)===JSON.stringify(b.lists)&&JSON.stringify(a.globals)===JSON.stringify(b.globals);
console.log(JSON.stringify({ok,editorEngine:a,standaloneRuntime:b},null,2)); if(!ok)process.exitCode=1;
