#!/usr/bin/env node
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const root = process.cwd();
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kix-apk-test-'));
const icon = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=';
const project = { name: 'Teste Kix', scenes: [{ name: 'Cena', actors: [] }], icon };
const manifest = {
  schema: 'kix-apk-build-manifest-v2',
  project: { id: 'test-project', name: 'Teste Kix', version: '1.0.0' },
  android: { packageId: 'com.kixgames.teste.kix', orientation: 'portrait', minSdk: 24, targetSdk: 35, fullscreen: true },
  permissions: { internet: false, microphone: false, camera: false, location: false },
  icon: { dataUrl: icon }
};
fs.writeFileSync(path.join(tmp, 'project.kix'), JSON.stringify(project));
fs.writeFileSync(path.join(tmp, 'manifest.json'), JSON.stringify(manifest));
const r = spawnSync(process.execPath, [
  'tools/kix-apk-compiler.mjs', 'build', path.join(tmp, 'project.kix'),
  '--manifest', path.join(tmp, 'manifest.json'), '--prepare-only'
], { cwd: root, encoding: 'utf8' });
if (r.error) throw r.error;
if (r.status !== 0) throw new Error(r.stderr || r.stdout);
const obj = JSON.parse(r.stdout);
if (!obj.ok || obj.packageId !== 'com.kixgames.teste.kix' || obj.variant !== 'debug') throw new Error('prepare-only inválido');
console.log(JSON.stringify({ ok: true, checks: 6, prepared: obj.prepared, variant: obj.variant, versionCode: obj.versionCode, permissions: obj.permissions }, null, 2));
