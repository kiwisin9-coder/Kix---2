import test from 'node:test';
import assert from 'node:assert/strict';
import { computeRegion4, computeSelectionMask, expandMask4, fillRgba, rgbaAt } from '../src/paint/kix-paint-algorithms.mjs';

function rgba(width, height, fill = [0, 0, 0, 0]) {
  const data = new Uint8ClampedArray(width * height * 4);
  for (let i = 0; i < width * height; i++) data.set(fill, i * 4);
  return data;
}
function setPixel(data, width, x, y, color) { data.set(color, (y * width + x) * 4); }
function paintClosedRect(data, width, x0, y0, x1, y1, color = [0, 0, 0, 255]) {
  for (let x = x0; x <= x1; x++) { setPixel(data, width, x, y0, color); setPixel(data, width, x, y1, color); }
  for (let y = y0; y <= y1; y++) { setPixel(data, width, x0, y, color); setPixel(data, width, x1, y, color); }
}
function indexes(mask, value = 1) { return [...mask].reduce((out, n, i) => (n === value ? out.concat(i) : out), []); }

test('TESTE 1 — quadrado fechado em Pixel Art: preenche apenas o interior conectado', () => {
  const w = 8, h = 8, data = rgba(w, h);
  paintClosedRect(data, w, 1, 1, 6, 6);
  const fill = fillRgba(data, w, h, 3, 3, { r: 255, g: 0, b: 0 }, { pixelArt: true, tolerance: 100, grow: 8 });
  assert.equal(fill.changed, true);
  assert.equal(indexes(fill.mask).length, 16);
  assert.deepEqual([...data.slice((3 * w + 3) * 4, (3 * w + 3) * 4 + 4)], [255, 0, 0, 255]);
  assert.deepEqual([...data.slice(0, 4)], [0, 0, 0, 0]);
  assert.deepEqual([...data.slice((1 * w + 1) * 4, (1 * w + 1) * 4 + 4)], [0, 0, 0, 255]);
});

test('TESTE 2 — contorno fechado de 1 px permanece fora da máscara', () => {
  const w = 8, h = 8, data = rgba(w, h);
  paintClosedRect(data, w, 1, 1, 6, 6, [18, 18, 18, 255]);
  const targetPixel = (y, x) => (y * w + x) * 4;
  const fill = fillRgba(data, w, h, 2, 2, { r: 230, g: 30, b: 30 }, { pixelArt: true, grow: 4, tolerance: 50 });
  for (let x = 1; x <= 6; x++) {
    assert.deepEqual([...data.slice(targetPixel(1, x), targetPixel(1, x) + 4)], [18, 18, 18, 255], 'borda superior intacta');
    assert.deepEqual([...data.slice(targetPixel(6, x), targetPixel(6, x) + 4)], [18, 18, 18, 255], 'borda inferior intacta');
  }
  for (let y = 1; y <= 6; y++) {
    assert.deepEqual([...data.slice(targetPixel(y, 1), targetPixel(y, 1) + 4)], [18, 18, 18, 255], 'borda esquerda intacta');
    assert.deepEqual([...data.slice(targetPixel(y, 6), targetPixel(y, 6) + 4)], [18, 18, 18, 255], 'borda direita intacta');
  }
  assert.equal(fill.changed, true);
  assert.equal(indexes(fill.mask).length, 16);
});

test('TESTE 3 — duas regiões internas: apenas a área tocada entra na máscara', () => {
  const w = 11, h = 7, data = rgba(w, h);
  paintClosedRect(data, w, 1, 1, 9, 5);
  for (let y = 2; y <= 4; y++) setPixel(data, w, 5, y, [0, 0, 0, 255]);
  const fill = fillRgba(data, w, h, 3, 3, { r: 30, g: 80, b: 240 }, { pixelArt: true });
  assert.equal(fill.mask[3 * w + 3], 1);
  assert.equal(fill.mask[3 * w + 7], 0);
  assert.equal(indexes(fill.mask).length, 9);
  assert.deepEqual([...data.slice((3 * w + 3) * 4, (3 * w + 3) * 4 + 4)], [30, 80, 240, 255]);
  assert.deepEqual([...data.slice((3 * w + 7) * 4, (3 * w + 7) * 4 + 4)], [0, 0, 0, 0]);
});

test('TESTE 4 — Pixel Art sem tolerância não atravessa uma borda de cor próxima', () => {
  const w = 5, h = 3, data = rgba(w, h, [100, 100, 100, 255]);
  for (let y = 0; y < h; y++) setPixel(data, w, 2, y, [102, 102, 102, 255]);
  // A política do modo Pixel Art fornece tolerância 0 mesmo que exista uma tolerância normal salva.
  const fill = fillRgba(data, w, h, 0, 1, { r: 250, g: 10, b: 10 }, { pixelArt: true, tolerance: 100 });
  assert.deepEqual(indexes(fill.mask), [0, 1, 5, 6, 10, 11]);
  assert.deepEqual([...data.slice((1 * w + 2) * 4, (1 * w + 2) * 4 + 4)], [102, 102, 102, 255]);
  assert.deepEqual([...data.slice((1 * w + 4) * 4, (1 * w + 4) * 4 + 4)], [100, 100, 100, 255]);
});

test('TESTE 5 — tolerância anti-aliased expande pixels próximos, mas nunca faz busca global', () => {
  const w = 9, h = 5, data = rgba(w, h, [100, 100, 100, 255]);
  // Pixels anti-aliased conectados ao fundo e dentro da tolerância.
  setPixel(data, w, 2, 2, [110, 110, 110, 255]);
  setPixel(data, w, 3, 2, [108, 108, 108, 255]);
  // Fronteira forte impede alcançar a área vizinha.
  for (let y = 0; y < h; y++) setPixel(data, w, 4, y, [230, 230, 230, 255]);
  // Região distante com a mesma cor-alvo, desconectada pela fronteira.
  const fill = fillRgba(data, w, h, 1, 2, { r: 10, g: 80, b: 230 }, { pixelArt: false, tolerance: 5, grow: 0 });
  assert.equal(fill.mask[2 * w + 2], 1);
  assert.equal(fill.mask[2 * w + 3], 1);
  assert.equal(fill.mask[2 * w + 7], 0);
  assert.equal(fill.mask[2 * w + 4], 0);
  assert.deepEqual([...data.slice((2 * w + 2) * 4, (2 * w + 2) * 4 + 4)], [10, 80, 230, 255]);
  assert.deepEqual([...data.slice((2 * w + 7) * 4, (2 * w + 7) * 4 + 4)], [100, 100, 100, 255]);
});

test('TESTE 6 — expansão é 4-connected e uma diagonal não vira região circular', () => {
  const w = 3, h = 3, data = rgba(w, h, [255, 255, 255, 255]);
  setPixel(data, w, 0, 0, [0, 0, 0, 255]);
  setPixel(data, w, 1, 1, [0, 0, 0, 255]);
  const region = computeRegion4(data, w, h, 0, 0, 0);
  assert.deepEqual(indexes(region), [0]);
  const noGrow = expandMask4(region, w, h, 0);
  assert.deepEqual(indexes(noGrow, 1), [0]);
  const grow = expandMask4(region, w, h, 1);
  assert.deepEqual(indexes(grow, 1), [0]);
  assert.equal(grow[1], 2);
  assert.equal(grow[3], 2);
  assert.equal(grow[4], 0, 'diagonal não pode ser adicionada com raio 1');
});


test('TESTE 7 — sem configurar Expandir borda, o modo normal usa expansão zero e preserva a borda', () => {
  const w = 7, h = 7, data = rgba(w, h, [0, 0, 0, 0]);
  paintClosedRect(data, w, 1, 1, 5, 5, [20, 20, 20, 255]);
  const fill = fillRgba(data, w, h, 3, 3, { r: 40, g: 180, b: 70 }, { pixelArt: false, tolerance: 10 });
  assert.equal(indexes(fill.mask).length, 9);
  assert.deepEqual([...data.slice((1 * w + 3) * 4, (1 * w + 3) * 4 + 4)], [20, 20, 20, 255]);
  assert.deepEqual([...data.slice((0 * w + 3) * 4, (0 * w + 3) * 4 + 4)], [0, 0, 0, 0]);
});

test('rgbaAt devolve coordenadas e cor do pixel real após clamp', () => {
  const data = rgba(2, 2);
  setPixel(data, 2, 1, 1, [18, 52, 86, 255]);
  assert.deepEqual(rgbaAt(data, 2, 2, 1.9, 1.5), { x: 1, y: 1, r: 18, g: 52, b: 86, a: 255 });
  assert.deepEqual(rgbaAt(data, 2, 2, -1, 0), { x: 0, y: 0, r: 0, g: 0, b: 0, a: 0 });
});

test('Seleção por semelhança continua separada: modo global não é usado pelo balde', () => {
  const w = 5, h = 1, data = rgba(w, h, [20, 20, 20, 255]);
  setPixel(data, w, 2, 0, [220, 220, 220, 255]);
  const global = computeSelectionMask(data, w, h, 0, 0, 0, false);
  const connected = computeSelectionMask(data, w, h, 0, 0, 0, true);
  assert.deepEqual(indexes(global), [0, 1, 3, 4]);
  assert.deepEqual(indexes(connected), [0, 1]);
});
