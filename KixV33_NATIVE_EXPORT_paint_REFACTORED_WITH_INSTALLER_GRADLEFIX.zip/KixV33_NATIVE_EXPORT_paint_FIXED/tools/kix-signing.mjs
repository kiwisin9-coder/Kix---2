#!/usr/bin/env node
/** Secure signing helper. Secrets are read only from environment variables and never written to sidecars/logs. */
import fs from 'node:fs';
import { spawnSync } from 'node:child_process';

function env(name) {
  const v = process.env[name];
  if (!v) throw new Error(`${name} ausente no ambiente.`);
  return v;
}
function run(args) {
  const r = spawnSync('keytool', args, { stdio: 'pipe', encoding: 'utf8', shell: false, env: process.env });
  if (r.status !== 0) throw new Error((r.stderr || r.stdout || 'keytool falhou.').slice(-4000));
  return r.stdout || '';
}
function fingerprint() {
  const file = fs.realpathSync(env('KIX_KEYSTORE'));
  const alias = env('KIX_KEY_ALIAS');
  const pass = env('KIX_STORE_PASSWORD');
  if (!fs.existsSync(file)) throw new Error('Keystore não encontrado.');
  const out = run(['-list','-v','-keystore',file,'-alias',alias,'-storepass:env','KIX_STORE_PASSWORD']);
  const m = out.match(/SHA256:\s*([0-9A-F:]+)/i);
  if (!m) throw new Error('Fingerprint SHA-256 não encontrado.');
  void pass;
  console.log(JSON.stringify({ ok: true, keystore: file, alias, sha256: m[1].toUpperCase() }, null, 2));
}
function create() {
  const file = env('KIX_KEYSTORE');
  const alias = env('KIX_KEY_ALIAS');
  const storePass = env('KIX_STORE_PASSWORD');
  const keyPass = env('KIX_KEY_PASSWORD');
  const dname = env('KIX_KEY_DNAME');
  if (fs.existsSync(file)) throw new Error('O arquivo do keystore já existe; não sobrescrevendo.');
  run(['-genkeypair','-v','-keystore',file,'-storetype','PKCS12','-alias',alias,'-keyalg','RSA','-keysize','3072','-validity','3650','-dname',dname,'-storepass:env','KIX_STORE_PASSWORD','-keypass:env','KIX_KEY_PASSWORD']);
  void storePass; void keyPass;
  fingerprint();
}
const cmd = process.argv[2];
try {
  if (cmd === 'create') create();
  else if (cmd === 'fingerprint') fingerprint();
  else throw new Error('Uso: kix-signing.mjs create|fingerprint');
} catch (e) {
  console.error(`KIX SIGNING: ${e.message || e}`);
  process.exitCode = 1;
}
