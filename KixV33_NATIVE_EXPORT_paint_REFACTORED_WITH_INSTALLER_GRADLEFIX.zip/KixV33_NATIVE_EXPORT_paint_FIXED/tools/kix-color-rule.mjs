#!/usr/bin/env node
// Regra de cores do Kix: neutros SÓ em cinza graffiti (escuro #2B2B2B, normal #6B6B6B, claro #C8C8C8),
// além de branco/preto puros. Nada de cinza azulado (slate/zinc/#202024/#3A3A42…).
// Uso:  node tools/kix-color-rule.mjs            → verifica os arquivos do Kix Paint (falha se violar)
//       node tools/kix-color-rule.mjs --all      → relatório do app inteiro (não falha; guia da migração)
//       node tools/kix-color-rule.mjs arq1 arq2  → verifica arquivos específicos
// Linhas com "kx-ok" no texto são ignoradas (ex.: cor do desenho do usuário, não da interface).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const GRAFFITI = { dark: '#2B2B2B', mid: '#6B6B6B', light: '#C8C8C8' };
const ALLOWED = new Set([...Object.values(GRAFFITI), '#000000', '#FFFFFF', '#000', '#FFF', '#111111'].map(s => s.toUpperCase()));
const PAINT_FILES = ['src/paint/kix-paint.css', 'src/paint/kix-paint.js', 'src/paint/kix-paint-brush.js'];
const ALL_FILES = ['index.html', 'app.js', 'src/paint/kix-paint.css', 'src/paint/kix-paint.js', 'src/paint/kix-paint-brush.js', 'kix-plugins.js', 'kix-phase2.js', 'kix-quality.js'];

function hexToHsl(h) {
  h = h.replace('#', ''); if (h.length === 3) h = h.split('').map(c => c + c).join('');
  const [r, g, b] = [0, 2, 4].map(i => parseInt(h.slice(i, i + 2), 16) / 255);
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
  const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
  return { s, l, bluish: b > r + 0.012 && b >= g };
}
export function scan(file) {
  const src = fs.readFileSync(path.join(ROOT, file), 'utf8').split('\n');
  const bad = [];
  src.forEach((line, i) => {
    if (line.includes('kx-ok')) return;
    for (const m of line.matchAll(/#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})\b/g)) {
      const hex = '#' + m[1].toUpperCase();
      const { s, l, bluish } = hexToHsl(hex);
      const isGray = s < 0.15 && l > 0.02 && l < 0.98;      // sem cor própria = é um cinza
      if (isGray && !ALLOWED.has(hex)) bad.push({ file, line: i + 1, hex, why: bluish ? 'cinza azulado' : 'cinza fora dos 3 tons graffiti' });
    }
    for (const m of line.matchAll(/\b(?:slate|zinc|gray|neutral|stone|cool-gray)-\d{2,3}\b/g)) bad.push({ file, line: i + 1, hex: m[0], why: 'classe Tailwind de cinza' });
  });
  return bad;
}
const args = process.argv.slice(2);
const all = args.includes('--all');
const files = args.filter(a => !a.startsWith('--'));
const targets = files.length ? files : all ? ALL_FILES : PAINT_FILES;
let total = 0;
for (const f of targets) {
  if (!fs.existsSync(path.join(ROOT, f))) continue;
  const bad = scan(f); total += bad.length;
  if (!all) bad.slice(0, 40).forEach(b => console.error(`${b.file}:${b.line}  ${b.hex}  (${b.why})`));
  console.log(`${f}: ${bad.length} violação(ões)`);
}
if (all) { console.log(`\nTotal no app: ${total} (migrar para ${Object.values(GRAFFITI).join(' / ')})`); process.exit(0); }
if (total) { console.error(`\nREGRA DE CORES violada: use só ${Object.values(GRAFFITI).join(' / ')} (+ branco/preto).`); process.exit(1); }
console.log('Regra de cores OK (cinza graffiti).');
