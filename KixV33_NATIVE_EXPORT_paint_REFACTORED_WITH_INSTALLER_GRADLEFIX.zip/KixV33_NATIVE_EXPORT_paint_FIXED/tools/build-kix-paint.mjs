#!/usr/bin/env node
import { build } from 'esbuild';
import { copyFile, cp, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const ASSETS = path.join(ROOT, 'app', 'src', 'main', 'assets', 'kix');
const ASSET_PARENT = path.dirname(ASSETS);
const STAGING = path.join(ASSET_PARENT, '.kix-build-staging');
const BACKUP = path.join(ASSET_PARENT, '.kix-build-backup');
const PAINT = path.join(ROOT, 'src', 'paint');
const TEMP = path.join(STAGING, '.build-tmp');

// Files referenced by the editor HTML. The root project is the only source of truth;
// app/src/main/assets/kix is a generated deployment tree, never edited by hand.
const ROOT_ASSETS = [
  'app.js', 'kix-drag-model.js', 'kix-sortable-lite.js', 'kix-phase2.js',
  'kix-plugins.js', 'kix-quality.js',
  'tailwind-runtime.js', 'tailwind-offline.css', 'engine.js',
];
const RUNTIME_ASSETS = [
  'runtime/kix-runtime-services.js',
  'runtime/kix-runtime.js',
  'runtime/kix-phase3-runtime.js',
  'runtime/kix-data-format.js',
];

async function writeAtomically(destination, contents) {
  await mkdir(path.dirname(destination), { recursive: true });
  const temporary = `${destination}.tmp-${process.pid}`;
  await writeFile(temporary, contents);
  await rename(temporary, destination);
}

async function copyAsset(relative) {
  const source = path.join(ROOT, relative);
  const destination = path.join(STAGING, relative);
  await mkdir(path.dirname(destination), { recursive: true });
  await copyFile(source, destination);
}

await mkdir(ASSET_PARENT, { recursive: true });
await rm(STAGING, { recursive: true, force: true });
await rm(BACKUP, { recursive: true, force: true });
await cp(ASSETS, STAGING, { recursive: true, force: true });
await rm(TEMP, { recursive: true, force: true });
await mkdir(TEMP, { recursive: true });

try {
  const result = await build({
    entryPoints: [path.join(PAINT, 'kix-paint.js')],
    outfile: path.join(TEMP, 'kix-paint.bundle.js'),
    bundle: true,
    write: false,
    platform: 'browser',
    format: 'iife',
    target: ['chrome80'],
    minify: false,
    sourcemap: false,
    legalComments: 'none',
    logLevel: 'info',
  });
  if (result.errors?.length || result.outputFiles.length !== 1) {
    throw new Error('Esbuild não retornou exatamente um bundle válido.');
  }

  const sourceHtml = await readFile(path.join(ROOT, 'index.html'), 'utf8');
  if (!sourceHtml.includes('href="src/paint/kix-paint.css"') ||
      !sourceHtml.includes('<script type="module" src="src/paint/kix-paint.js"></script>') ||
      !sourceHtml.includes('<script src="src/paint/kix-paint-brush.js"></script>')) {
    throw new Error('O index.html não aponta para os arquivos-fonte canônicos de Paint.');
  }
  const androidHtml = sourceHtml
    .replaceAll('href="src/paint/kix-paint.css"', 'href="kix-paint.css"')
    .replaceAll('<script type="module" src="src/paint/kix-paint.js"></script>', '<script src="kix-paint.bundle.js"></script>')
    .replaceAll('<script src="src/paint/kix-paint-brush.js"></script>', '<script src="kix-paint-brush.js"></script>');
  if (androidHtml.includes('src/paint/kix-paint.js') || androidHtml.includes('src/paint/kix-paint.css') || androidHtml.includes('src/paint/kix-paint-brush.js')) {
    throw new Error('A transformação Android deixou referências a caminhos de desenvolvimento.');
  }

  // Build outputs are committed to the generated assets directory only after validation.
  for (const relative of ROOT_ASSETS) await copyAsset(relative);
  for (const relative of RUNTIME_ASSETS) await copyAsset(relative);
  await writeAtomically(path.join(STAGING, 'index.html'), androidHtml);
  await writeAtomically(path.join(STAGING, 'kix-paint.css'), await readFile(path.join(PAINT, 'kix-paint.css')));
  await writeAtomically(path.join(STAGING, 'kix-paint-brush.js'), await readFile(path.join(PAINT, 'kix-paint-brush.js')));
  await writeAtomically(path.join(STAGING, 'kix-paint.bundle.js'), result.outputFiles[0].contents);

  // Flat aliases are kept because the native APK exporter has a documented legacy KEEP list.
  await copyFile(path.join(STAGING, 'runtime/kix-runtime.js'), path.join(STAGING, 'runtime.js'));
  await copyFile(path.join(STAGING, 'runtime/kix-runtime-services.js'), path.join(STAGING, 'kix-runtime-services.js'));
  await copyFile(path.join(STAGING, 'runtime/kix-phase3-runtime.js'), path.join(STAGING, 'kix-phase3-runtime.js'));
  await copyFile(path.join(STAGING, 'runtime/kix-data-format.js'), path.join(STAGING, 'kix-data-format.js'));

  // These are stale copies from the former multi-source layout. The bundle and CSS above
  // are the only Paint artifacts the Android editor should load.
  for (const stale of ['kix-paint.js', 'kix-paint-algorithms.mjs', 'kix-paint-algorithms.js']) {
    await rm(path.join(STAGING, stale), { force: true });
  }

  await rm(TEMP, { recursive: true, force: true });

  // Swap the generated tree only after every file has been copied and validated.
  await rm(BACKUP, { recursive: true, force: true });
  await rename(ASSETS, BACKUP);
  try {
    await rename(STAGING, ASSETS);
  } catch (error) {
    await rename(BACKUP, ASSETS);
    throw error;
  }
  await rm(BACKUP, { recursive: true, force: true });
  process.stdout.write(`Paint compilado e assets Android sincronizados: ${result.outputFiles[0].contents.length} bytes\n`);
} finally {
  await rm(STAGING, { recursive: true, force: true });
}
