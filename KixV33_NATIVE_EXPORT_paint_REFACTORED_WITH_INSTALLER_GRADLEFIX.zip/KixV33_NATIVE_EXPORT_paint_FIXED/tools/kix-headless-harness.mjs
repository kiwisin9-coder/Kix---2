#!/usr/bin/env node
import fs from 'node:fs';
import vm from 'node:vm';
import crypto from 'node:crypto';
import path from 'node:path';

class ClassList { constructor(){this.s=new Set();} add(...a){a.forEach(x=>this.s.add(String(x)));} remove(...a){a.forEach(x=>this.s.delete(String(x)));} toggle(x,on){if(on===undefined){if(this.s.has(x))this.s.delete(x);else this.s.add(x);}else if(on)this.s.add(x);else this.s.delete(x);return this.s.has(x);} contains(x){return this.s.has(String(x));} }
class Element {
  constructor(tag='div', owner=null){ this.tagName=String(tag).toUpperCase(); this.ownerDocument=owner; this.children=[]; this.parentNode=null; this.style={}; this.dataset={}; this.className=''; this.classList=new ClassList(); this.id=''; this.innerHTML=''; this.textContent=''; this.attributes={}; this.hidden=false; this.value=''; this.src=''; this.width=0; this.height=0; this.clientWidth=360; this.clientHeight=640; this.scrollWidth=360; this.scrollHeight=640; this._listeners=new Map(); this._rect={left:0,top:0,width:360,height:640,right:360,bottom:640}; }
  appendChild(c){if(!c)return c; if(c.parentNode)c.parentNode.removeChild(c); this.children.push(c); c.parentNode=this; if(c.id&&this.ownerDocument)this.ownerDocument._byId.set(c.id,c); return c;}
  remove(){if(this.parentNode)this.parentNode.removeChild(this);}
  removeChild(c){const i=this.children.indexOf(c);if(i>=0){this.children.splice(i,1);c.parentNode=null;if(c.id&&this.ownerDocument)this.ownerDocument._byId.delete(c.id);}return c;}
  insertBefore(c,ref){if(!ref)return this.appendChild(c);const i=this.children.indexOf(ref);if(i<0)return this.appendChild(c);if(c.parentNode)c.parentNode.removeChild(c);this.children.splice(i,0,c);c.parentNode=this;return c;}
  addEventListener(type,fn){const a=this._listeners.get(type)||[];a.push(fn);this._listeners.set(type,a);return ()=>this.removeEventListener(type,fn);}
  removeEventListener(type,fn){const a=this._listeners.get(type)||[];const i=a.indexOf(fn);if(i>=0)a.splice(i,1);}
  dispatchEvent(e){e=e||{};e.target=e.target||this;(this._listeners.get(e.type)||[]).slice().forEach(fn=>fn.call(this,e));return true;}
  contains(n){if(n===this)return true;return this.children.some(c=>c.contains(n));}
  closest(sel){if(!sel)return null;let n=this;while(n){if(n.matches(sel))return n;n=n.parentNode;}return null;}
  matches(sel){ if(!sel)return false; sel=sel.trim(); if(sel.startsWith('#'))return this.id===sel.slice(1); if(sel.startsWith('.'))return this.classList.contains(sel.slice(1)); return this.tagName.toLowerCase()===sel.toLowerCase(); }
  querySelector(sel){ if(sel==='img')return this._walk().find(x=>x.tagName==='IMG')||null; if(sel==='canvas')return this._walk().find(x=>x.tagName==='CANVAS')||null; return this._walk().find(x=>x.matches(sel))||null; }
  querySelectorAll(sel){ return this._walk().filter(x=>x.matches(sel)); }
  _walk(){const out=[];for(const c of this.children){out.push(c,...c._walk());}return out;}
  setAttribute(k,v){this.attributes[k]=String(v);if(k==='id'){this.id=String(v);if(this.ownerDocument)this.ownerDocument._byId.set(this.id,this);} if(k.startsWith('data-'))this.dataset[k.slice(5)]=String(v);}
  getAttribute(k){return this.attributes[k]??null;}
  getBoundingClientRect(){return {...this._rect};}
  getContext(){return {save(){},restore(){},beginPath(){},moveTo(){},lineTo(){},stroke(){},fill(){},arc(){},rect(){},fillRect(){},clearRect(){},fillText(){},drawImage(){}};}
}
class CanvasElement extends Element { constructor(owner){super('canvas',owner);this.width=300;this.height=150;} getContext(){return super.getContext('2d');} }
class Document {
  createDocumentFragment(){ return new Element('#document-fragment',this); }
  constructor(){this._byId=new Map();this._listeners=new Map();this.body=new Element('body',this);this.documentElement=new Element('html',this);this.documentElement.appendChild(this.body);this.fonts={add(){}};}
  createElement(tag){return String(tag).toLowerCase()==='canvas'?new CanvasElement(this):new Element(tag,this);}
  createElementNS(_ns,tag){return this.createElement(tag);}
  getElementById(id){return this._byId.get(String(id))||null;}
  querySelector(sel){return this.body.querySelector(sel)||this.documentElement.querySelector(sel);}
  querySelectorAll(sel){return this.documentElement.querySelectorAll(sel);}
  addEventListener(type,fn){const a=this._listeners.get(type)||[];a.push(fn);this._listeners.set(type,a);}
  removeEventListener(type,fn){const a=this._listeners.get(type)||[];const i=a.indexOf(fn);if(i>=0)a.splice(i,1);}
  dispatchEvent(e){(this._listeners.get(e.type)||[]).slice().forEach(fn=>fn.call(this,e));}
}
class Clock {
  constructor(){this.ms=0;}
  advance(ms){this.ms+=Number(ms)||0;}
  now(){return this.ms;}
}
function seededRandom(seed){let x=(seed>>>0)||0x12345678;return()=>{x^=x<<13;x^=x>>>17;x^=x<<5;x>>>=0;return x/0x100000000;};}
function makeContext(){
  const doc=new Document();
  const root=new Element('div',doc); root.id='play-canvas'; root.clientWidth=360; root.clientHeight=640; doc.body.appendChild(root);
  const stage=new Element('div',doc); stage.id='play-stage'; stage.clientWidth=360; stage.clientHeight=640; root.appendChild(stage);
  for(const id of ['kix-hud-root','kix-controls-root','kix-dialog-box','kix-var-overlay','kix-text-layer-root','kix-brightness-overlay','kix-shader-defs','play-status','play-fps-display']) { const e=new Element('div',doc); e.id=id; doc.body.appendChild(e); }
  const clock=new Clock();
  const baseMath=Object.create(Math); baseMath.random=seededRandom(0xC0FFEE);
  const NativeDate=Date;
  class FixedDate extends NativeDate {
    constructor(...args){super(...(args.length?args:[clock.ms]));}
    static now(){return clock.ms;}
  }
  const rafQueue=new Map(); let nextTimer=1;
  const timeouts=new Map();
  const sandbox={
    window:null,document:doc,console,performance:{now:()=>clock.now(),mark(){}},Math:baseMath,Date:FixedDate,
    navigator:{userAgent:'KixHeadless',onLine:true,mediaDevices:null},location:{href:'http://localhost/'},
    URL,URLSearchParams,Blob,File,TextEncoder,TextDecoder,AbortController,fetch:async()=>({ok:false,status:503,text:async()=>''}),
    setTimeout(fn,ms){const id=nextTimer++;timeouts.set(id,{fn,at:clock.ms+Math.max(0,Number(ms)||0),kind:'timeout'});return id;},
    clearTimeout(id){timeouts.delete(id);},
    setInterval(fn,ms){const id=nextTimer++;timeouts.set(id,{fn,at:clock.ms+Math.max(1,Number(ms)||1),interval:Math.max(1,Number(ms)||1),kind:'interval'});return id;},
    clearInterval(id){timeouts.delete(id);},
    requestAnimationFrame(fn){const id=nextTimer++;rafQueue.set(id,fn);return id;},cancelAnimationFrame(id){rafQueue.delete(id);},
    innerWidth:360,innerHeight:640,devicePixelRatio:1,visualViewport:{width:360,height:640,addEventListener(){},removeEventListener(){}},
    Image:class extends Element{constructor(){super('img',doc);this.complete=true;}},
    Audio:class{constructor(){this.currentTime=0;this.volume=1;this.playbackRate=1;this.paused=true;this._listeners=new Map();}load(){} play(){this.paused=false;return Promise.resolve();}pause(){this.paused=true;}addEventListener(t,f){this._listeners.set(t,f);}removeEventListener(){}},
    FontFace:class{constructor(n,u){this.family=n;this.src=u;}load(){return Promise.resolve(this);}},
    DeviceOrientationEvent:undefined,DeviceMotionEvent:undefined,
    localStorage:{_m:new Map(),getItem(k){return this._m.get(k)||null;},setItem(k,v){this._m.set(k,String(v));},removeItem(k){this._m.delete(k);}},
    sessionStorage:{_m:new Map(),getItem(k){return this._m.get(k)||null;},setItem(k,v){this._m.set(k,String(v));},removeItem(k){this._m.delete(k);}},
    requestIdleCallback:(fn)=>setTimeout(fn,0),cancelIdleCallback:(id)=>clearTimeout(id),
    CSS:{escape:s=>String(s)},getComputedStyle:()=>({}),
    KixCatrobatBrickAliases:{},KixCatrobatBrickRegistry:{},KixPluginRuntime:{ensureBuiltinPlugins(){},findBlockByName(){return null;}},KixCatroidCompatibility:{isCatrobatProject(){return false;},ensureProject(){}},
    kixTestClock:clock,
  };
  sandbox.window=sandbox; sandbox.self=sandbox; sandbox.globalThis=sandbox; sandbox.top=sandbox; sandbox.parent=sandbox; sandbox._listeners=new Map(); sandbox.addEventListener=function(type,fn){const a=this._listeners.get(type)||[];a.push(fn);this._listeners.set(type,a);}; sandbox.removeEventListener=function(type,fn){const a=this._listeners.get(type)||[];const i=a.indexOf(fn);if(i>=0)a.splice(i,1);}; sandbox.dispatchEvent=function(e){(this._listeners.get(e.type)||[]).slice().forEach(fn=>fn.call(this,e));};
  sandbox.crypto={getRandomValues(a){for(let i=0;i<a.length;i++)a[i]=Math.floor(baseMath.random()*256);return a;},subtle:crypto.webcrypto.subtle};
  sandbox.advance=(ms)=>{clock.advance(ms);let progressed=true;while(progressed){progressed=false;for(const [id,t] of [...timeouts]){if(t.at<=clock.ms){progressed=true;if(t.kind==='interval'){t.fn();t.at+=t.interval;}else timeouts.delete(id);}}}for(const [id,fn] of [...rafQueue]){rafQueue.delete(id);fn(clock.ms);}}
  sandbox.flush=()=>sandbox.advance(0);
  return sandbox;
}
function sha(v){return crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');}
export function loadEngine(engineFile, options={}){
  const sandbox=makeContext();
  const servicesFile=options.servicesFile || path.join(path.dirname(engineFile),'runtime','kix-runtime-services.js');
  const phase3File=options.phase3File || path.join(path.dirname(engineFile),'runtime','kix-phase3-runtime.js');
  if(fs.existsSync(servicesFile)) vm.runInNewContext(fs.readFileSync(servicesFile,'utf8'),sandbox,{filename:servicesFile});
  const src=fs.readFileSync(engineFile,'utf8');
  vm.runInNewContext(src,sandbox,{filename:engineFile});
  if(fs.existsSync(phase3File)) vm.runInNewContext(fs.readFileSync(phase3File,'utf8'),sandbox,{filename:phase3File});
  // Phase 3 hooks are initialized by startEngine; direct stepCoroutine tests can initialize explicitly.
  if(!sandbox.KixEngine) throw new Error('KixEngine não inicializou');
  return {sandbox,engine:sandbox.KixEngine,clock:sandbox.kixTestClock,sha};
}
export function runCoroutine(engine,actor,blocks,start,until=200){
  const co={actor,blocks,tree:{blocks},ip:start,waitUntil:0,dead:false,loopStack:[]};
  let t=0; let steps=0;
  while(!co.dead && co.ip && steps++<until){
    engine.stepCoroutine(co,t); t+=16.6666667;
    if(co.waitUntil>t)t=co.waitUntil;
  }
  return {co,steps};
}
if(import.meta.url===`file://${process.argv[1]}`){
  const file=process.argv[2]||path.join(process.cwd(),'engine.js');
  const {engine}=loadEngine(file);
  const tests=[
    ['formula precedence',engine.evalFormula('1+2*3',{vars:{}}),7],
    ['formula parentheses',engine.evalFormula('(1+2)*3',{vars:{}}),9],
    ['formula list',engine.evalFormula('tamanho da lista("a,b,c")',{vars:{}}),3]
  ];
  console.log(JSON.stringify({ok:tests.every(([,a,b])=>Object.is(a,b)),tests},null,2));
}
