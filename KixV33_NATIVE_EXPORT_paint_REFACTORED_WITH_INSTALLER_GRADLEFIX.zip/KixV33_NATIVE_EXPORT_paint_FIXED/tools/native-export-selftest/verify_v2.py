import struct,hashlib,sys,zipfile
from cryptography import x509
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes
d=open(sys.argv[1],'rb').read()
# EOCD
e=d.rfind(b'PK\x05\x06'); cdsize,cdoff=struct.unpack_from('<II',d,e+12)
assert d[cdoff-16:cdoff]==b'APK Sig Block 42','no magic'
bsize=struct.unpack_from('<Q',d,cdoff-24)[0]; bstart=cdoff-bsize-8
assert struct.unpack_from('<Q',d,bstart)[0]==bsize
pairs=d[bstart+8:cdoff-24]; v2=None; p=0
while p<len(pairs):
    l=struct.unpack_from('<Q',pairs,p)[0]; i=struct.unpack_from('<I',pairs,p+8)[0]
    if i==0x7109871a: v2=pairs[p+12:p+8+l]
    p+=8+l
def lp(b,o=0):
    n=struct.unpack_from('<I',b,o)[0]; return b[o+4:o+4+n],o+4+n
signers,_=lp(v2); signer,_=lp(signers)
sd,o=lp(signer); sigs,o=lp(signer,o); pk,o=lp(signer,o)
assert o==len(signer)
digs,o2=lp(sd); certs,o2=lp(sd,o2); attrs,o2=lp(sd,o2); assert o2==len(sd)
dg,_=lp(digs); algo=struct.unpack_from('<I',dg)[0]; digest,_=lp(dg,4); assert algo==0x103
cert_der,_=lp(certs); cert=x509.load_der_x509_certificate(cert_der)
sg,_=lp(sigs); salgo=struct.unpack_from('<I',sg)[0]; sig,_=lp(sg,4); assert salgo==0x103
cert.public_key().verify(sig,sd,padding.PKCS1v15(),hashes.SHA256())
# recompute digest
s1=d[:bstart]; s3=d[cdoff:cdoff+cdsize]; s4=bytearray(d[e:]); struct.pack_into('<I',s4,16,len(s1))
ch=[]
for s in (s1,s3,bytes(s4)):
    for i in range(0,len(s),1<<20):
        c=s[i:i+(1<<20)]; ch.append(hashlib.sha256(b'\xa5'+struct.pack('<I',len(c))+c).digest())
top=hashlib.sha256(b'\x5a'+struct.pack('<I',len(ch))+b''.join(ch)).digest()
assert top==digest,'DIGEST MISMATCH'
print('v2 signature OK; subject',cert.subject.rfc4514_string(),'chunks',len(ch))
z=zipfile.ZipFile(sys.argv[1]); assert z.testzip() is None
for i in z.infolist():
    off=i.header_offset+30+len(i.filename.encode())+struct.unpack_from('<H',d,i.header_offset+28)[0]
    print(i.filename,'stored' if i.compress_type==0 else 'deflated','data@%d %s'%(off,'aligned' if i.compress_type or off%4==0 else 'MISALIGNED'))
