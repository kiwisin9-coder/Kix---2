import struct,sys
def parse(path):
    d=open(path,'rb').read(); assert struct.unpack_from('<H',d,0)[0]==3
    assert struct.unpack_from('<I',d,4)[0]==len(d),'file size header mismatch'
    pos=8
    t,hdr,size,count,styles,flags,ss,_=struct.unpack_from('<HHIIIIII',d,pos)
    S=[]
    for i in range(count):
        o=pos+ss+struct.unpack_from('<I',d,pos+hdr+4*i)[0]
        if flags&0x100:
            l=d[o]; o+=2 if l&0x80 else 1
            l=d[o]; o+=1
            if l&0x80: l=((l&0x7f)<<8)|d[o]; o+=1
            S.append(d[o:o+l].decode())
        else:
            l=struct.unpack_from('<H',d,o)[0]; S.append(d[o+2:o+2+2*l].decode('utf-16le'))
    pos+=size
    if struct.unpack_from('<H',d,pos)[0]==0x180: pos+=struct.unpack_from('<I',d,pos+4)[0]
    out=[]
    while pos<len(d):
        t,h,sz=struct.unpack_from('<HHI',d,pos)
        if t==0x102:
            name=S[struct.unpack_from('<I',d,pos+20)[0]]; as_,asz,ac=struct.unpack_from('<HHH',d,pos+24)
            at={}
            for i in range(ac):
                o=pos+16+as_+i*asz; ns,n,raw,_,_,ty,data=struct.unpack_from('<IIIHBBI',d,o)
                at[S[n]]=S[data] if ty==3 else data
            out.append((name,at))
        pos+=sz
    assert pos==len(d)
    return out
if __name__=='__main__':
    for e in parse(sys.argv[1]): print(e)
