import struct,sys
def u8len(n): return bytes([n]) if n<0x80 else bytes([(n>>8)|0x80,n&0xff])
def pool(strings):
    data=b'';offs=[]
    for s in strings:
        offs.append(len(data)); b=s.encode(); data+=u8len(len(s))+u8len(len(b))+b+b'\0'
    while len(data)%4: data+=b'\0'
    hdr=28; ss=hdr+4*len(strings)
    return struct.pack('<HHIIIIII',1,hdr,ss+len(data),len(strings),0,0x100,ss,0)+b''.join(struct.pack('<I',o) for o in offs)+data
A='http://schemas.android.com/apk/res/android'
S=['versionCode','versionName','label','name','screenOrientation','minSdkVersion','targetSdkVersion','package', A,'','manifest','uses-sdk','uses-permission','application','activity','android','com.kix.engine','1.7.0','Kix','com.kix.engine.MainActivity','android.permission.INTERNET','android.permission.CAMERA','android.permission.ACCESS_FINE_LOCATION','permission','provider','com.kix.engine.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION']
I={s:i for i,s in enumerate(S)}
RID={'versionCode':0x0101021b,'versionName':0x0101021c,'label':0x01010001,'name':0x01010003,'screenOrientation':0x0101001e,'minSdkVersion':0x0101020c,'targetSdkVersion':0x01010270}
res=struct.pack('<HHI',0x180,8,8+4*7)+b''.join(struct.pack('<I',RID[S[i]]) for i in range(7))
def attr(ns,name,raw,typ,data): return struct.pack('<IIIHBBI',ns,I[name],raw,8,0,typ,data)
def start(el,attrs):
    body=struct.pack('<IIHHHHHH',0xffffffff,I[el],20,20,len(attrs),0,0,0)+b''.join(attrs)
    return struct.pack('<HHIII',0x102,16,16+len(body),1,0xffffffff)+body
def end(el): return struct.pack('<HHIIIII',0x103,16,24,1,0xffffffff,0xffffffff,I[el])
def nsstart(): return struct.pack('<HHIIIII',0x100,16,24,1,0xffffffff,I['android'],I[A])
def nsend(): return struct.pack('<HHIIIII',0x101,16,24,1,0xffffffff,I['android'],I[A])
N=I[A]
def sattr(name,val,ns=N): return attr(ns,name,I[val],3,I[val])
def iattr(name,v): return attr(N,name,0xffffffff,0x10,v)
perm=lambda p: start('uses-permission',[sattr('name',p)])+end('uses-permission')
body=nsstart()+start('manifest',[iattr('versionCode',170),sattr('versionName','1.7.0'),attr(0xffffffff,'package',I['com.kix.engine'],3,I['com.kix.engine'])])
body+=start('uses-sdk',[iattr('minSdkVersion',24),iattr('targetSdkVersion',35)])+end('uses-sdk')
body+=perm('android.permission.INTERNET')+perm('android.permission.CAMERA')+perm('android.permission.ACCESS_FINE_LOCATION')
body+=start('permission',[sattr('name','com.kix.engine.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION')])+end('permission')
body+=start('application',[sattr('label','Kix')])+start('provider',[sattr('name','com.kix.engine.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION')])+end('provider')+start('activity',[sattr('name','com.kix.engine.MainActivity'),iattr('screenOrientation',1)])+end('activity')+end('application')+end('manifest')+nsend()
p=pool(S)
out=struct.pack('<HHI',3,8,8+len(p)+len(res)+len(body))+p+res+body
open('manifest.bin','wb').write(out)
