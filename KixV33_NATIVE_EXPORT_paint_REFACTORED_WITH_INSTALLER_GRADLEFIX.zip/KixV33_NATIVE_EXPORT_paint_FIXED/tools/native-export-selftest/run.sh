#!/bin/sh
# Verifies the pure-Java core of the on-device exporter (AXML patch, ZIP writer, v2 signature) on a PC.
# Requires: JDK 17+ (javac), python3 with `cryptography`.
set -e
cd "$(dirname "$0")"; SRC=../../app/src/main/java/com/kix/engine; OUT=$(mktemp -d)
python3 gen_axml.py
javac -d "$OUT" $SRC/AxmlPatcher.java $SRC/ApkPackager.java $SRC/CertFactory.java SelfTest.java
java -cp "$OUT" SelfTest
python3 axml_dump.py patched.bin
python3 verify_v2.py out.apk
