import com.kix.engine.*;
import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.security.cert.X509Certificate;
import java.util.*;
public class SelfTest {
  public static void main(String[] a) throws Exception {
    byte[] man = Files.readAllBytes(Paths.get("manifest.bin"));
    AxmlPatcher.Edit e = new AxmlPatcher.Edit();
    e.packageName="com.kixgames.frog.stars"; e.versionName="1.17"; e.versionCode=7; e.label="Frog-Stars \u00e7"; e.minSdk=26; e.targetSdk=34; e.orientation=0;
    e.keepPermissions=new HashSet<>(Arrays.asList("android.permission.INTERNET"));
    byte[] p = AxmlPatcher.patch(man, e);
    Files.write(Paths.get("patched.bin"), p);
    LinkedHashMap<String,byte[]> f = new LinkedHashMap<>();
    f.put("AndroidManifest.xml", p);
    f.put("classes.dex", new byte[3_000_000]);
    byte[] big = new byte[2_500_000]; new Random(1).nextBytes(big);
    f.put("resources.arsc", big);
    f.put("assets/kix/project.json", "{\"name\":\"x\"}".getBytes());
    f.put("lib/arm64-v8a/libx.so", new byte[5000]);
    KeyPairGenerator g = KeyPairGenerator.getInstance("RSA"); g.initialize(2048);
    KeyPair kp = g.generateKeyPair();
    X509Certificate c = CertFactory.selfSigned(kp, "Kix Test", 25);
    c.verify(kp.getPublic());
    Files.write(Paths.get("out.apk"), ApkPackager.build(f, kp.getPrivate(), c));
    ApkPackager.verify(Files.readAllBytes(Paths.get("out.apk")), c); System.out.println("selfverify ok "+c.getSubjectX500Principal());
  }
}
