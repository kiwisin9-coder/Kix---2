import re,sys
css=open('_src/ui-v34.css',encoding='utf8').read()
tag='<style id="kix-ui-v34">\n'+css+'\n</style>\n'
for f in ['index.html']:
    s=open(f,encoding='utf8').read()
    s=re.sub(r'<style id="kix-ui-v34">.*?</style>\n','',s,flags=re.S)
    s=s.replace('</body>',tag+'</body>',1)
    open(f,'w',encoding='utf8').write(s)
print('injected')
