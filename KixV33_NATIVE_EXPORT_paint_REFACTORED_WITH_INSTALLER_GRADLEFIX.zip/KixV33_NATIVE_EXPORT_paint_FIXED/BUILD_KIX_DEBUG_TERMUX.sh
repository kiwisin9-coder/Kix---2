#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT_DIR="$HOME/storage/downloads"
OUT_APK="$OUT_DIR/KixV33_NATIVE_EXPORT_paint_FIXED-debug.apk"
AAPT2_OVERRIDE="${KIX_AAPT2:-$HOME/kix-aapt2-35-test/build-tools/35.0.0/aapt2}"

fail() { printf 'ERRO: %s\n' "$*" >&2; exit 1; }
command -v node >/dev/null 2>&1 || fail 'Node.js não encontrado no Termux.'
command -v npm >/dev/null 2>&1 || fail 'npm não encontrado no Termux.'
command -v gradle >/dev/null 2>&1 || fail 'Gradle não encontrado no Termux.'
[ -d "$OUT_DIR" ] || fail 'Pasta compartilhada não encontrada. Execute termux-setup-storage e rode novamente.'

cd "$ROOT"
printf '\n[1/3] Instalando a dependência de build do Paint...\n'
npm install --no-audit --no-fund
printf '\n[2/3] Gerando assets com Esbuild e executando testes...\n'
npm test
node tools/sync-runtime.mjs
node tools/kix-runtime-parity.mjs >/dev/null
node tools/kix-color-rule.mjs
printf '\n[3/3] Compilando APK debug...\n'
if [ -x "$AAPT2_OVERRIDE" ]; then
  gradle clean assembleDebug --no-daemon -Pandroid.aapt2FromMavenOverride="$AAPT2_OVERRIDE"
else
  gradle clean assembleDebug --no-daemon
fi

APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
[ -s "$APK" ] || fail "Gradle terminou sem produzir APK no caminho esperado: $APK"
cp "$APK" "$OUT_APK"
[ -s "$OUT_APK" ] || fail 'A cópia do APK para Downloads falhou.'
printf '\nAPK criado: %s\n' "$OUT_APK"
