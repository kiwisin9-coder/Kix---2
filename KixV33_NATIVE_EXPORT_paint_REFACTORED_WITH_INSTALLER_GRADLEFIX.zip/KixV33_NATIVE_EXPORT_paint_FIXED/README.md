# Kix V33 — projeto Android e runtime web

O repositório mantém uma única fonte de verdade para o Kix Paint e gera os arquivos de distribuição com Esbuild.

## Estrutura

```text
src/paint/                 # Fonte canônica do Paint: JS, algoritmo e CSS
runtime/                   # Runtime JS compartilhado do Kix
app/src/main/java/         # Integração Android / WebView / exportador APK
app/src/main/assets/kix/   # Saída gerada para o APK; não editar manualmente
DEVELOPMENT/               # Atalho para a página-fonte; sem cópias editáveis
tests/                     # Testes de algoritmo e integração
 tools/                    # Build, sincronização, auditoria e utilitários
```

O `index.html` da raiz é a página-fonte do editor. O build copia os arquivos locais necessários para `app/src/main/assets/kix/`, compila `src/paint/kix-paint.js` e suas importações em `kix-paint.bundle.js`, e adapta somente os caminhos específicos do WebView. A saída Android é gerada; ela não é uma segunda fonte de código.

## Termux — APK debug

Na pasta em que você extraiu o ZIP, execute:

```sh
bash BUILD_KIX_DEBUG_TERMUX.sh
```

O script instala Esbuild, gera os assets, executa testes e auditorias, compila `assembleDebug` e copia o APK para:

```text
~/storage/downloads/KixV33_NATIVE_EXPORT_paint_FIXED-debug.apk
```

Se o AAPT2 personalizado já usado no Termux estiver em outro caminho, defina `KIX_AAPT2=/caminho/para/aapt2` antes do comando. O build exige Java/Gradle/Android SDK configurados no Termux.

## Testes e build separados

```sh
npm install --no-audit --no-fund
npm run build:paint
npm test
```

`npm test` executa o build de assets antes dos testes de integração. `npm run test:paint` executa somente os testes puros do algoritmo.

## Atualização remota de assets

A cópia inicial para o armazenamento privado Android e o cliente de atualização estão no código nativo. A atualização remota permanece desativada até `KIX_UPDATE_MANIFEST_URL` apontar para um manifesto real publicado por HTTPS. Consulte `docs/KIX_ASSET_UPDATES.md` antes de configurar um servidor.

## Limites desta refatoração

A refatoração remove as cópias paralelas do Paint e automatiza a geração dos assets Android. O editor legado principal (`app.js`, `kix-phase2.js` e plugins) permanece nos caminhos atuais por causa de dependências globais e contratos do runtime; movê-lo para módulos `src/core` sem mapear essas dependências seria uma mudança de risco maior, não uma simples reorganização de pastas.
