-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.kix.engine.** { *; }
-keep class androidx.webkit.** { *; }
