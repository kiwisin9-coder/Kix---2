/*
 * Kix Paint — algoritmos puros do canvas.
 * Bro: a região é topológica, não uma busca global por cor.
 * Btw: os pixels rejeitados também são marcados durante a visita para não
 * enfileirar a mesma posição repetidamente.
 * Muita resenha, mas só quatro vizinhos: esquerda, direita, cima e baixo.
 * Negócio guloso Kkkkk: o flood fill não usa recursão nem estoura a pilha JS.
 * Kkkkk v2: expandir é uma fase separada, executada depois da máscara.
 * Descançar ne pai que o caba não e de ferro.
 */
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

function validateImage(data, width, height) {
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1) {
    throw new RangeError('Dimensões do canvas inválidas.');
  }
  const pixels = width * height;
  if (!Number.isSafeInteger(pixels) || !data || data.length < pixels * 4) {
    throw new RangeError('Buffer RGBA incompatível com as dimensões.');
  }
  return pixels;
}

export function computeRegion4(data, width, height, startX, startY, tolerancePercent = 0) {
  const pixelCount = validateImage(data, width, height);
  const x = Math.floor(Number(startX));
  const y = Math.floor(Number(startY));
  const mask = new Uint8Array(pixelCount);
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0 || x >= width || y >= height) return mask;

  const tolerance = clamp(Number.isFinite(Number(tolerancePercent)) ? Number(tolerancePercent) : 0, 0, 100) * 5.1;
  const toleranceSquared = tolerance * tolerance;
  const start = y * width + x;
  const startOffset = start * 4;
  const targetR = data[startOffset];
  const targetG = data[startOffset + 1];
  const targetB = data[startOffset + 2];
  const targetA = data[startOffset + 3];
  const stack = new Int32Array(pixelCount);
  let stackSize = 0;

  function visit(index) {
    if (mask[index] !== 0) return;
    // 2 significa visitado/rejeitado; 1 significa membro da região.
    // A comparação é sempre com a cor inicial, nunca com o pixel anterior.
    mask[index] = 2;
    const offset = index * 4;
    const dr = data[offset] - targetR;
    const dg = data[offset + 1] - targetG;
    const db = data[offset + 2] - targetB;
    const da = data[offset + 3] - targetA;
    if ((dr * dr + dg * dg + db * db + da * da) <= toleranceSquared) {
      mask[index] = 1;
      stack[stackSize++] = index;
    }
  }

  mask[start] = 1;
  stack[stackSize++] = start;
  while (stackSize > 0) {
    const index = stack[--stackSize];
    const px = index % width;
    // 4-connected: nenhuma diagonal é examinada.
    if (px > 0) visit(index - 1);
    if (px + 1 < width) visit(index + 1);
    if (index >= width) visit(index - width);
    if (index + width < pixelCount) visit(index + width);
  }

  // O resultado público é uma máscara binária; rejeitados voltam a zero.
  for (let i = 0; i < pixelCount; i++) if (mask[i] === 2) mask[i] = 0;
  return mask;
}

export function expandMask4(regionMask, width, height, radius = 0) {
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1) {
    throw new RangeError('Dimensões do canvas inválidas.');
  }
  const pixelCount = width * height;
  if (!Number.isSafeInteger(pixelCount) || !regionMask || regionMask.length < pixelCount) {
    throw new RangeError('Máscara incompatível com as dimensões.');
  }
  const amount = clamp(Math.floor(Number(radius) || 0), 0, 8);
  const expanded = new Uint8Array(pixelCount);
  const queue = new Int32Array(pixelCount);
  let tail = 0;
  for (let i = 0; i < pixelCount; i++) {
    if (regionMask[i]) {
      expanded[i] = 1; // região original
      queue[tail++] = i;
    }
  }
  if (amount === 0 || tail === 0) return expanded;

  let head = 0;
  let levelEnd = tail;
  for (let step = 0; step < amount && head < levelEnd; step++) {
    while (head < levelEnd) {
      const index = queue[head++];
      const px = index % width;
      const add = (next) => {
        if (expanded[next] !== 0) return;
        expanded[next] = 2; // somente expansão pós-região
        queue[tail++] = next;
      };
      if (px > 0) add(index - 1);
      if (px + 1 < width) add(index + 1);
      if (index >= width) add(index - width);
      if (index + width < pixelCount) add(index + width);
    }
    levelEnd = tail;
  }
  return expanded;
}

export function computeSelectionMask(data, width, height, startX, startY, tolerancePercent = 0, contiguous = true) {
  if (contiguous) return computeRegion4(data, width, height, startX, startY, tolerancePercent);
  const pixelCount = validateImage(data, width, height);
  const x = Math.floor(Number(startX));
  const y = Math.floor(Number(startY));
  const mask = new Uint8Array(pixelCount);
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0 || x >= width || y >= height) return mask;
  const startOffset = (y * width + x) * 4;
  const targetR = data[startOffset], targetG = data[startOffset + 1];
  const targetB = data[startOffset + 2], targetA = data[startOffset + 3];
  const tolerance = clamp(Number.isFinite(Number(tolerancePercent)) ? Number(tolerancePercent) : 0, 0, 100) * 5.1;
  const threshold = tolerance * tolerance;
  for (let pixel = 0; pixel < pixelCount; pixel++) {
    const i = pixel * 4;
    const dr = data[i] - targetR, dg = data[i + 1] - targetG;
    const db = data[i + 2] - targetB, da = data[i + 3] - targetA;
    if (dr * dr + dg * dg + db * db + da * da <= threshold) mask[pixel] = 1;
  }
  return mask;
}

export function fillRgba(data, width, height, startX, startY, fillColor, options = {}) {
  const pixelCount = validateImage(data, width, height);
  const x = Math.floor(Number(startX)), y = Math.floor(Number(startY));
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0 || x >= width || y >= height) {
    return { changed: false, mask: new Uint8Array(pixelCount) };
  }
  const pixelArt = !!options.pixelArt;
  const erase = !!options.erase;
  const alpha = clamp((options.opacity == null ? 100 : Number(options.opacity)) / 100, 0.01, 1);
  const tolerance = pixelArt ? 0 : clamp(options.tolerance == null ? 10 : Number(options.tolerance), 0, 100);
  const region = computeRegion4(data, width, height, x, y, tolerance);
  const growth = pixelArt || erase ? 0 : clamp(Math.floor(Number(options.grow) || 0), 0, 8);
  const mask = growth ? expandMask4(region, width, height, growth) : region;
  const color = {
    r: clamp(Math.round(Number(fillColor?.r) || 0), 0, 255),
    g: clamp(Math.round(Number(fillColor?.g) || 0), 0, 255),
    b: clamp(Math.round(Number(fillColor?.b) || 0), 0, 255),
  };
  let changed = false;
  for (let pixel = 0; pixel < pixelCount; pixel++) {
    const kind = mask[pixel];
    if (!kind) continue;
    const i = pixel * 4;
    const r = data[i], g = data[i + 1], b = data[i + 2], a0 = data[i + 3];
    if (erase) {
      data[i + 3] = Math.round(a0 * (1 - alpha));
    } else if (kind === 1) {
      const oldAlpha = a0 / 255;
      const newAlpha = alpha + oldAlpha * (1 - alpha);
      data[i] = Math.round((color.r * alpha + r * oldAlpha * (1 - alpha)) / newAlpha);
      data[i + 1] = Math.round((color.g * alpha + g * oldAlpha * (1 - alpha)) / newAlpha);
      data[i + 2] = Math.round((color.b * alpha + b * oldAlpha * (1 - alpha)) / newAlpha);
      data[i + 3] = Math.round(newAlpha * 255);
    } else {
      // Expansão posterior: a cor fica sob pixels de borda já suavizados.
      const oldAlpha = a0 / 255;
      const newAlpha = oldAlpha + alpha * (1 - oldAlpha);
      if (newAlpha <= 0) continue;
      data[i] = Math.round((r * oldAlpha + color.r * alpha * (1 - oldAlpha)) / newAlpha);
      data[i + 1] = Math.round((g * oldAlpha + color.g * alpha * (1 - oldAlpha)) / newAlpha);
      data[i + 2] = Math.round((b * oldAlpha + color.b * alpha * (1 - oldAlpha)) / newAlpha);
      data[i + 3] = Math.round(newAlpha * 255);
    }
    changed ||= data[i] !== r || data[i + 1] !== g || data[i + 2] !== b || data[i + 3] !== a0;
  }
  return { changed, mask };
}

export function rgbaAt(data, width, height, x, y) {
  validateImage(data, width, height);
  const px = clamp(Math.floor(Number(x) || 0), 0, width - 1);
  const py = clamp(Math.floor(Number(y) || 0), 0, height - 1);
  const i = (py * width + px) * 4;
  return { x: px, y: py, r: data[i], g: data[i + 1], b: data[i + 2], a: data[i + 3] };
}
