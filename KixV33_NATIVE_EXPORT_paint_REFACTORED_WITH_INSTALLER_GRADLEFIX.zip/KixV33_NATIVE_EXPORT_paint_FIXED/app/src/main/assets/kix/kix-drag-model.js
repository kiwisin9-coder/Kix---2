/* Kix BrickDragModel — pure, DOM-free structural drag/reorder model. */
(function(global){
  'use strict';

  function typeOf(block){
    return String(block?.brickType || block?.type || 'command').toLowerCase();
  }
  function isHat(block){
    if(!block) return false;
    const type = typeOf(block);
    const name = String(block.name || '');
    return type === 'hat' || /^Quando\s/i.test(name);
  }
  function isControl(block){
    if(!block) return false;
    const type = typeOf(block);
    const name = String(block.name || '');
    return type === 'loop' || type === 'if' ||
      /^Se .*então/i.test(name) || /^Sempre$/i.test(name) ||
      /^Repita/i.test(name);
  }
  function isElseMarker(block){
    if(!block) return false;
    const name = String(block.name || '');
    const source = String(block.catrobat?.sourceType || '');
    return source === 'KixIfElse' || source === 'CatrobatIfElse' || /^Senão$/i.test(name);
  }
  function isEndMarker(block){
    if(!block) return false;
    if(block.boundaryKind && block.boundaryKind !== 'ifElse') return true;
    const name = String(block.name || '');
    const source = String(block.catrobat?.sourceType || '');
    return source === 'KixIfEnd' || source === 'CatrobatIfEnd' ||
      /^(?:Fim de loop|Fim de condição|Fim se)$/i.test(name);
  }
  function idOf(block){
    return String(block?.id || '');
  }

  // Flat scripts may encode a loop/IF boundary on the control itself instead
  // of storing a physical end-marker record. All structural calculations must
  // honor that explicit boundary, otherwise blocks after the virtual marker
  // remain incorrectly nested under the control.
  function explicitEndIndex(arr, controlIndex, block){
    const type = typeOf(block);
    const explicit = (type === 'loop' && block?.loopBoundaryExplicit === true)
      || (type === 'if' && block?.ifBoundaryExplicit === true);
    if(!explicit) return -1;

    const endId = type === 'loop'
      ? String(block?.loopEndId ?? '')
      : String(block?.ifEndId ?? '');
    if(!endId) return controlIndex;

    const found = arr.findIndex((candidate, i) => i > controlIndex && idOf(candidate) === endId);
    return found > controlIndex ? found : controlIndex;
  }

  function structuralParentAt(list, targetIndex){
    const arr = Array.isArray(list) ? list : [];
    const stack = [];
    for(let i=0; i<arr.length && i<=targetIndex; i++){
      const block = arr[i];
      if(!block) continue;

      while(stack.length){
        const top = stack[stack.length - 1];
        const end = explicitEndIndex(arr, top.index, top.block);
        if(end >= 0 && i > end){
          stack.pop();
          continue;
        }
        break;
      }

      if(isHat(block)) stack.length = 0;

      if(i === targetIndex){
        return stack.length ? stack[stack.length - 1] : null;
      }

      if(isElseMarker(block)) continue;

      if(isEndMarker(block)){
        const owner = block.boundaryOwnerId ?? block.catrobat?.ifOwnerId ?? block.ifEndId ?? block.loopId ?? '';
        if(owner){
          const pos = stack.findIndex(x => idOf(x.block) === String(owner));
          if(pos >= 0) stack.splice(pos, 1);
          continue;
        }
        if(stack.length) stack.pop();
        continue;
      }

      if(isControl(block)) stack.push({id:idOf(block), block, index:i});
    }
    return null;
  }

  function groupRange(list, startIndex){
    const arr = Array.isArray(list) ? list : [];
    const start = Number(startIndex);
    const source = Number.isInteger(start) && start >= 0 ? arr[start] : null;
    if(!source) return {start, end:start};

    // An event/hat is the root of a Script. Moving only the hat would detach
    // its executable body and silently change the program structure. Treat the
    // whole hat-to-next-hat range as one structural unit.
    if(isHat(source)){
      let end = start;
      for(let i=start+1;i<arr.length;i++){
        if(isHat(arr[i])) break;
        end = i;
      }
      return {start, end};
    }

    if(!isControl(source)) return {start, end:start};

    const explicitId = source.loopBoundaryExplicit === true
      ? String(source.loopEndId ?? '')
      : source.ifBoundaryExplicit === true
        ? String(source.ifEndId ?? '')
        : '';

    if(explicitId){
      const found = arr.findIndex((b,i) => i > start && idOf(b) === explicitId);
      if(found > start) return {start, end:found};
    }

    // Legacy fallback: parse nested controls by depth. Nested control groups stay
    // inside the dragged unit instead of being flattened or split.
    let depth = 1;
    let end = start;
    for(let i=start+1; i<arr.length; i++){
      const block = arr[i];
      if(!block) continue;
      if(isHat(block) && depth === 1) break;

      if(isElseMarker(block)){
        end = i;
        continue;
      }

      if(isEndMarker(block)){
        depth--;
        end = i;
        if(depth === 0) break;
        continue;
      }

      if(isControl(block)){
        depth++;
        end = i;
        continue;
      }

      end = i;
    }
    return {start, end};
  }

  function calculateInsertionIndex(list, draggedIndex, beforeIndex){
    const arr = Array.isArray(list) ? list : [];
    const start = Number(draggedIndex);
    if(!Number.isInteger(start) || start < 0 || start >= arr.length) return -1;

    const range = groupRange(arr, start);
    const group = arr.slice(range.start, range.end + 1);
    const groupSet = new Set(group);
    const remaining = arr.filter(block => !groupSet.has(block));

    if(beforeIndex == null || Number(beforeIndex) < 0){
      return remaining.length;
    }

    const beforeBlock = arr[Number(beforeIndex)];
    if(!beforeBlock || groupSet.has(beforeBlock)) return remaining.length;

    const pos = remaining.indexOf(beforeBlock);
    return pos >= 0 ? pos : remaining.length;
  }

  function buildProposal(list, draggedIndex, beforeIndex){
    const arr = Array.isArray(list) ? list : [];
    const start = Number(draggedIndex);
    if(!Number.isInteger(start) || start < 0 || start >= arr.length){
      return {valid:false, reason:'invalid-source', scripts:arr.slice(), start, end:start, insertAt:-1, group:[]};
    }

    const range = groupRange(arr, start);
    const group = arr.slice(range.start, range.end + 1);
    const groupSet = new Set(group);
    const remaining = arr.filter(block => !groupSet.has(block));

    let insertAt = remaining.length;
    let beforeBlock = null;

    if(beforeIndex != null && Number(beforeIndex) >= 0){
      beforeBlock = arr[Number(beforeIndex)] || null;
      if(beforeBlock && !groupSet.has(beforeBlock)){
        const pos = remaining.indexOf(beforeBlock);
        if(pos >= 0) insertAt = pos;
      }
    }

    const scripts = remaining.slice(0,insertAt).concat(group,remaining.slice(insertAt));
    return {
      valid:true,
      reason:'ok',
      scripts,
      start:range.start,
      end:range.end,
      insertAt,
      group,
      beforeBlock
    };
  }

  function sameOrder(a,b){
    if(!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
    for(let i=0;i<a.length;i++){
      if(a[i] !== b[i] && idOf(a[i]) !== idOf(b[i])) return false;
    }
    return true;
  }

  function validateStructure(list){
    const arr = Array.isArray(list) ? list : [];
    const errors = [];
    const stack = [];

    for(let i=0;i<arr.length;i++){
      const block = arr[i];
      if(!block) continue;

      while(stack.length){
        const top = stack[stack.length - 1];
        const end = explicitEndIndex(arr, top.index, top.block);
        if(end >= 0 && i > end){
          stack.pop();
          continue;
        }
        break;
      }

      // Structural boundary markers are intentionally disabled in the UI, but
      // they still define nesting and therefore must be processed by validation.
      if(isElseMarker(block)) continue;
      if(isEndMarker(block)){
        if(stack.length) stack.pop();
        continue;
      }
      if(block.disabled) continue;

      if(isHat(block)){
        if(stack.length){
          errors.push({index:i,block,parent:stack[stack.length-1]?.block || null,reason:'event-inside-control'});
        }
        stack.length = 0;
        continue;
      }

      const parent = stack.length ? stack[stack.length-1].block : null;
      const childType = typeOf(block);

      if(parent){
        if(block.canBeChild === false){
          errors.push({index:i,block,parent,reason:'child-not-allowed'});
        }
        const allowedParents = Array.isArray(block.allowedParent) ? block.allowedParent : null;
        if(allowedParents && allowedParents.length){
          const parentType = typeOf(parent);
          const parentKind = (parentType === 'loop' || parentType === 'if') ? 'control' : parentType;
          if(!allowedParents.includes(parentType) && !allowedParents.includes(parentKind)){
            errors.push({index:i,block,parent,reason:'parent-not-allowed'});
          }
        }
        const allowedChildren = Array.isArray(parent.allowedChildren) ? parent.allowedChildren : null;
        if(allowedChildren && allowedChildren.length){
          if(!allowedChildren.includes(childType) && !allowedChildren.includes('command') && !allowedChildren.includes('control')){
            errors.push({index:i,block,parent,reason:'child-type-not-allowed'});
          }
        }
      }

      if(isControl(block)) stack.push({id:idOf(block),block,index:i});
    }

    return errors;
  }

  function isValidDrop(list, draggedIndex, beforeIndex){
    const arr = Array.isArray(list) ? list : [];
    const source = arr[Number(draggedIndex)];
    if(!source) return {valid:false,reason:'invalid-source',scripts:arr.slice()};

    if(beforeIndex != null && Number(beforeIndex) >= 0 && Number(beforeIndex) < arr.length){
      const target = arr[Number(beforeIndex)];
      if(target && target === source) return {valid:false,reason:'self-target',scripts:arr.slice()};
    }

    const proposal = buildProposal(arr, draggedIndex, beforeIndex);
    if(!proposal.valid) return proposal;

    const errors = validateStructure(proposal.scripts);
    const groupSet = new Set(proposal.group);
    const relevant = errors.find(err =>
      groupSet.has(err.block) || (err.parent && groupSet.has(err.parent))
    );

    if(relevant){
      return Object.assign(proposal,{
        valid:false,
        reason:relevant.reason || 'invalid-structure',
        error:relevant
      });
    }

    return proposal;
  }

  function cloneScripts(scripts){
    try { return JSON.parse(JSON.stringify(Array.isArray(scripts) ? scripts : [])); }
    catch(_) { return Array.isArray(scripts) ? scripts.slice() : []; }
  }

  global.KixBrickDragModel = {
    typeOf,
    isHat,
    isControl,
    isElseMarker,
    isEndMarker,
    structuralParentAt,
    groupRange,
    calculateInsertionIndex,
    buildProposal,
    sameOrder,
    validateStructure,
    isValidDrop,
    cloneScripts
  };
})(window);
