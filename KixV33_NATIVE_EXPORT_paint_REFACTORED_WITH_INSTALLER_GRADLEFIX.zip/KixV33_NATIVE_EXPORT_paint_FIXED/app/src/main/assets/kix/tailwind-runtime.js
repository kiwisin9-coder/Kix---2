/* Kix Offline Tailwind runtime compatibility layer.
 * It covers the utility forms actually used by Kix, including arbitrary values,
 * opacity, state variants and generated DOM classes. No network is required.
 */
(function(){
  'use strict';
  const style=document.createElement('style'); style.id='kix-tailwind-runtime'; const staticLink=document.querySelector("link[href*=\"tailwind-offline.css\"]"); if(staticLink&&staticLink.parentNode) staticLink.parentNode.insertBefore(style,staticLink); else document.head.appendChild(style);
  const done=new Set();
  const esc=s=>{try{return CSS.escape(s)}catch(_){return s.replace(/([^a-zA-Z0-9_-])/g,'\\$1')}};
  const val=s=>String(s).replace(/^\[/,'').replace(/\]$/,'').replace(/_/g,' ').replace(/\\([_])/g,'$1');
  const len=v=>{v=val(v); if(v==='px') return '1px'; if(/^[-+]?\d*\.?\d+$/.test(v)){if(Number(v)===0)return '0'; return `calc(0.25rem * ${v})`;} return v};
  const rgbaColor=(v,op)=>{v=val(v); if(v==='white') return `rgba(255,255,255,${op})`; if(v==='black') return `rgba(0,0,0,${op})`; if(v.startsWith('#')){let h=v.slice(1); if(h.length===3)h=h.split('').map(x=>x+x).join(''); if(h.length===6){let n=parseInt(h,16); return `rgba(${n>>16},${(n>>8)&255},${n&255},${op})`}} return null};
  const color=v=>{v=val(v); if(v==='transparent') return 'transparent'; if(v==='white') return '#fff'; if(v==='black') return '#000'; if(v.startsWith('rgba(')||v.startsWith('rgb(')||v.startsWith('#')||v.startsWith('hsl(')||v.startsWith('var(')) return v; return null};
  const opacity=v=>{v=String(v); return v.startsWith('[')?val(v):String(Number(v)/100)};
  function propFor(u){
    let p={};
    if(u==='block')p.display='block'; else if(u==='inline-block')p.display='inline-block'; else if(u==='inline')p.display='inline'; else if(u==='flex')p.display='flex'; else if(u==='inline-flex')p.display='inline-flex'; else if(u==='grid')p.display='grid'; else if(u==='hidden')p.display='none!important';
    else if(u==='flex-1')p.flex='1 1 0%'; else if(u==='flex-none')p.flex='none'; else if(u==='flex-shrink-0')p.flexShrink='0'; else if(u==='flex-wrap')p.flexWrap='wrap'; else if(u==='flex-nowrap')p.flexWrap='nowrap';
    else if(u==='flex-col')p.flexDirection='column'; else if(u==='flex-row')p.flexDirection='row';
    else if(u==='items-center')p.alignItems='center'; else if(u==='items-start')p.alignItems='flex-start'; else if(u==='items-end')p.alignItems='flex-end';
    else if(u==='justify-center')p.justifyContent='center'; else if(u==='justify-between')p.justifyContent='space-between'; else if(u==='justify-around')p.justifyContent='space-around'; else if(u==='justify-start')p.justifyContent='flex-start';
    else if(u==='absolute')p.position='absolute'; else if(u==='relative')p.position='relative'; else if(u==='fixed')p.position='fixed'; else if(u==='sticky')p.position='sticky';
    else if(u==='inset-0')p.inset='0'; else if(/^inset-x-/.test(u)){let x=len(u.slice(8));p.left=x;p.right=x} else if(/^inset-y-/.test(u)){let x=len(u.slice(8));p.top=x;p.bottom=x}
    else if(/^(top|right|bottom|left)-/.test(u)){let [a,b]=u.split(/-(.+)/); p[a]=b==='0'?'0':b==='1/2'?'50%':b.startsWith('[')?val(b):len(b)}
    else if(/^w-/.test(u)){let v=u.slice(2); if(v==='full')p.width='100%'; else if(v==='screen')p.width='100vw'; else if(v==='auto')p.width='auto'; else p.width=len(v)}
    else if(/^h-/.test(u)){let v=u.slice(2); if(v==='full')p.height='100%'; else if(v==='screen')p.height='100vh'; else if(v==='auto')p.height='auto'; else p.height=len(v)}
    else if(/^min-w-/.test(u)){let v=u.slice(6); p.minWidth=v==='0'?'0':v==='full'?'100%':len(v)}
    else if(/^min-h-/.test(u)){let v=u.slice(6); p.minHeight=v==='0'?'0':v==='full'?'100%':len(v)}
    else if(/^max-w-/.test(u)){let v=u.slice(6); p.maxWidth=v==='full'?'100%':len(v)} else if(/^max-h-/.test(u)){let v=u.slice(6); p.maxHeight=v==='full'?'100%':len(v)}
    else if(/^p[trblxy]?-.+/.test(u)){let m=u.match(/^p([trblxy]?)-(.+)$/); if(m){let v=len(m[2]); ({'':'padding','x':'paddingInline','y':'paddingBlock','t':'paddingTop','r':'paddingRight','b':'paddingBottom','l':'paddingLeft'}[m[1]]); let k={'':'padding','x':'paddingInline','y':'paddingBlock','t':'paddingTop','r':'paddingRight','b':'paddingBottom','l':'paddingLeft'}[m[1]]; p[k]=v}}
    else if(/^m[trblxy]?-.+/.test(u)){let m=u.match(/^m([trblxy]?)-(.+)$/); if(m){let v=m[2]==='auto'?'auto':len(m[2]); let k={'':'margin','x':'marginInline','y':'marginBlock','t':'marginTop','r':'marginRight','b':'marginBottom','l':'marginLeft'}[m[1]]; p[k]=v}}
    else if(/^gap-/.test(u))p.gap=len(u.slice(4)); else if(/^grid-cols-/.test(u)){let v=u.slice(10); p.gridTemplateColumns=v.startsWith('[')?val(v):`repeat(${v},minmax(0,1fr))`}
    else if(/^rounded/.test(u)){let v=u.split('-')[1]||''; p.borderRadius=v.startsWith('[')?val(v):({'':'0.25rem','sm':'.125rem','md':'.375rem','lg':'.5rem','xl':'.75rem','2xl':'1rem','3xl':'1.5rem','full':'9999px','none':'0'}[v]||'.25rem')}
    else if(u==='border') {p.borderWidth='1px';p.borderStyle='solid'} else if(u==='border-0')p.borderWidth='0'; else if(u==='border-b')p.borderBottomWidth='1px'; else if(u==='border-b-2')p.borderBottomWidth='2px'; else if(u==='border-t')p.borderTopWidth='1px'; else if(u==='border-dashed')p.borderStyle='dashed'; else if(/^border-\[/.test(u)){let v=val(u.slice(7)); if(/^\d/.test(v)){p.borderWidth=v}else p.borderColor=v}
    else if(/^bg-/.test(u)){let v=u.slice(3); let om=v.match(/^(\[[^\]]+\]|#[0-9A-Fa-f]{3,8}|white|black)\/(\d+|\[[^\]]+\])$/); if(om){let c=rgbaColor(om[1],om[2].startsWith('[')?val(om[2]):Number(om[2])/100); if(c)p.backgroundColor=c; return p;} if(v==='transparent')p.backgroundColor='transparent'; else if(v==='gradient-to-b')p.backgroundImage='linear-gradient(to bottom,var(--tw-from,transparent),var(--tw-via,transparent),var(--tw-to,transparent))'; else {let c=color(v); if(c)p.backgroundColor=c}}
    else if(/^text-/.test(u)){let v=u.slice(5); let om=v.match(/^(\[[^\]]+\]|#[0-9A-Fa-f]{3,8}|white|black)\/(\d+|\[[^\]]+\])$/); if(om){let c=rgbaColor(om[1],om[2].startsWith('[')?val(om[2]):Number(om[2])/100); if(c)p.color=c; return p;} let c=color(v); if(c)p.color=c; else if(/^\[/.test(v))p.fontSize=val(v); else p.fontSize=({'xs':'.75rem','sm':'.875rem','lg':'1.125rem','base':'1rem','xl':'1.25rem'}[v]||undefined)}
    else if(/^font-/.test(u))p.fontWeight=({'normal':400,'medium':500,'semibold':600,'bold':700}[u.slice(5)]||undefined);
    else if(u==='font-mono')p.fontFamily='ui-monospace,SFMono-Regular,Menlo,monospace'; else if(u==='text-left')p.textAlign='left'; else if(u==='uppercase')p.textTransform='uppercase'; else if(u==='truncate'){p.overflow='hidden';p.textOverflow='ellipsis';p.whiteSpace='nowrap'}
    else if(/^leading-/.test(u)){let lv=u.slice(8);p.lineHeight=lv==='none'?'1':(/^\[/.test(lv)?val(lv):({'3':'.75rem','4':'1rem','5':'1.25rem','6':'1.5rem','7':'1.75rem','8':'2rem','9':'2.25rem','10':'2.5rem'}[lv]||len(lv)))}
    else if(/^tracking-/.test(u)){let tv=u.slice(9);p.letterSpacing=({'tighter':'-.05em','tight':'-.025em','normal':'0','wide':'.025em','wider':'.05em','widest':'.1em'}[tv]||(/^\[/.test(tv)?val(tv):tv))}
    else if(u==='overflow-hidden')p.overflow='hidden'; else if(u==='overflow-y-auto')p.overflowY='auto'; else if(u==='resize-none')p.resize='none';
    else if(u==='object-contain')p.objectFit='contain'; else if(u==='object-cover')p.objectFit='cover';
    else if(/^opacity-/.test(u))p.opacity=opacity(u.slice(8));
    else if(u==='pointer-events-none')p.pointerEvents='none'; else if(u==='pointer-events-auto')p.pointerEvents='auto';
    else if(/^z-/.test(u))p.zIndex=val(u.slice(2));
    else if(/^aspect-\[/.test(u))p.aspectRatio=val(u.slice(7));
    else if(/^from-/.test(u)){let v=u.slice(5);let c=color(v);if(c)p['--tw-from']=c}
    else if(/^via-/.test(u)){let v=u.slice(4); let om=v.match(/^(\[[^\]]+\]|#[0-9A-Fa-f]{3,8}|white|black)\/(\d+|\[[^\]]+\])$/); let c=om?rgbaColor(om[1],om[2].startsWith('[')?val(om[2]):Number(om[2])/100):color(v); if(c)p['--tw-via']=c}
    else if(/^to-/.test(u)){let v=u.slice(3); let om=v.match(/^(\[[^\]]+\]|#[0-9A-Fa-f]{3,8}|white|black)\/(\d+|\[[^\]]+\])$/);let c=om?rgbaColor(om[1],om[2].startsWith('[')?val(om[2]):Number(om[2])/100):color(v);if(c)p['--tw-to']=c}
    else if(/^shadow/.test(u)){p.boxShadow=u==='shadow-2xl'?'0 25px 50px -12px rgba(0,0,0,.25)':u==='shadow-xl'?'0 20px 25px -5px rgba(0,0,0,.1),0 8px 10px -6px rgba(0,0,0,.1)':u==='shadow-lg'?'0 10px 15px -3px rgba(0,0,0,.1),0 4px 6px -4px rgba(0,0,0,.1)':val(u.slice(7))}
    else if(u==='transition-transform')p.transition='transform .15s ease';
    else if(u==='-translate-x-1/2'){p['--tw-translate-x']='-50%';p.transform='translate(var(--tw-translate-x,0),var(--tw-translate-y,0)) scale(var(--tw-scale-x,1),var(--tw-scale-y,1))'}
    else if(u==='-translate-y-1/2'){p['--tw-translate-y']='-50%';p.transform='translate(var(--tw-translate-x,0),var(--tw-translate-y,0)) scale(var(--tw-scale-x,1),var(--tw-scale-y,1))'}
    else if(/^scale-\[/.test(u)){const sv=val(u.slice(6));p['--tw-scale-x']=sv;p['--tw-scale-y']=sv;p.transform='translate(var(--tw-translate-x,0),var(--tw-translate-y,0)) scale(var(--tw-scale-x,1),var(--tw-scale-y,1))'}
    else if(/^origin-/.test(u))p.transformOrigin=u.slice(7).replace('center','center');
    else if(/^backdrop-blur-\[/.test(u))p.backdropFilter=`blur(${val(u.slice(18))})`; else if(u==='content-start')p.alignContent='flex-start'; else if(u==='shrink-0')p.flexShrink='0';
    else return null;
    return p;
  }
  function cssRule(cls){
    let parts=cls.split(':'); let base=parts.pop(); let variant=parts.join(':');
    let p=propFor(base); if(!p)return null;
    let sel='.'+esc(cls); let prefix='';
    if(variant==='hover')sel+=':hover'; else if(variant==='focus')sel+=':focus'; else if(variant==='active')sel+=':active'; else if(variant)return null;
    let out=sel+'{'; for(const [k,v] of Object.entries(p)){if(v==null)continue; let css=k.replace(/[A-Z]/g,m=>'-'+m.toLowerCase());out+=css+':'+v+';'} return out+'}';
  }
  function addClasses(set,el){
    if(el.nodeType!==1)return;
    const c=el.getAttribute('class'); if(c)c.split(/\s+/).forEach(x=>x&&set.add(x));
  }
  function flush(set){
    let add=''; set.forEach(c=>{if(done.has(c))return; const r=cssRule(c); done.add(c); if(r)add+=r}); if(add)style.appendChild(document.createTextNode(add));
  }
  function scan(){
    const set=new Set(); document.querySelectorAll('[class]').forEach(el=>addClasses(set,el)); flush(set);
  }
  // Incremental: only the nodes that changed are inspected (the old version walked
  // the whole document on every mutation, which froze low-end phones).
  new MutationObserver(list=>{
    const set=new Set();
    for(const m of list){
      if(m.type==='attributes'){ addClasses(set,m.target); continue; }
      m.addedNodes.forEach(n=>{ if(n.nodeType!==1)return; addClasses(set,n); if(n.firstElementChild)n.querySelectorAll('[class]').forEach(el=>addClasses(set,el)); });
    }
    if(set.size)flush(set);
  }).observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['class']});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',scan); else scan();

})();
