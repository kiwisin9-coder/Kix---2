/* Kix BrickDragController — model-first mobile brick reordering.
 * Pointer events are the input stream; the DOM is only a drag preview.
 * The editor commits the logical model exactly once on drop.
 */
(function(){
  'use strict';

  function matches(el, sel){
    return !!el && el.nodeType === 1 && el.matches && el.matches(sel);
  }
  function closestMatch(el, root, sel){
    let n = el;
    while(n && n !== root){
      if(matches(n, sel)) return n;
      n = n.parentElement;
    }
    return matches(root, sel) ? root : null;
  }
  function stripIds(node){
    try{
      node.removeAttribute?.('id');
      node.querySelectorAll?.('[id]').forEach(x => x.removeAttribute('id'));
    }catch(_){}
  }
  function scrollInfo(el){
    if(el === document.scrollingElement || el === document.documentElement || el === document.body){
      return {
        top: 0,
        bottom: window.innerHeight,
        getY: () => window.scrollY || 0,
        setY: y => window.scrollTo(window.scrollX || 0, y),
        max: Math.max(0, (document.documentElement?.scrollHeight || 0) - window.innerHeight)
      };
    }
    const r = el.getBoundingClientRect();
    return {
      top: r.top,
      bottom: r.bottom,
      getY: () => el.scrollTop,
      setY: y => { el.scrollTop = y; },
      max: Math.max(0, el.scrollHeight - el.clientHeight)
    };
  }

  class BrickDragController {
    constructor(root, options){
      this.el = root;
      this.options = options || {};
      // Optional cross-container target used by palette -> script insertion.
      // The same controller/state machine is reused; no second drag engine exists.

      // Required state machine:
      // IDLE -> PRESSED -> DRAGGING -> DROPPING/CANCELLED -> IDLE
      this.state = 'IDLE';
      this.pending = null;
      this.drag = null;
      this.slot = null;
      this.ghost = null;
      this.dropRoot = null;

      this.pointerId = null;
      this.pointerType = null;
      this.startPoint = null;
      this.lastEvent = null;
      this.grab = {x: 0, y: 0};

      this.dropBefore = null;
      this.dropValid = true;
      this.dropTarget = null;

      this.timer = null;
      this._dragDelayReady = false;
      this.scrollParent = null;
      this._autoRaf = null;
      this._autoDir = 0;
      this._autoSince = 0;
      this._autoSpeed = 0;
      // Pocket Code's classic drag view uses the upper/lower sixths of the list
      // as its auto-scroll trigger zones.
      this._edge = Number(this.options.autoScrollEdge ?? 0);
      this._maxSpeed = Number(this.options.autoScrollMax ?? 7);
      this._autoDelay = Number(this.options.autoScrollDelay ?? 260);

      this._sourceDisplay = '';
      this._sourceVisibility = '';
      this._sourceTransform = '';
      this._sourceTransition = '';
      this._sourcePointerEvents = '';
      this._sourceTouchAction = '';

      this.suppressClickUntil = 0;
      this.started = false;
      this._manualScroll = false;
      this._manualScrollLastY = 0;
      this._active = true;

      this._down = this._down.bind(this);
      this._move = this._move.bind(this);
      this._up = this._up.bind(this);
      this._click = this._click.bind(this);

      root.addEventListener('pointerdown', this._down, {passive:false});
      root.addEventListener('click', this._click, true);
    }

    isDragging(){ return this.state === 'DRAGGING'; }
    isPressed(){ return this.state === 'PRESSED'; }

    _getScrollParent(){
      try {
        if(typeof this.options.scrollRoot === 'function') return this.options.scrollRoot() || document.scrollingElement || document.documentElement;
        if(this.options.scrollRoot) return this.options.scrollRoot;
      } catch(_) {}
      let p = this.el.parentElement;
      while(p && p !== document.body){
        const cs = getComputedStyle(p);
        if(/auto|scroll/.test(cs.overflowY || '') && p.scrollHeight > p.clientHeight) return p;
        p = p.parentElement;
      }
      return document.scrollingElement || document.documentElement;
    }

    _click(e){
      if(this.suppressClickUntil && performance.now() < this.suppressClickUntil){
        e.preventDefault();
        e.stopImmediatePropagation();
      }
    }

    _cleanupListeners(){
      window.removeEventListener('pointermove', this._move);
      window.removeEventListener('pointerup', this._up);
      window.removeEventListener('pointercancel', this._up);
    }

    _capturePointer(){
      try{
        if(this.pointerId != null) this.el.setPointerCapture?.(this.pointerId);
      }catch(_){}
    }

    _releasePointer(){
      try{
        if(this.pointerId != null && this.el.hasPointerCapture?.(this.pointerId)){
          this.el.releasePointerCapture(this.pointerId);
        }
      }catch(_){}
    }

    _stopAutoScroll(){
      this._autoDir = 0;
      this._autoSince = 0;
      this._autoSpeed = 0;
      if(this._autoRaf != null){
        cancelAnimationFrame(this._autoRaf);
        this._autoRaf = null;
      }
    }

    _autoTick(){
      this._autoRaf = null;
      if(this.state !== 'DRAGGING' || !this.slot || !this.lastEvent){
        this._stopAutoScroll();
        return;
      }

      if(this._autoDir && performance.now() - this._autoSince >= this._autoDelay){
        const info = scrollInfo(this.scrollParent || this._getScrollParent());
        const oldY = info.getY();
        const nextY = Math.max(0, Math.min(info.max, oldY + this._autoSpeed));
        info.setY(nextY);

        // Scrolling changes brick geometry, therefore target is recalculated.
        if(info.getY() !== oldY) this._updatePreview(this.lastEvent);
      }

      if(this._autoDir) this._autoRaf = requestAnimationFrame(() => this._autoTick());
    }

    _updateAutoScroll(clientY){
      if(this.state !== 'DRAGGING') return;

      const info = scrollInfo(this.scrollParent || this._getScrollParent());
      // Match Pocket Code/Catroid's list-drag convention: scrolling begins
      // inside the top and bottom sixths of the visible list.
      const span = Math.max(1, info.bottom - info.top);
      const edge = this._edge > 0 ? this._edge : span / 6;
      let dir = 0;
      let distance = 0;

      if(clientY < info.top + edge){
        dir = -1;
        distance = info.top + edge - clientY;
      }else if(clientY > info.bottom - edge){
        dir = 1;
        distance = clientY - (info.bottom - edge);
      }

      if(!dir){
        this._stopAutoScroll();
        return;
      }

      if(dir !== this._autoDir){
        this._autoDir = dir;
        this._autoSince = performance.now();
        this._autoSpeed = 0;
      }

      const factor = Math.min(1, Math.max(0, distance / Math.max(1, edge)));
      this._autoSpeed = dir * Math.max(2, Math.round(this._maxSpeed * factor));

      if(this._autoRaf == null) this._autoRaf = requestAnimationFrame(() => this._autoTick());
    }

    _getDropRoot(){
      try {
        if(typeof this.options.dropRoot === 'function') return this.options.dropRoot() || this.el;
        return this.options.dropRoot || this.el;
      } catch(_) { return this.el; }
    }

    _visibleChildren(){
      const root = this._getDropRoot();
      return Array.from(root.children).filter(node => {
        if(node === this.drag || node === this.slot) return false;
        if(node.dataset?.kixDragHidden === '1') return false;
        if(node.classList?.contains('kix-sortable-slot')) return false;
        // Structural end/else markers are valid insertion boundaries even though
        // they are never draggable. This permits dropping into non-empty and
        // empty control bodies without mutating the model during preview.

        const cs = getComputedStyle(node);
        const r = node.getBoundingClientRect?.();
        return cs.display !== 'none' && cs.visibility !== 'hidden' && r && r.height > 0;
      });
    }

    calculateInsertionTarget(clientX, clientY){
      const children = this._visibleChildren();

      // Structural markers are real insertion boundaries, not ordinary rows.
      // Their entire visual rectangle must be a drop zone. Previously the
      // generic center-line rule treated the lower half of `Fim de loop` as
      // being after the loop, so the exact same drag could intermittently leave
      // the control depending on where the finger was released.
      for(const node of children){
        const r = node.getBoundingClientRect();
        const isBoundary = !!(
          node.classList?.contains('loop-end') ||
          node.classList?.contains('if-marker')
        );
        if(isBoundary && clientY >= r.top && clientY <= r.bottom){
          return {
            beforeNode: node,
            clientX,
            clientY,
            centerY: r.top + r.height / 2,
            targetElement: node
          };
        }
      }

      for(const node of children){
        const r = node.getBoundingClientRect();
        const centerY = r.top + r.height / 2;
        if(clientY < centerY){
          return {
            beforeNode: node,
            clientX,
            clientY,
            centerY,
            targetElement: node
          };
        }
      }
      return {
        beforeNode: null,
        clientX,
        clientY,
        centerY: null,
        targetElement: null
      };
    }

    isValidDropTarget(target){
      try{
        if(typeof this.options.isValidDropTarget === 'function'){
          return this.options.isValidDropTarget(target) !== false;
        }
      }catch(err){
        console.warn('Kix isValidDropTarget', err);
        return false;
      }
      return true;
    }

    _applyTargetFeedback(valid){
      this.dropValid = !!valid;

      if(this.slot){
        this.slot.classList.toggle('kix-sortable-invalid', !valid);
        this.slot.setAttribute('aria-hidden', 'true');
        this.slot.style.visibility = valid ? 'visible' : 'hidden';
      }

      if(this.ghost){
        this.ghost.classList.toggle('kix-sortable-invalid', !valid);
        this.ghost.setAttribute('aria-invalid', valid ? 'false' : 'true');
      }

      try{ this.el.classList.toggle('kix-sortable-drop-invalid', !valid); }catch(_){}

      try{
        if(typeof this.options.onTargetChange === 'function'){
          this.options.onTargetChange({
            item: this.drag,
            beforeNode: this.dropBefore,
            valid: this.dropValid,
            target: this.dropTarget,
            state: this.state
          });
        }
      }catch(err){ console.warn('Kix onTargetChange', err); }
    }

    _moveSlotTo(before){
      if(!this.slot) return;

      const current = this.slot.nextElementSibling;
      if(before === current || before === this.slot){
        this.dropBefore = before;
        return;
      }

      const root = this._getDropRoot();
      if(before) root.insertBefore(this.slot, before);
      else root.appendChild(this.slot);

      this.dropBefore = before;
    }

    _updatePreview(e){
      if(this.state !== 'DRAGGING' || !this.slot || !this.ghost) return;

      this.lastEvent = e;
      this.ghost.style.transform =
        'translate3d(' + (e.clientX - this.grab.x) + 'px,' +
        (e.clientY - this.grab.y) + 'px,0)';

      this._updateAutoScroll(e.clientY);

      const target = this.calculateInsertionTarget(e.clientX, e.clientY);
      const before = target.beforeNode;
      this.dropTarget = target;

      if(before !== this.dropBefore || (!before && this.slot.nextElementSibling !== null)){
        this._moveSlotTo(before);
      }

      const valid = this.isValidDropTarget({
        item: this.drag,
        beforeNode: before,
        target,
        pointer: {x:e.clientX, y:e.clientY},
        slot: this.slot
      });

      this._applyTargetFeedback(valid);
    }

    _begin(e){
      if(this.state !== 'PRESSED' || !this.pending) return;

      const source = this.pending;
      const r = source.getBoundingClientRect();

      if(!r.width || !r.height || source.parentNode !== this.el){
        this.cancelDrag();
        return;
      }
      const dropRoot = this._getDropRoot();
      const externalTarget = dropRoot !== this.el;
      this.dropRoot = dropRoot;

      this.state = 'DRAGGING';
      this.started = true;
      this._dragDelayReady = false;
      this.drag = source;
      this.scrollParent = this.scrollParent || this._getScrollParent();

      this._sourceDisplay = source.style.display;
      this._sourceVisibility = source.style.visibility;
      this._sourceTransform = source.style.transform;
      this._sourceTransition = source.style.transition;
      this._sourcePointerEvents = source.style.pointerEvents;
      this._sourceTouchAction = source.style.touchAction;

      // Preserve the exact point grabbed by the finger.
      this.grab.x = Math.max(0, Math.min(r.width, e.clientX - r.left));
      this.grab.y = Math.max(0, Math.min(r.height, e.clientY - r.top));

      source.classList.add('kix-sortable-dragging');
      source.setAttribute('draggable', 'false');
      source.style.pointerEvents = 'none';
      source.style.touchAction = 'none';

      this.slot = source.cloneNode(true);
      stripIds(this.slot);
      this.slot.classList.remove(
        'kix-block-enter',
        'kix-sortable-dragging',
        'kix-sortable-ghost',
        'kix-sortable-placeholder',
        'kix-sortable-invalid'
      );
      this.slot.classList.add('kix-sortable-slot');
      this.slot.setAttribute('aria-hidden', 'true');
      this.slot.dataset.kixSortSlot = '1';
      // Preserve the source's visual inline styles (especially background/color)
      // while applying only the layout/drag-preview overrides. Replacing cssText
      // here would erase the Brick's category color from the clone.
      this.slot.style.width = r.width + 'px';
      this.slot.style.height = r.height + 'px';
      this.slot.style.flex = '0 0 auto';
      this.slot.style.boxSizing = 'border-box';
      this.slot.style.margin = getComputedStyle(source).margin;
      this.slot.style.pointerEvents = 'none';
      this.slot.style.touchAction = 'none';
      this.slot.style.opacity = '0';
      this.slot.style.filter = 'none';
      this.slot.style.visibility = 'visible';

      this.ghost = source.cloneNode(true);
      stripIds(this.ghost);
      this.ghost.classList.remove(
        'kix-block-enter',
        'kix-sortable-dragging',
        'kix-sortable-slot',
        'kix-sortable-placeholder',
        'kix-sortable-invalid'
      );
      this.ghost.classList.add('kix-sortable-ghost');
      // Actor ghosts are intentionally not highlighted with the Brick glow.
      // Keep the same drag engine/ghost lifecycle; only scope the visual style.
      if (source.matches && source.matches('.actor-item')) {
        this.ghost.classList.add('kix-sortable-actor-ghost');
      }
      this.ghost.setAttribute('aria-hidden', 'true');
      // Keep the cloned Brick's visual inline styles intact. Only override
      // geometry and drag behavior; do not replace cssText, because that would
      // remove the category background and other visual properties.
      this.ghost.style.position = 'fixed';
      this.ghost.style.left = '0';
      this.ghost.style.top = '0';
      this.ghost.style.width = r.width + 'px';
      this.ghost.style.height = r.height + 'px';
      this.ghost.style.margin = '0';
      this.ghost.style.pointerEvents = 'none';
      this.ghost.style.zIndex = '99999';
      this.ghost.style.opacity = '.96';
      this.ghost.style.transform = 'translate3d(' + (e.clientX - this.grab.x) + 'px,' +
        (e.clientY - this.grab.y) + 'px,0)';
      this.ghost.style.transition = 'none';
      this.ghost.style.animation = 'none';

      document.body.appendChild(this.ghost);
      if(externalTarget){
        // Palette source remains in its own screen; the insertion slot belongs
        // to the script target so it previews the real destination.
        dropRoot.appendChild(this.slot);
      }else{
        this.el.insertBefore(this.slot, source);
      }

      source.style.display = 'none';
      source.style.visibility = 'hidden';

      this._capturePointer();
      this._stopAutoScroll();

      clearTimeout(this.timer);
      this.timer = null;

      try{
        document.documentElement.classList.add('kix-drag-active');
        document.body.classList.add('kix-drag-active');
        this.el.classList.add('kix-pocket-drag-dim');
      }catch(_){}

      // Host callbacks initialize the editor/model drag context (for example,
      // the script editor stores originalIndex/originalScripts). Run onStart
      // before the first preview so isValidDropTarget sees the prepared state.
      try{
        if(typeof this.options.onStart === 'function'){
          this.options.onStart({
            item: source,
            slot: this.slot,
            state: this.state,
            pointerId: this.pointerId,
            pointerType: this.pointerType,
            startPoint: this.startPoint,
            grab: {...this.grab}
          });
        }
      }catch(err){ console.warn('Kix onStart', err); }

      this._updatePreview(e);
    }

    beginDrag(e){
      if(e) this._begin(e);
    }

    updateDrag(e){
      if(e) this._updatePreview(e);
    }

    _manualScrollBy(clientY){
      if(!this._manualScroll) return;
      const parent = this.scrollParent || this._getScrollParent();
      const prevY = this._manualScrollLastY;
      const dy = Number(clientY) - Number(prevY);
      this._manualScrollLastY = Number(clientY);
      if(!dy) return;
      try {
        const root = document.scrollingElement || document.documentElement;
        if(parent === root || parent === document.body || parent === document.documentElement){
          const current = window.scrollY || root.scrollTop || 0;
          const max = Math.max(0, (root.scrollHeight || 0) - window.innerHeight);
          const next = Math.max(0, Math.min(max, current - dy));
          if(typeof window.scrollTo === 'function') window.scrollTo(window.scrollX || 0, next);
          else root.scrollTop = next;
        }else{
          const max = Math.max(0, parent.scrollHeight - parent.clientHeight);
          parent.scrollTop = Math.max(0, Math.min(max, Number(parent.scrollTop || 0) - dy));
        }
      } catch(err){ console.warn('Kix manual scroll', err); }
    }

    _down(e){
      if(!this._active) return;
      if(this.state !== 'IDLE') return;
      if(e.button !== undefined && e.button !== 0) return;

      // A previous scroll/drag may have armed click suppression. A new pointer
      // sequence starts a fresh gesture; never let stale suppression swallow
      // the new tap's legitimate options action.
      if(this.suppressClickUntil) this.suppressClickUntil = 0;

      const options = this.options;
      const item = closestMatch(e.target, this.el, options.draggable || '>*');

      if(!item || !this.el.contains(item)) return;
      if(options.filter && (matches(item, options.filter) || matches(e.target, options.filter) || closestMatch(e.target, item, options.filter))) return;

      if(options.handle &&
         !closestMatch(e.target, item, options.handle) &&
         !matches(e.target, options.handle)){
        return;
      }

      this.pending = item;
      this.drag = item;
      this.pointerId = e.pointerId;
      this.pointerType = e.pointerType || 'unknown';
      this.startPoint = {x:e.clientX, y:e.clientY};
      this.lastEvent = e;
      this._pressStartedAt = performance.now();
      this.dropBefore = null;
      this.dropValid = true;
      this.dropTarget = null;
      this.scrollParent = this._getScrollParent();
      this.started = false;
      this._manualScroll = false;
      this._manualScrollLastY = 0;
      this._dragDelayReady = false;
      this.state = 'PRESSED';

      window.addEventListener('pointermove', this._move, {passive:false});
      window.addEventListener('pointerup', this._up, {passive:false});
      window.addEventListener('pointercancel', this._up, {passive:false});

      const delay = this.options.delay == null ? 180 : Number(this.options.delay);
      const touchOnly = this.options.delayOnTouchOnly !== false;
      const shouldDelay = !touchOnly || this.pointerType === 'touch' || this.pointerType === 'pen';

      if(shouldDelay){
        const activationDelay = Math.max(80, delay);
        this.timer = setTimeout(() => {
          if(this.state === 'PRESSED' && this.pointerId != null){
            if(this.options.delayStartsDragOnMovementOnly){
              // Legacy opt-in retained for compatibility with any external
              // caller that explicitly requests movement-gated activation.
              this._dragDelayReady = true;
            }else{
              // Main mobile editor contract: once the hold window expires,
              // the current pointer gesture becomes a Drag even if the finger
              // has not moved yet. A later move only changes the drop target.
              this._begin(this.lastEvent || e);
            }
          }
        }, activationDelay);
      }
    }

    _move(e){
      if(this.state === 'IDLE' || e.pointerId !== this.pointerId) return;

      this.lastEvent = e;

      if(this.state === 'PRESSED'){
        const dx = e.clientX - this.startPoint.x;
        const dy = e.clientY - this.startPoint.y;
        const slop = Number(this.options.touchStartThreshold || 12);

        if(this.pointerType === 'touch' || this.pointerType === 'pen') {
          // Keep vertical scrolling available before the long-press, but make the
          // gesture forgiving: movement below the slop is ignored, and movement
          // after the activation window starts the drag instead of losing it.
          if(Math.hypot(dx, dy) >= slop){
            const elapsed = performance.now() - (this._pressStartedAt || performance.now());
            if(this.options.delayStartsDragOnMovementOnly){
              const activationDelay = Math.max(80, Number(this.options.delay || 180));
              if(this._dragDelayReady || elapsed >= activationDelay){
                if(e.cancelable) e.preventDefault();
                this._begin(e);
              }else{
                // Movement before the hold threshold is scrolling, not a tap.
                // Cancel the pending gesture and suppress the synthetic click
                // so the Brick's options panel cannot open after a scroll.
                this.cancelPending('scroll');
              }
            }else{
              const grace = Math.max(180, Number(this.options.delay || 360) * 0.55);
              if(elapsed >= grace){
                if(e.cancelable) e.preventDefault();
                this._begin(e);
              }else{
                // With touch-action:none the browser cannot perform native panning
                // from the Brick itself. Switch this gesture into a dedicated
                // scrolling state and move the actual scroll container manually.
                // This keeps short tap, scroll and long-press Drag mutually exclusive.
                if(this.options.manualScrollBeforeHold){
                  if(e.cancelable) e.preventDefault();
                  clearTimeout(this.timer);
                  this.timer = null;
                  this._manualScroll = true;
                  this._manualScrollLastY = this.startPoint?.y ?? e.clientY;
                  this.suppressClickUntil = performance.now() + 650;
                  this.state = 'SCROLLING';
                  this._manualScrollBy(e.clientY);
                }else{
                  // Legacy callers can still opt into the old cancellation path.
                  this.cancelPending('scroll');
                }
              }
            }
          }
          return;
        }

        if(Math.hypot(dx, dy) >= slop){
          if(e.cancelable) e.preventDefault();
          this._begin(e);
        }
        return;
      }

      if(this.state === 'SCROLLING'){
        if(e.cancelable) e.preventDefault();
        this._manualScrollBy(e.clientY);
        return;
      }

      if(this.state === 'DRAGGING'){
        if(e.cancelable) e.preventDefault();
        this._updatePreview(e);
      }
    }

    _finish(cancelled){
      const source = this.drag;
      const slot = this.slot;
      const wasDragging = this.state === 'DRAGGING';
      const invalid = wasDragging && !this.dropValid;
      const beforeNode = this.dropBefore;
      const target = this.dropTarget;

      clearTimeout(this.timer);
      this.timer = null;
      this._stopAutoScroll();
      this._cleanupListeners();

      if(wasDragging){
        // Any completed drag gesture must suppress the follow-up synthetic click.
        // This prevents a drag that is cancelled/invalidated from being mistaken
        // for the new short-click → block-options action.
        this.suppressClickUntil = performance.now() + 420;
      }

      if(wasDragging && source && slot && !cancelled && !invalid){
        this.state = 'DROPPING';

        if(this.dropRoot === this.el){
          if(slot.parentNode === this.el) this.el.insertBefore(source, slot);
          else this.el.appendChild(source);
        }

        try{ slot.remove(); }catch(_){}
        try{ this.ghost?.remove(); }catch(_){}

        source.style.display = this._sourceDisplay || '';
        source.style.visibility = this._sourceVisibility || '';
        source.style.pointerEvents = this._sourcePointerEvents || '';
        source.style.touchAction = this._sourceTouchAction || '';
        source.style.transform = this._sourceTransform || '';
        source.style.transition = this._sourceTransition || '';
        source.classList.remove('kix-sortable-dragging');


        try{
          if(typeof this.options.onEnd === 'function'){
            this.options.onEnd({
              item: source,
              position: Array.from(this.el.children).indexOf(source),
              dropBeforeNode: beforeNode,
              target,
              cancelled:false,
              invalid:false,
              state:'DROPPING'
            });
          }
        }catch(err){ console.warn('Kix onEnd', err); }
      }else if(wasDragging){
        try{ slot?.remove(); }catch(_){}
        try{ this.ghost?.remove(); }catch(_){}

        if(source){
          source.style.display = this._sourceDisplay || '';
          source.style.visibility = this._sourceVisibility || '';
          source.style.pointerEvents = this._sourcePointerEvents || '';
          source.style.touchAction = this._sourceTouchAction || '';
          source.style.transform = this._sourceTransform || '';
          source.style.transition = this._sourceTransition || '';
          source.classList.remove('kix-sortable-dragging');
        }

        this.state = 'CANCELLED';
        try{
          if(typeof this.options.onCancel === 'function'){
            this.options.onCancel({
              item: source,
              dropBeforeNode: beforeNode,
              target,
              cancelled:true,
              invalid,
              state:'CANCELLED'
            });
          }
        }catch(err){ console.warn('Kix onCancel', err); }
      }

      try{
        document.documentElement.classList.remove('kix-drag-active');
        document.body.classList.remove('kix-drag-active');
        this.el.classList.remove('kix-pocket-drag-dim');
      }catch(_){}

      this._releasePointer();

      this.pending = null;
      this.drag = null;
      this.slot = null;
      this.ghost = null;
      this.dropRoot = null;
      this.pointerId = null;
      this.pointerType = null;
      this.startPoint = null;
      this._pressStartedAt = 0;
      this.scrollParent = null;
      this.dropBefore = null;
      this.dropTarget = null;
      this.dropValid = true;
      this.lastEvent = null;
      this.started = false;
      this._manualScroll = false;
      this._manualScrollLastY = 0;
      this._dragDelayReady = false;
      this.state = 'IDLE';
    }

    performDrop(target){
      if(this.state !== 'DRAGGING') return false;
      if(target?.beforeNode !== undefined) this.dropBefore = target.beforeNode;
      if(target?.valid === false) this.dropValid = false;
      this._finish(false);
      return true;
    }

    restoreOriginalPosition(){
      if(this.state !== 'IDLE') this._finish(true);
    }

    _up(e){
      if(e.pointerId !== this.pointerId) return;
      // Native touch scrolling can hand control back to the browser with a
      // pointercancel instead of a final pointermove/pointerup. Treat that as
      // a non-tap gesture so an eventual synthetic click cannot open options.
      if(e.type === 'pointercancel' && this.state === 'PRESSED' &&
         (this.pointerType === 'touch' || this.pointerType === 'pen')){
        this.suppressClickUntil = performance.now() + 650;
      }
      this._finish(e.type === 'pointercancel');
    }

    cancelDrag(){
      if(this.state === 'IDLE') return;
      this._finish(true);
    }

    cancelPending(reason){
      if(this.state !== 'PRESSED') return;
      if(reason === 'scroll') this.suppressClickUntil = performance.now() + 650;
      this._finish(true);
    }

    destroy(){
      this._active = false;
      if(this.state !== 'IDLE') this._finish(true);
      this._stopAutoScroll();
      this.el.removeEventListener('pointerdown', this._down);
      this.el.removeEventListener('click', this._click, true);
    }
  }

  function Sortable(root, options){ return new BrickDragController(root, options); }
  Sortable.create = (root, options) => new BrickDragController(root, options);

  // Keep the compatibility name while exposing the architectural controller.
  window.BrickDragController = BrickDragController;
  window.Sortable = Sortable;
})();
