/*
 * KixV33 Phase 3 runtime extensions.
 * Loaded only after Kix runtime core + runtime services.
 * No compiler/UI code is allowed here.
 */
(function (global) {
  'use strict';
  const E = () => global.KixEngine;
  const S = () => global.KixPhase3Services;
  const R = () => E()?.runtime;
  const norm = v => String(v == null ? '' : v).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
  const cloneJSON = value => value == null ? value : JSON.parse(JSON.stringify(value));
  const stableString = value => JSON.stringify(value, Object.keys(value || {}).sort());

  let seq = 1;
  function nextId(prefix) { return `${prefix}-${seq++}`; }
  function sourceOf(co, blk, extra = {}) {
    return Object.assign({
      sceneId: R()?.sceneIndex ?? null,
      actorId: co?.actor?.id ?? co?.actor?.data?.kixId ?? co?.actor?.data?.id ?? null,
      actorName: co?.actor?.data?.name ?? null,
      blockId: blk?.id ?? null,
      blockIndex: Number.isInteger(co?.flatIndex) ? co.flatIndex : null,
      formula: null,
      eventId: null
    }, extra);
  }
  function diagnostic(code, message, src) { return S()?.diagnostics?.report?.(code, message, src) || null; }
  function trace(type, payload = {}) {
    const r = R(); if (!r) return null;
    r.phase3 = r.phase3 || { trace: [], seq: 1 };
    const event = Object.assign({ type, order: r.phase3.trace.length }, payload);
    r.phase3.trace.push(event);
    if (r.phase3.trace.length > 50000) r.phase3.trace.shift();
    return event;
  }

  function actorKey(actor) { return String(actor?.id ?? actor?.data?.kixId ?? actor?.data?.id ?? actor?.data?.name ?? ''); }
  function sortActors(actors) { return [...(actors || [])].sort((a,b) => actorKey(a).localeCompare(actorKey(b))); }

  function getFlat(actor) {
    let scripts = actor?.data?.scripts;
    if (scripts?.blocks && scripts?.stacks) scripts = E()?.scriptsToFlat?.(scripts) || [];
    if (!Array.isArray(scripts)) scripts = [];
    try { E()?.ensureFlatLoopBoundaries?.(scripts); } catch (_) {}
    actor.data.scripts = scripts;
    return scripts;
  }
  function isHat(block) {
    const n = norm(block?.name);
    return block?.type === 'hat' || n.startsWith('quando ') || n.startsWith('quando');
  }
  function matchingHats(actor, predicate) {
    const flat = getFlat(actor), out = [];
    for (let i=0;i<flat.length;i++) if (!flat[i]?.disabled && isHat(flat[i]) && predicate(flat[i], i)) out.push(i);
    return out;
  }
  function makeCoroutine(actor, flatBlocks, meta = {}) {
    const blocks = (flatBlocks || []).filter(Boolean).map(b => Object.assign({}, b));
    const co = {
      actor,
      flatMode: true,
      flatBlocks: blocks,
      flatIndex: 0,
      waitUntil: 0,
      dead: false,
      loopStack: [],
      blocks: {}, ip: null, tree: null,
      phase3: Object.assign({ id: nextId('co') }, meta)
    };
    R().coroutines.push(co);
    return co;
  }
  function launchHat(actor, predicate, meta = {}) {
    const flat = getFlat(actor);
    const indices = matchingHats(actor, predicate);
    const launched = [];
    for (const hi of indices) {
      const slice = [];
      for (let j=hi+1;j<flat.length;j++) {
        if (isHat(flat[j])) break;
        if (!flat[j]?.disabled) slice.push(flat[j]);
      }
      if (!slice.length) continue;
      const co = makeCoroutine(actor, slice, Object.assign({}, meta, { hatId: flat[hi]?.id || `hat-${hi}` }));
      launched.push(co);
    }
    return launched;
  }

  function messageFromBlock(co, blk, ctx) {
    const raw = blk?.values?.mensagem ?? blk?.values?.message ?? blk?.params?.mensagem ?? blk?.params?.message ?? '';
    try {
      const formula = E()?.evalFormula;
      if (formula && typeof raw === 'string' && /[+*\-/()]/.test(raw)) return String(formula(raw, ctx));
    } catch (_) {}
    return String(raw == null ? '' : raw).replace(/^['"]|['"]$/g, '');
  }
  function messageFromHat(hat) {
    const v = hat?.values?.mensagem ?? hat?.values?.message ?? hat?.values?.nome ?? hat?.params?.mensagem ?? hat?.params?.message ?? '';
    return String(v == null ? '' : v).replace(/^['"]|['"]$/g, '');
  }
  function launchMessage(message, eventId, parentCo) {
    const r = R();
    const msg = String(message);
    const actors = sortActors(r.actors);
    const receivers = [];
    for (const actor of actors) {
      const flat=getFlat(actor);
      for(let hi=0;hi<flat.length;hi++){
        const hat=flat[hi]; if(!hat || !isHat(hat) || hat.disabled) continue;
        const hn=norm(hat.name);
        if(!hn.includes('receber mensagem') && !hn.includes('quando receber')) continue;
        const expected=messageFromHat(hat);
        if(expected && expected !== msg && norm(expected) !== norm(msg) && expected !== '*') continue;
        const slice=[];
        for(let j=hi+1;j<flat.length;j++){ if(isHat(flat[j])) break; if(!flat[j]?.disabled) slice.push(flat[j]); }
        if(!slice.length) continue;
        const child=makeCoroutine(actor,slice,{receiverType:'broadcast',eventId,message:msg,parentEventId:parentCo?.phase3?.eventId||null,hatId:hat.id||`hat-${hi}`});
        try { S()?.receivers?.register?.('broadcast', actorKey(actor), ()=>{}, {id:`receiver-${child.phase3.id}`,eventId,message:msg}); } catch (_) {}
        receivers.push(child);
      }
    }
    receivers.sort((a,b)=>String(a.actor?.id || '').localeCompare(String(b.actor?.id || '')) || String(a.phase3?.hatId||'').localeCompare(String(b.phase3?.hatId||'')));
    r.phase3.pendingBroadcasts.set(eventId, { id:eventId, message:msg, receivers, wait:!!parentCo });
    for (const co of receivers) {
      try { S()?.receivers?.register?.('broadcast', actorKey(co.actor), () => {}, {id: `receiver-${co.phase3.id}`, eventId, message:msg}); } catch (_) {}
    }
    trace('broadcast.dispatch', { eventId, message:msg, receiverCount:receivers.length });
    return receivers;
  }

  function activeReceiverCount(eventId) {
    const item = R()?.phase3?.pendingBroadcasts?.get(eventId);
    if (!item) return 0;
    return item.receivers.filter(c => !c.dead).length;
  }
  function finishBroadcast(eventId) {
    const r=R(); const item=r?.phase3?.pendingBroadcasts?.get(eventId); if (!item) return;
    if (activeReceiverCount(eventId)===0) {
      r.phase3.pendingBroadcasts.delete(eventId);
      try { S()?.receivers?.snapshot?.().filter(x => x.meta?.eventId===eventId).forEach(x=>S().receivers.unregister(x.id)); } catch (_) {}
      trace('broadcast.complete', {eventId});
    }
  }

  function listName(blk, ctx) {
    const raw = blk?.values?.lista ?? blk?.values?.list ?? blk?.values?.nome ?? blk?.params?.lista ?? blk?.params?.list ?? blk?.params?.nome ?? '';
    let v=raw;
    try { if (typeof raw==='string' && raw.trim().startsWith('=')) v=E()?.evalFormula?.(raw.slice(1),ctx); } catch (_) {}
    return String(v == null ? '' : v).replace(/^['"]|['"]$/g,'').trim() || 'lista';
  }
  function listValue(blk,key,ctx,fallback='') {
    const raw=blk?.values?.[key] ?? blk?.params?.[key] ?? fallback;
    try { if (typeof raw==='string' && raw.trim().startsWith('=')) return E()?.evalFormula?.(raw.trim().slice(1),ctx); } catch (_) {}
    return raw;
  }
  function ensureLists(project, runtime) {
    const incoming = project?.lists || project?.data?.lists || {};
    const out={};
    if (Array.isArray(incoming)) for (const item of incoming) {
      const name=String(item?.name||item?.id||'lista'); out[name]=Array.isArray(item?.items)?cloneJSON(item.items):Array.isArray(item?.value)?cloneJSON(item.value):[];
    }
    else if (incoming && typeof incoming==='object') for (const [name,value] of Object.entries(incoming)) out[name]=Array.isArray(value)?cloneJSON(value):[];
    for (const [name,value] of Object.entries(runtime.lists||{})) if (!(name in out)) out[name]=Array.isArray(value)?value:[];
    runtime.lists=out;
    return out;
  }

  function cloneActor(source, index) {
    const r=R(), limit=Math.max(1,Math.floor(Number(r.project?.runtime?.maxClones ?? r.project?.settings?.maxClones ?? 256)));
    const current=r.actors.filter(a=>a?.data?.isClone).length;
    if(current>=limit){ diagnostic('CLONE_LIMIT',`Limite de clones excedido (${limit})`,{actorId:source?.id,actorName:source?.data?.name}); return null; }
    const data=cloneJSON(source.data||{});
    data.isClone=true; data.cloneOf=source.id ?? source.data?.kixId ?? source.data?.name ?? '';
    data.name=`${String(data.name||'Objeto')} clone ${current+1}`;
    data.kixId=nextId('clone'); data._vars=cloneJSON(data._vars||{});
    const el=document.createElement('div'); el.dataset.kixClone='1'; el.className=source.el?.className || 'kix-runtime-actor';
    el.style.cssText=source.el?.style?.cssText||'';
    const clone={id:data.kixId,index:r.actors.length,data,el,_cloneSource:source,_cloneIndex:index};
    try { r.actors.push(clone); if(r.stageEl?.appendChild) r.stageEl.appendChild(el); } catch (_) {}
    r.phase3.clones.set(clone.id,clone);
    try { E()?.updateSpriteTransform?.(clone,true); } catch (_) {}
    const launched=launchHat(clone,hat=>norm(hat.name).includes('comecar como clone'),{receiverType:'clone',cloneId:clone.id,eventId:nextId('clone-event')});
    trace('clone.create',{cloneId:clone.id,sourceId:source.id ?? null,receiverCount:launched.length});
    return clone;
  }
  function deleteClone(actor) {
    if(!actor?.data?.isClone) return false;
    const r=R();
    for(const co of r.coroutines||[]) if(co.actor===actor) co.dead=true;
    try { S()?.lifecycle?.clearScope?.(`clone:${actor.id}`); } catch (_) {}
    try { S()?.receivers?.unregisterOwner?.(actor.id); } catch (_) {}
    try { actor.el?.remove?.(); } catch (_) {}
    r.actors=r.actors.filter(a=>a!==actor); r.phase3.clones.delete(actor.id);
    trace('clone.delete',{cloneId:actor.id});
    return true;
  }

  function normalizeUserDefs(project) {
    const defs = project?.userDefinedBricks || project?.userBricks || project?.yourBricks || project?.customBricks || [];
    const arr=Array.isArray(defs)?defs:Object.entries(defs||{}).map(([id,d])=>Object.assign({id},d));
    const out=[];
    for(const d of arr) {
      if(!d) continue;
      const normalized={id:String(d.id||d.name||nextId('brick')),name:String(d.name||d.id||'UserBrick'),parameters:Array.isArray(d.parameters)?d.parameters.map(p=>({name:String(p?.name||''),type:String(p?.type||'text'),default:p?.default})):[],blocks:d.blocks?.blocks&&d.blocks?.stacks?(E()?.scriptsToFlat?.(d.blocks)||[]):Array.isArray(d.blocks)?d.blocks:(Array.isArray(d.scripts)?d.scripts:[]),returnType:String(d.returnType||'void'),noScreenRefresh:!!(d.noScreenRefresh||d.refreshScreen===false)};
      out.push(normalized);
    }
    return out;
  }
  function substituteValue(v,args) {
    if(typeof v==='string') {
      const exact=v.match(/^\s*(?:\$\{|\{\{)?([A-Za-z_][\w ]*)(?:\}|\})?\s*$/);
      if(exact && Object.prototype.hasOwnProperty.call(args,exact[1])) return args[exact[1]];
      return v.replace(/\$\{([^}]+)\}|\{\{([^}]+)\}\}/g,(_,a,b)=>String(args[a||b] ?? ''));
    }
    if(Array.isArray(v)) return v.map(x=>substituteValue(x,args));
    if(v && typeof v==='object') return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,substituteValue(x,args)]));
    return v;
  }
  function findUserDef(blk) {
    const id=blk?.userDefinedBrickId ?? blk?.customBrickId ?? blk?.userBrickId ?? blk?.values?.userDefinedBrickId ?? blk?.values?.id;
    const name=blk?.userDefinedBrickName ?? blk?.values?.nome ?? blk?.values?.name ?? blk?.name;
    const defs=R()?.phase3?.userBricks;
    return defs.find(d=>String(d.id)===String(id)) || defs.find(d=>norm(d.name)===norm(name)) || null;
  }
  function parameterArgs(def,blk,ctx) {
    const values=Object.assign({}, blk?.values||{}, (blk?.values && typeof blk.values.values==='object') ? blk.values.values : {});
    const args={};
    for(const p of def.parameters) {
      let v=values[p.name] ?? values[p.id] ?? blk?.params?.[p.name];
      if(v===undefined) v=p.default;
      if(typeof v==='string' && v.trim().startsWith('=')) { try{v=E()?.evalFormula?.(v.trim().slice(1),ctx);}catch(_){} }
      if(p.type==='number') v=Number(v)||0;
      else if(p.type==='boolean') v=(v===true||v===1||norm(v)==='true'||norm(v)==='sim');
      else v=v==null?'':v;
      args[p.name]=v;
    }
    return args;
  }
  function userBrickCall(co,blk,ctx) {
    const def=findUserDef(blk); if(!def){ diagnostic('USER_BRICK_NOT_FOUND',`UserDefinedBrick não encontrado: ${blk?.name||'desconhecido'}`,sourceOf(co,blk)); return {handled:true}; }
    const frame=S().userBricks.enter(def.id,parameterArgs(def,blk,ctx),sourceOf(co,blk));
    if(!frame) return {handled:true};
    const childBlocks=cloneJSON(def.blocks).map(b=>{const q=substituteValue(b,frame.args);return q;});
    const child=makeCoroutine(co.actor,childBlocks,{receiverType:'userbrick',userBrickId:def.id,parentCo:co.phase3?.id || null,userFrame:frame,noScreenRefresh:def.noScreenRefresh});
    child._phase3ReturnVar=def.returnVar||null;
    co._phase3UserBrickCall={child,frame,defId:def.id};
    trace('userbrick.enter',{id:def.id,depth:frame.depth,args:frame.args,parent:co.phase3?.id || null});
    return {handled:true,advance:false,yield:true};
  }
  function pollUserBrick(co) {
    const c=co?._phase3UserBrickCall; if(!c)return false;
    if(!c.child.dead)return true;
    const value=c.child._phase3ReturnValue;
    if(c.defId) { try { S()?.userBricks.leave?.(c.frame); } catch (_) {} }
    if(value!==undefined) R().globals.__user_brick_return=value;
    co._phase3UserBrickCall=null;
    trace('userbrick.exit',{id:c.defId,value:value===undefined?null:value,parent:co.phase3?.id});
    return false;
  }

  function sensorKey(name) {
    const n=norm(name);
    if(n.includes('acelerometro') && (n.endsWith(' x') || n.endsWith('_x'))) return 'acelerometro_x';
    if(n.includes('acelerometro') && (n.endsWith(' y') || n.endsWith('_y'))) return 'acelerometro_y';
    if(n.includes('acelerometro') && (n.endsWith(' z') || n.endsWith('_z'))) return 'acelerometro_z';
    if(n.includes('giroscopio') && n.includes('alpha')) return 'giroscopio_alpha';
    if(n==='giroscopio_alpha') return 'giroscopio_alpha';
    if(n.includes('giroscopio') && n.includes('beta')) return 'giroscopio_beta';
    if(n==='giroscopio_beta') return 'giroscopio_beta';
    if(n.includes('giroscopio') && n.includes('gamma')) return 'giroscopio_gamma';
    if(n==='giroscopio_gamma') return 'giroscopio_gamma';
    if(n.includes('inclinacao') && n.endsWith(' x')) return 'inclinacao_x';
    if(n.includes('inclinacao') && n.endsWith(' y')) return 'inclinacao_y';
    if(n.includes('inclinacao') && n.endsWith(' z')) return 'inclinacao_z';
    if(n.includes('bussola')) return 'bussola';
    if(n.includes('gps') && n.includes('latitude')) return 'gps_latitude';
    if(n.includes('gps') && n.includes('longitude')) return 'gps_longitude';
    if(n.includes('gps') && n.includes('precis')) return 'gps_precisao';
    if(n.includes('loudness') || n.includes('volume do microfone')) return 'loudness';
    if(n.includes('face')) return 'face_detected';
    if(n.includes('toque x')) return 'toque_x';
    if(n.includes('toque y')) return 'toque_y';
    if(n.includes('tela esta tocada') || n.includes('toque down') || n==='toque') return 'toque_down';
    return null;
  }

  function beforeBlock(payload) {
    const {co,blk,ctx,now,name} = payload;
    const beforeMutation = runtimeState();
    const r=R(); if(!r || !co || !blk) return null;
    for (const id of [...(r.phase3?.pendingBroadcasts?.keys?.() || [])]) finishBroadcast(id);
    if (co._phase3BroadcastWait) {
      const waitId=co._phase3BroadcastWait;
      finishBroadcast(waitId);
      if (r.phase3.pendingBroadcasts.has(waitId)) return {handled:true,advance:false,yield:true};
      co._phase3BroadcastWait=null;
      if (co.ip===blk.id) co.ip=blk.next||null;
      return {handled:true,advance:false,yield:false};
    }
    if (co._phase3UserBrickCall) {
      if (pollUserBrick(co)) return {handled:true,advance:false,yield:true};
      if (co.ip===blk.id) co.ip=blk.next||null;
      return {handled:true,advance:false,yield:false};
    }
    const n=norm(name);
    const source=sourceOf(co,blk);
    try {
      const t0=performance.now();
      S()?.debugger?.emit?.({type:'brick.enter',blockId:blk.id||null,name,actorId:source.actorId});
      const finish=(res)=>{S()?.profiler?.record?.(`brick:${blk.opcode||name}`,performance.now()-t0); trace('brick',{blockId:blk.id||null,name,actorId:source.actorId,result:res||'ok'});return res;};

      // Event/broadcast family: exact receiver matching + deterministic wait token.
      if(n==='enviar mensagem' || n==='enviar mensagem e esperar' || n.startsWith('enviar mensagem')) {
        const msg=messageFromBlock(co,blk,ctx), eventId=nextId('broadcast');
        const stack=r.phase3.broadcastStack;
        if(stack.includes(msg)){ diagnostic('BROADCAST_CYCLE',`Ciclo de broadcast detectado para "${msg}"`,Object.assign({},source,{eventId})); return finish({handled:true,advance:true}); }
        stack.push(msg); launchMessage(msg,eventId, n.includes('esperar')?co:null); stack.pop();
        r.messages.push(msg);
        if(n.includes('esperar')) { co._phase3BroadcastWait=eventId; return finish({handled:true,advance:false,yield:true}); }
        return finish({handled:true});
      }
      if(co._phase3BroadcastWait) {
        const id=co._phase3BroadcastWait; finishBroadcast(id);
        if(r.phase3.pendingBroadcasts.has(id)) return {handled:true,advance:false,yield:true};
        co._phase3BroadcastWait=null;
      }

      // Lists — 1 based; invalid indices become structured diagnostics.
      if(n.includes('criar lista')) { const nameL=listName(blk,ctx); r.lists[nameL]=[]; commitMutation('list:create', beforeMutation); return finish({handled:true}); }
      if(n.includes('adicionar') && n.includes('lista')) { const nameL=listName(blk,ctx), value=listValue(blk,'item',ctx,listValue(blk,'valor',ctx,'')); (r.lists[nameL] ||= []).push(value); trace('list.mutate',{op:'add',list:nameL}); commitMutation('list:add', beforeMutation); return finish({handled:true}); }
      if(n.includes('inserir') && n.includes('lista')) { const nameL=listName(blk,ctx), value=listValue(blk,'item',ctx,''), idx=Math.trunc(Number(listValue(blk,'indice',ctx,listValue(blk,'posição',ctx,1)))); const a=(r.lists[nameL] ||= []); if(idx<1||idx>a.length+1){diagnostic('LIST_INDEX',`Índice inválido: ${idx}`,source);return finish({handled:true});} a.splice(idx-1,0,value); trace('list.mutate',{op:'insert',list:nameL,index:idx});commitMutation('list:insert', beforeMutation);return finish({handled:true}); }
      if(n.includes('substituir') && n.includes('lista')) { const nameL=listName(blk,ctx), value=listValue(blk,'item',ctx,''), idx=Math.trunc(Number(listValue(blk,'indice',ctx,listValue(blk,'posição',ctx,1)))), a=(r.lists[nameL] ||= []); if(idx<1||idx>a.length){diagnostic('LIST_INDEX',`Índice inválido: ${idx}`,source);return finish({handled:true});} a[idx-1]=value; trace('list.mutate',{op:'replace',list:nameL,index:idx});commitMutation('list:replace', beforeMutation);return finish({handled:true}); }
      if(n.includes('apagar') && n.includes('lista') && n.includes('tudo')) { const nameL=listName(blk,ctx); r.lists[nameL]=[]; trace('list.mutate',{op:'clear',list:nameL});commitMutation('list:clear', beforeMutation);return finish({handled:true}); }
      if(n.includes('apagar') && n.includes('lista')) { const nameL=listName(blk,ctx), idx=Math.trunc(Number(listValue(blk,'indice',ctx,listValue(blk,'posição',ctx,1)))), a=(r.lists[nameL] ||= []); if(idx<1||idx>a.length){diagnostic('LIST_INDEX',`Índice inválido: ${idx}`,source);return finish({handled:true});} a.splice(idx-1,1);trace('list.mutate',{op:'delete',list:nameL,index:idx});commitMutation('list:delete', beforeMutation);return finish({handled:true}); }
      if(n.includes('tamanho') && n.includes('lista')) { const nameL=listName(blk,ctx); ctx.globals.__formula_result=(r.lists[nameL]||[]).length; return finish({handled:true}); }
      if(n.includes('item da lista')) { const nameL=listName(blk,ctx), idx=Math.trunc(Number(listValue(blk,'indice',ctx,listValue(blk,'posição',ctx,1)))), a=(r.lists[nameL]||[]); if(idx<1||idx>a.length){diagnostic('LIST_INDEX',`Índice inválido: ${idx}`,source);ctx.globals.__formula_result='';} else ctx.globals.__formula_result=a[idx-1]; return finish({handled:true}); }
      if(n.includes('lista contem') || n.includes('lista contém')) { const nameL=listName(blk,ctx), value=listValue(blk,'item',ctx,''), a=(r.lists[nameL]||[]); ctx.globals.__formula_result=a.includes(value)?1:0; return finish({handled:true}); }
      if(n.includes('indice') && n.includes('lista')) { const nameL=listName(blk,ctx), value=listValue(blk,'item',ctx,''), a=(r.lists[nameL]||[]), idx=a.indexOf(value); ctx.globals.__formula_result=idx<0?0:idx+1; return finish({handled:true}); }

      // Sensors with deterministic provider + permission gate.
      const sensor=sensorKey(name);
      if(sensor) { const value=S()?.sensors?.read?.(sensor,source) ?? 0; ctx.globals.__sensor_result=value; r.device=r.device||{}; return finish({handled:true, value}); }

      // Clones.
      if(n==='criar clone' || n.includes('criar clone')) { cloneActor(co.actor); commitMutation('clone:create', beforeMutation); return finish({handled:true}); }
      if(n.includes('apagar este clone')) { deleteClone(co.actor); commitMutation('clone:delete', beforeMutation); return finish({handled:true,advance:false,yield:true}); }

      // UserDefinedBrick invocation.
      if(blk.userDefinedBrickId || blk.customBrickId || blk.userBrickId || blk.userDefinedBrickName || n.startsWith('executar bloco personalizado') || n.startsWith('chamar bloco') || r.phase3.userBricks.some(d=>norm(d.name)===n)) {
        return userBrickCall(co,blk,ctx);
      }
    } catch(error) {
      S()?.debugger?.error?.(error,'phase3.beforeBlock');
      diagnostic('RUNTIME_BRICK_ERROR',String(error?.message||error),source);
      co.dead=true;
      return {handled:true,advance:false,yield:true};
    }
    return null;
  }

  function runtimeState(){
    const r=R();
    return {formatVersion:2,globals:cloneJSON(r?.globals||{}),lists:cloneJSON(r?.lists||{}),actors:(r?.actors||[]).map(a=>({id:a.id,data:cloneJSON(a.data||{})}))};
  }
  function applyRuntimeState(state){
    const r=R(); if(!r)return false;
    try{const data=global.KixDataFormat?.migrate?global.KixDataFormat.migrate(state):state;r.globals=cloneJSON(data.globals||{});r.lists=cloneJSON(data.lists||{});const byId=new Map((data.actors||[]).map(a=>[String(a.id),a.data||{}]));(r.actors||[]).forEach(a=>{const saved=byId.get(String(a.id));if(saved)a.data=Object.assign({},a.data,cloneJSON(saved));});return true;}catch(error){diagnostic('STATE_RESTORE',String(error?.message||error),{});return false;}
  }
  function commitMutation(label,before){try{const after=runtimeState();S()?.undoRedo?.commit?.(label,before,after);}catch(_){}}
  function undo(){return !!S()?.undoRedo?.undo?.();}
  function redo(){return !!S()?.undoRedo?.redo?.();}
  function init(project) {
    const r=R(); if(!r)return;
    seq=1;
    r.phase3={
      version:3,
      trace:[],seq:1,
      pendingBroadcasts:new Map(),
      broadcastStack:[],
      clones:new Map(),
      userBricks:normalizeUserDefs(project),
      maxClones:Math.max(1,Math.floor(Number(project?.runtime?.maxClones??256))),
      deterministic:!!S()?.determinism?.isDeterministic?.()
    };
    ensureLists(project,r);
    try{S()?.undoRedo?.configure?.(applyRuntimeState,100);S()?.undoRedo?.clear?.();}catch(_){}
    S()?.userBricks?.defs?.clear?.();
    for(const def of r.phase3.userBricks) { try { S()?.userBricks?.define?.(def); } catch (_) {} }
    trace('runtime.init',{userBrickCount:r.phase3.userBricks.length,listCount:Object.keys(r.lists||{}).length});
  }
  function stop() {
    const r=R(); if(!r?.phase3)return;
    for(const c of r.coroutines||[]) if(c?.actor?.data?.isClone) c.dead=true;
    try { S()?.lifecycle?.clearAll?.(); } catch (_) {}
    try { S()?.receivers?.snapshot?.().forEach(x=>S()?.receivers?.unregister?.(x.id)); } catch (_) {}
    r.phase3.pendingBroadcasts.clear(); r.phase3.broadcastStack.length=0; r.phase3.clones.clear();
    trace('runtime.stop',{remainingCoroutines:(r.coroutines||[]).filter(c=>!c.dead).length,receiverCount:S()?.receivers?.count?.()||0});
  }
  function sweep() {
    const r=R(); if(!r?.phase3)return;
    for(const id of [...r.phase3.pendingBroadcasts.keys()]) finishBroadcast(id);
    for(const rec of S()?.receivers?.snapshot?.()||[]) {
      const eventId=rec.meta?.eventId;
      if(eventId && !r.phase3.pendingBroadcasts.has(eventId)) { try { S()?.receivers?.unregister?.(rec.id); } catch (_) {} }
    }
  }
  function snapshot() {
    const r=R();
    return {
      phase3Version:3,
      lists:cloneJSON(r?.lists||{}),
      clones:[...(r?.phase3?.clones?.values?.()||[])].map(a=>({id:a.id,name:a.data?.name,cloneOf:a.data?.cloneOf})),
      broadcasts:[...(r?.phase3?.pendingBroadcasts?.values?.()||[])].map(x=>({id:x.id,message:x.message,receivers:activeReceiverCount(x.id)})),
      receivers:S()?.receivers?.snapshot?.()||[],
      userBricks:S()?.userBricks?.snapshot?.()||null,
      diagnostics:S()?.diagnostics?.list?.()||[],
      profiler:S()?.profiler?.snapshot?.()||[],
      lifecycle:S()?.lifecycle?.snapshot?.()||{},
      undoRedo:S()?.undoRedo?.snapshot?.()||{},
      trace:r?.phase3?.trace?.slice?.()||[]
    };
  }
  function traceHash() {
    const data=JSON.stringify(R()?.phase3?.trace||[]);
    let h=0x811c9dc5; for(let i=0;i<data.length;i++){h^=data.charCodeAt(i);h=Math.imul(h,16777619);} return (h>>>0).toString(16).padStart(8,'0');
  }

  global.KixPhase3Runtime={init,stop,beforeBlock,sweep,snapshot,traceHash,ensureLists,deleteClone,runtimeState,applyRuntimeState,undo,redo};
  // Formula sensor adapter. Engine formulaLookup remains the source of general semantics.
  global.KixPhase3Runtime.sensorFormula = function(name,source={}) { const key=sensorKey(name); return key ? S()?.sensors?.read?.(key,source) : undefined; };
})(typeof window!=='undefined'?window:globalThis);
