/* Kix Phase 2 — deterministic interaction, lifecycle, diagnostics and tooling. */
(() => {
  'use strict';

  class DeterministicRouter {
    constructor(root = document) {
      this.root = root;
      this.routes = {click:[],pointerdown:[],pointerup:[],keydown:[]};
      this.bound = false;
      this.sequence = 0;
      this.startedAt = performance.now();
      this.dispatchCount = 0;
    }
    on(type, selector, handler, priority = 100) {
      if (!this.routes[type]) throw new Error(`Unsupported event: ${type}`);
      const route = {selector, handler, priority:Number(priority)||0, order:this.sequence++};
      this.routes[type].push(route);
      this.routes[type].sort((a,b)=>b.priority-a.priority || a.order-b.order);
      return () => { const a=this.routes[type]; const i=a.indexOf(route); if(i>=0)a.splice(i,1); };
    }
    dispatch(type, event) {
      const routes = (this.routes[type] || []).slice();
      this.dispatchCount++;
      for (const route of routes) {
        let target = event.target;
        if (route.selector) {
          target = target?.closest?.(route.selector) || null;
          if (!target || !this.root.contains(target)) continue;
        }
        const result = route.handler(event, target);
        if (result === true) {
          event.preventDefault?.();
          event.stopImmediatePropagation?.();
          return true;
        }
      }
      return false;
    }
    start() {
      if (this.bound) return;
      this.bound = true;
      for (const type of Object.keys(this.routes)) {
        this.root.addEventListener(type, e => this.dispatch(type,e), true);
      }
    }
    snapshot() { return {startedAt:this.startedAt,dispatchCount:this.dispatchCount,routes:Object.fromEntries(Object.entries(this.routes).map(([k,v])=>[k,v.map(x=>({selector:x.selector,priority:x.priority,order:x.order}))]))}; }
  }

  class Lifecycle {
    constructor(){ this.scopes = new Map(); this.nextId=1; this.current='app'; }
    _scope(name){ const key=String(name||'app'); if(!this.scopes.has(key))this.scopes.set(key,new Map()); return this.scopes.get(key); }
    _add(scope, type, handle, meta={}){ const id=this.nextId++; this._scope(scope).set(id,{id,type,handle,createdAt:performance.now(),meta}); return id; }
    setTimeout(fn,ms,scope='app',meta={}){ const id=this.nextId; const handle=window.setTimeout(()=>{this._delete(scope,id); try{fn();}catch(e){window.KixDebugger?.error?.(e,'timer');}},ms); return this._add(scope,'timeout',handle,meta); }
    setInterval(fn,ms,scope='app',meta={}){ const id=this.nextId; const handle=window.setInterval(()=>{try{fn();}catch(e){window.KixDebugger?.error?.(e,'timer');}},ms); return this._add(scope,'interval',handle,meta); }
    requestAnimationFrame(fn,scope='app',meta={}){ const id=this.nextId; const handle=window.requestAnimationFrame(t=>{this._delete(scope,id); try{fn(t);}catch(e){window.KixDebugger?.error?.(e,'raf');}}); return this._add(scope,'raf',handle,meta); }
    _delete(scope,id){ this._scope(scope).delete(id); }
    clear(id,scope='app'){ const s=this._scope(scope), rec=s.get(id); if(!rec)return false; if(rec.type==='interval')window.clearInterval(rec.handle); else if(rec.type==='timeout')window.clearTimeout(rec.handle); else window.cancelAnimationFrame?.(rec.handle); s.delete(id); return true; }
    clearScope(scope){ const s=this._scope(scope); for(const rec of [...s.values()]){ if(rec.type==='interval')window.clearInterval(rec.handle); else if(rec.type==='timeout')window.clearTimeout(rec.handle); else window.cancelAnimationFrame?.(rec.handle); } s.clear(); }
    count(scope){return this._scope(scope).size;}
    enter(scope){ this.current=String(scope||'app'); }
    leave(previous='app'){ this.current=String(previous||'app'); }
    scope(){ return this.current; }
    runIn(scope,fn){ const prev=this.current; this.current=String(scope||'app'); try{return fn();} finally{this.current=prev;} }
    clearAll(){ for(const name of this.scopes.keys()) this.clearScope(name); }
    snapshot(){const out={}; for(const [k,v] of this.scopes)out[k]={count:v.size,timers:[...v.values()].map(x=>({type:x.type,ageMs:Math.round(performance.now()-x.createdAt),meta:x.meta}))}; return out;}
  }

  const router = new DeterministicRouter(document);
  const lifecycle = new Lifecycle();
  router.start();
  window.KixEventRouter = Object.freeze({on:(...a)=>router.on(...a),dispatch:(...a)=>router.dispatch(...a),snapshot:()=>router.snapshot()});
  window.KixLifecycle = Object.freeze({
    setTimeout:(...a)=>lifecycle.setTimeout(...a), setInterval:(...a)=>lifecycle.setInterval(...a), requestAnimationFrame:(...a)=>lifecycle.requestAnimationFrame(...a),
    clear:(...a)=>lifecycle.clear(...a), clearScope:(...a)=>lifecycle.clearScope(...a), count:(...a)=>lifecycle.count(...a), snapshot:()=>lifecycle.snapshot(), scope:()=>lifecycle.scope(), runIn:(...a)=>lifecycle.runIn(...a), clearAll:()=>lifecycle.clearAll(), setScope:s=>{lifecycle.current=String(s||'app');}
  });

  const profilerData = new Map();
  function profile(name, fn){ const start=performance.now(); try{return fn();} finally {const d=profilerData.get(name)||{calls:0,total:0,max:0}; const ms=performance.now()-start; d.calls++;d.total+=ms;d.max=Math.max(d.max,ms);profilerData.set(name,d);} }
  const profiler={measure:profile, record(name,ms){name=String(name);ms=Math.max(0,Number(ms)||0);const d=profilerData.get(name)||{calls:0,total:0,max:0};d.calls++;d.total+=ms;d.max=Math.max(d.max,ms);profilerData.set(name,d);return d;}, async measureAsync(name,fn){const start=performance.now();try{return await fn();}finally{const d=profilerData.get(name)||{calls:0,total:0,max:0};const ms=performance.now()-start;d.calls++;d.total+=ms;d.max=Math.max(d.max,ms);profilerData.set(name,d);}}, mark(name){try{performance.mark(String(name));}catch(_){}}, snapshot(){return [...profilerData.entries()].map(([name,d])=>({name,calls:d.calls,totalMs:+d.total.toFixed(2),avgMs:+(d.total/d.calls).toFixed(2),maxMs:+d.max.toFixed(2)})).sort((a,b)=>b.totalMs-a.totalMs);}, reset(){profilerData.clear();}};
  window.KixProfiler=Object.freeze(profiler);

  const logs=[]; const originalConsole={log:console.log,warn:console.warn,error:console.error};
  function capture(level,args){ logs.push({time:Date.now(),level,message:args.map(x=>{try{return typeof x==='string'?x:JSON.stringify(x);}catch(_){return String(x);}}).join(' ')}); if(logs.length>500)logs.shift(); }
  console.log=(...a)=>{capture('log',a);originalConsole.log.apply(console,a);};
  console.warn=(...a)=>{capture('warn',a);originalConsole.warn.apply(console,a);};
  console.error=(...a)=>{capture('error',a);originalConsole.error.apply(console,a);};
  const debuggerApi={
    logs:()=>logs.slice(), clear:()=>logs.splice(0,logs.length), error:(e,source='app')=>capture('error',[`[${source}]`,e?.stack||e?.message||e]),
    snapshot:()=>{const r=window.KixEngine?.runtime;return {playing:!!window.KixProjectAPI?.getCurrentProject?.(),runtime: r?{running:!!r.running,paused:!!r.paused,freeCam:!!r.freeCam,camX:r.camX,camY:r.camY,camZoom:r.camZoom}:null,lifecycle:lifecycle.snapshot(),history:window.KixBrickHistory?.counts?.()||null};}
  };
  const debugSubscribers=new Set();
  function debugEmit(event){ for(const fn of [...debugSubscribers]){try{fn(event);}catch(e){capture('error',['[debug-subscriber]',e]);}} }
  const originalError=debuggerApi.error;
  debuggerApi.error=(e,source='app')=>{const result=originalError(e,source);debugEmit({type:'error',time:Date.now(),source,message:e?.message||String(e)});return result;};
  window.KixDebugger=Object.freeze(Object.assign({},debuggerApi,{emit:event=>debugEmit(event),subscribe(fn){if(typeof fn!=='function')throw new TypeError('subscriber must be a function');debugSubscribers.add(fn);return()=>debugSubscribers.delete(fn);},events:()=>debugSubscribers.size}));

  const auditLog=[];
  function audit(action,payload={}){const entry={id:`audit-${Date.now()}-${auditLog.length+1}`,time:Date.now(),action:String(action),payload};auditLog.push(entry);if(auditLog.length>500)auditLog.shift();return entry;}
  const originalHistory=window.KixBrickHistory;
  const historyAdapter={
    undo(){const ok=originalHistory?.undo?.()===true;audit(ok?'history.undo':'history.undo.failed');return ok;},
    redo(){const ok=originalHistory?.redo?.()===true;audit(ok?'history.redo':'history.redo.failed');return ok;},
    clear(){originalHistory?.clear?.();audit('history.clear');},
    counts(){return originalHistory?.counts?.()||{undo:0,redo:0};},
    execute(command){
      if(!command||typeof command.redo!=='function'||typeof command.undo!=='function')throw new TypeError('Invalid history command');
      const label=String(command.label||command.name||'command');
      command.redo();
      const result={id:`cmd-${Date.now()}-${auditLog.length+1}`,label,createdAt:Date.now(),command};
      audit('command.execute',{id:result.id,label});
      return result;
    },
    audit:()=>auditLog.slice()
  };
  // Keep the original drag-history implementation authoritative while routing
  // public undo/redo calls through the audit layer. No second history stack is created.
  if(originalHistory){
    window.KixBrickHistory=Object.freeze({
      undo:historyAdapter.undo, redo:historyAdapter.redo, clear:historyAdapter.clear,
      counts:()=>originalHistory.counts?.()||{undo:0,redo:0}
    });
  }
  window.KixHistoryAudit=Object.freeze(historyAdapter);
  function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function svg(name){const p={back:'<path d="M15 19l-7-7 7-7"/>',inspect:'<path d="M4 5h16v14H4z"/><path d="M8 9h8M8 13h5"/>',bug:'<path d="M9 7V5h6v2M7 10H4m16 0h-3M7 14H4m16 0h-3M9 18v2m6-2v2"/><rect x="7" y="7" width="10" height="12" rx="4"/>',chart:'<path d="M4 19V5M4 19h16"/><path d="M7 15l3-4 3 2 5-7"/>',undo:'<path d="M9 7 4 12l5 5"/><path d="M4 12h10a5 5 0 010 10h-2"/>',refresh:'<path d="M20 11a8 8 0 10-2.3 5.7M20 5v6h-6"/>'};return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p[name]||p.inspect}</svg>`;}

  function ensureUI(){
    if(document.getElementById('kix-phase2-screen')) return;
    const style=document.createElement('style'); style.id='kix-phase2-style'; style.textContent=`
      #kix-phase2-screen{position:fixed;inset:0;z-index:2600;background:#1f1f1f;color:#e8e8e8;display:flex;flex-direction:column}
      #kix-phase2-screen.hidden{display:none!important}.k2-head{height:58px;display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid #34363b;background:#262626}.k2-head button{width:38px;height:38px;display:grid;place-items:center;background:none;border:0;color:#aaa}.k2-head svg{width:20px;height:20px}.k2-title{font-size:15px}.k2-tabs{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;padding:10px;background:#252525}.k2-tab{min-height:40px;border:1px solid #3a3d42;border-radius:9px;background:#2c2c2c;color:#bbb}.k2-tab.active{border-color:#059669;color:#fff;background:#303633}.k2-body{flex:1;min-height:0;overflow:auto;padding:12px}.k2-card{background:#292b2f;border:1px solid #383b40;border-radius:10px;margin-bottom:10px;padding:12px}.k2-card h3{font-size:13px;margin-bottom:8px}.k2-row{display:flex;justify-content:space-between;gap:12px;padding:7px 0;border-bottom:1px solid #35373b;font-size:12px}.k2-row:last-child{border-bottom:0}.k2-muted{color:#888}.k2-error{color:#f87171}.k2-warn{color:#fbbf24}.k2-ok{color:#34d399}.k2-pre{white-space:pre-wrap;word-break:break-word;font:11px/1.45 ui-monospace,monospace;color:#c7c9ce}.k2-action{min-height:40px;border:1px solid #3a3d42;background:#303238;color:#ddd;border-radius:8px;padding:0 12px}.k2-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.k2-empty{padding:22px;text-align:center;color:#777}
    `; document.head.appendChild(style);
    const screen=document.createElement('section'); screen.id='kix-phase2-screen'; screen.className='hidden'; screen.innerHTML=`<header class="k2-head"><button id="k2-back" aria-label="Voltar">${svg('back')}</button><div class="k2-title">Ferramentas técnicas</div></header><nav class="k2-tabs"><button class="k2-tab active" data-k2-tab="inspector">Inspector</button><button class="k2-tab" data-k2-tab="debugger">Debugger</button><button class="k2-tab" data-k2-tab="profiler">Profiler</button></nav><main class="k2-body" id="k2-body"></main></section>`; document.body.appendChild(screen);
    document.querySelectorAll('[data-k2-tab]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-k2-tab]').forEach(x=>x.classList.toggle('active',x===b));renderTab(b.dataset.k2Tab);}));
    document.getElementById('k2-back').addEventListener('click',()=>screen.classList.add('hidden'));
  }
  function currentSelection(){
    const selected=window._kixSelectedBlock||null;
    const actor=window.KixProjectAPI?.getCurrentActor?.(); const p=window.KixProjectAPI?.getCurrentProject?.();
    const block=document.querySelector('#script-blocks .pc-block[data-block-id="'+String(selected?.blockId||'').replace(/"/g,'')+'"]');
    return {project:p,actor,blockEl:block,selected};
  }
  function renderInspector(){const body=document.getElementById('k2-body');if(!body)return;const s=currentSelection();const p=s.project,a0=s.actor,b=s.blockEl;let a=a0;if(s.selected&&p){for(const sc of (p.scenes||[])){const found=(sc.actors||[]).find(x=>String(x?.id||'')===String(s.selected.actorId||''));if(found){a=found;break;}}}let block=null;if(a&&b){const idx=Number(b.dataset.scriptIdx);block=Number.isFinite(idx)&&Array.isArray(a.scripts)?a.scripts[idx]:null;} body.innerHTML=`<div class="k2-card"><h3>Projeto</h3><div class="k2-row"><span>ID</span><span class="k2-muted">${esc(p?.kixId||p?.id||'—')}</span></div><div class="k2-row"><span>Nome</span><span>${esc(p?.name||'—')}</span></div><div class="k2-row"><span>Cena</span><span>${esc(window.KixProjectAPI?.getCurrentSceneIndex?.()??'—')}</span></div></div><div class="k2-card"><h3>Objeto selecionado</h3><div class="k2-row"><span>ID</span><span class="k2-muted">${esc(a?.id||'—')}</span></div><div class="k2-row"><span>Nome</span><span>${esc(a?.name||'—')}</span></div></div><div class="k2-card"><h3>Brick selecionado</h3>${block?`<div class="k2-row"><span>ID</span><span>${esc(block.id)}</span></div><div class="k2-row"><span>Nome</span><span>${esc(block.name)}</span></div><div class="k2-row"><span>Tipo</span><span>${esc(block.type||'—')}</span></div><div class="k2-pre">${esc(JSON.stringify(block,null,2))}</div>`:'<div class="k2-empty">Selecione um Brick no editor e abra o Inspector.</div>'}</div>`;}
  function renderDebugger(){const body=document.getElementById('k2-body');if(!body)return;const d=debuggerApi.snapshot(),logs2=logs.slice(-100).reverse();body.innerHTML=`<div class="k2-card"><h3>Runtime</h3><div class="k2-row"><span>Executando</span><span>${d.runtime?.running?'sim':'não'}</span></div><div class="k2-row"><span>Pausado</span><span>${d.runtime?.paused?'sim':'não'}</span></div><div class="k2-row"><span>Câmera</span><span>${esc([d.runtime?.camX,d.runtime?.camY,d.runtime?.camZoom].join(' / '))}</span></div></div><div class="k2-card"><h3>Lifecycle</h3><div class="k2-pre">${esc(JSON.stringify(d.lifecycle,null,2))}</div></div><div class="k2-card"><h3>Histórico</h3><div class="k2-row"><span>Undo</span><span>${d.history?.undo??0}</span></div><div class="k2-row"><span>Redo</span><span>${d.history?.redo??0}</span></div><div class="k2-row"><span>Auditoria</span><span>${window.KixHistoryAudit?.audit?.().length??0}</span></div></div><div class="k2-card"><h3>Event Router</h3><div class="k2-pre">${esc(JSON.stringify(window.KixEventRouter?.snapshot?.()||{},null,2))}</div></div><div class="k2-card"><h3>Console capturado</h3><div class="k2-actions"><button class="k2-action" id="k2-clear-log">Limpar</button></div><div class="k2-pre">${esc(logs2.map(x=>`[${new Date(x.time).toLocaleTimeString()}] ${x.level}: ${x.message}`).join('\n')||'Sem eventos.')}</div></div>`;document.getElementById('k2-clear-log')?.addEventListener('click',()=>{debuggerApi.clear();renderDebugger();});}
  function renderProfiler(){const body=document.getElementById('k2-body');if(!body)return;const rows=profiler.snapshot();body.innerHTML=`<div class="k2-card"><h3>Tempo medido</h3><div class="k2-actions"><button class="k2-action" id="k2-prof-reset">Limpar medições</button></div>${rows.length?rows.map(x=>`<div class="k2-row"><span>${esc(x.name)}</span><span>${x.calls}× · ${x.avgMs} ms médio · ${x.maxMs} ms máx.</span></div>`).join(''):'<div class="k2-empty">Nenhuma medição registrada.</div>'}</div>`;document.getElementById('k2-prof-reset')?.addEventListener('click',()=>{profiler.reset();renderProfiler();});}
  function renderTab(tab){if(tab==='debugger')renderDebugger();else if(tab==='profiler')renderProfiler();else renderInspector();}
  function openTools(tab='inspector'){ensureUI();const s=document.getElementById('kix-phase2-screen');s.classList.remove('hidden');document.querySelectorAll('[data-k2-tab]').forEach(b=>b.classList.toggle('active',b.dataset.k2Tab===tab));renderTab(tab);}
  window.KixPhase2=Object.freeze({openInspector:()=>openTools('inspector'),openDebugger:()=>openTools('debugger'),openProfiler:()=>openTools('profiler'),runTests:()=>behaviorTests(),router:window.KixEventRouter,lifecycle:window.KixLifecycle});

  function behaviorTests(){
    const out=[];const check=(name,ok,detail='')=>out.push({name,ok:!!ok,detail});
    try{
      const r=new DeterministicRouter(document);let seq=[];r.on('click','#k2-test',()=>{seq.push('low');return false},10);r.on('click','#k2-test',()=>{seq.push('high');return true},100);const btn=document.createElement('button');btn.id='k2-test';document.body.appendChild(btn);r.dispatch('click',{target:btn,preventDefault(){},stopImmediatePropagation(){}});btn.remove();check('Router respeita prioridade determinística',seq.join(',')==='high','ordem: '+seq.join(','));
      const l=new Lifecycle();let ticks=0;l.setInterval(()=>ticks++,5,'test');check('Lifecycle registra intervalos',l.count('test')===1);l.clearScope('test');check('Lifecycle limpa escopo completo',l.count('test')===0);
      const h=window.KixBrickHistory?.counts?.();check('Undo/redo expõe contadores reais',!!h&&Number.isInteger(h.undo)&&Number.isInteger(h.redo),JSON.stringify(h));
      check('Lifecycle troca de escopo explicitamente',(()=>{lifecycle.enter('test-scope');const ok=lifecycle.current==='test-scope';lifecycle.leave();return ok})());
      check('Profiler registra medições',(()=>{const before=profiler.snapshot().length;profile('phase2-test',()=>1+1);return profiler.snapshot().length===before+1})());
      check('Lifecycle restaura escopo após exceção',(()=>{let restored=false;try{lifecycle.runIn('phase2-test',()=>{throw new Error('expected');});}catch(_){restored=lifecycle.scope()==='app';}return restored;})());
      check('Router snapshot expõe contagem de dispatch',()=>Number.isInteger(window.KixEventRouter.snapshot().dispatchCount));
      check('Auditoria de histórico está disponível',()=>Array.isArray(window.KixHistoryAudit.audit()));
      check('Lifecycle possui escopo runtime',()=>{const before=lifecycle.count('runtime');const id=lifecycle.setTimeout(()=>{},1000,'runtime',{test:true});const ok=lifecycle.count('runtime')===before+1;lifecycle.clear(id,'runtime');return ok;});
      check('Profiler aceita registro manual de runtime',()=>{const before=profiler.snapshot().length;profiler.record('runtime.test',0.01);return profiler.snapshot().length===before+1;});
    }catch(e){check('Execução dos testes comportamentais',false,e.message||String(e));}
    return {ok:out.every(x=>x.ok),results:out};
  }
  window.KixPhase2Tests=behaviorTests;

  // One deterministic path for the new technical tools. Existing editor handlers
  // remain intact; this router does not replace them blindly.
  router.on('click','#kix-open-inspector',e=>{e.preventDefault();openTools('inspector');return true;},1000);
  router.on('click','#kix-open-debugger',e=>{e.preventDefault();openTools('debugger');return true;},1000);
  router.on('click','#kix-open-profiler',e=>{e.preventDefault();openTools('profiler');return true;},1000);

  // Play-stage controls use the same capture-phase router. This gives these
  // controls one priority order without rewriting unrelated editor gestures.
  router.on('click','#btn-play-more',e=>{document.getElementById('play-more-menu')?.classList.toggle('hidden');return true;},1000);
  const stageActions={
    '#play-more-rotate':()=>window.rotatePlayScreen?.(),
    '#play-more-camera':()=>window.toggleFreeCam?.(),
    '#play-more-reset-camera':()=>window.fitStage?.(),
    '#play-more-fit':()=>window.fitStage?.(),
    '#play-more-axes':()=>window.toggleStageAxes?.(),
    '#play-more-grid':()=>window.toggleStageGrid?.(),
    '#play-more-fps':()=>{const r=window.KixEngine?.runtime;if(!r)return; r.showFps=!r.showFps;document.getElementById('play-fps-display')?.classList.toggle('hidden',!r.showFps);document.getElementById('debug-panel')?.classList.toggle('hidden',!r.showFps);},
    '#play-more-clearlog':()=>{window.KixDebugger.clear();},
    '#play-more-selftest':()=>{const r=window.KixEngine?.selfTest?.();console.table(r?.results||[]);window.KixProjectAPI?.toast?.(r?.ok?'Verificação concluída: OK':'Verificação encontrou falhas — veja o console');},
    '#play-more-clean':()=>window.setPlayCleanMode?.(true),
    '#play-more-reload':()=>{try{window.KixEngine?.stopEngine?.();window.startPlay?.();}catch(e){window.KixDebugger.error(e,'reload');}},
  };
  Object.entries(stageActions).forEach(([selector,fn])=>router.on('click',selector,e=>{e.preventDefault();fn();document.getElementById('play-more-menu')?.classList.add('hidden');return true;},1000));
  document.querySelectorAll('.kix-stage-option-heading').forEach(heading=>router.on('click','#'+heading.id,e=>{const body=document.getElementById(heading.getAttribute('aria-controls'));if(!body)return false;const open=body.classList.toggle('hidden')===false;heading.setAttribute('aria-expanded',String(open));return true;},1100));

  // Keyboard undo/redo is centralized here without hijacking text inputs.
  router.on('keydown','body',(e)=>{
    const z=(e.ctrlKey||e.metaKey)&&String(e.key).toLowerCase()==='z'; const y=(e.ctrlKey||e.metaKey)&&String(e.key).toLowerCase()==='y';
    if(!z&&!y)return false;
    const t=e.target; if(t?.matches?.('input,textarea,[contenteditable="true"]') && !t.closest?.('#screen-formula'))return false;
    if(t?.closest?.('#screen-formula')){ if(z){window.undoFormula?.();return true;} if(y|| (z&&e.shiftKey)){window.redoFormula?.();return true;} return false; }
    if(z&&!e.shiftKey){window.KixBrickHistory?.undo?.();return true;} if(y||e.shiftKey){window.KixBrickHistory?.redo?.();return true;} return false;
  },900);

  // Diagnostics entry points are intentionally explicit and use SVG-only icons.
  window.addEventListener('kix:phase2:open',e=>openTools(e.detail?.tab||'inspector'));
})();
