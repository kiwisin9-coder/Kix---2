/*
 * Kix Plugins runtime/editor — Kix 1.7.5
 *
 * Plugin manifests are JSON and are stored locally. JavaScript is the runtime
 * language because the current Kix client is a self-contained Android WebView.
 * The manifest keeps an explicit language field so future native/embedded
 * runtimes can be added without changing the block/category data model.
 */
(function (global) {
  'use strict';

  function kixPluginSvgIcon(name, size=18) {
    const paths = {
      more: '<circle cx="12" cy="5" r="1.35"/><circle cx="12" cy="12" r="1.35"/><circle cx="12" cy="19" r="1.35"/>',
      chevron: '<path d="M6 9l6 6 6-6"/>'
    };
    return `<svg class="kix-svg-icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.more}</svg>`;
  }

  const STORE = 'kix_plugins';
  const EDITOR_STORE = 'kix_editor_mode';
  const DB_NAME = 'KixSafeStore';
  const DB_VERSION = 1;
  const SCHEMA = 'kix-plugin-v1';
  const SUPPORTED_RUNTIME_LANGUAGE = 'javascript';
  const LANGUAGE_LABELS = {
    javascript: 'JavaScript',
    python: 'Python',
    lua: 'Lua',
    java: 'Java'
  };

  const state = {
    plugins: [],
    app: null,
    attached: false,
    currentPluginId: null,
    currentSection: 'overview',
    globalRuntimeStarted: new Set(),
    languageRuntimes: new Map(),
    uiRuleSnapshots: [],
    editingKind: null,
    editingId: null,
    editorDraft: null,
    editorSaveTimer: null
  };

  function clone(v) {
    try { return JSON.parse(JSON.stringify(v)); } catch (_) { return v; }
  }

  function safeParse(raw, fallback) {
    try { return JSON.parse(raw); } catch (_) { return fallback; }
  }

  function cleanId(v) {
    return String(v == null ? '' : v).trim().toLowerCase()
      .replace(/[^a-z0-9._-]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 96);
  }

  function stableId(prefix, text, index) {
    const base = cleanId(text) || (prefix + '-' + Date.now().toString(36));
    return prefix + '.' + base + (index != null ? '-' + index : '');
  }

  function normalizeParam(raw, index) {
    if (typeof raw === 'string') return { name: raw.trim() || ('valor' + (index + 1)), type: 'text', default: '' };
    const p = raw && typeof raw === 'object' ? raw : {};
    const name = String(p.name || ('valor' + (index + 1))).trim();
    const allowed = new Set(['text','string','number','bool','color','choice','sound','image','look','appearance','folder','scene','object','actor','file','url','code','data']);
    const type = allowed.has(String(p.type || 'text').toLowerCase()) ? String(p.type || 'text').toLowerCase() : 'text';
    return {
      name,
      type,
      default: p.default == null ? '' : p.default,
      placeholder: p.placeholder == null ? '' : String(p.placeholder),
      options: Array.isArray(p.options) ? p.options.map(String) : [],
      multiline: p.multiline === true
    };
  }

  function normalizeBlock(raw, pluginId, index) {
    if (!raw || typeof raw !== 'object') return null;
    const name = String(raw.name || raw.label || '').trim();
    if (!name) return null;
    const id = cleanId(raw.id) || stableId('block', name, index);
    const rawHeight = Number(raw.heightY == null ? raw.height : raw.heightY);
    const heightY = Number.isFinite(rawHeight) ? Math.max(32, rawHeight) : 56;
    const type = ['action','hat','loop','if','note'].includes(String(raw.type || 'action')) ? String(raw.type || 'action') : 'action';
    const params = Array.isArray(raw.params) ? raw.params.map(normalizeParam) : [];
    const code = raw.code && typeof raw.code === 'object' ? raw.code : {};
    const handlerLanguage = String(raw.handlerLanguage || raw.language || Object.keys(code)[0] || SUPPORTED_RUNTIME_LANGUAGE).toLowerCase();
    const handler = String(raw.handler || code[handlerLanguage] || code.javascript || code.python || code.lua || code.java || '').trim();
    return {
      id,
      name,
      categoryId: String(raw.categoryId || raw.category || '').trim(),
      family: String(raw.family || '').trim(),
      badge: String(raw.badge || '').trim(),
      color: /^#[0-9a-f]{6}$/i.test(String(raw.color || '')) ? String(raw.color) : '',
      useCategoryColor: raw.useCategoryColor !== false,
      heightY,
      multiline: raw.multiline === true,
      template: String(raw.template || '').trim(),
      example: raw.example == null ? '' : String(raw.example),
      params,
      type,
      canContainChildren: raw.canContainChildren === true || type === 'loop' || type === 'if',
      ifElse: raw.ifElse === true,
      canBeChild: raw.canBeChild !== false,
      allowedParent: Array.isArray(raw.allowedParent) ? raw.allowedParent.map(String) : ['script','control'],
      allowedChildren: Array.isArray(raw.allowedChildren) ? raw.allowedChildren.map(String) : [],
      handler,
      handlerLanguage,
      overrideOf: String(raw.overrideOf || '').trim(),
      presets: Array.isArray(raw.presets) ? raw.presets.map(x=>String(x||'').trim()).filter(Boolean).slice(0,64) : (typeof raw.presets === 'string' ? raw.presets.split(/[\n,]+/).map(x=>x.trim()).filter(Boolean).slice(0,64) : []),
      enabled: raw.enabled !== false,
      pluginId
    };
  }

  function normalizeCategory(raw, pluginId, index) {
    if (!raw || typeof raw !== 'object') return null;
    const name = String(raw.name || '').trim();
    if (!name) return null;
    const id = cleanId(raw.id) || stableId('category', name, index);
    return {
      id,
      name,
      color: /^#[0-9a-f]{6}$/i.test(String(raw.color || '')) ? String(raw.color) : '#64748B',
      body: /^#[0-9a-f]{6}$/i.test(String(raw.body || '')) ? String(raw.body) : '#CBD5E1',
      family: String(raw.family || '').trim(),
      badge: String(raw.badge || '').trim(),
      order: Number.isFinite(Number(raw.order)) ? Number(raw.order) : index,
      pluginId
    };
  }

  function normalizeUiRule(raw, index) {
    if (!raw || typeof raw !== 'object') return null;
    const selector = String(raw.selector || '').trim();
    if (!selector) return null;
    return {
      id: cleanId(raw.id) || stableId('ui', selector, index),
      selector,
      text: raw.text == null ? null : String(raw.text),
      cssText: raw.cssText == null ? '' : String(raw.cssText),
      visible: raw.visible == null ? null : !!raw.visible,
      title: raw.title == null ? null : String(raw.title),
      className: raw.className == null ? null : String(raw.className)
    };
  }

  function normalizeInsertRule(raw, index) {
    if (!raw || typeof raw !== 'object') return null;
    const selector = String(raw.selector || '').trim();
    const text = raw.text == null ? '' : String(raw.text);
    if (!selector || !text) return null;
    const position = ['beforebegin','afterbegin','beforeend','afterend'].includes(String(raw.position || 'beforeend'))
      ? String(raw.position || 'beforeend') : 'beforeend';
    const tag = ['div','span','p','button','label'].includes(String(raw.tag || 'div').toLowerCase())
      ? String(raw.tag || 'div').toLowerCase() : 'div';
    return {
      id: cleanId(raw.id) || stableId('insert', selector, index),
      selector,
      position,
      text,
      tag,
      className: String(raw.className || '').trim(),
      clickCode: String(raw.clickCode || '').trim()
    };
  }
  function normalizePlugin(raw, source) {
    if (!raw || typeof raw !== 'object') throw new Error('Manifesto de plugin inválido');
    if (raw.schema && raw.schema !== SCHEMA) throw new Error('Schema de plugin não suportado: ' + String(raw.schema));
    const name = String(raw.name || '').trim();
    if (!name) throw new Error('O plugin precisa de um nome');
    const id = cleanId(raw.id) || cleanId(name);
    if (!id) throw new Error('ID de plugin inválido');
    const version = String(raw.version || '1.0.0').trim();
    const requestedLanguage = String(raw.language || raw.runtime?.language || SUPPORTED_RUNTIME_LANGUAGE).toLowerCase();
    const language = LANGUAGE_LABELS[requestedLanguage] ? requestedLanguage : SUPPORTED_RUNTIME_LANGUAGE;
    const categories = Array.isArray(raw.categories) ? raw.categories.map((x,i)=>normalizeCategory(x,id,i)).filter(Boolean) : [];
    const blocks = Array.isArray(raw.blocks) ? raw.blocks.map((x,i)=>normalizeBlock(x,id,i)).filter(Boolean) : [];
    const ui = raw.ui && typeof raw.ui === 'object' ? raw.ui : {};
    const uiRules = Array.isArray(ui.rules) ? ui.rules.map(normalizeUiRule).filter(Boolean) : [];
    const inserts = Array.isArray(ui.inserts) ? ui.inserts.map(normalizeInsertRule).filter(Boolean) : [];
    const categoryOverrides = Array.isArray(raw.categoryOverrides) ? raw.categoryOverrides.map((x,i)=>{
      const id = String(x?.id || ('override-'+i));
      const def = normalizeCategory(Object.assign({},x,{id}),'__native__',i);
      if(def && /^native:/i.test(id)) def.id = id;
      return def;
    }).filter(Boolean) : [];
    const runtime = raw.runtime && typeof raw.runtime === 'object' ? raw.runtime : {};
    const runtimeCodes = {
      javascript: String(runtime.javascript || raw.javascript || '').trim(),
      python: String(runtime.python || raw.python || '').trim(),
      lua: String(runtime.lua || raw.lua || '').trim(),
      java: String(runtime.java || raw.java || '').trim()
    };
    const capabilities = Array.isArray(raw.capabilities) ? raw.capabilities.map(String).slice(0, 64) : [];
    const sourceKey = source ? String(source) : 'local';
    // Built-ins are trusted only when this runtime creates/restores them from the
    // reserved internal source. An imported manifest cannot self-assign protection.
    const builtin = raw.builtin === true && sourceKey === 'builtin';
    const protectedPlugin = builtin && raw.protected === true;
    const compatibility = raw.compatibility && typeof raw.compatibility === 'object' ? {
      role: String(raw.compatibility.role || '').trim(),
      formats: Array.isArray(raw.compatibility.formats) ? raw.compatibility.formats.map(String).filter(Boolean).slice(0,16) : []
    } : { role:'', formats:[] };
    const normalized = {
      schema: SCHEMA,
      id,
      name,
      version,
      author: String(raw.author || '').trim(),
      description: String(raw.description || '').trim(),
      icon: typeof raw.icon === 'string' ? raw.icon.trim() : '',
      iconImage: typeof raw.iconImage === 'string' ? raw.iconImage.trim() : '',
      language,
      enabled: raw.enabled !== false || protectedPlugin,
      builtin,
      protected: protectedPlugin,
      compatibility,
      createdAt: Number(raw.createdAt) || Date.now(),
      updatedAt: Date.now(),
      categories,
      blocks,
      categoryOverrides,
      ui: { rules: uiRules, inserts },
      runtime: runtimeCodes,
      capabilities,
      source: sourceKey
    };
    const knownIds = new Set();
    normalized.blocks.forEach(b => {
      if (knownIds.has(b.id)) throw new Error('ID de bloco duplicado: ' + b.id);
      knownIds.add(b.id);
    });
    const cats = new Set(normalized.categories.map(c=>c.id));
    normalized.blocks.forEach(b => {
      if (b.categoryId && !cats.has(b.categoryId) && !String(b.categoryId).startsWith('native:')) {
        throw new Error('Categoria não encontrada para o bloco "' + b.name + '"');
      }
      // The declaration remains enabled for every language. Actual execution is
      // gated by the registered language runtime adapter in executeBlock().
      b.enabledRuntime = b.enabled;
    });
    return normalized;
  }

  const KIX_BUILTIN_CATROID_PLUGIN = Object.freeze({
    schema: SCHEMA,
    id: 'kix.catroid.compat',
    name: 'Catroid Compatibility',
    version: '1.1.0',
    description: 'Ponte de compatibilidade Catroid/Catrobat/NewCatroid do Kix. Usa o catálogo nativo já existente e o interpretador Catrobat do Kix, sem duplicar blocos.',
    language: 'javascript',
    enabled: true,
    categories: [],
    blocks: [],
    categoryOverrides: [],
    ui: {rules: [], inserts: []},
    runtime: {
      javascript: "runtime.globals = runtime.globals || {}; runtime.globals.__kix_catroid_compat_v1_1 = {pluginId:api.plugin.id, version:api.plugin.version, enabled:true};"
    },
    capabilities: ['catrobat-import','newtrobat-import','pocket-code-import','catroid-yourbricks','user-defined-receivers','user-defined-input-preservation','nested-control-preservation','source-metadata-preservation','project-compatibility'],
    compatibility: { role:'project-bridge', formats:['catrobat','newtrobat'] },
    builtin: true,
    protected: true
  });

  function ensureBuiltinPlugins() {
    const raw = clone(KIX_BUILTIN_CATROID_PLUGIN);
    let canonical;
    try { canonical = normalizePlugin(raw, 'builtin'); } catch (e) {
      console.error('Kix built-in Catroid plugin inválido', e);
      return false;
    }
    const idx = state.plugins.findIndex(p => String(p.id) === canonical.id);
    let changed = false;
    if (idx < 0) {
      state.plugins.push(canonical);
      changed = true;
    } else {
      const current = state.plugins[idx];
      const sameCore = current && current.builtin === true && current.protected === true && String(current.version) === canonical.version;
      if (!sameCore) {
        canonical.createdAt = Number(current?.createdAt) || canonical.createdAt;
        state.plugins.splice(idx, 1, canonical);
        changed = true;
      }
    }
    const active = state.plugins.find(p => String(p.id) === canonical.id);
    if (active && active.enabled === false) { active.enabled = true; active.updatedAt = Date.now(); changed = true; }
    if (!state.currentPluginId) state.currentPluginId = canonical.id;
    return changed;
  }

  function pluginKey(id) { return 'plugin:' + cleanId(id); }

  function saveMirror() {
    try { localStorage.setItem(STORE, JSON.stringify(state.plugins)); } catch (e) { console.warn('Kix plugin local mirror', e); }
  }

  function openDb() {
    return new Promise((resolve,reject)=>{
      if (!global.indexedDB) return resolve(null);
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('state')) db.createObjectStore('state');
      };
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(req.result);
    });
  }

  async function savePersistent() {
    saveMirror();
    try {
      const db = await openDb();
      if (!db) return false;
      await new Promise((resolve,reject)=>{
        const tx = db.transaction('state','readwrite');
        tx.objectStore('state').put(clone(state.plugins), STORE);
        tx.oncomplete = resolve;
        tx.onerror = () => reject(tx.error);
      });
      try { db.close(); } catch (_) {}
      return true;
    } catch (e) {
      console.warn('Kix plugin IDB persistence', e);
      return false;
    }
  }

  async function restorePersistent() {
    const fromMirror = safeParse(localStorage.getItem(STORE) || '[]', []);
    if (Array.isArray(fromMirror)) {
      state.plugins = fromMirror.map((x)=>{
        try { return normalizePlugin(x, x?.source || 'local'); } catch (_) { return null; }
      }).filter(Boolean);
    }
    try {
      const db = await openDb();
      if (db) {
        const stored = await new Promise((resolve,reject)=>{
          const tx=db.transaction('state','readonly');
          const req=tx.objectStore('state').get(STORE);
          req.onsuccess=()=>resolve(req.result);
          req.onerror=()=>reject(req.error);
        });
        try { db.close(); } catch (_) {}
        if (Array.isArray(stored)) {
          state.plugins = stored.map(x=>{
            try{return normalizePlugin(x,x?.source||'local')}catch(_){return null;}
          }).filter(Boolean);
          saveMirror();
        }
      }
    } catch (e) { console.warn('Kix plugin restore', e); }
    const builtinChanged = ensureBuiltinPlugins();
    if (builtinChanged) await savePersistent();
    refreshAttachedCategories();
    renderPluginScreens();
  }

  function getPlugin(id) { return state.plugins.find(p=>String(p.id)===String(id)) || null; }

  function listEnabled() { return state.plugins.filter(p=>p.enabled !== false); }

  function refreshAttachedCategories() {
    const app = state.app;
    if (!app || !app.CATEGORIES) return;
    // Remove previously injected plugin categories.
    Object.keys(app.CATEGORIES).forEach(key => {
      if (String(key).startsWith('plugin:')) delete app.CATEGORIES[key];
    });
    // Restore native category presentation before applying current overrides.
    Object.values(app.CATEGORIES).forEach(cat => {
      if (cat && cat._kixPluginOriginal) {
        const o=cat._kixPluginOriginal;
        cat.name=o.name; cat.color=o.color; cat.body=o.body;
        delete cat._kixPluginOriginal;
      }
      if (cat && cat._kixPluginOriginalBlocks) {
        cat.blocks = cat._kixPluginOriginalBlocks.slice();
        delete cat._kixPluginOriginalBlocks;
      }
    });
    listEnabled().forEach(plugin => {
      (plugin.categoryOverrides || []).forEach(override => {
        const key = String(override.id || '').replace(/^override-/,'');
        // Native override ids are stored as native:<key> to avoid collision with
        // plugin category ids. Older files may omit the prefix.
        const nativeKey = key.replace(/^native:/,'').replace(/^native-/,'');
        const cat = app.CATEGORIES[nativeKey];
        if (!cat || !cat.name) return;
        if (!cat._kixPluginOriginal) cat._kixPluginOriginal = {name:cat.name,color:cat.color,body:cat.body};
        if (override.name) cat.name=override.name;
        if (override.color) cat.color=override.color;
        if (override.body) cat.body=override.body;
      });
      plugin.blocks.forEach(blockDef=>{
        if(!blockDef || blockDef.enabled===false) return;
        const rawCategory=String(blockDef.categoryId||'');
        if(!rawCategory.startsWith('native:')) return;
        const nativeKey=rawCategory.slice(7);
        const cat=app.CATEGORIES[nativeKey];
        if(!cat || !Array.isArray(cat.blocks)) return;
        if(!cat._kixPluginOriginalBlocks) cat._kixPluginOriginalBlocks=cat.blocks.slice();
        cat.blocks.push(blockDef);
      });
      plugin.categories.forEach(catDef => {
        const key = 'plugin:' + plugin.id + ':' + catDef.id;
        app.CATEGORIES[key] = {
          name: catDef.name,
          color: catDef.color,
          body: catDef.body,
          blocks: plugin.blocks.filter(b=>b.categoryId===catDef.id && b.enabled !== false),
          isPlugin: true,
          pluginId: plugin.id,
          pluginCategoryId: catDef.id,
          pluginBadge: catDef.badge || 'Plugin',
          pluginName: plugin.name,
          family: catDef.family || '',
          order: catDef.order
        };
      });
      executeGlobalRuntime(plugin);
    });
    applyUiRules();
  }

  function findBlockById(id) {
    const raw = String(id || '');
    for (const p of listEnabled()) {
      const b = p.blocks.find(x=>x.id===raw);
      if (b) return b;
    }
    return null;
  }

  function findBlock(pluginId, blockId) {
    const p=getPlugin(pluginId);
    if (!p) return null;
    return p.blocks.find(b=>String(b.id)===String(blockId)) || null;
  }

  function findBlockByName(name) {
    const n=String(name||'').trim();
    if (!n) return null;
    for (const p of listEnabled()) {
      const override=p.blocks.find(b=>b.enabled && b.overrideOf && b.overrideOf===n);
      if (override) return override;
    }
    for (const p of listEnabled()) {
      const b=p.blocks.find(b=>b.enabled && b.name===n);
      if (b) return b;
    }
    return null;
  }

  function getPresentation(name, base, persistedBlock) {
    const p=(persistedBlock?.pluginId && persistedBlock?.pluginBlockId) ? findBlock(persistedBlock.pluginId,persistedBlock.pluginBlockId) : findBlockByName(name);
    if (!p) return base || null;
    return Object.assign({}, base || {}, {
      pluginId:p.pluginId,
      pluginBlockId:p.id,
      color: p.useCategoryColor ? (getCategoryPresentation(p.pluginId,p.categoryId)?.color || p.color || base?.color) : (p.color || base?.color),
      heightY:p.heightY,
      multiline:p.multiline,
      template:p.template,
      example:p.example,
      badge:p.badge,
      family:p.family,
      params:p.params
    });
  }

  function categoryPresentation(pluginId, categoryId) {
    return getCategoryPresentation(pluginId, categoryId);
  }

  function getCategoryPresentation(pluginId, categoryId) {
    const p=getPlugin(pluginId); const c=p?.categories?.find(x=>x.id===categoryId);
    return c || null;
  }

  function resolvePluginBlockForPersisted(block) {
    if (!block) return null;
    if (block.pluginId && block.pluginBlockId) return findBlock(block.pluginId,block.pluginBlockId);
    return findBlockByName(block.name);
  }

  function collectParams(blockDef, block, ctx) {
    const out={};
    const values=block?.values || {};
    (blockDef?.params || []).forEach(p=>{
      const v=values[p.name] !== undefined ? values[p.name] : p.default;
      out[p.name]=v;
    });
    return out;
  }

  function makeApi(plugin, co, blk, ctx) {
    const actor=co?.actor;
    const runtime=global.KixEngine?.runtime || {};
    const api = {
      plugin: { id: plugin.id, name: plugin.name, version: plugin.version },
      block: { id: blk?.id || '', name: blk?.name || '', params: clone(collectParams(findBlock(plugin.id,blk?.pluginBlockId||''),blk,ctx)) },
      actor: {
        get data(){ return actor?.data || {}; },
        getId(){ return String(actor?.data?.kixId || actor?.data?.id || actor?.id || ''); },
        getName(){ return actor ? String(actor.name || '') : ''; },
        setName(name){ if(!actor)return false; actor.name=String(name||'').trim() || actor.name; try { state.app?.save?.(); } catch (_) {} return true; },
        isVisible(){ return actor?.data?.visible !== false; },
        setVisible(v){ if (actor) actor.data.visible = !!v; },
        getPosition(){ return {x:Number(actor?.data?.x)||0,y:Number(actor?.data?.y)||0}; },
        setPosition(x,y){ try { global.KixEngine?.actorPositionSet?.(actor, Number(x)||0, Number(y)||0); } catch (_) { if(actor){actor.data.x=Number(x)||0;actor.data.y=Number(y)||0;} } },
        move(dx,dy){ try { global.KixEngine?.actorPositionMove?.(actor, Number(dx)||0, Number(dy)||0); } catch (_) { if(actor){actor.data.x=(Number(actor.data.x)||0)+(Number(dx)||0);actor.data.y=(Number(actor.data.y)||0)+(Number(dy)||0);} } },
        getSize(){ return Number(actor?.data?.size)||0; },
        setSize(v){ if(actor) actor.data.size=Number(v)||0; },
        getDirection(){ return Number(actor?.data?.direction)||0; },
        setDirection(v){ if(actor){actor.data.direction=Number(v)||0; try{actor._lastKey=null;}catch(_){} } },
        getVelocity(){ return {x:Number(actor?.data?.vx)||0,y:Number(actor?.data?.vy)||0}; },
        setVelocity(x,y){ if(actor){actor.data.vx=Number(x)||0;actor.data.vy=Number(y)||0;try{actor._lastKey=null;}catch(_){} } },
        isMoving(){ return Math.abs(Number(actor?.data?.vx)||0)>0 || Math.abs(Number(actor?.data?.vy)||0)>0; },
        setVariable(name,value){ if(!actor)return; actor.data._vars=actor.data._vars||{}; actor.data._vars[String(name)]=value; },
        getVariable(name,fallback){ return actor?.data?._vars?.[String(name)] ?? fallback; }
      },
      physics: {
        getGravity(){ return Number(runtime.gravity)||0; },
        setGravity(value){ const g=Number(value); runtime.gravity=Number.isFinite(g)?g:0; (runtime.actors||[]).forEach(a=>{ if(a?.data) a.data.gravity=runtime.gravity; }); return runtime.gravity; },
        getMass(){ return Number(actor?.data?.mass)||1; },
        setMass(value){ if(!actor)return false; actor.data.mass=Math.max(0.001,Number(value)||1); return actor.data.mass; },
        getFriction(){ return Number(actor?.data?.friction)||0; },
        setFriction(value){ if(!actor)return false; actor.data.friction=Math.max(0,Number(value)||0); return actor.data.friction; },
        pauseActor(value=true){ if(!actor)return false; actor.data.physicsPaused=!!value; return actor.data.physicsPaused; },
        setCollisionMode(mode){ if(!actor)return false; const allowed=new Set(['none','parar','solid','platform','collect','damage','push','sensor','projectile','teleport']); const m=String(mode||'none').trim().toLowerCase(); actor.data.collisionResponse=allowed.has(m)?m:'none'; return actor.data.collisionResponse; },
        getCollisionMode(){ return String(actor?.data?.collisionResponse||'none'); },
        overlaps(target){ const needle=String(target||'').trim().toLowerCase(); if(!actor||!needle)return false; const other=(runtime.actors||[]).find(a=>a!==actor && (String(a?.data?.kixId||a?.id||'').toLowerCase()===needle || String(a?.data?.name||'').toLowerCase()===needle)); if(!other || typeof global.KixEngine?.checkCollision!=='function')return false; return !!global.KixEngine.checkCollision(actor,other); }
      },
      project: {
        getName(){ return state.app?.getCurrentProject?.()?.name != null ? String(state.app.getCurrentProject().name) : ''; },
        setName(name){ const pr=state.app?.getCurrentProject?.(); if(!pr)return false; pr.name=String(name||'').trim() || pr.name; try{state.app?.save?.();}catch(_){} return true; },
        getDescription(){ const pr=state.app?.getCurrentProject?.(); return pr?.description == null ? '' : String(pr.description); },
        setDescription(text){ const pr=state.app?.getCurrentProject?.(); if(!pr)return false; pr.description=String(text==null?'':text); try{state.app?.save?.();}catch(_){} return true; },
        getScenes(){ const pr=state.app?.getCurrentProject?.(); return clone(pr?.scenes || []); },
        getFiles(){ const pr=state.app?.getCurrentProject?.(); return clone(pr?.files || []); },
        save(){ try{ state.app?.save?.(); return true; }catch(_){ return false; } }
      },
      scene: {
        getIndex(){ return Number(state.app?.getCurrentScene?.()||0)||0; },
        getName(){ const pr=state.app?.getCurrentProject?.(); const sc=pr?.scenes?.[Number(state.app?.getCurrentScene?.()||0)||0]; return sc?.name == null ? '' : String(sc.name); },
        setName(name){ const pr=state.app?.getCurrentProject?.(); const i=Number(state.app?.getCurrentScene?.()||0)||0; const sc=pr?.scenes?.[i]; if(!sc)return false; sc.name=String(name||'').trim() || sc.name; try{state.app?.save?.();}catch(_){} return true; },
        switchTo(target,options){ try{ if(typeof global.KixChangeScene!=='function') return false; global.KixChangeScene(target, options||{fade:0.05}); return true; }catch(_){ return false; } },
        restart(options){ try{ if(typeof global.KixChangeScene!=='function') return false; global.KixChangeScene('restart', Object.assign({fade:0.05}, options||{})); return true; }catch(_){ return false; } },
        getObjects(){ const pr=state.app?.getCurrentProject?.(); const i=Number(state.app?.getCurrentScene?.()||0)||0; return clone(pr?.scenes?.[i]?.actors || []); },
        getTilemaps(){ const pr=state.app?.getCurrentProject?.(); const i=Number(state.app?.getCurrentScene?.()||0)||0; return clone(pr?.scenes?.[i]?.tilemaps || []); },
        getParticleEmitters(){ const pr=state.app?.getCurrentProject?.(); const i=Number(state.app?.getCurrentScene?.()||0)||0; return clone(pr?.scenes?.[i]?.particleEmitters || []); }
      },
      actors: {
        list(){ const pr=state.app?.getCurrentProject?.(); const i=Number(state.app?.getCurrentScene?.()||0)||0; const actors=pr?.scenes?.[i]?.actors; return Array.isArray(actors) ? actors.map(a=>({id:String(a?.kixId||a?.id||''),name:String(a?.name||''),visible:a?.data?.visible!==false && a?.visible!==false,position:{x:Number(a?.x??a?.data?.x)||0,y:Number(a?.y??a?.data?.y)||0},size:Number(a?.size??a?.data?.size)||0,direction:Number(a?.direction??a?.data?.direction)||0})) : []; },
        count(){ const pr=state.app?.getCurrentProject?.(); const i=Number(state.app?.getCurrentScene?.()||0)||0; return Array.isArray(pr?.scenes?.[i]?.actors) ? pr.scenes[i].actors.length : 0; },
        get(index){ const pr=state.app?.getCurrentProject?.(); const i=Number(state.app?.getCurrentScene?.()||0)||0; const a=(pr?.scenes?.[i]?.actors||[])[Number(index)]; return a ? {id:String(a?.kixId||a?.id||''),name:String(a?.name||''),visible:a?.data?.visible!==false && a?.visible!==false,position:{x:Number(a?.x??a?.data?.x)||0,y:Number(a?.y??a?.data?.y)||0},size:Number(a?.size??a?.data?.size)||0,direction:Number(a?.direction??a?.data?.direction)||0} : null; },
        find(name){ const needle=String(name||'').trim().toLowerCase(); const pr=state.app?.getCurrentProject?.(); const i=Number(state.app?.getCurrentScene?.()||0)||0; const a=(pr?.scenes?.[i]?.actors||[]).find(x=>String(x?.name||'').toLowerCase()===needle); return a ? {id:String(a?.kixId||a?.id||''),name:String(a?.name||''),position:{x:Number(a?.x??a?.data?.x)||0,y:Number(a?.y??a?.data?.y)||0}} : null; },
        findById(id){ const needle=String(id||''); const pr=state.app?.getCurrentProject?.(); const i=Number(state.app?.getCurrentScene?.()||0)||0; const a=(pr?.scenes?.[i]?.actors||[]).find(x=>String(x?.kixId||x?.id||'')===needle); return a ? {id:String(a?.kixId||a?.id||''),name:String(a?.name||''),visible:a?.visible!==false} : null; }
      },
      globals: {
        get(name,fallback){ return runtime.globals?.[String(name)] ?? fallback; },
        set(name,value){ runtime.globals=runtime.globals||{}; runtime.globals[String(name)]=value; return value; }
      },
      params: {
        get(name,fallback){ const v=collectParams(findBlock(plugin.id,blk?.pluginBlockId||''),blk,ctx)[String(name)]; return v === undefined ? fallback : v; },
        all(){ return clone(collectParams(findBlock(plugin.id,blk?.pluginBlockId||''),blk,ctx)); }
      },
      ui: {
        toast(msg){ try { global.toast?.(String(msg)); } catch (_) {} },
        setText(selector,text){ const el=document.querySelector(String(selector||'')); if(el) el.textContent=String(text); return !!el; },
        setVisible(selector,visible){ const el=document.querySelector(String(selector||'')); if(!el)return false; el.classList.toggle('hidden',!visible); el.style.display=visible?'':'none'; return true; },
        setStyle(selector,cssText){ const el=document.querySelector(String(selector||'')); if(!el)return false; el.style.cssText += ';'+String(cssText||''); return true; },
        addText(selector,position,text,className){ const host=document.querySelector(String(selector||'')); if(!host)return false; const el=document.createElement('div'); el.textContent=String(text||''); if(className)el.className=String(className); host.insertAdjacentElement(position||'beforeend',el); return true; }
      },
      storage: {
        key(k){return pluginKey(plugin.id)+':'+String(k||'');},
        get(k,fallback){try{const raw=localStorage.getItem(this.key(k));return raw==null?fallback:JSON.parse(raw);}catch(_){return fallback;}},
        set(k,v){localStorage.setItem(this.key(k),JSON.stringify(v));return v;},
        remove(k){localStorage.removeItem(this.key(k));},
        clear(){try{const prefix=pluginKey(plugin.id)+':'; const keys=[]; for(let i=0;i<localStorage.length;i++){const key=localStorage.key(i);if(key&&key.indexOf(prefix)===0)keys.push(key);} keys.forEach(k=>localStorage.removeItem(k)); return true;}catch(_){return false;}},
        has(k){ try{return localStorage.getItem(this.key(k))!==null;}catch(_){return false;} },
        keys(){ try{const prefix=pluginKey(plugin.id)+':'; const out=[]; for(let i=0;i<localStorage.length;i++){const key=localStorage.key(i); if(key&&key.indexOf(prefix)===0)out.push(key.slice(prefix.length));} return out;}catch(_){return [];} }
      },
      notify(msg){ try { global.toast?.(String(msg)); } catch (_) {} },
      audio: {
        play(src){
          try {
            const a=new Audio(String(src));
            runtime.sounds=Array.isArray(runtime.sounds)?runtime.sounds:[];
            runtime.sounds.push(a);
            const remove=()=>{const i=runtime.sounds.indexOf(a);if(i>=0)runtime.sounds.splice(i,1);};
            a.addEventListener('ended',remove,{once:true});
            a.addEventListener('error',remove,{once:true});
            const p=a.play(); if(p&&typeof p.catch==='function')p.catch(()=>{});
            return a;
          } catch(_){return null;}
        },
        stopAll(){ const sounds=Array.isArray(runtime.sounds)?runtime.sounds.slice():[]; sounds.forEach(a=>{try{a.pause();a.currentTime=0;}catch(_){} }); runtime.sounds=[]; try{if(global.speechSynthesis)global.speechSynthesis.cancel();}catch(_){} return true; }
      },
      crypto: global.crypto || null,
      // Advanced host access is intentionally not sandboxed in this build.
      // Plugin handlers run as local JavaScript in the same WebView realm.
      raw: global,
      host: {
        window: global,
        document: global.document || null,
        navigator: global.navigator || null,
        location: global.location || null,
        localStorage: global.localStorage || null,
        sessionStorage: global.sessionStorage || null,
        indexedDB: global.indexedDB || null,
        crypto: global.crypto || null,
        fetch: typeof global.fetch === 'function' ? global.fetch.bind(global) : null,
        Android: global.Android || null,
        KixEngine: global.KixEngine || null,
        KixPluginRuntime: global.KixPluginRuntime || null
      },
      app: state.app || null,
      engine: global.KixEngine || null,
      fetch(url,options){
        if(!global.fetch) throw new Error('Fetch não está disponível nesta build');
        return global.fetch(url,options);
      },
      now(){ return Date.now(); },
      wait(ms){ return new Promise(resolve=>setTimeout(resolve,Math.max(0,Number(ms)||0))); },
      json(value){ try{return JSON.stringify(value);}catch(_){return '';} },
      parse(value,fallback){ try{return JSON.parse(value);}catch(_){return fallback;} },
      runtime: {
        get(name,fallback){ const rt=global.KixEngine?.runtime || {}; const key=String(name||''); const value=rt[key]; if(value === undefined) return fallback; if(value === null || typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') return value; try{return clone(value);}catch(_){return fallback;} },
        getMany(names){ const out={}; (Array.isArray(names)?names:[]).forEach(name=>{const key=String(name||''); if(!key)return; out[key]=runtime[key];}); return clone(out); },
        isRunning(){ return !!global.KixEngine?.runtime?.running; },
        isPaused(){ return !!global.KixEngine?.runtime?.paused; },
        has(name){ const rt=global.KixEngine?.runtime || {}; return Object.prototype.hasOwnProperty.call(rt,String(name||'')); },
        set(name,value){ const rt=global.KixEngine?.runtime; if(!rt)return false; const key=String(name||''); if(!key)return false; rt[key]=value; return value; },
        setMany(values){ const rt=global.KixEngine?.runtime; if(!rt || !values || typeof values!=='object')return false; Object.keys(values).forEach(k=>{rt[k]=values[k];}); return true; }
      },
      stage: {
        getSize(){ const rt=global.KixEngine?.runtime || {}; return {width:Number(rt._logicalStageW || 0)||0,height:Number(rt._logicalStageH || 0)||0}; },
        getBounds(){ const stage=global.KixEngine?.runtime?.stageEl || document.getElementById('play-stage'); if(!stage?.getBoundingClientRect)return null; const r=stage.getBoundingClientRect(); return {left:Number(r.left)||0,top:Number(r.top)||0,width:Number(r.width)||0,height:Number(r.height)||0,right:Number(r.right)||((Number(r.left)||0)+(Number(r.width)||0)),bottom:Number(r.bottom)||((Number(r.top)||0)+(Number(r.height)||0))}; },
        getPointer(){ const t=global.KixEngine?.runtime?.touch || {}; const rawIndex=Number(t.targetActorIndex); return {x:Number(t.x)||0,y:Number(t.y)||0,down:!!t.down,active:!!t.active,targetActorId:t.targetActorId||null,targetActorIndex:Number.isFinite(rawIndex)?rawIndex:-1}; },
        screenToWorld(clientX,clientY){ try{return clone(global.KixEngine?.stagePointToWorld?.(Number(clientX),Number(clientY)) || {x:0,y:0});}catch(_){return {x:0,y:0};} },
        isRunning(){ return !!global.KixEngine?.runtime?.running; },
        getMode(){ return String(global.KixEngine?.runtime?.mode || 'idle'); }
      },
      camera: {
        getPosition(){ const rt=global.KixEngine?.runtime || {}; return {x:Number(rt.cameraWorldX != null ? rt.cameraWorldX : -Number(rt.camX)||0)||0,y:Number(rt.cameraWorldY != null ? rt.cameraWorldY : Number(rt.camY)||0)||0}; },
        setPosition(x,y){ const rt=global.KixEngine?.runtime; if(!rt)return false; rt._camFollow=null; rt._camFollowTouch=false; rt.camX=-(Number(x)||0); rt.camY=Number(y)||0; try{global.KixEngine?.applyEngineCamera?.();}catch(_){} return true; },
        getZoom(){ return Number(global.KixEngine?.runtime?.camZoom)||1; },
        setZoom(z){ const rt=global.KixEngine?.runtime; if(!rt)return false; const lo=Math.max(0.01,Number(rt.camZoomMin)||0.25),hi=Math.max(lo,Number(rt.camZoomMax)||4); rt.camZoom=Math.max(lo,Math.min(hi,Number(z)||1)); try{global.KixEngine?.applyEngineCamera?.();}catch(_){} return true; },
        getRotation(){ return Number(global.KixEngine?.runtime?.camRot)||0; },
        setRotation(degrees){ const rt=global.KixEngine?.runtime; if(!rt)return false; rt.camRot=Number(degrees)||0; try{global.KixEngine?.applyEngineCamera?.();}catch(_){} return true; },
        reset(){ const rt=global.KixEngine?.runtime; if(!rt)return false; rt.camX=0;rt.camY=0;rt.camZoom=1;rt.camRot=0;rt._camFollow=null;rt._camFollowTouch=false;try{global.KixEngine?.applyEngineCamera?.();}catch(_){} return true; },
        follow(target){ const rt=global.KixEngine?.runtime; if(!rt)return false; const needle=String(target||'').trim().toLowerCase(); const actor=(rt.actors||[]).find(ra=>String(ra?.data?.kixId||ra?.data?.id||ra?.id||'').toLowerCase()===needle || String(ra?.data?.name||'').toLowerCase()===needle); if(!actor)return false; rt._camFollow=actor;rt._camFollowTouch=false;return true; },
        stopFollow(){ const rt=global.KixEngine?.runtime; if(!rt)return false; rt._camFollow=null;rt._camFollowTouch=false;return true; },
        getSmoothing(){ const v=Number(global.KixEngine?.runtime?.camSmooth); return Number.isFinite(v)?v:1; },
        setSmoothing(value){ const rt=global.KixEngine?.runtime; if(!rt)return false; const v=Number(value); rt.camSmooth=Number.isFinite(v)?Math.max(0.01,Math.min(1,v)):1; try{global.KixEngine?.applyEngineCamera?.();}catch(_){} return rt.camSmooth; },
        getDeadZone(){ const rt=global.KixEngine?.runtime||{}; return {width:Number(rt.camDeadW)||0,height:Number(rt.camDeadH)||0}; },
        setDeadZone(width,height){ const rt=global.KixEngine?.runtime; if(!rt)return false; rt.camDeadW=Math.max(0,Number(width)||0); rt.camDeadH=Math.max(0,Number(height)||0); try{global.KixEngine?.applyEngineCamera?.();}catch(_){} return {width:rt.camDeadW,height:rt.camDeadH}; },
        getLookAhead(){ return Number(global.KixEngine?.runtime?.camLookAhead)||0; },
        setLookAhead(value){ const rt=global.KixEngine?.runtime; if(!rt)return false; rt.camLookAhead=Number(value)||0; try{global.KixEngine?.applyEngineCamera?.();}catch(_){} return rt.camLookAhead; },
        getAxisLock(){ return String(global.KixEngine?.runtime?.camAxisLock||''); },
        setAxisLock(axis){ const rt=global.KixEngine?.runtime; if(!rt)return false; const a=String(axis||'').toLowerCase(); rt.camAxisLock=(a==='x'||a==='y')?a:''; try{global.KixEngine?.applyEngineCamera?.();}catch(_){} return rt.camAxisLock; },
        getOffset(){ const rt=global.KixEngine?.runtime||{}; return {x:Number(rt.camOffsetX)||0,y:Number(rt.camOffsetY)||0}; },
        setOffset(x,y){ const rt=global.KixEngine?.runtime; if(!rt)return false; rt.camOffsetX=Number(x)||0; rt.camOffsetY=Number(y)||0; try{global.KixEngine?.applyEngineCamera?.();}catch(_){} return {x:rt.camOffsetX,y:rt.camOffsetY}; }
      },
      clipboard: {
        async readText(){ try{ return typeof navigator?.clipboard?.readText==='function' ? await navigator.clipboard.readText() : null; }catch(_){return null;} },
        async writeText(text){ try{ if(typeof navigator?.clipboard?.writeText!=='function')return false; await navigator.clipboard.writeText(String(text??'')); return true; }catch(_){return false;} }
      },
      input: {
        getPointer(){ const t=global.KixEngine?.runtime?.touch || {}; const rawIndex=Number(t.targetActorIndex); return {x:Number(t.x)||0,y:Number(t.y)||0,down:!!t.down,active:!!t.active,targetActorId:t.targetActorId||null,targetActorIndex:Number.isFinite(rawIndex)?rawIndex:-1}; },
        isDown(){ return !!global.KixEngine?.runtime?.touch?.down; },
        getTargetActor(){ const t=global.KixEngine?.runtime?.touch || {}; const actors=global.KixEngine?.runtime?.actors || []; const i=Number(t.targetActorIndex); if(i>=0&&actors[i])return {id:String(actors[i]?.data?.kixId||actors[i]?.id||''),name:String(actors[i]?.data?.name||'')}; return null; }
      },
      device: {
        getViewport(){ return {width:Number(global.innerWidth)||0,height:Number(global.innerHeight)||0,devicePixelRatio:Number(global.devicePixelRatio)||1}; },
        getLanguage(){ return String(global.navigator?.language || ''); },
        isOnline(){ return global.navigator?.onLine !== false; },
        canVibrate(){ return typeof global.navigator?.vibrate === 'function'; },
        vibrate(ms){ try { return typeof global.navigator?.vibrate === 'function' ? !!global.navigator.vibrate(Math.max(0,Number(ms)||0)) : false; } catch(_) { return false; } },
        hasTouch(){ return ('ontouchstart' in global) || Number(global.navigator?.maxTouchPoints||0)>0; },
        getPlatform(){ return String(global.navigator?.userAgent || ''); },
        getScreenSize(){ return {width:Number(global.screen?.width)||0,height:Number(global.screen?.height)||0}; }
      },
      tilemap: {
        list(){ const pr=state.app?.getCurrentProject?.(); const i=Number(state.app?.getCurrentScene?.()||0)||0; return clone(pr?.scenes?.[i]?.tilemaps || []); },
        get(id){ const pr=state.app?.getCurrentProject?.(); const i=Number(state.app?.getCurrentScene?.()||0)||0; const tm=(pr?.scenes?.[i]?.tilemaps||[]).find(x=>String(x?.id||'')===String(id||'')); return tm ? clone(tm) : null; },
        getCell(tilemapId,x,y,layerId){ const tm=this.get(tilemapId); if(!tm)return null; const layer=(tm.layers||[]).find(l=>!layerId || String(l?.id||'')===String(layerId)); if(!layer)return null; return layer.cells?.[Math.floor(Number(x)||0)+','+Math.floor(Number(y)||0)] ?? null; }
      },
      particles: {
        list(){ const pr=state.app?.getCurrentProject?.(); const i=Number(state.app?.getCurrentScene?.()||0)||0; return clone(pr?.scenes?.[i]?.particleEmitters || []); },
        get(id){ const arr=this.list(); return arr.find(x=>String(x?.id||'')===String(id||'')) || null; },
        isRunning(id){ const rt=global.KixEngine?.runtime || {}; const em=(rt.sceneEmitters||[]).find(x=>String(x?.id||'')===String(id||'')); return !!em?.active; }
      },
      math: {
        clamp(v,min,max){ const n=Number(v); const lo=Number(min); const hi=Number(max); if(!Number.isFinite(n)) return Number.isFinite(lo)?lo:0; if(!Number.isFinite(lo)||!Number.isFinite(hi)) return n; return Math.min(Math.max(n,Math.min(lo,hi)),Math.max(lo,hi)); },
        lerp(a,b,t){ const x=Number(a)||0, y=Number(b)||0, u=Number(t)||0; return x+(y-x)*u; },
        random(min=0,max=1){ const a=Number(min)||0,b=Number(max); const hi=Number.isFinite(b)?b:1; return a+Math.random()*(hi-a); },
        round(v){return Math.round(Number(v)||0);}, floor(v){return Math.floor(Number(v)||0);}, ceil(v){return Math.ceil(Number(v)||0);}, abs(v){return Math.abs(Number(v)||0);}, min(...v){return Math.min(...v.map(Number));}, max(...v){return Math.max(...v.map(Number));},
        distance(x1,y1,x2,y2){return Math.hypot((Number(x2)||0)-(Number(x1)||0),(Number(y2)||0)-(Number(y1)||0));},
        angle(x1,y1,x2,y2){return Math.atan2((Number(y2)||0)-(Number(y1)||0),(Number(x2)||0)-(Number(x1)||0))*180/Math.PI;},
        degToRad(v){return (Number(v)||0)*Math.PI/180;}, radToDeg(v){return (Number(v)||0)*180/Math.PI;},
        map(v,inMin,inMax,outMin,outMax){ const a=Number(inMin)||0,b=Number(inMax)||0,c=Number(outMin)||0,d=Number(outMax)||0; const u=b===a?0:(Number(v)-a)/(b-a); return c+(d-c)*u; },
        randomInt(min=0,max=1){ const a=Math.ceil(Number(min)||0),b=Math.floor(Number(max)); const hi=Number.isFinite(b)?b:a; return Math.floor(Math.random()*(hi-a+1))+a; },
        sign(v){ const n=Number(v)||0; return n<0?-1:n>0?1:0; },
        sin(v){ return Math.sin(Number(v)||0); },
        cos(v){ return Math.cos(Number(v)||0); },
        tan(v){ return Math.tan(Number(v)||0); },
        atan2(y,x){ return Math.atan2(Number(y)||0,Number(x)||0); },
        pow(a,b){ return Math.pow(Number(a)||0,Number(b)||0); },
        sqrt(v){ return Math.sqrt(Math.max(0,Number(v)||0)); },
        mod(a,b){ const x=Number(a)||0,y=Number(b)||0; return y===0?0:((x%y)+y)%y; },
        normalize(x,y){ const a=Number(x)||0,b=Number(y)||0,len=Math.hypot(a,b); return len?{x:a/len,y:b/len}:{x:0,y:0}; }
      },
      canvas: {
        make(width,height){ const c=document.createElement('canvas'); c.width=Math.max(1,Number(width)||1); c.height=Math.max(1,Number(height)||1); return c; }
      }
    };

    // Kix Game API v1.7.5: public facade over verified runtime/application primitives.
    const resolveRuntimeActor = (ref) => {
      if (ref && typeof ref === 'object' && ref.data && ref.el) return ref;
      const rt = global.KixEngine?.runtime || {}, needle=String(ref==null?'':ref).trim().toLowerCase();
      if (!needle) return actor || rt.actors?.[0] || null;
      return (rt.actors||[]).find(a=>String(a?.data?.kixId||a?.data?.id||a?.id||'').toLowerCase()===needle || String(a?.data?.name||a?.name||'').toLowerCase()===needle)||null;
    };
    const engineBlock = (name, values, targetActor) => {
      const step=global.KixEngine?.stepCoroutine, target=resolveRuntimeActor(targetActor); if(typeof step!=='function')return false;
      const id='__gameapi_'+plugin.id+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,6), blk0={id,name:String(name||''),values:Object.assign({},values||{}),type:'action',next:null};
      const co0={actor:target,ip:id,blocks:{[id]:blk0},tree:{blocks:{[id]:blk0}},loopStack:[],dead:false,waitUntil:0,vars:target?.data?._vars||{},stateKey:'_gameapi'};
      try{step(co0,performance.now());return true;}catch(e){console.error('[Kix Game API]',name,e);return false;}
    };
    const gameSaveKey = slot => { const p=state.app?.getCurrentProject?.(), pid=cleanId(p?.id||p?.kixId||p?.name||'project')||'project'; return 'kix.game.save.v1:'+pid+':'+String(slot==null?'1':slot); };
    const saveGameState = slot => { const rt=global.KixEngine?.runtime||{}, snap={version:1,createdAt:Date.now(),projectId:state.app?.getCurrentProject?.()?.id||null,globals:clone(rt.globals||{}),actors:(rt.actors||[]).map(a=>({id:String(a?.data?.kixId||a?.id||''),name:String(a?.data?.name||a?.name||''),x:Number(a?.data?.x)||0,y:Number(a?.data?.y)||0,size:Number(a?.data?.size)||0,direction:Number(a?.data?.direction)||0,visible:a?.data?.visible!==false,vars:clone(a?.data?._vars||{})}))}; try{localStorage.setItem(gameSaveKey(slot),JSON.stringify(snap));return true;}catch(_){return false;} };
    const loadGameState = slot => { try{const raw=localStorage.getItem(gameSaveKey(slot));if(!raw)return null;const d=JSON.parse(raw),rt=global.KixEngine?.runtime||{};rt.globals=clone(d.globals||{});(d.actors||[]).forEach(saved=>{const ra=resolveRuntimeActor(saved.id||saved.name);if(!ra?.data)return;['x','y','size','direction'].forEach(k=>{if(saved[k]!=null)ra.data[k]=Number(saved[k])||0;});ra.data.visible=saved.visible!==false;ra.data._vars=clone(saved.vars||{});try{global.KixEngine.updateSpriteTransform?.(ra,true);}catch(_){}});return clone(d);}catch(_){return null;} };
    const eventRegistry=state.gameApiEvents||(state.gameApiEvents=new Map()), timerRegistry=state.gameApiTimers||(state.gameApiTimers=new Map());
    const ensureProjectFiles = () => {
      const pr=state.app?.getCurrentProject?.();
      if(!pr) return [];
      if(!Array.isArray(pr.files)) pr.files=[];
      return pr.files;
    };
    const normalizeVirtualPath = value => {
      const raw=String(value==null?'':value).replace(/\\/g,'/').trim();
      const parts=raw.split('/').filter(Boolean).filter(x=>x!=='.'&&x!=='..');
      return parts.join('/');
    };
    const fileNameFromPath = value => {
      const p=normalizeVirtualPath(value);
      const i=p.lastIndexOf('/');
      return i>=0?p.slice(i+1):p;
    };
    const fileRefKey = value => String(value==null?'':value).trim().replace(/^['"]|['"]$/g,'');
    const findProjectFile = ref => {
      const key=fileRefKey(ref).toLowerCase();
      if(!key) return null;
      const files=ensureProjectFiles();
      const norm=s=>normalizeVirtualPath(s).toLowerCase();
      return files.find(f=>{
        if(!f) return false;
        const id=String(f.id||'').toLowerCase();
        const name=String(f.name||'').toLowerCase();
        const path=norm(f.path);
        return id===key || name===key || path===key || norm(name)===norm(key) || path===norm(key);
      }) || null;
    };
    const bytesToText = bytes => {
      try { if(typeof TextDecoder==='function') return new TextDecoder('utf-8').decode(bytes); } catch(_) {}
      let binary=''; for(let i=0;i<bytes.length;i++) binary+=String.fromCharCode(bytes[i]);
      try { return decodeURIComponent(escape(binary)); } catch(_) { return binary; }
    };
    const dataUrlToText = value => {
      const raw=String(value||'');
      const m=raw.match(/^data:([^,]*?),(.*)$/s);
      if(!m) return raw;
      const meta=m[1]||'', body=m[2]||'';
      if(/;base64/i.test(meta)){
        try { const bin=atob(body.replace(/\s/g,'')); const bytes=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++) bytes[i]=bin.charCodeAt(i); return bytesToText(bytes); } catch(_) { return ''; }
      }
      try { return decodeURIComponent(body); } catch(_) { return body; }
    };
    const textToDataUrl = (text,mime) => 'data:'+(String(mime||'text/plain;charset=utf-8'))+';base64,'+utf8ToBase64(String(text==null?'':text));
    const estimateDataUrlBytes = dataUrl => {
      const raw=String(dataUrl||'');
      const comma=raw.indexOf(',');
      if(comma<0) return raw.length;
      if(/;base64/i.test(raw.slice(0,comma))){ const body=raw.slice(comma+1).replace(/\s/g,''); return Math.floor(body.length*3/4); }
      try { return new Blob([decodeURIComponent(raw.slice(comma+1))]).size; } catch(_) { return raw.length; }
    };
    const upsertProjectFile = (ref,name,type) => {
      const existing=findProjectFile(ref);
      if(existing) return existing;
      const requested=fileRefKey(name||ref)||'arquivo.txt';
      const path=normalizeVirtualPath(requested);
      const base=fileNameFromPath(requested)||'arquivo.txt';
      const file={id:String(global.KixEngine?.newId?.()||('file_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8))),name:base,type:String(type||'text/plain;charset=utf-8'),path:path,dataUrl:textToDataUrl('',type||'text/plain;charset=utf-8')};
      ensureProjectFiles().push(file);
      return file;
    };
    const persistProject = () => { try { state.app?.save?.(); return true; } catch(_) { return false; } };
    const timerSet=id=>{let s=timerRegistry.get(id);if(!s){s=new Set();timerRegistry.set(id,s);}return s;}, clearPluginTimers=id=>{const s=timerRegistry.get(id);if(!s)return 0;let n=0;s.forEach(h=>{try{clearTimeout(h);clearInterval(h);}catch(_){}n++;});s.clear();timerRegistry.delete(id);return n;}, eventMap=id=>{let m=eventRegistry.get(id);if(!m){m=new Map();eventRegistry.set(id,m);}return m;};
    const systemRegistry=state.gameApiSystems||(state.gameApiSystems=new Map());
    const systemState=()=>{let s=systemRegistry.get(plugin.id);if(!s){s={waves:{},stateMachines:{},lastEvents:[]};systemRegistry.set(plugin.id,s);}return s;};
    const systemActorKey=target=>{const ra=resolveRuntimeActor(target);return ra?String(ra.data?.kixId||ra.data?.id||ra.id||ra.data?.name||ra.name||'actor'):'';};
    const actorVars=target=>{const ra=resolveRuntimeActor(target);if(!ra?.data)return null;ra.data._vars=ra.data._vars&&typeof ra.data._vars==='object'?ra.data._vars:{};return ra.data._vars;};
    const numberOr=(value,fallback=0)=>{const n=Number(value);return Number.isFinite(n)?n:fallback;};
    const emitSystemEvent=(name,payload)=>{const key='game-system:'+String(name||'').trim();const data=clone(payload||{});const reg=systemState();reg.lastEvents.push({name:key,data,time:Date.now()});if(reg.lastEvents.length>64)reg.lastEvents.shift();return api.events.emit(key,data);};
    const healthVars=(target)=>{const v=actorVars(target);if(!v)return null;const max=numberOr(v.__kix_health_max,numberOr(v.health,100));if(!Number.isFinite(v.__kix_health_max))v.__kix_health_max=max;return v;};
    const getHealthValue=target=>{const v=healthVars(target);return v?numberOr(v.health,numberOr(v.__kix_health_max,100)):0;};
    const setHealthValue=(target,value)=>{const v=healthVars(target);if(!v)return false;const max=Math.max(0,numberOr(v.__kix_health_max,100));v.health=Math.max(0,Math.min(max,numberOr(value,0)));return v.health;};
    const getCombatTarget=target=>{const ra=resolveRuntimeActor(target);return ra?ra:null;};
    const invulnerable=target=>{const v=actorVars(target);return !!v?.__kix_combat_invulnerable;};
    const inventoryValue=target=>{const v=actorVars(target);if(!v)return null;if(!Array.isArray(v.__kix_inventory_v1))v.__kix_inventory_v1=[];return v.__kix_inventory_v1;};
    const rpgValue=target=>{const v=actorVars(target);if(!v)return null;if(!v.__kix_rpg_v1||typeof v.__kix_rpg_v1!=='object')v.__kix_rpg_v1={level:1,xp:0,stats:{}};if(!v.__kix_rpg_v1.stats||typeof v.__kix_rpg_v1.stats!=='object')v.__kix_rpg_v1.stats={};return v.__kix_rpg_v1;};
    const aiValue=target=>{const v=actorVars(target);if(!v)return null;if(!v.__kix_ai_v1||typeof v.__kix_ai_v1!=='object')v.__kix_ai_v1={enabled:true,state:'idle',target:null};return v.__kix_ai_v1;};
    const platformerValue=target=>{const v=actorVars(target);if(!v)return null;if(!v.__kix_platformer_v1||typeof v.__kix_platformer_v1!=='object')v.__kix_platformer_v1={enabled:true,speed:6,jumpVelocity:-12,gravityScale:1};return v.__kix_platformer_v1;};
    const shooterValue=target=>{const v=actorVars(target);if(!v)return null;if(!v.__kix_shooter_v1||typeof v.__kix_shooter_v1!=='object')v.__kix_shooter_v1={cooldownMs:250,lastFire:0,damage:10};return v.__kix_shooter_v1;};
    const bossValue=target=>{const v=actorVars(target);if(!v)return null;if(!v.__kix_boss_v1||typeof v.__kix_boss_v1!=='object')v.__kix_boss_v1={active:false,phase:1,enraged:false};return v.__kix_boss_v1;};
    const projectileValue=target=>{const ra=resolveRuntimeActor(target),v=actorVars(target);if(!ra?.data||!v)return null;if(!v.__kix_projectile_v1||typeof v.__kix_projectile_v1!=='object')v.__kix_projectile_v1={};return v.__kix_projectile_v1;};
    Object.assign(api, {
      actor:Object.assign({},api.actor,{getRuntime(){const ra=resolveRuntimeActor();return ra?{id:String(ra.data?.kixId||ra.id||''),name:String(ra.data?.name||ra.name||''),position:{x:Number(ra.data?.x)||0,y:Number(ra.data?.y)||0},visible:ra.data?.visible!==false}:null;},setVisible(v){const ra=resolveRuntimeActor();if(!ra)return false;ra.data.visible=!!v;try{global.KixEngine.updateSpriteTransform?.(ra,true);}catch(_){}return true;}}),
      actors:Object.assign({},api.actors,{each(fn){if(typeof fn!=='function')return 0;const xs=(global.KixEngine?.runtime?.actors||[]).slice();xs.forEach((ra,i)=>{try{fn({index:i,id:String(ra?.data?.kixId||ra?.id||''),name:String(ra?.data?.name||ra?.name||''),actor:ra.data||null});}catch(e){console.warn('[Kix Game API] actors.each',e);}});return xs.length;},countRuntime(){return Array.isArray(global.KixEngine?.runtime?.actors)?global.KixEngine.runtime.actors.length:0;}}),
      collision:{between(a,b){const ra=resolveRuntimeActor(a),rb=resolveRuntimeActor(b);return !!(ra&&rb&&global.KixEngine?.checkCollision?.(ra,rb));},overlaps(t){const ra=resolveRuntimeActor(),rb=resolveRuntimeActor(t);return !!(ra&&rb&&ra!==rb&&global.KixEngine?.checkCollision?.(ra,rb));},point(x,y,t){const ra=resolveRuntimeActor(t);if(!ra)return false;const a=ra.data||{},w=Math.max(1,(Number(a.width)||64)*(Number(a.size||100)/100)),h=Math.max(1,(Number(a.height)||64)*(Number(a.size||100)/100)),px=Number(x)||0,py=Number(y)||0,cx=Number(a.x)||0,cy=Number(a.y)||0;return px>=cx-w/2&&px<=cx+w/2&&py>=cy-h/2&&py<=cy+h/2;},bounds(t){const ra=resolveRuntimeActor(t);if(!ra)return null;const a=ra.data||{},w=Math.max(1,(Number(a.width)||64)*(Number(a.size||100)/100)),h=Math.max(1,(Number(a.height)||64)*(Number(a.size||100)/100)),x=Number(a.x)||0,y=Number(a.y)||0;return{left:x-w/2,right:x+w/2,top:y-h/2,bottom:y+h/2,width:w,height:h};}},
      animation:{play(folder,options,target){const ra=resolveRuntimeActor(target);return !!(ra&&global.KixEngine?.startLookAnimation?.(ra,String(folder||'Idle'),options||{}));},stop(options,target){const ra=resolveRuntimeActor(target);if(!ra||!global.KixEngine?.stopLookAnimation)return false;global.KixEngine.stopLookAnimation(ra,options||{});return true;},isPlaying(target){const ra=resolveRuntimeActor(target);return !!ra?._animPlaying;},getState(target){const ra=resolveRuntimeActor(target);return ra?{playing:!!ra._animPlaying,done:!!ra._animDone,folder:ra._animFolder||null,frame:Number(ra._animFrame)||0,frames:Array.isArray(ra._animFrames)?ra._animFrames.slice():[],loop:!!ra._animLoop}:null;},tick(deltaMs){try{global.KixEngine.tickLookAnimations?.(Number(deltaMs)||0);return true;}catch(_){return false;}}},
      appearance:{set(v,t){const ra=resolveRuntimeActor(t);return !!(ra&&global.KixEngine?.applyAppearance?.(ra,String(v||''),{}));},setByIndex(i,t){const ra=resolveRuntimeActor(t);return !!(ra&&global.KixEngine?.applyAppearance?.(ra,String(Math.floor(Number(i)||1)),{numericOneBased:true}));},opacity(v,t){const ra=resolveRuntimeActor(t);return ra&&global.KixEngine?.setActorOpacity?global.KixEngine.setActorOpacity(ra,v):false;},transparency(v,t){const ra=resolveRuntimeActor(t);return ra&&global.KixEngine?.setActorTransparency?global.KixEngine.setActorTransparency(ra,v):false;},show(t){const ra=resolveRuntimeActor(t);if(!ra)return false;ra.data.visible=true;global.KixEngine?.updateSpriteTransform?.(ra,true);return true;},hide(t){const ra=resolveRuntimeActor(t);if(!ra)return false;ra.data.visible=false;global.KixEngine?.updateSpriteTransform?.(ra,true);return true;},pixelArt(v,t){const ra=resolveRuntimeActor(t);if(!ra)return false;ra.data.pixelArt=!!v;global.KixEngine?.updateSpriteTransform?.(ra,true);return true;}},
      audio:Object.assign({},api.audio,{playMusic(src,o){const a=api.audio.play(src);if(a)try{a.loop=!!o?.loop;}catch(_){}return a;},isPlaying(src){const k=String(src||'');return (runtime.sounds||[]).some(a=>a&&!a.paused&&(!k||String(a.src||'')===k||String(a.src||'').includes(k)));}}),
      particles:Object.assign({},api.particles,{emit(count,target){return engineBlock('Emitir partículas',{quantidade:Math.max(1,Number(count)||1)},target);},start(target){return engineBlock('Criar emissor de partículas',{},target);},stop(target){return engineBlock('Parar partículas',{},target);}}),
      controls:{joystick(id,o){o=o||{};return engineBlock('Criar joystick virtual',{id:String(id||'joystick1'),tamanho:Number(o.size)||110,x:Number(o.x)||0,y:Number(o.y)||0,estilo:String(o.style||'glass')});},dpad(id,o){o=o||{};return engineBlock('Criar D-Pad',{id:String(id||'dpad1'),cima:String(o.up||'dpad_cima'),baixo:String(o.down||'dpad_baixo'),esquerda:String(o.left||'dpad_esquerda'),direita:String(o.right||'dpad_direita')});},actionButton(id,text){return engineBlock('Criar botão de ação',{id:String(id||'acao1'),texto:String(text||'Ação')});},getJoystick(id){const c=global.KixEngine?.runtime?._presets?.controls?.[String(id||'joystick1')];return c?{id:c.id,x:Number(c.axisX)||0,y:Number(c.axisY)||0,force:Number(c.force)||0,direction:Number(c.direction)||0,active:!!c.active}:null;},remove(id='todos'){return engineBlock('Remover controles virtuais',{id:String(id)});}},
      hud:{show(){return engineBlock('Mostrar HUD',{});},hide(){return engineBlock('Esconder HUD',{});},button(id,text){return engineBlock('Criar botão',{id:String(id||'btn1'),texto:String(text||'Botão')});},slider(id,min=0,max=100){return engineBlock('Criar slider',{id:String(id||'sl1'),min:Number(min)||0,max:Number(max)||100});},text(id,value){return engineBlock('Criar texto na UI',{id:String(id||'txt1'),texto:String(value??'')});},progress(id,max=100,value=0){const ok=engineBlock('Criar barra de progresso',{id:String(id||'prog1'),max:Number(max)||100});if(ok&&Number(value)!==0)engineBlock('Atualizar barra de progresso',{id:String(id||'prog1'),valor:Number(value)||0});return ok;},setProgress(id,value){return engineBlock('Atualizar barra de progresso',{id:String(id||'prog1'),valor:Number(value)||0});},dialog(id,text){return engineBlock('Criar diálogo',{id:String(id||'dlg1'),texto:String(text??'')});},closeDialog(id){return engineBlock('Fechar diálogo',{id:String(id||'dlg1')});},counter(id,value){return engineBlock('Criar contador',{id:String(id||'cnt1'),valor:String(value??0)});},setCounter(id,value){return engineBlock('Atualizar contador',{id:String(id||'cnt1'),valor:String(value??0)});},clear(){return engineBlock('Facilitador: limpar toda a UI',{});},state(){return clone(global.KixEngine?.runtime?._hud||null);}},
      ui:Object.assign({},api.ui,{create(tag,o){o=o||{};const t=['div','span','button','img','p','label'].includes(String(tag||'div').toLowerCase())?String(tag).toLowerCase():'div',el=document.createElement(t);el.textContent=o.text==null?'':String(o.text);if(o.id)el.id=String(o.id);if(o.className)el.className=String(o.className);if(o.parent){const h=document.querySelector(String(o.parent));if(h)h.appendChild(el);}return el;},remove(sel){const xs=document.querySelectorAll(String(sel||''));xs.forEach(x=>x.remove());return xs.length;}}),
      scene:Object.assign({},api.scene,{current(){return{index:api.scene.getIndex(),name:api.scene.getName()};}}),
      project:Object.assign({},api.project,{current(){return clone(state.app?.getCurrentProject?.()||null);}}),
      files:{
        list(){ return clone(ensureProjectFiles()); },
        exists(ref){ return !!findProjectFile(ref); },
        get(ref){ const f=findProjectFile(ref); return f?clone(f):null; },
        create(name,data='',type='text/plain;charset=utf-8'){
          const existing=findProjectFile(name);
          if(existing) return clone(existing);
          const f=upsertProjectFile(null,name,type);
          f.dataUrl=textToDataUrl(typeof data==='string'?data:JSON.stringify(data,null,2),type);
          persistProject();
          return clone(f);
        },
        writeText(ref,text,type){ const f=upsertProjectFile(ref,ref,type||'text/plain;charset=utf-8'); if(!f)return null; f.type=String(type||f.type||'text/plain;charset=utf-8'); f.dataUrl=textToDataUrl(text,f.type); persistProject(); return clone(f); },
        readText(ref){ const f=findProjectFile(ref); return f?dataUrlToText(f.dataUrl):null; },
        writeJSON(ref,value,pretty=true){ const f=upsertProjectFile(ref,ref,'application/json;charset=utf-8'); if(!f)return null; f.type='application/json;charset=utf-8'; f.dataUrl=textToDataUrl(JSON.stringify(value,null,pretty?2:0),f.type); persistProject(); return clone(f); },
        readJSON(ref,fallback=null){ const text=this.readText(ref); if(text==null)return fallback; try{return JSON.parse(text);}catch(_){return fallback;} },
        rename(ref,newName){ const f=findProjectFile(ref),name=fileNameFromPath(newName); if(!f||!name)return false; f.name=name; if(f.path) { const parts=normalizeVirtualPath(f.path).split('/'); parts.pop(); f.path=parts.length?parts.join('/')+'/'+name:name; } else f.path=name; persistProject(); return true; },
        move(ref,destinationPath){ const f=findProjectFile(ref),dest=normalizeVirtualPath(destinationPath); if(!f||!dest)return false; f.path=dest.indexOf('/')>=0?dest:dest; const n=fileNameFromPath(dest); if(n)f.name=n; persistProject(); return true; },
        redirect(ref,destinationPath){ return this.move(ref,destinationPath); },
        remove(ref){ const files=ensureProjectFiles(),f=findProjectFile(ref); if(!f)return false; const i=files.indexOf(f); if(i<0)return false; files.splice(i,1); persistProject(); return true; },
        saveVariables(ref,variables){ if(!variables || typeof variables!=='object' || Array.isArray(variables)) return false; const f=upsertProjectFile(ref,ref,'application/json;charset=utf-8'); if(!f)return false; f.type='application/json;charset=utf-8'; f.dataUrl=textToDataUrl(JSON.stringify({kind:'kix-variables-v1',variables:clone(variables)}),f.type); persistProject(); return true; },
        loadVariables(ref,fallback={}){ const raw=this.readJSON(ref,null); if(raw&&raw.kind==='kix-variables-v1'&&raw.variables&&typeof raw.variables==='object'&&!Array.isArray(raw.variables))return clone(raw.variables); if(raw&&typeof raw==='object'&&!Array.isArray(raw))return clone(raw); return fallback; },
        saveList(ref,list){ if(!Array.isArray(list))return false; const f=upsertProjectFile(ref,ref,'application/json;charset=utf-8'); if(!f)return false; f.type='application/json;charset=utf-8'; f.dataUrl=textToDataUrl(JSON.stringify({kind:'kix-list-v1',list:clone(list)}),f.type); persistProject(); return true; },
        loadList(ref,fallback=[]){ const raw=this.readJSON(ref,null); if(raw&&raw.kind==='kix-list-v1'&&Array.isArray(raw.list))return clone(raw.list); if(Array.isArray(raw))return clone(raw); return fallback; },
        export(ref,suggestedName){ const f=findProjectFile(ref); if(!f)return false; const filename=safeExportFileName(suggestedName||f.name||'arquivo') || 'arquivo'; const mime=String(f.type||'application/octet-stream'); const payload=String(f.dataUrl||''); try{ const comma=payload.indexOf(','); const bytesBase64=comma>=0&&/;base64/i.test(payload.slice(0,comma))?payload.slice(comma+1):utf8ToBase64(dataUrlToText(payload)); if(global.Android&&typeof global.Android.beginFile==='function'){global.Android.beginFile(filename,mime);for(let i=0;i<bytesBase64.length;i+=60*1024)global.Android.appendFileChunk(bytesBase64.slice(i,i+60*1024));global.Android.finishFile();return true;} const a=document.createElement('a');a.href=payload.indexOf('data:')===0?payload:'data:'+mime+';base64,'+bytesBase64;a.download=filename;document.body.appendChild(a);a.click();a.remove();return true;}catch(_){return false;} },
        size(ref){ const f=findProjectFile(ref); return f?estimateDataUrlBytes(f.dataUrl):0; }
      },
      lists:{
        create(name,initial=[]){ const k=String(name||'lista').trim()||'lista'; if(!Array.isArray(runtime.lists))runtime.lists={}; runtime.lists[k]=Array.isArray(initial)?clone(initial):[]; return clone(runtime.lists[k]); },
        exists(name){ const k=String(name||'').trim(); return !!(k&&runtime.lists&&Array.isArray(runtime.lists[k])); },
        get(name,fallback=[]){ const k=String(name||'').trim(); return runtime.lists&&Array.isArray(runtime.lists[k])?clone(runtime.lists[k]):fallback; },
        set(name,values){ const k=String(name||'lista').trim()||'lista'; if(!runtime.lists)runtime.lists={}; runtime.lists[k]=Array.isArray(values)?clone(values):[]; return clone(runtime.lists[k]); },
        add(name,value){ const k=String(name||'lista').trim()||'lista'; if(!runtime.lists)runtime.lists={}; if(!Array.isArray(runtime.lists[k]))runtime.lists[k]=[]; runtime.lists[k].push(value); return runtime.lists[k].length; },
        insert(name,index,value){ const k=String(name||'lista').trim()||'lista'; if(!runtime.lists)runtime.lists={}; if(!Array.isArray(runtime.lists[k]))runtime.lists[k]=[]; const i=Math.max(0,Math.min(runtime.lists[k].length,Math.floor(Number(index)||0))); runtime.lists[k].splice(i,0,value); return runtime.lists[k].length; },
        remove(name,index){ const k=String(name||'lista').trim()||'lista'; const list=runtime.lists&&runtime.lists[k]; if(!Array.isArray(list))return false; const i=Math.floor(Number(index)||0); if(i<0||i>=list.length)return false; list.splice(i,1); return true; },
        clear(name){ const k=String(name||'lista').trim()||'lista'; if(!runtime.lists)runtime.lists={}; runtime.lists[k]=[]; return true; },
        size(name){ const k=String(name||'').trim(); return runtime.lists&&Array.isArray(runtime.lists[k])?runtime.lists[k].length:0; },
        contains(name,value){ const k=String(name||'').trim(); const list=runtime.lists&&runtime.lists[k]; return Array.isArray(list)?list.some(x=>String(x)===String(value)):false; },
        saveToFile(name,fileRef){ return this.exists(name)?api.files.saveList(fileRef||String(name)+'.json',runtime.lists[name]):false; },
        loadFromFile(name,fileRef){ const list=api.files.loadList(fileRef,[]); return Array.isArray(list)?this.set(name,list):[]; }
      },
      webview:{
        getUrl(){ try{return String(global.location?.href||'');}catch(_){return '';} },
        getTitle(){ try{return String(global.document?.title||'');}catch(_){return '';} },
        setTitle(title){ try{global.document.title=String(title==null?'':title);return true;}catch(_){return false;} },
        getReadyState(){ try{return String(global.document?.readyState||'');}catch(_){return '';} },
        getViewport(){ return {width:Number(global.innerWidth)||0,height:Number(global.innerHeight)||0,devicePixelRatio:Number(global.devicePixelRatio)||1}; },
        scrollTo(x,y){ try{global.scrollTo(Number(x)||0,Number(y)||0);return true;}catch(_){return false;} },
        scrollBy(x,y){ try{global.scrollBy(Number(x)||0,Number(y)||0);return true;}catch(_){return false;} },
        reload(){ try{global.location?.reload?.();return true;}catch(_){return false;} },
        openExternal(url){ const u=String(url||'').trim(); if(!/^https?:\/\//i.test(u))return false; try{if(typeof global.Android?.openExternalUrl==='function'){return !!global.Android.openExternalUrl(u);} const w=global.open?.(u,'_blank','noopener,noreferrer'); return !!w;}catch(_){return false;} }
      },
      save:{slot:s=>saveGameState(s),load:s=>loadGameState(s),exists:s=>{try{return localStorage.getItem(gameSaveKey(s))!==null;}catch(_){return false;}},remove:s=>{try{localStorage.removeItem(gameSaveKey(s));return true;}catch(_){return false;}}},
      timers:{timeout(ms,fn){if(typeof fn!=='function')return null;const s=timerSet(plugin.id),h=setTimeout(()=>{s.delete(h);try{fn();}catch(e){console.error('[Kix Game API] timeout',e);}},Math.max(0,Number(ms)||0));s.add(h);return h;},interval(ms,fn){if(typeof fn!=='function')return null;const s=timerSet(plugin.id),h=setInterval(()=>{try{fn();}catch(e){console.error('[Kix Game API] interval',e);}},Math.max(16,Number(ms)||16));s.add(h);return h;},clear(h){try{clearTimeout(h);clearInterval(h);}catch(_){}timerSet(plugin.id).delete(h);return true;},clearAll(){return clearPluginTimers(plugin.id);}},
      events:{on(name,fn){if(typeof fn!=='function')return false;const m=eventMap(plugin.id),k=String(name||'').trim();if(!k)return false;const a=m.get(k)||[];a.push(fn);m.set(k,a);return()=>{m.set(k,(m.get(k)||[]).filter(x=>x!==fn));};},emit(name,data){const k=String(name||'').trim();if(!k)return 0;let n=0;(eventMap(plugin.id).get(k)||[]).slice().forEach(fn=>{try{fn(data,{name:k});n++;}catch(e){console.error('[Kix Game API] event',k,e);}});try{n+=Number(global.KixEngine?.gameApi?.dispatchEvent?.(k,data)||0);}catch(_){}return n;},clear(name){const m=eventMap(plugin.id);if(name==null){m.clear();return true;}return m.delete(String(name||'').trim());}},
      networking:global.KixEngine?.gameApi?.networking||{},
      multiplayer:global.KixEngine?.gameApi?.multiplayer||{},
      assets:{listImages(){const p=state.app?.getCurrentProject?.();if(!p)return [];const out=[],seen=new Set(),add=(src,name,owner)=>{if(src==null||String(src)===''||seen.has(String(src)))return;seen.add(String(src));out.push({src:String(src),name:String(name||'Imagem'),owner:String(owner||'')});};(p.scenes||[]).forEach(sc=>(sc?.actors||[]).forEach(a=>{if(!a)return;const owner=String(a.name||a.kixId||'');add(a.image,owner+' • imagem principal',owner);add(a.thumbnailImage,owner+' • miniatura',owner);(a.looks||[]).forEach((look,i)=>add(typeof look==='string'?look:(look?.src||look?.dataUrl||look?.image),owner+' • aparência '+(i+1),owner));(a.folders||[]).forEach(folder=>(folder?.looks||[]).forEach((look,i)=>add(typeof look==='string'?look:(look?.src||look?.dataUrl||look?.image),owner+' • '+String(folder.name||'Pasta')+' '+(i+1),owner)));}));return out;},listSounds(){const p=state.app?.getCurrentProject?.();if(!p)return [];const out=[],seen=new Set();(p.scenes||[]).forEach(sc=>(sc?.actors||[]).forEach(a=>(a?.sounds||[]).forEach((sound,i)=>{const src=typeof sound==='string'?sound:(sound?.src||sound?.url||sound?.dataUrl||sound?.file);if(src==null||String(src)===''||seen.has(String(src)))return;seen.add(String(src));out.push({src:String(src),name:String(sound?.name||('Som '+(i+1))),owner:String(a?.name||'')});})));return out;},listLooks(t){return clone(resolveRuntimeActor(t)?.data?.looks||[]);},find(name){const n=String(name||'').trim().toLowerCase(),p=state.app?.getCurrentProject?.(),all=[...(p?.files||[]),...(p?.assets||[])];const hit=all.find(x=>String(x?.name||x?.id||x?.src||'').toLowerCase()===n);if(hit)return clone(hit);const image=this.listImages().find(x=>x.name.toLowerCase()===n||x.src.toLowerCase()===n);if(image)return clone(image);const sound=this.listSounds().find(x=>x.name.toLowerCase()===n||x.src.toLowerCase()===n);return sound?clone(sound):null;}},
      math:Object.assign({},api.math,{vector(x=0,y=0){return{x:Number(x)||0,y:Number(y)||0};},dot(ax,ay,bx,by){return(Number(ax)||0)*(Number(bx)||0)+(Number(ay)||0)*(Number(by)||0);},length(x,y){return Math.hypot(Number(x)||0,Number(y)||0);},rotate(x,y,d){const r=(Number(d)||0)*Math.PI/180,c=Math.cos(r),s=Math.sin(r),a=Number(x)||0,b=Number(y)||0;return{x:a*c-b*s,y:a*s+b*c};}}),
      gameSystems:{
        Combat:{damage(target,amount,meta){const ra=getCombatTarget(target),v=healthVars(ra);if(!ra||!v||invulnerable(ra))return 0;const before=getHealthValue(ra),after=setHealthValue(ra,before-Math.max(0,numberOr(amount,0)));emitSystemEvent('combat.damage',{source:systemActorKey(actor),target:systemActorKey(ra),amount:Math.max(0,before-after),health:after,meta:clone(meta||{})});return Math.max(0,before-after);},heal(target,amount,meta){const ra=getCombatTarget(target),v=healthVars(ra);if(!ra||!v)return 0;const before=getHealthValue(ra),after=setHealthValue(ra,before+Math.max(0,numberOr(amount,0)));emitSystemEvent('combat.heal',{target:systemActorKey(ra),amount:Math.max(0,after-before),health:after,meta:clone(meta||{})});return Math.max(0,after-before);},getHealth(target){return getHealthValue(target);},setHealth(target,value){const ra=getCombatTarget(target),after=setHealthValue(ra,value);if(after===false)return false;return after;},setInvulnerable(target,value=true){const v=actorVars(target);if(!v)return false;v.__kix_combat_invulnerable=!!value;return v.__kix_combat_invulnerable;},isInvulnerable(target){return invulnerable(target);},setTeam(target,team){const v=actorVars(target);if(!v)return false;v.__kix_combat_team=String(team??'');return v.__kix_combat_team;},getTeam(target){return actorVars(target)?.__kix_combat_team||'';}},
        RPG:{getLevel(target){return numberOr(rpgValue(target)?.level,1);},setLevel(target,value){const v=rpgValue(target);if(!v)return false;v.level=Math.max(1,Math.floor(numberOr(value,1)));return v.level;},addXP(target,amount){const v=rpgValue(target);if(!v)return false;v.xp=Math.max(0,numberOr(v.xp,0)+numberOr(amount,0));emitSystemEvent('rpg.xp',{target:systemActorKey(target),xp:v.xp,amount:numberOr(amount,0)});return v.xp;},getXP(target){return numberOr(rpgValue(target)?.xp,0);},setStat(target,name,value){const v=rpgValue(target);if(!v||!String(name||'').trim())return false;v.stats[String(name).trim()]=value;return value;},getStat(target,name,fallback=null){return rpgValue(target)?.stats?.[String(name).trim()]??fallback;},getStats(target){return clone(rpgValue(target)?.stats||{});}},
        AI:{setEnabled(target,value=true){const v=aiValue(target);if(!v)return false;v.enabled=!!value;return v.enabled;},isEnabled(target){return !!aiValue(target)?.enabled;},setState(target,value){const v=aiValue(target);if(!v)return false;v.state=String(value||'idle');emitSystemEvent('ai.state',{target:systemActorKey(target),state:v.state});return v.state;},getState(target){return aiValue(target)?.state||'idle';},setTarget(target,targetActor){const v=aiValue(target);if(!v)return false;v.target=systemActorKey(targetActor)||null;return v.target;},getTarget(target){return aiValue(target)?.target||null;},clearTarget(target){const v=aiValue(target);if(!v)return false;v.target=null;return true;}},
        Inventory:{get(target){return clone(inventoryValue(target)||[]);},set(target,items){const list=inventoryValue(target);if(!list||!Array.isArray(items))return false;list.splice(0,list.length,...clone(items));return clone(list);},add(target,item,quantity=1){const list=inventoryValue(target);if(!list)return false;const q=Math.max(1,Math.floor(numberOr(quantity,1)));for(let i=0;i<q;i++)list.push(item);return list.length;},remove(target,item,quantity=1){const list=inventoryValue(target);if(!list)return 0;let left=Math.max(1,Math.floor(numberOr(quantity,1))),removed=0;for(let i=list.length-1;i>=0&&left>0;i--){if(String(list[i])===String(item)){list.splice(i,1);left--;removed++;}}return removed;},has(target,item){return !!inventoryValue(target)?.some(x=>String(x)===String(item));},count(target,item){return (inventoryValue(target)||[]).filter(x=>String(x)===String(item)).length;},clear(target){const list=inventoryValue(target);if(!list)return false;list.splice(0,list.length);return true;}},
        Save:{slot(s){return api.save.slot(s);},load(s){return api.save.load(s);},exists(s){return api.save.exists(s);},remove(s){return api.save.remove(s);}},
        Camera:Object.assign({},api.camera),
        Platformer:{configure(target,options){const v=platformerValue(target);if(!v)return false;Object.keys(options||{}).forEach(k=>{if(['speed','jumpVelocity','gravityScale'].includes(k))v[k]=numberOr(options[k],v[k]);if(k==='enabled')v.enabled=!!options[k];});return clone(v);},getConfig(target){return clone(platformerValue(target)||{});},move(target,direction,speed){const ra=resolveRuntimeActor(target),v=platformerValue(ra);if(!ra||!v||v.enabled===false)return false;const dx=Math.max(-1,Math.min(1,numberOr(direction,0)));ra.data.vx=dx*numberOr(speed,v.speed);return ra.data.vx;},jump(target,velocity){const ra=resolveRuntimeActor(target),v=platformerValue(ra);if(!ra||!v||v.enabled===false)return false;ra.data.vy=numberOr(velocity,v.jumpVelocity);return ra.data.vy;}},
        Shooter:{configure(target,options){const v=shooterValue(target);if(!v)return false;Object.keys(options||{}).forEach(k=>{if(['cooldownMs','damage'].includes(k))v[k]=Math.max(0,numberOr(options[k],v[k]));});return clone(v);},canFire(target){const v=shooterValue(target);if(!v)return false;return Date.now()-numberOr(v.lastFire,0)>=Math.max(0,numberOr(v.cooldownMs,250));},fire(target,targetActor,options){const v=shooterValue(target);if(!v||!this.canFire(target))return false;v.lastFire=Date.now();const damage=numberOr(options?.damage,v.damage);const dealt=targetActor!=null?api.gameSystems.Combat.damage(targetActor,damage,{weapon:systemActorKey(target)}):0;emitSystemEvent('shooter.fire',{source:systemActorKey(target),target:systemActorKey(targetActor),damage,dealt});return{fired:true,damage,dealt,time:v.lastFire};},getConfig(target){return clone(shooterValue(target)||{});}},
        Boss:{configure(target,options){const v=bossValue(target);if(!v)return false;v.active=options?.active==null?v.active:!!options.active;v.phase=Math.max(1,Math.floor(numberOr(options?.phase,v.phase)));v.enraged=options?.enraged==null?v.enraged:!!options.enraged;return clone(v);},setPhase(target,value){const v=bossValue(target);if(!v)return false;v.phase=Math.max(1,Math.floor(numberOr(value,1)));emitSystemEvent('boss.phase',{target:systemActorKey(target),phase:v.phase});return v.phase;},getPhase(target){return numberOr(bossValue(target)?.phase,1);},setEnraged(target,value=true){const v=bossValue(target);if(!v)return false;v.enraged=!!value;return v.enraged;},isEnraged(target){return !!bossValue(target)?.enraged;},setActive(target,value=true){const v=bossValue(target);if(!v)return false;v.active=!!value;return v.active;},isActive(target){return !!bossValue(target)?.active;}},
        Dialogue:{say(text,id='dialogue1'){return api.hud.dialog(String(id),String(text??''));},close(id='dialogue1'){return api.hud.closeDialog(String(id));}},
        Health:{get(target){return getHealthValue(target);},set(target,value){return setHealthValue(resolveRuntimeActor(target),value);},damage(target,amount,meta){return api.gameSystems.Combat.damage(target,amount,meta);},heal(target,amount,meta){return api.gameSystems.Combat.heal(target,amount,meta);},getMax(target){return numberOr(healthVars(target)?.__kix_health_max,100);},setMax(target,value){const v=healthVars(target);if(!v)return false;v.__kix_health_max=Math.max(0,numberOr(value,100));if(numberOr(v.health,v.__kix_health_max)>v.__kix_health_max)v.health=v.__kix_health_max;return v.__kix_health_max;},percentage(target){const v=healthVars(target);if(!v)return 0;const max=Math.max(0,numberOr(v.__kix_health_max,100));return max>0?getHealthValue(target)/max:0;}},
        Quest:{getState(id){const q=String(id||'').trim();if(!q)return null;const all=global.KixEngine?.runtime?.globals?.__kix_quests_v1||{};return clone(all[q]||null);},setState(id,stateValue){const q=String(id||'').trim();if(!q)return false;const rt=global.KixEngine?.runtime;if(!rt)return false;rt.globals=rt.globals||{};rt.globals.__kix_quests_v1=rt.globals.__kix_quests_v1||{};rt.globals.__kix_quests_v1[q]=Object.assign({},rt.globals.__kix_quests_v1[q]||{},typeof stateValue==='object'&&stateValue?clone(stateValue):{state:String(stateValue||'active')});emitSystemEvent('quest.state',{id:q,state:clone(rt.globals.__kix_quests_v1[q])});return clone(rt.globals.__kix_quests_v1[q]);},setProgress(id,value){const q=String(id||'').trim();if(!q)return false;const rt=global.KixEngine?.runtime;if(!rt)return false;rt.globals=rt.globals||{};rt.globals.__kix_quests_v1=rt.globals.__kix_quests_v1||{};const entry=rt.globals.__kix_quests_v1[q]||{state:'active'};entry.progress=numberOr(value,0);rt.globals.__kix_quests_v1[q]=entry;return entry.progress;},getProgress(id){return numberOr(this.getState(id)?.progress,0);},complete(id){return this.setState(id,{state:'completed',progress:1});},reset(id){const q=String(id||'').trim(),rt=global.KixEngine?.runtime;if(!q||!rt)return false;rt.globals=rt.globals||{};rt.globals.__kix_quests_v1=rt.globals.__kix_quests_v1||{};delete rt.globals.__kix_quests_v1[q];return true;}},
        Projectiles:{configure(target,options){const ra=resolveRuntimeActor(target),v=projectileValue(ra);if(!ra||!v)return false;ra.data.collisionResponse='projectile';if(options?.damage!=null)ra.data.collisionDamage=Math.max(0,numberOr(options.damage,10));if(options?.speed!=null)ra.data.collisionProjectileSpeed=Math.max(0,numberOr(options.speed,10));v.damage=numberOr(options?.damage,numberOr(ra.data.collisionDamage,10));v.speed=numberOr(options?.speed,numberOr(ra.data.collisionProjectileSpeed,10));v.configured=true;return clone(v);},isProjectile(target){const ra=resolveRuntimeActor(target);return String(ra?.data?.collisionResponse||'')==='projectile';},getConfig(target){const ra=resolveRuntimeActor(target),v=projectileValue(ra);return ra&&v?Object.assign({damage:numberOr(ra.data.collisionDamage,0),speed:numberOr(ra.data.collisionProjectileSpeed,0),collisionResponse:String(ra.data.collisionResponse||'none')},clone(v)):null;}},
        Hitboxes:{get(target){return clone(api.collision.bounds(target));},contains(target,x,y){return !!api.collision.point(x,y,target);},overlaps(a,b){return !!api.collision.between(a,b);},setSize(target,width,height){const ra=resolveRuntimeActor(target);if(!ra?.data)return false;ra.data.width=Math.max(1,numberOr(width,64));ra.data.height=Math.max(1,numberOr(height,64));try{global.KixEngine.updateSpriteTransform?.(ra,true);}catch(_){}return{width:ra.data.width,height:ra.data.height};}},
        Checkpoints:{set(id,target){const ra=resolveRuntimeActor(target)||actor;if(!ra)return false;const rt=global.KixEngine?.runtime;if(!rt)return false;rt.checkpoint={id:String(id||'checkpoint'),x:numberOr(ra.data?.x,0),y:numberOr(ra.data?.y,0),actor:ra};return{ id:rt.checkpoint.id,x:rt.checkpoint.x,y:rt.checkpoint.y};},get(){const cp=global.KixEngine?.runtime?.checkpoint;return cp?{id:String(cp.id||'checkpoint'),x:numberOr(cp.x,0),y:numberOr(cp.y,0)}:null;},clear(){const rt=global.KixEngine?.runtime;if(!rt)return false;rt.checkpoint=null;return true;}},
        Respawn:{atCheckpoint(target){const ra=resolveRuntimeActor(target)||actor,cp=global.KixEngine?.runtime?.checkpoint;if(!ra?.data||!cp)return false;ra.data.x=numberOr(cp.x,0);ra.data.y=numberOr(cp.y,0);ra.data.vx=0;ra.data.vy=0;ra.data.visible=true;try{global.KixEngine.updateSpriteTransform?.(ra,true);}catch(_){}emitSystemEvent('respawn',{target:systemActorKey(ra),checkpoint:String(cp.id||'checkpoint')});return{ x:ra.data.x,y:ra.data.y,checkpoint:String(cp.id||'checkpoint')};}},
        'Wave System':{configure(id,options){const key=String(id||'default');const reg=systemState();reg.waves[key]=Object.assign({current:0,total:0,active:false,defeated:0},reg.waves[key]||{},clone(options||{}));return clone(reg.waves[key]);},start(id){const key=String(id||'default'),reg=systemState();reg.waves[key]=Object.assign({current:0,total:0,active:false,defeated:0},reg.waves[key]||{}, {active:true,current:Math.max(1,Math.floor(numberOr(reg.waves[key]?.current,1)))});emitSystemEvent('wave.start',{id:key,wave:reg.waves[key].current});return clone(reg.waves[key]);},next(id){const key=String(id||'default'),reg=systemState();const w=reg.waves[key];if(!w)return false;w.current+=1;w.defeated=0;w.active=Number(w.total)>0?w.current<=Number(w.total):true;emitSystemEvent('wave.next',{id:key,wave:w.current});return clone(w);},defeat(id,count=1){const w=systemState().waves[String(id||'default')];if(!w)return false;w.defeated+=Math.max(0,Math.floor(numberOr(count,1)));return clone(w);},get(id){return clone(systemState().waves[String(id||'default')]||null);},reset(id){const key=String(id||'default'),reg=systemState();delete reg.waves[key];return true;}},
        'State Machine':{define(id,initial='idle'){const key=String(id||'machine');const reg=systemState();reg.stateMachines[key]=reg.stateMachines[key]||{state:String(initial)};return clone(reg.stateMachines[key]);},get(id){return clone(systemState().stateMachines[String(id||'machine')]||null);},set(id,stateValue,meta){const key=String(id||'machine'),reg=systemState();reg.stateMachines[key]=Object.assign({},reg.stateMachines[key]||{}, {state:String(stateValue??'idle'),updatedAt:Date.now()});emitSystemEvent('state-machine.transition',{id:key,state:reg.stateMachines[key].state,meta:clone(meta||{})});return clone(reg.stateMachines[key]);},has(id,stateValue){return String(systemState().stateMachines[String(id||'machine')]?.state||'')===String(stateValue??'');},clear(id){delete systemState().stateMachines[String(id||'machine')];return true;}},
        Multiplayer:Object.assign({},api.multiplayer)
      },
      debug:{log(...a){console.log('[Kix Game API]',...a);},warn(...a){console.warn('[Kix Game API]',...a);},error(...a){console.error('[Kix Game API]',...a);},getStats(){const rt=global.KixEngine?.runtime||{};return{version:global.KixEngine?.version||'unknown',running:!!rt.running,paused:!!rt.paused,actors:Array.isArray(rt.actors)?rt.actors.length:0,coroutines:Array.isArray(rt.coroutines)?rt.coroutines.length:0,fps:Number(rt.fps)||0,frameMs:Number(rt.frameMs)||0};},collisions(v){const rt=global.KixEngine?.runtime;if(!rt)return false;rt.debugCollisions=!!v;try{global.KixEngine?.renderCollisionDebug?.();}catch(_){}return rt.debugCollisions;},fps(v){const rt=global.KixEngine?.runtime;if(!rt)return false;rt.showFps=!!v;return rt.showFps;}}
    });
    return api;
  }

  function registerLanguageRuntime(language, executor) {
    const key=String(language||'').trim().toLowerCase();
    if(!key || typeof executor!=='function') return false;
    state.languageRuntimes.set(key,executor);
    return true;
  }

  function executeGlobalRuntime(plugin) {
    if(!plugin || plugin.enabled===false) return false;
    const language=String(plugin.language||SUPPORTED_RUNTIME_LANGUAGE).toLowerCase();
    const code=String(plugin.runtime?.[language]||'').trim();
    if(!code) return false;
    const key=plugin.id+':'+String(plugin.updatedAt||'')+':'+language;
    if(state.globalRuntimeStarted.has(key)) return true;
    state.globalRuntimeStarted.add(key);
    const api=makeApi(plugin,{actor:null},null,{});
    if(language!==SUPPORTED_RUNTIME_LANGUAGE){
      const executor=state.languageRuntimes.get(language);
      if(typeof executor!=='function'){
        console.warn('[Kix Plugins] runtime global não registrado:', language, plugin.name);
        return false;
      }
      try{
        const result=executor({scope:'global',plugin,code,api,runtime:global.KixEngine?.runtime||{},now:Date.now()});
        if(result&&typeof result.then==='function') result.catch(e=>console.error('[Kix Plugin global language runtime]',plugin.name,e));
        return true;
      }catch(e){console.error('[Kix Plugin global language runtime]',plugin.name,e);return false;}
    }
    try {
      const fn=new Function('api','plugin','runtime','now','\"use strict\";\nreturn (async function(){\n'+code+'\n}).call(null);');
      const result=fn(api,clone(plugin),global.KixEngine?.runtime||{},Date.now());
      if(result&&typeof result.then==='function') result.catch(e=>console.error('[Kix Plugin global runtime]',plugin.name,e));
      return true;
    } catch(e) {
      console.error('[Kix Plugin global runtime]',plugin.name,e);
      return false;
    }
  }

  function executeBlock(co, blk, ctx, now) {
    const def=resolvePluginBlockForPersisted(blk);
    if(!def || def.enabled===false) return false;
    const plugin=getPlugin(def.pluginId);
    if(!plugin || plugin.enabled===false) return false;
    const handler=def.handler;
    if(!handler || def.enabledRuntime===false) {
      if (def.handler) console.warn('[Kix Plugins] runtime desativado:', def.handlerLanguage, def.name);
      return {handled:true};
    }
    const stateKey='_kixPluginRun';
    const active=co[stateKey];
    if(active && active.blockId===String(blk.id)){
      if(!active.done) return {handled:true,yield:true};
      co[stateKey]=null;
      if(active.error) console.error('[Kix Plugins]',active.error);
      return {handled:true};
    }
    if(def.handlerLanguage!==SUPPORTED_RUNTIME_LANGUAGE){
      const executor=state.languageRuntimes.get(def.handlerLanguage);
      if(typeof executor==='function'){
        try{
          const result=executor({plugin,def,co,blk,ctx,now,api:makeApi(plugin,co,blk,ctx),code:handler});
          if(result&&typeof result.then==='function'){
            const run={blockId:String(blk.id),done:false,error:null};
            co[stateKey]=run;
            Promise.resolve(result).then(()=>{run.done=true;}).catch(e=>{run.error=e;run.done=true;});
            return {handled:true,yield:true};
          }
          return {handled:true};
        }catch(e){
          console.error('[Kix Plugin language runtime]',plugin.name,def.name,e);
          return {handled:true};
        }
      }
      console.warn('[Kix Plugins] runtime não registrado:', def.handlerLanguage, def.name);
      return {handled:true};
    }
    let result;
    try {
      const fn=new Function('api','ctx','block','runtime','now','"use strict";\nreturn (async function(){\n'+handler+'\n}).call(null);');
      result=fn(makeApi(plugin,co,blk,ctx),ctx,blk,global.KixEngine?.runtime||{},now);
    } catch(e) {
      console.error('[Kix Plugin block]',plugin.name,def.name,e);
      return {handled:true};
    }
    if(result && typeof result.then==='function'){
      const run={blockId:String(blk.id),done:false,error:null};
      co[stateKey]=run;
      Promise.resolve(result).then(()=>{run.done=true;}).catch(e=>{run.error=e;run.done=true;});
      return {handled:true,yield:true};
    }
    return {handled:true};
  }

  function disposePluginGameApiRuntime(pluginId){try{const id=String(pluginId||''),s=state.gameApiTimers?.get(id);if(s){s.forEach(h=>{try{clearTimeout(h);clearInterval(h);}catch(_){}});s.clear();state.gameApiTimers.delete(id);}state.gameApiEvents?.delete(id);state.gameApiSystems?.delete(id);return true;}catch(_){return false;}}

  function install(raw, source) {
    const sourceKey = source || 'import';
    const plugin=normalizePlugin(raw,sourceKey);
    const existingIndex=state.plugins.findIndex(p=>p.id===plugin.id);
    const existing=existingIndex>=0 ? state.plugins[existingIndex] : null;
    if (existing?.builtin && existing?.protected && plugin.id === 'kix.catroid.compat' && sourceKey !== 'builtin') {
      state.currentPluginId=existing.id;
      return clone(existing);
    }
    if(existingIndex>=0) state.plugins.splice(existingIndex,1,plugin); else state.plugins.push(plugin);
    state.currentPluginId=plugin.id;
    refreshAttachedCategories();
    savePersistent();
    renderPluginScreens();
    return clone(plugin);
  }

  function uninstall(id) {
    const plugin = getPlugin(id);
    if (plugin?.builtin && plugin?.protected) return false;
    const before=state.plugins.length;
    disposePluginGameApiRuntime(id);
    state.plugins=state.plugins.filter(p=>p.id!==String(id));
    if(state.plugins.length===before) return false;
    if(state.currentPluginId===String(id)) state.currentPluginId=state.plugins[0]?.id || null;
    ensureBuiltinPlugins();
    refreshAttachedCategories(); savePersistent(); renderPluginScreens();
    return true;
  }

  function toggle(id,enabled) {
    const p=getPlugin(id); if(!p)return false;
    if (p.builtin && p.protected) {
      p.enabled = true;
      return false;
    }
    p.enabled=enabled!==false; if(!p.enabled) disposePluginGameApiRuntime(p.id); p.updatedAt=Date.now();
    refreshAttachedCategories(); savePersistent(); renderPluginScreens();
    return true;
  }

  function setEditorMode(enabled) {
    const on=!!enabled;
    try { localStorage.setItem(EDITOR_STORE,on?'1':'0'); } catch(_){ }
    const btn=document.getElementById('btn-kix-plugin-editor-fab');
    const home=document.getElementById('screen-home');
    const onHome=!!home && !home.classList.contains('hidden');
    if(btn) btn.classList.toggle('hidden',!(on && onHome));
    return on;
  }

  function editorMode() {
    try { return localStorage.getItem(EDITOR_STORE)==='1'; } catch(_){ return false; }
  }

  function safeExportFileName(name, fallback='kix-plugin') {
    const raw=String(name||fallback).trim() || fallback;
    return raw.replace(/[\\/:*?"<>|]/g,'_').replace(/[. ]+$/,'') || fallback;
  }

  function utf8ToBase64(text) {
    const value=String(text);
    if(typeof TextEncoder!=='function') return btoa(unescape(encodeURIComponent(value)));
    const bytes=new TextEncoder().encode(value);
    let binary='';
    for(let i=0;i<bytes.length;i+=24*1024){
      const chunk=bytes.subarray(i,i+24*1024);
      for(let j=0;j<chunk.length;j++) binary+=String.fromCharCode(chunk[j]);
    }
    return btoa(binary);
  }

  function downloadJson(name,data,extension='.kixplugin',mime='application/json') {
    try {
      const payload=JSON.stringify(data,null,2);
      const filename=safeExportFileName(name)+String(extension||'');
      // Android WebView has no reliable browser download surface for blob: URLs.
      // Route through the native document picker when the bridge exists.
      if(global.Android && typeof global.Android.beginFile==='function') {
        global.Android.beginFile(filename,mime);
        const encoded=utf8ToBase64(payload);
        for(let i=0;i<encoded.length;i+=60*1024) global.Android.appendFileChunk(encoded.slice(i,i+60*1024));
        global.Android.finishFile();
        return true;
      }
      const blob=new Blob([payload],{type:mime});
      const url=URL.createObjectURL(blob);
      const a=document.createElement('a'); a.href=url; a.download=filename;
      document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),1000);
      return true;
    } catch(e){console.error('plugin export',e);return false;}
  }

  function exportAllPlugins(){
    if(!state.plugins.length){ toast('Nenhum plugin para exportar'); return false; }
    const bundle={schema:'kix-plugin-bundle-v1',exportedAt:new Date().toISOString(),plugins:state.plugins.map(clone)};
    return downloadJson('kix-plugins',bundle,'.kixplugins.json','application/json');
  }

  function pluginTemplate() {
    return {
      schema: SCHEMA,
      id: 'meu-plugin',
      name: 'Meu Plugin',
      icon: '',
      version: '1.0.0',
      author: '',
      description: '',
      language: 'javascript',
      enabled: true,
      categories: [{id:'geral',name:'Meu Plugin',color:'#7C3AED',body:'#C4B5FD',badge:'PLUGIN',order:0}],
      blocks: [{id:'notificar',name:'Notificar {mensagem}',categoryId:'geral',useCategoryColor:true,heightY:56,multiline:false,template:'Notificar {mensagem}',example:'Olá do plugin',params:[{name:'mensagem',type:'text',default:"'Olá do plugin'",placeholder:'Mensagem'}],type:'action',handlerLanguage:'javascript',handler:"api.notify(api.params.get('mensagem','Olá'))"}],
      categoryOverrides: [],
      ui: {rules:[],inserts:[]},
      runtime: {javascript:''},
      capabilities:['ui','storage']
    };
  }

  const PLUGIN_ACTION_SVGS = {
    import:'<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 20h14"/>',
    export:'<path d="M12 21V9"/><path d="m7 12 5-5 5 5"/><path d="M5 3h14"/>',
    save:'<path d="M5 4h11l3 3v13H5z"/><path d="M8 4v6h8V4"/><path d="M8 20v-6h8v6"/>',
    delete:'<path d="M4 7h16"/><path d="M9 7V4h6v3"/><path d="M7 7v13h10V7"/><path d="M10 10v7M14 10v7"/>'
  };
  function pluginActionIconSvg(key,size=18){
    const d=PLUGIN_ACTION_SVGS[cleanId(key)]||'';
    return '<svg class="kix-plugin-action-svg" viewBox="0 0 24 24" width="'+size+'" height="'+size+'" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+d+'</svg>';
  }

  const PLUGIN_ICON_SVGS = {
    puzzle:'<path d="M8 3.5a2.5 2.5 0 1 1 4.95.5H16a2 2 0 0 1 2 2v3.05A2.5 2.5 0 1 1 18.5 14H18v4a2 2 0 0 1-2 2h-3.05A2.5 2.5 0 1 1 8 19.5V20H6a2 2 0 0 1-2-2v-4h.5A2.5 2.5 0 1 0 5 9.05H4V6a2 2 0 0 1 2-2h2v-.5Z"/>' ,
    tools:'<path d="m14.7 6.3 3-3a1.5 1.5 0 0 1 2.1 2.1l-3 3-2.7.6Z"/><path d="m14.1 8.9 1 1"/><path d="M4 7h6l1.5 2H20a1.5 1.5 0 0 1 1.5 1.5v6A2.5 2.5 0 0 1 19 19H5a2.5 2.5 0 0 1-2.5-2.5v-8A1.5 1.5 0 0 1 4 7Z"/>' ,
    brush:'<path d="m14 5 5 5-9.5 9.5H4v-5.5L14 5Z"/><path d="M13 6 18 11"/><path d="M4 20h16"/>' ,
    bolt:'<path d="m13 2-9 12h7l-1 8 9-12h-7l1-8Z"/>' ,
    code:'<path d="m8 7-5 5 5 5M16 7l5 5-5 5M14 4l-4 16"/>' ,
    database:'<ellipse cx="12" cy="5" rx="7" ry="3"/><path d="M5 5v7c0 1.7 3.1 3 7 3s7-1.3 7-3V5"/><path d="M5 12v7c0 1.7 3.1 3 7 3s7-1.3 7-3v-7"/>' ,
    music:'<path d="M9 18V6l10-2v12"/><circle cx="6" cy="18" r="3"/><circle cx="16" cy="16" r="3"/>' ,
    game:'<path d="M7 9h10a4 4 0 0 1 3.8 5.2l-1 3A2.5 2.5 0 0 1 15 18l-1.5-2h-3L9 18a2.5 2.5 0 0 1-4.8-.8l-1-3A4 4 0 0 1 7 9Z"/><path d="M8 12v4M6 14h4M16 13h.01M18 15h.01"/>' ,
    shield:'<path d="M12 3 19 6v5c0 4.4-2.8 8.3-7 10-4.2-1.7-7-5.6-7-10V6l7-3Z"/><path d="m9 12 2 2 4-4"/>' ,
    bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>'
  };
  function pluginIconSvg(key, size=18){
    const d=PLUGIN_ICON_SVGS[cleanId(key)] || PLUGIN_ICON_SVGS.puzzle;
    return '<svg class="kix-plugin-icon-svg" viewBox="0 0 24 24" width="'+size+'" height="'+size+'" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+d+'</svg>';
  }
  function isPluginImageSource(value){
    const src=String(value||'').trim();
    if(!src) return false;
    if(/^data:image\/(?:png|jpe?g|webp|gif);base64,/i.test(src)) return true;
    if(/^https:\/\//i.test(src)) return true;
    return /^(?:\.?\/?[A-Za-z0-9_./-]+\.(?:png|jpe?g|webp|gif))(?:[?#].*)?$/i.test(src);
  }
  function pluginIconImageValue(p){
    const img=String(p?.iconImage||'').trim();
    if(isPluginImageSource(img)) return img;
    const legacy=String(p?.icon||'').trim();
    if(isPluginImageSource(legacy)) return legacy;
    return '';
  }
  function pluginIconImageHtml(p,size,alt){
    const src=pluginIconImageValue(p);
    if(!src) return '<span class="kix-plugin-icon-fallback" aria-hidden="true">?</span>';
    return '<img class="kix-plugin-icon-image" src="'+esc(src)+'" width="'+size+'" height="'+size+'" alt="'+esc(alt||p?.name||'Plugin')+'" loading="lazy" decoding="async" draggable="false" onerror="this.replaceWith(Object.assign(document.createElement(\'span\'),{className:\'kix-plugin-icon-fallback\',textContent:\'?\'}))">';
  }
  function byId(id){return document.getElementById(id);}
  function esc(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

  function ensureScreenStyles() {
    if(byId('kix-plugin-runtime-style')) return;
    const s=document.createElement('style'); s.id='kix-plugin-runtime-style';
    s.textContent=`
      .kix-script-fabs .kix-fab{transition:transform .16s ease,filter .16s ease,box-shadow .16s ease;will-change:transform}
      .kix-script-fabs .kix-fab:active{transform:scale(.94)}
      .kix-script-fabs .kix-fab-editor{background:#17171d;border:1px solid #4b4b58;box-shadow:0 8px 24px #0008}
      .kix-script-fabs .kix-fab-editor:hover{filter:brightness(1.12)}
      .kix-script-fabs .kix-fab-add{background:#059669}
      .kix-plugin-hero{margin:14px 16px 4px;padding:15px;border:1px solid #303039;border-radius:16px;background:linear-gradient(135deg,#19191e,#121216);box-shadow:0 10px 28px #0003}
      .kix-plugin-hero-icon{width:40px;height:40px;border-radius:12px;display:grid;place-items:center;background:#22222a;border:1px solid #3b3b46;color:#34d399;flex:none}
      .kix-plugin-card{margin:10px 16px 0;padding:13px;border:1px solid #2f3038;border-radius:14px;background:#151518;box-shadow:0 6px 18px #0002}
      .kix-plugin-card-head{display:flex;align-items:center;gap:10px;min-width:0}
      .kix-plugin-card-icon{width:34px;height:34px;border-radius:10px;display:grid;place-items:center;background:#202027;color:#a7f3d0;border:1px solid #34343e;flex:none}
      .kix-plugin-card-actions{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px}
      .kix-editor-btn{border:1px solid #3a3a42;background:#202024;color:#d9d9de;border-radius:10px;padding:8px 11px;font-size:12px;min-height:38px;display:inline-flex;align-items:center;justify-content:center;gap:7px;transition:background .15s,border-color .15s,transform .15s}
      .kix-editor-btn:active{transform:scale(.98)}
      .kix-editor-btn.primary{background:#059669;border-color:#059669;color:#04130e}
      .kix-editor-btn.ghost{background:#19191d}
      .kix-editor-icon{width:16px;height:16px;flex:none}
      .kix-editor-field{padding:0 16px;margin-top:14px}
      .kix-editor-input,.kix-editor-select,.kix-editor-textarea{background:#1b1b20;border-color:#34343d;border-radius:11px;padding:11px 12px}
      .kix-editor-input:focus,.kix-editor-select:focus,.kix-editor-textarea:focus{border-color:#059669;box-shadow:0 0 0 2px rgba(255,255,255,.08)}
      #screen-kix-plugin-editor .kix-editor-tabs{gap:4px;padding:6px 8px;border-bottom:1px solid #2b2b32;background:#151518;box-shadow:0 4px 14px #0003}
      #screen-kix-plugin-editor .kix-editor-tabs button{border-radius:9px;padding:8px 4px;color:#777;background:transparent;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;line-height:1.1}
      #screen-kix-plugin-editor .kix-editor-tabs button.active{color:#d9fff0;background:#1f2a26;border:1px solid #285c4a;box-shadow:none}
      #screen-kix-plugin-editor .kix-editor-tabs svg{width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}
      .kix-editor-section{padding-bottom:8px}
      .kix-plugin-section-title{padding:18px 16px 8px;font-size:11px;color:#6f7078;text-transform:uppercase;letter-spacing:.08em}
      .kix-plugin-row{display:flex;align-items:center;gap:10px;padding:14px 16px;border-bottom:1px solid #2c2c2c;background:#0f0f11}
      .kix-editor-btn{border:1px solid #3a3a42;background:#202024;color:#d9d9de;border-radius:9px;padding:8px 10px;font-size:12px;min-height:36px}
      .kix-editor-btn.primary{background:#059669;border-color:#059669;color:#04130e}
      .kix-editor-input,.kix-editor-select,.kix-editor-textarea{width:100%;background:#202024;border:1px solid #393942;border-radius:9px;color:#f2f2f4;padding:10px 11px;outline:none;font-size:13px;box-sizing:border-box}
      .kix-editor-textarea{min-height:120px;resize:vertical;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;line-height:1.45}
      .kix-editor-label{font-size:11px;color:#858690;margin-bottom:5px;display:block}
      .kix-editor-field{padding:0 16px;margin-top:12px}
      .kix-editor-card{margin:10px 16px 0;padding:12px;border:1px solid #303038;border-radius:12px;background:#17171a}
      .kix-native-badge{display:inline-flex;align-items:center;padding:2px 6px;border:1px solid #4a4a52;border-radius:999px;font-size:9px;color:#9b9ca4;text-transform:uppercase;letter-spacing:.05em;margin-left:5px}
      #screen-kix-plugin-editor .kix-editor-tabs{display:flex;border-bottom:1px solid #303038;background:#18181b;position:sticky;top:0;z-index:3}
      #screen-kix-plugin-editor .kix-editor-tabs button{flex:1;padding:10px 4px;background:none;border:0;color:#777;font-size:11px}
      #screen-kix-plugin-editor .kix-editor-tabs button.active{color:#34d399;border-bottom:2px solid #059669}
      .kix-plugin-icon-svg{display:block;flex:none}
      .kix-plugin-manager-screen *, #screen-kix-plugin-editor *{font-weight:400 !important;font-family:'Inter',system-ui,sans-serif !important;}
      .kix-plugin-manager-screen{position:relative;background-color:#292a2c;background-image:radial-gradient(circle at 10% 8%,rgba(255,255,255,.035) 0 1px,transparent 1.6px),radial-gradient(circle at 86% 16%,rgba(255,255,255,.025) 0 1px,transparent 1.5px),repeating-linear-gradient(115deg,rgba(255,255,255,.012) 0 1px,transparent 1px 7px),linear-gradient(160deg,#2d2e30 0%,#242527 48%,#202123 100%);background-size:23px 23px,31px 31px,13px 13px,100% 100%;}
      .kix-plugin-manager-header{min-height:76px;padding:calc(25px + env(safe-area-inset-top,0px)) 15px 11px;background:rgba(31,32,34,.82);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border-bottom:1px solid rgba(255,255,255,.065);box-shadow:0 5px 18px rgba(0,0,0,.14);gap:9px;z-index:3;}
      .kix-plugin-back-btn{width:38px;height:38px;border:0;border-radius:12px;background:transparent;color:#9c9da2;display:grid;place-items:center;flex:none;transition:background .16s,color .16s,transform .16s;}
      .kix-plugin-back-btn:active{background:rgba(255,255,255,.05);transform:scale(.95);}
      .kix-plugin-manager-title{font-size:19px;font-weight:400;line-height:1.05;letter-spacing:-.025em;color:#ededee;}
      .kix-plugin-icon-fallback{display:grid;place-items:center;width:100%;height:100%;font-size:22px;font-weight:400;color:#d5d6d8;line-height:1;}
      .kix-plugin-manager-count{margin-top:4px;font-size:11px;color:#85868c;font-weight:400;letter-spacing:.015em;}
      .kix-plugin-manager-scroll{padding:0 0 0;scrollbar-width:thin;overscroll-behavior:contain;}
      #screen-kix-plugins #kix-plugins-list{padding:13px 15px 0;}
      .kix-plugin-list-label{padding:4px 4px 10px;color:#76787e;font-size:10px;font-weight:400;letter-spacing:.14em;}
      .kix-plugin-empty-state{min-height:calc(100dvh - 160px);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:42px 24px;text-align:center;color:#84868c;}
      .kix-plugin-empty-mark{width:68px;height:68px;border-radius:22px;display:grid;place-items:center;border:1px solid rgba(255,255,255,.1);background:#2f3034;color:#a5a7ad;font-size:31px;font-weight:300;box-shadow:0 10px 26px rgba(0,0,0,.18),inset 0 1px 0 rgba(255,255,255,.04);}
      .kix-plugin-empty-title{margin-top:14px;color:#d0d1d4;font-size:15px;font-weight:400;}
      .kix-plugin-empty-meta{margin-top:4px;color:#74767c;font-size:11px;}
      .kix-plugin-manager-bottom-space{height:92px;}
      .kix-plugin-import-fab{position:absolute;right:17px;bottom:calc(18px + env(safe-area-inset-bottom,0px));width:58px;height:58px;border:0;border-radius:50%;background:#059669;color:#ecfff7;font-size:31px;font-weight:300;line-height:1;display:grid;place-items:center;z-index:20;box-shadow:0 12px 26px rgba(0,0,0,.34),0 0 0 1px rgba(255,255,255,.08);transition:transform .16s,filter .16s,box-shadow .16s;}
      .kix-plugin-import-fab:active{transform:scale(.91);filter:brightness(.95);box-shadow:0 7px 17px rgba(0,0,0,.3),0 0 0 1px rgba(255,255,255,.06);}
      .kix-plugin-import-fab:focus-visible{outline:2px solid #b4ffe1;outline-offset:4px;}
      .kix-plugin-import-fab{width:60px;height:60px;padding:15px;background:#353638;border:1px solid #44464b;box-shadow:0 12px 26px rgba(0,0,0,.34),0 0 0 1px rgba(255,255,255,.08);}
      .kix-plugin-import-fab img{width:28px;height:28px;object-fit:contain;display:block;}
      .kix-plugin-empty-mark img{width:30px;height:30px;object-fit:contain;display:block;}
      .kix-plugin-empty-meta{min-height:4px;}
      #screen-kix-plugin-editor{background:#111214 !important;}
      #screen-kix-plugin-editor > .bg-\[\#262626\]{background:#1c1d20 !important;border-bottom:1px solid #303238;}
      #screen-kix-plugin-editor .kix-editor-tabs{padding:5px 8px;background:#17181a;border-bottom:1px solid #2f3034;box-shadow:none;}
      #screen-kix-plugin-editor #kix-plugin-save-template{background:#353638 !important;border:0 !important;border-radius:0 !important;}
      #screen-kix-plugin-editor #kix-plugin-save-template svg,#screen-kix-plugin-editor #kix-plugin-delete svg,#screen-kix-plugin-editor #kix-plugin-enable svg{display:block;margin:auto;}
      #screen-kix-plugin-editor .kix-editor-tabs button{min-height:50px;border-radius:9px;color:#81838a;gap:4px;}
      #screen-kix-plugin-editor .kix-editor-tabs button.active{color:#dffcef;background:#202723;border:1px solid #315646;}
      .kix-editor-profile-card{margin:14px 16px 4px;padding:14px;border-radius:16px;border:1px solid #303238;background:#191a1d;display:flex;align-items:center;gap:13px;}
      .kix-editor-profile-icon{width:72px;height:72px;border-radius:16px;overflow:hidden;background:#27292c;border:1px solid #3a3c42;display:grid;place-items:center;flex:0 0 72px;}
      .kix-editor-profile-icon .kix-plugin-icon-image{width:100%;height:100%;object-fit:cover;}
      .kix-editor-profile-meta{min-width:0;}
      .kix-editor-profile-name{font-size:18px;font-weight:680;color:#f0f1f2;line-height:1.15;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
      .kix-editor-profile-description{margin-top:6px;font-size:12px;color:#8f9299;line-height:1.42;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;overflow:hidden;}
      .kix-editor-image-card{margin:14px 16px 0;padding:13px;border:1px solid #303238;border-radius:14px;background:#191a1d;display:grid;grid-template-columns:1fr;gap:10px;}
      .kix-editor-image-head{display:flex;align-items:center;justify-content:space-between;gap:12px;}
      .kix-editor-image-title{font-size:12px;color:#a8aab0;}
      .kix-editor-image-preview{width:74px;height:74px;border-radius:14px;overflow:hidden;background:#25272b;border:1px solid #393b42;display:grid;place-items:center;}
      .kix-editor-image-preview .kix-plugin-icon-image{width:100%;height:100%;object-fit:cover;}
      .kix-editor-image-controls{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center;}
      .kix-editor-file{width:100%;font-size:11px;color:#a2a4aa;min-height:38px;}
      .kix-editor-save-main{margin:15px 16px 18px;width:calc(100% - 32px);min-height:46px;font-size:13px;font-weight:600;}
      .kix-editor-save-main img{width:18px;height:18px;object-fit:contain;}
      .kix-editor-btn.ghost{background:#1c1d20;}
      @media (max-width:380px){.kix-editor-image-controls{grid-template-columns:1fr}.kix-editor-profile-icon{width:64px;height:64px;flex-basis:64px}.kix-editor-profile-name{font-size:16px}}

      /* Plugin manager mirrors the object list: icon, name, overflow menu. */
      #screen-kix-plugins .kix-plugin-manager-screen{background:#1f1f1f;}
      #screen-kix-plugins .kix-plugin-manager-header{background:#262626;border-bottom:1px solid #34343a;backdrop-filter:none;-webkit-backdrop-filter:none;box-shadow:none;}
      #screen-kix-plugins .kix-plugin-manager-scroll{padding:4px 0 0;}
      #screen-kix-plugins #kix-plugins-list{padding:0 12px 96px;}
      #screen-kix-plugins .kix-plugin-list-label{display:none;}
      .kix-plugin-object-row{position:relative;display:flex;align-items:center;gap:12px;min-height:64px;padding:7px 8px;margin:0 0 7px;border:1px solid #44464b;border-radius:11px;background:#353638;box-shadow:none;touch-action:none;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none;}
      .kix-plugin-object-row:active{filter:brightness(.97);}
      .kix-plugin-object-icon{width:46px;height:46px;border-radius:8px;display:grid;place-items:center;overflow:hidden;flex:0 0 46px;background:#3f4043;border:1px solid #55565b;color:#d0d1d3;}
      .kix-plugin-object-icon .kix-plugin-icon-image{width:100%;height:100%;display:block;object-fit:cover;}
      .kix-plugin-object-name{min-width:0;flex:1;color:#f1f1f2;font-size:15px;font-weight:400;line-height:1.2;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
      .kix-plugin-object-row.is-disabled .kix-plugin-object-name{color:#8c8d93;}
      .kix-plugin-object-menu{width:40px;height:40px;min-width:40px;border:0;border-radius:9px;background:#414246;color:#c3c4c7;display:inline-flex;align-items:center;justify-content:center;padding:0;font-size:21px;line-height:1;}
      .kix-plugin-object-menu:active{background:#3d3e43;}
      .kix-plugin-mini-menu{position:fixed;z-index:var(--kix-z-modal);min-width:190px;max-width:min(260px,calc(100vw - 24px));padding:5px;background:#292a2d;border:1px solid #41434a;border-radius:12px;box-shadow:0 14px 34px rgba(0,0,0,.42);}
      .kix-plugin-mini-title{padding:8px 10px 7px;color:#777980;font-size:10px;text-transform:uppercase;letter-spacing:.08em;border-bottom:1px solid #38393f;margin-bottom:3px;}
      .kix-plugin-mini-action{width:100%;min-height:42px;padding:9px 11px;border:0;border-radius:8px;background:#292a2d;color:#e1e2e5;text-align:left;font-size:13px;display:flex;align-items:center;gap:9px;}
      .kix-plugin-mini-action:active{background:#35363b;}
      .kix-plugin-mini-action.danger{color:#ff9f9f;}
      .kix-plugin-mini-state{margin-left:auto;color:#6edbb0;font-size:10px;}
      .kix-plugin-sort-placeholder{height:64px;border:1px dashed #4b4d53;border-radius:11px;background:#252629;margin:0 0 7px;}
      .kix-plugin-object-row.kix-sortable-dragging{opacity:.55!important;box-shadow:0 10px 22px rgba(0,0,0,.28)!important;}
      @media(max-width:360px){.kix-plugin-object-row{min-height:60px;gap:10px}.kix-plugin-object-icon{width:42px;height:42px;flex-basis:42px}.kix-plugin-object-menu{width:38px;height:38px;min-width:38px}}
      @keyframes kixPluginCardIn{from{opacity:0;transform:translateY(8px) scale(.99)}to{opacity:1;transform:translateY(0) scale(1)}}
      .kix-step{min-width:0;padding:9px 8px;border:1px solid #2F3139;border-radius:11px;background:#14161A;display:flex;gap:7px;align-items:flex-start}
      .kix-step>span{width:19px;height:19px;border-radius:50%;display:grid;place-items:center;background:#1B5B49;color:#CFF8E7;font-size:9px;font-weight:700;flex:none}
      .kix-step strong{font-size:10px;color:#E4E6E9;display:block}
      .kix-step small{display:block;color:#737681;font-size:9px;line-height:1.35;margin-top:2px}
      .kix-editor-group-title{margin:17px 16px 4px;color:#8C909A;font-size:10px;letter-spacing:.08em;text-transform:uppercase;display:flex;align-items:center;gap:6px}
      .kix-editor-note{font-size:11px;line-height:1.5;color:#888C96}
      #screen-kix-plugins #kix-plugins-list{padding-bottom:18px}
      #screen-kix-plugin-editor #kix-plugin-editor-content{overscroll-behavior:contain}
      #screen-kix-plugin-editor .kix-editor-tabs button{min-width:0}
      #screen-kix-plugin-editor .kix-editor-tabs button span{white-space:nowrap}
      .kix-chip{display:inline-flex;align-items:center;gap:5px;padding:6px 9px;border:1px solid #3a3a42;border-radius:8px;color:#c9c9ce;font-size:11px;margin:4px 4px 0 0;background:#202024}
      .kix-plugin-multiline .blk-label{white-space:pre-line;line-height:1.25}
    `;
    document.head.appendChild(s);
  }

  function dismissEditorTransientMenus() {
    // Resource selectors and contextual menus are mounted on <body>. If the
    // Plugin Editor is opened while one is visible, it can otherwise stay above
    // the editor because it has a higher z-index than the editor screen. Close
    // the transient UI rather than changing its persistent state.
    try {
      document.querySelectorAll(
        '.kix-inline-dropdown, .kix-plugin-mini-menu, .kix-formula-category-menu, .kix-data-mini-menu, #kix-data-screen-menu'
      ).forEach(el => { try { el.remove(); } catch (_) {} });
      document.querySelectorAll('.param.dropdown.kix-dropdown-active').forEach(el => {
        el.classList.remove('kix-dropdown-active');
        el.setAttribute('aria-expanded','false');
      });
      try { global._kixSelectorTarget = null; } catch (_) {}
      document.querySelectorAll('.ctx-menu.open').forEach(el => el.classList.remove('open'));
      document.querySelectorAll('.sheet.open').forEach(el => el.classList.remove('open'));
      byId('sheet-backdrop')?.classList.remove('open');
    } catch (_) {}
  }

  function showScreen(name) {
    closeAllPluginEditorDropdowns();
    if (name === 'kix-plugin-editor') {
      dismissEditorTransientMenus();
      document.body.classList.add('kix-plugin-editor-open');
    } else {
      document.body.classList.remove('kix-plugin-editor-open');
    }
    try { global.show?.(name); } catch(_) {
      document.querySelectorAll('[id^="screen-"]').forEach(x=>{x.classList.add('hidden');x.hidden=true;x.setAttribute('aria-hidden','true');x.style.pointerEvents='none';});
      const active=byId('screen-'+name);
      if(active){active.classList.remove('hidden');active.hidden=false;active.setAttribute('aria-hidden','false');active.style.pointerEvents='auto';}
    }
    if (name === 'kix-plugin-editor') dismissEditorTransientMenus();
  }

  function closePluginMiniMenu() {
    // All editor overflow menus are body-mounted. Remove both the manager menu
    // and object-editor menus, and always dispose their document listeners.
    try { document.querySelectorAll('body > .kix-plugin-mini-menu').forEach(el => el.remove()); } catch (_) {}
    if (global.__kixPluginMiniMenuCleanup) {
      try { global.__kixPluginMiniMenuCleanup(); } catch (_) {}
      global.__kixPluginMiniMenuCleanup = null;
    }
  }

  function openPluginMiniMenu(plugin, anchor) {
    closePluginMiniMenu();
    if (!plugin || !anchor) return;
    const menu = document.createElement('div');
    menu.id = 'kix-plugin-mini-menu';
    menu.className = 'kix-plugin-mini-menu';
    menu.setAttribute('role','menu');
    const title = document.createElement('div');
    title.className = 'kix-plugin-mini-title';
    title.textContent = plugin.name || 'Plugin';
    menu.appendChild(title);

    const action = (label, fn, danger=false) => {
      const b = document.createElement('button');
      b.type='button'; b.className='kix-plugin-mini-action' + (danger ? ' danger' : '');
      b.setAttribute('role','menuitem'); b.textContent = label;
      b.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); closePluginMiniMenu(); fn(); });
      menu.appendChild(b);
      return b;
    };
    action(plugin.enabled ? 'Desativar' : 'Ativar', () => {
      state.currentPluginId = plugin.id;
      toggle(plugin.id, !plugin.enabled);
    });
    action('Excluir', () => {
      state.currentPluginId = plugin.id;
      global.askConfirm?.('Excluir plugin', 'Excluir este Kix Plugin?', () => uninstall(plugin.id));
    }, true);
    action('Exportar este plugin', () => {
      state.currentPluginId = plugin.id;
      downloadJson(plugin.name, plugin);
    });

    document.body.appendChild(menu);
    const r = anchor.getBoundingClientRect();
    const w = Math.min(260, Math.max(190, window.innerWidth - 24));
    menu.style.width = w + 'px';
    const h = menu.offsetHeight;
    let left = r.right - w;
    let top = r.bottom + 6;
    if (left < 12) left = 12;
    if (left + w > window.innerWidth - 12) left = window.innerWidth - w - 12;
    if (top + h > window.innerHeight - 12) top = Math.max(12, r.top - h - 6);
    menu.style.left = Math.round(left) + 'px';
    menu.style.top = Math.round(top) + 'px';

    const outside = e => {
      if (!menu.contains(e.target) && e.target !== anchor && !anchor.contains(e.target)) closePluginMiniMenu();
    };
    const escape = e => { if (e.key === 'Escape') closePluginMiniMenu(); };
    document.addEventListener('pointerdown', outside, true);
    document.addEventListener('keydown', escape, true);
    global.__kixPluginMiniMenuCleanup = () => {
      document.removeEventListener('pointerdown', outside, true);
      document.removeEventListener('keydown', escape, true);
    };
  }

  function renderPluginManager(){
    const list=byId('kix-plugins-list'); if(!list)return;
    closePluginMiniMenu();
    if (list._pluginSortable && typeof list._pluginSortable.destroy === 'function') {
      try { list._pluginSortable.destroy(); } catch (_) {}
    }
    list._pluginSortable = null;
    list.innerHTML='';
    const total=state.plugins.length;
    const enabled=state.plugins.filter(p=>p.enabled !== false).length;
    const count=byId('kix-plugin-manager-count');
    if(count) count.textContent=total ? (total+' instalado'+(total===1?'':'s')+' · '+enabled+' ativo'+(enabled===1?'':'s')) : 'Nenhum instalado';
    if(!total){
      const empty=document.createElement('div'); empty.className='kix-plugin-empty-state';
      const mark=document.createElement('div'); mark.className='kix-plugin-empty-mark'; mark.innerHTML=pluginActionIconSvg('import',30);
      const title=document.createElement('div'); title.className='kix-plugin-empty-title'; title.textContent='Nenhum plugin baixado';
      const meta=document.createElement('div'); meta.className='kix-plugin-empty-meta'; meta.textContent='Use o botão + para importar um plugin';
      empty.append(mark,title,meta); list.appendChild(empty);
      return;
    }
    state.plugins.forEach((p,index)=>{
      const row=document.createElement('div');
      row.className='kix-plugin-object-row'+(p.enabled === false?' is-disabled':'');
      row.dataset.pluginId=String(p.id);
      row.dataset.index=String(index);
      const icon=document.createElement('div');
      icon.className='kix-plugin-object-icon';
      icon.innerHTML=pluginIconImageHtml(p,46,p.name);
      const name=document.createElement('span');
      name.className='kix-plugin-object-name';
      name.textContent=p.name || 'Plugin';
      const menu=document.createElement('button');
      menu.type='button'; menu.className='kix-plugin-object-menu'; menu.setAttribute('aria-label','Opções de '+(p.name||'plugin')); menu.title='Opções'; menu.innerHTML=kixPluginSvgIcon('more',18);
      menu.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();openPluginMiniMenu(p,menu);});
      row.append(icon,name,menu);
      list.appendChild(row);
    });
    if (global.Sortable && list.children.length) {
      try {
        list._pluginSortable = global.Sortable.create(list, {
          draggable: '.kix-plugin-object-row',
          filter: '.kix-plugin-object-menu,button,input,select,textarea,[contenteditable="true"]',
          delay: 120,
          delayOnTouchOnly: true,
          forceFallback: true,
          fallbackTolerance: 5,
          touchStartThreshold: 5,
          animation: 120,
          ghostClass: 'kix-sortable-dragging',
          onEnd: function() {
            try {
              const orderedIds = Array.from(list.querySelectorAll('.kix-plugin-object-row')).map(r=>String(r.dataset.pluginId||'')).filter(Boolean);
              const byId = new Map(state.plugins.map(p=>[String(p.id),p]));
              const ordered = orderedIds.map(id=>byId.get(id)).filter(Boolean);
              const remainder = state.plugins.filter(p=>!ordered.includes(p));
              state.plugins = ordered.concat(remainder);
              refreshAttachedCategories();
              savePersistent();
              renderPluginManager();
            } catch (e) { console.warn('plugin reorder', e); renderPluginManager(); }
          }
        });
      } catch (e) { console.warn('plugin sortable', e); }
    }
  }

  let activeEditorDropdown = null;
  function closePluginEditorDropdown(){
    const active = activeEditorDropdown;
    activeEditorDropdown = null;
    if(!active) return;
    try { active.menu.remove(); } catch(_) {}
    try { active.button.setAttribute('aria-expanded','false'); } catch(_) {}
    try { active.wrap.classList.remove('kix-editor-select-open'); } catch(_) {}
  }
  function closeAllPluginEditorDropdowns(){
    closePluginEditorDropdown();
    closePluginMiniMenu();
    try { document.querySelectorAll('#screen-kix-plugin-editor .kix-editor-select-native').forEach(el=>el.blur()); } catch(_) {}
  }
  function syncPluginEditorSelect(select,button,options){
    const opt=(options||[]).find(o=>String(o.value??'')===String(select.value));
    const label=button.querySelector('.kix-editor-select-label');
    if(label) label.textContent=String(opt?.label??select.value??'');
    if(activeEditorDropdown?.select===select){
      activeEditorDropdown.rows.forEach(row=>{ const yes=String(row.dataset.value)===String(select.value); row.classList.toggle('selected',yes); row.setAttribute('aria-selected',yes?'true':'false'); });
    }
  }
  function openPluginEditorDropdown(select,button,wrap,options){
    if(activeEditorDropdown?.select === select){ closePluginEditorDropdown(); return; }
    closePluginEditorDropdown();
    const menu=document.createElement('div');
    menu.className='kix-editor-select-menu';
    menu.setAttribute('role','listbox');
    menu.setAttribute('aria-label',select.getAttribute('aria-label')||'Selecionar');
    const r=button.getBoundingClientRect();
    const width=Math.max(180,Math.min(420,Math.max(r.width,window.innerWidth-24)));
    menu.style.width=Math.round(width)+'px';
    const rows=[];
    options.forEach(opt=>{
      const row=document.createElement('button'); row.type='button'; row.className='kix-editor-select-option';
      row.setAttribute('role','option'); row.dataset.value=String(opt.value??''); row.textContent=String(opt.label??opt.value??'');
      if(String(select.value)===String(opt.value??'')){ row.classList.add('selected'); row.setAttribute('aria-selected','true'); }
      row.addEventListener('click',e=>{
        e.preventDefault(); e.stopPropagation();
        select.value=String(opt.value??'');
        try { select.dispatchEvent(new Event('input',{bubbles:true})); } catch(_) {}
        try { select.dispatchEvent(new Event('change',{bubbles:true})); } catch(_) {}
        syncPluginEditorSelect(select,button,options);
        closePluginEditorDropdown();
      });
      menu.appendChild(row); rows.push(row);
    });
    menu.style.zIndex='var(--kix-z-dropdown)';
    menu.style.pointerEvents='auto';
    document.body.appendChild(menu);
    const h=menu.offsetHeight;
    let left=Math.max(12,Math.min(window.innerWidth-width-12,r.left));
    let top=r.bottom+5;
    if(top+h>window.innerHeight-12) top=Math.max(12,r.top-h-5);
    menu.style.left=Math.round(left)+'px'; menu.style.top=Math.round(top)+'px';
    button.setAttribute('aria-expanded','true'); wrap.classList.add('kix-editor-select-open');
    activeEditorDropdown={select,button,wrap,menu,options,rows};
  }
  function makePluginEditorSelect(select, options){
    if(!select || select.dataset.kixCustomSelect==='1') return;
    select.dataset.kixCustomSelect='1';
    select.classList.add('kix-editor-select-native');
    const wrap=select.parentElement;
    if(!wrap) return;
    const button=document.createElement('button');
    button.type='button'; button.className='kix-editor-select-button';
    button.setAttribute('aria-haspopup','listbox'); button.setAttribute('aria-expanded','false');
    button.innerHTML='<span class="kix-editor-select-label"></span>'+kixPluginSvgIcon('chevron',16);
    button.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();openPluginEditorDropdown(select,button,wrap,options||[]);});
    wrap.insertBefore(button,select);
    syncPluginEditorSelect(select,button,options||[]);
    select.addEventListener('change',()=>syncPluginEditorSelect(select,button,options||[]));
    select.addEventListener('input',()=>syncPluginEditorSelect(select,button,options||[]));
  }
  function upgradePluginEditorSelects(root){
    const scope=root||document;
    scope.querySelectorAll('#screen-kix-plugin-editor select.kix-editor-select:not([data-kix-custom-select="1"])').forEach(select=>{
      const options=Array.from(select.options).map(o=>({value:o.value,label:o.textContent}));
      makePluginEditorSelect(select,options);
    });
  }
  function field(label,value,type='text',attrs={}){
    const wrap=document.createElement('div'); wrap.className='kix-editor-field';
    const l=document.createElement('label'); l.className='kix-editor-label'; l.textContent=label; wrap.appendChild(l);
    let input;
    if(type==='textarea'){input=document.createElement('textarea');input.className='kix-editor-textarea';}
    else if(type==='select'){input=document.createElement('select');input.className='kix-editor-select';(attrs.options||[]).forEach(o=>{const opt=document.createElement('option');opt.value=o.value;opt.textContent=o.label;input.appendChild(opt);});}
    else {input=document.createElement('input');input.type=type;input.className='kix-editor-input'; if(type==='color'){input.style.padding='4px';input.style.height='42px';}}
    if(value!==undefined) input.value=String(value??'');
    Object.entries(attrs||{}).forEach(([k,v])=>{if(k==='options')return; if(k==='checked')input.checked=!!v; else if(k.startsWith('data-'))input.setAttribute(k,v);});
    wrap.appendChild(input);
    if(type==='select') makePluginEditorSelect(input,attrs.options||[]);
    return {wrap,input};
  }

  function ensureEditorPreviewStyles(){
    if(document.getElementById('kix-plugin-editor-preview-style')) return;
    const style=document.createElement('style');
    style.id='kix-plugin-editor-preview-style';
    style.textContent=`
      .kix-editor-live-preview{margin:10px 16px 14px;padding:14px;background:#121417;border:0;border-radius:10px;}
      .kix-editor-live-preview-title{font-size:11px;color:#8b8d94;margin-bottom:10px;letter-spacing:.03em;}
      .kix-editor-live-preview-stage{min-height:74px;display:flex;align-items:center;justify-content:flex-start;overflow:hidden;}
      .kix-editor-live-preview .pc-block{margin:8px 14px 8px 20px!important;max-width:calc(100% - 34px);width:auto!important;min-height:48px!important;}
      .kix-editor-live-preview-category{width:100%;box-sizing:border-box;cursor:default;}
      .kix-editor-live-preview-meta{margin-top:8px;font-size:10px;color:#73767e;}
    `;
    document.head.appendChild(style);
  }

  function renderLiveBlockPreview(host,b,opts={}){
    ensureEditorPreviewStyles();
    host.innerHTML='';
    const wrap=document.createElement('section'); wrap.className='kix-editor-live-preview'+(opts.compact?' compact':'');
    const title=document.createElement('div'); title.className='kix-editor-live-preview-title'; title.textContent=opts.compact?'1:1':'Pré-visualização 1:1 do bloco';
    const stage=document.createElement('div'); stage.className='kix-editor-live-preview-stage';
    const brick=document.createElement('div'); brick.className='pc-block';
    const cat=getCategoryPresentation(persistPreviewPluginId(b),b.categoryId);
    brick.style.background=b.useCategoryColor ? (cat?.color||b.color||'#64748B') : (b.color||'#64748B');
    const previewMeta = Object.assign({}, b, { suppressDropdown: true });
    brick.innerHTML=typeof global.buildBlockLabelHtml==='function' ? global.buildBlockLabelHtml(b.name,b.params||[],Object.fromEntries((b.params||[]).map(x=>[x.name,x.default||''])),true,previewMeta) : '<span class="blk-label"></span>';
    if(!brick.textContent.trim()) brick.textContent=b.name;
    stage.appendChild(brick); wrap.append(title,stage);
    if(!opts.compact){ const meta=document.createElement('div'); meta.className='kix-editor-live-preview-meta'; meta.textContent=(b.type||'action')+' · '+(b.params?.length||0)+' parâmetro(s)'; wrap.appendChild(meta); }
    host.appendChild(wrap);
  }

  function persistPreviewPluginId(block){ return String(block?.pluginId || state.currentPluginId || ''); }

  function clearEditorDraft(){
    if(state.editorSaveTimer){ clearTimeout(state.editorSaveTimer); state.editorSaveTimer=null; }
    state.editingKind=null; state.editingId=null; state.editorDraft=null;
  }

  function getEditingTarget(p,kind,id){
    if(!p) return null;
    const key=String(id||'');
    return kind==='category' ? p.categories.find(x=>String(x.id)===key) || null : p.blocks.find(x=>String(x.id)===key) || null;
  }

  function startObjectEditor(p,kind,id){
    const target=getEditingTarget(p,kind,id); if(!target) return false;
    state.editingKind=kind; state.editingId=String(id); state.editorDraft=clone(target);
    state.currentSection=kind==='category'?'category-edit':'block-edit';
    renderPluginEditor();
    return true;
  }

  function syncDraftToPlugin(p,kind,draft){
    const target=getEditingTarget(p,kind,draft?.id); if(!target) return false;
    Object.keys(target).forEach(k=>{ if(!Object.prototype.hasOwnProperty.call(draft,k)) delete target[k]; });
    Object.assign(target,clone(draft));
    target.pluginId=p.id;
    if(kind==='category') normalizeCategoryOrder(p);
    return true;
  }

  function queueEditorDraftSave(){
    const p=getPlugin(state.currentPluginId);
    if(!p || !state.editorDraft || !state.editingKind) return;
    syncDraftToPlugin(p,state.editingKind,state.editorDraft);
    state.editorSaveTimer && clearTimeout(state.editorSaveTimer);
    state.editorSaveTimer=setTimeout(()=>{
      state.editorSaveTimer=null;
      try { refreshAttachedCategories(); savePersistent(); } catch(e){ console.warn('Kix editor autosave',e); }
      const status=byId('kix-plugin-editor-status');
      if(status) status.textContent=(p.enabled?'Ativado':'Desativado')+' · '+p.name+' · Salvo automaticamente';
    },220);
  }

  function commitEditorDraft(){
    const p=getPlugin(state.currentPluginId);
    if(!p || !state.editorDraft || !state.editingKind) return false;
    if(state.editorSaveTimer){ clearTimeout(state.editorSaveTimer); state.editorSaveTimer=null; }
    const ok=syncDraftToPlugin(p,state.editingKind,state.editorDraft);
    if(ok){ refreshAttachedCategories(); savePersistent(); }
    clearEditorDraft();
    return ok;
  }

  function makeColorWheel(value,onChange,label){
    const wrap=document.createElement('div'); wrap.className='kix-color-field';
    const text=document.createElement('div'); text.className='kix-editor-label'; text.textContent=label||'Cor';
    const row=document.createElement('div'); row.className='kix-color-row';
    const button=document.createElement('button'); button.type='button'; button.className='kix-color-wheel'; button.setAttribute('aria-label',(label||'Cor')+' — abrir seletor');
    const inner=document.createElement('span'); inner.className='kix-color-wheel-inner'; button.appendChild(inner);
    const input=document.createElement('input'); input.type='color'; input.className='kix-color-native-input'; input.value=/^#[0-9a-f]{6}$/i.test(String(value||''))?String(value):'#64748B';
    const hex=document.createElement('code'); hex.className='kix-color-hex';
    const update=(emit=true)=>{ const v=input.value; button.style.setProperty('--wheel-value',v); inner.style.background=v; hex.textContent=v.toUpperCase(); if(emit && typeof onChange==='function') onChange(v); };
    button.onclick=()=>input.click(); input.addEventListener('input',()=>update(true)); update(false);
    row.append(button,hex,input); wrap.append(text,row); return {wrap,input,update};
  }

  function renderEditorObjectMenu(anchor,p,kind,id){
    closePluginMiniMenu();
    const menu=document.createElement('div'); menu.className='kix-plugin-mini-menu kix-object-edit-menu'; menu.setAttribute('role','menu');
    const add=(label,fn,danger=false)=>{ const b=document.createElement('button'); b.type='button'; b.className='kix-plugin-mini-action'+(danger?' danger':''); b.textContent=label; b.onclick=e=>{e.preventDefault();e.stopPropagation();closePluginMiniMenu();fn();}; menu.appendChild(b); };
    add('Editar',()=>startObjectEditor(p,kind,id));
    const arr=kind==='category'?p.categories:p.blocks; const idx=arr.findIndex(x=>String(x.id)===String(id));
    add('Subir',()=>{if(moveItem(arr,idx,-1)){normalizeCategoryOrder(p);refreshAttachedCategories();savePersistent();renderPluginEditor();}});
    add('Descer',()=>{if(moveItem(arr,idx,1)){normalizeCategoryOrder(p);refreshAttachedCategories();savePersistent();renderPluginEditor();}});
    add('Excluir',()=>{
      const target=arr.find(x=>String(x.id)===String(id)); if(!target)return;
      if(kind==='category'){
        if(p.categories.length<=1){toast('O plugin precisa manter pelo menos uma categoria.');return;}
        global.askConfirm?.('Excluir categoria', 'Excluir esta categoria? Os blocos serão movidos para outra categoria.', () => {
          const fallback=p.categories.find(x=>String(x.id)!==String(id))?.id||'';
          p.blocks.forEach(b=>{if(String(b.categoryId)===String(id))b.categoryId=fallback;});
          p.categories=p.categories.filter(x=>String(x.id)!==String(id));
          normalizeCategoryOrder(p); refreshAttachedCategories(); savePersistent(); renderPluginEditor();
        });
      } else {
        global.askConfirm?.('Excluir bloco', 'Excluir este bloco do plugin?', () => {
          p.blocks=p.blocks.filter(x=>String(x.id)!==String(id));
          refreshAttachedCategories(); savePersistent(); renderPluginEditor();
        });
      }
    },true);
    document.body.appendChild(menu); const r=anchor.getBoundingClientRect(); const w=Math.min(230,Math.max(190,window.innerWidth-24)); menu.style.width=w+'px';
    const h=menu.offsetHeight; let left=r.right-w; let top=r.bottom+6; if(left<12)left=12; if(left+w>window.innerWidth-12)left=window.innerWidth-w-12; if(top+h>window.innerHeight-12)top=Math.max(12,r.top-h-6); menu.style.left=Math.round(left)+'px'; menu.style.top=Math.round(top)+'px';
    const outside=e=>{if(!menu.contains(e.target)&&e.target!==anchor&&!anchor.contains(e.target))closePluginMiniMenu();}; const escape=e=>{if(e.key==='Escape')closePluginMiniMenu();}; document.addEventListener('pointerdown',outside,true);document.addEventListener('keydown',escape,true); global.__kixPluginMiniMenuCleanup=()=>{document.removeEventListener('pointerdown',outside,true);document.removeEventListener('keydown',escape,true);};
  }

  function makeEditorObjectRow(p,kind,item){
    const row=document.createElement('article'); row.className='kix-editor-object-row'; row.dataset.id=item.id;
    const preview=document.createElement('div'); preview.className='kix-editor-object-preview';
    if(kind==='category') renderLiveCategoryPreview(preview,{name:item.name,color:item.color,body:item.body,badge:item.badge,family:item.family,compact:true});
    else renderLiveBlockPreview(preview,item,{compact:true});
    const meta=document.createElement('div'); meta.className='kix-editor-object-meta';
    const name=document.createElement('div'); name.className='kix-editor-object-name'; name.textContent=item.name||'Sem nome';
    const sub=document.createElement('div'); sub.className='kix-editor-object-sub'; sub.textContent=(kind==='category'?'Categoria':'Bloco')+' · '+String(item.id||'');
    meta.append(name,sub);
    const menu=document.createElement('button'); menu.type='button'; menu.className='kix-editor-object-menu'; menu.innerHTML=kixPluginSvgIcon('more',18); menu.setAttribute('aria-label','Opções de '+(item.name||''));
    menu.onclick=e=>{e.preventDefault();e.stopPropagation();renderEditorObjectMenu(menu,p,kind,item.id);};
    row.append(preview,meta,menu); row.onclick=e=>{if(e.target.closest('.kix-editor-object-menu'))return;startObjectEditor(p,kind,item.id);};
    return row;
  }

  function makeAddObjectButton(label,fn){
    const btn=document.createElement('button'); btn.type='button'; btn.className='kix-editor-object-add'; btn.setAttribute('aria-label',label); btn.innerHTML='<span>+</span><em>'+esc(label)+'</em>'; btn.onclick=fn; return btn;
  }

  function renderLiveCategoryPreview(host,c){
    ensureEditorPreviewStyles(); host.innerHTML='';
    const wrap=document.createElement('section'); wrap.className='kix-editor-live-preview'+(c.compact?' compact':'');
    const title=document.createElement('div'); title.className='kix-editor-live-preview-title'; title.textContent=c.compact?'1:1':'Pré-visualização 1:1 da categoria';
    const stage=document.createElement('div'); stage.className='kix-editor-live-preview-stage category-stage';
    // Reuse the exact category-card class/visual rules from the Categories tab.
    // body is metadata in the plugin model; the Categories tab renders white text.
    const card=document.createElement('div'); card.className='cat-card kix-editor-live-preview-category'; card.style.background=c.color||'#64748B'; card.textContent=c.name||'Categoria';
    stage.appendChild(card); wrap.append(title,stage);
    if(!c.compact){ const meta=document.createElement('div'); meta.className='kix-editor-live-preview-meta'; meta.textContent=(c.badge||'PLUGIN')+' · '+(c.family||'sem família'); wrap.appendChild(meta); }
    host.appendChild(wrap);
  }

  function ensureObjectEditorStyles(){
    if(byId('kix-plugin-object-editor-style')) return;
    const s=document.createElement('style'); s.id='kix-plugin-object-editor-style'; s.textContent=`
      .kix-editor-list-title{padding:18px 16px 12px;display:flex;flex-direction:column;gap:4px;}
      .kix-editor-list-title strong{font-size:18px;color:#f1f2f3;font-weight:600;}
      .kix-editor-list-title span{font-size:11px;color:#7e8088;line-height:1.35;}
      .kix-editor-object-list{display:flex;flex-direction:column;gap:8px;padding:0 12px 4px;}
      .kix-editor-object-row{display:flex;align-items:center;gap:12px;min-height:92px;padding:8px;border:1px solid #2e3035;border-radius:12px;background:#16181b;cursor:pointer;user-select:none;-webkit-user-select:none;transition:background .14s,transform .14s,border-color .14s;}
      .kix-editor-object-row:active{transform:scale(.992);background:#1a1d20;}
      .kix-editor-object-preview{width:82px;height:82px;flex:none;display:grid;place-items:center;overflow:hidden;background:#101215;border:1px solid #25282d;border-radius:0;}
      .kix-editor-object-preview .kix-editor-live-preview{margin:0!important;padding:0!important;background:transparent!important;border:0!important;border-radius:0!important;width:100%;height:100%;display:grid;place-items:center;}
      .kix-editor-object-preview .kix-editor-live-preview-title,.kix-editor-object-preview .kix-editor-live-preview-meta{display:none;}
      .kix-editor-object-preview .kix-editor-live-preview-stage{min-height:0!important;width:100%;height:100%;display:grid!important;place-items:center!important;overflow:hidden;}
      .kix-editor-object-preview .pc-block{margin:0!important;max-width:none!important;width:max-content!important;min-height:48px!important;transform:none!important;}
      .kix-editor-object-preview .kix-editor-live-preview-category{max-width:100%;overflow:hidden;}
      .kix-editor-object-meta{min-width:0;flex:1;}
      .kix-editor-object-name{font-size:15px;color:#f0f1f2;line-height:1.25;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
      .kix-editor-object-sub{margin-top:5px;font-size:10px;color:#777a82;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
      .kix-editor-object-menu{width:40px;height:40px;min-width:40px;border:0;border-radius:8px;background:transparent;color:#b9bcc2;font-size:22px;display:grid;place-items:center;}
      .kix-editor-object-menu:active{background:#202328;}
      .kix-editor-object-add{margin:10px 12px 6px;width:calc(100% - 24px);min-height:48px;border:0;border-radius:24px;background:#059669;color:#ecfff7;display:flex;align-items:center;justify-content:center;gap:9px;font-size:13px;}
      .kix-editor-object-add>span{width:28px;height:28px;border-radius:50%;display:grid;place-items:center;background:#0bbf86;color:#032117;font-size:24px;line-height:1;}
      .kix-editor-object-add>em{font-style:normal;}
      .kix-editor-object-add.small{width:auto;margin:10px 16px;justify-content:flex-start;background:#18201d;color:#baf7df;border:1px solid #254b3c;}
      .kix-object-editor-head{position:sticky;top:0;z-index:6;display:flex;align-items:center;gap:10px;min-height:52px;padding:8px 12px;background:#111214;border-bottom:1px solid #25282d;}
      .kix-nested-back{width:40px;height:40px;border:0;background:transparent;color:#d9dde1;font-size:32px;line-height:1;}
      .kix-object-editor-title{font-size:16px;color:#f0f1f2;font-weight:500;flex:1;}
      .kix-object-editor-save-state{font-size:10px;color:#65d6a7;white-space:nowrap;}
      .kix-object-editor-preview{margin:10px 16px 12px;padding:12px;background:#121417;border:1px solid #25282d;border-radius:10px;}
      .kix-object-editor-note{margin:14px 16px 28px;padding:10px 0;color:#666a72;font-size:10px;line-height:1.5;}
      .kix-editor-two-col{display:grid;grid-template-columns:1fr 1fr;gap:8px;}
      .kix-editor-two-col .kix-editor-field{padding:0;margin-top:12px;}
      .kix-editor-color-pair{display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:0 16px;margin-top:12px;}
      .kix-color-field{min-width:0;padding:0;}
      .kix-color-row{display:flex;align-items:center;gap:10px;}
      .kix-color-wheel{position:relative;width:44px;height:44px;border:0;border-radius:50%;padding:4px;background:conic-gradient(from 0deg,#ef4444,#f59e0b,#eab308,#22c55e,#06b6d4,#3b82f6,#8b5cf6,#ec4899,#ef4444);box-shadow:0 0 0 1px #3a3d42;}
      .kix-color-wheel-inner{display:block;width:100%;height:100%;border-radius:50%;box-shadow:inset 0 0 0 2px #16181b,0 0 0 1px rgba(255,255,255,.08);}
      .kix-color-native-input{position:absolute!important;opacity:0!important;width:1px!important;height:1px!important;pointer-events:none!important;}
      .kix-color-hex{font:500 11px ui-monospace,SFMono-Regular,Menlo,monospace;color:#9ea2aa;}
      .kix-editor-readonly{color:#7f828a!important;background:#181a1d!important;}
      #screen-kix-plugin-editor .kix-editor-select-native{position:absolute!important;width:1px!important;height:1px!important;opacity:0!important;pointer-events:none!important;inset:auto!important;}
      #screen-kix-plugin-editor .kix-editor-select-button{width:100%;min-height:42px;padding:10px 11px;border:0!important;border-radius:0!important;outline:0!important;background:#202024;color:#f2f2f4;display:flex;align-items:center;justify-content:space-between;gap:10px;text-align:left;font-size:13px;box-sizing:border-box;}
      #screen-kix-plugin-editor .kix-editor-select-button:focus,#screen-kix-plugin-editor .kix-editor-select-button:focus-visible,#screen-kix-plugin-editor .kix-editor-select-button:active{border:0!important;border-radius:0!important;outline:0!important;box-shadow:none!important;background:#292a2e;}
      #screen-kix-plugin-editor .kix-editor-select-open .kix-editor-select-button{border:0!important;border-radius:0!important;box-shadow:none!important;}
      #screen-kix-plugin-editor .kix-editor-select-chevron{font-size:15px;line-height:1;color:#9da0a8;transform:translateY(-1px);}
      .kix-editor-select-menu{position:fixed;z-index:var(--kix-z-dropdown);max-height:min(300px,calc(100vh - 24px));overflow-y:auto;box-sizing:border-box;padding:4px;background:#202024;border:0!important;border-radius:0!important;outline:0!important;box-shadow:0 12px 30px rgba(0,0,0,.45);overscroll-behavior:contain;}
      .kix-editor-select-option{width:100%;min-height:42px;padding:9px 11px;border:0!important;border-radius:0!important;outline:0!important;background:transparent;color:#e8e8eb;text-align:left;font-size:13px;}
      .kix-plugin-action-svg,.kix-editor-save-main svg,.kix-plugin-import-fab svg,.kix-plugin-empty-mark svg{display:block;flex:0 0 auto;place-self:center;}
      .kix-editor-select-option.selected{background:#19372d;color:#d9fff0;}
      .kix-editor-select-option:active{background:#24513f;color:#fff;}
      .kix-param-editor-list{display:flex;flex-direction:column;gap:7px;padding:0 16px;}
      .kix-param-editor-inline{display:grid;grid-template-columns:1.1fr .9fr 1fr 1fr 36px;gap:6px;align-items:center;}
      .kix-param-editor-inline .kix-editor-input,.kix-param-editor-inline .kix-editor-select{min-width:0;padding:9px 8px;border-radius:8px;}
      .kix-param-editor-inline .kix-editor-btn{padding:0;min-height:36px;width:36px;}
      @media(max-width:520px){.kix-param-editor-inline{grid-template-columns:1fr 1fr 36px}.kix-param-editor-inline input:nth-of-type(2),.kix-param-editor-inline input:nth-of-type(3){grid-column:span 1}.kix-param-editor-inline .kix-editor-select{grid-column:span 1}.kix-editor-color-pair{grid-template-columns:1fr 1fr}.kix-editor-two-col{grid-template-columns:1fr 1fr}}
    `; document.head.appendChild(s);
  }

  function renderPluginEditor(){
    ensureEditorPreviewStyles(); ensureObjectEditorStyles();
    const host=byId('kix-plugin-editor-content'); if(!host)return;
    host.innerHTML='';
    let p=getPlugin(state.currentPluginId);
    if(!p){ const raw=pluginTemplate(); p=normalizePlugin(raw,'editor'); state.currentPluginId=p.id; }
    const status=byId('kix-plugin-editor-status');
    const protectedBuiltin = !!(p.builtin && p.protected);
    if(status) status.textContent=(p.enabled?'Ativado':'Desativado')+' · '+p.name+(protectedBuiltin?' · Integrado':'')+(state.editingKind?' · Salvo automaticamente':'');
    const deleteBtn = byId('kix-plugin-delete');
    const enableBtn = byId('kix-plugin-enable');
    if (deleteBtn) { deleteBtn.disabled = protectedBuiltin; deleteBtn.setAttribute('aria-hidden', protectedBuiltin ? 'true' : 'false'); }
    if (enableBtn) { enableBtn.disabled = protectedBuiltin; enableBtn.setAttribute('aria-hidden', protectedBuiltin ? 'true' : 'false'); }
    const tabs=byId('kix-plugin-editor-tabs');
    if(tabs) tabs.querySelectorAll('button').forEach(b=>b.classList.toggle('active',b.dataset.section===state.currentSection));
    const section=state.currentSection;
    if(section==='category-edit'){ renderCategoryObjectEditor(p,host); upgradePluginEditorSelects(host); return; }
    if(section==='block-edit'){ renderBlockObjectEditor(p,host); upgradePluginEditorSelects(host); return; }

    if(section==='overview'){
      const card=document.createElement('section'); card.className='kix-editor-profile-card';
      const preview=document.createElement('div'); preview.className='kix-editor-profile-icon'; preview.innerHTML=pluginIconImageHtml(p,72,p.name);
      const meta=document.createElement('div'); meta.className='kix-editor-profile-meta';
      const title=document.createElement('div'); title.className='kix-editor-profile-name'; title.textContent=p.name;
      const desc=document.createElement('div'); desc.className='kix-editor-profile-description'; desc.textContent=p.description||'Sem descrição';
      meta.append(title,desc); card.append(preview,meta); host.appendChild(card);
      const chooser=field('Plugin',p.id,'select',{options:state.plugins.map(x=>({value:x.id,label:x.name}))}); chooser.input.addEventListener('change',()=>{commitEditorDraft();state.currentPluginId=chooser.input.value;state.currentSection='overview';renderPluginEditor();}); host.appendChild(chooser.wrap);
      const identity=document.createElement('div'); identity.className='kix-plugin-section-title'; identity.textContent='Identidade'; host.appendChild(identity);
      const n=field('Nome',p.name); host.appendChild(n.wrap); const d=field('Descrição',p.description,'textarea'); d.input.style.minHeight='86px'; host.appendChild(d.wrap); const v=field('Versão',p.version); host.appendChild(v.wrap); const a=field('Autor',p.author); host.appendChild(a.wrap);
      const imageSection=document.createElement('section'); imageSection.className='kix-editor-image-card'; const imageHead=document.createElement('div'); imageHead.className='kix-editor-image-head'; const imageLabel=document.createElement('div'); imageLabel.className='kix-editor-image-title'; imageLabel.textContent='Ícone do plugin'; const imagePreview=document.createElement('div'); imagePreview.className='kix-editor-image-preview'; imagePreview.innerHTML=pluginIconImageHtml(p,74,p.name); imageHead.append(imageLabel,imagePreview); imageSection.appendChild(imageHead); const imageControls=document.createElement('div'); imageControls.className='kix-editor-image-controls'; const imageFile=document.createElement('input'); imageFile.type='file'; imageFile.accept='image/png,image/jpeg,image/webp,image/gif'; imageFile.className='kix-editor-file'; imageControls.appendChild(imageFile); const clearIcon=document.createElement('button'); clearIcon.type='button'; clearIcon.className='kix-editor-btn ghost'; clearIcon.textContent='Remover imagem'; imageControls.appendChild(clearIcon); imageSection.appendChild(imageControls); host.appendChild(imageSection);
      imageFile.addEventListener('change',()=>{const file=imageFile.files?.[0];if(!file)return;if(file.size>262144){toast('Ícone muito grande. Use uma imagem de até 256 KB.');imageFile.value='';return;}const reader=new FileReader();reader.onload=()=>{p.iconImage=String(reader.result||'');p.icon='';imagePreview.innerHTML=pluginIconImageHtml(p,74,p.name);savePersistent();};reader.readAsDataURL(file);});
      clearIcon.addEventListener('click',()=>{p.iconImage='';p.icon='';imageFile.value='';imagePreview.innerHTML=pluginIconImageHtml(p,74,p.name);savePersistent();});
      const runtimeTitle=document.createElement('div'); runtimeTitle.className='kix-plugin-section-title'; runtimeTitle.textContent='Execução'; host.appendChild(runtimeTitle);
      const lang=field('Linguagem',p.language,'select',{options:Object.entries(LANGUAGE_LABELS).map(([value,label])=>({value,label: value===SUPPORTED_RUNTIME_LANGUAGE?label:label+' · NÃO VERIFICADO'}))}); host.appendChild(lang.wrap);
      const save=document.createElement('button'); save.className='kix-editor-btn primary kix-editor-save-main'; save.innerHTML=pluginActionIconSvg('save',18)+'<span>Salvar alterações</span>'; save.onclick=()=>{try{const updated=Object.assign({},p,{name:n.input.value.trim()||p.name,version:v.input.value.trim()||p.version,author:a.input.value,description:d.input.value,language:lang.input.value,icon:'',iconImage:String(p.iconImage||'')});install(updated,'editor');toast('Alterações salvas');}catch(e){toast(e.message)}}; host.appendChild(save);
      const isProtectedBuiltin = !!(p.builtin && p.protected);
      if (isProtectedBuiltin) {
        try { lang.input.disabled = true; } catch (_) {}
        try { n.input.disabled = true; v.input.disabled = true; a.input.disabled = true; d.input.disabled = true; } catch (_) {}
      }
    } else if(section==='categories'){ renderCategoryEditor(p,host); }
    else if(section==='blocks'){ renderBlockEditor(p,host); }
    else if(section==='ui'){ renderUiEditor(p,host); }
    else if(section==='code'){ const codeLang=field('Linguagem',p.language,'select',{options:Object.entries(LANGUAGE_LABELS).map(([value,label])=>({value,label:value===SUPPORTED_RUNTIME_LANGUAGE?label:label+' · NÃO VERIFICADO'}))});host.appendChild(codeLang.wrap); const code=field('Código global',p.runtime?.[p.language]||'','textarea');host.appendChild(code.wrap); const refreshCode=()=>{code.input.value=String(p.runtime?.[codeLang.input.value]||'');}; codeLang.input.addEventListener('change',refreshCode); const save=document.createElement('button');save.className='kix-editor-btn primary kix-editor-save-main';save.innerHTML=pluginActionIconSvg('save',18)+'<span>Salvar código</span>';save.onclick=()=>{p.runtime[codeLang.input.value]=code.input.value;install(p,'editor');toast('Código salvo');};host.appendChild(save); }
    upgradePluginEditorSelects(host);
  }

  function renderCategoryObjectEditor(p,host){
    const c=state.editorDraft; if(!c){state.currentSection='categories';renderPluginEditor();return;}
    const head=document.createElement('div'); head.className='kix-object-editor-head'; const back=document.createElement('button'); back.type='button'; back.className='kix-nested-back'; back.textContent='‹'; back.onclick=()=>{commitEditorDraft();state.currentSection='categories';renderPluginEditor();}; const title=document.createElement('div'); title.className='kix-object-editor-title'; title.textContent='Categoria'; const saved=document.createElement('div'); saved.className='kix-object-editor-save-state'; saved.textContent='Salvo automaticamente'; head.append(back,title,saved); host.appendChild(head);
    const previewHost=document.createElement('div'); previewHost.className='kix-object-editor-preview'; host.appendChild(previewHost);
    const render=()=>renderLiveCategoryPreview(previewHost,c); render();
    const n=field('Nome da categoria',c.name); const id=field('ID da categoria',c.id); id.input.readOnly=true; id.input.classList.add('kix-editor-readonly'); const family=field('Família / agrupamento',c.family); const badge=field('Identificador visual',c.badge); host.append(n.wrap,id.wrap,family.wrap,badge.wrap);
    const colorRow=document.createElement('div'); colorRow.className='kix-editor-color-pair'; const cw=makeColorWheel(c.color,v=>{c.color=v;render();queueEditorDraftSave();},'Cor da categoria'); const bw=makeColorWheel(c.body,v=>{c.body=v;render();queueEditorDraftSave();},'Cor do texto'); colorRow.append(cw.wrap,bw.wrap); host.appendChild(colorRow);
    [n,family,badge].forEach(({input})=>input.addEventListener('input',()=>{c.name=n.input.value.trim()||'Nova categoria';c.family=family.input.value;c.badge=badge.input.value;render();queueEditorDraftSave();}));
    const note=document.createElement('div'); note.className='kix-object-editor-note'; note.textContent='Saindo desta tela salva automaticamente. O ID permanece estável para não quebrar blocos vinculados.'; host.appendChild(note);
  }

  function renderBlockObjectEditor(p,host){
    const b=state.editorDraft; if(!b){state.currentSection='blocks';renderPluginEditor();return;}
    const head=document.createElement('div'); head.className='kix-object-editor-head'; const back=document.createElement('button'); back.type='button'; back.className='kix-nested-back'; back.textContent='‹'; back.onclick=()=>{commitEditorDraft();state.currentSection='blocks';renderPluginEditor();}; const title=document.createElement('div'); title.className='kix-object-editor-title'; title.textContent='Bloco'; const saved=document.createElement('div'); saved.className='kix-object-editor-save-state'; saved.textContent='Salvo automaticamente'; head.append(back,title,saved); host.appendChild(head);
    const previewHost=document.createElement('div'); previewHost.className='kix-object-editor-preview'; host.appendChild(previewHost); const render=()=>renderLiveBlockPreview(previewHost,b); render();
    const n=field('Texto do bloco',b.name); const id=field('ID do bloco',b.id); id.input.readOnly=true; id.input.classList.add('kix-editor-readonly'); host.append(n.wrap,id.wrap);
    const catOpts=[...p.categories.map(c=>({value:c.id,label:c.name})),...Object.keys(state.app?.CATEGORIES||{}).filter(k=>!k.startsWith('plugin:')).map(k=>({value:'native:'+k,label:'Nativo · '+(state.app.CATEGORIES[k]?.name||k)}))];
    const cat=field('Categoria',b.categoryId,'select',{options:catOpts}); host.appendChild(cat.wrap);
    const presets=field('Presets (um por linha)',(b.presets||[]).join('\n'),'textarea'); presets.input.style.minHeight='78px'; host.appendChild(presets.wrap);
    const template=field('Template do bloco',b.template||''); host.appendChild(template.wrap);
    const example=field('Exemplo dos parâmetros',b.example||''); host.appendChild(example.wrap);
    const pair=document.createElement('div'); pair.className='kix-editor-two-col'; const height=field('Altura',b.heightY,'number'); const type=field('Tipo estrutural',b.type,'select',{options:[{value:'action',label:'Ação'},{value:'hat',label:'Evento'},{value:'loop',label:'Loop'},{value:'if',label:'If'},{value:'note',label:'Nota'}]}); pair.append(height.wrap,type.wrap); host.appendChild(pair);
    const color=makeColorWheel(b.color||'#64748B',v=>{b.color=v;render();queueEditorDraftSave();},'Cor do bloco'); host.appendChild(color.wrap);
    const flags=document.createElement('div'); flags.className='kix-editor-check-grid'; const catColor=document.createElement('label'); const catCb=document.createElement('input');catCb.type='checkbox';catCb.checked=b.useCategoryColor!==false;catCb.onchange=()=>{b.useCategoryColor=catCb.checked;render();queueEditorDraftSave();};catColor.append(catCb,document.createTextNode('Usar cor da categoria')); const multi=document.createElement('label'); const multiCb=document.createElement('input');multiCb.type='checkbox';multiCb.checked=!!b.multiline;multiCb.onchange=()=>{b.multiline=multiCb.checked;render();queueEditorDraftSave();};multi.append(multiCb,document.createTextNode('Permitir multilinha')); const ifelse=document.createElement('label'); const ifCb=document.createElement('input');ifCb.type='checkbox';ifCb.checked=!!b.ifElse;ifCb.onchange=()=>{b.ifElse=ifCb.checked;queueEditorDraftSave();};ifelse.append(ifCb,document.createTextNode('If com Senão')); flags.append(catColor,multi,ifelse); host.appendChild(flags);
    const paramTitle=document.createElement('div'); paramTitle.className='kix-plugin-section-title'; paramTitle.textContent='Parâmetros do bloco'; host.appendChild(paramTitle); const paramBox=document.createElement('div'); paramBox.className='kix-param-editor-list';
    const rerenderParams=()=>{paramBox.innerHTML='';(b.params||[]).forEach(param=>{const row=document.createElement('div');row.className='kix-param-editor-inline'; const pn=document.createElement('input');pn.className='kix-editor-input';pn.value=param.name||'';pn.placeholder='nome'; const pt=document.createElement('select');pt.className='kix-editor-select';['text','number','bool','color','choice','sound','image','object','actor','folder','scene','url','code','data'].forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=v;pt.appendChild(o);});pt.value=param.type||'text'; const pd=document.createElement('input');pd.className='kix-editor-input';pd.value=param.default??'';pd.placeholder='padrão'; const ph=document.createElement('input');ph.className='kix-editor-input';ph.value=param.placeholder||'';ph.placeholder='texto'; const del=document.createElement('button');del.className='kix-editor-btn';del.type='button';del.textContent='×'; del.onclick=()=>{b.params=b.params.filter(x=>x!==param);rerenderParams();render();queueEditorDraftSave();}; [pn,pt,pd,ph].forEach(el=>el.addEventListener('input',()=>{param.name=pn.value.trim()||param.name;param.type=pt.value;param.default=pd.value;param.placeholder=ph.value;render();queueEditorDraftSave();})); row.append(pn,pt,pd,ph,del); paramBox.appendChild(row);});}; rerenderParams(); host.appendChild(paramBox);
    const addParam=document.createElement('button'); addParam.type='button'; addParam.className='kix-editor-object-add small'; addParam.innerHTML='<span>+</span><em>Adicionar parâmetro</em>'; addParam.onclick=()=>{b.params=b.params||[];b.params.push({name:'valor'+(b.params.length+1),type:'text',default:'',placeholder:'valor'});rerenderParams();render();queueEditorDraftSave();}; host.appendChild(addParam);
    const adv=document.createElement('div'); adv.className='kix-plugin-section-title'; adv.textContent='Código e integração'; host.appendChild(adv);
    const lang=field('Linguagem do handler',b.handlerLanguage,'select',{options:Object.entries(LANGUAGE_LABELS).map(([value,label])=>({value,label:value===SUPPORTED_RUNTIME_LANGUAGE?label:label+' · NÃO VERIFICADO'}))}); host.appendChild(lang.wrap); const code=field('Código do bloco',b.handler,'textarea'); code.input.style.minHeight='180px'; host.appendChild(code.wrap); const override=field('Substituir bloco nativo (opcional)',b.overrideOf); host.appendChild(override.wrap); const family=field('Família / agrupamento',b.family); const badge=field('Sinalização',b.badge); host.append(family.wrap,badge.wrap);
    const wire=()=>{b.name=n.input.value.trim()||'Novo bloco';b.categoryId=cat.input.value;b.presets=presets.input.value.split(/[\n,]+/).map(x=>x.trim()).filter(Boolean).slice(0,64);b.template=template.input.value;b.example=example.input.value;b.heightY=Math.max(32,Number(height.input.value)||56);b.type=type.input.value;b.handlerLanguage=lang.input.value;b.handler=code.input.value;b.overrideOf=override.input.value.trim();b.family=family.input.value.trim();b.badge=badge.input.value.trim();render();queueEditorDraftSave();}; [n.input,cat.input,presets.input,template.input,example.input,height.input,type.input,lang.input,code.input,override.input,family.input,badge.input].forEach(el=>el.addEventListener('input',wire)); cat.input.addEventListener('change',wire); type.input.addEventListener('change',wire); lang.input.addEventListener('change',wire);
    const note=document.createElement('div'); note.className='kix-object-editor-note'; note.textContent='A pré-visualização usa o mesmo renderizador do Kix e atualiza em tempo real. Sair desta tela salva automaticamente.'; host.appendChild(note);
  }

  function moveItem(arr,index,delta){
    const from=Number(index), to=from+Number(delta);
    if(!Array.isArray(arr) || !Number.isInteger(from) || !Number.isInteger(to) || from<0 || to<0 || from>=arr.length || to>=arr.length) return false;
    const [item]=arr.splice(from,1); arr.splice(to,0,item); return true;
  }

  function normalizeCategoryOrder(p){ (p.categories||[]).forEach((c,i)=>c.order=i); }

  function renderCategoryEditor(p,host){
    const title=document.createElement('div'); title.className='kix-editor-list-title'; title.innerHTML='<strong>Categorias</strong><span>Crie e organize como objetos do próprio Kix.</span>'; host.appendChild(title);
    const list=document.createElement('div'); list.className='kix-editor-object-list'; p.categories.slice().sort((a,b)=>a.order-b.order).forEach(c=>list.appendChild(makeEditorObjectRow(p,'category',c))); host.appendChild(list);
    const add=makeAddObjectButton('Nova categoria',()=>{const c=normalizeCategory({id:'categoria-'+(p.categories.length+1),name:'Nova categoria',color:'#10B981',body:'#D1FAE5',badge:'PLUGIN',order:p.categories.length},p.id,p.categories.length);p.categories.push(c);normalizeCategoryOrder(p);refreshAttachedCategories();savePersistent();startObjectEditor(p,'category',c.id);}); host.appendChild(add);
    const oTitle=document.createElement('div');oTitle.className='kix-plugin-section-title';oTitle.textContent='Categorias nativas';host.appendChild(oTitle);
    const nativeKeys=Object.keys(state.app?.CATEGORIES||{}).filter(k=>!k.startsWith('plugin:'));
    const nSel=field('Categoria nativa','', 'select',{options:[{value:'',label:'Escolha uma categoria'}].concat(nativeKeys.map(k=>({value:'native:'+k,label:(state.app.CATEGORIES[k]?.name||k)})))}); host.appendChild(nSel.wrap);
    const on=field('Novo nome',''); const oc=makeColorWheel('#64748B',()=>{},'Nova cor'); const ob=makeColorWheel('#CBD5E1',()=>{},'Cor do corpo'); host.append(on.wrap,oc.wrap,ob.wrap);
    const os=document.createElement('button');os.className='kix-editor-btn primary mx-4 mt-3 w-[calc(100%-32px)]';os.textContent='Salvar alteração nativa';os.onclick=()=>{const key=nSel.input.value;if(!key){toast('Escolha uma categoria');return;}const existing=p.categoryOverrides.find(x=>String(x.id)===key);const spec={id:key,name:on.input.value,color:oc.input.value,body:ob.input.value};if(existing)Object.assign(existing,spec);else p.categoryOverrides.push(spec);install(p,'editor');toast('Categoria nativa alterada');};host.appendChild(os);
    (p.categoryOverrides||[]).forEach(o=>{const row=document.createElement('div');row.className='kix-editor-card';row.textContent='Nativo: '+String(o.id||'').replace(/^native:/,'');const del=document.createElement('button');del.className='kix-editor-btn mt-3';del.textContent='Remover alteração';del.onclick=()=>{p.categoryOverrides=p.categoryOverrides.filter(x=>x!==o);install(p,'editor');renderPluginEditor();};row.appendChild(del);host.appendChild(row);});
  }

  function renderBlockEditor(p,host){
    const title=document.createElement('div'); title.className='kix-editor-list-title'; title.innerHTML='<strong>Blocos</strong><span>Crie comandos como você cria objetos no Kix.</span>'; host.appendChild(title);
    const list=document.createElement('div'); list.className='kix-editor-object-list'; p.blocks.forEach(b=>list.appendChild(makeEditorObjectRow(p,'block',b))); host.appendChild(list);
    const add=makeAddObjectButton('Novo bloco',()=>{const cat=p.categories[0]?.id||'';const b=normalizeBlock({id:'bloco-'+(p.blocks.length+1),name:'Novo bloco',categoryId:cat,useCategoryColor:true,heightY:56,template:'Novo bloco',example:'',presets:[],params:[],type:'action',handlerLanguage:'javascript',handler:"api.notify('Novo bloco')"},p.id,p.blocks.length);p.blocks.push(b);refreshAttachedCategories();savePersistent();startObjectEditor(p,'block',b.id);}); host.appendChild(add);
  }

  function renderParamChipEditor(block,param){
    const row=document.createElement('div');row.className='kix-editor-card';
    const n=field('Nome',param.name);const t=field('Tipo',param.type,'select',{options:['text','number','bool','color','choice','sound','image','object','actor','folder','scene','url','code','data'].map(v=>({value:v,label:v}))});const d=field('Padrão',param.default);const ph=field('Texto de ajuda',param.placeholder);row.append(n.wrap,t.wrap,d.wrap,ph.wrap);const del=document.createElement('button');del.className='kix-editor-btn';del.textContent='Remover parâmetro';del.onclick=()=>{block.params=block.params.filter(x=>x!==param);const pp=findBlock(state.currentPluginId,block.id);if(pp)pp.params=block.params;install(pp || findBlock(state.currentPluginId,block.id),'editor');renderPluginEditor();};row.append(del);return row;
  }

  function renderUiEditor(p,host){
    const title=document.createElement('div');title.className='kix-plugin-section-title';title.textContent='Reorganização da UI';host.appendChild(title);
    const info=document.createElement('div');info.className='kix-plugin-section-title';info.textContent='Regras de interface';host.appendChild(info);
    (p.ui.rules||[]).forEach(rule=>{const card=document.createElement('div');card.className='kix-editor-card';const s=field('Seletor',rule.selector);const text=field('Texto',rule.text||'');const css=field('CSS',rule.cssText||'','textarea');const vis=field('Visível',rule.visible==null?'':String(rule.visible),'select',{options:[{value:'',label:'Não alterar'},{value:'true',label:'Mostrar'},{value:'false',label:'Ocultar'}]});card.append(s.wrap,text.wrap,css.wrap,vis.wrap);const save=document.createElement('button');save.className='kix-editor-btn primary w-full mt-3';save.textContent='Salvar regra';save.onclick=()=>{rule.selector=s.input.value;rule.text=text.input.value;rule.cssText=css.input.value;rule.visible=vis.input.value===''?null:vis.input.value==='true';install(p,'editor');toast('Regra salva');};card.appendChild(save);host.appendChild(card);});
    const add=document.createElement('button');add.className='kix-editor-btn primary mx-4 mt-4 w-[calc(100%-32px)]';add.textContent='+ Adicionar regra de UI';add.onclick=()=>{p.ui.rules.push(normalizeUiRule({selector:'#screen-home',text:''},p.ui.rules.length));install(p,'editor');renderPluginEditor();};host.appendChild(add);
    const insTitle=document.createElement('div');insTitle.className='kix-plugin-section-title';insTitle.textContent='Novos itens';host.appendChild(insTitle);
    (p.ui.inserts||[]).forEach((rule,actualIndex)=>{const card=document.createElement('div');card.className='kix-editor-card';const sel=field('Inserir perto de',rule.selector);const text=field('Texto',rule.text);const pos=field('Posição',rule.position,'select',{options:['beforebegin','afterbegin','beforeend','afterend'].map(x=>({value:x,label:x}))});const tag=field('Elemento',rule.tag||'div','select',{options:['div','span','p','button','label'].map(x=>({value:x,label:x}))});const cls=field('Classe CSS',rule.className);const click=field('Código ao tocar',rule.clickCode||'','textarea');click.input.style.minHeight='100px';card.append(sel.wrap,text.wrap,pos.wrap,tag.wrap,cls.wrap,click.wrap);const controls=document.createElement('div');controls.className='flex gap-2 mt-3';const up=document.createElement('button');up.className='kix-editor-btn';up.textContent='↑';up.title='Subir';up.disabled=actualIndex<=0;up.onclick=()=>{if(moveItem(p.ui.inserts,actualIndex,-1)){install(p,'editor');renderPluginEditor();}};const down=document.createElement('button');down.className='kix-editor-btn';down.textContent='↓';down.title='Descer';down.disabled=actualIndex>=p.ui.inserts.length-1;down.onclick=()=>{if(moveItem(p.ui.inserts,actualIndex,1)){install(p,'editor');renderPluginEditor();}};const save=document.createElement('button');save.className='kix-editor-btn primary flex-1';save.textContent='Salvar inserção';save.onclick=()=>{rule.selector=sel.input.value;rule.text=text.input.value;rule.position=pos.input.value;rule.tag=tag.input.value;rule.className=cls.input.value;rule.clickCode=click.input.value;install(p,'editor');toast('Inserção salva');};const del=document.createElement('button');del.className='kix-editor-btn';del.textContent='Excluir';del.onclick=()=>{p.ui.inserts.splice(actualIndex,1);install(p,'editor');renderPluginEditor();};controls.append(up,down,save,del);card.appendChild(controls);host.appendChild(card);});
    const addI=document.createElement('button');addI.className='kix-editor-btn mx-4 mt-4 w-[calc(100%-32px)]';addI.textContent='+ Novo item';addI.onclick=()=>{p.ui.inserts.push(normalizeInsertRule({selector:'#scripts-area',text:'Item do plugin',position:'beforeend',tag:'button',clickCode:"api.notify('Ação do plugin')"},p.ui.inserts.length));install(p,'editor');renderPluginEditor();};host.appendChild(addI);
  }

  function directTextNodes(el){
    try{return Array.from(el?.childNodes||[]).filter(n=>n && n.nodeType===3);}catch(_){return [];}
  }

  function applyUiText(el,text){
    const nodes=directTextNodes(el);
    if(nodes.length){
      nodes[0].textContent=String(text);
      for(let i=1;i<nodes.length;i++) nodes[i].textContent='';
      return {nodes,inserted:null,textOnly:false};
    }
    if(el?.children && el.children.length){
      try{const node=document.createTextNode(String(text));el.insertBefore(node,el.firstChild||null);return {nodes:[],inserted:node,textOnly:false};}catch(_){}
    }
    const old=el?.textContent;
    if(el) el.textContent=String(text);
    return {nodes:[],inserted:null,textOnly:true,oldText:old};
  }

  function restoreUiRuleEffects(){
    for(let i=state.uiRuleSnapshots.length-1;i>=0;i--){
      const snap=state.uiRuleSnapshots[i];
      const el=snap?.el;
      if(!el) continue;
      try{
        if(snap.textOnly) el.textContent=snap.oldText==null?'':snap.oldText;
        else {
          (snap.textNodes||[]).forEach((node,index)=>{if(node) node.textContent=snap.textValues?.[index] ?? '';});
          if(snap.inserted && snap.inserted.parentNode===el) el.removeChild(snap.inserted);
        }
        if(snap.className!==undefined) el.className=snap.className;
        if(snap.style!==undefined) el.style.cssText=snap.style;
        if(snap.title!==undefined) el.title=snap.title;
      }catch(_){}
    }
    state.uiRuleSnapshots=[];
  }

  function applyUiRules(){
    restoreUiRuleEffects();
    if(!state.attached) return;
    // Remove previously generated insertions.
    document.querySelectorAll('[data-kix-plugin-ui]').forEach(el=>{try{el.remove();}catch(_){}});
    listEnabled().forEach(p=>{
      (p.ui?.rules||[]).forEach(rule=>{
        if(rule.selector==='#app' || rule.selector==='#kix-app-root') return; // never rewrite the root shell blindly
        // Plugin UI rules may extend content, but must not be able to hide or rewrite
        // Kix navigation, screen containers, plugin import controls, or settings entry.
        // This also prevents a plugin rule snapshot from restoring a stale hidden state
        // over a screen opened later.
        if(/^#(?:screen-|btn-|input-|kix-plugin-settings-entry|app-settings-content)/i.test(rule.selector)) return;
        let el;try{el=document.querySelector(rule.selector);}catch(_){el=null;}
        if(!el)return;
        if(el.id==='app-logo' || el.closest?.('#app-logo')) return;
        const snap={el,className:el.className,style:el.style.cssText,title:el.title,textNodes:directTextNodes(el)};
        snap.textValues=snap.textNodes.map(node=>node.textContent);
        if(rule.text!=null && rule.text!==''){
          const applied=applyUiText(el,rule.text);
          snap.textOnly=!!applied.textOnly;
          snap.oldText=applied.oldText;
          snap.inserted=applied.inserted;
        }
        state.uiRuleSnapshots.push(snap);
        if(rule.cssText) el.style.cssText += ';'+rule.cssText;
        if(rule.title!=null) el.title=rule.title;
        if(rule.visible!=null){el.classList.toggle('hidden',!rule.visible);el.style.display=rule.visible?'':'';}
        if(rule.className) rule.className.split(/\s+/).filter(Boolean).forEach(c=>el.classList.add(c));
      });
      (p.ui?.inserts||[]).forEach(rule=>{
        let host;try{host=document.querySelector(rule.selector);}catch(_){host=null;}
        if(!host)return;
        if(host.id==='app-logo' || host.closest?.('#app-logo')) return;
        const tag=['div','span','p','button','label'].includes(String(rule.tag||'div').toLowerCase()) ? String(rule.tag||'div').toLowerCase() : 'div';
        const el=document.createElement(tag);el.textContent=rule.text;el.className=rule.className||'';el.dataset.kixPluginUi=p.id;
        if(rule.clickCode){
          el.addEventListener('click',()=>{
            try{
              const api=makeApi(p,{actor:null},{id:'ui-'+rule.id,name:rule.text||'Plugin UI',pluginId:p.id,pluginBlockId:''},{},Date.now());
              const fn=new Function('api','plugin','"use strict";\n'+rule.clickCode);
              const result=fn(api,p);
              if(result&&typeof result.then==='function') result.catch(e=>console.error('[Kix Plugin UI]',p.name,e));
            }catch(e){console.error('[Kix Plugin UI]',p.name,e);}
          });
        }
        host.insertAdjacentElement(rule.position||'beforeend',el);
      });
    });
  }

  function handleBack(){
    try{
      if(document.querySelector('.kix-plugin-mini-menu')){ closePluginMiniMenu(); return true; }
      const editor=byId('screen-kix-plugin-editor');
      if(editor && !editor.classList.contains('hidden')){
        if(state.editingKind){ closeAllPluginEditorDropdowns(); commitEditorDraft(); state.currentSection = state.editingKind === 'category' ? 'categories' : 'blocks'; renderPluginEditor(); }
        else { showScreen('home'); }
        return true;
      }
      const manager=byId('screen-kix-plugins');
      if(manager && !manager.classList.contains('hidden')){ showScreen('settings'); return true; }
    }catch(_){}
    return false;
  }

  function renderPluginScreens(){
    ensureScreenStyles(); renderPluginManager(); renderPluginEditor(); setEditorMode(editorMode()); applyUiRules();
  }

  function bindUi(){
    ensureScreenStyles();
    setEditorMode(editorMode());
    const pluginSettingsEntry=byId('kix-plugin-settings-entry');
    if(pluginSettingsEntry){
      const openPlugins=()=>showScreen('kix-plugins');
      pluginSettingsEntry.addEventListener('click',openPlugins);
      pluginSettingsEntry.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openPlugins();}});
    }
    const importKixPlugins = () => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.kixplugin,.kixplugins,.json,application/json,text/plain';
      input.multiple = true;
      input.style.position = 'fixed';
      input.style.left = '-10000px';
      input.style.top = '0';
      input.setAttribute('aria-hidden','true');
      document.body.appendChild(input);
      let settled = false;
      const cleanup = () => { if (settled) return; settled = true; try { input.value=''; input.remove(); } catch (_) {} };
      input.addEventListener('change', async e => {
        try { await handlePluginFiles(e.target.files); } finally { cleanup(); }
      }, {once:true});
      input.addEventListener('cancel', cleanup, {once:true});
      input.click();
    };
    byId('btn-kix-plugin-import-fab')?.addEventListener('click',importKixPlugins);
    byId('btn-kix-plugin-editor-fab')?.addEventListener('click',()=>{if(!state.plugins.length){const created=install(pluginTemplate(),'editor');state.currentPluginId=created.id;}else if(!getPlugin(state.currentPluginId)){state.currentPluginId=state.plugins[0].id;}state.currentSection='overview';showScreen('kix-plugin-editor');renderPluginEditor();});
    byId('btn-kix-plugin-editor-back')?.addEventListener('click',()=>{closeAllPluginEditorDropdowns();if(state.editingKind){commitEditorDraft();state.currentSection=state.editingKind==='category'?'categories':'blocks';renderPluginEditor();return;}showScreen('home');});
    byId('btn-kix-plugins-back')?.addEventListener('click',()=>showScreen('settings'));
    async function handlePluginFiles(fileList){
      const files=Array.from(fileList||[]);
      if(!files.length)return false;
      try{
        const manifests=[];
        for(const f of files){
          const text=await f.text();
          const raw=safeParse(text,null);
          if(!raw || typeof raw!=='object') throw new Error('Plugin inválido: use um arquivo .kixplugin JSON');
          if(raw.schema && raw.schema !== SCHEMA && !(raw.schema==='kix-plugin-bundle-v1' && Array.isArray(raw.plugins))) throw new Error('Schema de plugin não suportado: '+String(raw.schema));
          const items=Array.isArray(raw.plugins) && String(raw.schema||'')==='kix-plugin-bundle-v1' ? raw.plugins : [raw];
          items.forEach((item,i)=>{
            try{ manifests.push([normalizePlugin(item,f.name+'#'+(i+1)),f.name]); }
            catch(err){throw new Error((f.name||'arquivo')+' · plugin '+(i+1)+': '+(err.message||'manifesto inválido'));}
          });
        }
        const executable=manifests.some(([p])=>{
          const runtimeCode=Object.values(p.runtime||{}).some(v=>String(v||'').trim());
          return p.language==='javascript' || runtimeCode || p.blocks.some(b=>String(b.handler||'').trim());
        });
        if(executable){
          const allowed = await new Promise(resolve => {
            if(typeof global.openActionScreen !== 'function'){ resolve(false); return; }
            global.openActionScreen({
              title:'Plugin com código',
              message:'Este Kix Plugin pode executar código dentro do Kix. Instale apenas código em que você confia.',
              options:[
                {label:'Cancelar',action:()=>resolve(false)},
                {label:'Continuar',action:()=>resolve(true)}
              ]
            });
          });
          if(!allowed) return false;
        }
        for(const [raw,name] of manifests) install(raw,name);
        toast(manifests.length+' plugin(s) instalado(s)');
        return true;
      }catch(err){ console.error('Kix plugin import',err); toast('Falha ao importar plugin: '+(err.message||'arquivo inválido')); return false; }
    }
    const editorToggle=byId('kix-editor-mode-toggle'); if(editorToggle){editorToggle.checked=editorMode();editorToggle.addEventListener('change',()=>{setEditorMode(editorToggle.checked);try{localStorage.setItem(EDITOR_STORE,editorToggle.checked?'1':'0');}catch(_){ }toast(editorToggle.checked?'Modo Editor ativado':'Modo Editor desativado');});}
    byId('kix-plugin-save-template')?.addEventListener('click',()=>{if(state.editingKind) commitEditorDraft(); const p=getPlugin(state.currentPluginId);if(p){downloadJson(p.name,p);toast('Exportação do plugin iniciada');}});
    byId('btn-kix-plugin-export-all')?.addEventListener('click',()=>{if(exportAllPlugins()) toast('Exportação dos plugins iniciada');});
    byId('kix-plugin-delete')?.addEventListener('click',()=>{
      if(!state.currentPluginId) return;
      if (isProtectedBuiltin(state.currentPluginId)) { toast('Plugin Catroid de compatibilidade é integrado ao Kix e não pode ser removido.'); return; }
      global.askConfirm?.('Remover plugin', 'Remover este Kix Plugin?', () => { uninstall(state.currentPluginId); showScreen('kix-plugins'); });
    });
    byId('kix-plugin-enable')?.addEventListener('click',()=>{const p=getPlugin(state.currentPluginId);if(p)toggle(p.id,!p.enabled);});
    byId('kix-plugin-editor-tabs')?.addEventListener('click',e=>{closeAllPluginEditorDropdowns();const b=e.target.closest('button[data-section]');if(!b)return;commitEditorDraft();state.currentSection=b.dataset.section||'overview';renderPluginEditor();});
    byId('screen-kix-plugin-editor')?.addEventListener('touchstart',e=>{if(!e.target.closest('.kix-editor-select-button,.kix-editor-select-menu')) closeAllPluginEditorDropdowns(); if(e.target.closest('input,textarea,select,button'))return;}, {passive:true});
    byId('screen-kix-plugin-editor')?.addEventListener('click',e=>{if(e.target.closest('.kix-editor-select-button,.kix-editor-select-menu'))return;closeAllPluginEditorDropdowns();}, true);
    document.addEventListener('keydown',e=>{if(e.key==='Escape') closeAllPluginEditorDropdowns();}, true);
    document.addEventListener('pointerdown',e=>{if(!activeEditorDropdown)return;if(e.target.closest('.kix-editor-select-menu,.kix-editor-select-button'))return;closeAllPluginEditorDropdowns();}, true);
    document.addEventListener('scroll',()=>closeAllPluginEditorDropdowns(),true);
    window.addEventListener('resize',()=>closeAllPluginEditorDropdowns());
    if(!global.__kixPluginEditorScreenObserver && typeof MutationObserver==='function'){
      const editor=byId('screen-kix-plugin-editor');
      const observer=new MutationObserver(()=>{
        if(!editor || editor.classList.contains('hidden') || editor.hidden || editor.getAttribute('aria-hidden')==='true') closeAllPluginEditorDropdowns();
      });
      document.querySelectorAll('[id^="screen-"]').forEach(el=>observer.observe(el,{attributes:true,attributeFilter:['class','hidden','aria-hidden','style']}));
      global.__kixPluginEditorScreenObserver=observer;
    }
  }

  function attachApp(app){
    state.app=app||{}; state.attached=true; refreshAttachedCategories(); renderPluginScreens();
  }

  global.KixPluginRuntime = {
    schema: SCHEMA,
    supportedRuntimeLanguage: SUPPORTED_RUNTIME_LANGUAGE,
    languages: clone(LANGUAGE_LABELS),
    list: ()=>clone(state.plugins),
    enabled: ()=>clone(listEnabled()),
    get:getPlugin,
    findBlock,
    findBlockById,
    findBlockByName,
    getPresentation,
    categoryPresentation,
    executeBlock,
    registerLanguageRuntime,
    handleBack,
    executeGlobalRuntime,
    install,
    uninstall,
    toggle,
    attachApp,
    editorMode,
    setEditorMode,
    refresh:refreshAttachedCategories,
    disposeGameApiRuntime:disposePluginGameApiRuntime,
    applyUiRules,
    closeEditorDropdowns:closeAllPluginEditorDropdowns,
    dismissEditorTransientMenus,
    exportCurrent:()=>{if(state.editingKind) commitEditorDraft(); const p=getPlugin(state.currentPluginId); return p?downloadJson(p.name,p):false;},
    exportAll:exportAllPlugins,
    template:pluginTemplate,
    normalize:normalizePlugin,
    iconImageSource:(plugin)=>pluginIconImageValue(plugin),
    ensureBuiltinPlugins,
    builtinCatalog:()=>clone(KIX_BUILTIN_CATROID_PLUGIN),
    isProtectedBuiltin:(id)=>{const p=getPlugin(id);return !!(p?.builtin&&p?.protected);}
  };

  try {
    state.plugins = (safeParse(localStorage.getItem(STORE)||'[]',[])||[]).map(x=>{try{return normalizePlugin(x,x?.source||'local');}catch(_){return null;}}).filter(Boolean);
    ensureBuiltinPlugins();
  } catch (_) {
    state.plugins=[];
    ensureBuiltinPlugins();
  }
  try { document.addEventListener('DOMContentLoaded',()=>{bindUi();restorePersistent();}); } catch (_) {}

})(typeof window!=='undefined'?window:globalThis);
