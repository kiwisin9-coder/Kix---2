/* Kix Paint — Motor de pincéis (Brush Engine).
 * Sem nenhuma dependência de interface: recebe pontos, desenha em canvas.
 *
 * Recursos: tamanho, opacidade (teto do traço), fluxo (por carimbo), espaçamento,
 * pressão de caneta (+ simulação por velocidade para dedo/mouse), estabilização
 * (corda + suavização), inclinação (tilt da caneta), rotação (fixa, seguindo o traço,
 * aleatória), formato (redondo, quadrado, imagem), dureza, textura (papel, grão, giz,
 * tela, ruído, imagem), dispersão, quantidade, jitter, borda úmida (aquarela)
 * e o formato de arquivo .kixbrush.
 *
 * API:  KixBrush.PRESETS / ERASERS / make(id) / normalize(raw)
 *       KixBrush.createStroke({brush,color,w,h,zoom,pixelArt,erase,target,buffer,seed})
 *            → { add(ev), end(ev), takeDirty(), commit(ctx), opacity }
 *       KixBrush.preview(canvas, brush, color)   KixBrush.textureThumb(type, canvas)
 *       KixBrush.serialize(brushes) / parse(text)   KixBrush.preload(brush)
 */
(() => {
  'use strict';
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const num = (v, d, a, b) => { v = Number(v); return Number.isFinite(v) ? clamp(v, a, b) : d; };
  const lerp = (a, b, t) => a + (b - a) * t;
  const TEXTURES = ['none', 'paper', 'grain', 'chalk', 'canvas', 'noise', 'image'];
  const TIPS = ['round', 'square', 'image'];
  const CURVES = ['soft', 'linear', 'hard'];
  const ICONS = ['basic', 'soft', 'pixel', 'pencil', 'pen', 'marker', 'airbrush', 'chalk', 'charcoal', 'ink', 'watercolor', 'eraser', 'custom'];
  const DATA_URL = /^data:image\/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$/;
  const MAX_IMG = 400000;

  // ===================== Modelo do pincel =====================
  function defaults() {
    return {
      v: 1, id: '', name: 'Pincel', icon: 'custom', preset: false,
      size: 10, opacity: 100, flow: 100, spacing: 10,
      tip: { shape: 'round', image: null, hardness: 100, roundness: 100, angle: 0, followStroke: false, snap: false },
      texture: { type: 'none', scale: 100, strength: 0, image: null },
      dyn: { sizeJitter: 0, flowJitter: 0, angleJitter: 0, scatter: 0, count: 1 },
      pressure: { size: 0, opacity: 0, flow: 0, curve: 'linear', simulate: true, speed: 0 },
      tilt: 0, stab: 0, stabDist: -1, stabSmooth: -1, wet: 0
    };
  }
  const cleanImg = (s) => (typeof s === 'string' && s.length <= MAX_IMG && DATA_URL.test(s)) ? s : null;
  let idSeq = 0;
  function normalize(raw) {
    const d = defaults(); raw = raw && typeof raw === 'object' ? raw : {};
    const t = raw.tip || {}, x = raw.texture || {}, y = raw.dyn || {}, p = raw.pressure || {};
    const b = {
      v: 1,
      id: (typeof raw.id === 'string' && /^[\w.-]{1,40}$/.test(raw.id)) ? raw.id : 'b' + Date.now().toString(36) + (idSeq++).toString(36),
      name: String(raw.name == null ? d.name : raw.name).slice(0, 40) || d.name,
      icon: ICONS.includes(raw.icon) ? raw.icon : 'custom',
      preset: raw.preset === true,
      size: num(raw.size, d.size, 1, 400), opacity: num(raw.opacity, d.opacity, 1, 100),
      flow: num(raw.flow, d.flow, 1, 100), spacing: num(raw.spacing, d.spacing, 1, 300),
      tip: {
        shape: TIPS.includes(t.shape) ? t.shape : 'round', image: cleanImg(t.image),
        hardness: num(t.hardness, 100, 0, 100), roundness: num(t.roundness, 100, 5, 100),
        angle: num(t.angle, 0, -180, 180), followStroke: t.followStroke === true, snap: t.snap === true
      },
      texture: {
        type: TEXTURES.includes(x.type) ? x.type : 'none', scale: num(x.scale, 100, 10, 800),
        strength: num(x.strength, 0, 0, 100), image: cleanImg(x.image)
      },
      dyn: {
        sizeJitter: num(y.sizeJitter, 0, 0, 100), flowJitter: num(y.flowJitter, 0, 0, 100),
        angleJitter: num(y.angleJitter, 0, 0, 100), scatter: num(y.scatter, 0, 0, 300), count: Math.round(num(y.count, 1, 1, 12))
      },
      pressure: {
        size: num(p.size, 0, 0, 100), opacity: num(p.opacity, 0, 0, 100), flow: num(p.flow, 0, 0, 100),
        curve: CURVES.includes(p.curve) ? p.curve : 'linear', simulate: p.simulate !== false, speed: num(p.speed, 0, 0, 100)
      },
      tilt: num(raw.tilt, 0, 0, 100), stab: Math.round(num(raw.stab, 0, 0, 4)),
      stabDist: num(raw.stabDist, -1, -1, 80), stabSmooth: num(raw.stabSmooth, -1, -1, 95), wet: num(raw.wet, 0, 0, 100)
    };
    if (b.tip.shape === 'image' && !b.tip.image) b.tip.shape = 'round';
    if (b.texture.type === 'image' && !b.texture.image) b.texture.type = 'none';
    return b;
  }
  const clone = (b) => normalize(JSON.parse(JSON.stringify(b)));

  // ===================== Presets =====================
  const merge = (base, over) => {
    const out = JSON.parse(JSON.stringify(base));
    Object.keys(over).forEach(k => { out[k] = (over[k] && typeof over[k] === 'object' && !Array.isArray(over[k])) ? Object.assign({}, out[k], over[k]) : over[k]; });
    return out;
  };
  const mk = (id, name, icon, over) => { const b = normalize(merge(defaults(), Object.assign({ id, name, icon, preset: true }, over))); b.preset = true; return b; };
  const PRESETS = [
    mk('basic', 'Básico', 'basic', { size: 8, spacing: 8, stab: 0 }),
    mk('soft', 'Suave', 'soft', { size: 26, spacing: 6, stab: 0, tip: { hardness: 25 } }),
    mk('pixel', 'Pixel', 'pixel', { size: 4, spacing: 100, tip: { shape: 'square', snap: true } }),
    mk('pencil', 'Lápis', 'pencil', {
      size: 5, flow: 55, spacing: 6, stab: 0, tilt: 60, tip: { hardness: 80 },
      texture: { type: 'paper', strength: 70, scale: 100 }, dyn: { flowJitter: 15 },
      pressure: { size: 45, opacity: 55, flow: 40, curve: 'soft', simulate: true, speed: 30 }
    }),
    mk('pen', 'Caneta', 'pen', { size: 4, spacing: 5, stab: 1, pressure: { size: 65, curve: 'linear', simulate: true, speed: 55 } }),
    mk('marker', 'Marcador', 'marker', { size: 18, opacity: 65, spacing: 8, stab: 1, tip: { shape: 'square', roundness: 38, angle: -35 }, pressure: { simulate: false } }),
    mk('airbrush', 'Aerógrafo', 'airbrush', {
      size: 42, flow: 10, spacing: 5, stab: 0, tip: { hardness: 0 }, texture: { type: 'grain', strength: 30, scale: 50 },
      pressure: { opacity: 70, flow: 50, curve: 'soft', simulate: false }
    }),
    mk('chalk', 'Giz', 'chalk', {
      size: 22, flow: 80, spacing: 14, tip: { hardness: 75, roundness: 85 }, texture: { type: 'chalk', strength: 90, scale: 100 },
      dyn: { scatter: 6, count: 2, sizeJitter: 25, angleJitter: 100, flowJitter: 30 },
      pressure: { size: 25, opacity: 40, flow: 30, curve: 'soft', simulate: true, speed: 20 }
    }),
    mk('charcoal', 'Carvão', 'charcoal', {
      size: 26, flow: 60, spacing: 10, tilt: 85, tip: { hardness: 55, roundness: 55, followStroke: true },
      texture: { type: 'grain', strength: 85, scale: 120 }, dyn: { scatter: 12, count: 3, sizeJitter: 30, angleJitter: 40, flowJitter: 35 },
      pressure: { size: 30, opacity: 70, flow: 40, curve: 'soft', simulate: true, speed: 15 }
    }),
    mk('ink', 'Tinta', 'ink', { size: 14, spacing: 4, stab: 1, tip: { hardness: 95 }, pressure: { size: 90, curve: 'soft', simulate: true, speed: 85 } }),
    mk('watercolor', 'Aquarela', 'watercolor', {
      size: 40, flow: 22, opacity: 70, spacing: 7, stab: 1, wet: 55, tip: { hardness: 25 },
      texture: { type: 'paper', strength: 50, scale: 220 }, dyn: { sizeJitter: 12, flowJitter: 25, scatter: 3 },
      pressure: { size: 20, opacity: 50, flow: 50, curve: 'soft', simulate: true, speed: 10 }
    })
  ];
  const ERASERS = [
    mk('er-hard', 'Borracha', 'eraser', { size: 18, spacing: 6 }),
    mk('er-soft', 'Macia', 'eraser', { size: 30, spacing: 6, tip: { hardness: 20 } }),
    mk('er-chalk', 'Textura', 'eraser', { size: 26, flow: 85, spacing: 12, tip: { hardness: 70 }, texture: { type: 'chalk', strength: 85, scale: 100 }, dyn: { angleJitter: 100 } }),
    mk('er-pixel', 'Pixel', 'pixel', { size: 4, spacing: 100, tip: { shape: 'square', snap: true } })
  ];
  const make = (id) => { const f = PRESETS.concat(ERASERS).find(b => b.id === id); return f ? clone(f) : normalize({}); };

  // ===================== Texturas procedurais =====================
  function rng32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  const N = 128;
  function noiseField(n, seed) {
    const r = rng32(seed), g = new Float32Array(n * n); for (let i = 0; i < g.length; i++) g[i] = r();
    return (u, v) => {
      const fx = u * n, fy = v * n, x0 = Math.floor(fx) % n, y0 = Math.floor(fy) % n, x1 = (x0 + 1) % n, y1 = (y0 + 1) % n;
      let tx = fx - Math.floor(fx), ty = fy - Math.floor(fy); tx = tx * tx * (3 - 2 * tx); ty = ty * ty * (3 - 2 * ty);
      return lerp(lerp(g[y0 * n + x0], g[y0 * n + x1], tx), lerp(g[y1 * n + x0], g[y1 * n + x1], tx), ty);
    };
  }
  const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  function proceduralValues(type) {
    const out = new Float32Array(N * N), r = rng32(type.length * 7919 + type.charCodeAt(0));
    const n32 = noiseField(32, 11), n64 = noiseField(64, 12), n16 = noiseField(16, 13), n8 = noiseField(8, 14);
    for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
      const u = x / N, v = y / N; let val;
      if (type === 'paper') val = smooth(0.28, 0.72, 0.5 * n32(u, v) + 0.3 * n64(u, v) + 0.2 * r());
      else if (type === 'grain') val = clamp((r() - 0.35) * 3, 0, 1);
      else if (type === 'chalk') val = clamp(((0.55 * n16(u, v) + 0.45 * r()) - 0.45) * 4, 0, 1);
      else if (type === 'canvas') val = clamp(0.62 + 0.3 * Math.sin(x * Math.PI / 4) * Math.sin(y * Math.PI / 4) + (r() - 0.5) * 0.18, 0, 1);
      else val = smooth(0.25, 0.75, 0.65 * n8(u, v) + 0.35 * n32(u, v));
      out[y * N + x] = val;
    }
    return out;
  }
  const valCache = new Map(), patCache = new Map(), imgCache = new Map();
  function imageValues(src) {
    const im = imgCache.get(src); if (!im || !im.complete) return null;
    const c = document.createElement('canvas'); c.width = c.height = N;
    const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(im, 0, 0, N, N);
    const d = x.getImageData(0, 0, N, N).data, out = new Float32Array(N * N);
    for (let i = 0; i < N * N; i++) out[i] = ((0.3 * d[i * 4] + 0.59 * d[i * 4 + 1] + 0.11 * d[i * 4 + 2]) / 255) * (d[i * 4 + 3] / 255);
    return out;
  }
  function textureCanvas(tex) {
    if (tex.type === 'none' || tex.strength <= 0) return null;
    const key = tex.type + '|' + Math.round(tex.strength) + '|' + (tex.type === 'image' ? tex.image.length + tex.image.slice(-24) : '');
    if (patCache.has(key)) return patCache.get(key);
    let vals = tex.type === 'image' ? imageValues(tex.image) : (valCache.get(tex.type) || (valCache.set(tex.type, proceduralValues(tex.type)), valCache.get(tex.type)));
    if (!vals) return null;
    const c = document.createElement('canvas'); c.width = c.height = N;
    const x = c.getContext('2d'), id = x.createImageData(N, N), s = tex.strength / 100;
    for (let i = 0; i < N * N; i++) id.data[i * 4 + 3] = Math.round(255 * (1 - s * (1 - vals[i])));
    x.putImageData(id, 0, 0);
    if (patCache.size > 40) patCache.clear();
    patCache.set(key, c); return c;
  }
  function textureThumb(type, canvas) {
    const x = canvas.getContext('2d'); x.clearRect(0, 0, canvas.width, canvas.height);
    if (type === 'none') return;
    const vals = valCache.get(type) || (valCache.set(type, proceduralValues(type)), valCache.get(type));
    const id = x.createImageData(canvas.width, canvas.height);
    for (let y = 0; y < canvas.height; y++) for (let xx = 0; xx < canvas.width; xx++) {
      const v = vals[((y * 2) % N) * N + ((xx * 2) % N)], o = (y * canvas.width + xx) * 4, g = Math.round(40 + 190 * v);
      id.data[o] = id.data[o + 1] = id.data[o + 2] = g; id.data[o + 3] = 255;
    }
    x.putImageData(id, 0, 0);
  }
  function preload(brush) {
    const srcs = [brush.tip && brush.tip.image, brush.texture && brush.texture.image].filter(Boolean);
    return Promise.all(srcs.map(s => new Promise(res => {
      if (imgCache.has(s) && imgCache.get(s).complete) return res();
      const im = new Image(); im.onload = im.onerror = () => res(); im.src = s; imgCache.set(s, im);
    })));
  }
  function tintedTip(src, color) {
    const im = imgCache.get(src); if (!im || !im.complete || !im.naturalWidth) return null;
    const c = document.createElement('canvas'); c.width = c.height = N;
    const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(im, 0, 0, N, N);
    const id = x.getImageData(0, 0, N, N), d = id.data; let opaque = true;
    for (let i = 3; i < d.length; i += 4) if (d[i] < 250) { opaque = false; break; }
    const rgb = hexRgb(color);
    for (let i = 0; i < d.length; i += 4) {
      const a = opaque ? 1 - (0.3 * d[i] + 0.59 * d[i + 1] + 0.11 * d[i + 2]) / 255 : d[i + 3] / 255;
      d[i] = rgb.r; d[i + 1] = rgb.g; d[i + 2] = rgb.b; d[i + 3] = Math.round(a * 255);
    }
    x.putImageData(id, 0, 0); return c;
  }
  function hexRgb(hex) {
    hex = String(hex || '#000000').replace('#', ''); if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    const n = parseInt(hex, 16) || 0; return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
  }

  // ===================== Traço =====================
  let scratch = null;
  function getScratch(s) {
    if (!scratch) scratch = document.createElement('canvas');
    if (scratch.width < s || scratch.height < s) { scratch.width = Math.max(s, scratch.width); scratch.height = Math.max(s, scratch.height); }
    return scratch;
  }
  const STAB_DIST = [0, 2, 6, 12, 22];       // px de tela (corda)
  const STAB_SMOOTH = [0, 0.1, 0.25, 0.4, 0.55];
  const curveFn = (p, c) => c === 'soft' ? Math.pow(p, 0.6) : c === 'hard' ? Math.pow(p, 1.7) : p;

  function createStroke(o) {
    const b = normalize(o.brush), erase = !!o.erase, pixel = !!o.pixelArt, snap = pixel || b.tip.snap;
    const W = o.w, H = o.h, zoom = o.zoom || 1;
    const out = erase ? o.target : o.buffer.getContext('2d');
    if (!erase && !o.keepBuffer) out.clearRect(0, 0, W, H);
    const color = erase ? '#000000' : (o.color === 'transparent' ? '#000000' : o.color || '#000000');
    const rgb = hexRgb(color), zero = `rgba(${rgb.r},${rgb.g},${rgb.b},0)`, midC = `rgba(${rgb.r},${rgb.g},${rgb.b},0.45)`;
    const rnd = rng32(o.seed || (Date.now() & 0x7fffffff));
    const tex = snap ? null : textureCanvas(b.texture);
    const tipImg = (b.tip.shape === 'image' && b.tip.image) ? tintedTip(b.tip.image, color) : null;
    const pat = tex ? out.createPattern(tex, 'repeat') : null;
    const texScale = b.texture.scale / 100, canSetT = pat && typeof pat.setTransform === 'function' && typeof DOMMatrix === 'function';
    const tmx = canSetT ? new DOMMatrix() : null;
    const ps = b.pressure.size / 100, po = b.pressure.opacity / 100, pf = b.pressure.flow / 100;
    const useTilt = b.tilt / 100, flowK = b.flow / 100, strokeOpacity = b.opacity / 100;
    const ropeScreen = b.stabDist >= 0 ? b.stabDist : STAB_DIST[b.stab];
    const rope = ropeScreen / zoom, smoothK = b.stabSmooth >= 0 ? b.stabSmooth / 100 : STAB_SMOOTH[b.stab];
    const dirty = { x0: 1e9, y0: 1e9, x1: -1e9, y1: -1e9 }, bounds = { x0: 1e9, y0: 1e9, x1: -1e9, y1: -1e9 };
    const grow = (r, x0, y0, x1, y1) => { r.x0 = Math.min(r.x0, x0); r.y0 = Math.min(r.y0, y0); r.x1 = Math.max(r.x1, x1); r.y1 = Math.max(r.y1, y1); };

    function drawTip(c, cx, cy, r, ang, rn) {
      c.save(); c.translate(cx, cy); if (ang) c.rotate(ang); if (rn < 1) c.scale(1, rn);
      if (b.tip.shape === 'square') { c.fillStyle = color; c.fillRect(-r, -r, r * 2, r * 2); }
      else if (tipImg) c.drawImage(tipImg, -r, -r, r * 2, r * 2);
      else {
        const h = b.tip.hardness / 100;
        if (h >= 0.99) { c.fillStyle = color; c.beginPath(); c.arc(0, 0, r, 0, Math.PI * 2); c.fill(); }
        else {
          const g = c.createRadialGradient(0, 0, 0, 0, 0, r);
          g.addColorStop(0, color); g.addColorStop(clamp(h, 0, 0.97), color);
          g.addColorStop(clamp(h + (1 - h) * 0.5, 0.01, 0.99), midC); g.addColorStop(1, zero);
          c.fillStyle = g; c.beginPath(); c.arc(0, 0, r, 0, Math.PI * 2); c.fill();
        }
      }
      c.restore();
    }
    function stamp(x, y, d, alpha, ang, rn) {
      if (alpha <= 0.003 || d <= 0.2) return;
      out.globalCompositeOperation = erase ? 'destination-out' : 'source-over';
      if (snap) {
        const s = Math.max(1, Math.round(d)); out.globalAlpha = alpha; out.fillStyle = color;
        if (b.tip.shape === 'round' && s > 2) { out.beginPath(); out.arc(Math.round(x), Math.round(y), s / 2, 0, Math.PI * 2); out.fill(); }
        else out.fillRect(Math.floor(x - s / 2), Math.floor(y - s / 2), s, s);
        grow(dirty, x - s, y - s, x + s, y + s); grow(bounds, x - s, y - s, x + s, y + s); out.globalAlpha = 1; return;
      }
      const r = d / 2, half = Math.ceil((b.tip.shape === 'round' ? r : r * 1.42) + 2);
      if (pat) {
        const S = half * 2, sc = getScratch(S), c = sc.getContext('2d'), ox = Math.round(x - half), oy = Math.round(y - half);
        c.setTransform(1, 0, 0, 1, 0, 0); c.globalCompositeOperation = 'source-over'; c.globalAlpha = 1; c.clearRect(0, 0, S, S);
        drawTip(c, x - ox, y - oy, r, ang, rn);
        c.globalCompositeOperation = 'destination-in';
        if (canSetT) { tmx.a = tmx.d = texScale; tmx.b = tmx.c = 0; tmx.e = -ox; tmx.f = -oy; pat.setTransform(tmx); }
        c.fillStyle = pat; c.fillRect(0, 0, S, S);
        out.globalAlpha = alpha; out.drawImage(sc, 0, 0, S, S, ox, oy, S, S);
      } else { out.globalAlpha = alpha; drawTip(out, x, y, r, ang, rn); }
      out.globalAlpha = 1;
      grow(dirty, x - half, y - half, x + half, y + half); grow(bounds, x - half, y - half, x + half, y + half);
    }

    // Um "passo" do pincel: aplica pressão, inclinação, jitter e dispersão e carimba.
    function emit(pt, dir) {
      const pc = curveFn(clamp(pt.p, 0, 1), b.pressure.curve);
      let sizeK = (1 - ps) + ps * pc, ang0 = b.tip.angle * Math.PI / 180, rn0 = b.tip.roundness / 100;
      if (b.tip.followStroke && dir != null) ang0 += dir;
      if (useTilt > 0 && pt.pen && (pt.tx || pt.ty)) {
        const mag = clamp(Math.hypot(pt.tx, pt.ty) / 90, 0, 1);
        ang0 = lerp(ang0, Math.atan2(pt.ty, pt.tx), useTilt); rn0 = rn0 * (1 - useTilt * mag * 0.7); sizeK *= 1 + useTilt * mag * 0.8;
      }
      const alphaBase = flowK * ((1 - po) + po * pc) * ((1 - pf) + pf * pc) * (erase ? strokeOpacity : 1);
      const cnt = b.dyn.count, dj = b.dyn.sizeJitter / 100, fj = b.dyn.flowJitter / 100, aj = b.dyn.angleJitter / 100, sc = b.dyn.scatter / 100;
      for (let i = 0; i < cnt; i++) {
        const d = b.size * sizeK * (1 - rnd() * dj);
        let x = pt.x, y = pt.y;
        if (sc > 0) { const a = rnd() * Math.PI * 2, rr = Math.sqrt(rnd()) * sc * b.size * sizeK; x += Math.cos(a) * rr; y += Math.sin(a) * rr; }
        stamp(x, y, d, alphaBase * (1 - rnd() * fj), ang0 + (rnd() * 2 - 1) * aj * Math.PI, clamp(rn0, 0.05, 1));
      }
    }
    const stepFor = (pt) => {
      const pc = curveFn(clamp(pt.p, 0, 1), b.pressure.curve), sizeK = (1 - ps) + ps * pc;
      return Math.max(snap ? 1 : 0.5, b.size * Math.max(0.05, sizeK) * b.spacing / 100);
    };
    const mixPt = (a, c, t) => ({ x: lerp(a.x, c.x, t), y: lerp(a.y, c.y, t), p: lerp(a.p, c.p, t), tx: lerp(a.tx, c.tx, t), ty: lerp(a.ty, c.ty, t), pen: a.pen });
    let carry = 0;
    function walk(a, c) {
      const len = Math.hypot(c.x - a.x, c.y - a.y); if (len < 1e-6) return;
      const dir = Math.atan2(c.y - a.y, c.x - a.x); let pos = 0;
      for (let guard = 0; guard < 4000; guard++) {
        const step = stepFor(mixPt(a, c, pos / len)), need = step - carry;
        if (pos + need > len) { carry += len - pos; break; }
        pos += need; carry = 0; emit(mixPt(a, c, pos / len), dir);
      }
    }
    // Trajetória suavizada: curvas quadráticas entre pontos médios.
    const direct = rope <= 0 && smoothK <= 0;     // sem estabilização: segue os pontos do dedo, sem atraso
    const pts = []; let lastMid = null;
    const mid = (a, c) => mixPt(a, c, 0.5);
    function accept(pt) {
      pts.push(pt); const n = pts.length;
      if (n === 1) { emit(pt, null); lastMid = pt; return; }
      if (direct) { walk(pts[n - 2], pt); lastMid = pt; return; }
      if (n === 2) { const m = mid(pts[0], pts[1]); walk(pts[0], m); lastMid = m; return; }
      const P1 = pts[n - 2], P2 = pts[n - 1], m2 = mid(P1, P2), A = lastMid;
      const chord = Math.hypot(m2.x - A.x, m2.y - A.y), steps = clamp(Math.ceil(chord / 2), 2, 60);
      let prev = A;
      for (let i = 1; i <= steps; i++) {
        const t = i / steps, u = 1 - t, q = mixPt(A, m2, t);
        q.x = u * u * A.x + 2 * u * t * P1.x + t * t * m2.x; q.y = u * u * A.y + 2 * u * t * P1.y + t * t * m2.y;
        walk(prev, q); prev = q;
      }
      lastMid = m2;
    }
    // Estabilizador (corda + suavização exponencial) e pressão simulada.
    let st = null, last = null, travel = 0, pSmooth = null;
    function addPoint(ev, bypass) {
      const pen = ev.pointerType === 'pen';
      let x = ev.x, y = ev.y;
      if (!bypass) {
        if (!st) st = { x, y, sx: x, sy: y };
        else {
          const dd = Math.hypot(x - st.x, y - st.y);
          if (dd > rope) { const k = rope > 0 ? (dd - rope) / dd : 1; st.x += (x - st.x) * k; st.y += (y - st.y) * k; }
          st.sx = lerp(st.sx, st.x, 1 - smoothK); st.sy = lerp(st.sy, st.y, 1 - smoothK);
        }
        x = st.sx; y = st.sy;
      }
      const t = ev.t || 0; let p;
      if (pen && ev.pressure > 0) p = ev.pressure;
      else if (b.pressure.simulate) {
        let target = 0.75, ramp = 1;
        if (last) {
          const dt = Math.max(1, t - last.t), v = Math.hypot(x - last.x, y - last.y) * zoom / dt;
          target = 1 / (1 + v * 0.9); travel += Math.hypot(x - last.x, y - last.y) * zoom;
        }
        const sp = b.pressure.speed / 100; target = lerp(1, target, sp);
        ramp = Math.min(1, 0.5 + 0.5 * travel / (14 + b.size * zoom)); p = clamp(target * (last ? ramp : 0.8), 0.06, 1);
      } else p = 1;
      pSmooth = pSmooth == null ? p : lerp(pSmooth, p, pen ? 0.7 : 0.4);
      last = { x, y, t };
      accept({ x, y, p: pSmooth, tx: ev.tiltX || 0, ty: ev.tiltY || 0, pen });
    }
    return {
      opacity: strokeOpacity, erase,
      // junta a área suja/ocupada de outro traço (simetria: vários traços no mesmo buffer)
      absorb(other) {
        const d = other.takeDirty(); if (d) { grow(dirty, d.x, d.y, d.x + d.w, d.y + d.h); }
        const b = other.bounds(); if (b) { grow(bounds, b.x, b.y, b.x + b.w, b.y + b.h); }
      },
      add(ev) { addPoint(ev, false); },
      end(ev) {
        if (last && ev && st) {   // alcança o ponto final real e afina a ponta (tinta)
          const sx = st.sx, sy = st.sy, k = 6, fade = b.pressure.simulate && !(ev.pointerType === 'pen');
          for (let i = 1; i <= k; i++) {
            const t = i / k, pt = { x: lerp(sx, ev.x, t), y: lerp(sy, ev.y, t), t: (last.t || 0) + i, pointerType: ev.pointerType, pressure: ev.pressure, tiltX: ev.tiltX, tiltY: ev.tiltY };
            addPoint(pt, true);
            if (fade && pSmooth != null) pSmooth = lerp(pSmooth, 0.2, 0.25);
          }
        }
        if (pts.length >= 2) walk(lastMid, pts[pts.length - 1]);
      },
      takeDirty() {
        if (dirty.x1 < dirty.x0) return null;
        const x0 = clamp(Math.floor(dirty.x0), 0, W), y0 = clamp(Math.floor(dirty.y0), 0, H), x1 = clamp(Math.ceil(dirty.x1), 0, W), y1 = clamp(Math.ceil(dirty.y1), 0, H);
        dirty.x0 = dirty.y0 = 1e9; dirty.x1 = dirty.y1 = -1e9;
        return (x1 > x0 && y1 > y0) ? { x: x0, y: y0, w: x1 - x0, h: y1 - y0 } : null;
      },
      bounds() {
        if (bounds.x1 < bounds.x0) return null;
        const pad = 12, x0 = clamp(Math.floor(bounds.x0) - pad, 0, W), y0 = clamp(Math.floor(bounds.y0) - pad, 0, H), x1 = clamp(Math.ceil(bounds.x1) + pad, 0, W), y1 = clamp(Math.ceil(bounds.y1) + pad, 0, H);
        return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
      },
      // Aplica o traço na camada com a opacidade do pincel (+ borda úmida da aquarela).
      commit(ctx) {
        if (erase) return;
        const bd = this.bounds(); if (!bd) return;
        const buf = o.buffer; let src = buf, sx = bd.x, sy = bd.y;
        if (b.wet > 0 && 'filter' in out) {
          const wc = document.createElement('canvas'); wc.width = bd.w; wc.height = bd.h; const w = wc.getContext('2d');
          w.drawImage(buf, bd.x, bd.y, bd.w, bd.h, 0, 0, bd.w, bd.h);
          const bl = document.createElement('canvas'); bl.width = bd.w; bl.height = bd.h; const bx = bl.getContext('2d');
          bx.filter = `blur(${clamp(b.size * 0.12, 1, 6)}px)`; bx.drawImage(wc, 0, 0);
          const ed = document.createElement('canvas'); ed.width = bd.w; ed.height = bd.h; const ex = ed.getContext('2d');
          ex.drawImage(wc, 0, 0); ex.globalCompositeOperation = 'destination-out'; ex.drawImage(bl, 0, 0);
          w.globalCompositeOperation = 'source-atop'; w.globalAlpha = clamp(b.wet / 100 * 1.6, 0, 1); w.drawImage(ed, 0, 0);
          src = wc; sx = 0; sy = 0;
        }
        ctx.save(); ctx.globalAlpha = strokeOpacity; ctx.globalCompositeOperation = 'source-over';
        ctx.drawImage(src, sx, sy, bd.w, bd.h, bd.x, bd.y, bd.w, bd.h); ctx.restore();
      }
    };
  }

  // Amostra de traço (pré-visualização dos pincéis; usa o próprio motor).
  let pvBuf = null;
  function preview(canvas, brush, color) {
    const w = canvas.width, h = canvas.height, ctx = canvas.getContext('2d'); ctx.clearRect(0, 0, w, h);
    if (!pvBuf) pvBuf = document.createElement('canvas'); pvBuf.width = w; pvBuf.height = h;
    const b = normalize(brush); b.size = Math.min(b.size, h * 0.55);
    const s = createStroke({ brush: b, color: color || '#C8C8C8', w, h, zoom: 1, pixelArt: false, buffer: pvBuf, seed: 7 }), n = 56, pad = h * 0.55;
    for (let i = 0; i <= n; i++) {
      const t = i / n;
      s.add({ x: pad + (w - pad * 2) * t, y: h / 2 + Math.sin(t * Math.PI * 2) * h * 0.2, pressure: Math.pow(Math.sin(Math.PI * t), 0.6) * 0.95 + 0.05, pointerType: 'pen', tiltX: 0, tiltY: 0, t: i * 12 });
    }
    s.end({ x: w - pad, y: h / 2, pointerType: 'pen', pressure: 0.05 }); s.commit(ctx);
  }

  // ===================== Arquivo .kixbrush =====================
  function serialize(brushes) {
    const list = (Array.isArray(brushes) ? brushes : [brushes]).map(b => { const n = normalize(b); n.preset = false; return n; });
    return JSON.stringify({ format: 'kixbrush', version: 1, brushes: list }, null, 1);
  }
  function parse(text) {
    let j; try { j = JSON.parse(String(text)); } catch (_) { throw new Error('Arquivo .kixbrush inválido'); }
    if (!j || j.format !== 'kixbrush' || !Array.isArray(j.brushes) || !j.brushes.length) throw new Error('Não é um arquivo .kixbrush');
    return j.brushes.slice(0, 64).map(r => { const b = normalize(Object.assign({}, r, { id: '' })); b.preset = false; return b; });
  }

  window.KixBrush = { STAB: { dist: STAB_DIST, smooth: STAB_SMOOTH }, VERSION: 1, PRESETS, ERASERS, TEXTURES, make, normalize, clone, defaults, createStroke, preview, textureThumb, serialize, parse, preload, ICONS };
})();
