/*
 * Kix Runtime Services v2 — shared runtime infrastructure.
 * No UI editor, DOM editing API, or compiler dependency is allowed here.
 */
(function (global) {
  'use strict';

  const nativeNow = () => (global.performance && typeof global.performance.now === 'function') ? global.performance.now() : Date.now();
  const nativeRandom = () => Math.random();
  const state = {
    clock: { now: null, random: null },
    lifecycle: null,
    diagnostics: [],
    profiler: new Map(),
    debuggerLogs: [],
    debugSubscribers: new Set(),
    router: null,
    sensors: null,
    receivers: null,
    userBricks: null,
    nextId: 1
  };

  function now() { return typeof state.clock.now === 'function' ? Number(state.clock.now()) || 0 : nativeNow(); }
  function random() { return typeof state.clock.random === 'function' ? Number(state.clock.random()) || 0 : nativeRandom(); }
  function configureDeterminism(config = {}) {
    state.clock.now = typeof config.now === 'function' ? config.now : null;
    state.clock.random = typeof config.random === 'function' ? config.random : null;
    return { deterministic: !!(state.clock.now || state.clock.random) };
  }
  function resetDeterminism() { state.clock.now = null; state.clock.random = null; }
  const determinism = Object.freeze({ now, random, configure: configureDeterminism, reset: resetDeterminism, isDeterministic: () => !!(state.clock.now || state.clock.random) });

  class Lifecycle {
    constructor() { this.scopes = new Map(); this.nextId = 1; this.current = 'app'; }
    _scope(scope) { const key = String(scope || 'app'); if (!this.scopes.has(key)) this.scopes.set(key, new Map()); return this.scopes.get(key); }
    _add(scope, type, handle, meta = {}) { const id = this.nextId++; this._scope(scope).set(id, { id, type, handle, createdAt: now(), meta }); return id; }
    setTimeout(fn, ms, scope = 'app', meta = {}) {
      const id = this.nextId;
      const handle = global.setTimeout(() => { this._scope(scope).delete(id); try { fn(); } catch (error) { global.KixDebugger?.error?.(error, 'timer'); } }, Math.max(0, Number(ms) || 0));
      return this._add(scope, 'timeout', handle, meta);
    }
    setInterval(fn, ms, scope = 'app', meta = {}) {
      const id = this.nextId;
      const handle = global.setInterval(() => { try { fn(); } catch (error) { global.KixDebugger?.error?.(error, 'timer'); } }, Math.max(1, Number(ms) || 1));
      return this._add(scope, 'interval', handle, meta);
    }
    requestAnimationFrame(fn, scope = 'app', meta = {}) {
      const id = this.nextId;
      const raf = typeof global.requestAnimationFrame === 'function'
        ? global.requestAnimationFrame((t) => { this._scope(scope).delete(id); try { fn(t); } catch (error) { global.KixDebugger?.error?.(error, 'raf'); } })
        : global.setTimeout(() => { this._scope(scope).delete(id); try { fn(now()); } catch (error) { global.KixDebugger?.error?.(error, 'raf'); } }, 16);
      return this._add(scope, 'raf', raf, meta);
    }
    clear(id, scope = 'app') {
      const s = this._scope(scope), rec = s.get(id); if (!rec) return false;
      if (rec.type === 'interval') global.clearInterval(rec.handle);
      else if (rec.type === 'timeout') global.clearTimeout(rec.handle);
      else global.cancelAnimationFrame?.(rec.handle);
      s.delete(id); return true;
    }
    clearScope(scope) {
      const s = this._scope(scope);
      for (const rec of [...s.values()]) {
        if (rec.type === 'interval') global.clearInterval(rec.handle);
        else if (rec.type === 'timeout') global.clearTimeout(rec.handle);
        else global.cancelAnimationFrame?.(rec.handle);
      }
      s.clear();
    }
    clearAll() { for (const scope of this.scopes.keys()) this.clearScope(scope); }
    count(scope) { return this._scope(scope).size; }
    enter(scope) { this.current = String(scope || 'app'); }
    leave(previous = 'app') { this.current = String(previous || 'app'); }
    runIn(scope, fn) { const previous = this.current; this.current = String(scope || 'app'); try { return fn(); } finally { this.current = previous; } }
    snapshot() { const out = {}; for (const [scope, timers] of this.scopes) out[scope] = { count: timers.size, timers: [...timers.values()].map(t => ({ id: t.id, type: t.type, ageMs: Math.max(0, Math.round(now() - t.createdAt)), meta: t.meta })) }; return out; }
  }
  state.lifecycle = new Lifecycle();

  function diagnostic(code, message, source = {}) {
    const item = { id: `diag-${state.nextId++}`, code: String(code), severity: String(source.severity || 'error'), message: String(message), source: {
      sceneId: source.sceneId ?? null, actorId: source.actorId ?? null, actorName: source.actorName ?? null,
      blockId: source.blockId ?? null, blockIndex: Number.isInteger(source.blockIndex) ? source.blockIndex : null,
      formula: source.formula ?? null, eventId: source.eventId ?? null
    }, createdAt: now() };
    state.diagnostics.push(item); if (state.diagnostics.length > 1000) state.diagnostics.shift();
    try { global.KixDebugger?.emit?.({ type: 'diagnostic', diagnostic: item }); } catch (_) {}
    return item;
  }
  const diagnostics = Object.freeze({ report: diagnostic, list: () => state.diagnostics.slice(), clear: () => state.diagnostics.splice(0), latest: () => state.diagnostics[state.diagnostics.length - 1] || null });

  function profile(name, fn) {
    const start = nativeNow();
    try { return fn(); }
    finally { const ms = Math.max(0, nativeNow() - start); profiler.record(name, ms); }
  }
  const profiler = {
    measure: profile,
    record(name, ms) { name = String(name); const d = state.profiler.get(name) || { calls: 0, total: 0, max: 0 }; const n = Math.max(0, Number(ms) || 0); d.calls++; d.total += n; d.max = Math.max(d.max, n); state.profiler.set(name, d); return d; },
    async measureAsync(name, fn) { const start = nativeNow(); try { return await fn(); } finally { profiler.record(name, nativeNow() - start); } },
    snapshot() { return [...state.profiler.entries()].map(([name, d]) => ({ name, calls: d.calls, totalMs: Number(d.total.toFixed(4)), avgMs: Number((d.total / d.calls).toFixed(4)), maxMs: Number(d.max.toFixed(4)) })).sort((a,b) => b.totalMs - a.totalMs); },
    reset() { state.profiler.clear(); },
    mark(name) { try { global.performance?.mark?.(String(name)); } catch (_) {} }
  };

  function debugLog(level, args) {
    const entry = { time: now(), level, message: args.map(v => { try { return typeof v === 'string' ? v : JSON.stringify(v); } catch (_) { return String(v); } }).join(' ') };
    state.debuggerLogs.push(entry); if (state.debuggerLogs.length > 1000) state.debuggerLogs.shift();
  }
  const debuggerApi = {
    logs: () => state.debuggerLogs.slice(),
    clear: () => state.debuggerLogs.splice(0),
    error(error, source = 'runtime') { debugLog('error', [`[${source}]`, error?.stack || error?.message || error]); const event = { type:'error', time: now(), source, message: String(error?.message || error) }; for (const fn of [...state.debugSubscribers]) { try { fn(event); } catch (_) {} } return event; },
    emit(event) { const e = Object.assign({ time: now() }, event || {}); for (const fn of [...state.debugSubscribers]) { try { fn(e); } catch (_) {} } return e; },
    subscribe(fn) { if (typeof fn !== 'function') throw new TypeError('subscriber must be a function'); state.debugSubscribers.add(fn); return () => state.debugSubscribers.delete(fn); },
    snapshot() { return { lifecycle: state.lifecycle.snapshot(), diagnostics: state.diagnostics.length, profiler: profiler.snapshot(), logs: state.debuggerLogs.slice(-100) }; },
    events: () => state.debugSubscribers.size
  };

  class EventRouter {
    constructor() { this.routes = new Map(); this.sequence = 0; this.dispatchCount = 0; this.queue = []; this.active = new Set(); this.maxDepth = 64; }
    on(type, handler, priority = 100, id = null) { const key = String(type); if (typeof handler !== 'function') throw new TypeError('handler'); const route = { id: id || `route-${this.sequence}`, priority: Number(priority) || 0, order: this.sequence++, handler }; const arr = this.routes.get(key) || []; arr.push(route); arr.sort((a,b) => b.priority - a.priority || a.order - b.order); this.routes.set(key, arr); return () => { const xs = this.routes.get(key) || []; const i = xs.indexOf(route); if (i >= 0) xs.splice(i, 1); }; }
    dispatch(type, payload = {}, meta = {}) {
      const eventType = String(type); this.dispatchCount++; const depth = Number(meta.depth || 0); if (depth > this.maxDepth) { return { ok:false, cycle:true, eventId: meta.eventId || null, delivered:0 }; }
      const eventId = String(meta.eventId || `event-${this.sequence++}`); if (this.active.has(eventId)) { return { ok:false, cycle:true, eventId, delivered:0 }; }
      this.active.add(eventId); let delivered = 0;
      try { for (const route of (this.routes.get(eventType) || []).slice()) { route.handler(payload, { eventId, type: eventType, depth, routeId: route.id }); delivered++; } }
      finally { this.active.delete(eventId); }
      return { ok:true, cycle:false, eventId, delivered };
    }
    snapshot() { return { dispatchCount: this.dispatchCount, routes: Object.fromEntries([...this.routes.entries()].map(([type, routes]) => [type, routes.map(r => ({id:r.id,priority:r.priority,order:r.order}))])), pending: this.queue.length, active: [...this.active] }; }
  }
  state.router = new EventRouter();

  class SensorHub {
    constructor() { this.specs = new Map(); this.providers = new Map(); this.permissions = new Map(); this.values = new Map(); this.permissionRequester = null; }
    define(name, spec = {}) { this.specs.set(String(name), { name:String(name), unit:String(spec.unit || ''), rateHz:Number(spec.rateHz || 0), permission:String(spec.permission || ''), fallback:spec.fallback ?? 0, normalization:spec.normalization || null }); }
    setProvider(name, provider) { this.providers.set(String(name), provider); }
    setPermissionRequester(fn) { this.permissionRequester = typeof fn === 'function' ? fn : null; }
    setPermission(name, stateValue) { this.permissions.set(String(name), String(stateValue)); }
    permission(name) { return this.permissions.get(String(name)) || 'unknown'; }
    async requestPermission(name) { const spec = this.specs.get(String(name)); if (!spec) return false; try { const ok = this.permissionRequester ? await this.permissionRequester(spec) : false; this.permissions.set(spec.name, ok ? 'granted' : 'denied'); return ok; } catch (_) { this.permissions.set(spec.name, 'denied'); return false; } }
    setDeterministicValues(values = {}) { for (const [k,v] of Object.entries(values)) this.values.set(String(k), v); }
    read(name, source = {}) {
      const key = String(name); const spec = this.specs.get(key) || {name:key,unit:'',rateHz:0,permission:'',fallback:0};
      let value = this.values.has(key) ? this.values.get(key) : spec.fallback;
      const provider = this.providers.get(key);
      if (provider) { try { value = typeof provider === 'function' ? provider() : provider.read?.(); } catch (error) { diagnostic('SENSOR_PROVIDER_ERROR', `Sensor ${key}: ${error?.message || error}`, source); value = spec.fallback; } }
      const permission = this.permission(spec.permission || key);
      if (spec.permission && permission !== 'granted' && provider?.requiresPermission !== false) { diagnostic('SENSOR_PERMISSION', `Permissão indisponível para ${key}: ${permission}`, source); return spec.fallback; }
      if (value == null || (typeof value === 'number' && !Number.isFinite(value))) { diagnostic('SENSOR_UNAVAILABLE', `Sensor ${key} indisponível`, source); return spec.fallback; }
      return value;
    }
    snapshot() { return { specs:[...this.specs.values()], permissions:Object.fromEntries(this.permissions), values:Object.fromEntries(this.values) }; }
  }
  state.sensors = new SensorHub();
  for (const [name, spec] of Object.entries({
    acelerometro_x:{unit:'m/s²',rateHz:60,fallback:0},acelerometro_y:{unit:'m/s²',rateHz:60,fallback:0},acelerometro_z:{unit:'m/s²',rateHz:60,fallback:0},
    giroscopio_alpha:{unit:'deg/s',rateHz:60,fallback:0},giroscopio_beta:{unit:'deg/s',rateHz:60,fallback:0},giroscopio_gamma:{unit:'deg/s',rateHz:60,fallback:0},
    inclinacao_x:{unit:'deg',rateHz:30,fallback:0},inclinacao_y:{unit:'deg',rateHz:30,fallback:0},inclinacao_z:{unit:'deg',rateHz:30,fallback:0},
    bussola:{unit:'deg',rateHz:20,fallback:0},gps_latitude:{unit:'deg',rateHz:1,permission:'location',fallback:0},gps_longitude:{unit:'deg',rateHz:1,permission:'location',fallback:0},gps_precisao:{unit:'m',rateHz:1,permission:'location',fallback:0},
    toque_x:{unit:'stage',rateHz:60,fallback:0},toque_y:{unit:'stage',rateHz:60,fallback:0},toque_down:{unit:'bool',rateHz:60,fallback:0},loudness:{unit:'normalized',rateHz:30,permission:'microphone',fallback:0},face_detected:{unit:'bool',rateHz:15,permission:'camera',fallback:0}
  })) state.sensors.define(name, spec);

  class ReceiverRegistry {
    constructor() { this.items = new Map(); this.sequence = 0; }
    register(type, ownerId, handler, meta = {}) { const id = meta.id || `receiver-${this.sequence++}`; this.items.set(id, {id, type:String(type), ownerId:String(ownerId||''), handler, meta:Object.assign({},meta)}); return id; }
    unregister(id) { return this.items.delete(String(id)); }
    unregisterOwner(ownerId) { let n = 0; for (const [id,r] of this.items) if (r.ownerId === String(ownerId)) { this.items.delete(id); n++; } return n; }
    dispatch(type, payload, meta = {}) { const routes = [...this.items.values()].filter(r => r.type === String(type)).sort((a,b)=>String(a.id).localeCompare(String(b.id))); const errors=[]; for (const r of routes) { try { r.handler(payload, meta); } catch (error) { errors.push({receiverId:r.id,error:String(error?.message||error)}); diagnostic('RECEIVER_ERROR', errors.at(-1).error, {receiverId:r.id}); } } return {delivered: routes.length, errors}; }
    snapshot() { return [...this.items.values()].map(r => ({id:r.id,type:r.type,ownerId:r.ownerId,meta:r.meta})); }
    count() { return this.items.size; }
  }
  state.receivers = new ReceiverRegistry();

  class UserBrickRegistry {
    constructor() { this.defs = new Map(); this.calls = []; this.maxDepth = 32; }
    define(definition) { const d = Object.assign({ parameters:[], blocks:[], returnType:'void' }, definition || {}); const id = String(d.id || d.name || ''); if (!id) throw new Error('UserDefinedBrick sem ID'); d.id = id; d.name = String(d.name || id); d.parameters = Array.isArray(d.parameters) ? d.parameters.map(p => ({name:String(p?.name || ''), type:String(p?.type || 'text'), default:p?.default})) : []; d.blocks = Array.isArray(d.blocks) ? d.blocks : []; this.defs.set(id,d); return d; }
    remove(id) { return this.defs.delete(String(id)); }
    get(id) { return this.defs.get(String(id)) || null; }
    enter(id, args, context = {}) { const def = this.get(id); if (!def) { diagnostic('USER_BRICK_NOT_FOUND', `UserDefinedBrick não encontrado: ${id}`, context); return null; } if (this.calls.length >= this.maxDepth) { diagnostic('USER_BRICK_RECURSION', `Profundidade máxima de UserDefinedBrick excedida: ${id}`, context); return null; } const frame = {id:def.id, args:Object.assign({},args||{}), context, depth:this.calls.length+1}; this.calls.push(frame); return frame; }
    leave(frame) { const i = this.calls.lastIndexOf(frame); if (i >= 0) this.calls.splice(i,1); }
    stack() { return this.calls.slice(); }
    snapshot() { return {definitions:[...this.defs.values()].map(d=>({id:d.id,name:d.name,parameters:d.parameters.map(p=>({name:p.name,type:p.type})),blockCount:d.blocks.length})),calls:this.calls.map(c=>({id:c.id,depth:c.depth}))}; }
  }
  state.userBricks = new UserBrickRegistry();

  class UndoRedo {
    constructor(){ this.undoStack=[]; this.redoStack=[]; this.max=100; this.applySnapshot=null; }
    configure(fn,max=100){ this.applySnapshot=typeof fn==='function'?fn:null; this.max=Math.max(1,Number(max)||100); }
    commit(label,before,after){
      const item={label:String(label||'operation'),before:JSON.parse(JSON.stringify(before)),after:JSON.parse(JSON.stringify(after))};
      this.undoStack.push(item); if(this.undoStack.length>this.max)this.undoStack.shift(); this.redoStack.length=0; return item;
    }
    undo(){ const item=this.undoStack.pop(); if(!item||!this.applySnapshot)return false; this.applySnapshot(item.before); this.redoStack.push(item); return true; }
    redo(){ const item=this.redoStack.pop(); if(!item||!this.applySnapshot)return false; this.applySnapshot(item.after); this.undoStack.push(item); return true; }
    clear(){this.undoStack.length=0;this.redoStack.length=0;}
    snapshot(){return {undoDepth:this.undoStack.length,redoDepth:this.redoStack.length,labels:this.undoStack.map(x=>x.label)};}
  }
  state.undoRedo = new UndoRedo();

  global.KixDeterminism = determinism;
  global.KixLifecycle = Object.freeze({
    setTimeout:(...a)=>state.lifecycle.setTimeout(...a), setInterval:(...a)=>state.lifecycle.setInterval(...a), requestAnimationFrame:(...a)=>state.lifecycle.requestAnimationFrame(...a),
    clear:(...a)=>state.lifecycle.clear(...a), clearScope:(...a)=>state.lifecycle.clearScope(...a), clearAll:()=>state.lifecycle.clearAll(), count:(...a)=>state.lifecycle.count(...a),
    enter:(...a)=>state.lifecycle.enter(...a), leave:(...a)=>state.lifecycle.leave(...a), runIn:(...a)=>state.lifecycle.runIn(...a), scope:()=>state.lifecycle.current, snapshot:()=>state.lifecycle.snapshot(), setScope:(s)=>state.lifecycle.enter(s)
  });
  global.KixDiagnostics = diagnostics;
  global.KixProfiler = Object.freeze(profiler);
  global.KixDebugger = Object.freeze(debuggerApi);
  global.KixEventRouter = state.router;
  global.KixSensorHub = state.sensors;
  global.KixReceiverRegistry = state.receivers;
  global.KixUserBrickRegistry = state.userBricks;
  global.KixUndoRedo = state.undoRedo;
  global.KixPhase3Services = Object.freeze({ determinism, lifecycle:state.lifecycle, diagnostics, profiler, debugger:debuggerApi, router:state.router, sensors:state.sensors, receivers:state.receivers, userBricks:state.userBricks, undoRedo:state.undoRedo });
})(typeof window !== 'undefined' ? window : globalThis);
