import { computeSelectionMask, fillRgba } from './kix-paint-algorithms.mjs';

/* Kix Paint — editor de desenho (pixel art + desenho livre) do Kix.
 * Interface pensada para crianças: ferramentas só com ícones (estilo FlipaClip),
 * gavetas pequenas em vez de abas (estilo Pocket Paint) e animação sempre à vista.
 * Regra de cores: só cinza graffiti (escuro/normal/claro) + verde de destaque (kix-paint.css).
 * Módulo isolado: expõe apenas window.KixPaint = { open(opts) }.
 * opts.mode: 'new-actor' | 'look'
 * opts.baseImage: dataURL opcional para editar uma imagem existente
 * opts.onSave(dataUrl, frames): frames = [{src, ms}, ...] quando há mais de 1 quadro
 */
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const uid = () => 'k' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

  function toast(msg) {
    try { if (typeof window.toast === 'function') { window.toast(msg); return; } } catch (_) {}
    const t = $('toast');
    if (!t) return;
    t.textContent = msg; t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 1800);
  }

  // ===================== Modal helper (confirmar / escolher / texto) =====================
  const Modal = {
    show(title, bodyEl, actions) {
      $('kp-modal-title').textContent = title;
      const body = $('kp-modal-body'); body.innerHTML = ''; if (bodyEl) body.appendChild(bodyEl);
      const act = $('kp-modal-actions'); act.innerHTML = '';
      (actions || []).forEach(a => {
        const b = document.createElement('button');
        b.className = a.primary ? 'kp-modal-btn-primary' : 'kp-modal-btn-ghost';
        b.textContent = a.label;
        b.onclick = () => { Modal.hide(); a.onClick && a.onClick(); };
        act.appendChild(b);
      });
      $('kp-modal-backdrop').classList.remove('hidden');
      $('kp-modal').classList.remove('hidden');
    },
    hide() {
      $('kp-modal-backdrop').classList.add('hidden');
      $('kp-modal').classList.add('hidden');
    },
    confirm(title, msg, onYes) {
      const d = document.createElement('div');
      d.style.cssText = 'font-size:14px;color:var(--kx-light);line-height:1.5';
      d.textContent = msg;
      Modal.show(title, d, [
        { label: 'Cancelar' },
        { label: 'Confirmar', primary: true, onClick: onYes }
      ]);
    },
    prompt(title, placeholder, value, onOk) {
      const wrap = document.createElement('div');
      const inp = document.createElement('input');
      inp.className = 'kp-hex-input'; inp.style.width = '100%'; inp.placeholder = placeholder || '';
      inp.value = value || '';
      wrap.appendChild(inp);
      Modal.show(title, wrap, [
        { label: 'Cancelar' },
        { label: 'OK', primary: true, onClick: () => onOk(inp.value) }
      ]);
      setTimeout(() => inp.focus(), 60);
    }
  };
  $('kp-modal-backdrop') && ($('kp-modal-backdrop').onclick = Modal.hide);

  // ===================== Estado do documento =====================
  const RECENT_LS_KEY = 'kix_paint_recent_colors_v1';
  function loadRecent() { try { const v = JSON.parse(localStorage.getItem(RECENT_LS_KEY) || 'null'); return Array.isArray(v) ? v : []; } catch (_) { return []; } }
  function saveRecent(list) { try { localStorage.setItem(RECENT_LS_KEY, JSON.stringify(list.slice(0, 16))); } catch (_) {} }

  const SWATCHES = [
    '#E53935', '#FB8C00', '#FDD835', '#7CB342', '#43A047',
    '#00ACC1', '#1E88E5', '#3949AB', '#8E24AA', '#D81B60',
    '#6D4C41', '#C68642', '#FFCC99', '#FF8A80', 'transparent',
    '#000000', '#2B2B2B', '#6B6B6B', '#C8C8C8', '#FFFFFF'
  ];

  function hexToRgb(hex) {
    hex = String(hex || '#000000').replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    const n = parseInt(hex, 16) || 0;
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
  }
  function rgbToHex(r, g, b) { return '#' + [r, g, b].map(v => clamp(v, 0, 255).toString(16).padStart(2, '0')).join(''); }
  function hslToRgb(h, s, l) {
    s /= 100; l /= 100;
    const c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2;
    let r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; } else if (h < 180) { g = c; b = x; }
    else if (h < 240) { g = x; b = c; } else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
    return { r: Math.round((r + m) * 255), g: Math.round((g + m) * 255), b: Math.round((b + m) * 255) };
  }
  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0; const l = (max + min) / 2;
    if (max !== min) {
      const d = max - min;
      s = l > .5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
    }
    return { h, s: s * 100, l: l * 100 };
  }

  // ===================== Módulo principal =====================
  const KP = {
    opts: null,
    doc: null,            // { w, h, pixelArt, frames:[{id,ms,layers:[{id,name,visible,opacity,canvas,ctx}]}] }
    frameIdx: 0,
    layerIdx: 0,
    tool: 'brush',
    color: '#111111',
    brush: null, eraser: null, customBrushes: [], brushTab: 'shape', _buf: null, slot: 1, stretch: false, sel: null, float: null, pending: null, xfRef: null, xfSkew: false, xfLock: true, selKind: 'select-rect', selMode: 'new', wandTol: 20, wandContiguous: true, clip: null, guides: null, refs: [], _snap: null, _persp: null, rot: 0, flip: false, full: false, rotLock: false, color2: 'transparent', colorTab: 'swatches', palSel: 'fav', pals: { favorites: [], palettes: [] },
    fill: { mode: 'fill', tol: 10, opacity: 100, grow: 0 }, replaceTol: 10, replaceScope: 'layer',
    sheet: null, dirty: false, shapeKind: null, prevTool: 'brush', colorAdv: false, onionAuto: false,
    zoom: 1, panX: 0, panY: 0,
    history: [], future: [],
    playing: false, playTimer: null, onionSkin: false, gridOn: false,
    shapeFilled: false,
    _stroke: null, _eyedropper: null
  };

  function newLayer(name, w, h) {
    const c = document.createElement('canvas');
    c.width = w != null ? w : KP.doc.w; c.height = h != null ? h : KP.doc.h;
    return { id: uid(), name: name || 'Camada', visible: true, opacity: 100, canvas: c, ctx: c.getContext('2d') };
  }
  function newFrame(ms, w, h) { return { id: uid(), ms: ms || 120, layers: [newLayer('Camada 1', w, h)] }; }
  function currentFrame() { return KP.doc.frames[KP.frameIdx]; }
  function currentLayer() { const f = currentFrame(); return f.layers[clamp(KP.layerIdx, 0, f.layers.length - 1)]; }

  function compositeInto(ctx, frame) {
    ctx.clearRect(0, 0, KP.doc.w, KP.doc.h);
    frame.layers.forEach(l => {
      if (!l.visible) return;
      ctx.globalAlpha = clamp(l.opacity, 0, 100) / 100;
      ctx.drawImage(l.canvas, 0, 0);
    });
    ctx.globalAlpha = 1;
  }

  // ---- Histórico (snapshot do frame ativo) ----
  function snapshotFrame() {
    const f = currentFrame();
    return { frameId: f.id, layers: f.layers.map(l => ({ id: l.id, data: l.ctx.getImageData(0, 0, KP.doc.w, KP.doc.h) })) };
  }
  function pushHistory() {
    KP.history.push(snapshotFrame());
    if (KP.history.length > 25) KP.history.shift();
    KP._prevFuture = KP.future.slice(); KP.future.length = 0; KP.dirty = true;
    updateUndoRedoButtons();
  }
  function restoreSnapshot(snap) {
    const fi = KP.doc.frames.findIndex(x => x.id === snap.frameId);
    if (fi < 0) return;
    const f = KP.doc.frames[fi];
    snap.layers.forEach(s => {
      const l = f.layers.find(x => x.id === s.id);
      if (l) l.ctx.putImageData(s.data, 0, 0);
    });
    const moved = KP.frameIdx !== fi;
    KP.frameIdx = fi;
    renderAll();
    if (moved) { markActiveFrame(); refreshTransport(); }
  }
  function undo() {
    if (KP.float) { commitFloat(false); return; }
    if (KP.pending) { commitPending(false); return; }
    if (!KP.history.length) return;
    KP.future.push(snapshotFrame());
    restoreSnapshot(KP.history.pop());
    updateUndoRedoButtons();
  }
  function redo() {
    if (KP.float || KP.pending) return;
    if (!KP.future.length) return;
    KP.history.push(snapshotFrame());
    restoreSnapshot(KP.future.pop());
    updateUndoRedoButtons();
  }
  function updateUndoRedoButtons() {
    $('kp-undo').disabled = !KP.history.length;
    $('kp-redo').disabled = !KP.future.length;
  }

  // ===================== Canvas / zoom / stage =====================
  let elStage, elBg, elOnion, elMain, elOverlay;
  function sizeCanvases() {
    [elBg, elOnion, elMain, elOverlay, $('kp-canvas-sel')].forEach(c => { c.width = KP.doc.w; c.height = KP.doc.h; });
    elStage.style.width = KP.doc.w + 'px';
    elStage.style.height = KP.doc.h + 'px';
    elStage.classList.toggle('kp-pixel', !!KP.doc.pixelArt);
    fitZoom();
  }
  // Vista: posição (pan), zoom, rotação e espelho. Conversões sem ler o layout do navegador.
  function refreshWrapRect() { const r = $('kp-stage-wrap').getBoundingClientRect(); KP._wr = { left: r.left, top: r.top, w: r.width, h: r.height }; }
  function docToWrap(x, y) {
    const c = Math.cos(KP.rot), s = Math.sin(KP.rot), px = x * (KP.flip ? -KP.zoom : KP.zoom), py = y * KP.zoom;
    return { x: KP.panX + px * c - py * s, y: KP.panY + px * s + py * c };
  }
  function wrapToDoc(x, y) {
    const dx = x - KP.panX, dy = y - KP.panY, c = Math.cos(-KP.rot), s = Math.sin(-KP.rot);
    return { x: (dx * c - dy * s) / (KP.flip ? -KP.zoom : KP.zoom), y: (dx * s + dy * c) / KP.zoom };
  }
  function panToKeep(doc, wx, wy) {   // ajusta o pan para o ponto do desenho `doc` ficar em (wx, wy) da tela
    const c = Math.cos(KP.rot), s = Math.sin(KP.rot), px = doc.x * (KP.flip ? -KP.zoom : KP.zoom), py = doc.y * KP.zoom;
    KP.panX = wx - (px * c - py * s); KP.panY = wy - (px * s + py * c);
  }
  function fitZoom(keepRotation) {
    const wrap = $('kp-stage-wrap'), pad = 24;
    if (!keepRotation) KP.rot = 0;
    const sx = (wrap.clientWidth - pad) / KP.doc.w, sy = (wrap.clientHeight - pad) / KP.doc.h;
    KP.zoom = Math.max(0.5, Math.min(sx, sy, 16));
    panToKeep({ x: KP.doc.w / 2, y: KP.doc.h / 2 }, wrap.clientWidth / 2, wrap.clientHeight / 2);
    refreshWrapRect(); applyTransform();
  }
  function applyTransform() {
    elStage.style.transform = `translate(${KP.panX}px,${KP.panY}px) rotate(${KP.rot}rad) scale(${KP.flip ? -KP.zoom : KP.zoom},${KP.zoom})`;
    if (KP._viewChanged) KP._viewChanged();
  }
  function toggleFlipView() {
    const w = $('kp-stage-wrap'), c = wrapToDoc(w.clientWidth / 2, w.clientHeight / 2);
    KP.flip = !KP.flip; panToKeep(c, w.clientWidth / 2, w.clientHeight / 2); applyTransform();
  }
  function resetRotation() {
    const w = $('kp-stage-wrap'), c = wrapToDoc(w.clientWidth / 2, w.clientHeight / 2);
    KP.rot = 0; panToKeep(c, w.clientWidth / 2, w.clientHeight / 2); applyTransform();
  }
  function toggleFull(on) {
    const scr = $('screen-kix-paint'), w = $('kp-stage-wrap'), c = wrapToDoc(w.clientWidth / 2, w.clientHeight / 2);
    KP.full = on == null ? !KP.full : !!on; scr.classList.toggle('kp-full', KP.full); closeSheet();
    try { if (KP.full && scr.requestFullscreen) scr.requestFullscreen().catch(() => {}); else if (!KP.full && document.fullscreenElement) document.exitFullscreen().catch(() => {}); } catch (_) {}
    requestAnimationFrame(() => { refreshWrapRect(); panToKeep(c, w.clientWidth / 2, w.clientHeight / 2); applyTransform(); });
  }

  function renderAll() {
    compositeInto(elMain.getContext('2d'), currentFrame());
    const onionCtx = elOnion.getContext('2d');
    onionCtx.clearRect(0, 0, KP.doc.w, KP.doc.h);
    if (KP.onionSkin && KP.doc.frames[KP.frameIdx - 1]) compositeInto(onionCtx, KP.doc.frames[KP.frameIdx - 1]);
    drawGrid();
    scheduleThumb();
    if (KP.sheet === 'layers') rerenderSheet();
  }
  function drawGrid() {
    const bgCtx = elBg.getContext('2d');
    bgCtx.clearRect(0, 0, KP.doc.w, KP.doc.h);
    if (!KP.gridOn) return;
    const gs = KP.doc.pixelArt ? 1 : 32;
    bgCtx.strokeStyle = 'rgba(0,0,0,.22)'; bgCtx.lineWidth = 1 / KP.zoom;
    bgCtx.beginPath();
    for (let x = 0; x <= KP.doc.w; x += gs) { bgCtx.moveTo(x, 0); bgCtx.lineTo(x, KP.doc.h); }
    for (let y = 0; y <= KP.doc.h; y += gs) { bgCtx.moveTo(0, y); bgCtx.lineTo(KP.doc.w, y); }
    bgCtx.stroke();
  }

  // ===================== Ferramentas: pintura =====================
  function stageToCanvasPoint(clientX, clientY) {
    if (!KP._wr) refreshWrapRect();
    return wrapToDoc(clientX - KP._wr.left, clientY - KP._wr.top);
  }
  function pickColorAt(x, y) {
    const ctx = elMain.getContext('2d', { willReadFrequently: true });
    const px = clamp(Math.floor(x), 0, KP.doc.w - 1);
    const py = clamp(Math.floor(y), 0, KP.doc.h - 1);
    const d = ctx.getImageData(px, py, 1, 1).data;
    if (d[3] === 0) return 'transparent';
    return rgbToHex(d[0], d[1], d[2]);
  }

  // A lupa fica fora do stage transformado e só lê o canvas composto.
  // Bro: feedback visual apenas; nenhum pixel do desenho é escrito por aqui.
  const EYE_CELL = 10;
  const EYE_SIDE_MAX = 11;
  let elEyeLoupe = null, elEyeCanvas = null, elEyeCenter = null, elEyeSwatch = null, elEyeHex = null;
  function ensureEyedropperLoupe() {
    if (elEyeLoupe && elEyeLoupe.isConnected) return;
    const wrap = $('kp-stage-wrap');
    if (!wrap) return;
    elEyeLoupe = document.createElement('div');
    elEyeLoupe.id = 'kp-eyedropper-loupe';
    elEyeLoupe.className = 'kp-eyedropper-loupe';
    elEyeLoupe.setAttribute('aria-hidden', 'true');
    elEyeLoupe.innerHTML = '<div class="kp-eyedropper-meta"><span class="kp-eyedropper-swatch"></span><span class="kp-eyedropper-hex">#000000</span></div><div class="kp-eyedropper-zoom"><canvas class="kp-eyedropper-pixels"></canvas><span class="kp-eyedropper-center"></span></div>';
    wrap.appendChild(elEyeLoupe);
    elEyeCanvas = elEyeLoupe.querySelector('.kp-eyedropper-pixels');
    elEyeCenter = elEyeLoupe.querySelector('.kp-eyedropper-center');
    elEyeSwatch = elEyeLoupe.querySelector('.kp-eyedropper-swatch');
    elEyeHex = elEyeLoupe.querySelector('.kp-eyedropper-hex');
    elEyeLoupe.style.display = 'none';
  }
  function hideEyedropperLoupe() {
    if (elEyeLoupe) elEyeLoupe.style.display = 'none';
  }
  function updateEyedropperLoupe(p, clientX, clientY) {
    ensureEyedropperLoupe();
    if (!elEyeLoupe || !KP.doc) return 'transparent';
    const image = elMain, W = KP.doc.w, H = KP.doc.h;
    const px = clamp(Math.floor(p.x), 0, W - 1);
    const py = clamp(Math.floor(p.y), 0, H - 1);
    let side = Math.min(EYE_SIDE_MAX, W, H);
    if (side > 1 && side % 2 === 0) side--;
    side = Math.max(1, side);
    const maxX = Math.max(0, W - side), maxY = Math.max(0, H - side);
    const sx = clamp(px - Math.floor(side / 2), 0, maxX);
    const sy = clamp(py - Math.floor(side / 2), 0, maxY);
    const cell = EYE_CELL;
    const size = side * cell;
    elEyeCanvas.width = size; elEyeCanvas.height = size;
    elEyeCanvas.style.width = size + 'px'; elEyeCanvas.style.height = size + 'px';
    const ctx = elEyeCanvas.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, size, size);
    // Escala a amostra com nearest-neighbor: o centro corresponde a um único pixel real.
    ctx.drawImage(image, sx, sy, side, side, 0, 0, size, size);
    const col = px - sx, row = py - sy;
    elEyeCenter.style.width = cell + 'px'; elEyeCenter.style.height = cell + 'px';
    elEyeCenter.style.left = (col * cell) + 'px'; elEyeCenter.style.top = (row * cell) + 'px';
    const color = pickColorAt(px, py);
    elEyeSwatch.style.backgroundColor = color === 'transparent' ? 'transparent' : color;
    elEyeSwatch.classList.toggle('is-transparent', color === 'transparent');
    elEyeHex.textContent = color === 'transparent' ? 'TRANSP.' : color.toUpperCase();
    elEyeLoupe.style.display = 'flex';
    const wrap = $('kp-stage-wrap');
    // O preview HEX cede espaço à amostra em telas estreitas.
    elEyeHex.style.display = wrap.clientWidth < 180 ? 'none' : '';
    const wr = wrap.getBoundingClientRect();
    const w = elEyeLoupe.offsetWidth || 146, h = elEyeLoupe.offsetHeight || (size + 48);
    let left = clientX - wr.left + 22;
    let top = clientY - wr.top - h - 20;
    if (left + w > wrap.clientWidth - 4) left = clientX - wr.left - w - 22;
    if (top < 4) top = clientY - wr.top + 22;
    left = clamp(left, 4, Math.max(4, wrap.clientWidth - w - 4));
    top = clamp(top, 4, Math.max(4, wrap.clientHeight - h - 4));
    elEyeLoupe.style.left = left + 'px';
    elEyeLoupe.style.top = top + 'px';
    return color;
  }
  function beginEyedropper(e) {
    const p = stageToCanvasPoint(e.clientX, e.clientY);
    KP._eyedropper = { pointerId: e.pointerId, x: p.x, y: p.y };
    updateEyedropperLoupe(p, e.clientX, e.clientY);
  }
  function moveEyedropper(e) {
    if (!KP._eyedropper || KP._eyedropper.pointerId !== e.pointerId) return false;
    const p = stageToCanvasPoint(e.clientX, e.clientY);
    KP._eyedropper.x = p.x; KP._eyedropper.y = p.y;
    updateEyedropperLoupe(p, e.clientX, e.clientY);
    return true;
  }
  function finishEyedropper(e, commit) {
    const state = KP._eyedropper;
    if (!state || (e && state.pointerId !== e.pointerId)) return false;
    let chosen = null;
    if (commit) {
      if (e && e.clientX != null) {
        const p = stageToCanvasPoint(e.clientX, e.clientY);
        state.x = p.x; state.y = p.y;
      }
      chosen = pickColorAt(state.x, state.y);
    }
    KP._eyedropper = null;
    hideEyedropperLoupe();
    setTool(KP.prevTool && KP.prevTool !== 'eyedropper' ? KP.prevTool : 'brush');
    if (commit) { setColor(chosen); toast('Cor escolhida'); }
    return true;
  }

  // ===================== Pointer handling (desenhar / pinça) =====================
  const pointers = new Map();
  let pinchStart = null;

  function wrapPoint(x, y) { if (!KP._wr) refreshWrapRect(); return { x: x - KP._wr.left, y: y - KP._wr.top }; }
  function onPointerDown(e) {
    if (KP.playing) { togglePlay(); return; }
    if (KP.sheet && !(KP.sheet === 'xform' && xfObj())) closeSheet();
    closeFrameMenu();
    refreshWrapRect();
    if (pointers.size === 0) KP._g = { t0: e.timeStamp, max: 0, moved: false, start: new Map() };
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (KP._g) { KP._g.start.set(e.pointerId, { x: e.clientX, y: e.clientY }); KP._g.max = Math.max(KP._g.max, pointers.size); }
    try { $('kp-stage-wrap').setPointerCapture?.(e.pointerId); } catch (_) {}
    if (pointers.size === 2) {
      // Bro: dois dedos cancelam a seleção de cor em vez de deixar a lupa presa.
      if (KP._eyedropper) finishEyedropper(null, false);
      const pts = [...pointers.values()], mid = wrapPoint((pts[0].x + pts[1].x) / 2, (pts[0].y + pts[1].y) / 2);
      pinchStart = { d: Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y), ang: Math.atan2(pts[1].y - pts[0].y, pts[1].x - pts[0].x), zoom: KP.zoom, rot: KP.rot, mid, docMid: wrapToDoc(mid.x, mid.y), rotating: false };
      cancelStroke();
      return;
    }
    if (pointers.size > 1) return;
    if (KP.tool === 'eyedropper') { beginEyedropper(e); return; }
    beginStroke(e);
  }
  function onPointerMove(e) {
    if (!pointers.has(e.pointerId)) return;
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (KP._eyedropper && KP._eyedropper.pointerId === e.pointerId) { moveEyedropper(e); return; }
    if (KP._g) { const st = KP._g.start.get(e.pointerId); if (st && Math.hypot(e.clientX - st.x, e.clientY - st.y) > 12) KP._g.moved = true; }
    if (pointers.size === 2 && pinchStart) {
      // Dois dedos: pinça = zoom, girar = rotacionar a vista, arrastar = mover.
      const pts = [...pointers.values()], d = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y), ang = Math.atan2(pts[1].y - pts[0].y, pts[1].x - pts[0].x);
      const mid = wrapPoint((pts[0].x + pts[1].x) / 2, (pts[0].y + pts[1].y) / 2);
      let da = ang - pinchStart.ang; while (da > Math.PI) da -= Math.PI * 2; while (da < -Math.PI) da += Math.PI * 2;
      if (!pinchStart.rotating && Math.abs(da) > 0.14) pinchStart.rotating = true;   // evita girar sem querer ao dar zoom
      KP.zoom = clamp(pinchStart.zoom * (d / (pinchStart.d || 1)), 0.3, 24);
      KP.rot = (pinchStart.rotating && !KP.rotLock) ? pinchStart.rot + da : pinchStart.rot;
      panToKeep(pinchStart.docMid, mid.x, mid.y); pinchStart.lastMid = mid;
      applyTransform();
      return;
    }
    if (pointers.size > 1) return;
    moveStroke(e);
  }
  function onPointerUp(e) {
    if (KP._eyedropper && KP._eyedropper.pointerId === e.pointerId) {
      pointers.delete(e.pointerId);
      if (KP._g) KP._g = null;
      finishEyedropper(e, e.type !== 'pointercancel');
      if (pointers.size === 0) pinchStart = null;
      return;
    }
    const had = pointers.delete(e.pointerId);
    if (pointers.size < 2 && pinchStart) {
      if (pinchStart.rotating && Math.abs(KP.rot) < 0.07 && pinchStart.lastMid) { KP.rot = 0; panToKeep(pinchStart.docMid, pinchStart.lastMid.x, pinchStart.lastMid.y); applyTransform(); }
      pinchStart = null;
    }
    if (pointers.size === 0) {
      const g = KP._g; KP._g = null;
      if (had && g && !KP._stroke && g.max >= 2 && !g.moved && e.timeStamp - g.t0 < 320) {   // toque rápido: 2 dedos = desfazer, 3 = refazer
        if (g.max === 2) undo(); else if (g.max === 3) redo();
        return;
      }
      endStroke(e);
    }
  }

  // ===================== Traço (pincel, borracha, balde, formas) =====================
  const SHAPE_KINDS = ['line', 'rect', 'ellipse', 'triangle', 'star', 'heart'];
  const SHAPE_ICON = { line: 'line', rect: 'square', ellipse: 'circle', triangle: 'triangle', star: 'star', heart: 'heart' };
  const isShapeTool = (t) => SHAPE_KINDS.includes(t);
  const SIZED_TOOLS = ['brush', 'eraser'].concat(SHAPE_KINDS, ['bezier', 'polygon', 'arc']);
  Object.assign(SHAPE_ICON, { bezier: 'curve', polygon: 'poly', arc: 'arc', text: 'text' });
  const SEL_ICON = { 'select-rect': 'selRect', 'select-lasso': 'selLasso', 'select-wand': 'selWand' };

  function beginStroke(e) {
    const p = stageToCanvasPoint(e.clientX, e.clientY);
    const layer = currentLayer();
    if (xfObj()) { xfBegin(e, p); return; }                       // transformando: só as alças reagem
    if (guideBegin(e, p)) return;                                  // arrastando régua / guia / ponto de fuga
    if (isSelTool(KP.tool)) { selBegin(e, p); return; }
    if (isPendTool(KP.tool)) { pendBegin(e, p); return; }
    if (KP.tool === 'text') { openTextDialog(null, p); return; }
    if (['brush', 'eraser'].includes(KP.tool)) {
      pushHistory();
      const erase = KP.tool === 'eraser' || KP.color === 'transparent';
      const brush = KP.tool === 'eraser' ? KP.eraser : KP.brush;
      const mkEngine = (keep, seed) => KixBrush.createStroke({ brush, color: KP.color, w: KP.doc.w, h: KP.doc.h, zoom: KP.zoom, pixelArt: KP.doc.pixelArt, erase, target: layer.ctx, buffer: strokeBuffer(), keepBuffer: keep, seed });
      const seed0 = (Math.random() * 1e9) | 0, engine = mkEngine(false, seed0);
      const subs = symTransforms().map((fn, i) => ({ fn, eng: mkEngine(true, seed0 + i + 1) }));        // simetria
      pickStrokeSnap(p, wrapPoint(e.clientX, e.clientY));                                                // régua / guia / perspectiva
      KP._selSnap = (KP.sel && erase) ? (() => { const c = newCanvas(KP.doc.w, KP.doc.h); c.getContext('2d').drawImage(layer.canvas, 0, 0); return c; })() : null;
      KP._stroke = { type: KP.tool, engine, subs, erase };
      feedStroke(e, engine);
    } else if (KP.tool === 'fill') {
      if (KP.fill.mode === 'fill') {
        withSelection(layer, () => floodFill(layer, p.x, p.y, KP.color, { tolerance: KP.fill.tol, opacity: KP.fill.opacity, pixelArt: KP.doc.pixelArt, grow: KP.fill.grow }));
        renderAll();
      } else KP._stroke = { type: 'gradient', start: p, last: p };
    } else if (KP.tool === 'eyedropper') {
      beginEyedropper(e);
    } else if (isShapeTool(KP.tool)) {
      KP._stroke = { type: KP.tool, start: p, last: p, seed: (Math.random() * 1e9) | 0 };
    } else if (KP.tool === 'move') {
      pushHistory();
      KP._stroke = { type: 'move', start: p, last: p, snapshot: layer.ctx.getImageData(0, 0, KP.doc.w, KP.doc.h) };
    }
  }
  function moveStroke(e) {
    if (KP._xfDrag) { xfMove(stageToCanvasPoint(e.clientX, e.clientY)); return; }
    if (KP._gdrag) { guideMove(stageToCanvasPoint(e.clientX, e.clientY)); return; }
    if (KP._pdrag) { pendMove(stageToCanvasPoint(e.clientX, e.clientY)); return; }
    if (!KP._stroke) return;
    const p = stageToCanvasPoint(e.clientX, e.clientY);
    const layer = currentLayer();
    if (KP._stroke.type === 'select') { selMove(p); return; }
    if (KP._stroke.type === 'brush' || KP._stroke.type === 'eraser') {
      feedStroke(e, KP._stroke.engine);
    } else if (KP._stroke.type === 'gradient') {
      KP._stroke.last = p; previewGradient();
    } else if (isShapeTool(KP._stroke.type)) {
      KP._stroke.last = p;
      drawShapePreview();
    } else if (KP._stroke.type === 'move') {
      const dx = Math.round(p.x - KP._stroke.start.x), dy = Math.round(p.y - KP._stroke.start.y);
      const tmp = document.createElement('canvas'); tmp.width = KP.doc.w; tmp.height = KP.doc.h;
      tmp.getContext('2d').putImageData(KP._stroke.snapshot, 0, 0);
      layer.ctx.clearRect(0, 0, KP.doc.w, KP.doc.h);
      layer.ctx.drawImage(tmp, dx, dy);
      renderAll();
    }
  }
  function shapePath(ctx, type, x, y, w, h) {
    ctx.beginPath();
    if (type === 'rect') ctx.rect(x, y, w, h);
    else if (type === 'ellipse') ctx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
    else if (type === 'triangle') { ctx.moveTo(x + w / 2, y); ctx.lineTo(x + w, y + h); ctx.lineTo(x, y + h); ctx.closePath(); }
    else if (type === 'star') {
      const cx = x + w / 2, cy = y + h / 2;
      for (let i = 0; i < 10; i++) {
        const a = -Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? 0.45 : 1;
        const px = cx + (w / 2) * r * Math.cos(a), py = cy + (h / 2) * r * Math.sin(a);
        if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      }
      ctx.closePath();
    } else if (type === 'heart') {
      const cx = x + w / 2, top = h * 0.3;
      ctx.moveTo(cx, y + top);
      ctx.bezierCurveTo(cx, y, x, y, x, y + top);
      ctx.bezierCurveTo(x, y + (h + top) / 2, cx, y + (h + top) / 2, cx, y + h);
      ctx.bezierCurveTo(cx, y + (h + top) / 2, x + w, y + (h + top) / 2, x + w, y + top);
      ctx.bezierCurveTo(x + w, y, cx, y, cx, y + top);
      ctx.closePath();
    }
  }
  function strokeBuffer() {
    if (!KP._buf) KP._buf = document.createElement('canvas');
    if (KP._buf.width !== KP.doc.w || KP._buf.height !== KP.doc.h) { KP._buf.width = KP.doc.w; KP._buf.height = KP.doc.h; }
    return KP._buf;
  }
  function strokeEvent(e, end) {
    const p = stageToCanvasPoint(e.clientX, e.clientY);
    return { x: p.x, y: p.y, pressure: end ? 0.05 : e.pressure, pointerType: e.pointerType, tiltX: e.tiltX || 0, tiltY: e.tiltY || 0, t: e.timeStamp };
  }
  // O traço é desenhado num buffer e mostrado na camada de pré-visualização (só a área nova).
  function presentStroke(engine) {
    if (engine.erase) {
      if (KP.sel && KP._selSnap) { const r = engine.takeDirty(); if (r) restoreOutside(currentLayer(), KP._selSnap, r); }
      renderAll(); return;
    }
    const r = engine.takeDirty(); if (!r) return;
    const ctx = elOverlay.getContext('2d');
    ctx.clearRect(r.x, r.y, r.w, r.h); ctx.globalAlpha = engine.opacity;
    ctx.drawImage(KP._buf, r.x, r.y, r.w, r.h, r.x, r.y, r.w, r.h); ctx.globalAlpha = 1;
    if (KP.sel) { ctx.save(); ctx.globalCompositeOperation = 'destination-in'; ctx.drawImage(KP.sel.mask, r.x, r.y, r.w, r.h, r.x, r.y, r.w, r.h); ctx.restore(); }
  }
  function feedStroke(e, engine) {
    const list = (e.type === 'pointermove' && e.getCoalescedEvents) ? e.getCoalescedEvents() : null, st = KP._stroke;
    (list && list.length ? list : [e]).forEach(ev => {
      const q = strokeEvent(ev), sp = snapStrokePoint({ x: q.x, y: q.y }); if (!sp) return; q.x = sp.x; q.y = sp.y;
      engine.add(q);
      if (st && st.subs) st.subs.forEach(s => { const t = s.fn(q); s.eng.add(Object.assign({}, q, { x: t.x, y: t.y })); });
    });
    if (st && st.subs) st.subs.forEach(s => engine.absorb(s.eng));
    presentStroke(engine);
  }
  function cancelStroke() {
    KP._xfDrag = null; KP._gdrag = null; KP._pdrag = null;
    const s = KP._stroke; if (!s) return;
    if (s.engine) {
      elOverlay.getContext('2d').clearRect(0, 0, KP.doc.w, KP.doc.h);
      const snap = KP.history.pop(); if (snap && s.erase) restoreSnapshot(snap);
      if (KP._prevFuture) KP.future = KP._prevFuture;
      updateUndoRedoButtons();
    }
    KP._stroke = null; renderAll();
  }
  function endStroke(e) {
    if (KP._xfDrag) { KP._xfDrag = null; return; }
    if (KP._gdrag) { KP._gdrag = null; scheduleUi(); return; }
    if (KP._pdrag) { pendEnd(); return; }
    if (!KP._stroke) return;
    if (KP._stroke.type === 'select') { selEnd(); return; }
    if (KP._stroke.engine) {
      const eng = KP._stroke.engine, subs = KP._stroke.subs || [];
      if (e && e.clientX != null) {
        const q = strokeEvent(e, true), sp = snapStrokePoint({ x: q.x, y: q.y }); if (sp) { q.x = sp.x; q.y = sp.y; }
        eng.end(q); subs.forEach(s => { const t = s.fn(q); s.eng.end(Object.assign({}, q, { x: t.x, y: t.y })); });
      } else { eng.end(null); subs.forEach(s => s.eng.end(null)); }
      subs.forEach(s => eng.absorb(s.eng));
      presentStroke(eng);
      if (!eng.erase) {
        if (KP.sel) { const bx = KP._buf.getContext('2d'); bx.save(); bx.globalCompositeOperation = 'destination-in'; bx.drawImage(KP.sel.mask, 0, 0); bx.restore(); }
        eng.commit(currentLayer().ctx); elOverlay.getContext('2d').clearRect(0, 0, KP.doc.w, KP.doc.h);
      }
      KP._selSnap = null; KP._snap = null; KP._persp = null;
      KP._stroke = null; renderAll(); return;
    }
    if (isShapeTool(KP._stroke.type)) commitShape(KP._stroke);
    else if (KP._stroke.type === 'gradient') commitGradient(KP._stroke);
    KP._stroke = null;
    renderAll();
  }

  // ===================== Ícones =====================
  // Regra de cores do Kix Paint: só cinza graffiti (escuro / normal / claro) + verde de destaque.
  // Os tokens ficam em kix-paint.css (--kx-dark, --kx-mid, --kx-light, --kx-accent).
  const ICON = {
    back: '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
    undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/>',
    redo: '<path d="m15 14 5-5-5-5"/><path d="M20 9H9.5a5.5 5.5 0 0 0 0 11H13"/>',
    more: '<circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    brush: '<path d="m9.06 11.9 8.07-8.06a2.85 2.85 0 1 1 4.03 4.03l-8.06 8.08"/><path d="M7.07 14.94c-1.66 0-3 1.35-3 3.02 0 1.33-2.5 1.52-2 2.02 1.08 1.1 2.49 2.02 4 2.02 2.2 0 4-1.8 4-4.04a3.01 3.01 0 0 0-3-3.02z"/>',
    eraser: '<path d="m7 21-4.3-4.3c-1-1-1-2.5 0-3.4l9.6-9.6c1-1 2.5-1 3.4 0l5.6 5.6c1 1 1 2.5 0 3.4L13 21"/><path d="M22 21H7"/><path d="m5 11 9 9"/>',
    bucket: '<path d="m19 11-8-8-8.6 8.6a2 2 0 0 0 0 2.8l5.2 5.2c.8.8 2 .8 2.8 0L19 11Z"/><path d="m5 2 5 5"/><path d="M2 13h15"/><path d="M22 20a2 2 0 1 1-4 0c0-1.6 1.7-2.4 2-4 .3 1.6 2 2.4 2 4Z"/>',
    shapes: '<path d="M8.3 10a.7.7 0 0 1-.626-1.079L11.4 3a.7.7 0 0 1 1.198-.043L16.3 8.9a.7.7 0 0 1-.572 1.1Z"/><rect x="3" y="14" width="7" height="7" rx="1"/><circle cx="17.5" cy="17.5" r="3.5"/>',
    pipette: '<path d="m2 22 1-1h3l9-9"/><path d="M3 21v-3l9-9"/><path d="m15 6 3.4-3.4a2.1 2.1 0 1 1 3 3L18 9l.4.4a2.1 2.1 0 1 1-3 3l-3.8-3.8a2.1 2.1 0 1 1 3-3l.4.4Z"/>',
    palette: '<circle cx="13.5" cy="6.5" r="1" fill="currentColor"/><circle cx="17.5" cy="10.5" r="1" fill="currentColor"/><circle cx="8.5" cy="7.5" r="1" fill="currentColor"/><circle cx="6.5" cy="12.5" r="1" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.7-.7 1.7-1.6 0-.4-.2-.8-.5-1.1-.3-.3-.4-.7-.4-1.1 0-.9.8-1.7 1.7-1.7H16c3 0 5.5-2.5 5.5-5.5C21.5 6 17.5 2 12 2z"/>',
    sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
    play: '<path d="M7 4.5v15a1 1 0 0 0 1.5.86l12-7.5a1 1 0 0 0 0-1.72l-12-7.5A1 1 0 0 0 7 4.5z"/>',
    pause: '<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>',
    prev: '<path d="M19 20 9 12l10-8z"/><path d="M5 19V5"/>',
    next: '<path d="m5 4 10 8-10 8z"/><path d="M19 5v14"/>',
    onion: '<circle cx="9" cy="12" r="6"/><circle cx="15" cy="12" r="6"/>',
    layers: '<path d="M12 3 3 8l9 5 9-5z"/><path d="m3 12.5 9 5 9-5"/><path d="m3 17 9 5 9-5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    trash: '<path d="M19 6l-1 14H6L5 6M10 11v5M14 11v5M9 6V4h6v2M3 6h18"/>',
    copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>',
    eyeoff: '<path d="M3 3l18 18"/><path d="M10.6 10.6a3 3 0 0 0 4.24 4.24"/><path d="M9.9 4.2A10.7 10.7 0 0 1 12 4c7 0 11 7 11 7a13.2 13.2 0 0 1-3.2 3.9M6.6 6.6A13.4 13.4 0 0 0 1 11s4 7 11 7a10.7 10.7 0 0 0 5.4-1.4"/>',
    up: '<path d="m18 15-6-6-6 6"/>',
    down: '<path d="m6 9 6 6 6-6"/>',
    grid: '<path d="M4 4h16v16H4z"/><path d="M4 10h16M4 16h16M10 4v16M16 4v16"/>',
    flipH: '<path d="M12 3v18M7 7l-4 5 4 5M17 7l4 5-4 5"/>',
    flipV: '<path d="M3 12h18M7 7l5-4 5 4M7 17l5 4 5-4"/>',
    move: '<path d="M12 2v20M2 12h20M5 9l-3 3 3 3M19 9l3 3-3 3M9 5l3-3 3 3M9 19l3 3 3-3"/>',
    maximize: '<path d="M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/>',
    fit: '<path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>',
    download: '<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>',
    film: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 3v18M17 3v18M3 8h4M3 12h4M3 16h4M17 8h4M17 12h4M17 16h4"/>',
    video: '<path d="m22 8-6 4 6 4V8z"/><rect x="2" y="6" width="14" height="12" rx="2"/>',
    line: '<path d="M5 19 19 5"/>',
    square: '<rect x="4" y="4" width="16" height="16" rx="1"/>',
    circle: '<circle cx="12" cy="12" r="8.5"/>',
    triangle: '<path d="M12 4 21 19H3z"/>',
    star: '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
    heart: '<path d="M12 20s-8-4.6-8-10.2A4.3 4.3 0 0 1 12 7.4a4.3 4.3 0 0 1 8 2.4C20 15.4 12 20 12 20z"/>',
    pencil: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
    wheel: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/><path d="M12 3v5.5M20.2 8l-4.7 2.7M20.2 16l-4.7-2.7"/>',
    harmony: '<circle cx="12" cy="5" r="2.5"/><circle cx="5" cy="17" r="2.5"/><circle cx="19" cy="17" r="2.5"/><path d="M12 7.5 6.5 15M12 7.5 17.5 15M7.5 17h9"/>',
    book: '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
    gradLin: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M8 8v8" opacity=".95"/><path d="M12 8v8" opacity=".6"/><path d="M16 8v8" opacity=".3"/>',
    gradRad: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5" opacity=".6"/><circle cx="12" cy="12" r="1.5"/>',
    swap: '<path d="M7 4 3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7"/>',
    maximize2: '<path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>',
    compass: '<circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5-5 2 2-5z"/>',
    lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    expand: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
    selRect: '<rect x="4" y="4" width="16" height="16" rx="1" stroke-dasharray="3.5 3"/>',
    selLasso: '<path d="M7 17c-3-1-4-4-2-7 2-4 8-6 12-3 3 2 3 6 0 8-2 1-5 1-7 0"/><path d="M9 17c0 2-1 3-3 4"/>',
    selWand: '<path d="m4 20 11-11"/><path d="m14 3 1 2.4 2.4 1-2.4 1L14 10l-1-2.6-2.4-1 2.4-1z"/><path d="M19 13l.6 1.4 1.4.6-1.4.6L19 17l-.6-1.4-1.4-.6 1.4-.6z"/>',
    selAll: '<rect x="3" y="3" width="18" height="18" rx="2" stroke-dasharray="3 3"/><path d="m8 12 3 3 5-6"/>',
    close: '<path d="M6 6l12 12M18 6 6 18"/>',
    cut: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4 8.1 15.9M14.5 14.5 20 20M8.1 8.1 12 12"/>',
    paste: '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/>',
    clipboard: '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2M9 12h6M9 16h4"/>',
    skew: '<path d="M7 5h13l-3 14H4z"/>',
    text: '<path d="M5 6V4h14v2M12 4v16M9 20h6"/>',
    curve: '<path d="M4 18C8 4 16 20 20 6"/><circle cx="4" cy="18" r="1.6"/><circle cx="20" cy="6" r="1.6"/>',
    poly: '<path d="M12 3 21 9.5 17.5 20h-11L3 9.5z"/>',
    arc: '<path d="M4 17a8 8 0 0 1 16 0"/><circle cx="4" cy="17" r="1.5"/><circle cx="20" cy="17" r="1.5"/>',
    ruler: '<path d="M3 17 17 3l4 4L7 21z"/><path d="m8 8 2 2M11 5l2 2M5 11l2 2"/>',
    guideH: '<path d="M3 12h18" stroke-dasharray="3 3"/><path d="M12 5v4M12 15v4"/>',
    guideV: '<path d="M12 3v18" stroke-dasharray="3 3"/><path d="M5 12h4M15 12h4"/>',
    symV: '<path d="M12 3v18" stroke-dasharray="2 2.5"/><path d="M9 7 4 12l5 5zM15 7l5 5-5 5z"/>',
    symH: '<path d="M3 12h18" stroke-dasharray="2 2.5"/><path d="M7 9 12 4l5 5zM7 15l5 5 5-5z"/>',
    symVH: '<path d="M12 3v18M3 12h18" stroke-dasharray="2 2.5"/><circle cx="7" cy="7" r="2"/><circle cx="17" cy="7" r="2"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/>',
    symRad: '<circle cx="12" cy="12" r="2"/><path d="M12 3v5M12 16v5M3 12h5M16 12h5M5.6 5.6l3.5 3.5M14.9 14.9l3.5 3.5M18.4 5.6l-3.5 3.5M9.1 14.9l-3.5 3.5"/>',
    persp1: '<path d="M12 11 3 20M12 11l9 9M12 11 3 6M12 11l9-5M12 11v-8"/><circle cx="12" cy="11" r="1.5"/>',
    persp2: '<path d="M3 12 12 20 21 12M3 12l9-8 9 8"/><circle cx="3" cy="12" r="1.4"/><circle cx="21" cy="12" r="1.4"/>',
    persp3: '<path d="M3 15 12 21 21 15M3 15l9-3 9 3M12 3l-9 12M12 3l9 12"/><circle cx="12" cy="3" r="1.4"/>',
    alignL: '<path d="M4 6h16M4 10h10M4 14h16M4 18h10"/>', alignC: '<path d="M4 6h16M7 10h10M4 14h16M7 18h10"/>', alignR: '<path d="M4 6h16M10 10h10M4 14h16M10 18h10"/>',
    bold: '<path d="M7 5h6a3.5 3.5 0 0 1 0 7H7zM7 12h7a3.5 3.5 0 0 1 0 7H7z"/>', italic: '<path d="M10 4h8M6 20h8M14 4 10 20"/>', outline: '<rect x="4" y="4" width="16" height="16" rx="3" stroke-dasharray="2 3"/><path d="M9 15V9l3 4 3-4v6"/>',
    camera: '<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3z"/><circle cx="12" cy="13" r="3.5"/>',
    refIc: '<rect x="3" y="6" width="12" height="14" rx="1.5"/><rect x="9" y="3" width="12" height="14" rx="1.5" opacity=".55"/>',
    traceIc: '<path d="M4 20 20 4"/><rect x="3" y="3" width="18" height="18" rx="2" stroke-dasharray="2 3"/>',
    drop: '<path d="M12 3s7 7 7 12a7 7 0 0 1-14 0c0-5 7-12 7-12z"/>',
    wave: '<path d="M3 12c2.5-6 5 6 7.5 0s5 6 7.5 0 2-3 3-3"/>',
    grain: '<circle cx="6" cy="6" r="1.2"/><circle cx="12" cy="5" r="1.2"/><circle cx="18" cy="7" r="1.2"/><circle cx="8" cy="12" r="1.2"/><circle cx="15" cy="12" r="1.2"/><circle cx="5" cy="18" r="1.2"/><circle cx="11" cy="18" r="1.2"/><circle cx="18" cy="17" r="1.2"/>',
    dots: '<circle cx="7" cy="8" r="2"/><circle cx="16" cy="6" r="1.4"/><circle cx="12" cy="13" r="2.6"/><circle cx="19" cy="15" r="1.6"/><circle cx="6" cy="18" r="1.4"/>',
    upload: '<path d="M12 21V9M7 14l5-5 5 5M5 3h14"/>',
    star2: '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
    curveSoft: '<path d="M4 20C4 8 12 5 20 4"/>',
    curveLin: '<path d="M4 20 20 4"/>',
    curveHard: '<path d="M4 20c10 0 15-6 16-16"/>',
    fillsq: '<rect x="4" y="4" width="16" height="16" rx="2"/>',
    outsq: '<rect x="4.5" y="4.5" width="15" height="15" rx="2"/>'
  };
  const ICON_FILLED = new Set(['play', 'pause', 'fillsq']);
  const svg = (name, size) => `<svg viewBox="0 0 24 24" width="${size || 24}" height="${size || 24}" fill="${ICON_FILLED.has(name) ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON[name] || ''}</svg>`;
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const iconBtn = (cls, icon, label, onClick, size) => {
    const b = el('button', cls, svg(icon, size || 24)); b.type = 'button';
    b.setAttribute('aria-label', label); b.title = label; b.onclick = onClick; return b;
  };
  function hydrateIcons() {
    $$('#screen-kix-paint [data-ic]').forEach(n => { n.innerHTML = svg(n.dataset.ic, Number(n.dataset.sz) || 24); });
  }

  // ===================== Barra de ferramentas =====================
  function setTool(tool) {
    if (tool === 'eyedropper' && KP.tool !== 'eyedropper') KP.prevTool = KP.tool;
    if (tool !== KP.tool && tool !== 'eyedropper') { if (KP.float) commitFloat(true); if (KP.pending && KP.pending.kind !== tool) commitPending(true); if (KP.xfRef) stopEditRef(); }
    KP.tool = tool;
    if (isShapeLike(tool)) KP.shapeKind = tool;
    if (isSelTool(tool)) KP.selKind = tool;
    refreshToolbar();
  }
  function setColor(hex, quiet) {
    if (KP.slot === 2) KP.color2 = hex; else KP.color = hex;
    if (!quiet) { const recent = loadRecent().filter(c => c !== hex); recent.unshift(hex); saveRecent(recent); noteProjectColor(hex); }
    const paint = (id, c) => { const n = $(id); if (!n) return; n.style.background = c === 'transparent' ? '' : c; n.classList.toggle('kp-transparent', c === 'transparent'); };
    paint('kp-color-dot', KP.color); paint('kp-cur-color-swatch', KP.color); paint('kp-cur-color-swatch2', KP.color2);
  }
  function refreshToolbar() {
    $$('#kp-tools [data-kp-tool]').forEach(b => {
      const t = b.dataset.kpTool;
      if (t === 'color') { b.classList.toggle('sheet-open', KP.sheet === 'color'); b.classList.toggle('active', KP.tool === 'eyedropper'); return; }
      b.classList.toggle('active', t === 'shape' ? isShapeLike(KP.tool) : t === 'select' ? isSelTool(KP.tool) : KP.tool === t);
    });
    const sb = document.querySelector('#kp-tools [data-kp-tool="shape"]');
    if (sb) sb.innerHTML = svg(KP.shapeKind ? SHAPE_ICON[KP.shapeKind] : 'shapes', 26);
    const sbn = document.querySelector('#kp-tools [data-kp-tool="select"]'); if (sbn) sbn.innerHTML = svg(SEL_ICON[KP.selKind] || 'selRect', 26);
    const fb = document.querySelector('#kp-tools [data-kp-tool="fill"]');
    if (fb) fb.innerHTML = svg(KP.fill.mode === 'fill' ? 'bucket' : KP.fill.mode === 'linear' ? 'gradLin' : 'gradRad', 26);
    const kind = sliderKind(), opt = $('kp-options');
    if (opt) opt.classList.toggle('kp-opt-off', !kind);
    const sz = $('kp-size');
    if (sz && KP.doc && kind) {
      if (kind === 'tol') { sz.max = 100; sz.value = KP.fill.tol; $('kp-size-num').textContent = KP.fill.tol + '%'; }
      else if (kind === 'wand') { sz.max = 100; sz.value = KP.wandTol; $('kp-size-num').textContent = KP.wandTol + '%'; }
      else { const ab = activeBrush(); sz.max = KP.doc.pixelArt ? 24 : 120; ab.size = clamp(Math.round(ab.size), 1, Number(sz.max)); sz.value = ab.size; $('kp-size-num').textContent = ab.size; }
    }
    $('kp-more') && $('kp-more').classList.toggle('on', KP.sheet === 'more');
    $('kp-layers') && $('kp-layers').classList.toggle('on', KP.sheet === 'layers');
  }
  function onToolTap(kind) {
    if (kind === 'color') return toggleSheet('color');
    if (kind === 'select') {
      if (isSelTool(KP.tool)) return toggleSheet('select');
      setTool(KP.selKind || 'select-rect'); return openSheet('select');
    }
    if (kind === 'shape') {
      if (isShapeLike(KP.tool)) return toggleSheet('shape');
      setTool(KP.shapeKind || 'rect'); return openSheet('shape');
    }
    if (KP.tool === kind) { if (kind === 'brush' || kind === 'eraser' || kind === 'fill') toggleSheet(kind); else closeSheet(); return; }
    setTool(kind); closeSheet();
  }

  // ===================== Gavetas (painéis que sobem de baixo) =====================
  const SHEETS = () => ({ select: renderSelectSheet, guides: renderGuidesSheet, refs: renderRefsSheet, xform: renderXformSheet, fill: renderFillSheet, brush: renderBrushSheet, brushedit: renderBrushEditor, eraser: renderEraserSheet, shape: renderShapeSheet, color: renderColorSheet, layers: renderLayersSheet, more: renderMoreSheet });
  function openSheet(name) {
    if (KP.playing) togglePlay();
    closeFrameMenu();
    KP.sheet = name;
    const panel = $('kp-panel');
    panel.innerHTML = '';
    const inner = el('div', 'kp-panel-inner'); panel.appendChild(inner);
    SHEETS()[name](inner);
    panel.classList.add('open'); panel.classList.toggle('tall', ['brushedit', 'color', 'fill', 'select', 'guides', 'refs', 'xform'].includes(name));
    refreshToolbar();
  }
  function closeSheet() {
    KP.sheet = null; KP.slot = 1;
    $('kp-panel').classList.remove('open');
    refreshToolbar();
  }
  function toggleSheet(name) { KP.sheet === name ? closeSheet() : openSheet(name); }
  function rerenderSheet() {
    if (!KP.sheet) return;
    const inner = $('kp-panel').querySelector('.kp-panel-inner'); if (!inner) return;
    const top = inner.scrollTop; inner.innerHTML = '';
    SHEETS()[KP.sheet](inner);
    inner.scrollTop = top;
  }

  // ===================== Pincéis (interface; a lógica fica em kix-paint-brush.js) =====================
  const CUSTOM_LS_KEY = 'kix_paint_brushes_v2', OLD_LS_KEY = 'kix_paint_brushes_v1';
  function loadCustomBrushes() {
    try {
      const v = JSON.parse(localStorage.getItem(CUSTOM_LS_KEY) || 'null');
      if (Array.isArray(v)) return v.map(b => { const n = KixBrush.normalize(b); n.preset = false; return n; });
    } catch (_) {}
    const out = [];   // migra pincéis salvos na versão anterior (os 5 padrões antigos não entram)
    try {
      const old = JSON.parse(localStorage.getItem(OLD_LS_KEY) || 'null');
      if (Array.isArray(old)) old.filter(b => b && !/^b[1-5]$/.test(b.id)).forEach(b => out.push(KixBrush.normalize({
        name: b.name, size: b.size, opacity: b.opacity, spacing: b.spacing, tip: { shape: b.shape === 'square' ? 'square' : 'round', hardness: b.hardness }
      })));
    } catch (_) {}
    return out;
  }
  function saveCustomBrushes() {
    try { localStorage.setItem(CUSTOM_LS_KEY, JSON.stringify(KP.customBrushes)); return true; }
    catch (_) { toast('Sem espaço para salvar o pincel'); return false; }
  }
  const activeBrush = () => KP.tool === 'eraser' ? KP.eraser : KP.brush;
  const sliderKind = () => KP.tool === 'select-wand' ? 'wand' : KP.tool === 'fill' ? (KP.fill.mode === 'fill' ? 'tol' : null) : (SIZED_TOOLS.includes(KP.tool) ? 'size' : null);
  const isCustomBrush = (b) => KP.customBrushes.some(c => c.id === b.id);
  function pixelFit(b) { if (KP.doc && KP.doc.pixelArt) b.size = clamp(Math.round(b.size / 8), 1, 4); return b; }

  // --- pré-visualização real (o próprio motor desenha uma amostra) ---
  const pvCache = new Map();
  const PV_COLOR = '#C8C8C8';
  function pvKey(b) { return JSON.stringify(b, (k, v) => (k === 'image' && v) ? v.length + v.slice(-16) : v); }
  function paintPreview(cv, b) {
    const key = pvKey(b), hit = pvCache.get(key);
    if (hit) { cv.getContext('2d').drawImage(hit, 0, 0); return; }
    const go = () => {
      KixBrush.preview(cv, b, PV_COLOR);
      if (pvCache.size > 80) pvCache.clear();
      const copy = document.createElement('canvas'); copy.width = cv.width; copy.height = cv.height; copy.getContext('2d').drawImage(cv, 0, 0); pvCache.set(key, copy);
    };
    if (b.tip.image || b.texture.image) KixBrush.preload(b).then(go); else go();
  }
  function brushChip(b, active, onPick) {
    const chip = el('button', 'kp-bchip' + (active ? ' on' : '')); chip.type = 'button'; chip.title = b.name; chip.setAttribute('aria-label', b.name);
    const cv = document.createElement('canvas'); cv.width = 240; cv.height = 72; chip.appendChild(cv);
    chip.appendChild(el('span', 'kp-bchip-name', '')).textContent = b.name;
    paintPreview(cv, b);
    chip.onclick = onPick; return chip;
  }
  function pickBrush(p) {
    KP.brush = pixelFit(KixBrush.clone(p)); KP.brush.preset = !!p.preset; KP.brush.id = p.id;
    KixBrush.preload(KP.brush); refreshToolbar(); rerenderSheet();
  }
  function stabDots(b, onChange) {
    const row = el('div', 'kp-stab'); row.appendChild(el('span', 'kp-ico', svg('wave', 20)));
    for (let i = 0; i < 5; i++) {
      const d = el('button', 'kp-stab-dot' + (b.stab === i ? ' on' : '') + (i <= b.stab ? ' fill' : '')); d.type = 'button';
      d.setAttribute('aria-label', 'Estabilização ' + i); d.title = ['Desligada', 'Baixa', 'Média', 'Alta', 'Muito alta'][i];
      d.onclick = () => { b.stab = i; b.stabDist = -1; b.stabSmooth = -1; onChange(); };
      row.appendChild(d);
    }
    return row;
  }
  function opacityRow(b) {
    const top = el('div', 'kp-brush-top'); top.appendChild(el('span', 'kp-ico', svg('drop', 20)));
    const op = el('input'); op.type = 'range'; op.min = 5; op.max = 100; op.value = b.opacity; op.setAttribute('aria-label', 'Opacidade');
    const v = el('span', 'kp-val', Math.round(b.opacity) + '%');
    op.oninput = () => { b.opacity = Number(op.value); v.textContent = op.value + '%'; };
    top.appendChild(op); top.appendChild(v); return top;
  }
  function renderBrushSheet(inner, eraserMode) {
    const b = eraserMode ? KP.eraser : KP.brush;
    inner.appendChild(opacityRow(b));
    inner.appendChild(stabDots(b, rerenderSheet));
    const grid = el('div', 'kp-bgrid');
    (eraserMode ? KixBrush.ERASERS : KixBrush.PRESETS).forEach(p => grid.appendChild(brushChip(p, b.id === p.id, () => {
      if (eraserMode) { KP.eraser = pixelFit(KixBrush.clone(p)); KP.eraser.preset = true; KP.eraser.id = p.id; refreshToolbar(); rerenderSheet(); } else pickBrush(p);
    })));
    inner.appendChild(grid);
    if (eraserMode) return;
    if (KP.customBrushes.length) {
      inner.appendChild(el('div', 'kp-sub', svg('star', 16)));
      const g2 = el('div', 'kp-bgrid');
      KP.customBrushes.forEach(p => g2.appendChild(brushChip(p, b.id === p.id, () => pickBrush(p))));
      inner.appendChild(g2);
    }
    const acts = el('div', 'kp-adv-actions');
    acts.appendChild(iconBtn('kp-sq-btn', 'sliders', 'Editar pincel', () => openSheet('brushedit'), 24));
    acts.appendChild(iconBtn('kp-sq-btn', 'upload', 'Importar pincel (.kixbrush)', () => $('kp-input-brush').click(), 24));
    inner.appendChild(acts);
  }
  const renderEraserSheet = (inner) => renderBrushSheet(inner, true);

  // --- editor de pincéis ---
  const fmt = (v, u) => Math.round(v) + (u || '');
  function slider(label, get, set, min, max, unit, disabled) {
    const r = el('div', 'kp-adv-row'); r.appendChild(el('span', 'kp-adv-label', label));
    const inp = el('input'); inp.type = 'range'; inp.min = min; inp.max = max; inp.value = get(); inp.disabled = !!disabled;
    const v = el('span', 'kp-val', fmt(get(), unit));
    inp.oninput = () => { set(Number(inp.value)); v.textContent = fmt(inp.value, unit); refreshToolbar(); if (KP._pvRedraw) KP._pvRedraw(); };
    r.appendChild(inp); r.appendChild(v); return r;
  }
  function chipRow(items, current, onPick) {
    const row = el('div', 'kp-chips');
    items.forEach(it => {
      const c = el('button', 'kp-chip' + (current === it.id ? ' on' : '')); c.type = 'button'; c.title = it.label; c.setAttribute('aria-label', it.label);
      if (it.icon) c.innerHTML = svg(it.icon, 24); if (it.thumb) { const cv = document.createElement('canvas'); cv.width = cv.height = 48; KixBrush.textureThumb(it.thumb, cv); c.appendChild(cv); }
      if (it.text) c.appendChild(el('span', 'kp-chip-t', it.text));
      c.onclick = () => onPick(it.id); row.appendChild(c);
    });
    return row;
  }
  function toggleBtn(icon, label, on, onClick) {
    const b = el('button', 'kp-toggle' + (on ? ' on' : ''), svg(icon, 22) + '<span>' + label + '</span>'); b.type = 'button'; b.onclick = onClick; return b;
  }
  function pickImage(target) { KP._imgTarget = target; $('kp-input-img').click(); }
  function renderBrushEditor(inner) {
    const b = KP.brush;
    const pv = document.createElement('canvas'); pv.width = 640; pv.height = 110; pv.className = 'kp-bpreview'; inner.appendChild(pv);
    let raf = 0; KP._pvRedraw = () => { if (raf) return; raf = requestAnimationFrame(() => { raf = 0; KixBrush.preview(pv, KP.brush, PV_COLOR); }); };
    KixBrush.preload(b).then(() => KP._pvRedraw());
    const TABS = [['shape', 'circle', 'Forma'], ['stroke', 'wave', 'Traço'], ['texture', 'grain', 'Textura'], ['dyn', 'pencil', 'Pressão'], ['scatter', 'dots', 'Dispersão']];
    const tabs = el('div', 'kp-tabs'); TABS.forEach(([id, ic, lb]) => tabs.appendChild(iconBtn('kp-tab' + (KP.brushTab === id ? ' on' : ''), ic, lb, () => { KP.brushTab = id; rerenderSheet(); }, 22)));
    inner.appendChild(tabs);
    const body = el('div', 'kp-edbody'); inner.appendChild(body);
    const re = rerenderSheet;
    if (KP.brushTab === 'shape') {
      body.appendChild(chipRow([{ id: 'round', icon: 'circle', label: 'Redondo' }, { id: 'square', icon: 'square', label: 'Quadrado' }, { id: 'image', icon: 'image', label: 'Imagem' }], b.tip.shape, (id) => {
        if (id === 'image' && !b.tip.image) { pickImage('tip'); return; }
        b.tip.shape = id; re();
      }));
      body.appendChild(slider('Dureza', () => b.tip.hardness, v => b.tip.hardness = v, 0, 100, '%'));
      body.appendChild(slider('Achatar', () => 105 - b.tip.roundness, v => b.tip.roundness = 105 - v, 5, 100, '%'));
      body.appendChild(slider('Ângulo', () => b.tip.angle, v => b.tip.angle = v, -180, 180, '°'));
      body.appendChild(slider('Ângulo aleat.', () => b.dyn.angleJitter, v => b.dyn.angleJitter = v, 0, 100, '%'));
      const t = el('div', 'kp-toggles');
      t.appendChild(toggleBtn('move', 'Seguir o traço', b.tip.followStroke, () => { b.tip.followStroke = !b.tip.followStroke; re(); }));
      t.appendChild(toggleBtn('grid', 'Pixel nítido', b.tip.snap, () => { b.tip.snap = !b.tip.snap; re(); }));
      body.appendChild(t);
      if (b.tip.image) body.appendChild(iconBtn('kp-sq-btn', 'image', 'Trocar imagem da ponta', () => pickImage('tip'), 22));
    } else if (KP.brushTab === 'stroke') {
      const maxS = KP.doc.pixelArt ? 24 : 120;
      body.appendChild(slider('Tamanho', () => Math.min(b.size, maxS), v => b.size = v, 1, maxS, 'px'));
      body.appendChild(slider('Opacidade', () => b.opacity, v => b.opacity = v, 5, 100, '%'));
      body.appendChild(slider('Fluxo', () => b.flow, v => b.flow = v, 1, 100, '%'));
      body.appendChild(slider('Espaçamento', () => b.spacing, v => b.spacing = v, 1, 200, '%'));
      body.appendChild(stabDots(b, () => { re(); KP._pvRedraw(); }));
      const ST = KixBrush.STAB;
      body.appendChild(slider('Distância', () => b.stabDist >= 0 ? b.stabDist : ST.dist[b.stab], v => b.stabDist = v, 0, 80, 'px'));
      body.appendChild(slider('Suavização', () => b.stabSmooth >= 0 ? b.stabSmooth : Math.round(ST.smooth[b.stab] * 100), v => b.stabSmooth = v, 0, 95, '%'));
    } else if (KP.brushTab === 'texture') {
      const T = KixBrush.TEXTURES.map(id => ({ id, label: id === 'none' ? 'Sem textura' : id, thumb: (id === 'none' || id === 'image') ? null : id, icon: id === 'none' ? 'circle' : id === 'image' ? 'image' : null }));
      body.appendChild(chipRow(T, b.texture.type, (id) => {
        if (id === 'image' && !b.texture.image) { pickImage('texture'); return; }
        b.texture.type = id; if (id !== 'none' && b.texture.strength < 20) b.texture.strength = 70; re(); KP._pvRedraw();
      }));
      body.appendChild(slider('Escala', () => b.texture.scale, v => b.texture.scale = v, 10, 800, '%'));
      body.appendChild(slider('Intensidade', () => b.texture.strength, v => b.texture.strength = v, 0, 100, '%'));
      if (b.texture.type === 'image') body.appendChild(iconBtn('kp-sq-btn', 'image', 'Trocar imagem da textura', () => pickImage('texture'), 22));
    } else if (KP.brushTab === 'dyn') {
      body.appendChild(slider('Tamanho ← pressão', () => b.pressure.size, v => b.pressure.size = v, 0, 100, '%'));
      body.appendChild(slider('Opacidade ← pressão', () => b.pressure.opacity, v => b.pressure.opacity = v, 0, 100, '%'));
      body.appendChild(slider('Fluxo ← pressão', () => b.pressure.flow, v => b.pressure.flow = v, 0, 100, '%'));
      body.appendChild(chipRow([{ id: 'soft', icon: 'curveSoft', label: 'Curva suave' }, { id: 'linear', icon: 'curveLin', label: 'Curva linear' }, { id: 'hard', icon: 'curveHard', label: 'Curva firme' }], b.pressure.curve, (id) => { b.pressure.curve = id; re(); KP._pvRedraw(); }));
      const t = el('div', 'kp-toggles');
      t.appendChild(toggleBtn('brush', 'Simular pressão (dedo)', b.pressure.simulate, () => { b.pressure.simulate = !b.pressure.simulate; re(); KP._pvRedraw(); }));
      body.appendChild(t);
      body.appendChild(slider('Velocidade afina', () => b.pressure.speed, v => b.pressure.speed = v, 0, 100, '%'));
      body.appendChild(slider('Inclinação da caneta', () => b.tilt, v => b.tilt = v, 0, 100, '%'));
    } else {
      body.appendChild(slider('Dispersão', () => b.dyn.scatter, v => b.dyn.scatter = v, 0, 300, '%'));
      body.appendChild(slider('Quantidade', () => b.dyn.count, v => b.dyn.count = Math.round(v), 1, 12, 'x'));
      body.appendChild(slider('Variar tamanho', () => b.dyn.sizeJitter, v => b.dyn.sizeJitter = v, 0, 100, '%'));
      body.appendChild(slider('Variar fluxo', () => b.dyn.flowJitter, v => b.dyn.flowJitter = v, 0, 100, '%'));
      body.appendChild(slider('Borda úmida', () => b.wet, v => b.wet = v, 0, 100, '%'));
    }
    // ações
    const acts = el('div', 'kp-adv-actions kp-ed-actions');
    acts.appendChild(iconBtn('kp-sq-btn', 'plus', 'Salvar como novo pincel', () => Modal.prompt('Novo pincel', 'Nome do pincel', b.preset ? b.name + ' 2' : b.name, (name) => {
      if (!name) return;
      const nb = KixBrush.normalize(Object.assign(KixBrush.clone(KP.brush), { id: '', name, preset: false, icon: 'custom' }));
      KP.customBrushes.push(nb); if (saveCustomBrushes()) { KP.brush = nb; rerenderSheet(); toast('Pincel salvo'); }
    }), 22));
    if (isCustomBrush(b)) {
      acts.appendChild(iconBtn('kp-sq-btn', 'check', 'Atualizar este pincel', () => {
        const i = KP.customBrushes.findIndex(c => c.id === b.id); if (i < 0) return;
        KP.customBrushes[i] = KixBrush.normalize(Object.assign(KixBrush.clone(KP.brush), { id: b.id, preset: false })); if (saveCustomBrushes()) toast('Pincel atualizado');
      }, 22));
      acts.appendChild(iconBtn('kp-sq-btn kp-danger', 'trash', 'Excluir pincel', () => Modal.confirm('Excluir pincel', 'Excluir "' + b.name + '"?', () => {
        KP.customBrushes = KP.customBrushes.filter(c => c.id !== b.id); saveCustomBrushes(); pickBrush(KixBrush.PRESETS[0]); openSheet('brush');
      }), 22));
    } else {
      acts.appendChild(iconBtn('kp-sq-btn', 'undo', 'Restaurar o padrão', () => { const f = KixBrush.PRESETS.find(p => p.id === b.id); if (f) { pickBrush(f); } }, 22));
    }
    acts.appendChild(iconBtn('kp-sq-btn', 'download', 'Exportar (.kixbrush)', () => {
      const nm = (b.name || 'pincel').replace(/[^\w\-]+/g, '_').slice(0, 32) || 'pincel';
      downloadBlob(new Blob([KixBrush.serialize([b])], { type: 'application/json' }), nm + '.kixbrush'); toast('Pincel exportado');
    }, 22));
    acts.appendChild(iconBtn('kp-sq-btn', 'upload', 'Importar (.kixbrush)', () => $('kp-input-brush').click(), 22));
    inner.appendChild(acts);
    KP._pvRedraw();
  }
  // importar .kixbrush / imagens
  function bindBrushInputs() {
    const bi = $('kp-input-brush');
    if (bi) bi.onchange = (e) => {
      const f = e.target.files && e.target.files[0]; e.target.value = ''; if (!f) return;
      const rd = new FileReader();
      rd.onload = () => {
        try {
          const list = KixBrush.parse(rd.result);
          list.forEach(b => KP.customBrushes.push(b)); if (!saveCustomBrushes()) return;
          pickBrush(list[0]); toast(list.length > 1 ? list.length + ' pincéis importados' : 'Pincel importado'); openSheet('brush');
        } catch (err) { toast(err.message || 'Arquivo inválido'); }
      };
      rd.readAsText(f);
    };
    const ii = $('kp-input-img');
    if (ii) ii.onchange = (e) => {
      const f = e.target.files && e.target.files[0]; e.target.value = ''; if (!f) return;
      const rd = new FileReader();
      rd.onload = () => {
        const im = new Image();
        im.onload = () => {
          if (KP._imgTarget === 'palette') {
            const cols = extractPalette(im, 16); if (!cols.length) { toast('Nenhuma cor encontrada'); return; }
            const p = { id: newId(), name: 'Imagem ' + (KP.pals.palettes.length + 1), colors: cols }; KP.pals.palettes.push(p); KP.palSel = p.id; savePalettes(); KP.colorTab = 'palettes'; if (KP.sheet === 'color') rerenderSheet(); toast('Paleta criada (' + cols.length + ' cores)'); return;
          }
          const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d');
          const s = Math.min(im.naturalWidth, im.naturalHeight), sx = (im.naturalWidth - s) / 2, sy = (im.naturalHeight - s) / 2;
          x.drawImage(im, sx, sy, s, s, 0, 0, 128, 128);
          const url = c.toDataURL('image/png'), b = KP.brush;
          if (KP._imgTarget === 'tip') { b.tip.image = url; b.tip.shape = 'image'; } else { b.texture.image = url; b.texture.type = 'image'; if (b.texture.strength < 20) b.texture.strength = 80; }
          KixBrush.preload(b).then(() => { rerenderSheet(); });
        };
        im.onerror = () => toast('Imagem inválida'); im.src = String(rd.result);
      };
      rd.readAsDataURL(f);
    };
  }

  // ===================== Interface de vista (alças, guias, seleção) =====================
  const uiDrawers = [];
  let uiRaf = 0;
  function scheduleUi() { if (!uiRaf) uiRaf = requestAnimationFrame(() => { uiRaf = 0; drawUi(); }); }
  function drawUi() {
    const c = $('kp-canvas-ui'), w = $('kp-stage-wrap'); if (!c || !w || !KP.doc) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1), W = w.clientWidth, H = w.clientHeight;
    if (c.width !== Math.round(W * dpr) || c.height !== Math.round(H * dpr)) { c.width = Math.round(W * dpr); c.height = Math.round(H * dpr); }
    const ctx = c.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, W, H);
    uiDrawers.forEach(fn => fn(ctx, W, H));
  }
  KP._viewChanged = () => { scheduleUi(); scheduleAnts(); };
  const dashLine = (ctx, pts, close) => {      // contorno "formigas": branco + preto tracejado
    if (pts.length < 2) return;
    ctx.save(); ctx.lineWidth = 1.5; ctx.lineJoin = 'round';
    ctx.beginPath(); pts.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)); if (close) ctx.closePath();
    ctx.strokeStyle = '#fff'; ctx.setLineDash([]); ctx.stroke();
    ctx.strokeStyle = '#000'; ctx.setLineDash([5, 5]); ctx.lineDashOffset = -(KP._antPhase || 0); ctx.stroke(); ctx.restore();
  };

  // ===================== Seleção =====================
  // KP.sel = { mask (canvas do tamanho do desenho, alfa = dentro), bbox, edge }
  const newCanvas = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
  const maskCanvas = () => newCanvas(KP.doc.w, KP.doc.h);
  function bboxOfCanvas(cv) {
    const d = cv.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, cv.width, cv.height).data, W = cv.width;
    let x0 = 1e9, y0 = 1e9, x1 = -1, y1 = -1;
    for (let i = 3, p = 0; i < d.length; i += 4, p++) if (d[i] > 8) { const x = p % W, y = (p / W) | 0; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    return x1 < 0 ? null : { x: x0, y: y0, w: x1 - x0 + 1, h: y1 - y0 + 1 };
  }
  function maskFromRect(x, y, w, h) { const c = maskCanvas(), x2 = c.getContext('2d'); x2.fillStyle = '#000'; x2.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h)); return c; }
  function maskFromPoly(pts) {
    const c = maskCanvas(), x = c.getContext('2d'); x.fillStyle = '#000'; x.beginPath(); pts.forEach((p, i) => i ? x.lineTo(p.x, p.y) : x.moveTo(p.x, p.y)); x.closePath(); x.fill(); return c;
  }
  function maskFromRegion(region) {
    const c = maskCanvas(), x = c.getContext('2d'), id = x.createImageData(KP.doc.w, KP.doc.h);
    for (let p = 0; p < region.length; p++) if (region[p]) id.data[p * 4 + 3] = 255;
    x.putImageData(id, 0, 0); return c;
  }
  function setSelection(mask, mode) {
    if (!KP.sel || mode === 'new' || !mode) KP.sel = { mask };
    else { const x = KP.sel.mask.getContext('2d'); x.save(); x.globalCompositeOperation = mode === 'sub' ? 'destination-out' : 'source-over'; x.drawImage(mask, 0, 0); x.restore(); }
    KP.sel.bbox = bboxOfCanvas(KP.sel.mask);
    if (!KP.sel.bbox) { clearSelection(); return; }
    rebuildAnts(); refreshToolbar(); if (KP.sheet === 'select') rerenderSheet(); scheduleUi();
  }
  function clearSelection() {
    KP.sel = null; const c = $('kp-canvas-sel'); if (c) c.getContext('2d').clearRect(0, 0, c.width, c.height);
    clearInterval(KP._antsTimer); KP._antsTimer = 0; refreshToolbar(); if (KP.sheet === 'select') rerenderSheet(); scheduleUi();
  }
  // formigas marchando: contorno da máscara pintado com listras que andam
  function rebuildAnts() {
    const sel = KP.sel; if (!sel) return;
    const t = Math.round(clamp(1.6 / KP.zoom, 1, 8)), er = maskCanvas(), ec = er.getContext('2d');
    ec.drawImage(sel.mask, 0, 0); ec.globalCompositeOperation = 'destination-in';
    [[t, 0], [-t, 0], [0, t], [0, -t]].forEach(([dx, dy]) => ec.drawImage(sel.mask, dx, dy));
    const edge = maskCanvas(), ex = edge.getContext('2d'); ex.drawImage(sel.mask, 0, 0); ex.globalCompositeOperation = 'destination-out'; ex.drawImage(er, 0, 0);
    sel.edge = edge; sel.antsT = t; sel.stripe = newCanvas(8, 8);
    const sx = sel.stripe.getContext('2d'); sx.fillStyle = '#fff'; sx.fillRect(0, 0, 8, 8); sx.fillStyle = '#000'; sx.beginPath(); sx.moveTo(0, 4); sx.lineTo(4, 0); sx.lineTo(8, 0); sx.lineTo(0, 8); sx.fill(); sx.beginPath(); sx.moveTo(8, 4); sx.lineTo(4, 8); sx.lineTo(8, 8); sx.lineTo(8, 4); sx.fill();
    paintAnts();
    clearInterval(KP._antsTimer);
    if (KP.doc.w * KP.doc.h < 3e6) KP._antsTimer = setInterval(() => { if (!KP.sel || $('screen-kix-paint').classList.contains('hidden')) return; KP._antPhase = ((KP._antPhase || 0) + 1) % 8; paintAnts(); }, 140);
  }
  function paintAnts() {
    const sel = KP.sel, c = $('kp-canvas-sel'); if (!c) return; const x = c.getContext('2d'); x.clearRect(0, 0, c.width, c.height); if (!sel || !sel.edge) return;
    x.globalCompositeOperation = 'source-over'; x.drawImage(sel.edge, 0, 0); x.globalCompositeOperation = 'source-in';
    const pat = x.createPattern(sel.stripe, 'repeat'), z = 1 / KP.zoom;
    if (pat.setTransform) pat.setTransform(new DOMMatrix().translate((KP._antPhase || 0) * z, 0).scale(z));
    x.fillStyle = pat; x.fillRect(0, 0, c.width, c.height); x.globalCompositeOperation = 'source-over';
  }
  let antsT = 0;
  function scheduleAnts() { if (!KP.sel || antsT) return; antsT = setTimeout(() => { antsT = 0; if (KP.sel && Math.round(clamp(1.6 / KP.zoom, 1, 8)) !== KP.sel.antsT) rebuildAnts(); }, 160); }

  // --- limitar ferramentas à seleção ---
  function restoreOutside(layer, snap, r) {
    if (!KP.sel) return;
    r = r || { x: 0, y: 0, w: KP.doc.w, h: KP.doc.h };
    const out = newCanvas(r.w, r.h), ox = out.getContext('2d');
    ox.fillStyle = '#000'; ox.fillRect(0, 0, r.w, r.h); ox.globalCompositeOperation = 'destination-out'; ox.drawImage(KP.sel.mask, r.x, r.y, r.w, r.h, 0, 0, r.w, r.h);   // alfa = fora da seleção
    const old = newCanvas(r.w, r.h), oc = old.getContext('2d'); oc.drawImage(snap, r.x, r.y, r.w, r.h, 0, 0, r.w, r.h); oc.globalCompositeOperation = 'destination-in'; oc.drawImage(out, 0, 0);
    const lx = layer.ctx; lx.save(); lx.globalCompositeOperation = 'destination-out'; lx.drawImage(out, r.x, r.y); lx.globalCompositeOperation = 'source-over'; lx.drawImage(old, r.x, r.y); lx.restore();
  }
  function withSelection(layer, fn) {
    if (!KP.sel) return fn();
    const snap = newCanvas(KP.doc.w, KP.doc.h); snap.getContext('2d').drawImage(layer.canvas, 0, 0);
    const res = fn(); restoreOutside(layer, snap); return res;
  }

  // --- criar a seleção com o dedo ---
  function selBegin(e, p) {
    if (KP.tool === 'select-wand') {
      const layer = currentLayer(), W = KP.doc.w, H = KP.doc.h;
      if (p.x < 0 || p.y < 0 || p.x >= W || p.y >= H) return;
      const d = layer.ctx.getImageData(0, 0, W, H).data, x = Math.floor(p.x), y = Math.floor(p.y);
      setSelection(maskFromRegion(computeSelectionMask(d, W, H, x, y, KP.wandTol, KP.wandContiguous)), KP.selMode); return;
    }
    KP._stroke = { type: 'select', kind: KP.tool, start: p, last: p, pts: [p] };
  }
  function selMove(p) {
    const s = KP._stroke; s.last = p; if (s.kind === 'select-lasso') { const q = s.pts[s.pts.length - 1]; if (Math.hypot(p.x - q.x, p.y - q.y) > 1.2 / KP.zoom) s.pts.push(p); }
    scheduleUi();
  }
  function selEnd() {
    const s = KP._stroke; KP._stroke = null;
    if (s.kind === 'select-rect') {
      const x = Math.min(s.start.x, s.last.x), y = Math.min(s.start.y, s.last.y), w = Math.abs(s.last.x - s.start.x), h = Math.abs(s.last.y - s.start.y);
      if (w < 2 || h < 2) { if (KP.selMode === 'new') clearSelection(); } else setSelection(maskFromRect(x, y, w, h), KP.selMode);
    } else if (s.pts.length >= 3) setSelection(maskFromPoly(s.pts), KP.selMode);
    else if (KP.selMode === 'new') clearSelection();
    scheduleUi();
  }
  function drawSelPreviewUi(ctx) {
    const s = KP._stroke; if (!s || s.type !== 'select') return;
    let pts;
    if (s.kind === 'select-rect') { const a = s.start, b = s.last; pts = [{ x: a.x, y: a.y }, { x: b.x, y: a.y }, { x: b.x, y: b.y }, { x: a.x, y: b.y }]; } else pts = s.pts;
    dashLine(ctx, pts.map(q => docToWrap(q.x, q.y)), true);
  }
  uiDrawers.push(drawSelPreviewUi);

  // --- operações: copiar, cortar, colar, apagar, preencher, inverter ---
  function selCanvasFrom(layer) {
    const b = KP.sel.bbox, c = newCanvas(b.w, b.h), x = c.getContext('2d');
    x.drawImage(layer.canvas, b.x, b.y, b.w, b.h, 0, 0, b.w, b.h); x.globalCompositeOperation = 'destination-in'; x.drawImage(KP.sel.mask, b.x, b.y, b.w, b.h, 0, 0, b.w, b.h); return c;
  }
  function clearInsideSelection(layer) { const x = layer.ctx; x.save(); x.globalCompositeOperation = 'destination-out'; x.drawImage(KP.sel.mask, 0, 0); x.restore(); }
  async function copySel(cut) {
    if (!KP.sel) { toast('Selecione algo primeiro'); return; }
    const layer = currentLayer(), c = selCanvasFrom(layer);
    KP.clip = { canvas: c, x: KP.sel.bbox.x, y: KP.sel.bbox.y };
    try { const blob = await new Promise(r => c.toBlob(r, 'image/png')); if (navigator.clipboard && window.ClipboardItem) await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]); } catch (_) {}
    if (cut) { pushHistory(); clearInsideSelection(layer); renderAll(); }
    toast(cut ? 'Cortado' : 'Copiado');
  }
  function deleteSel() { if (!KP.sel) return; pushHistory(); clearInsideSelection(currentLayer()); renderAll(); }
  function fillSel() {
    if (!KP.sel) { toast('Selecione algo primeiro'); return; }
    pushHistory(); const layer = currentLayer(), b = KP.sel.bbox, c = newCanvas(b.w, b.h), x = c.getContext('2d');
    x.fillStyle = KP.color === 'transparent' ? '#000' : KP.color; x.fillRect(0, 0, b.w, b.h); x.globalCompositeOperation = 'destination-in'; x.drawImage(KP.sel.mask, b.x, b.y, b.w, b.h, 0, 0, b.w, b.h);
    layer.ctx.save(); layer.ctx.globalAlpha = KP.fill.opacity / 100; if (KP.color === 'transparent') layer.ctx.globalCompositeOperation = 'destination-out'; layer.ctx.drawImage(c, b.x, b.y); layer.ctx.restore(); renderAll();
  }
  function selectAll() { setSelection(maskFromRect(0, 0, KP.doc.w, KP.doc.h), 'new'); }
  function invertSel() {
    if (!KP.sel) { selectAll(); return; }
    const inv = maskCanvas(), x = inv.getContext('2d'); x.fillStyle = '#000'; x.fillRect(0, 0, inv.width, inv.height); x.globalCompositeOperation = 'destination-out'; x.drawImage(KP.sel.mask, 0, 0); setSelection(inv, 'new');
  }
  async function pasteClip(fromSystem) {
    let canvas = null;
    if (fromSystem && navigator.clipboard && navigator.clipboard.read) {
      try {
        for (const item of await navigator.clipboard.read()) { const t = item.types.find(q => q.startsWith('image/')); if (t) { canvas = await blobToCanvas(await item.getType(t)); break; } }
      } catch (_) {}
    }
    if (!canvas && KP.clip) { canvas = KP.clip.canvas; }
    if (!canvas) { toast('Nada para colar'); return; }
    startFloat(canvas, { cx: KP.clip && canvas === KP.clip.canvas ? KP.clip.x + canvas.width / 2 : KP.doc.w / 2, cy: KP.clip && canvas === KP.clip.canvas ? KP.clip.y + canvas.height / 2 : KP.doc.h / 2, kind: 'paste' });
  }
  function blobToCanvas(blob) {
    return new Promise((res, rej) => { const u = URL.createObjectURL(blob), im = new Image(); im.onload = () => { const c = newCanvas(im.naturalWidth, im.naturalHeight); c.getContext('2d').drawImage(im, 0, 0); URL.revokeObjectURL(u); res(c); }; im.onerror = () => { URL.revokeObjectURL(u); rej(new Error('Imagem inválida')); }; im.src = u; });
  }

  // --- gaveta da seleção ---
  const SEL_TOOLS = ['select-rect', 'select-lasso', 'select-wand'];
  const isSelTool = (t) => SEL_TOOLS.includes(t);
  function renderSelectSheet(inner) {
    inner.appendChild(chipRow([{ id: 'select-rect', icon: 'selRect', label: 'Retângulo' }, { id: 'select-lasso', icon: 'selLasso', label: 'Laço' }, { id: 'select-wand', icon: 'selWand', label: 'Varinha mágica' }], KP.tool, (id) => { setTool(id); rerenderSheet(); }));
    inner.appendChild(chipRow([{ id: 'new', icon: 'square', label: 'Nova seleção' }, { id: 'add', icon: 'plus', label: 'Somar à seleção' }, { id: 'sub', icon: 'minus', label: 'Subtrair da seleção' }], KP.selMode, (id) => { KP.selMode = id; rerenderSheet(); }));
    if (KP.tool === 'select-wand') {
      inner.appendChild(slider('Tolerância', () => KP.wandTol, v => KP.wandTol = v, 0, 100, '%'));
      const t = el('div', 'kp-toggles'); t.appendChild(toggleBtn('grid', 'Todas as parecidas', !KP.wandContiguous, () => { KP.wandContiguous = !KP.wandContiguous; rerenderSheet(); })); inner.appendChild(t);
    }
    const has = !!KP.sel, grid = el('div', 'kp-more-grid kp-sel-grid');
    const items = [
      { ic: 'copy', label: 'Copiar', dis: !has, fn: () => copySel(false) }, { ic: 'cut', label: 'Cortar', dis: !has, fn: () => copySel(true) },
      { ic: 'paste', label: 'Colar', fn: () => { closeSheet(); pasteClip(false); } }, { ic: 'clipboard', label: 'Da área', fn: () => { closeSheet(); pasteClip(true); } },
      { ic: 'move', label: 'Transformar', fn: () => { closeSheet(); liftSelectionToFloat(); } }, { ic: 'bucket', label: 'Preencher', dis: !has, fn: () => fillSel() },
      { ic: 'trash', label: 'Apagar', dis: !has, fn: () => deleteSel() }, { ic: 'swap', label: 'Inverter', fn: () => invertSel() },
      { ic: 'selAll', label: 'Tudo', fn: () => selectAll() }, { ic: 'close', label: 'Nada', dis: !has, fn: () => clearSelection() }
    ];
    items.forEach(it => { const b = el('button', 'kp-more-item', svg(it.ic, 24) + '<span>' + it.label + '</span>'); b.type = 'button'; if (it.dis) b.disabled = true; b.onclick = it.fn; grid.appendChild(b); });
    inner.appendChild(grid);
  }

  // ===================== Transformar: alças (escalar, girar, inclinar) e modo preciso =====================
  // Um objeto transformável tem: cx, cy (centro no desenho), w, h (tamanho original), sx, sy (escala), rot (rad), ax, ay (inclinação, rad).
  // Pode ser o "flutuante" (colado, texto, seleção levantada) ou uma imagem de referência.
  const xfObj = () => KP.float || KP.xfRef || null;
  const tanC = (a) => Math.tan(clamp(a, -1.3, 1.3));
  function xfFwd(f, X, Y) {                         // espaço local escalado -> desenho
    const kx = X + tanC(f.ax) * Y, ky = tanC(f.ay) * X + Y, c = Math.cos(f.rot), s = Math.sin(f.rot);
    return { x: f.cx + kx * c - ky * s, y: f.cy + kx * s + ky * c };
  }
  function xfInv(f, px, py) {                       // desenho -> espaço local escalado
    const dx = px - f.cx, dy = py - f.cy, c = Math.cos(-f.rot), s = Math.sin(-f.rot), kx = dx * c - dy * s, ky = dx * s + dy * c;
    const a = tanC(f.ax), b = tanC(f.ay), det = 1 - a * b || 1e-6;
    return { x: (kx - a * ky) / det, y: (ky - b * kx) / det };
  }
  function applyXfMatrix(ctx, f) { ctx.translate(f.cx, f.cy); ctx.rotate(f.rot); ctx.transform(1, tanC(f.ay), tanC(f.ax), 1, 0, 0); ctx.scale(f.sx, f.sy); }
  function xfHandles(f) {
    const hw = f.sx * f.w / 2, hh = f.sy * f.h / 2, up = 36 / KP.zoom * (f.sy < 0 ? -1 : 1);
    const H = {};
    [['tl', -1, -1], ['t', 0, -1], ['tr', 1, -1], ['r', 1, 0], ['br', 1, 1], ['b', 0, 1], ['bl', -1, 1], ['l', -1, 0]].forEach(([k, hx, hy]) => { H[k] = Object.assign({ hx, hy }, xfFwd(f, hx * hw, hy * hh)); });
    H.rot = Object.assign({ hx: 0, hy: -1 }, xfFwd(f, 0, -hh - up)); return H;
  }
  function renderFloat() {
    const f = KP.float, ctx = elOverlay.getContext('2d'); ctx.clearRect(0, 0, KP.doc.w, KP.doc.h); if (!f) return;
    ctx.save(); applyXfMatrix(ctx, f); ctx.imageSmoothingEnabled = !KP.doc.pixelArt; ctx.drawImage(f.canvas, -f.w / 2, -f.h / 2); ctx.restore();
  }
  function xfRender() { if (KP.float) renderFloat(); else if (KP.xfRef) applyRefDom(KP.xfRef); scheduleUi(); if (KP.sheet === 'xform') syncXfFields(); }
  function startFloat(canvas, o) {
    commitPending(true); commitFloat(true); KP.xfRef = null;
    const f = KP.float = { canvas, w: canvas.width, h: canvas.height, cx: o.cx, cy: o.cy, sx: 1, sy: 1, rot: 0, ax: 0, ay: 0, kind: o.kind || 'paste', lifted: !!o.lifted, text: o.text || null, selKeep: o.selKeep || null };
    // cabe na tela se for grande demais
    const fit = Math.min(1, (KP.doc.w * 0.95) / f.w, (KP.doc.h * 0.95) / f.h); if (fit < 1 && o.kind !== 'lift') { f.sx = f.sy = fit; }
    KP.xfSkew = false; KP.xfLock = true; renderFloat(); renderFloatBar(); scheduleUi();
  }
  function liftSelectionToFloat() {
    if (!KP.sel) selectAll();
    const layer = currentLayer(), b = KP.sel.bbox; pushHistory();
    const c = selCanvasFrom(layer); clearInsideSelection(layer); renderAll();
    startFloat(c, { cx: b.x + b.w / 2, cy: b.y + b.h / 2, kind: 'lift', lifted: true });
  }
  function commitFloat(apply) {
    const f = KP.float; if (!f) return;
    KP.float = null; KP._xfDrag = null;
    const ov = elOverlay.getContext('2d'); ov.clearRect(0, 0, KP.doc.w, KP.doc.h);
    if (apply) {
      if (!f.lifted) pushHistory();
      const layer = currentLayer(); layer.ctx.save(); applyXfMatrix(layer.ctx, f); layer.ctx.imageSmoothingEnabled = !KP.doc.pixelArt; layer.ctx.drawImage(f.canvas, -f.w / 2, -f.h / 2); layer.ctx.restore();
      const m = maskCanvas(), mx = m.getContext('2d'); mx.save(); applyXfMatrix(mx, f); mx.drawImage(f.canvas, -f.w / 2, -f.h / 2); mx.restore();
      setSelection(m, 'new');
    } else if (f.lifted) { const snap = KP.history.pop(); if (snap) restoreSnapshot(snap); updateUndoRedoButtons(); }
    if (KP.sheet === 'xform') closeSheet();
    renderAll(); renderFloatBar(); scheduleUi();
  }
  function flipFloatContent(h) {
    const f = KP.float; if (!f) return; const c = newCanvas(f.w, f.h), x = c.getContext('2d');
    x.save(); if (h) { x.translate(f.w, 0); x.scale(-1, 1); } else { x.translate(0, f.h); x.scale(1, -1); } x.drawImage(f.canvas, 0, 0); x.restore(); f.canvas = c; xfRender();
  }

  // --- toque nas alças ---
  function xfHit(wp) {
    const f = xfObj(); if (!f) return null;
    const H = xfHandles(f), R = 26;
    const order = ['rot', 'tl', 'tr', 'br', 'bl', 't', 'r', 'b', 'l'];
    for (const k of order) { const w = docToWrap(H[k].x, H[k].y); if (Math.hypot(w.x - wp.x, w.y - wp.y) <= R) return { type: k, h: H[k] }; }
    const p = wrapToDoc(wp.x, wp.y), l = xfInv(f, p.x, p.y);
    if (Math.abs(l.x) <= Math.abs(f.sx * f.w / 2) + 6 / KP.zoom && Math.abs(l.y) <= Math.abs(f.sy * f.h / 2) + 6 / KP.zoom) return { type: 'move' };
    return null;
  }
  function xfBegin(e, p) {
    const wp = wrapPoint(e.clientX, e.clientY), hit = xfHit(wp); if (!hit) return false;
    const f = xfObj(); KP._xfDrag = { type: hit.type, h: hit.h, start: p, f0: { cx: f.cx, cy: f.cy, sx: f.sx, sy: f.sy, rot: f.rot, ax: f.ax, ay: f.ay } }; return true;
  }
  function xfMove(p) {
    const d = KP._xfDrag, f = xfObj(); if (!d || !f) return; const f0 = d.f0, t = d.type;
    if (t === 'move') { f.cx = f0.cx + (p.x - d.start.x); f.cy = f0.cy + (p.y - d.start.y); }
    else if (t === 'rot') {
      let a = Math.atan2(p.y - f0.cy, p.x - f0.cx) + Math.PI / 2; const snap = Math.PI / 12, r = Math.round(a / snap) * snap; if (Math.abs(a - r) < 0.04) a = r; f.rot = a;
    } else if (KP.xfSkew && (t === 't' || t === 'b' || t === 'l' || t === 'r')) {
      const dx = p.x - f0.cx, dy = p.y - f0.cy, c = Math.cos(-f0.rot), s = Math.sin(-f0.rot), X = dx * c - dy * s, Y = dx * s + dy * c;
      if (t === 't' || t === 'b') { const yh = d.h.hy * f0.sy * f.h / 2; if (Math.abs(yh) > 1e-3) f.ax = Math.atan(clamp(X / yh, -3, 3)); }
      else { const xh = d.h.hx * f0.sx * f.w / 2; if (Math.abs(xh) > 1e-3) f.ay = Math.atan(clamp(Y / xh, -3, 3)); }
    } else {
      const f0o = { cx: f0.cx, cy: f0.cy, rot: f0.rot, ax: f0.ax, ay: f0.ay }, q = xfInv(f0o, p.x, p.y), hx = d.h.hx, hy = d.h.hy;
      const Ox = -hx * f0.sx * f.w / 2, Oy = -hy * f0.sy * f.h / 2, minS = 6 / KP.zoom;
      let sxN = f0.sx, syN = f0.sy, midX = 0, midY = 0;
      if (hx !== 0) { const wX = Math.max(minS, (q.x - Ox) * hx); sxN = wX / f.w * Math.sign(f0.sx || 1); midX = (Ox + (Ox + hx * wX)) / 2; }
      if (hy !== 0) { const wY = Math.max(minS, (q.y - Oy) * hy); syN = wY / f.h * Math.sign(f0.sy || 1); midY = (Oy + (Oy + hy * wY)) / 2; }
      if (hx !== 0 && hy !== 0 && KP.xfLock) {
        const k = Math.max(Math.abs(sxN / f0.sx), Math.abs(syN / f0.sy)); sxN = f0.sx * k; syN = f0.sy * k;
        midX = (Ox + (Ox + hx * Math.abs(sxN) * f.w)) / 2; midY = (Oy + (Oy + hy * Math.abs(syN) * f.h)) / 2;
      }
      f.sx = sxN; f.sy = syN; const c = xfFwd(Object.assign({}, f0o), midX, midY); f.cx = c.x; f.cy = c.y;
    }
    xfRender();
  }
  function drawXfUi(ctx) {
    const f = xfObj(); if (!f) return;
    const H = xfHandles(f), W = (k) => docToWrap(H[k].x, H[k].y), quad = ['tl', 'tr', 'br', 'bl'].map(W);
    dashLine(ctx, quad, true);
    const top = W('t'), rot = W('rot'); ctx.save(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(top.x, top.y); ctx.lineTo(rot.x, rot.y); ctx.stroke();
    ctx.fillStyle = '#059669'; ctx.beginPath(); ctx.arc(rot.x, rot.y, 11, 0, Math.PI * 2); ctx.fill(); ctx.lineWidth = 2.5; ctx.stroke();
    ctx.strokeStyle = '#fff'; ctx.fillStyle = '#fff'; ctx.lineWidth = 1.8; ctx.beginPath(); ctx.arc(rot.x, rot.y, 5, -2.2, 1.9); ctx.stroke();
    ctx.beginPath(); const ax = rot.x + Math.cos(1.9) * 5, ay = rot.y + Math.sin(1.9) * 5; ctx.moveTo(ax - 1, ay + 4.2); ctx.lineTo(ax - 4.6, ay - 1.6); ctx.lineTo(ax + 2.8, ay - 1.8); ctx.closePath(); ctx.fill();
    ['tl', 'tr', 'br', 'bl', 't', 'r', 'b', 'l'].forEach(k => {
      const w = W(k), corner = k.length === 2, skew = KP.xfSkew && !corner; ctx.fillStyle = skew ? '#C8C8C8' : '#fff'; ctx.strokeStyle = '#059669'; ctx.lineWidth = 2;
      ctx.beginPath(); if (skew) { ctx.moveTo(w.x, w.y - 9); ctx.lineTo(w.x + 9, w.y); ctx.lineTo(w.x, w.y + 9); ctx.lineTo(w.x - 9, w.y); ctx.closePath(); } else ctx.rect(w.x - (corner ? 8 : 6), w.y - (corner ? 8 : 6), corner ? 16 : 12, corner ? 16 : 12);
      ctx.fill(); ctx.stroke();
    });
    ctx.restore();
  }
  uiDrawers.push(drawXfUi);

  // --- barra flutuante (✓ ✕ preciso ...) ---
  function renderFloatBar() {
    const bar = $('kp-float-bar'); if (!bar) return; bar.innerHTML = '';
    const f = KP.float, pend = KP.pending;
    bar.classList.toggle('show', !!(f || pend || KP.xfRef));
    if (!(f || pend || KP.xfRef)) return;
    const add = (ic, label, fn, on, cls) => { const b = iconBtn('kp-fbtn' + (on ? ' on' : '') + (cls ? ' ' + cls : ''), ic, label, fn, 22); bar.appendChild(b); return b; };
    if (KP.xfRef && !f) { add('check', 'Pronto', () => { stopEditRef(); }, false, 'kp-fok'); add('sliders', 'Posição e tamanho exatos', () => toggleSheet('xform')); add('lock', 'Manter proporção', () => { KP.xfLock = !KP.xfLock; renderFloatBar(); }, KP.xfLock); add('skew', 'Inclinar', () => { KP.xfSkew = !KP.xfSkew; renderFloatBar(); scheduleUi(); }, KP.xfSkew); return; }
    if (pend) { add('check', 'Concluir', () => commitPending(true), false, 'kp-fok'); add('close', 'Cancelar', () => commitPending(false), false, 'kp-fno'); if (pend.kind === 'polygon') add('undo', 'Remover último ponto', () => { pend.pts.pop(); pendingChanged(); }); return; }
    add('check', 'Aplicar', () => commitFloat(true), false, 'kp-fok'); add('close', 'Cancelar', () => commitFloat(false), false, 'kp-fno');
    add('sliders', 'Posição e tamanho exatos', () => toggleSheet('xform'));
    add('lock', 'Manter proporção', () => { KP.xfLock = !KP.xfLock; renderFloatBar(); }, KP.xfLock);
    add('skew', 'Inclinar', () => { KP.xfSkew = !KP.xfSkew; renderFloatBar(); scheduleUi(); }, KP.xfSkew);
    add('flipH', 'Espelhar', () => flipFloatContent(true)); add('flipV', 'Virar', () => flipFloatContent(false));
    if (f.kind === 'text') add('text', 'Editar texto', () => openTextDialog(f));
  }

  // --- modo preciso ---
  function xfFieldDefs(f) {
    return [
      ['X', () => Math.round(f.cx * 10) / 10, v => f.cx = v, 'px'], ['Y', () => Math.round(f.cy * 10) / 10, v => f.cy = v, 'px'],
      ['Largura', () => Math.round(Math.abs(f.sx) * f.w * 10) / 10, v => { const r = Math.max(1, v) / f.w; if (KP.xfLock) f.sy = Math.sign(f.sy || 1) * Math.abs(f.sy) * r / Math.abs(f.sx || 1); f.sx = Math.sign(f.sx || 1) * r; }, 'px'],
      ['Altura', () => Math.round(Math.abs(f.sy) * f.h * 10) / 10, v => { const r = Math.max(1, v) / f.h; if (KP.xfLock) f.sx = Math.sign(f.sx || 1) * Math.abs(f.sx) * r / Math.abs(f.sy || 1); f.sy = Math.sign(f.sy || 1) * r; }, 'px'],
      ['Rotação', () => Math.round(f.rot * 1800 / Math.PI) / 10, v => f.rot = v * Math.PI / 180, '°'],
      ['Inclinar H', () => Math.round(f.ax * 1800 / Math.PI) / 10, v => f.ax = clamp(v, -75, 75) * Math.PI / 180, '°'],
      ['Inclinar V', () => Math.round(f.ay * 1800 / Math.PI) / 10, v => f.ay = clamp(v, -75, 75) * Math.PI / 180, '°']
    ];
  }
  function renderXformSheet(inner) {
    const f = xfObj(); if (!f) { inner.appendChild(el('div', 'kp-hint', 'Nada para transformar')); return; }
    const grid = el('div', 'kp-xf-grid'); KP._xfInputs = [];
    xfFieldDefs(f).forEach(([label, get, set, unit], i) => {
      const fld = el('label', 'kp-num-field'); fld.appendChild(el('span', 'kp-num-label', label + ' (' + unit + ')'));
      const inp = el('input', 'kp-num-input kp-xf-input'); inp.type = 'number'; inp.inputMode = 'decimal'; inp.step = unit === '°' ? 1 : 1; inp.value = get();
      inp.oninput = () => { const v = parseFloat(inp.value); if (!Number.isFinite(v)) return; set(v); if (KP.float) renderFloat(); else if (KP.xfRef) applyRefDom(KP.xfRef); scheduleUi(); syncXfFields(i); };
      fld.appendChild(inp); grid.appendChild(fld); KP._xfInputs.push({ inp, get });
    });
    inner.appendChild(grid);
    const t = el('div', 'kp-toggles');
    t.appendChild(toggleBtn('lock', 'Manter proporção', KP.xfLock, () => { KP.xfLock = !KP.xfLock; rerenderSheet(); renderFloatBar(); }));
    inner.appendChild(t);
  }
  function syncXfFields(skip) { (KP._xfInputs || []).forEach((o, i) => { if (i !== skip && document.activeElement !== o.inp) o.inp.value = o.get(); }); }

  // ===================== Texto =====================
  const TEXT_FONTS = [
    { id: 'sans', css: '"Segoe UI", Roboto, Arial, sans-serif' }, { id: 'serif', css: 'Georgia, "Times New Roman", serif' },
    { id: 'mono', css: '"Courier New", monospace' }, { id: 'hand', css: '"Comic Sans MS", "Segoe Print", "Bradley Hand", cursive' },
    { id: 'bold', css: 'Impact, "Arial Black", sans-serif' }, { id: 'round', css: '"Trebuchet MS", Verdana, sans-serif' }
  ];
  function renderTextCanvas(o) {
    const fam = (TEXT_FONTS.find(f => f.id === o.font) || TEXT_FONTS[0]).css, size = clamp(o.size, 6, 600);
    const font = `${o.italic ? 'italic ' : ''}${o.bold ? 'bold ' : ''}${size}px ${fam}`, lines = String(o.text || ' ').split('\n');
    const m = document.createElement('canvas').getContext('2d'); m.font = font;
    const lh = size * 1.2, pad = size * 0.25 + (o.outline ? size * 0.1 : 0), w = Math.max(...lines.map(l => m.measureText(l).width)), c = newCanvas(Math.ceil(w + pad * 2), Math.ceil(lines.length * lh + pad * 2)), x = c.getContext('2d');
    x.font = font; x.textBaseline = 'top'; x.textAlign = o.align || 'center'; x.lineJoin = 'round';
    const ox = o.align === 'left' ? pad : o.align === 'right' ? c.width - pad : c.width / 2;
    lines.forEach((l, i) => {
      if (o.outline) { x.lineWidth = size * 0.2; x.strokeStyle = o.outlineColor || '#000'; x.strokeText(l, ox, pad + i * lh + size * 0.1); }
      x.fillStyle = o.color; x.fillText(l, ox, pad + i * lh + size * 0.1);
    });
    return c;
  }
  function openTextDialog(existing, at) {
    const st = existing && existing.text ? Object.assign({}, existing.text) : { text: '', font: 'sans', size: clamp(Math.round(KP.doc.h / 7), 16, 160), bold: false, italic: false, align: 'center', outline: false };
    const wrap = el('div', 'kp-text-form');
    const ta = el('textarea', 'kp-textarea'); ta.rows = 3; ta.placeholder = 'Escreva aqui...'; ta.value = st.text; wrap.appendChild(ta);
    const pv = document.createElement('canvas'); pv.className = 'kp-bpreview'; pv.width = 640; pv.height = 140; wrap.appendChild(pv);
    const colorOf = () => KP.color === 'transparent' ? '#000000' : KP.color, outlineOf = () => (isHexColor(KP.color2) ? KP.color2 : '#000000');
    const redraw = () => {
      const c = renderTextCanvas(Object.assign({}, st, { text: ta.value || 'Aa', color: colorOf(), outlineColor: outlineOf() })), x = pv.getContext('2d'); x.clearRect(0, 0, pv.width, pv.height);
      const k = Math.min(1, (pv.width - 20) / c.width, (pv.height - 10) / c.height); x.fillStyle = '#6B6B6B'; x.fillRect(0, 0, pv.width, pv.height); x.drawImage(c, (pv.width - c.width * k) / 2, (pv.height - c.height * k) / 2, c.width * k, c.height * k);
    };
    const fonts = el('div', 'kp-chips');
    const drawFonts = () => { fonts.innerHTML = ''; TEXT_FONTS.forEach(f => { const b = el('button', 'kp-chip' + (st.font === f.id ? ' on' : ''), '<span class="kp-chip-t" style="font:22px ' + f.css.replace(/"/g, "'") + '">Aa</span>'); b.type = 'button'; b.onclick = () => { st.font = f.id; drawFonts(); redraw(); }; fonts.appendChild(b); }); };
    drawFonts(); wrap.appendChild(fonts);
    const sz = el('div', 'kp-adv-row'); sz.appendChild(el('span', 'kp-adv-label', 'Tamanho')); const si = el('input'); si.type = 'range'; si.min = 8; si.max = 300; si.value = st.size; const sv = el('span', 'kp-val', st.size + 'px');
    si.oninput = () => { st.size = Number(si.value); sv.textContent = st.size + 'px'; redraw(); }; sz.append(si, sv); wrap.appendChild(sz);
    const tg = el('div', 'kp-toggles'); const mk = (ic, lb, key) => { const b = toggleBtn(ic, lb, st[key], () => { st[key] = !st[key]; b.classList.toggle('on', st[key]); redraw(); }); tg.appendChild(b); };
    mk('bold', 'Negrito', 'bold'); mk('italic', 'Itálico', 'italic'); mk('outline', 'Contorno', 'outline'); wrap.appendChild(tg);
    const alignBox = el('div'), drawAlign = () => { alignBox.innerHTML = ''; alignBox.appendChild(chipRow([{ id: 'left', icon: 'alignL', label: 'Esquerda' }, { id: 'center', icon: 'alignC', label: 'Centro' }, { id: 'right', icon: 'alignR', label: 'Direita' }], st.align, (id) => { st.align = id; drawAlign(); redraw(); })); };
    drawAlign(); wrap.appendChild(alignBox);
    ta.oninput = redraw; redraw();
    Modal.show('Texto', wrap, [{ label: 'Cancelar' }, {
      label: existing ? 'Atualizar' : 'Inserir', primary: true, onClick: () => {
        st.text = ta.value; if (!st.text.trim()) return;
        const c = renderTextCanvas(Object.assign({}, st, { color: colorOf(), outlineColor: outlineOf() }));
        if (existing && KP.float === existing) { existing.canvas = c; existing.w = c.width; existing.h = c.height; existing.text = st; xfRender(); }
        else { const p = at || { x: KP.doc.w / 2, y: KP.doc.h / 2 }; startFloat(c, { cx: p.x, cy: p.y, kind: 'text', text: st }); }
      }
    }]);
    setTimeout(() => ta.focus && ta.focus(), 120);
  }

  // ===================== Curva Bézier, polígono e arco =====================
  const PEND_TOOLS = ['bezier', 'polygon', 'arc'];
  const isPendTool = (t) => PEND_TOOLS.includes(t);
  const isShapeLike = (t) => isShapeTool(t) || isPendTool(t) || t === 'text';
  function cubicPts(p0, c1, c2, p3, n) {
    const out = []; for (let i = 0; i <= n; i++) { const t = i / n, u = 1 - t; out.push({ x: u * u * u * p0.x + 3 * u * u * t * c1.x + 3 * u * t * t * c2.x + t * t * t * p3.x, y: u * u * u * p0.y + 3 * u * u * t * c1.y + 3 * u * t * t * c2.y + t * t * t * p3.y }); } return out;
  }
  function arcPts(a, m, b) {      // arco circular passando por a, m, b
    const d = 2 * (a.x * (m.y - b.y) + m.x * (b.y - a.y) + b.x * (a.y - m.y));
    if (Math.abs(d) < 1e-3) return [a, b];
    const ux = ((a.x ** 2 + a.y ** 2) * (m.y - b.y) + (m.x ** 2 + m.y ** 2) * (b.y - a.y) + (b.x ** 2 + b.y ** 2) * (a.y - m.y)) / d;
    const uy = ((a.x ** 2 + a.y ** 2) * (b.x - m.x) + (m.x ** 2 + m.y ** 2) * (a.x - b.x) + (b.x ** 2 + b.y ** 2) * (m.x - a.x)) / d;
    const r = Math.hypot(a.x - ux, a.y - uy), a0 = Math.atan2(a.y - uy, a.x - ux), am = Math.atan2(m.y - uy, m.x - ux), a1 = Math.atan2(b.y - uy, b.x - ux);
    const norm = (v) => { v %= Math.PI * 2; return v < 0 ? v + Math.PI * 2 : v; };
    let sweep = norm(a1 - a0); const mid = norm(am - a0); if (mid > sweep) sweep -= Math.PI * 2;   // passa por m
    const n = clamp(Math.ceil(Math.abs(sweep) * r / 2), 12, 720), out = [];
    for (let i = 0; i <= n; i++) { const t = a0 + sweep * i / n; out.push({ x: ux + Math.cos(t) * r, y: uy + Math.sin(t) * r }); } return out;
  }
  function pendingPolyline(p) {
    const q = p.pts;
    if (p.kind === 'polygon') return q.length >= 3 ? q.concat([q[0]]) : q.slice();
    if (p.kind === 'bezier') return q.length === 4 ? cubicPts(q[0], q[1], q[2], q[3], 80) : q.slice();
    return q.length === 3 ? arcPts(q[0], q[1], q[2]) : q.slice();
  }
  const pendingClosed = (p) => p.kind === 'polygon' ? p.pts.length >= 3 : false;
  function startPending(kind, p) {
    commitFloat(true);
    KP.pending = { kind, pts: kind === 'polygon' ? [p] : [p, p], stage: kind === 'polygon' ? 'edit' : 'draw', seed: (Math.random() * 1e9) | 0 };
    renderFloatBar(); pendingChanged();
  }
  function pendingChanged() { paintPending(); scheduleUi(); }
  function paintPending() {
    const p = KP.pending, ctx = elOverlay.getContext('2d'), W = KP.doc.w, H = KP.doc.h; ctx.clearRect(0, 0, W, H); if (!p) return;
    const poly = pendingPolyline(p); if (poly.length < 2) return;
    const b = shapeBrush(), fillIt = KP.shapeFilled && (p.kind === 'polygon' ? p.pts.length >= 3 : poly.length > 2);
    if (fillIt) { ctx.save(); ctx.globalAlpha = b.opacity / 100; ctx.fillStyle = KP.color === 'transparent' ? '#C8C8C8' : KP.color; ctx.beginPath(); poly.forEach((q, i) => i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y)); ctx.closePath(); ctx.fill(); ctx.restore(); }
    const eng = KixBrush.createStroke({ brush: b, color: KP.color === 'transparent' ? '#C8C8C8' : KP.color, w: W, h: H, zoom: KP.zoom, pixelArt: KP.doc.pixelArt, buffer: strokeBuffer(), seed: p.seed });
    runPolyStroke(eng, poly); ctx.globalAlpha = eng.opacity; ctx.drawImage(KP._buf, 0, 0); ctx.globalAlpha = 1;
  }
  function runPolyStroke(engine, poly) {
    const pts = densify(poly, 1.4), endPt = pts[pts.length - 1];
    pts.forEach((q, i) => engine.add({ x: q.x, y: q.y, pressure: 1, pointerType: 'pen', tiltX: 0, tiltY: 0, t: i * 4 }));
    engine.end({ x: endPt.x, y: endPt.y, pointerType: 'pen', pressure: 1, tiltX: 0, tiltY: 0 });
  }
  function commitPending(apply) {
    const p = KP.pending; if (!p) return; KP.pending = null; KP._pdrag = null;
    elOverlay.getContext('2d').clearRect(0, 0, KP.doc.w, KP.doc.h);
    const poly = pendingPolyline(p);
    if (apply && poly.length >= 2) {
      pushHistory(); const layer = currentLayer(), b = shapeBrush(), erase = KP.color === 'transparent', W = KP.doc.w, H = KP.doc.h;
      withSelection(layer, () => {
        if (KP.shapeFilled && (p.kind !== 'polygon' || p.pts.length >= 3)) { layer.ctx.save(); layer.ctx.globalAlpha = b.opacity / 100; layer.ctx.fillStyle = erase ? '#000' : KP.color; if (erase) layer.ctx.globalCompositeOperation = 'destination-out'; layer.ctx.beginPath(); poly.forEach((q, i) => i ? layer.ctx.lineTo(q.x, q.y) : layer.ctx.moveTo(q.x, q.y)); layer.ctx.closePath(); layer.ctx.fill(); layer.ctx.restore(); }
        const eng = KixBrush.createStroke({ brush: b, color: erase ? '#000000' : KP.color, w: W, h: H, zoom: KP.zoom, pixelArt: KP.doc.pixelArt, erase, target: layer.ctx, buffer: strokeBuffer(), seed: p.seed });
        runPolyStroke(eng, poly); if (!erase) eng.commit(layer.ctx);
      });
      renderAll();
    }
    renderFloatBar(); scheduleUi();
  }
  function pendHit(wp) {
    const p = KP.pending; if (!p || p.stage !== 'edit') return -1;
    for (let i = p.pts.length - 1; i >= 0; i--) { const w = docToWrap(p.pts[i].x, p.pts[i].y); if (Math.hypot(w.x - wp.x, w.y - wp.y) <= 26) return i; }
    return -1;
  }
  function pendBegin(e, p) {
    const wp = wrapPoint(e.clientX, e.clientY);
    if (!KP.pending || KP.pending.kind !== KP.tool) { commitPending(true); startPending(KP.tool, p); KP._pdrag = { idx: KP.pending.kind === 'polygon' ? 0 : 1 }; return; }
    const pd = KP.pending, i = pendHit(wp);
    if (i >= 0) { KP._pdrag = { idx: i }; return; }
    if (pd.kind === 'polygon') { pd.pts.push(p); KP._pdrag = { idx: pd.pts.length - 1 }; pendingChanged(); }
  }
  function pendMove(p) {
    const pd = KP.pending, d = KP._pdrag; if (!pd || !d) return;
    pd.pts[d.idx] = p; pendingChanged();
  }
  function pendEnd() {
    const pd = KP.pending; if (!pd) { KP._pdrag = null; return; }
    if (pd.stage === 'draw') {
      const a = pd.pts[0], b = pd.pts[1], L = Math.hypot(b.x - a.x, b.y - a.y);
      if (L < 6 / KP.zoom) { KP.pending = null; KP._pdrag = null; renderFloatBar(); elOverlay.getContext('2d').clearRect(0, 0, KP.doc.w, KP.doc.h); scheduleUi(); return; }
      const nx = -(b.y - a.y) / L, ny = (b.x - a.x) / L, o = L * 0.25;
      if (pd.kind === 'bezier') pd.pts = [a, { x: a.x + (b.x - a.x) / 3 + nx * o, y: a.y + (b.y - a.y) / 3 + ny * o }, { x: a.x + (b.x - a.x) * 2 / 3 + nx * o, y: a.y + (b.y - a.y) * 2 / 3 + ny * o }, b];
      else pd.pts = [a, { x: (a.x + b.x) / 2 + nx * L * 0.3, y: (a.y + b.y) / 2 + ny * L * 0.3 }, b];
      pd.stage = 'edit'; pendingChanged();
    }
    KP._pdrag = null;
  }
  function drawPendingUi(ctx) {
    const p = KP.pending; if (!p || p.stage !== 'edit') return;
    const W = p.pts.map(q => docToWrap(q.x, q.y));
    ctx.save(); ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.setLineDash([4, 4]);
    if (p.kind === 'bezier') { [[0, 1], [3, 2]].forEach(([a, b]) => { ctx.beginPath(); ctx.moveTo(W[a].x, W[a].y); ctx.lineTo(W[b].x, W[b].y); ctx.stroke(); }); }
    if (p.kind === 'polygon' && W.length > 1) { ctx.beginPath(); W.forEach((q, i) => i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y)); if (W.length > 2) ctx.closePath(); ctx.stroke(); }
    ctx.setLineDash([]);
    W.forEach((q, i) => {
      const control = (p.kind === 'bezier' && (i === 1 || i === 2)) || (p.kind === 'arc' && i === 1);
      ctx.beginPath(); ctx.arc(q.x, q.y, control ? 9 : 11, 0, Math.PI * 2); ctx.fillStyle = control ? 'rgba(0,0,0,.55)' : '#fff'; ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = '#059669'; ctx.stroke();
    });
    ctx.restore();
  }
  uiDrawers.push(drawPendingUi);

  // ===================== Régua, guias, simetria e perspectiva =====================
  function defaultGuides() {
    return { rulerOn: false, ruler: { a: { x: KP.doc.w * 0.2, y: KP.doc.h * 0.5 }, b: { x: KP.doc.w * 0.8, y: KP.doc.h * 0.5 } }, lines: [], snapGuides: true,
      sym: { mode: 'off', n: 6, cx: KP.doc.w / 2, cy: KP.doc.h / 2 }, persp: { n: 0, vps: [] } };
  }
  function perspVps(n) {
    const w = KP.doc.w, h = KP.doc.h;
    return n === 1 ? [{ x: w / 2, y: h * 0.4 }] : n === 2 ? [{ x: -w * 0.35, y: h * 0.4 }, { x: w * 1.35, y: h * 0.4 }] : n === 3 ? [{ x: -w * 0.35, y: h * 0.4 }, { x: w * 1.35, y: h * 0.4 }, { x: w / 2, y: h * 2.2 }] : [];
  }
  function guideHandles() {
    const G = KP.guides, out = [];
    if (G.rulerOn) { out.push({ k: 'ra', p: G.ruler.a }, { k: 'rb', p: G.ruler.b }); }
    if (G.sym.mode !== 'off') out.push({ k: 'sym', p: { x: G.sym.cx, y: G.sym.cy } });
    G.persp.vps.forEach((v, i) => out.push({ k: 'vp', i, p: v }));
    return out;
  }
  function guideLineHandles(W, H) {       // bolinhas nas bordas para arrastar guias H/V
    return KP.guides.lines.map((g, i) => { const w = g.o === 'h' ? docToWrap(0, g.pos) : docToWrap(g.pos, 0); return { k: 'gl', i, x: g.o === 'h' ? 16 : w.x, y: g.o === 'h' ? w.y : 16 }; });
  }
  function guideHit(wp) {
    for (const h of guideHandles()) { const w = docToWrap(h.p.x, h.p.y); if (Math.hypot(w.x - wp.x, w.y - wp.y) <= 24) return h; }
    for (const h of guideLineHandles()) if (Math.hypot(h.x - wp.x, h.y - wp.y) <= 24) return h;
    return null;
  }
  function guideBegin(e, p) {
    const hit = guideHit(wrapPoint(e.clientX, e.clientY)); if (!hit) return false; KP._gdrag = hit; return true;
  }
  function guideMove(p) {
    const h = KP._gdrag, G = KP.guides; if (!h) return;
    if (h.k === 'ra') G.ruler.a = { x: p.x, y: p.y }; else if (h.k === 'rb') G.ruler.b = { x: p.x, y: p.y };
    else if (h.k === 'sym') { G.sym.cx = p.x; G.sym.cy = p.y; } else if (h.k === 'vp') G.persp.vps[h.i] = { x: p.x, y: p.y };
    else if (h.k === 'gl') { const g = G.lines[h.i]; g.pos = g.o === 'h' ? p.y : p.x; }
    scheduleUi();
  }
  function drawGuidesUi(ctx, W, H) {
    const G = KP.guides; if (!G) return;
    const A = '#059669', L = (a, b, dash, col, lw) => { ctx.save(); ctx.strokeStyle = col || A; ctx.lineWidth = lw || 1.5; ctx.setLineDash(dash || []); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.restore(); };
    const ray = (o, dx, dy, col, lw, dash) => { const len = 6000; L(o, { x: o.x + dx * len, y: o.y + dy * len }, dash, col, lw); };
    G.lines.forEach(g => { if (g.o === 'h') { const a = docToWrap(0, g.pos), b = docToWrap(KP.doc.w, g.pos); const dx = b.x - a.x, dy = b.y - a.y, l = Math.hypot(dx, dy) || 1; ray(a, dx / l, dy / l, A, 1.2, [6, 4]); ray(a, -dx / l, -dy / l, A, 1.2, [6, 4]); } else { const a = docToWrap(g.pos, 0), b = docToWrap(g.pos, KP.doc.h); const dx = b.x - a.x, dy = b.y - a.y, l = Math.hypot(dx, dy) || 1; ray(a, dx / l, dy / l, A, 1.2, [6, 4]); ray(a, -dx / l, -dy / l, A, 1.2, [6, 4]); } });
    G.lines.forEach((g, i) => { const h = guideLineHandles()[i]; ctx.beginPath(); ctx.arc(h.x, h.y, 9, 0, 7); ctx.fillStyle = A; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = '#fff'; ctx.stroke(); });
    if (G.sym.mode !== 'off') {
      const c = docToWrap(G.sym.cx, G.sym.cy), axes = [];
      const dir = (ang) => { const a = docToWrap(G.sym.cx + Math.cos(ang), G.sym.cy + Math.sin(ang)); const dx = a.x - c.x, dy = a.y - c.y, l = Math.hypot(dx, dy) || 1; return { x: dx / l, y: dy / l }; };
      if (G.sym.mode === 'v' || G.sym.mode === 'vh') axes.push(Math.PI / 2); if (G.sym.mode === 'h' || G.sym.mode === 'vh') axes.push(0);
      if (G.sym.mode === 'radial') for (let k = 0; k < G.sym.n; k++) axes.push(k * Math.PI / G.sym.n);
      axes.forEach(a => { const d = dir(a); ray(c, d.x, d.y, 'rgba(5,150,105,.9)', 1.5, [7, 5]); ray(c, -d.x, -d.y, 'rgba(5,150,105,.9)', 1.5, [7, 5]); });
    }
    if (G.persp.n > 0) {
      G.persp.vps.forEach(v => { const o = docToWrap(v.x, v.y); for (let k = 0; k < 28; k++) { const a = k * Math.PI / 14; ray(o, Math.cos(a), Math.sin(a), 'rgba(200,200,200,.28)', 1); } });
      const v0 = G.persp.vps[0]; if (v0) { const a = docToWrap(0, v0.y), b = docToWrap(KP.doc.w, v0.y); const dx = b.x - a.x, dy = b.y - a.y, l = Math.hypot(dx, dy) || 1; ray(a, dx / l, dy / l, 'rgba(255,255,255,.7)', 1.2, [8, 5]); ray(a, -dx / l, -dy / l, 'rgba(255,255,255,.7)', 1.2, [8, 5]); }
    }
    if (G.rulerOn) { const a = docToWrap(G.ruler.a.x, G.ruler.a.y), b = docToWrap(G.ruler.b.x, G.ruler.b.y); const dx = b.x - a.x, dy = b.y - a.y, l = Math.hypot(dx, dy) || 1; ray(a, dx / l, dy / l, 'rgba(255,255,255,.35)', 1, [3, 4]); ray(a, -dx / l, -dy / l, 'rgba(255,255,255,.35)', 1, [3, 4]); L(a, b, [], '#fff', 3); L(a, b, [], A, 1.5); }
    guideHandles().forEach(h => { const w = docToWrap(h.p.x, h.p.y); ctx.beginPath(); ctx.arc(w.x, w.y, h.k === 'vp' ? 12 : 11, 0, 7); ctx.fillStyle = h.k === 'sym' ? '#fff' : A; ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = h.k === 'sym' ? A : '#fff'; ctx.stroke(); });
  }
  uiDrawers.push(drawGuidesUi);

  // --- travar o traço em régua / guia / perspectiva ---
  function distToLineWrap(wp, a, b) { const wa = docToWrap(a.x, a.y), wb = docToWrap(b.x, b.y), dx = wb.x - wa.x, dy = wb.y - wa.y, l = Math.hypot(dx, dy) || 1; return Math.abs((wp.x - wa.x) * dy - (wp.y - wa.y) * dx) / l; }
  function pickStrokeSnap(p, wp) {
    const G = KP.guides; KP._snap = null; KP._persp = null;
    if (G.rulerOn && distToLineWrap(wp, G.ruler.a, G.ruler.b) < 28) { KP._snap = { a: G.ruler.a, b: G.ruler.b }; return; }
    if (G.snapGuides) for (const g of G.lines) { const a = g.o === 'h' ? { x: 0, y: g.pos } : { x: g.pos, y: 0 }, b = g.o === 'h' ? { x: 1, y: g.pos } : { x: g.pos, y: 1 }; if (distToLineWrap(wp, a, b) < 14) { KP._snap = { a, b }; return; } }
    if (G.persp.n > 0) KP._persp = { start: p, lock: undefined };
  }
  function snapProject(p, a, b) { const dx = b.x - a.x, dy = b.y - a.y, l2 = dx * dx + dy * dy || 1, t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2; return { x: a.x + dx * t, y: a.y + dy * t }; }
  function snapStrokePoint(p) {            // devolve o ponto travado, ou null enquanto decide (perspectiva)
    if (KP._snap) return snapProject(p, KP._snap.a, KP._snap.b);
    const ps = KP._persp; if (!ps) return p;
    if (ps.lock === undefined) {
      if (Math.hypot(p.x - ps.start.x, p.y - ps.start.y) < 10 / KP.zoom) return null;
      const ang = Math.atan2(p.y - ps.start.y, p.x - ps.start.x), diff = (a, b) => { let d = Math.abs(((a - b) % Math.PI + Math.PI) % Math.PI); return Math.min(d, Math.PI - d); };
      const cands = KP.guides.persp.vps.map((v, i) => ({ i, a: Math.atan2(ps.start.y - v.y, ps.start.x - v.x) })).concat([{ i: 'h', a: 0 }]);
      if (KP.guides.persp.n >= 2) cands.push({ i: 'v', a: Math.PI / 2 });
      let best = null, bd = 0.2; cands.forEach(c => { const d = diff(ang, c.a); if (d < bd) { bd = d; best = c; } });
      ps.lock = best ? best.a : null;
    }
    if (ps.lock === null) return p;
    const dx = Math.cos(ps.lock), dy = Math.sin(ps.lock); return snapProject(p, ps.start, { x: ps.start.x + dx, y: ps.start.y + dy });
  }
  // simetria: transformações dos pontos
  function symTransforms() {
    const s = KP.guides.sym, cx = s.cx, cy = s.cy, T = [];
    if (s.mode === 'v' || s.mode === 'vh') T.push(p => ({ x: 2 * cx - p.x, y: p.y }));
    if (s.mode === 'h' || s.mode === 'vh') T.push(p => ({ x: p.x, y: 2 * cy - p.y }));
    if (s.mode === 'vh') T.push(p => ({ x: 2 * cx - p.x, y: 2 * cy - p.y }));
    if (s.mode === 'radial') for (let k = 1; k < s.n; k++) { const a = k * Math.PI * 2 / s.n, c = Math.cos(a), sn = Math.sin(a); T.push(p => ({ x: cx + (p.x - cx) * c - (p.y - cy) * sn, y: cy + (p.x - cx) * sn + (p.y - cy) * c })); }
    return T;
  }
  function renderGuidesSheet(inner) {
    const G = KP.guides, t = el('div', 'kp-toggles');
    t.appendChild(toggleBtn('ruler', 'Régua', G.rulerOn, () => { G.rulerOn = !G.rulerOn; rerenderSheet(); scheduleUi(); }));
    t.appendChild(toggleBtn('lock', 'Prender nas guias', G.snapGuides, () => { G.snapGuides = !G.snapGuides; rerenderSheet(); }));
    inner.appendChild(t);
    inner.appendChild(el('div', 'kp-sub2', 'Guias'));
    const gl = el('div', 'kp-toggles');
    gl.appendChild(toggleBtn('guideH', 'Horizontal', false, () => { G.lines.push({ o: 'h', pos: KP.doc.h / 2 }); rerenderSheet(); scheduleUi(); }));
    gl.appendChild(toggleBtn('guideV', 'Vertical', false, () => { G.lines.push({ o: 'v', pos: KP.doc.w / 2 }); rerenderSheet(); scheduleUi(); }));
    if (G.lines.length) gl.appendChild(toggleBtn('trash', 'Limpar (' + G.lines.length + ')', false, () => { G.lines = []; rerenderSheet(); scheduleUi(); }));
    inner.appendChild(gl);
    inner.appendChild(el('div', 'kp-sub2', 'Simetria'));
    inner.appendChild(chipRow([{ id: 'off', icon: 'close', label: 'Sem simetria' }, { id: 'v', icon: 'symV', label: 'Espelho vertical' }, { id: 'h', icon: 'symH', label: 'Espelho horizontal' }, { id: 'vh', icon: 'symVH', label: 'Quatro lados' }, { id: 'radial', icon: 'symRad', label: 'Radial' }], G.sym.mode, (id) => { G.sym.mode = id; rerenderSheet(); scheduleUi(); }));
    if (G.sym.mode === 'radial') inner.appendChild(slider('Pontas', () => G.sym.n, v => { G.sym.n = Math.round(v); scheduleUi(); }, 2, 16, ''));
    inner.appendChild(el('div', 'kp-sub2', 'Perspectiva'));
    inner.appendChild(chipRow([{ id: 0, icon: 'close', label: 'Sem perspectiva' }, { id: 1, icon: 'persp1', label: '1 ponto de fuga' }, { id: 2, icon: 'persp2', label: '2 pontos de fuga' }, { id: 3, icon: 'persp3', label: '3 pontos de fuga' }], G.persp.n, (id) => { G.persp.n = id; G.persp.vps = perspVps(id); rerenderSheet(); scheduleUi(); }));
    inner.appendChild(el('div', 'kp-hint', 'Arraste as bolinhas no desenho para mover a régua, os pontos de fuga e o centro da simetria.'));
  }

  // ===================== Referências, decalque, câmera e área de transferência =====================
  function applyRefDom(r) {
    if (!r.el) return; const e = r.el;
    e.style.width = r.w + 'px'; e.style.height = r.h + 'px'; e.style.opacity = r.opacity; e.style.display = r.visible ? '' : 'none';
    e.style.transform = `translate(${r.cx}px,${r.cy}px) rotate(${r.rot}rad) matrix(1,${tanC(r.ay)},${tanC(r.ax)},1,0,0) scale(${r.sx},${r.sy}) translate(${-r.w / 2}px,${-r.h / 2}px)`;
    const host = $(r.mode === 'trace' ? 'kp-refs-over' : 'kp-refs-under'); if (e.parentNode !== host) host.appendChild(e);
  }
  function renderRefs() { $('kp-refs-under').innerHTML = ''; $('kp-refs-over').innerHTML = ''; KP.refs.forEach(applyRefDom); }
  function fitViewTo(x0, y0, x1, y1) {
    const w = $('kp-stage-wrap'), pad = 40, z = clamp(Math.min((w.clientWidth - pad) / (x1 - x0), (w.clientHeight - pad) / (y1 - y0)), 0.1, 16);
    KP.zoom = z; KP.rot = 0; panToKeep({ x: (x0 + x1) / 2, y: (y0 + y1) / 2 }, w.clientWidth / 2, w.clientHeight / 2); applyTransform();
  }
  function addRef(canvas, mode) {
    const im = new Image(); im.draggable = false; im.src = canvas.toDataURL('image/png');
    const W = KP.doc.w, H = KP.doc.h, trace = mode === 'trace';
    const k = trace ? Math.min(W / canvas.width, H / canvas.height) : Math.min(1, (Math.max(W, H) * 0.55) / Math.max(canvas.width, canvas.height));
    const r = { id: newId(), canvasW: canvas.width, el: im, w: canvas.width, h: canvas.height, sx: k, sy: k, rot: 0, ax: 0, ay: 0, opacity: trace ? 0.4 : 1, visible: true, mode, cx: trace ? W / 2 : W + canvas.width * k / 2 + 20, cy: trace ? H / 2 : canvas.height * k / 2 };
    KP.refs.push(r); applyRefDom(r);
    if (!trace) fitViewTo(Math.min(0, r.cx - r.w * k / 2) - 10, Math.min(0, r.cy - r.h * k / 2) - 10, Math.max(W, r.cx + r.w * k / 2) + 10, Math.max(H, r.cy + r.h * k / 2) + 10);
    if (KP.sheet === 'refs') rerenderSheet(); toast(trace ? 'Decalque adicionado' : 'Referência adicionada'); return r;
  }
  function editRef(r) { commitFloat(true); commitPending(true); KP.xfRef = r; KP.xfSkew = false; KP.xfLock = true; closeSheet(); renderFloatBar(); scheduleUi(); }
  function stopEditRef() { KP.xfRef = null; renderFloatBar(); scheduleUi(); if (KP.sheet === 'xform') closeSheet(); }
  function askImportTarget(canvas) {
    Modal.show('Importar imagem', null, [
      { label: 'Na camada', primary: true, onClick: () => startFloat(canvas, { cx: KP.doc.w / 2, cy: KP.doc.h / 2, kind: 'import' }) },
      { label: 'Referência', onClick: () => addRef(canvas, 'ref') }, { label: 'Decalque', onClick: () => addRef(canvas, 'trace') }, { label: 'Cancelar' }
    ]);
  }
  function fileToCanvas(file) {
    return new Promise((res, rej) => { const rd = new FileReader(); rd.onload = () => { const im = new Image(); im.onload = () => { const c = newCanvas(im.naturalWidth, im.naturalHeight); c.getContext('2d').drawImage(im, 0, 0); res(c); }; im.onerror = () => rej(new Error('Imagem inválida')); im.src = String(rd.result); }; rd.onerror = () => rej(new Error('Falha ao ler')); rd.readAsDataURL(file); });
  }
  async function importFromClipboard() {
    try {
      if (navigator.clipboard && navigator.clipboard.read) for (const item of await navigator.clipboard.read()) { const t = item.types.find(q => q.startsWith('image/')); if (t) { askImportTarget(await blobToCanvas(await item.getType(t))); return; } }
    } catch (_) {}
    if (KP.clip) { toast('Usando o que você copiou no Paint'); askImportTarget(KP.clip.canvas); return; }
    toast('Não há imagem na área de transferência (ou o aparelho não deixou ler)');
  }
  function bindImportInputs() {
    const go = (e) => { const f = e.target.files && e.target.files[0]; e.target.value = ''; if (!f) return; fileToCanvas(f).then(askImportTarget).catch(err => toast(err.message || 'Erro')); };
    const a = $('kp-input-import'), b = $('kp-input-cam'); if (a) a.onchange = go; if (b) b.onchange = go;
  }
  function renderRefsSheet(inner) {
    const add = el('div', 'kp-adv-actions');
    add.appendChild(iconBtn('kp-sq-btn', 'image', 'Adicionar da galeria', () => $('kp-input-import').click(), 24));
    add.appendChild(iconBtn('kp-sq-btn', 'camera', 'Tirar foto', () => $('kp-input-cam').click(), 24));
    add.appendChild(iconBtn('kp-sq-btn', 'clipboard', 'Da área de transferência', () => importFromClipboard(), 24));
    add.appendChild(iconBtn('kp-sq-btn', 'brush', 'Usar o desenho atual', () => addRef(currentFlatCanvas(), 'ref'), 24));
    inner.appendChild(add);
    if (!KP.refs.length) inner.appendChild(el('div', 'kp-hint', 'Adicione fotos para olhar enquanto desenha (Referência) ou para copiar por cima (Decalque).'));
    KP.refs.forEach(r => {
      const row = el('div', 'kp-ref-row'); const th = el('div', 'kp-layer-thumb'); const im = el('img'); im.src = r.el.src; im.style.cssText = 'width:100%;height:100%;object-fit:contain'; th.appendChild(im); row.appendChild(th);
      const mid = el('div', 'kp-ref-mid'), line = el('div', 'kp-ref-line');
      line.appendChild(iconBtn('kp-mini-btn' + (r.visible ? '' : ' off'), r.visible ? 'eye' : 'eyeoff', 'Mostrar ou esconder', () => { r.visible = !r.visible; applyRefDom(r); rerenderSheet(); }, 20));
      line.appendChild(iconBtn('kp-mini-btn' + (r.mode === 'trace' ? ' on' : ''), r.mode === 'trace' ? 'traceIc' : 'refIc', r.mode === 'trace' ? 'Decalque (por cima, para copiar)' : 'Referência (por trás)', () => { r.mode = r.mode === 'trace' ? 'ref' : 'trace'; if (r.mode === 'trace' && r.opacity > 0.6) r.opacity = 0.4; applyRefDom(r); rerenderSheet(); }, 20));
      line.appendChild(iconBtn('kp-mini-btn', 'move', 'Mover e redimensionar', () => editRef(r), 20));
      line.appendChild(iconBtn('kp-mini-btn kp-danger', 'trash', 'Remover', () => { KP.refs = KP.refs.filter(q => q !== r); if (r.el.parentNode) r.el.parentNode.removeChild(r.el); if (KP.xfRef === r) stopEditRef(); rerenderSheet(); }, 20));
      mid.appendChild(line);
      const op = el('input'); op.type = 'range'; op.min = 5; op.max = 100; op.value = Math.round(r.opacity * 100); op.setAttribute('aria-label', 'Opacidade'); op.oninput = () => { r.opacity = Number(op.value) / 100; applyRefDom(r); }; mid.appendChild(op);
      row.appendChild(mid); inner.appendChild(row);
    });
  }

  function renderShapeSheet(inner) {
    const grid = el('div', 'kp-shape-grid');
    const SHAPE_LABEL = { line: 'Linha', rect: 'Quadrado', ellipse: 'Círculo', triangle: 'Triângulo', star: 'Estrela', heart: 'Coração', bezier: 'Curva Bézier', polygon: 'Polígono', arc: 'Arco', text: 'Texto' };
    SHAPE_KINDS.concat(['bezier', 'polygon', 'arc', 'text']).forEach(k => grid.appendChild(iconBtn('kp-shape-btn' + (KP.tool === k ? ' on' : ''), SHAPE_ICON[k], SHAPE_LABEL[k] || k, () => { setTool(k); rerenderSheet(); }, 28)));
    inner.appendChild(grid);
    const fill = el('div', 'kp-shape-fill');
    fill.appendChild(iconBtn('kp-shape-btn' + (!KP.shapeFilled ? ' on' : ''), 'outsq', 'Só contorno', () => { KP.shapeFilled = false; rerenderSheet(); }, 28));
    fill.appendChild(iconBtn('kp-shape-btn' + (KP.shapeFilled ? ' on' : ''), 'fillsq', 'Preenchido', () => { KP.shapeFilled = true; rerenderSheet(); }, 28));
    inner.appendChild(fill);
  }

  // ===================== Cores: roda, RGB, CMYK, harmonias, paletas =====================
  const isHexColor = (c) => typeof c === 'string' && /^#[0-9a-f]{6}$/i.test(c);
  const clamp255 = (v) => clamp(Math.round(v), 0, 255);
  function rgbToHsv(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn; let h = 0;
    if (d) { if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h *= 60; if (h < 0) h += 360; }
    return { h, s: mx ? d / mx : 0, v: mx };
  }
  function hsvToRgb(h, s, v) {
    const c = v * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = v - c; let r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; } else if (h < 180) { g = c; b = x; }
    else if (h < 240) { g = x; b = c; } else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
    return { r: clamp255((r + m) * 255), g: clamp255((g + m) * 255), b: clamp255((b + m) * 255) };
  }
  function rgbToCmyk(r, g, b) {
    const k = 1 - Math.max(r, g, b) / 255; if (k >= 1) return { c: 0, m: 0, y: 0, k: 100 };
    const f = (v) => Math.round((1 - v / 255 - k) / (1 - k) * 100);
    return { c: f(r), m: f(g), y: f(b), k: Math.round(k * 100) };
  }
  function cmykToRgb(c, m, y, k) {
    const f = (v) => clamp255(255 * (1 - v / 100) * (1 - k / 100));
    return { r: f(c), g: f(m), b: f(y) };
  }
  const solid = () => KP.slot === 2 ? KP.color2 : KP.color;
  const solidRgb = () => { const c = solid(); return c === 'transparent' || !isHexColor(c) ? { r: 0, g: 0, b: 0 } : hexToRgb(c); };
  const hexOf = (rgb) => rgbToHex(rgb.r, rgb.g, rgb.b).toUpperCase();

  // --- armazenamento de paletas ---
  const PAL_LS = 'kix_paint_palettes_v1';
  const projPalKey = () => 'kix_paint_proj_pal_' + ((typeof currentProject !== 'undefined' && currentProject && (currentProject.kixId || currentProject.name)) || 'x');
  const newId = () => 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
  function sanPalette(p) {
    if (!p || !Array.isArray(p.colors)) return null;
    return { id: String(p.id || newId()).replace(/[^\w.-]/g, '').slice(0, 40) || newId(), name: String(p.name || 'Paleta').slice(0, 40), colors: p.colors.filter(isHexColor).map(c => c.toUpperCase()).slice(0, 256) };
  }
  function loadPalettes() {
    try {
      const v = JSON.parse(localStorage.getItem(PAL_LS) || 'null');
      if (v && Array.isArray(v.palettes)) return { favorites: (v.favorites || []).filter(isHexColor).map(c => c.toUpperCase()), palettes: v.palettes.map(sanPalette).filter(Boolean) };
    } catch (_) {}
    return { favorites: [], palettes: [] };
  }
  function savePalettes() { try { localStorage.setItem(PAL_LS, JSON.stringify(KP.pals)); } catch (_) { toast('Sem espaço para salvar a paleta'); } }
  function loadProjectColors() { try { const v = JSON.parse(localStorage.getItem(projPalKey()) || 'null'); return Array.isArray(v) ? v.filter(isHexColor) : []; } catch (_) { return []; } }
  function noteProjectColor(hex) {
    if (!isHexColor(hex)) return;
    const up = hex.toUpperCase(), list = loadProjectColors().filter(c => c !== up); list.unshift(up);
    try { localStorage.setItem(projPalKey(), JSON.stringify(list.slice(0, 64))); } catch (_) {}
  }
  const BUILTIN_PALETTES = [
    { id: 'b-kix', name: 'Kix', colors: SWATCHES.filter(c => c !== 'transparent') },
    { id: 'b-graf', name: 'Graffiti', colors: ['#000000', '#2B2B2B', '#6B6B6B', '#C8C8C8', '#FFFFFF'] },
    { id: 'b-pico', name: 'PICO-8', colors: ['#000000', '#1D2B53', '#7E2553', '#008751', '#AB5236', '#5F574F', '#C2C3C7', '#FFF1E8', '#FF004D', '#FFA300', '#FFEC27', '#00E436', '#29ADFF', '#83769C', '#FF77A8', '#FFCCAA'] }, // kx-ok
    { id: 'b-gb', name: 'Game Boy', colors: ['#0F380F', '#306230', '#8BAC0F', '#9BBC0F'] },
    { id: 'b-pastel', name: 'Pastel', colors: ['#FFB3BA', '#FFDFBA', '#FFFFBA', '#BAFFC9', '#BAE1FF', '#E0BBE4', '#FFC8DD', '#CDB4DB'] },
    { id: 'b-terra', name: 'Terra', colors: ['#3E2723', '#5D4037', '#8D6E63', '#A1887F', '#D7CCC8', '#6B8E23', '#556B2F', '#C19A6B'] },
    { id: 'b-neon', name: 'Neon', colors: ['#FF0080', '#FF5F00', '#FFFF00', '#39FF14', '#00FFFF', '#0080FF', '#8000FF', '#FF00FF'] },
    { id: 'b-pele', name: 'Pele', colors: ['#FFE0BD', '#FFCD94', '#EAC086', '#C68642', '#8D5524', '#6B3E1F', '#4A2912', '#2C170B'] }
  ];
  function currentFlatCanvas() {
    const c = document.createElement('canvas'); c.width = KP.doc.w; c.height = KP.doc.h;
    compositeInto(c.getContext('2d'), currentFrame()); return c;
  }
  function extractPalette(src, n) {
    const W = src.width, H = src.height, sc = Math.min(1, 160 / Math.max(W, H));
    const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(W * sc)); c.height = Math.max(1, Math.round(H * sc));
    const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(src, 0, 0, c.width, c.height);
    const d = x.getImageData(0, 0, c.width, c.height).data, bins = new Map();
    for (let i = 0; i < d.length; i += 4) {
      if (d[i + 3] < 128) continue;
      const key = ((d[i] >> 3) << 10) | ((d[i + 1] >> 3) << 5) | (d[i + 2] >> 3);
      const e = bins.get(key) || { n: 0, r: 0, g: 0, b: 0 }; e.n++; e.r += d[i]; e.g += d[i + 1]; e.b += d[i + 2]; bins.set(key, e);
    }
    const list = [...bins.values()].map(e => ({ n: e.n, r: e.r / e.n, g: e.g / e.n, b: e.b / e.n })).sort((a, b) => b.n - a.n);
    const out = [], dist = (a, b) => Math.hypot(a.r - b.r, a.g - b.g, a.b - b.b);
    for (const minD of [40, 24, 12, 0]) {
      for (const cnd of list) { if (out.length >= n) break; if (!out.includes(cnd) && out.every(o => dist(o, cnd) >= minD)) out.push(cnd); }
      if (out.length >= n) break;
    }
    return out.map(o => hexOf({ r: clamp255(o.r), g: clamp255(o.g), b: clamp255(o.b) }));
  }
  function parsePaletteText(text, fallbackName) {
    const t = String(text || '').slice(0, 400000);
    try {
      const j = JSON.parse(t);
      if (j && j.format === 'kixpalette' && Array.isArray(j.colors)) { const p = sanPalette({ name: j.name || fallbackName, colors: j.colors }); if (p && p.colors.length) { p.id = newId(); return p; } }
    } catch (_) {}
    const colors = [];
    t.split(/\r?\n/).forEach(line => {
      const l = line.trim(); if (!l || /^(GIMP|Name|Columns|#\s*$)/i.test(l)) return;
      let m = l.match(/^#?([0-9a-f]{6})\b/i);
      if (m) { colors.push('#' + m[1].toUpperCase()); return; }
      m = l.match(/^\s*(\d{1,3})\s+(\d{1,3})\s+(\d{1,3})\b/);
      if (m) colors.push(hexOf({ r: clamp255(+m[1]), g: clamp255(+m[2]), b: clamp255(+m[3]) }));
    });
    if (!colors.length) throw new Error('Nenhuma cor encontrada no arquivo');
    return { id: newId(), name: String(fallbackName || 'Importada').replace(/\.[^.]+$/, '').slice(0, 40), colors: colors.slice(0, 256) };
  }
  function paletteToFile(p, kind) {
    const nm = (p.name || 'paleta').replace(/[^\w\-]+/g, '_').slice(0, 32) || 'paleta';
    if (kind === 'hex') return { name: nm + '.hex', text: p.colors.map(c => c.replace('#', '').toLowerCase()).join('\n') };
    if (kind === 'gpl') return { name: nm + '.gpl', text: 'GIMP Palette\nName: ' + p.name + '\nColumns: 8\n#\n' + p.colors.map(c => { const r = hexToRgb(c); return `${String(r.r).padStart(3)} ${String(r.g).padStart(3)} ${String(r.b).padStart(3)} ${c}`; }).join('\n') };
    return { name: nm + '.kixpalette', text: JSON.stringify({ format: 'kixpalette', version: 1, name: p.name, colors: p.colors }, null, 1) };
  }
  function longPress(node, fn) {
    let t = 0, fired = false;
    const clear = () => { clearTimeout(t); };
    node.addEventListener('pointerdown', () => { fired = false; clear(); t = setTimeout(() => { fired = true; fn(); }, 520); });
    ['pointerup', 'pointerleave', 'pointercancel'].forEach(ev => node.addEventListener(ev, clear));
    node.addEventListener('click', (e) => { if (fired) { e.stopImmediatePropagation(); e.preventDefault(); fired = false; } }, true);
  }

  // --- roda de cores (anel de matiz + quadrado de saturação/brilho) ---
  let ringCache = null;
  function buildRing(S) {
    if (ringCache && ringCache.width === S) return ringCache;
    const c = document.createElement('canvas'); c.width = c.height = S; const x = c.getContext('2d'), id = x.createImageData(S, S);
    const R = S / 2 - 2, r = R - S * 0.11;
    for (let py = 0; py < S; py++) for (let px = 0; px < S; px++) {
      const dx = px + 0.5 - S / 2, dy = py + 0.5 - S / 2, d = Math.hypot(dx, dy);
      if (d > R || d < r) continue;
      const h = (Math.atan2(dy, dx) * 180 / Math.PI + 360) % 360, c2 = hsvToRgb(h, 1, 1), o = (py * S + px) * 4;
      const edge = clamp(Math.min(R - d, d - r) * 1.2, 0, 1);
      id.data[o] = c2.r; id.data[o + 1] = c2.g; id.data[o + 2] = c2.b; id.data[o + 3] = Math.round(255 * edge);
    }
    x.putImageData(id, 0, 0); ringCache = c; return c;
  }
  function buildWheel(onChange, onDone) {
    const S = 520, cv = document.createElement('canvas'); cv.width = cv.height = S; cv.className = 'kp-wheel';
    const x = cv.getContext('2d'); const rgb = solidRgb(); const hsv = rgbToHsv(rgb.r, rgb.g, rgb.b);
    if (hsv.s === 0 && hsv.v === 0 && solid() === 'transparent') { hsv.v = 1; }
    const R = S / 2 - 2, r = R - S * 0.11, half = (r - S * 0.025) / Math.SQRT2, sq = { x: S / 2 - half, y: S / 2 - half, w: half * 2, h: half * 2 };
    function draw() {
      x.clearRect(0, 0, S, S); x.drawImage(buildRing(S), 0, 0);
      const hue = hsvToRgb(hsv.h, 1, 1);
      x.fillStyle = `rgb(${hue.r},${hue.g},${hue.b})`; x.fillRect(sq.x, sq.y, sq.w, sq.h);
      let g = x.createLinearGradient(sq.x, 0, sq.x + sq.w, 0); g.addColorStop(0, '#fff'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(sq.x, sq.y, sq.w, sq.h);
      g = x.createLinearGradient(0, sq.y, 0, sq.y + sq.h); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, '#000'); x.fillStyle = g; x.fillRect(sq.x, sq.y, sq.w, sq.h);
      const a = hsv.h * Math.PI / 180, mr = (R + r) / 2, hx = S / 2 + Math.cos(a) * mr, hy = S / 2 + Math.sin(a) * mr;
      const cur = hsvToRgb(hsv.h, hsv.s, hsv.v);
      const mark = (px, py, fill) => { x.beginPath(); x.arc(px, py, S * 0.032, 0, Math.PI * 2); x.fillStyle = fill; x.fill(); x.lineWidth = S * 0.01; x.strokeStyle = '#fff'; x.stroke(); x.lineWidth = S * 0.004; x.strokeStyle = 'rgba(0,0,0,.5)'; x.stroke(); };
      mark(hx, hy, `rgb(${hue.r},${hue.g},${hue.b})`);
      mark(sq.x + hsv.s * sq.w, sq.y + (1 - hsv.v) * sq.h, `rgb(${cur.r},${cur.g},${cur.b})`);
    }
    let mode = null;
    const pos = (e) => { const b = cv.getBoundingClientRect(); return { x: (e.clientX - b.left) * S / b.width, y: (e.clientY - b.top) * S / b.height }; };
    const apply = (p) => {
      if (mode === 'hue') hsv.h = (Math.atan2(p.y - S / 2, p.x - S / 2) * 180 / Math.PI + 360) % 360;
      else { hsv.s = clamp((p.x - sq.x) / sq.w, 0, 1); hsv.v = 1 - clamp((p.y - sq.y) / sq.h, 0, 1); }
      const c = hsvToRgb(hsv.h, hsv.s, hsv.v); draw(); onChange(hexOf(c));
    };
    cv.onpointerdown = (e) => {
      const p = pos(e), d = Math.hypot(p.x - S / 2, p.y - S / 2);
      if (d >= r - S * 0.02 && d <= R + S * 0.02) mode = 'hue';
      else if (p.x >= sq.x - 14 && p.x <= sq.x + sq.w + 14 && p.y >= sq.y - 14 && p.y <= sq.y + sq.h + 14) mode = 'sv'; else return;
      try { cv.setPointerCapture(e.pointerId); } catch (_) {}
      apply(p); e.preventDefault();
    };
    cv.onpointermove = (e) => { if (mode) apply(pos(e)); };
    const end = () => { if (mode) { mode = null; onDone(); } };
    cv.onpointerup = end; cv.onpointercancel = end;
    draw(); return cv;
  }

  // --- gaveta de cor ---
  function colorSwatchBtn(c, onPick, active) {
    const b = el('button', 'kp-swatch' + (c === 'transparent' ? ' kp-transparent' : '') + (active ? ' on' : '')); b.type = 'button';
    b.setAttribute('aria-label', c === 'transparent' ? 'Transparente' : c); if (c !== 'transparent') b.style.background = c; b.onclick = onPick; return b;
  }
  function renderColorSheet(inner) {
    const top = el('div', 'kp-color-top');
    [1, 2].forEach(n => {
      const b = el('button', 'kp-color-big' + (KP.slot === n ? ' on' : '')); b.type = 'button'; b.id = n === 1 ? 'kp-cur-color-swatch' : 'kp-cur-color-swatch2';
      b.setAttribute('aria-label', n === 1 ? 'Cor principal' : 'Cor secundária (gradiente e substituir)');
      b.onclick = () => { KP.slot = n; rerenderSheet(); }; top.appendChild(b);
    });
    top.appendChild(iconBtn('kp-sq-btn', 'pipette', 'Conta-gotas', () => { closeSheet(); setTool('eyedropper'); toast('Toque no desenho para pegar uma cor'); }));
    top.appendChild(iconBtn('kp-sq-btn' + (isHexColor(solid()) && KP.pals.favorites.includes(String(solid()).toUpperCase()) ? ' on' : ''), 'star', 'Favoritar cor', () => {
      const c = solid(); if (!isHexColor(c)) return; const up = c.toUpperCase();
      KP.pals.favorites = KP.pals.favorites.includes(up) ? KP.pals.favorites.filter(f => f !== up) : [up].concat(KP.pals.favorites).slice(0, 64);
      savePalettes(); rerenderSheet();
    }));
    inner.appendChild(top);
    setColor(KP.color, true);
    const TABS = [['swatches', 'grid', 'Amostras'], ['wheel', 'wheel', 'Roda'], ['mix', 'sliders', 'RGB e CMYK'], ['harmony', 'harmony', 'Harmonias'], ['palettes', 'book', 'Paletas']];
    const tabs = el('div', 'kp-tabs'); TABS.forEach(([id, ic, lb]) => tabs.appendChild(iconBtn('kp-tab' + (KP.colorTab === id ? ' on' : ''), ic, lb, () => { KP.colorTab = id; rerenderSheet(); }, 22)));
    inner.appendChild(tabs);
    const body = el('div', 'kp-edbody'); inner.appendChild(body);
    const pick = (c) => () => { setColor(c); rerenderSheet(); };
    const cur = String(solid()).toLowerCase();
    if (KP.colorTab === 'swatches') {
      const grid = el('div', 'kp-swatch-grid'); SWATCHES.forEach(c => grid.appendChild(colorSwatchBtn(c, pick(c), cur === c.toLowerCase()))); body.appendChild(grid);
      const recent = loadRecent().filter(c => !SWATCHES.some(s => s.toLowerCase() === String(c).toLowerCase())).slice(0, 10);
      if (recent.length) { const rr = el('div', 'kp-recent-row'); recent.forEach(c => rr.appendChild(colorSwatchBtn(c, pick(c), cur === String(c).toLowerCase()))); body.appendChild(rr); }
    } else if (KP.colorTab === 'wheel') {
      const hex = el('input', 'kp-hex-input'); hex.maxLength = 7; hex.placeholder = '#RRGGBB'; hex.value = isHexColor(solid()) ? solid().toUpperCase() : '';
      const wrap = el('div', 'kp-wheel-wrap');
      wrap.appendChild(buildWheel((c) => { setColor(c, true); hex.value = c; }, () => setColor(solid())));
      body.appendChild(wrap);
      hex.oninput = () => { if (/^#[0-9a-fA-F]{6}$/.test(hex.value)) { setColor(hex.value.toUpperCase()); rerenderSheet(); } };
      body.appendChild(hex);
    } else if (KP.colorTab === 'mix') {
      renderMixTab(body);
    } else if (KP.colorTab === 'harmony') {
      renderHarmonyTab(body, pick);
    } else renderPaletteTab(body, pick);
  }
  function gradSlider(label, min, max, value, track, onInput, onCommit, suffix) {
    const r = el('div', 'kp-adv-row'); r.appendChild(el('span', 'kp-adv-label kp-short', label));
    const inp = el('input', 'kp-gtrack'); inp.type = 'range'; inp.min = min; inp.max = max; inp.value = value; inp.style.setProperty('--track', track);
    const v = el('span', 'kp-val', Math.round(value) + (suffix || '')); inp.oninput = () => { onInput(Number(inp.value)); v.textContent = Math.round(inp.value) + (suffix || ''); }; inp.onchange = onCommit;
    r.appendChild(inp); r.appendChild(v); return { row: r, input: inp, val: v };
  }
  function renderMixTab(body) {
    const rgb = solidRgb(), st = { r: rgb.r, g: rgb.g, b: rgb.b, cmyk: rgbToCmyk(rgb.r, rgb.g, rgb.b) };
    const hex = el('input', 'kp-hex-input'); hex.maxLength = 7; hex.value = hexOf(rgb);
    const rs = [], cs = [];
    const refreshHex = () => { const h = hexOf(st); hex.value = h; setColor(h, true); };
    const syncRgbSliders = () => rs.forEach((s, i) => { const k = 'rgb'[i], v = st[k]; s.input.value = v; s.val.textContent = String(v); });
    const syncCmykSliders = () => cs.forEach((s, i) => { const k = 'cmyk'[i], v = st.cmyk[k]; s.input.value = v; s.val.textContent = v + '%'; });
    [['R', 'r', '#000', '#f00'], ['G', 'g', '#000', '#0f0'], ['B', 'b', '#000', '#00f']].forEach(([lb, k, a, b]) => {
      const s = gradSlider(lb, 0, 255, st[k], `linear-gradient(90deg,${a},${b})`, (v) => { st[k] = v; st.cmyk = rgbToCmyk(st.r, st.g, st.b); refreshHex(); syncCmykSliders(); }, () => setColor(solid()));
      rs.push(s); body.appendChild(s.row);
    });
    body.appendChild(el('div', 'kp-sep'));
    [['C', 'c', '#fff', '#0ff'], ['M', 'm', '#fff', '#f0f'], ['Y', 'y', '#fff', '#ff0'], ['K', 'k', '#fff', '#000']].forEach(([lb, k, a, b]) => {
      const s = gradSlider(lb, 0, 100, st.cmyk[k], `linear-gradient(90deg,${a},${b})`, (v) => { st.cmyk[k] = v; const c = cmykToRgb(st.cmyk.c, st.cmyk.m, st.cmyk.y, st.cmyk.k); st.r = c.r; st.g = c.g; st.b = c.b; refreshHex(); syncRgbSliders(); }, () => setColor(solid()), '%');
      cs.push(s); body.appendChild(s.row);
    });
    hex.oninput = () => {
      if (!/^#[0-9a-fA-F]{6}$/.test(hex.value)) return; const c = hexToRgb(hex.value); st.r = c.r; st.g = c.g; st.b = c.b; st.cmyk = rgbToCmyk(c.r, c.g, c.b);
      setColor(hex.value.toUpperCase(), true); syncRgbSliders(); syncCmykSliders();
    };
    hex.onchange = () => setColor(solid());
    body.appendChild(hex);
  }
  function renderHarmonyTab(body, pick) {
    const rgb = solidRgb(), hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
    const mk = (dh, dl) => { const c = hslToRgb(((hsl.h + dh) % 360 + 360) % 360, hsl.s, clamp(hsl.l + (dl || 0), 6, 94)); return hexOf(c); };
    const SETS = [
      ['Complementar', [0, 180]], ['Análogas', [-30, 0, 30]], ['Tríade', [0, 120, 240]], ['Tétrade', [0, 90, 180, 270]],
      ['Complementar dividida', [0, 150, 210]], ['Monocromática', null]
    ];
    SETS.forEach(([name, hues]) => {
      const row = el('div', 'kp-harm'); row.appendChild(el('div', 'kp-harm-name', name));
      const sw = el('div', 'kp-harm-sw');
      const list = hues ? hues.map(h => mk(h)) : [-30, -15, 0, 15, 30].map(dl => mk(0, dl));
      list.forEach(c => sw.appendChild(colorSwatchBtn(c, pick(c), false)));
      row.appendChild(sw); body.appendChild(row);
    });
  }
  function paletteList() {
    const draw = (() => { try { return extractPalette(currentFlatCanvas(), 16); } catch (_) { return []; } })();
    return [
      { id: 'fav', name: 'Favoritas', colors: KP.pals.favorites, editable: 'fav' },
      { id: 'proj', name: 'Projeto', colors: loadProjectColors(), editable: 'proj' },
      { id: 'draw', name: 'Do desenho', colors: draw }
    ].concat(KP.pals.palettes.map(p => Object.assign({ editable: 'user' }, p))).concat(BUILTIN_PALETTES);
  }
  function renderPaletteTab(body, pick) {
    const all = paletteList(); let sel = all.find(p => p.id === KP.palSel) || all[0]; KP.palSel = sel.id;
    const chips = el('div', 'kp-pchips');
    all.forEach(p => { const c = el('button', 'kp-pchip' + (p.id === sel.id ? ' on' : '')); c.type = 'button'; c.textContent = p.name; c.onclick = () => { KP.palSel = p.id; rerenderSheet(); }; chips.appendChild(c); });
    body.appendChild(chips);
    const grid = el('div', 'kp-pgrid'), cur = String(solid()).toLowerCase();
    sel.colors.forEach(c => {
      const b = colorSwatchBtn(c, pick(c), cur === c.toLowerCase()); b.classList.add('small');
      if (sel.editable) longPress(b, () => {
        if (sel.editable === 'fav') KP.pals.favorites = KP.pals.favorites.filter(f => f !== c);
        else if (sel.editable === 'user') { const p = KP.pals.palettes.find(q => q.id === sel.id); if (p) p.colors = p.colors.filter(f => f !== c); }
        else if (sel.editable === 'proj') { try { localStorage.setItem(projPalKey(), JSON.stringify(loadProjectColors().filter(f => f !== c))); } catch (_) {} }
        savePalettes(); toast('Cor removida'); rerenderSheet();
      });
      grid.appendChild(b);
    });
    if (sel.editable === 'user' || sel.editable === 'fav') {
      const add = iconBtn('kp-swatch small kp-addsw', 'plus', 'Adicionar a cor atual', () => {
        const c = solid(); if (!isHexColor(c)) { toast('Escolha uma cor sólida'); return; } const up = c.toUpperCase();
        if (sel.editable === 'fav') { if (!KP.pals.favorites.includes(up)) KP.pals.favorites.unshift(up); }
        else { const p = KP.pals.palettes.find(q => q.id === sel.id); if (p && !p.colors.includes(up) && p.colors.length < 256) p.colors.push(up); }
        savePalettes(); rerenderSheet();
      }, 20); grid.appendChild(add);
    }
    if (!sel.colors.length && !sel.editable) grid.appendChild(el('div', 'kp-empty', 'Sem cores'));
    body.appendChild(grid);
    const saveFromList = (name, colors) => { if (!colors.length) { toast('Nenhuma cor encontrada'); return; } const p = { id: newId(), name, colors }; KP.pals.palettes.push(p); KP.palSel = p.id; savePalettes(); rerenderSheet(); toast('Paleta criada'); };
    const acts = el('div', 'kp-adv-actions kp-pal-actions');
    acts.appendChild(iconBtn('kp-sq-btn', 'plus', 'Nova paleta', () => Modal.prompt('Nova paleta', 'Nome da paleta', 'Minha paleta', (n) => { if (n) saveFromList(n, []) || void 0; }), 22));
    acts.appendChild(iconBtn('kp-sq-btn', 'brush', 'Criar paleta a partir do desenho', () => saveFromList('Do desenho ' + (KP.pals.palettes.length + 1), extractPalette(currentFlatCanvas(), 16)), 22));
    acts.appendChild(iconBtn('kp-sq-btn', 'image', 'Criar paleta a partir de uma imagem', () => pickImage('palette'), 22));
    acts.appendChild(iconBtn('kp-sq-btn', 'upload', 'Importar paleta', () => $('kp-input-pal').click(), 22));
    acts.appendChild(iconBtn('kp-sq-btn', 'download', 'Exportar paleta', () => {
      if (!sel.colors.length) { toast('Paleta vazia'); return; }
      const out = (kind) => () => { const f = paletteToFile({ name: sel.name, colors: sel.colors }, kind); downloadBlob(new Blob([f.text], { type: 'text/plain' }), f.name); toast('Paleta exportada'); };
      Modal.show('Exportar paleta', null, [{ label: 'Kix', primary: true, onClick: out('kix') }, { label: 'HEX', onClick: out('hex') }, { label: 'GIMP', onClick: out('gpl') }, { label: 'Cancelar' }]);
    }, 22));
    if (sel.editable === 'user') acts.appendChild(iconBtn('kp-sq-btn kp-danger', 'trash', 'Excluir paleta', () => Modal.confirm('Excluir paleta', 'Excluir "' + sel.name + '"?', () => { KP.pals.palettes = KP.pals.palettes.filter(p => p.id !== sel.id); KP.palSel = 'fav'; savePalettes(); rerenderSheet(); }), 22));
    body.appendChild(acts);
    renderReplaceBox(body);
  }
  // --- substituir cor (A → B) ---
  function renderReplaceBox(body) {
    const box = el('div', 'kp-replace'); box.appendChild(el('div', 'kp-sub2', 'Substituir cor'));
    const row = el('div', 'kp-replace-row');
    const a = colorSwatchBtn(KP.color, () => { KP.slot = 1; KP.colorTab = 'swatches'; rerenderSheet(); }, false); a.classList.add('small');
    const arrow = el('span', 'kp-ico', svg('next', 20));
    const b = colorSwatchBtn(KP.color2, () => { KP.slot = 2; KP.colorTab = 'swatches'; rerenderSheet(); }, false); b.classList.add('small');
    row.append(a, arrow, b); box.appendChild(row);
    box.appendChild(slider('Tolerância', () => KP.replaceTol, v => KP.replaceTol = v, 0, 100, '%'));
    const scope = chipRow([{ id: 'layer', icon: 'layers', label: 'Camada atual' }, { id: 'frame', icon: 'copy', label: 'Todas as camadas do quadro' }, { id: 'all', icon: 'film', label: 'Todos os quadros' }], KP.replaceScope, (id) => { KP.replaceScope = id; rerenderSheet(); });
    box.appendChild(scope);
    box.appendChild(iconBtn('kp-sq-btn kp-apply', 'check', 'Aplicar substituição', () => { const n = replaceColor(KP.color, KP.color2, KP.replaceTol, KP.replaceScope); toast(n ? n + ' pixels trocados' : 'Nada para trocar'); }, 22));
    body.appendChild(box);
  }
  function replaceColor(fromHex, toHex, tolPct, scope) {
    const frames = scope === 'all' ? KP.doc.frames : [currentFrame()];
    const layers = []; frames.forEach(f => (scope === 'layer' ? [currentLayer()] : f.layers).forEach(l => layers.push(l)));
    const fromT = fromHex === 'transparent', toT = toHex === 'transparent';
    const f = fromT ? null : hexToRgb(fromHex), t = toT ? null : hexToRgb(toHex), tol = (tolPct / 100) * 255 * 1.2;
    pushHistory(); let n = 0;
    layers.forEach(l => {
      const snapL = KP.sel ? (() => { const c = newCanvas(KP.doc.w, KP.doc.h); c.getContext('2d').drawImage(l.canvas, 0, 0); return c; })() : null;
      const img = l.ctx.getImageData(0, 0, KP.doc.w, KP.doc.h), d = img.data;
      for (let i = 0; i < d.length; i += 4) {
        if (fromT) { if (d[i + 3] > tol) continue; if (toT) continue; d[i] = t.r; d[i + 1] = t.g; d[i + 2] = t.b; d[i + 3] = 255; n++; continue; }
        if (d[i + 3] === 0) continue;
        if (Math.hypot(d[i] - f.r, d[i + 1] - f.g, d[i + 2] - f.b) > tol) continue;
        if (toT) d[i + 3] = 0; else { d[i] = t.r; d[i + 1] = t.g; d[i + 2] = t.b; }
        n++;
      }
      l.ctx.putImageData(img, 0, 0); if (snapL) restoreOutside(l, snapL);
    });
    renderAll(); renderFramesStrip(); return n;
  }
  function bindPaletteInputs() {
    const pi = $('kp-input-pal');
    if (pi) pi.onchange = (e) => {
      const f = e.target.files && e.target.files[0]; e.target.value = ''; if (!f) return;
      const rd = new FileReader();
      rd.onload = () => { try { const p = parsePaletteText(rd.result, f.name); KP.pals.palettes.push(p); KP.palSel = p.id; savePalettes(); KP.colorTab = 'palettes'; if (KP.sheet === 'color') rerenderSheet(); toast('Paleta importada (' + p.colors.length + ' cores)'); } catch (err) { toast(err.message || 'Arquivo inválido'); } };
      rd.readAsText(f);
    };
  }

  // ===================== Balde (força própria), gradiente, formas com o pincel, tamanho =====================
  // tolerância em % (0–100): quão diferente da cor tocada um pixel pode ser para ainda ser preenchido.
  function floodFill(layer, x, y, fillColor, o) {
    o = o || {};
    const W = KP.doc.w, H = KP.doc.h; x = Math.floor(x); y = Math.floor(y);
    if (x < 0 || y < 0 || x >= W || y >= H) return false;
    const img = layer.ctx.getImageData(0, 0, W, H);
    const erase = fillColor === 'transparent';
    const fc = erase ? { r: 0, g: 0, b: 0 } : hexToRgb(fillColor);
    // Bro: o teste é feito na cópia; o snapshot de undo ainda lê o canvas anterior.
    const result = fillRgba(img.data, W, H, x, y, fc, {
      opacity: o.opacity == null ? 100 : o.opacity,
      tolerance: o.tolerance == null ? 10 : o.tolerance,
      pixelArt: !!(o.pixelArt || KP.doc.pixelArt),
      grow: o.grow == null ? 0 : o.grow,
      erase,
    });
    if (!result.changed) return false;
    pushHistory();
    layer.ctx.putImageData(img, 0, 0);
    return true;
  }

  function gradStop(c, other) {
    if (c !== 'transparent') return c;
    const o = (other && other !== 'transparent' && isHexColor(other)) ? hexToRgb(other) : { r: 0, g: 0, b: 0 };
    return `rgba(${o.r},${o.g},${o.b},0)`;
  }
  function paintGradient(ctx, a, b, mode, alpha) {
    const dist = Math.hypot(b.x - a.x, b.y - a.y); if (dist < 1) return false;
    const g = mode === 'radial' ? ctx.createRadialGradient(a.x, a.y, 0, a.x, a.y, dist) : ctx.createLinearGradient(a.x, a.y, b.x, b.y);
    g.addColorStop(0, gradStop(KP.color, KP.color2)); g.addColorStop(1, gradStop(KP.color2, KP.color));
    ctx.save(); ctx.globalAlpha = alpha; ctx.fillStyle = g; ctx.fillRect(0, 0, KP.doc.w, KP.doc.h); ctx.restore(); return true;
  }
  function previewGradient() {
    const s = KP._stroke; if (!s || s.type !== 'gradient') return;
    const ctx = elOverlay.getContext('2d'); ctx.clearRect(0, 0, KP.doc.w, KP.doc.h);
    paintGradient(ctx, s.start, s.last, KP.fill.mode, KP.fill.opacity / 100);
  }
  function renderFillSheet(inner) {
    const f = KP.fill;
    inner.appendChild(chipRow([{ id: 'fill', icon: 'bucket', label: 'Preencher' }, { id: 'linear', icon: 'gradLin', label: 'Gradiente linear' }, { id: 'radial', icon: 'gradRad', label: 'Gradiente radial' }], f.mode, (id) => { f.mode = id; refreshToolbar(); rerenderSheet(); }));
    inner.appendChild(slider('Opacidade', () => f.opacity, v => f.opacity = v, 5, 100, '%'));
    if (f.mode === 'fill') {
      inner.appendChild(slider('Força (tolerância)', () => KP.doc.pixelArt ? 0 : f.tol, v => f.tol = v, 0, 100, '%', !!KP.doc.pixelArt));
      inner.appendChild(slider('Expandir borda', () => KP.doc.pixelArt ? 0 : f.grow, v => f.grow = Math.round(v), 0, 8, 'px', !!KP.doc.pixelArt));
      inner.appendChild(el('div', 'kp-hint', KP.doc.pixelArt
        ? 'Pixel Art: região conectada exata, sem expandir bordas'
        : 'Preenche somente a região conectada pelos quatro lados'));
    } else {
      const row = el('div', 'kp-replace-row');
      const a = colorSwatchBtn(KP.color, () => { KP.slot = 1; openSheet('color'); }, false), b = colorSwatchBtn(KP.color2, () => { KP.slot = 2; openSheet('color'); }, false);
      a.classList.add('small'); b.classList.add('small');
      row.append(a, el('span', 'kp-ico', svg('next', 20)), b, iconBtn('kp-sq-btn', 'swap', 'Inverter cores', () => { const t = KP.color; KP.color = KP.color2; KP.color2 = t; setColor(KP.color, true); rerenderSheet(); }, 22));
      inner.appendChild(row);
      inner.appendChild(el('div', 'kp-hint', 'Arraste no desenho para criar o gradiente'));
    }
  }

  // --- formas desenhadas com o PINCEL escolhido ---
  function shapePolyline(type, x, y, w, h) {
    if (type === 'rect') return [{ x, y }, { x: x + w, y }, { x: x + w, y: y + h }, { x, y: y + h }, { x, y }];
    if (type === 'triangle') return [{ x: x + w / 2, y }, { x: x + w, y: y + h }, { x, y: y + h }, { x: x + w / 2, y }];
    if (type === 'ellipse') {
      const n = clamp(Math.round((w + h) * 1.6), 24, 720), out = [];
      for (let i = 0; i <= n; i++) { const a = i / n * Math.PI * 2; out.push({ x: x + w / 2 + Math.cos(a) * w / 2, y: y + h / 2 + Math.sin(a) * h / 2 }); }
      return out;
    }
    if (type === 'star') {
      const out = [], cx = x + w / 2, cy = y + h / 2;
      for (let i = 0; i <= 10; i++) { const a = -Math.PI / 2 + (i % 10) * Math.PI / 5, r = (i % 2) ? 0.45 : 1; out.push({ x: cx + w / 2 * r * Math.cos(a), y: cy + h / 2 * r * Math.sin(a) }); }
      return out;
    }
    // coração: 4 curvas de Bézier
    const cx = x + w / 2, top = h * 0.3, mid = y + (h + top) / 2;
    const curves = [
      [{ x: cx, y: y + top }, { x: cx, y }, { x, y }, { x, y: y + top }],
      [{ x, y: y + top }, { x, y: mid }, { x: cx, y: mid }, { x: cx, y: y + h }],
      [{ x: cx, y: y + h }, { x: cx, y: mid }, { x: x + w, y: mid }, { x: x + w, y: y + top }],
      [{ x: x + w, y: y + top }, { x: x + w, y }, { x: cx, y }, { x: cx, y: y + top }]
    ], out = [];
    curves.forEach(([p0, p1, p2, p3]) => { for (let i = 0; i <= 40; i++) { const t = i / 40, u = 1 - t; out.push({ x: u * u * u * p0.x + 3 * u * u * t * p1.x + 3 * u * t * t * p2.x + t * t * t * p3.x, y: u * u * u * p0.y + 3 * u * u * t * p1.y + 3 * u * t * t * p2.y + t * t * t * p3.y }); } });
    return out;
  }
  function densify(poly, step) {
    const out = [poly[0]];
    for (let i = 1; i < poly.length; i++) {
      const a = poly[i - 1], b = poly[i], n = Math.max(1, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / step));
      for (let k = 1; k <= n; k++) out.push({ x: lerpN(a.x, b.x, k / n), y: lerpN(a.y, b.y, k / n) });
    }
    return out;
  }
  const lerpN = (a, b, t) => a + (b - a) * t;
  function shapeBrush() {
    const b = KixBrush.clone(KP.brush); b.stab = 0; b.stabDist = 0; b.stabSmooth = 0; b.pressure.simulate = false; return b;
  }
  function shapeBox(st) {
    const a = st.start, b = st.last;
    return { x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), w: Math.abs(b.x - a.x), h: Math.abs(b.y - a.y) };
  }
  function runShapeStroke(engine, st) {
    const a = st.start, b = st.last, bx = shapeBox(st);
    const poly = st.type === 'line' ? [a, b] : shapePolyline(st.type, bx.x, bx.y, bx.w, bx.h);
    const pts = densify(poly, 1.4), endPt = pts[pts.length - 1];
    pts.forEach((p, i) => engine.add({ x: p.x, y: p.y, pressure: 1, pointerType: 'pen', tiltX: 0, tiltY: 0, t: i * 4 }));
    engine.end({ x: endPt.x, y: endPt.y, pointerType: 'pen', pressure: 1, tiltX: 0, tiltY: 0 });
  }
  function fillShapePath(ctx, st, alpha, erase) {
    const bx = shapeBox(st); ctx.save(); ctx.globalAlpha = alpha; ctx.fillStyle = erase ? '#000' : KP.color;
    if (erase) ctx.globalCompositeOperation = 'destination-out';
    shapePath(ctx, st.type, bx.x, bx.y, bx.w, bx.h); ctx.fill(); ctx.restore();
  }
  function paintShapePreview() {
    const st = KP._stroke; KP._shapeRaf = 0; if (!st || !isShapeTool(st.type)) return;
    const ctx = elOverlay.getContext('2d'), W = KP.doc.w, H = KP.doc.h; ctx.clearRect(0, 0, W, H);
    const bx = shapeBox(st); if (st.type !== 'line' && bx.w < 1 && bx.h < 1) return;
    const b = shapeBrush(), erase = KP.color === 'transparent';
    if (KP.shapeFilled && st.type !== 'line') fillShapePath(ctx, st, b.opacity / 100, false);
    const eng = KixBrush.createStroke({ brush: b, color: erase ? '#C8C8C8' : KP.color, w: W, h: H, zoom: KP.zoom, pixelArt: KP.doc.pixelArt, buffer: strokeBuffer(), seed: st.seed });
    runShapeStroke(eng, st);
    ctx.globalAlpha = eng.opacity; ctx.drawImage(KP._buf, 0, 0); ctx.globalAlpha = 1;
  }
  function drawShapePreview() { if (!KP._shapeRaf) KP._shapeRaf = requestAnimationFrame(paintShapePreview); }
  function commitShape(st) {
    const W = KP.doc.w, H = KP.doc.h, bx = shapeBox(st);
    elOverlay.getContext('2d').clearRect(0, 0, W, H);
    if (Math.max(bx.w, bx.h) < 2) return;
    pushHistory();
    const layer = currentLayer(), b = shapeBrush(), erase = KP.color === 'transparent';
    withSelection(layer, () => {
      if (KP.shapeFilled && st.type !== 'line') fillShapePath(layer.ctx, st, b.opacity / 100, erase);
      const eng = KixBrush.createStroke({ brush: b, color: erase ? '#000000' : KP.color, w: W, h: H, zoom: KP.zoom, pixelArt: KP.doc.pixelArt, erase, target: layer.ctx, buffer: strokeBuffer(), seed: st.seed });
      runShapeStroke(eng, st);
      if (!erase) eng.commit(layer.ctx);
    });
  }
  function commitGradient(st) {
    elOverlay.getContext('2d').clearRect(0, 0, KP.doc.w, KP.doc.h);
    if (Math.hypot(st.last.x - st.start.x, st.last.y - st.start.y) < 2) return;
    pushHistory(); withSelection(currentLayer(), () => paintGradient(currentLayer().ctx, st.start, st.last, KP.fill.mode, KP.fill.opacity / 100));
  }

  // --- tamanho: Altura × Largura livres ---
  function openSizeDialog() {
    const wrap = el('div', 'kp-size-form'), row = el('div', 'kp-size-row');
    const mk = (label, val) => {
      const f = el('label', 'kp-num-field'); f.appendChild(el('span', 'kp-num-label', label));
      const i = el('input', 'kp-num-input'); i.type = 'number'; i.inputMode = 'numeric'; i.min = 1; i.max = 4096; i.step = 1; i.value = val; f.appendChild(i); return { f, i };
    };
    const Hh = mk('Altura', KP.doc.h), Ww = mk('Largura', KP.doc.w);
    row.append(Hh.f, el('span', 'kp-num-x', '×'), Ww.f); wrap.appendChild(row);
    wrap.appendChild(el('div', 'kp-hint', 'De 1 a 4096 pixels.' + (KP.stretch ? ' O desenho será esticado para caber.' : ' O desenho é cortado ou ganha espaço vazio.')));
    Modal.show('Tamanho do desenho', wrap, [{ label: 'Cancelar' }, {
      label: 'Aplicar', primary: true, onClick: () => {
        const h = clamp(parseInt(Hh.i.value, 10) || KP.doc.h, 1, 4096), w = clamp(parseInt(Ww.i.value, 10) || KP.doc.w, 1, 4096);
        if (w === KP.doc.w && h === KP.doc.h) return;
        const layers = KP.doc.frames.reduce((n, f) => n + f.layers.length, 0);
        if (layers * w * h * 4 > 480e6) { toast('Tamanho grande demais para este desenho'); return; }
        resizeDocTo(w, h, KP.doc.pixelArt, KP.stretch);
      }
    }]);
    setTimeout(() => Hh.i.select && Hh.i.select(), 80);
  }

  function renderLayersSheet(inner) {
    const frame = currentFrame();
    for (let i = frame.layers.length - 1; i >= 0; i--) {
      const l = frame.layers[i];
      const row = el('div', 'kp-layer-row' + (i === KP.layerIdx ? ' on' : ''));
      const thumb = el('div', 'kp-layer-thumb'); thumb.appendChild(layerThumb(l));
      row.appendChild(thumb);
      row.appendChild(el('div', 'kp-layer-name', '')).textContent = l.name;
      const stop = (fn) => (e) => { e.stopPropagation(); fn(); };
      row.appendChild(iconBtn('kp-mini-btn' + (l.visible ? '' : ' off'), l.visible ? 'eye' : 'eyeoff', 'Mostrar ou esconder', stop(() => { l.visible = !l.visible; renderAll(); rerenderSheet(); }), 20));
      const up = iconBtn('kp-mini-btn', 'up', 'Subir', stop(() => { [frame.layers[i], frame.layers[i + 1]] = [frame.layers[i + 1], frame.layers[i]]; KP.layerIdx = i + 1; KP.dirty = true; renderAll(); rerenderSheet(); }), 20);
      up.disabled = i === frame.layers.length - 1; row.appendChild(up);
      const down = iconBtn('kp-mini-btn', 'down', 'Descer', stop(() => { [frame.layers[i], frame.layers[i - 1]] = [frame.layers[i - 1], frame.layers[i]]; KP.layerIdx = i - 1; KP.dirty = true; renderAll(); rerenderSheet(); }), 20);
      down.disabled = i === 0; row.appendChild(down);
      row.appendChild(iconBtn('kp-mini-btn kp-danger', 'trash', 'Excluir camada', stop(() => {
        if (frame.layers.length <= 1) { toast('Precisa de ao menos 1 camada'); return; }
        Modal.confirm('Excluir camada', 'Excluir "' + l.name + '"?', () => { frame.layers.splice(i, 1); KP.layerIdx = clamp(KP.layerIdx, 0, frame.layers.length - 1); KP.dirty = true; renderAll(); rerenderSheet(); });
      }), 20));
      row.onclick = () => { finalizeEdits(); KP.layerIdx = i; rerenderSheet(); };
      row.ondblclick = () => Modal.prompt('Renomear camada', 'Nome', l.name, (n) => { if (n) { l.name = n; rerenderSheet(); } });
      inner.appendChild(row);
    }
    inner.appendChild(iconBtn('kp-add-row', 'plus', 'Nova camada', () => {
      frame.layers.push(newLayer('Camada ' + (frame.layers.length + 1))); KP.layerIdx = frame.layers.length - 1; KP.dirty = true; renderAll(); rerenderSheet();
    }));
  }

  function renderMoreSheet(inner) {
    const grid = el('div', 'kp-more-grid');
    const items = [
      { ic: 'grid', label: 'Grade', on: KP.gridOn, fn: () => { KP.gridOn = !KP.gridOn; renderAll(); rerenderSheet(); } },
      { ic: 'flipH', label: 'Espelhar', fn: () => { flipLayer(true); } },
      { ic: 'flipV', label: 'Virar', fn: () => { flipLayer(false); } },
      { ic: 'move', label: 'Mover', fn: () => { closeSheet(); setTool('move'); toast('Arraste para mover o desenho'); } },
      { ic: 'trash', label: 'Limpar', fn: () => { closeSheet(); Modal.confirm('Limpar camada', 'Apagar todo o conteúdo da camada atual?', () => { pushHistory(); currentLayer().ctx.clearRect(0, 0, KP.doc.w, KP.doc.h); renderAll(); }); } },
      { ic: 'maximize', label: 'Tamanho', fn: () => { closeSheet(); openSizeDialog(); } },
      { ic: 'grid', label: 'Pixel art', on: KP.doc.pixelArt, fn: () => { KP.doc.pixelArt = !KP.doc.pixelArt; KP.doc.pixelArt ? $('kp-stage').classList.add('kp-pixel') : $('kp-stage').classList.remove('kp-pixel'); refreshToolbar(); renderAll(); rerenderSheet(); toast(KP.doc.pixelArt ? 'Pixel art ligado' : 'Pixel art desligado'); } },
      { ic: 'fit', label: 'Esticar', on: KP.stretch, fn: () => { KP.stretch = !KP.stretch; rerenderSheet(); toast(KP.stretch ? 'Mudar o tamanho estica o desenho' : 'Mudar o tamanho corta ou aumenta o espaço'); } },
      { ic: 'image', label: 'Importar', fn: () => { closeSheet(); $('kp-input-import').click(); } },
      { ic: 'camera', label: 'Câmera', fn: () => { closeSheet(); $('kp-input-cam').click(); } },
      { ic: 'clipboard', label: 'Colar da área', fn: () => { closeSheet(); importFromClipboard(); } },
      { ic: 'refIc', label: 'Referências', fn: () => openSheet('refs') },
      { ic: 'ruler', label: 'Guias e simetria', fn: () => openSheet('guides') },
      { ic: 'maximize2', label: 'Ajustar vista', fn: () => { closeSheet(); fitZoom(); } },
      { ic: 'flipH', label: 'Espelhar vista', on: KP.flip, fn: () => { toggleFlipView(); rerenderSheet(); } },
      { ic: 'compass', label: 'Zerar giro', fn: () => { closeSheet(); resetRotation(); } },
      { ic: 'lock', label: 'Travar giro', on: KP.rotLock, fn: () => { KP.rotLock = !KP.rotLock; rerenderSheet(); toast(KP.rotLock ? 'Giro com dois dedos travado' : 'Giro com dois dedos liberado'); } },
      { ic: 'expand', label: 'Tela cheia', fn: () => { toggleFull(true); } },
      { ic: 'download', label: 'PNG', fn: () => { closeSheet(); saveToGallery('png'); } },
      { ic: 'film', label: 'GIF', fn: () => { closeSheet(); saveToGallery('gif'); } },
      { ic: 'video', label: 'Vídeo', fn: () => { closeSheet(); saveToGallery('webm'); } }
    ];
    items.forEach(it => {
      const b = el('button', 'kp-more-item' + (it.on ? ' on' : ''), svg(it.ic, 26) + '<span>' + it.label + '</span>');
      b.type = 'button'; b.onclick = it.fn; grid.appendChild(b);
    });
    inner.appendChild(grid);
  }
  function flipLayer(horizontal) {
    const l = currentLayer();
    pushHistory();
    const tmp = document.createElement('canvas'); tmp.width = KP.doc.w; tmp.height = KP.doc.h;
    tmp.getContext('2d').drawImage(l.canvas, 0, 0);
    l.ctx.clearRect(0, 0, KP.doc.w, KP.doc.h);
    l.ctx.save();
    if (horizontal) { l.ctx.translate(KP.doc.w, 0); l.ctx.scale(-1, 1); } else { l.ctx.translate(0, KP.doc.h); l.ctx.scale(1, -1); }
    l.ctx.drawImage(tmp, 0, 0);
    l.ctx.restore();
    renderAll();
  }
  function layerThumb(layer) {
    const c = document.createElement('canvas'); c.width = 80; c.height = 80;
    const ctx = c.getContext('2d');
    const r = Math.min(80 / layer.canvas.width, 80 / layer.canvas.height);
    const w = layer.canvas.width * r, h = layer.canvas.height * r;
    ctx.drawImage(layer.canvas, (80 - w) / 2, (80 - h) / 2, w, h);
    return c;
  }

  // ===================== Linha do tempo (quadros + reproduzir) =====================
  function thumbInto(c, frame) {
    const ctx = c.getContext('2d'); ctx.clearRect(0, 0, c.width, c.height);
    frame.layers.forEach(l => { if (!l.visible) return; ctx.globalAlpha = clamp(l.opacity, 0, 100) / 100; ctx.drawImage(l.canvas, 0, 0, c.width, c.height); });
    ctx.globalAlpha = 1;
  }
  let thumbRaf = 0;
  function scheduleThumb() { if (thumbRaf) return; thumbRaf = requestAnimationFrame(() => { thumbRaf = 0; updateActiveThumb(); }); }
  function updateActiveThumb() {
    const cell = $$('#kp-frames-list .kp-frame')[KP.frameIdx]; const c = cell && cell.querySelector('canvas');
    if (c && KP.doc) thumbInto(c, currentFrame());
  }
  function renderFramesStrip() {
    const list = $('kp-frames-list'); if (!list || !KP.doc) return;
    list.innerHTML = '';
    const th = 48, tw = clamp(Math.round(th * KP.doc.w / KP.doc.h), 36, 96);
    KP.doc.frames.forEach((f, i) => {
      const cell = el('button', 'kp-frame' + (i === KP.frameIdx ? ' on' : '')); cell.type = 'button';
      cell.style.width = tw + 'px'; cell.setAttribute('aria-label', 'Quadro ' + (i + 1));
      const c = document.createElement('canvas'); c.width = tw * 2; c.height = th * 2; thumbInto(c, f);
      cell.appendChild(c); cell.appendChild(el('span', 'kp-frame-num', String(i + 1)));
      cell.onclick = () => { if (i === KP.frameIdx) toggleFrameMenu(); else selectFrame(i); };
      list.appendChild(cell);
    });
    refreshTransport();
    const on = list.querySelector('.kp-frame.on'); if (on && on.scrollIntoView) on.scrollIntoView({ inline: 'center', block: 'nearest' });
    if ($('kp-frame-menu').classList.contains('open')) renderFrameMenu();
  }
  function markActiveFrame() {
    $$('#kp-frames-list .kp-frame').forEach((c, i) => c.classList.toggle('on', i === KP.frameIdx));
    const on = document.querySelector('#kp-frames-list .kp-frame.on'); if (on && on.scrollIntoView) on.scrollIntoView({ inline: 'center', block: 'nearest' });
  }
  function finalizeEdits() { if (KP.float) commitFloat(true); if (KP.pending) commitPending(true); if (KP.xfRef) stopEditRef(); }
  function selectFrame(i) {
    finalizeEdits();
    if (!KP.doc.frames[i]) return;
    if (KP.playing) togglePlay();
    KP.frameIdx = i; KP.layerIdx = clamp(KP.layerIdx, 0, currentFrame().layers.length - 1);
    closeFrameMenu(); renderAll(); markActiveFrame(); refreshTransport();
  }
  function addFrame(copy) {
    finalizeEdits();
    if (KP.playing) togglePlay();
    const f = currentFrame();
    const nf = { id: uid(), ms: f.ms, layers: f.layers.map(l => { const nl = newLayer(l.name); nl.visible = l.visible; nl.opacity = l.opacity; if (copy) nl.ctx.drawImage(l.canvas, 0, 0); return nl; }) };
    KP.doc.frames.splice(KP.frameIdx + 1, 0, nf); KP.frameIdx++; KP.dirty = true;
    if (!copy && KP.doc.frames.length === 2 && !KP.onionAuto) { KP.onionSkin = true; KP.onionAuto = true; }
    renderAll(); renderFramesStrip();
  }
  function refreshTransport() {
    if (!KP.doc) return;
    const many = KP.doc.frames.length > 1;
    const play = $('kp-play'); if (!play) return;
    play.innerHTML = svg(KP.playing ? 'pause' : 'play', 26);
    play.setAttribute('aria-label', KP.playing ? 'Pausar' : 'Reproduzir');
    play.disabled = !many;
    $('kp-prev').disabled = !many || KP.frameIdx === 0 || KP.playing;
    $('kp-next').disabled = !many || KP.frameIdx >= KP.doc.frames.length - 1 || KP.playing;
    $('kp-onion').classList.toggle('on', !!KP.onionSkin);
  }
  function toggleFrameMenu() { const m = $('kp-frame-menu'); if (m.classList.contains('open')) closeFrameMenu(); else { closeSheet(); renderFrameMenu(); m.classList.add('open'); } }
  function closeFrameMenu() { const m = $('kp-frame-menu'); if (m) m.classList.remove('open'); }
  function renderFrameMenu() {
    const m = $('kp-frame-menu'); m.innerHTML = '';
    const f = currentFrame();
    const step = f.ms < 200 ? 20 : f.ms < 1000 ? 50 : 100;
    const setMs = (v) => { f.ms = clamp(v, 20, 5000); renderFrameMenu(); };
    m.appendChild(iconBtn('kp-mini-btn', 'copy', 'Duplicar quadro', () => { addFrame(true); }, 22));
    m.appendChild(el('span', 'kp-ms-icon', svg('clock', 18)));
    m.appendChild(iconBtn('kp-mini-btn', 'minus', 'Mais rápido', () => setMs(f.ms - step), 20));
    m.appendChild(el('span', 'kp-ms', String(f.ms)));
    m.appendChild(iconBtn('kp-mini-btn', 'plus', 'Mais devagar', () => setMs(f.ms + step), 20));
    m.appendChild(iconBtn('kp-mini-btn kp-danger', 'trash', 'Excluir quadro', () => {
      if (KP.doc.frames.length <= 1) { toast('Precisa de ao menos 1 quadro'); return; }
      Modal.confirm('Excluir quadro', 'Excluir este quadro da animação?', () => {
        KP.doc.frames.splice(KP.frameIdx, 1); KP.frameIdx = clamp(KP.frameIdx, 0, KP.doc.frames.length - 1);
        KP.layerIdx = clamp(KP.layerIdx, 0, currentFrame().layers.length - 1); KP.dirty = true; closeFrameMenu(); renderAll(); renderFramesStrip();
      });
    }, 22));
  }
  function togglePlay() {
    if (KP.playing) { KP.playing = false; clearTimeout(KP.playTimer); renderAll(); refreshTransport(); return; }
    if (KP.doc.frames.length < 2) return;
    closeSheet(); closeFrameMenu();
    KP.playing = true; refreshTransport();
    elOnion.getContext('2d').clearRect(0, 0, KP.doc.w, KP.doc.h);
    const step = () => {
      if (!KP.playing) return;
      compositeInto(elMain.getContext('2d'), currentFrame());
      markActiveFrame();
      KP.playTimer = setTimeout(() => { KP.frameIdx = (KP.frameIdx + 1) % KP.doc.frames.length; step(); }, currentFrame().ms);
    };
    step();
  }

  function bindUi() {
    const wrapEl = $('kp-stage-wrap');
    wrapEl.onpointerdown = onPointerDown;
    wrapEl.onpointermove = onPointerMove;
    wrapEl.onpointerup = onPointerUp;
    wrapEl.onpointercancel = onPointerUp;
    $$('#kp-tools [data-kp-tool]').forEach(b => { b.onclick = () => onToolTap(b.dataset.kpTool); });
    $('kp-undo').onclick = undo;
    $('kp-redo').onclick = redo;
    $('kp-full-undo').onclick = undo; $('kp-full-redo').onclick = redo; $('kp-full-exit').onclick = () => toggleFull(false);
    $('kp-close').onclick = () => { if (KP.dirty) Modal.confirm('Sair', 'Sair sem salvar as alterações?', closePaint); else closePaint(); };
    $('kp-save').onclick = saveAsSprite;
    $('kp-more').onclick = () => toggleSheet('more');
    $('kp-layers').onclick = () => toggleSheet('layers');
    $('kp-size').oninput = (e) => {
      if (sliderKind() === 'tol') { KP.fill.tol = Number(e.target.value); $('kp-size-num').textContent = KP.fill.tol + '%'; }
      else if (sliderKind() === 'wand') { KP.wandTol = Number(e.target.value); $('kp-size-num').textContent = KP.wandTol + '%'; }
      else { activeBrush().size = Number(e.target.value); $('kp-size-num').textContent = e.target.value; }
    };
    bindBrushInputs(); bindPaletteInputs(); bindImportInputs();
    $('kp-onion').onclick = () => { KP.onionSkin = !KP.onionSkin; renderAll(); refreshTransport(); };
    $('kp-prev').onclick = () => selectFrame(KP.frameIdx - 1);
    $('kp-next').onclick = () => selectFrame(KP.frameIdx + 1);
    $('kp-play').onclick = togglePlay;
    $('kp-frame-add').onclick = () => addFrame(false);
  }

  // ===================== Exportação =====================
  function flattenToDataUrl(frame) {
    const c = document.createElement('canvas'); c.width = KP.doc.w; c.height = KP.doc.h;
    compositeInto(c.getContext('2d'), frame);
    return c.toDataURL('image/png');
  }
  function saveAsSprite() {
    finalizeEdits();
    const frames = KP.doc.frames.map(f => ({ src: flattenToDataUrl(f), ms: f.ms }));
    KP.opts.onSave && KP.opts.onSave(frames[0].src, frames);
    closePaint();
  }
  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 20000);
  }
  async function saveToGallery(kind) {
    finalizeEdits();
    if (kind === 'png') {
      const dataUrl = flattenToDataUrl(currentFrame());
      const blob = await (await fetch(dataUrl)).blob();
      downloadBlob(blob, 'kix-sprite-' + Date.now() + '.png');
      toast('PNG salvo');
      return;
    }
    if (kind === 'gif') {
      toast('Gerando GIF…');
      setTimeout(() => {
        try {
          const blob = encodeGif(KP.doc.frames, KP.doc.w, KP.doc.h);
          downloadBlob(blob, 'kix-sprite-' + Date.now() + '.gif');
          toast('GIF salvo');
        } catch (e) { console.error(e); toast('Não foi possível gerar o GIF'); }
      }, 30);
      return;
    }
    if (kind === 'webm') {
      if (KP.doc.frames.length < 2) { toast('Adicione mais de um quadro para exportar vídeo'); return; }
      if (!window.MediaRecorder || !elMain.captureStream) { toast('Este WebView não suporta exportar vídeo'); return; }
      try {
        toast('Gravando vídeo…');
        const supportsManualFrames = typeof elMain.captureStream === 'function';
        const stream = supportsManualFrames ? elMain.captureStream(0) : elMain.captureStream(30);
        const track = stream.getVideoTracks()[0];
        const canRequestFrame = typeof track.requestFrame === 'function';
        let mime = 'video/webm';
        if (window.MediaRecorder.isTypeSupported && !MediaRecorder.isTypeSupported(mime)) {
          mime = MediaRecorder.isTypeSupported('video/webm;codecs=vp8') ? 'video/webm;codecs=vp8' : '';
        }
        const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
        const chunks = [];
        rec.ondataavailable = (e) => { if (e.data.size) chunks.push(e.data); };
        const finished = new Promise(resolve => rec.onstop = resolve);
        rec.start();
        for (let loop = 0; loop < 2; loop++) {
          for (const f of KP.doc.frames) {
            compositeInto(elMain.getContext('2d'), f);
            if (canRequestFrame) track.requestFrame();
            await new Promise(r => setTimeout(r, f.ms));
          }
        }
        await new Promise(r => setTimeout(r, 120));
        rec.stop();
        await finished;
        downloadBlob(new Blob(chunks, { type: 'video/webm' }), 'kix-sprite-' + Date.now() + '.webm');
        toast('Vídeo salvo');
        renderAll();
      } catch (e) { console.error(e); toast('Não foi possível gravar o vídeo'); }
    }
  }

  // ---- Codificador GIF89a (quantização por redução de bits + LZW) ----
  function quantizeFrames(frames, w, h) {
    const bitmaps = frames.map(f => {
      const c = document.createElement('canvas'); c.width = w; c.height = h;
      compositeInto(c.getContext('2d'), f);
      return c.getContext('2d').getImageData(0, 0, w, h).data;
    });
    // Reduz os 8 bits por canal até a paleta caber em 256 cores (quantização
    // por posterização, igual em espírito à usada por conversores GIF simples).
    const keyOf = (r, g, b, bits, shift) => ((r >> shift) << (2 * bits)) | ((g >> shift) << bits) | (b >> shift);
    let bits = 8, palette = null;
    for (; bits >= 1; bits--) {
      const shift = 8 - bits;
      const map = new Map();
      bitmaps.forEach(data => {
        for (let i = 0; i < data.length; i += 4) {
          const key = data[i + 3] < 128 ? 'T' : keyOf(data[i], data[i + 1], data[i + 2], bits, shift);
          if (!map.has(key)) map.set(key, [0, 0, 0, 0]);
          const v = map.get(key);
          if (key !== 'T') { v[0] += data[i]; v[1] += data[i + 1]; v[2] += data[i + 2]; }
          v[3]++;
        }
      });
      if (map.size <= 256) { palette = map; break; }
    }
    const shift = 8 - bits;
    const keys = [...palette.keys()];
    const hasTransparent = keys.includes('T');
    const colorKeys = keys.filter(k => k !== 'T');
    const table = colorKeys.map(k => {
      const v = palette.get(k);
      return [Math.round(v[0] / v[3]), Math.round(v[1] / v[3]), Math.round(v[2] / v[3])];
    });
    while (table.length < 2) table.push([0, 0, 0]);
    let tableSize = 1; while (tableSize < table.length + (hasTransparent ? 1 : 0)) tableSize *= 2;
    const tIdx = hasTransparent ? colorKeys.length : -1;
    while (table.length < tableSize) table.push([0, 0, 0]);
    const keyToIndex = new Map(colorKeys.map((k, i) => [k, i]));
    const indexed = bitmaps.map(data => {
      const out = new Uint8Array(w * h);
      for (let i = 0, p = 0; i < data.length; i += 4, p++) {
        if (data[i + 3] < 128) { out[p] = tIdx >= 0 ? tIdx : 0; continue; }
        const key = keyOf(data[i], data[i + 1], data[i + 2], bits, shift);
        const idx = keyToIndex.get(key);
        out[p] = idx == null ? 0 : idx;
      }
      return out;
    });
    return { table, indexed, transparentIndex: tIdx, codeSize: Math.max(2, Math.ceil(Math.log2(tableSize))) };
  }

  function lzwEncode(indices, minCodeSize) {
    const clearCode = 1 << minCodeSize, endCode = clearCode + 1;
    let codeSize = minCodeSize + 1, nextCode = endCode + 1;
    let dict = new Map();
    const resetDict = () => { dict = new Map(); for (let i = 0; i < clearCode; i++) dict.set(String(i), i); codeSize = minCodeSize + 1; nextCode = endCode + 1; };
    resetDict();
    const out = [];
    let bitBuf = 0, bitCount = 0;
    const emit = (code) => {
      bitBuf |= code << bitCount; bitCount += codeSize;
      while (bitCount >= 8) { out.push(bitBuf & 0xFF); bitBuf >>= 8; bitCount -= 8; }
    };
    emit(clearCode);
    let w = String(indices[0]);
    for (let i = 1; i < indices.length; i++) {
      const k = String(indices[i]);
      const wk = w + ',' + k;
      if (dict.has(wk)) { w = wk; continue; }
      emit(dict.get(w));
      if (nextCode < 4096) { dict.set(wk, nextCode++); if (nextCode > (1 << codeSize) && codeSize < 12) codeSize++; }
      else { emit(clearCode); resetDict(); }
      w = k;
    }
    emit(dict.get(w));
    emit(endCode);
    if (bitCount > 0) out.push(bitBuf & 0xFF);
    return out;
  }

  function encodeGif(frames, w, h) {
    const { table, indexed, transparentIndex, codeSize } = quantizeFrames(frames, w, h);
    const bytes = [];
    const push = (...v) => v.forEach(x => bytes.push(x & 0xFF));
    const pushStr = (s) => { for (let i = 0; i < s.length; i++) bytes.push(s.charCodeAt(i)); };
    pushStr('GIF89a');
    push(w & 0xFF, (w >> 8) & 0xFF, h & 0xFF, (h >> 8) & 0xFF);
    const tableBits = Math.ceil(Math.log2(table.length)) - 1;
    push(0x80 | (tableBits & 7), 0, 0);
    table.forEach(c => push(c[0], c[1], c[2]));
    // NETSCAPE2.0 (loop infinito)
    push(0x21, 0xFF, 0x0B); pushStr('NETSCAPE2.0'); push(3, 1, 0, 0, 0);
    frames.forEach((f, i) => {
      const delay = Math.round((f.ms || 100) / 10);
      push(0x21, 0xF9, 4, transparentIndex >= 0 ? 0x09 : 0x08, delay & 0xFF, (delay >> 8) & 0xFF, transparentIndex >= 0 ? transparentIndex : 0, 0);
      push(0x2C, 0, 0, 0, 0, w & 0xFF, (w >> 8) & 0xFF, h & 0xFF, (h >> 8) & 0xFF, 0);
      const effMin = Math.max(2, Math.ceil(Math.log2(table.length)));
      push(effMin);
      const data = lzwEncode(Array.from(indexed[i]), effMin);
      for (let p = 0; p < data.length; p += 255) {
        const chunk = data.slice(p, p + 255);
        push(chunk.length); chunk.forEach(b => bytes.push(b));
      }
      push(0);
    });
    push(0x3B);
    return new Blob([new Uint8Array(bytes)], { type: 'image/gif' });
  }

  // ===================== Abertura / fechamento =====================
  function buildDocFromImage(dataUrl, cb) {
    const img = new Image();
    img.onload = () => {
      const w = img.naturalWidth || 480, h = img.naturalHeight || 360;
      const pixelArt = w <= 128 && h <= 128;
      const doc = { w, h, pixelArt, frames: [newFrame(120, w, h)] };
      doc.frames[0].layers[0].ctx.drawImage(img, 0, 0);
      cb(doc);
    };
    img.onerror = () => cb({ w: 480, h: 360, pixelArt: false, frames: [newFrame(120, 480, 360)] });
    img.src = dataUrl;
  }

  function resizeDocTo(w, h, pixelArt, stretch) {
    KP.doc.frames.forEach(f => f.layers.forEach(l => {
      const tmp = document.createElement('canvas'); tmp.width = l.canvas.width; tmp.height = l.canvas.height;
      tmp.getContext('2d').drawImage(l.canvas, 0, 0);
      l.canvas.width = w; l.canvas.height = h;
      l.ctx.imageSmoothingEnabled = !pixelArt;
      if (stretch) l.ctx.drawImage(tmp, 0, 0, w, h); else l.ctx.drawImage(tmp, 0, 0);
    }));
    KP.history = []; KP.future = []; KP.dirty = true; updateUndoRedoButtons(); KP.float = null; KP.pending = null; KP.sel = null;
    KP.doc.w = w; KP.doc.h = h; KP.doc.pixelArt = pixelArt;
    sizeCanvases(); renderAll(); renderFramesStrip(); refreshToolbar();
  }
  function closePaint() {
    if (KP.playing) togglePlay();
    closeSheet(); closeFrameMenu(); Modal.hide(); KP._eyedropper = null; hideEyedropperLoupe(); KP.float = null; KP.pending = null; KP.xfRef = null; clearInterval(KP._antsTimer);
    try { window.KixProjectAPI?.show?.(KP._returnScreen || 'scripts', { noPush: true }); } catch (_) { show?.(KP._returnScreen || 'scripts', { noPush: true }); }
    $('screen-kix-paint').classList.add('hidden');
  }

  function open(opts) {
    opts = opts || {};
    KP.opts = opts;
    KP.history = []; KP.future = []; KP.gridOn = false; KP.onionSkin = false; KP.onionAuto = false; KP.playing = false;
    KP.sheet = null; KP.dirty = false; KP.shapeKind = null; KP.prevTool = 'brush'; KP.colorAdv = false; KP.brushTab = 'shape';
    KP.customBrushes = loadCustomBrushes(); KP.pals = loadPalettes(); KP.slot = 1; KP.color2 = 'transparent'; KP.colorTab = 'swatches'; KP.palSel = 'fav';
    KP.fill = { mode: 'fill', tol: 10, opacity: 100, grow: 1 }; KP.replaceTol = 10; KP.replaceScope = 'layer';
    KP.brush = KixBrush.make('basic'); KP.brush.size = 10; KP.brush.id = 'basic'; KP.brush.preset = true;
    KP.eraser = KixBrush.make('er-hard'); KP.eraser.id = 'er-hard'; KP.eraser.preset = true;
    KP.tool = 'brush'; KP.color = '#111111'; KP.shapeFilled = false;
    elStage = $('kp-stage'); elBg = $('kp-canvas-bg'); elOnion = $('kp-canvas-onion'); elMain = $('kp-canvas-main'); elOverlay = $('kp-canvas-overlay');
    try { elOverlay.getContext('2d', { desynchronized: true }); } catch (_) {}   // menos latência ao desenhar (Android)
    KP.sel = null; KP.float = null; KP.pending = null; KP.xfRef = null; KP.refs = []; KP.clip = null; KP._stroke = null; KP._eyedropper = null; ensureEyedropperLoupe(); hideEyedropperLoupe(); clearInterval(KP._antsTimer);
    KP.rot = 0; KP.flip = false; KP.full = false; KP.rotLock = false; KP.stretch = false; $('screen-kix-paint').classList.remove('kp-full');
    KP._returnScreen = (typeof lastScreen !== 'undefined') ? lastScreen : 'scripts';
    const screen = $('screen-kix-paint');
    screens_show(screen);
    hydrateIcons();
    bindUi();

    // Abre direto no desenho (sem perguntar tamanho). O tamanho da tela fica em "mais".
    const start = (doc) => {
      KP.doc = doc; KP.frameIdx = 0; KP.layerIdx = 0;
      if (doc.pixelArt) { KP.brush.size = doc.w <= 32 ? 1 : 2; KP.eraser.size = KP.brush.size; }
      sizeCanvases(); KP.guides = defaultGuides(); renderRefs(); renderFloatBar(); clearSelection();
      updateUndoRedoButtons();
      closeSheet(); closeFrameMenu();
      setColor(KP.color, true);
      refreshToolbar();
      renderAll();
      renderFramesStrip();
      requestAnimationFrame(fitZoom);
    };
    if (opts.baseImage) buildDocFromImage(opts.baseImage, start);
    else start({ w: 480, h: 360, pixelArt: false, frames: [newFrame(120, 480, 360)] });
  }
    function screens_show(screen) {
    // As demais telas do app marcam a si mesmas com o atributo `hidden` (não só
    // a classe) sempre que qualquer show() roda — inclusive antes de abrirmos o
    // editor. É preciso limpar os dois para a tela realmente aparecer.
    document.querySelectorAll('[id^="screen-"]').forEach(s => {
      if (s === screen) return;
      s.classList.add('hidden'); s.hidden = true; s.style.pointerEvents = 'none';
    });
    screen.classList.remove('hidden'); screen.hidden = false;
    screen.style.pointerEvents = 'auto'; screen.setAttribute('aria-hidden', 'false');
    screen.classList.add('kix-screen-enter');
    setTimeout(() => screen.classList.remove('kix-screen-enter'), 420);
  }

  window.addEventListener('resize', () => { if (KP.doc && !$('screen-kix-paint').classList.contains('hidden')) { refreshWrapRect(); fitZoom(true); } });
  document.addEventListener('fullscreenchange', () => { if (KP.full && !document.fullscreenElement) toggleFull(false); });

  window.KixPaint = Object.freeze({ open });
})();
