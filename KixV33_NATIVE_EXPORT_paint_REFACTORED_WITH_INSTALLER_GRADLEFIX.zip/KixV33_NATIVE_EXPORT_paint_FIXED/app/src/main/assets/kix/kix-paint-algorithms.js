/*
 * Kix Paint — algoritmos puros do canvas.
 * Bro: a região é topológica, não uma busca global por cor.
 * Btw: os pixels rejeitados também são marcados durante a visita para não
 * enfileirar a mesma posição repetidamente.
 * Muita resenha, mas só quatro vizinhos: esquerda, direita, cima e baixo.
 * Negócio guloso Kkkkk: o flood fill não usa recursão nem estoura a pilha JS.
 * Kkkkk v2: expandir é uma fase separada, executada depois da máscara.
 * Descançar ne pai que o caba não e de ferro.
 */
(function attachKixPaintAlgorithms(root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.KixPaintAlgorithms = api;
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : null), function createKixPaintAlgorithms() {
  'use strict';

  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

  function validateImage(data, width, height) {
    if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1) {
      throw new RangeError('Dimensões do canvas inválidas.');
    }
    const pixels = width * height;
    if (!Number.isSafeInteger(pixels) || !data || data.length < pixels * 4) {
      throw new RangeError('Buffer RGBA incompatível com as dimensões.');
    }
    return pixels;
  }

  function computeRegion4(data, width, height, startX, startY, tolerancePercent = 0) {
    const pixelCount = validateImage(data, width, height);
    const x = Math.floor(Number(startX));
    const y = Math.floor(Number(startY));
    const mask = new Uint8Array(pixelCount);
    if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0 || x >= width || y >= height) return mask;

    const tolerance = clamp(Number.isFinite(Number(tolerancePercent)) ? Number(tolerancePercent) : 0, 0, 100) * 5.1;
    const toleranceSquared = tolerance * tolerance;
    const start = y * width + x;
    const startOffset = start * 4;
    const targetR = data[startOffset];
    const targetG = data[startOffset + 1];
    const targetB = data[startOffset + 2];
    const targetA = data[startOffset + 3];
    const stack = new Int32Array(pixelCount);
    let stackSize = 0;

    function visit(index) {
      if (mask[index] !== 0) return;
      // 2 significa visitado/rejeitado; 1 significa membro da região.
      // A comparação é sempre com a cor inicial, nunca com o pixel anterior.
      mask[index] = 2;
      const offset = index * 4;
      const dr = data[offset] - targetR;
      const dg = data[offset + 1] - targetG;
      const db = data[offset + 2] - targetB;
      const da = data[offset + 3] - targetA;
      if ((dr * dr + dg * dg + db * db + da * da) <= toleranceSquared) {
        mask[index] = 1;
        stack[stackSize++] = index;
      }
    }

    mask[start] = 1;
    stack[stackSize++] = start;
    while (stackSize > 0) {
      const index = stack[--stackSize];
      const px = index % width;
      // 4-connected: nenhuma diagonal é examinada.
      if (px > 0) visit(index - 1);
      if (px + 1 < width) visit(index + 1);
      if (index >= width) visit(index - width);
      if (index + width < pixelCount) visit(index + width);
    }

    // O resultado público é uma máscara binária; rejeitados voltam a zero.
    for (let i = 0; i < pixelCount; i++) if (mask[i] === 2) mask[i] = 0;
    return mask;
  }

  function expandMask4(regionMask, width, height, radius = 0) {
    const pixelCount = validateImage(regionMask, width, height);
    const amount = clamp(Math.floor(Number(radius) || 0), 0, 8);
    const expanded = new Uint8Array(pixelCount);
    const queue = new Int32Array(pixelCount);
    let tail = 0;
    for (let i = 0; i < pixelCount; i++) {
      if (regionMask[i]) {
        expanded[i] = 1; // região original
        queue[tail++] = i;
      }
    }
    if (amount === 0 || tail === 0) return expanded;

    let head = 0;
    let levelEnd = tail;
    for (let step = 0; step < amount && head < levelEnd; step++) {
      while (head < levelEnd) {
        const index = queue[head++];
        const px = index % width;
        const candidates = [];
        if (px > 0) candidates.push(index - 1);
        if (px + 1 < width) candidates.push(index + 1);
        if (index >= width) candidates.push(index - width);
        if (index + width < pixelCount) candidates.push(index + width);
        for (const next of candidates) {
          if (expanded[next] !== 0) continue;
          expanded[next] = 2; // somente expansão pós-região
          queue[tail++] = next;
        }
      }
      levelEnd = tail;
    }
    return expanded;
  }

  function rgbaAt(data, width, height, x, y) {
    validateImage(data, width, height);
    const px = clamp(Math.floor(Number(x) || 0), 0, width - 1);
    const py = clamp(Math.floor(Number(y) || 0), 0, height - 1);
    const i = (py * width + px) * 4;
    return { x: px, y: py, r: data[i], g: data[i + 1], b: data[i + 2], a: data[i + 3] };
  }

  return Object.freeze({ computeRegion4, expandMask4, rgbaAt });
});
