/* Kix persisted-data format and N-1 -> N migration. Runtime-only. */
(function(global){
  'use strict';
  const CURRENT_FORMAT = 2;
  const clone = v => v == null ? v : JSON.parse(JSON.stringify(v));
  function migrate(input){
    let data = clone(input || {});
    let version = Number(data.formatVersion || data.dataFormatVersion || 1);
    if (!Number.isInteger(version) || version < 1 || version > CURRENT_FORMAT) {
      throw new Error(`Formato de dados inválido: ${version}`);
    }
    if (version === 1) {
      data = {
        ...data,
        formatVersion: 2,
        globals: data.globals && typeof data.globals === 'object' ? data.globals : (data.vars || {}),
        lists: data.lists && typeof data.lists === 'object' ? data.lists : {},
        runtime: data.runtime && typeof data.runtime === 'object' ? data.runtime : {}
      };
      delete data.vars;
      version = 2;
    }
    data.formatVersion = CURRENT_FORMAT;
    return data;
  }
  function serialize(runtime){
    const r = runtime || {};
    const actors = Array.isArray(r.actors) ? r.actors : [];
    return {formatVersion: CURRENT_FORMAT, globals: clone(r.globals || {}), lists: clone(r.lists || {}), actors: actors.map(a => ({id:a.id, data:clone(a.data || {})}))};
  }
  function restore(runtime, state){
    const data = migrate(state);
    if (runtime) {
      runtime.globals = clone(data.globals || {});
      runtime.lists = clone(data.lists || {});
      if (Array.isArray(data.actors) && Array.isArray(runtime.actors)) {
        const byId = new Map(data.actors.map(a => [String(a.id), a.data || {}]));
        for (const actor of runtime.actors) {
          const saved = byId.get(String(actor.id));
          if (saved) actor.data = {...actor.data, ...clone(saved)};
        }
      }
    }
    return data;
  }
  global.KixDataFormat = Object.freeze({CURRENT_FORMAT, migrate, serialize, restore});
})(typeof window !== 'undefined' ? window : globalThis);
