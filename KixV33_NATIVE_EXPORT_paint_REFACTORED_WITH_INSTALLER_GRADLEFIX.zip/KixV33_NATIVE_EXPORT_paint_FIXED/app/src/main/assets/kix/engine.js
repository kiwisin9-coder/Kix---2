// ============================================================
// Kix Engine v1.7.5 — tree scripts + interpreter + stage
// ============================================================
(function (global) {
  'use strict';


  const KIX_APP_VERSION = '1.8.0-phase3';
  const runtimeNow = () => { try { return Number(global.KixDeterminism?.now?.()) || 0; } catch (_) { return Date.now(); } };
  const runtimeRandom = () => { try { const n = Number(global.KixDeterminism?.random?.()); return Number.isFinite(n) ? n : Math.random(); } catch (_) { return Math.random(); } };
  const runtimeDate = () => new Date(runtimeNow());
  function runtimeDiagnostic(code, message, source = {}) { try { return global.KixDiagnostics?.report?.(code, message, source); } catch (_) { return null; } }
  const STAGE_W = 480;
  const STAGE_H = 800;
  let uid = 0;
  // Image resources persist between play/restart cycles. Recreating the cache on every
  // start was causing browsers to decode the same sprites again and could stall a frame.
  const globalImageCache = new Map();
  const globalImageLoads = new Map();
  function newId() { return 'b' + (++uid) + '_' + runtimeNow().toString(36); }

  const HAT_NAMES = new Set([
    'Quando a cena começar', 'Quando tocado', 'Quando a tela for pressionada',
    'Quando receber mensagem', 'Quando começar como clone', 'Quando um clone for criado',
    'Quando o dispositivo for sacudido', 'Quando o app for retomado', 'Quando inclinar dispositivo', 'Quando bater no dispositivo'
  ]);
  const LOOP_NAMES = new Set(['Sempre', 'Repita X vezes', 'Repita até', 'Repita enquanto', 'Repetir assincronamente X vezes', 'Repetir para sempre com delay']);
  const IF_NAMES = new Set(['Se ... então', 'Se ... então ... senão', 'Se [Fórmula] for verdadeira então...']);

  function blockType(name) {
    const raw = String(name || '');
    if (HAT_NAMES.has(raw) || (raw && raw.startsWith('Quando '))) return 'hat';
    if (LOOP_NAMES.has(raw)) return 'loop';
    if (IF_NAMES.has(raw)) return 'if';
    if (raw && (raw.includes('Comentário') || raw === 'Nota')) return 'note';
    try {
      const pluginDef = global.KixPluginRuntime?.findBlockByName?.(raw);
      if (pluginDef && ['hat','loop','if','note','action'].includes(String(pluginDef.type || ''))) return String(pluginDef.type);
    } catch (_) {}
    // The Catrobat registry may be supplied by the host. Resolve it lazily
    // so persisted/imported English Catrobat names receive the right structural type.
    try {
      const alias = global.KixCatrobatBrickAliases && global.KixCatrobatBrickAliases[String(raw).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[.……]/g,'').replace(/[^a-z0-9]+/g,' ').trim()];
      const def = alias && global.KixCatrobatBrickRegistry ? global.KixCatrobatBrickRegistry[alias] : null;
      if (def && (def.type === 'hat' || def.type === 'loop' || def.type === 'if' || def.type === 'note')) return def.type;
    } catch (_) {}
    return 'action';
  }

  const BLOCK_ALIASES = {
    'Se condição então': 'Se ... então',
    'Se condição então senão': 'Se ... então ... senão',
    'Tentar e se der erro': 'Tentar ... se erro',
    'Se estiver na borda volte': 'Se estiver na borda, volte',
    'Ir para X: Y:': 'Ir para X e Y',
    'Definir Gravidade Custom': 'Definir gravidade personalizada',
    'Física de Veículo': 'Configurar física de veículo',
    'Simular Explosão': 'Simular explosão',
    'Definir Restituição': 'Definir restituição',
    'Reproduzir animação': 'Reproduzir animação da pasta',
    'Repetir animação': 'Repetir animação da pasta',
    'Repetir animação da pasta em loop': 'Repetir animação da pasta em loop',
    'Definir pasta como animação em loop': 'Repetir animação da pasta',
    'Parar animação em loop da pasta': 'Parar animação da pasta',
    'Definir negrito/italico': 'Definir negrito e itálico',
    'Definir espacamento entre linhas': 'Definir espaçamento entre linhas',
    'Efeito de digitacao (typewriter)': 'Efeito de digitação',
    'Quebra de linha automatica': 'Quebra de linha automática'
  };
  function stableOpcode(name) {
    const canonical = BLOCK_ALIASES[name] || name;
    let h = 2166136261;
    const s = String(canonical).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    for (let i=0;i<s.length;i++) { h ^= s.charCodeAt(i); h = Math.imul(h,16777619); }
    return 'kix.' + (h >>> 0).toString(16).padStart(8,'0');
  }
  function opcodeFor(name) { return stableOpcode(String(name || '')); }
  function canonicalBlockName(name) { const n = BLOCK_ALIASES[name] || name; return String(n || '').replace(/^Preset:\s*/i, ''); }

  /** Migrate flat scripts array → tree of stacks */
  function migrateScripts(scripts) {
    if (!scripts) return { stacks: [], blocks: [] };
    if (scripts.stacks && scripts.blocks) return scripts;

    const list = Array.isArray(scripts) ? scripts : [];
    const blocks = {};
    const ids = list.map((s, i) => {
      const id = (s && s.id) ? String(s.id) : ('b' + i);
      if (s && !s.id) s.id = id;
      const persistedType = ['hat','action','loop','if','note','custom'].includes(String(s?.type||'')) ? String(s.type) : '';
      const rawName = String(s?.name || '');
      const compatAlias = (() => {
        try {
          const key = rawName.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[.……]/g,'').replace(/[^a-z0-9]+/g,' ').trim();
          return global.KixCatrobatBrickAliases && global.KixCatrobatBrickAliases[key];
        } catch (_) { return ''; }
      })();
      const compatDef = compatAlias && global.KixCatrobatBrickRegistry ? global.KixCatrobatBrickRegistry[compatAlias] : null;
      const type = (compatDef && ['hat','loop','if','note'].includes(String(compatDef.type||'')))
        ? compatDef.type
        : (persistedType || (compatDef && compatDef.type) || blockType(rawName));
      const sourceType = String(s?.catrobat?.sourceType || '');
      const sourceName = canonicalBlockName((compatDef && compatDef.projectName) || rawName);
      const boundaryKind = /CatrobatLoopEnd/i.test(sourceType) || sourceName === 'Fim de loop'
        ? 'loop'
        : (/CatrobatIfElse/i.test(sourceType) || sourceName === 'Senão' ? 'ifElse'
          : (/CatrobatIfEnd/i.test(sourceType) || sourceName === 'Fim de condição' || sourceName === 'Fim se' ? 'if' : null));
      blocks[id] = {
        id,
        opcode: s?.opcode || stableOpcode(s?.name),
        type,
        name: sourceName,
        legacyName: s && s.name !== sourceName ? s.name : undefined,
        color: s?.color,
        params: s?.params || [],
        values: s?.values || {},
        disabled: !!s?.disabled,
        next: null,
        boundaryKind,
        boundaryAfter: null,
        boundaryOwnerId: null,
        loopEndId: type === 'loop' && s?.loopEndId != null ? String(s.loopEndId) : null,
        loopBoundaryExplicit: type === 'loop' && s?.loopBoundaryExplicit === true,
        ifEndId: type === 'if' && s?.ifEndId != null ? String(s.ifEndId) : null,
        ifBoundaryExplicit: type === 'if' && s?.ifBoundaryExplicit === true,
        ifElseId: type === 'if' && s?.ifElseId != null ? String(s.ifElseId) : null,
        ifElseExplicit: type === 'if' && s?.ifElseExplicit === true,
        body: (type === 'loop' || type === 'if') ? [] : undefined,
        bodyElse: type === 'if' ? [] : undefined,
        pluginId: s?.pluginId != null ? String(s.pluginId) : undefined,
        pluginBlockId: s?.pluginBlockId != null ? String(s.pluginBlockId) : undefined,
        pluginLanguage: s?.pluginLanguage != null ? String(s.pluginLanguage) : undefined,
        heightY: s?.heightY != null ? Number(s.heightY) : undefined,
        multiline: s?.multiline === true,
        template: s?.template != null ? String(s.template) : undefined,
        example: s?.example != null ? String(s.example) : undefined,
        useCategoryColor: s?.useCategoryColor != null ? s.useCategoryColor !== false : undefined,
        compatId: s?.compatId || compatAlias || undefined,
        catrobatName: s?.catrobatName || (compatDef && compatDef.catrobatName) || undefined,
        catrobatCategory: s?.catrobatCategory || (compatDef && compatDef.category) || undefined,
        compatNative: s?.compatNative !== undefined ? s.compatNative : (compatDef ? compatDef.compatNative : undefined),
        customBrickId: s?.customBrickId || undefined,
        userDefinedBrickId: s?.userDefinedBrickId || (s?.values && s.values.userDefinedBrickId) || undefined,
        userDefinedBrickName: s?.userDefinedBrickName || undefined,
        userBrickId: s?.userBrickId || undefined,
        brickType: s?.brickType || undefined,
        canContainChildren: s?.canContainChildren,
        canBeChild: s?.canBeChild,
        allowedParent: Array.isArray(s?.allowedParent) ? s.allowedParent.slice() : undefined,
        allowedChildren: Array.isArray(s?.allowedChildren) ? s.allowedChildren.slice() : undefined
      };
      return id;
    });
    if (!ids.length) return { stacks: [], blocks };

    const indexById = new Map(ids.map((id, i) => [String(id), i]));

    // Structured flat-script migration. A control block owns everything up to its
    // explicit terminator; nested controls are parsed recursively, so their own
    // 'next' pointers are never overwritten by the parent loop/IF.
    function explicitEndIndex(block, index) {
      const endId = block?.type === 'loop'
        ? (block.loopBoundaryExplicit ? block.loopEndId : null)
        : (block?.type === 'if' ? (block.ifBoundaryExplicit ? block.ifEndId : null) : null);
      if (!endId) return -1;
      const n = indexById.get(String(endId));
      if (n == null || n <= index) return -1;
      const endBlock = blocks[String(endId)];
      if (!endBlock) return -1;
      return n;
    }

    function legacyEndIndex(index, limit) {
      // Backwards-compatible heuristic for older Kix flat projects without explicit
      // boundary IDs. Modern/imported projects use the structured path above.
      let end = Math.min(limit - 1, index);
      for (let j = index + 1; j < limit; j++) {
        const cb = blocks[ids[j]];
        if (!cb) continue;
        if (cb.type === 'hat' || cb.type === 'loop' || cb.type === 'if') break;
        if (cb.boundaryKind) break;
        end = j;
      }
      return end > index ? end : -1;
    }

    function parseRange(startIndex, endExclusive, tailId) {
      const result = [];
      let i = startIndex;
      while (i < endExclusive) {
        const id = ids[i];
        const b = blocks[id];
        if (!b) { i++; continue; }
        if (b.type === 'hat') break;
        // A terminator belonging to an enclosing control is not part of this direct
        // sequence. Its owning control explicitly includes it in its own body.
        if (b.boundaryKind) { i++; continue; }

        if (b.type === 'loop' || b.type === 'if') {
          let endIndex = explicitEndIndex(b, i);
          if (endIndex < 0) endIndex = legacyEndIndex(i, endExclusive);
          let bodyIncludesEnd = false;
          if (endIndex >= 0 && endIndex < endExclusive) {
            const endId = ids[endIndex];
            const endBlock = blocks[endId];
            if (b.type === 'if') {
              let elseIndex = -1;
              const explicitElse = b.ifElseExplicit && b.ifElseId ? indexById.get(String(b.ifElseId)) : null;
              if (explicitElse != null && explicitElse > i && explicitElse < endIndex) elseIndex = explicitElse;
              if (elseIndex < 0) {
                for (let j = i + 1; j < endIndex; j++) {
                  const candidate = blocks[ids[j]];
                  if (candidate?.boundaryKind === 'ifElse') { elseIndex = j; break; }
                }
              }
              if (elseIndex >= 0) {
                const elseId = ids[elseIndex];
                const elseBlock = blocks[elseId];
                const trueBody = parseRange(i + 1, elseIndex, elseId);
                const falseBody = parseRange(elseIndex + 1, endIndex, endId);
                b.body = trueBody;
                b.bodyElse = falseBody;
                b.ifElseId = String(elseId);
                b.ifElseExplicit = true;
                if (elseBlock) {
                  elseBlock.boundaryKind = 'ifElse';
                  elseBlock.boundaryOwnerId = b.id;
                  elseBlock.boundaryAfter = String(endId);
                  elseBlock.next = String(endId);
                  elseBlock.disabled = true;
                }
              } else {
                b.body = parseRange(i + 1, endIndex, endId);
                b.bodyElse = [];
              }
            } else if (endBlock && !endBlock.boundaryKind) {
              // O editor do Kix guarda loopEndId como o ÚLTIMO bloco do corpo (o "Fim de loop"
              // é só um marcador visual). Esse bloco faz parte do loop e NÃO pode ser tratado
              // como terminador, senão ele é desativado e o loop perde o último bloco.
              b.body = parseRange(i + 1, endIndex + 1, null);
              bodyIncludesEnd = true;
            } else {
              const inner = parseRange(i + 1, endIndex, endId);
              b.body = inner.concat([endId]);
            }
            if (endBlock && !bodyIncludesEnd) {
              endBlock.boundaryKind = b.type === 'loop' ? 'loop' : 'if';
              endBlock.boundaryOwnerId = b.id;
              endBlock.boundaryAfter = null;
              endBlock.next = null;
              endBlock.disabled = true;
            }
            result.push(id);
            i = endIndex + 1;
            continue;
          }
          // Empty/legacy malformed structured control: keep it safe and sequential.
          b.body = [];
          result.push(id);
          i++;
          continue;
        }
        result.push(id);
        i++;
      }

      // Link this direct sequence. Control blocks keep the 'next' after their own
      // terminator; ordinary blocks simply chain to the next direct element. The
      // supplied tail is the enclosing control terminator when parsing a body.
      for (let k = 0; k < result.length; k++) {
        const cur = blocks[result[k]];
        if (!cur) continue;
        const nextId = k + 1 < result.length ? result[k + 1] : (tailId || null);
        cur.next = nextId;
      }
      return result;
    }

    const stacks = [];
    const hatIndices = [];
    for (let i = 0; i < ids.length; i++) if (blocks[ids[i]]?.type === 'hat') hatIndices.push(i);

    if (hatIndices.length) {
      // Keep any prefix before the first hat as a regular chain for old/corrupt files.
      if (hatIndices[0] > 0) {
        const prefix = parseRange(0, hatIndices[0], null);
        if (prefix.length) stacks.push(prefix[0]);
      }
      for (let h = 0; h < hatIndices.length; h++) {
        const hi = hatIndices[h];
        const end = h + 1 < hatIndices.length ? hatIndices[h + 1] : ids.length;
        const hat = blocks[ids[hi]];
        const chain = parseRange(hi + 1, end, null);
        hat.next = chain.length ? chain[0] : null;
        stacks.push(hat.id);
      }
    } else {
      const chain = parseRange(0, ids.length, null);
      if (chain.length) stacks.push(chain[0]);
    }

    // Fill the boundary-after metadata now that each control's parent sequence has
    // determined the block that follows its terminator.
    for (const id of ids) {
      const b = blocks[id];
      if (!b || !b.boundaryOwnerId) continue;
      const owner = blocks[b.boundaryOwnerId];
      if (b.boundaryKind === 'if') b.boundaryAfter = owner ? owner.next : null;
      if (b.boundaryKind === 'ifElse') b.boundaryAfter = owner && owner.ifEndId ? owner.ifEndId : null;
    }

    return { stacks, blocks };
  }

  // ===== Formula engine =====
  // Human-friendly formulas are parsed here instead of passing them through Function/eval.
  // This keeps multi-word sensors/properties usable inside larger expressions such as:
  // "toque y + 20", "posição x da câmera + 10", "seno(45) * 10".
  function formulaNormalizeName(v) {
    return String(v == null ? '' : v).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
  }

  function dataDefinitionFor(name, actor) {
    const p = runtime.project;
    const defs = Array.isArray(p && p.dataDefinitions) ? p.dataDefinitions : [];
    const q = String(name == null ? '' : name).trim();
    if (!q) return null;
    const def = defs.find(d => String(d && d.name || '') === q) || defs.find(d => String(d && d.name || '').toLowerCase() === q.toLowerCase());
    if (!def) return null;
    return def;
  }
  function dataDefinitionActorKey(actor) {
    try { return String(actor?.kixId ?? actor?.id ?? actor?.name ?? ''); } catch (_) { return ''; }
  }
  function runtimeDataGet(name, actor, fallback) {
    const def = dataDefinitionFor(name, actor);
    if (!def) return fallback;
    if (def.scope === 'object') {
      const key = dataDefinitionActorKey(actor);
      if (key && def.valuesByActor && Object.prototype.hasOwnProperty.call(def.valuesByActor,key)) return def.valuesByActor[key];
      if (actor?._vars && Object.prototype.hasOwnProperty.call(actor._vars, def.name)) return actor._vars[def.name];
      return def.value;
    }
    if (runtime.globals && Object.prototype.hasOwnProperty.call(runtime.globals,def.name)) return runtime.globals[def.name];
    return def.value;
  }
  function runtimeDataSet(name, value, actor) {
    const def = dataDefinitionFor(name, actor);
    if (!def) return false;
    def.updatedAt = runtimeNow();
    if (def.scope === 'object') {
      const key = dataDefinitionActorKey(actor);
      if (key) { def.valuesByActor = def.valuesByActor || {}; def.valuesByActor[key] = value; }
      if (actor) { actor._vars = actor._vars || {}; actor._vars[def.name] = value; }
    } else {
      def.value = value;
      runtime.globals[def.name] = value;
    }
    return true;
  }
  function formulaLookup(name, ctx) {
    const n = formulaNormalizeName(name);
    const actor = (ctx && ctx.actor) || {};
    const vars = (ctx && ctx.vars) || {};
    const globals = (ctx && ctx.globals) || {};
    const aliases = {
      'posicao x':'x', 'posição x':'x', 'posicao y':'y', 'posição y':'y',
      'direcao':'direction', 'direção':'direction', 'tamanho':'size',
      'largura':'_width', 'altura':'_height', 'camada':'layer',
      'transparencia':'transparency', 'transparência':'transparency',
      'velocidade x':'vx', 'velocidade y':'vy',
    };

    if (n in vars) return vars[n];
    if (name in vars) return vars[name];
    const dataValue = runtimeDataGet(name, actor, undefined);
    if (dataValue !== undefined) return dataValue;
    if (n in globals) return globals[n];
    if (name in globals) return globals[name];

    // Direct variable fallback (accent/case insensitive).
    for (const k of Object.keys(vars)) if (formulaNormalizeName(k) === n) return vars[k];
    for (const k of Object.keys(globals)) if (formulaNormalizeName(k) === n) return globals[k];

    if (n === 'sim' || n === 'true' || n === 'verdadeiro') return 1;
    if (n === 'nao' || n === 'false' || n === 'falso') return 0;

    if (n === '__camera_x' || n === 'posicao x da camera' || n === 'camera x' || n === 'camera_x') return -Number(runtime.camX || 0);
    if (n === '__camera_y' || n === 'posicao y da camera' || n === 'camera y' || n === 'camera_y') return Number(runtime.camY) || 0;
    if (n === '__camera_zoom' || n === 'zoom da camera' || n === 'camera zoom' || n === 'camera_zoom') return Number(runtime.camZoom) || 1;
    if (n === '__camera_rot' || n === 'rotacao da camera' || n === 'rotação da câmera' || n === 'camera rotacao') return Number(runtime.camRot) || 0;
    if (n === '__camera_center_x' || n === 'centro x da camera' || n === 'centro x da câmera') {
      const sw = Number(runtime._logicalStageW || (runtime.stageEl && runtime.stageEl._stageW) || 480) / 2;
      return -Number(runtime.camX || 0) + sw;
    }
    if (n === '__camera_center_y' || n === 'centro y da camera' || n === 'centro y da câmera') {
      const sh = Number(runtime._logicalStageH || (runtime.stageEl && runtime.stageEl._stageH) || 800) / 2;
      return Number(runtime.camY || 0) + sh;
    }
    if (n === '__fps' || n === 'fps' || n === 'fps atual' || n === 'fps da engine') return Number(runtime.fps) || 0;
    if (n === '__elapsed' || n === 'tempo' || n === 'tempo de jogo' || n === 'tempo decorrido') return Number(runtime.elapsedSeconds) || 0;
    if (n === '__elapsed_ms' || n === 'tempo ms' || n === 'tempo em ms') return Number(runtime.elapsedMs) || 0;
    if (n === '__touch_x' || n === 'toque x' || n === 'valor toque x' || n === 'touch x') return Number(runtime.touch.x) || 0;
    if (n === '__touch_y' || n === 'toque y' || n === 'valor toque y' || n === 'touch y') return Number(runtime.touch.y) || 0;
    if (n === '__touch_down' || n === 'tela esta tocada' || n === 'tela tocada' || n === 'touch down') return runtime.touch.down ? 1 : 0;
    if (n === 'toque ativo') return runtime.touch.active ? 1 : 0;
    // Catrobat finger/object sensors used by imported Duststorm projects.
    if (n === '__finger_x' || n === 'finger x' || n === 'finger_x') return Number(runtime.touch.x) || 0;
    if (n === '__finger_y' || n === 'finger y' || n === 'finger_y') return Number(runtime.touch.y) || 0;
    if (n === '__finger_touched' || n === 'finger touched' || n === 'finger_touched') return runtime.touch.down ? 1 : 0;
    if (n === '__last_finger_index' || n === 'last finger index' || n === 'last_finger_index') return Number(runtime.touch.lastFingerIndex) || 0;
    if (n === '__collides_with_finger' || n === 'collides with finger' || n === 'collides_with_finger') {
      const ra = (ctx && (ctx.runtimeActor || ctx.actorRuntime));
      return pointInActorBounds(ra, Number(runtime.touch.x)||0, Number(runtime.touch.y)||0) ? 1 : 0;
    }
    if (n === '__collides_with_edge' || n === 'collides with edge' || n === 'collides_with_edge') {
      const ra = (ctx && (ctx.runtimeActor || ctx.actorRuntime));
      return actorCollidesWithStageEdge(ra) ? 1 : 0;
    }
    if (n === '__object_x' || n === 'object x' || n === 'object_x') return Number(actor.x) || 0;
    if (n === '__object_y' || n === 'object y' || n === 'object_y') return Number(actor.y) || 0;
    if (n === '__object_transparency' || n === 'object transparency' || n === 'object_transparency') return Number(actor.transparency != null ? actor.transparency : (100 - Number(actor.opacity == null ? 100 : actor.opacity))) || 0;
    if (n === '__object_size' || n === 'object size' || n === 'object_size') return Number(actor.size) || 0;
    if (n === '__screen_w' || n === 'largura da tela' || n === 'tela largura') return Number(runtime._logicalStageW || (runtime.stageEl && runtime.stageEl._stageW) || 0);
    if (n === '__screen_h' || n === 'altura da tela' || n === 'tela altura') return Number(runtime._logicalStageH || (runtime.stageEl && runtime.stageEl._stageH) || 0);
    if (n === 'objetos') return (runtime.actors || []).length;
    if (n === 'custo fps' || n === 'tempo do frame' || n === 'ms por frame') return Number(runtime.frameMs) || 0;
    if (n === 'timestamp' || n === 'agora') return runtimeNow();

    // Phase 3 sensor provider takes precedence over the legacy device cache.
    try {
      const phase3Sensor = global.KixPhase3Runtime?.sensorFormula?.(name, ctx?.diagnosticSource || {});
      if (phase3Sensor !== undefined) return phase3Sensor;
    } catch (_) {}

    // Device / clock sensors. These are live values and are safe to read from formulas.
    const ds = runtime.device || {};
    if (n === 'bateria' || n === 'nivel da bateria') return Math.round((Number(ds.battery) || 0) * 100);
    if (n === 'acelerometro' || n === 'acelerometro x') return Number(ds.accel && ds.accel.x) || 0;
    if (n === 'acelerometro y') return Number(ds.accel && ds.accel.y) || 0;
    if (n === 'acelerometro z') return Number(ds.accel && ds.accel.z) || 0;
    if (n === 'giroscopio' || n === 'giroscopio beta') return Number(ds.gyro && ds.gyro.beta) || 0;
    if (n === 'giroscopio alpha') return Number(ds.gyro && ds.gyro.alpha) || 0;
    if (n === 'giroscopio gamma') return Number(ds.gyro && ds.gyro.gamma) || 0;
    if (n === 'bussola' || n === 'bússola') return Number(ds.compass) || 0;
    if (n === 'gps latitude' || n === 'gps lat') return Number(ds.gps && ds.gps.lat) || 0;
    if (n === 'gps longitude' || n === 'gps lng') return Number(ds.gps && ds.gps.lng) || 0;
    if (n === 'gps precisao' || n === 'gps precisão') return Number(ds.gps && ds.gps.accuracy) || 0;
    if (n === 'luz' || n === 'sensor de luz') return Number(ds.light) || 0;
    if (n === 'proximidade') return ds.proximity ? 1 : 0;
    const clock = runtimeDate();
    if (n === 'hora') return clock.getHours();
    if (n === 'minuto') return clock.getMinutes();
    if (n === 'segundo') return clock.getSeconds();
    if (n === 'milissegundo') return clock.getMilliseconds();
    if (n === 'ano') return clock.getFullYear();
    if (n === 'mes') return clock.getMonth() + 1;
    if (n === 'dia') return clock.getDate();
    if (n === 'dia da semana') return clock.getDay();

    // Actor properties used by expression evaluation.
    if (n === '__actor_x') return Number(actor.x) || 0;
    if (n === '__actor_y') return Number(actor.y) || 0;
    if (n === '__vx') return Number(actor.vx) || 0;
    if (n === '__vy') return Number(actor.vy) || 0;
    if (n === '__actor_width') return Number(actor.width || actor._width || 0);
    if (n === '__actor_height') return Number(actor.height || actor._height || 0);

    if (n === '__touching_obj' || n === 'esta tocando objeto' || n === 'está tocando objeto') {
      if (ctx && ctx.touchingActor) return 1;
      return 0;
    }
    if (n === '__edge' || n === 'tocando na borda') {
      const w = Number((runtime.stageEl && runtime.stageEl._stageW) || 480) / 2;
      const h = Number((runtime.stageEl && runtime.stageEl._stageH) || 800) / 2;
      return (Math.abs(Number(actor.x)||0) >= w || Math.abs(Number(actor.y)||0) >= h) ? 1 : 0;
    }
    if (n === 'distancia ate' || n === 'distância até') return 0;

    if (aliases[n]) {
      const key = aliases[n];
      if (key === 'opacity') return actor.opacity != null ? Number(actor.opacity) : 100;
      if (key === 'layer') return Number(actor.layer) || 0;
      if (key === '_width') return Number(actor.width || actor._width || 0);
      if (key === '_height') return Number(actor.height || actor._height || 0);
      return actor[key] != null ? Number(actor[key]) || 0 : 0;
    }

    // Appearance metadata is kept readable for formulas.
    if (n === '__look_index' || n === 'aparencia atual' || n === 'aparência atual') return Number(actor.costume || 0) + 1;
    if (n === '__look_name' || n === 'nome da aparencia' || n === 'nome da aparência') {
      const names = actor.lookNames || {};
      const src = Array.isArray(actor.looks) ? actor.looks[Number(actor.costume)||0] : '';
      return names[src] || '';
    }

    return undefined;
  }

  function formulaFn(name, args, ctx) {
    const n = formulaNormalizeName(name);
    const a = args || [];
    const x = Number(a[0]) || 0;
    switch (n) {
      case 'seno': return Math.sin(x * Math.PI / 180);
      case 'cosseno': return Math.cos(x * Math.PI / 180);
      case 'tangente': return Math.tan(x * Math.PI / 180);
      case 'raiz': return Math.sqrt(Math.max(0, x));
      case 'potencia': case 'potência': return Math.pow(x, Number(a[1]) || 0);
      case 'arredondar': return Math.round(x);
      case 'piso': return Math.floor(x);
      case 'teto': return Math.ceil(x);
      case 'absoluto': return Math.abs(x);
      case 'aleatorio': case 'aleatório': {
        const min = a.length > 1 ? Number(a[0]) || 0 : 0;
        const max = a.length > 1 ? Number(a[1]) || 1 : x || 1;
        return min + runtimeRandom() * (max - min);
      }
      case 'mod': case 'resto': return Number(a[1]) === 0 ? 0 : x % Number(a[1]);
      case 'comprimento': return String(a[0] == null ? '' : a[0]).length;
      case 'juntar': return a.map(v => String(v == null ? '' : v)).join('');
      case 'letra': {
        const text = String(a[0] == null ? '' : a[0]);
        const i = Math.max(1, Math.floor(Number(a[1]) || 1)) - 1;
        return text[i] || '';
      }
      case 'para numero': case 'para número': case 'para_numero': return Number(a[0]) || 0;
      case 'para texto': case 'para_texto': return String(a[0] == null ? '' : a[0]);
      case 'minimo': case 'mínimo': return Math.min(...a.map(v => Number(v)||0));
      case 'maximo': case 'máximo': return Math.max(...a.map(v => Number(v)||0));
      case 'limitar': case 'clamp': return Math.min(Number(a[2])||0, Math.max(Number(a[1])||0, x));
      case 'log': case 'logaritmo': return Math.log(Math.max(Number(x), Number.EPSILON));
      case 'log base': case 'logaritmo base': return (Number(a[1]) > 0 && Number(a[1]) !== 1) ? Math.log(Math.max(Number(a[0]), Number.EPSILON)) / Math.log(Number(a[1])) : 0;
      case 'log10': return Math.log10(Math.max(Number(x), Number.EPSILON));
      case 'exponencial': case 'exp': return Math.exp(x);
      case 'interpolar': case 'lerp': return Number(a[0]) + (Number(a[1])-Number(a[0]))*(Number(a[2])||0);
      case 'misturar': return Number(a[0]) + (Number(a[1])-Number(a[0]))*(Number(a[2])||0);
      case 'maiuscula': return String(a[0] == null ? '' : a[0]).toUpperCase();
      case 'minuscula': return String(a[0] == null ? '' : a[0]).toLowerCase();
      case 'substituir': return String(a[0] == null ? '' : a[0]).split(String(a[1] == null ? '' : a[1])).join(String(a[2] == null ? '' : a[2]));
      case 'dividir texto': case 'dividir_texto': return String(a[0] == null ? '' : a[0]).split(String(a[1] == null ? ',' : a[1]));
      case 'comeca com': return String(a[0]).startsWith(String(a[1])) ? 1 : 0;
      case 'termina com': return String(a[0]).endsWith(String(a[1])) ? 1 : 0;
      case 'contem texto': return String(a[0]).includes(String(a[1])) ? 1 : 0;
      case 'tamanho da lista': { const key=String(a[0]??''); const l=Object.prototype.hasOwnProperty.call(runtime.lists||{},key)?runtime.lists[key]:(Array.isArray(a[0])?a[0]:String(a[0]||'').split(',').filter(Boolean)); return Array.isArray(l)?l.length:0; }
      case 'item da lista': { const key=String(a[0]??''); const l=Object.prototype.hasOwnProperty.call(runtime.lists||{},key)?runtime.lists[key]:(Array.isArray(a[0])?a[0]:String(a[0]||'').split(',')); const i=Math.floor(Number(a[1])||1); return i<1||i>l.length?'':l[i-1]; }
      case 'lista contem': { const key=String(a[0]??''); const l=Object.prototype.hasOwnProperty.call(runtime.lists||{},key)?runtime.lists[key]:(Array.isArray(a[0])?a[0]:String(a[0]||'').split(',')); return l.map(String).includes(String(a[1]))?1:0; }
      case 'indice de': { const key=String(a[0]??''); const l=Object.prototype.hasOwnProperty.call(runtime.lists||{},key)?runtime.lists[key]:(Array.isArray(a[0])?a[0]:String(a[0]||'').split(',')); return l.map(String).indexOf(String(a[1]))+1; }
      case 'primeiro item': { const l=Array.isArray(a[0])?a[0]:String(a[0]||'').split(','); return l[0] ?? ''; }
      case 'ultimo item': { const l=Array.isArray(a[0])?a[0]:String(a[0]||'').split(','); return l[l.length-1] ?? ''; }
      case 'lista vazia': { const l=Array.isArray(a[0])?a[0]:String(a[0]||'').split(',').filter(Boolean); return l.length===0?1:0; }
      case 'contar item': { const l=Array.isArray(a[0])?a[0]:String(a[0]||'').split(','); return l.map(String).filter(v=>v===String(a[1])).length; }
      case 'rgb para hex': { const r=Math.max(0,Math.min(255,Number(a[0])||0)).toString(16).padStart(2,'0'); const g=Math.max(0,Math.min(255,Number(a[1])||0)).toString(16).padStart(2,'0'); const b=Math.max(0,Math.min(255,Number(a[2])||0)).toString(16).padStart(2,'0'); return '#'+r+g+b; }
      case 'hex para vermelho': case 'hex para verde': case 'hex para azul': { const h=String(a[0]||'#000').replace('#','').padEnd(6,'0'), idx=n==='hex para vermelho'?0:n==='hex para verde'?2:4; return parseInt(h.slice(idx,idx+2),16)||0; }
      case 'misturar cores': { const h1=String(a[0]||'#000').replace('#','').padEnd(6,'0'),h2=String(a[1]||'#000').replace('#','').padEnd(6,'0'),t=Math.max(0,Math.min(1,Number(a[2])||0.5)); const c=i=>Math.round(parseInt(h1.slice(i,i+2),16)*(1-t)+parseInt(h2.slice(i,i+2),16)*t).toString(16).padStart(2,'0'); return '#'+c(0)+c(2)+c(4); }
      case 'milissegundo': return runtimeDate().getMilliseconds();
      case 'ano': return runtimeDate().getFullYear();
      case 'mes': return runtimeDate().getMonth() + 1;
      case 'dia': return runtimeDate().getDate();
      case 'dia da semana': return runtimeDate().getDay();
      case 'timestamp': return runtimeNow();
      case 'data atual': return runtimeDate().toLocaleDateString();
      case 'hora atual': return runtimeDate().toLocaleTimeString();
      case 'entre': return (x >= Number(a[1]) && x <= Number(a[2])) ? 1 : 0;
      case 'nao': case 'não': return x ? 0 : 1;
      case 'e': return a.every(v => !!v) ? 1 : 0;
      case 'ou': return a.some(v => !!v) ? 1 : 0;
      case 'distancia': case 'distância': {
        const dx = x - (Number(a[1])||0), dy = (Number(a[2])||0) - (Number(a[3])||0);
        return Math.hypot(dx, dy);
      }
      case 'distancia x': case 'distância x': case 'distancia_x': return Math.abs(x - (Number(a[1])||0));
      case 'distancia y': case 'distância y': case 'distancia_y': return Math.abs(x - (Number(a[1])||0));
      case 'sinal': return x === 0 ? 0 : x > 0 ? 1 : -1;
      case 'clamp': return Math.min(Number(a[2])||0, Math.max(Number(a[1])||0, x));
      case 'valor': case 'valor da variavel': case 'valor da variável': case 'variavel': case 'variável': {
        const key = String(a[0] == null ? '' : a[0]);
        if (Object.prototype.hasOwnProperty.call((ctx && ctx.vars) || {}, key)) return ctx.vars[key];
        if (Object.prototype.hasOwnProperty.call((ctx && ctx.globals) || {}, key)) return ctx.globals[key];
        const nv = formulaNormalizeName(key);
        for (const k of Object.keys((ctx && ctx.vars) || {})) if (formulaNormalizeName(k) === nv) return ctx.vars[k];
        for (const k of Object.keys((ctx && ctx.globals) || {})) if (formulaNormalizeName(k) === nv) return ctx.globals[k];
        return 0;
      }
      case 'contem': case 'contém': return String(a[0] == null ? '' : a[0]).includes(String(a[1] == null ? '' : a[1])) ? 1 : 0;
      case 'comeca com': case 'começa com': return String(a[0] == null ? '' : a[0]).startsWith(String(a[1] == null ? '' : a[1])) ? 1 : 0;
      case 'termina com': return String(a[0] == null ? '' : a[0]).endsWith(String(a[1] == null ? '' : a[1])) ? 1 : 0;
      case 'maiusculas': case 'maiúsculas': return String(a[0] == null ? '' : a[0]).toUpperCase();
      case 'minusculas': case 'minúsculas': return String(a[0] == null ? '' : a[0]).toLowerCase();
      case 'substituir': return String(a[0] == null ? '' : a[0]).split(String(a[1] == null ? '' : a[1])).join(String(a[2] == null ? '' : a[2]));
      case 'recortar': return String(a[0] == null ? '' : a[0]).slice(Math.max(0, Number(a[1]) || 0), Math.max(0, Number(a[2]) || String(a[0] == null ? '' : a[0]).length));
      case 'tempo em fps': return Number(runtime.fps) || 0;
      case 'fps': return Number(runtime.fps) || 0;
      case 'objetos': return (runtime.actors || []).length;
      case 'largura da tela': return Number((runtime.stageEl && runtime.stageEl._stageW) || 0);
      case 'altura da tela': return Number((runtime.stageEl && runtime.stageEl._stageH) || 0);
      case 'agora': return runtimeNow();
      case 'segundos': return Math.floor(runtimeNow() / 1000);
      case 'milissegundos': return runtimeNow();
      case 'se': return a[0] ? (a.length > 1 ? a[1] : 1) : (a.length > 2 ? a[2] : 0);
      case 'pi': return Math.PI;
      case 'aleatorio inteiro': case 'aleatório inteiro': case 'aleatorio_inteiro': {
        const min = Math.ceil(Number(a[0])||0), max = Math.floor(Number(a[1])||0);
        return Math.floor(runtimeRandom()*(max-min+1))+min;
      }
      default: return undefined;
    }
  }

  function encodeFormulaWords(source) {
    const phrases = [
      ['posicao x da camera','__camera_x'],['posição x da câmera','__camera_x'],
      ['posicao y da camera','__camera_y'],['posição y da câmera','__camera_y'],
      ['zoom da camera','__camera_zoom'],['zoom da câmera','__camera_zoom'],
      ['rotacao da camera','__camera_rot'],['rotação da câmera','__camera_rot'],
      ['centro x da camera','__camera_center_x'],['centro x da câmera','__camera_center_x'],
      ['centro y da camera','__camera_center_y'],['centro y da câmera','__camera_center_y'],
      ['largura da tela','__screen_w'],['altura da tela','__screen_h'],
      ['tela esta tocada','__touch_down'],['tela está tocada','__touch_down'],
      ['valor toque x','__touch_x'],['valor toque y','__touch_y'],
      ['toque x','__touch_x'],['toque y','__touch_y'],
      ['posicao x','__actor_x'],['posição x','__actor_x'],
      ['posicao y','__actor_y'],['posição y','__actor_y'],
      ['nome da aparencia','__look_name'],['nome da aparência','__look_name'],
      ['aparencia atual','__look_index'],['aparência atual','__look_index'],
      ['esta tocando objeto','__touching_obj'],['está tocando objeto','__touching_obj'],
      ['tocando na borda','__edge'],['distancia ate','__distance'],['distância até','__distance'],
      ['velocidade x','__vx'],['velocidade y','__vy'],
      ['tempo de jogo','__elapsed'],['tempo decorrido','__elapsed'],
      ['tempo ms','__elapsed_ms'],['tempo em ms','__elapsed_ms'],
      ['fps atual','__fps'],['fps da engine','__fps'],['valor do fps','__fps'],['bateria','bateria'],['acelerometro x','acelerometro_x'],['acelerômetro x','acelerometro_x'],['acelerometro y','acelerometro_y'],['acelerômetro y','acelerometro_y'],['acelerometro z','acelerometro_z'],['acelerômetro z','acelerometro_z'],['giroscopio alpha','giroscopio_alpha'],['giroscópio alpha','giroscopio_alpha'],['giroscopio beta','giroscopio_beta'],['giroscópio beta','giroscopio_beta'],['giroscopio gamma','giroscopio_gamma'],['giroscópio gamma','giroscopio_gamma'],['gps latitude','gps_latitude'],['gps longitude','gps_longitude'],['gps precisao','gps_precisao'],['gps precisão','gps_precisao'],
      ['para numero','para_numero'],['para número','para_numero'],
      ['para texto','para_texto'],['aleatorio inteiro','aleatorio_inteiro'],['aleatório inteiro','aleatorio_inteiro'],
      ['distancia x','distancia_x'],['distância x','distancia_x'],['distancia y','distancia_y'],['distância y','distancia_y']
    ].sort((a,b)=>b[0].length-a[0].length);
    let s=String(source==null?'':source);
    let out=''; let buf=''; let quote='';
    const flush=()=>{
      let z=buf;
      for(const [from,to] of phrases) z=z.replace(new RegExp('(^|[^A-Za-zÀ-ÿ0-9_])'+from.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'(?=$|[^A-Za-zÀ-ÿ0-9_])','gi'), '$1'+to);
      out+=z; buf='';
    };
    for(let i=0;i<s.length;i++){
      const c=s[i];
      if(c==='\\' && quote && i+1<s.length){buf+=c+s[++i];continue;}
      if(c==='"' || c==="'"){
        if(!quote) { flush(); quote=c; out+=c; }
        else if(quote===c) { out+=buf; buf=''; out+=c; quote=''; }
        else buf+=c;
      } else if(quote) buf+=c; else buf+=c;
    }
    if(quote) out+=buf; else flush();
    return out;
  }

  function tokenizeFormula(source) {
    const out = [];
    const s = String(source == null ? '' : source);
    let i = 0;
    while (i < s.length) {
      const c = s[i];
      if (/\s/.test(c)) { i++; continue; }
      if (c === '"' || c === "'") {
        const q = c; let j = i + 1; let val = '';
        while (j < s.length) {
          if (s[j] === '\\' && j + 1 < s.length) { val += s[j+1]; j += 2; continue; }
          if (s[j] === q) break;
          val += s[j++];
        }
        out.push({t:'str', v:val}); i = Math.min(s.length, j + 1); continue;
      }
      const two = s.slice(i, i+2);
      const three = s.slice(i, i+3);
      if (['>=','<=','!=','==','&&','||'].includes(two)) { out.push({t:'op',v:two}); i+=2; continue; }
      if (['≠','≥','≤','×','÷','^','+','-','*','/','%','=','>','<','(',')',',','!'].includes(c)) { out.push({t:(c==='('||c===')'||c===',')?c:'op',v:c}); i++; continue; }
      const num = s.slice(i).match(/^(?:\d+(?:\.\d*)?|\.\d+)/);
      if (num) { out.push({t:'num',v:Number(num[0])}); i+=num[0].length; continue; }
      const id = s.slice(i).match(/^[A-Za-zÀ-ÿ_][A-Za-zÀ-ÿ0-9_]*/);
      if (id) { out.push({t:'id',v:id[0]}); i+=id[0].length; continue; }
      i++;
    }
    return out;
  }

  function evalFormulaParser(source, ctx) {
    const tokens = tokenizeFormula(encodeFormulaWords(source));
    let pos = 0;
    const peek = () => tokens[pos];
    const take = () => tokens[pos++];
    const match = (v) => { if (peek() && peek().t !== 'str' && peek().v === v) { pos++; return true; } return false; };
    const primary = () => {
      const t = take();
      if (!t) return 0;
      if (t.t === 'num' || t.t === 'str') return t.v;
      if (t.v === '(') { const v = orExpr(); match(')'); return v; }
      if (t.t === 'id') {
        // Function names may contain spaces (e.g. "tamanho da lista", "log base").
        // Choose the longest consecutive identifier sequence immediately followed by `(`.
        let name = t.v;
        let end = pos;
        let candidate = name;
        while (tokens[end] && tokens[end].t === 'id') {
          candidate += ' ' + tokens[end].v;
          end++;
          if (tokens[end] && tokens[end].t === '(') { name = candidate; pos = end; break; }
        }
        if (match('(')) {
          const args=[]; if (!match(')')) { do { args.push(orExpr()); } while (match(',')); match(')'); }
          const v = formulaFn(name,args,ctx); return v === undefined ? 0 : v;
        }
        const v = formulaLookup(name,ctx);
        return v === undefined ? name : v;
      }
      return 0;
    };
    const unary = () => {
      if (match('+')) return Number(unary()) || 0;
      if (match('-')) return -(Number(unary()) || 0);
      if (match('!')) return unary() ? 0 : 1;
      if (peek() && peek().t === 'id' && ['nao','não'].includes(formulaNormalizeName(peek().v))) { take(); return unary() ? 0 : 1; }
      return primary();
    };
    const power = () => {
      const left = unary();
      if (!match('^')) return left;
      const right = power(); // right-associative exponentiation
      const a = Number(left), b = Number(right);
      if (!Number.isFinite(a) || !Number.isFinite(b)) { runtimeDiagnostic('FORMULA_TYPE', 'Potência recebeu operando não finito.', ctx?.diagnosticSource || {}); return 0; }
      const v = Math.pow(a, b);
      if (!Number.isFinite(v)) { runtimeDiagnostic('FORMULA_OVERFLOW', 'Resultado numérico fora do intervalo finito.', ctx?.diagnosticSource || {}); return 0; }
      return v;
    };
    const mul = () => {
      let v = power();
      while (peek() && ['*','/','×','÷','%'].includes(peek().v)) {
        const op = take().v, b = power();
        if (op === '*' || op === '×') v = (Number(v) || 0) * (Number(b) || 0);
        else if (op === '/' || op === '÷') {
          const den = Number(b);
          if (!Number.isFinite(den) || den === 0) { runtimeDiagnostic('FORMULA_DIV_ZERO', 'Divisão por zero ou denominador inválido.', ctx?.diagnosticSource || {}); v = 0; }
          else v = Number(v) / den;
        } else {
          const den = Number(b);
          if (!Number.isFinite(den) || den === 0) { runtimeDiagnostic('FORMULA_DIV_ZERO', 'Módulo por zero ou denominador inválido.', ctx?.diagnosticSource || {}); v = 0; }
          else v = Number(v) % den;
        }
        if (typeof v === 'number' && !Number.isFinite(v)) { runtimeDiagnostic('FORMULA_OVERFLOW', 'Resultado numérico fora do intervalo finito.', ctx?.diagnosticSource || {}); v = 0; }
      }
      return v;
    };
    const add = () => {
      let v = mul();
      while (peek() && ['+','-'].includes(peek().v)) {
        const op = take().v, b = mul();
        if (op === '+' && (typeof v === 'string' || typeof b === 'string')) v = String(v) + String(b);
        else v = op === '+' ? (Number(v) || 0) + (Number(b) || 0) : (Number(v) || 0) - (Number(b) || 0);
        if (typeof v === 'number' && !Number.isFinite(v)) { runtimeDiagnostic('FORMULA_OVERFLOW', 'Resultado numérico fora do intervalo finito.', ctx?.diagnosticSource || {}); v = 0; }
      }
      return v;
    };
    const compare = () => {
      let v = add();
      while (peek() && ['=','==','!=','≠','>','<','≥','≤','>=','<='].includes(peek().v)) {
        const op = take().v, b = add(); let r = false;
        switch(op) {
          case '=': case '==': r = String(v) === String(b); break;
          case '!=': case '≠': r = String(v) !== String(b); break;
          case '>': r = Number(v) > Number(b); break;
          case '<': r = Number(v) < Number(b); break;
          case '≥': case '>=': r = Number(v) >= Number(b); break;
          case '≤': case '<=': r = Number(v) <= Number(b); break;
        }
        v = r ? 1 : 0;
      }
      return v;
    };
    const andExpr = () => {
      let v = compare();
      while (peek() && (peek().v === '&&' || formulaNormalizeName(peek().v) === 'e')) { take(); const b = compare(); v = (v && b) ? 1 : 0; }
      return v;
    };
    const orExpr = () => {
      let v = andExpr();
      while (peek() && (peek().v === '||' || formulaNormalizeName(peek().v) === 'ou')) { take(); const b = andExpr(); v = (v || b) ? 1 : 0; }
      return v;
    };
    const result = orExpr();
    if (pos < tokens.length) runtimeDiagnostic('FORMULA_PARSE', `Tokens inesperados após posição ${pos}.`, ctx?.diagnosticSource || {});
    return result;
  }

  function evalExpr(expr, ctx) {
    try {
      if (expr === null || expr === undefined || expr === '') return 0;
      if (typeof expr === 'number' || typeof expr === 'boolean') return expr;
      const fullCtx = ctx || {};
      const v = evalFormulaParser(String(expr), fullCtx);
      if (v === undefined) { runtimeDiagnostic('FORMULA_UNDEFINED', 'Fórmula sem valor.', fullCtx.diagnosticSource || {}); return 0; }
      if (typeof v === 'number' && !Number.isFinite(v)) { runtimeDiagnostic('FORMULA_NON_FINITE', 'Fórmula produziu NaN/Infinity.', fullCtx.diagnosticSource || {}); return 0; }
      return v;
    } catch (e) {
      console.warn('[Kix formula]', expr, e);
      return 0;
    }
  }

  function param(blk, key, def, ctx) {
    const v = (blk.values && (blk.values[key] !== undefined)) ? blk.values[key]
      : (blk.params && Array.isArray(blk.params) && blk.params.some(p => (typeof p === 'object' ? p.name : p) === key) ? (blk.values && blk.values[key]) : undefined);
    if (v === undefined || v === null) return def;
    return evalExpr(v, ctx);
  }

  /** String param: never collapse unknown names to 0 */
  function paramStr(blk, key, def, ctx) {
    let raw;
    if (blk.values && blk.values[key] !== undefined && blk.values[key] !== null && blk.values[key] !== '') {
      raw = blk.values[key];
    } else if (blk.params && Array.isArray(blk.params)) {
      const p = blk.params.find(x => (typeof x === 'object' ? x.name : x) === key);
      if (p && typeof p === 'object' && p.default != null) raw = p.default;
    }
    if (raw === undefined || raw === null || raw === '') return def != null ? String(def) : '';
    let s = String(raw).trim();
    if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) {
      s = s.slice(1, -1);
    }
    // If looks like a pure number and key is nome/pasta, still allow numeric folder names
    return s;
  }

  // ---- Runtime ----
  // Runtime-owned asynchronous work is routed through KixLifecycle when Phase 2
  // is available. The native fallback preserves standalone-engine compatibility.
  const kixRuntimeTimerScope = 'runtime';
  function kixSetTimeout(fn, ms) {
    const l = global.KixLifecycle;
    return l?.setTimeout ? l.setTimeout(fn, ms, kixRuntimeTimerScope, {owner:'engine'}) : window.setTimeout(fn, ms);
  }
  function kixSetInterval(fn, ms) {
    const l = global.KixLifecycle;
    return l?.setInterval ? l.setInterval(fn, ms, kixRuntimeTimerScope, {owner:'engine'}) : window.setInterval(fn, ms);
  }
  function kixRequestAnimationFrame(fn) {
    const l = global.KixLifecycle;
    if (l?.requestAnimationFrame) return l.requestAnimationFrame(fn, kixRuntimeTimerScope, {owner:'engine'});
    return typeof window.requestAnimationFrame === 'function' ? window.requestAnimationFrame(fn) : window.setTimeout(() => fn(performance.now()), 16);
  }
  function kixClearTimer(id) {
    const l = global.KixLifecycle;
    if (l?.clear && l.clear(id, kixRuntimeTimerScope)) return true;
    try { window.clearTimeout(id); window.clearInterval(id); window.cancelAnimationFrame?.(id); } catch (_) {}
    return false;
  }
  function kixClearScope() {
    try { global.KixLifecycle?.clearScope?.(kixRuntimeTimerScope); } catch (_) {}
  }

  const runtime = {
    running: false,
    paused: false,
    actors: [], // runtime actor state
    coroutines: [],
    messages: [],
    sounds: [],
    previewAudio: null,
    globals: {},
    stageEl: null,
    // Catrobat world invariant: physical viewport changes must never mutate logical
    // actor coordinates, size, or camera scale while a project is running.
    _playViewportLocked: false,
    _playLockedStageW: 0,
    _playLockedStageH: 0,
    _playLockedWorldScale: 1,
    _playLockedLogicalW: 0,
    _playLockedLogicalH: 0,
    _playLockedPresentationOrientation: '',
    _lastViewportWidth: 0,
    _lastViewportHeight: 0,
    _orientationGuardInstalled: false,
    _stagePresentationOrientation: '',
    initialSnapshots: [],
    touch: { x: 0, y: 0, down: false, active: false, lastFingerIndex: 0, targetActorId: null, targetActorIndex: -1 },
    colorTolerance: 40,
    multiTapWindow: 600, // ms between taps to count as consecutive
    soundVolume: 1,
    soundPitch: 1,
    soundLoop: false,
    speechLang: 'pt-BR',
    lists: {},
    varVisible: {},
    _dirty: true,
    _frame: 0,
    raf: null,
    lastTs: 0,
    network: { ws:null, wsStatus:'closed', lastMessage:'', lastError:'', tcp:null, tcpStatus:'closed', udpStatus:'closed', lastUDP:'', inputs:{}, outputs:{}, timeout:5000, firebase:{config:null, status:'disconnected', token:null, uid:null, path:'', error:'', listeners:{}} },
    // Free camera changes only world/camera transform; never screen orientation.
    freeCam: false,
    debugCollisions: false,
    fps: 0,
    frameMs: 16.67,
    elapsedMs: 0,
    elapsedSeconds: 0,
    showFps: false,
    _collisionBounds: [],
    _collisionBoundsFrame: -1,
    _collisionDebugEls: new Map(),
    _collisionDebugFrame: -1,
    _stageInner: null,
    _hudParent: null,
    _controlsParent: null,
    _collisionGrid: new Map(),
    _collisionCandidates: new Set(),
    _collisionLargeIndices: []
  };

  
  function netSetVar(co, key, value) { try { deviceSetVar(co, key, value); } catch (_) { runtime.globals[key] = value; } }
  function netEndpoint(raw) { return String(raw == null ? '' : raw).trim().replace(/^['"]|['"]$/g,''); }
  function netSendWs(data) {
    const ws=runtime.network.ws;
    if(ws && ws.readyState===1) { try { ws.send(typeof data==='string'?data:JSON.stringify(data)); return true; } catch(e){ runtime.network.lastError=String(e); } }
    return false;
  }
  function netOpenWs(url) {
    try {
      if(runtime.network.ws) try{runtime.network.ws.close();}catch(_){}
      if(!global.WebSocket) throw new Error('WebSocket indisponível neste ambiente');
      const ws=new WebSocket(url); runtime.network.ws=ws; runtime.network.wsStatus='connecting';
      ws.onopen=()=>{runtime.network.wsStatus='open'; runtime.network.lastError='';};
      ws.onmessage=e=>{runtime.network.lastMessage=typeof e.data==='string'?e.data:String(e.data); runtime.network.inputs.websocket=runtime.network.lastMessage;};
      ws.onerror=e=>{runtime.network.wsStatus='error'; runtime.network.lastError='WebSocket error';};
      ws.onclose=()=>{runtime.network.wsStatus='closed';};
      return true;
    } catch(e){ runtime.network.wsStatus='error'; runtime.network.lastError=String(e&&e.message||e); return false; }
  }

  // ===== FIREBASE REST MULTIPLAYER =====
  function fbClean(v){ return String(v == null ? '' : v).trim().replace(/^['"]|['"]$/g,''); }
  function fbCfg(){ return runtime.network.firebase.config || {}; }
  function fbBase(){ const c=fbCfg(); return fbClean(c.databaseURL || (c.projectId ? ('https://' + fbClean(c.projectId) + '-default-rtdb.firebaseio.com') : '')); }
  function fbPath(path){ const base=fbBase(); let p=fbClean(path || runtime.network.firebase.path || '').replace(/^\/+|\/+$/g,''); return base ? base + (p ? '/' + p : '') + '.json' : ''; }
  function fbSetStatus(status,error){ runtime.network.firebase.status=status; if(error) runtime.network.firebase.error=String(error.message||error); }
  async function fbFetch(path, opts){ const url=fbPath(path); if(!url) throw new Error('Configure o Firebase primeiro'); const o=Object.assign({},opts||{}); const token=runtime.network.firebase.token; if(token) o.urlParams=true; let final=url; if(token) final += '?auth='+encodeURIComponent(token); const res=await fetch(final,o); const text=await res.text(); let data=null; try{data=text?JSON.parse(text):null;}catch(_){data=text;} if(!res.ok) throw new Error((data&&data.error)||('Firebase HTTP '+res.status)); return data; }
  async function fbAuth(endpoint,body){ const c=fbCfg(); const key=fbClean(c.apiKey); if(!key) throw new Error('apiKey do Firebase não configurada'); const res=await fetch('https://identitytoolkit.googleapis.com/v1/accounts:'+endpoint+'?key='+encodeURIComponent(key),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}); const data=await res.json().catch(()=>({})); if(!res.ok) throw new Error(data?.error?.message||'Falha na autenticação Firebase'); runtime.network.firebase.token=data.idToken||null; runtime.network.firebase.uid=data.localId||null; fbSetStatus('connected'); return data; }
  function fbStore(co,key,val){ try{netSetVar(co,key,val);}catch(_){} }
  function fbDataValue(raw){ if(typeof raw!=='string') return raw; const t=raw.trim(); if(!t) return ''; try{return JSON.parse(t);}catch(_){return fbClean(t);} }
  function fbRoomPath(room, suffix){ const root=fbClean(runtime.network.firebase.path||'salas'); const r=fbClean(room); const s=fbClean(suffix||''); return [root,r,s].filter(Boolean).join('/'); }

  function resolveSound(actorData, nameOrIdx) {
    const sounds = (actorData && actorData.sounds) || [];
    if (!sounds.length) return null;
    const key = String(nameOrIdx == null ? '' : nameOrIdx).replace(/^['"]|['"]$/g, '').trim();
    if (!key) return sounds[0];
    // by index (1-based)
    const n = Number(key);
    if (!isNaN(n) && n >= 1 && n <= sounds.length) return sounds[n - 1];
    // by name
    let s = sounds.find(x => x && String(x.name) === key);
    if (!s) s = sounds.find(x => x && String(x.name).toLowerCase() === key.toLowerCase());
    if (!s) s = sounds.find(x => x && String(x.name).toLowerCase().includes(key.toLowerCase()));
    return s || sounds[0];
  }

  function stopPreviewSound() {
    const audio = runtime.previewAudio;
    runtime.previewAudio = null;
    if (!audio) return;
    try { audio.pause(); } catch (_) {}
    try { audio.currentTime = 0; } catch (_) {}
  }

  function previewSound(entry) {
    stopPreviewSound();
    if (!entry || !entry.data) return Promise.reject(new Error('Áudio sem dados para pré-visualização'));
    let audio;
    try {
      audio = new Audio(entry.data);
      audio.preload = 'auto';
      audio.volume = Math.max(0, Math.min(1, runtime.soundVolume != null ? runtime.soundVolume : 1));
      try { audio.playbackRate = Math.max(0.25, Math.min(4, runtime.soundPitch != null ? runtime.soundPitch : 1)); } catch (_) {}
      audio.loop = false;
      runtime.previewAudio = audio;
      const clear = () => {
        if (runtime.previewAudio === audio) runtime.previewAudio = null;
        try { audio.pause(); } catch (_) {}
      };
      audio.addEventListener('ended', clear, { once: true });
      audio.addEventListener('error', clear, { once: true });
      const playResult = audio.play();
      if (!playResult || typeof playResult.then !== 'function') return Promise.resolve(audio);
      return playResult.then(() => audio).catch(err => { clear(); throw err; });
    } catch (e) {
      runtime.previewAudio = null;
      console.warn('[Kix] audio preview', e);
      return Promise.reject(e);
    }
  }

  function playSoundEntry(entry, opts) {
    if (!entry || !entry.data) return null;
    try {
      const audio = new Audio(entry.data);
      audio.preload = 'auto';
      audio.volume = Math.max(0, Math.min(1, runtime.soundVolume != null ? runtime.soundVolume : 1));
      try { audio.playbackRate = Math.max(0.25, Math.min(4, runtime.soundPitch != null ? runtime.soundPitch : 1)); } catch (_) {}
      audio.loop = !!(opts && opts.loop != null ? opts.loop : runtime.soundLoop);
      const p = audio.play();
      audio._kixPlayPromise = p || null;
      audio._kixSoundName = String(entry.name || '');
      runtime.sounds = Array.isArray(runtime.sounds) ? runtime.sounds : [];
      runtime.sounds.push(audio);
      const cleanup = () => { runtime.sounds = (runtime.sounds || []).filter(a => a !== audio); };
      if (p && typeof p.catch === 'function') p.catch(err => {
        audio._kixPlayError = err || new Error('Falha ao iniciar áudio');
        cleanup();
        try { audio.pause(); } catch (_) {}
      });
      audio.addEventListener('ended', () => {
        cleanup();
        try { runtime.actors.forEach(ra => startHatsFor(ra, 'Quando som terminar')); } catch (_) {}
      }, { once: true });
      audio.addEventListener('error', cleanup, { once: true });
      return audio;
    } catch (e) {
      console.warn('playSound', e);
      return null;
    }
  }

  const LEGACY_SOUND_IDS = Object.freeze({
    'tocar som':'sound.start','start sound':'sound.start',
    'tocar som e esperar terminar':'sound.start_wait','start sound and wait':'sound.start_wait',
    'parar todos os sons':'sound.stop_all','stop all sounds':'sound.stop_all',
    'parar este som':'sound.stop','stop sound':'sound.stop',
    'mudar volume em':'sound.change_volume','change volume by':'sound.change_volume',
    'definir volume para':'sound.set_volume','set volume to':'sound.set_volume',
    'tocar som com volume':'kix.sound.play_volume',
    'pausar som':'kix.sound.pause_all','pause sound':'kix.sound.pause_all',
    'retomar som':'kix.sound.resume_all','resume sound':'kix.sound.resume_all',
    'pausar todos os sons':'kix.sound.pause_all','pause all sounds':'kix.sound.pause_all',
    'retomar todos os sons':'kix.sound.resume_all','resume all sounds':'kix.sound.resume_all',
    'mudar tom pitch em':'kix.sound.change_pitch','change pitch by':'kix.sound.change_pitch',
    'definir tom para':'kix.sound.set_pitch','set pitch to':'kix.sound.set_pitch',
    'definir loop do som':'kix.sound.set_loop','set sound loop':'kix.sound.set_loop',
    'falar texto para voz':'kix.sound.speak','speak text':'kix.sound.speak',
    'falar e esperar':'kix.sound.speak_wait','speak and wait':'kix.sound.speak_wait',
    'definir idioma da fala':'kix.sound.set_speech_lang','set speech language':'kix.sound.set_speech_lang',
    'crossfade':'kix.sound.crossfade',
    'definir canal':'kix.sound.set_channel','set audio channel':'kix.sound.set_channel',
    'quando som terminar':'kix.sound.when_ended','when sound ends':'kix.sound.when_ended',
    'fade out em':'kix.sound.fade_out','fade in em':'kix.sound.fade_in'
  });

  function normalizeSoundName(value) {
    return String(value == null ? '' : value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[.……]/g,'').replace(/[^a-z0-9]+/g,' ').trim();
  }

  function soundCompatIdForBlock(blk, name) {
    const existing = String(catCompatId(blk) || '').toLowerCase();
    if (existing && (existing.indexOf('sound.') === 0 || existing.indexOf('kix.sound.') === 0)) return existing;
    return LEGACY_SOUND_IDS[normalizeSoundName(name)] || '';
  }

  function executeSoundBlock(co, blk, ctx, now) {
    if (!co || !blk) return false;
    const name = canonicalBlockName(blk.name || blk.legacyName || '');
    const id = soundCompatIdForBlock(blk, name);
    if (!id) return false;
    const getString = (keys, fallback='') => {
      for (const key of keys) {
        const v = paramStr(blk, key, undefined, ctx);
        if (v !== undefined && v !== null && v !== '') return v;
      }
      return fallback;
    };
    const stopAllSounds = () => {
      (runtime.sounds || []).forEach(a => { try { a.pause(); a.currentTime = 0; } catch (_) {} });
      runtime.sounds = [];
      try { if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (_) {}
    };
    if (id === 'sound.start') {
      playSoundEntry(resolveSound(co.actor.data, getString(['som','sound'],'')), {loop:runtime.soundLoop}); return true;
    }
    if (id === 'sound.start_wait') {
      const audio = playSoundEntry(resolveSound(co.actor.data, getString(['som','sound'],'')), {loop:false});
      if (!audio) return true;
      const resume = () => { co.waitUntil = 0; };
      audio.addEventListener('ended', resume, {once:true});
      if (audio._kixPlayPromise && typeof audio._kixPlayPromise.catch === 'function') audio._kixPlayPromise.catch(resume);
      co.ip = blk.next || null;
      co.waitUntil = now + 120000;
      return {yield:true,handled:true};
    }
    if (id === 'sound.stop_all') { stopAllSounds(); stopPreviewSound(); return true; }
    if (id === 'sound.stop') {
      const key = getString(['som','sound'],'').replace(/^['"]|['"]$/g,'').toLowerCase();
      const exact = key ? (runtime.sounds||[]).filter(a => String(a&&a._kixSoundName||'').toLowerCase() === key) : [];
      const targets = exact.length ? exact : ((runtime.sounds||[]).length ? [runtime.sounds[runtime.sounds.length-1]] : []);
      targets.forEach(a=>{try{a.pause();a.currentTime=0;}catch(_){}});
      runtime.sounds=(runtime.sounds||[]).filter(a=>!targets.includes(a)); return true;
    }
    if (id === 'sound.change_volume' || id === 'sound.set_volume') {
      const v = Number(param(blk, 'valor', param(blk, 'percent', id==='sound.set_volume'?100:0, ctx), ctx));
      runtime.soundVolume = id==='sound.set_volume' ? Math.max(0,Math.min(1,(isNaN(v)?100:v)/100)) : Math.max(0,Math.min(1,(runtime.soundVolume!=null?runtime.soundVolume:1)+(Number.isFinite(v)?v:0)/100));
      (runtime.sounds||[]).forEach(a=>{try{a.volume=runtime.soundVolume;}catch(_){}}); return true;
    }
    if (id === 'sound.play_note') { const beats=Math.max(.01,Number(catCompatValue(blk,['beats'],1,ctx))||1),sec=beats*catCompatBeatSeconds(); catCompatPlayTone(catCompatToneFrequency(catCompatValue(blk,['note'],'A4',ctx)),sec,'sine'); co.ip=blk.next||null; co.waitUntil=now+sec*1000; return {yield:true,handled:true}; }
    if (id === 'sound.play_drum') { const beats=Math.max(.01,Number(catCompatValue(blk,['beats'],1,ctx))||1),sec=beats*catCompatBeatSeconds(); catCompatPlayDrum(catCompatValue(blk,['drum'],'bass',ctx),Math.min(sec,.6)); co.ip=blk.next||null; co.waitUntil=now+sec*1000; return {yield:true,handled:true}; }
    if (id === 'sound.set_instrument') { catCompatEnsureState().sound.instrument=catCompatStr(blk,['instrument'],'piano',ctx); return true; }
    if (id === 'sound.change_tempo') { const c=catCompatEnsureState(); c.sound.tempo=Math.max(20,Math.min(400,(Number(c.sound.tempo)||120)+(Number(catCompatValue(blk,['bpm'],0,ctx))||0))); return true; }
    if (id === 'sound.set_tempo') { catCompatEnsureState().sound.tempo=Math.max(20,Math.min(400,Number(catCompatValue(blk,['bpm'],120,ctx))||120)); return true; }
    if (id === 'sound.pause_beats') { const sec=Math.max(.01,Number(catCompatValue(blk,['beats'],1,ctx))||1)*catCompatBeatSeconds(); co.ip=blk.next||null; co.waitUntil=now+sec*1000; return {yield:true,handled:true}; }
    if (id === 'kix.sound.pause_all') { (runtime.sounds||[]).forEach(a=>{try{a.pause();}catch(_){}}); runtime._soundsPaused=true; return true; }
    if (id === 'kix.sound.resume_all') { (runtime.sounds||[]).forEach(a=>{try{const p=a.play&&a.play();if(p&&p.catch)p.catch(()=>{});}catch(_){}}); runtime._soundsPaused=false; return true; }
    if (id === 'kix.sound.play_volume') { const a=playSoundEntry(resolveSound(co.actor.data,getString(['som','sound'],'')),{loop:runtime.soundLoop}); if(a)a.volume=Math.max(0,Math.min(1,(Number(param(blk,'volume',100,ctx))||100)/100)); return true; }
    if (id === 'kix.sound.change_pitch' || id === 'kix.sound.set_pitch') { const v=Number(param(blk,'valor',id.endsWith('set_pitch')?100:10,ctx)); runtime.soundPitch=id.endsWith('set_pitch')?Math.max(.25,Math.min(4,(isNaN(v)?100:v)/100)):Math.max(.25,Math.min(4,(runtime.soundPitch!=null?runtime.soundPitch:1)+(Number.isFinite(v)?v:0)/100)); (runtime.sounds||[]).forEach(a=>{try{a.playbackRate=runtime.soundPitch;}catch(_){}}); return true; }
    if (id === 'kix.sound.set_loop') { const raw=getString(['sim','sim/não','loop','value'],'sim').toLowerCase(); runtime.soundLoop=['sim','true','1','yes','on'].includes(raw); return true; }
    if (id === 'kix.sound.speak' || id === 'kix.sound.speak_wait') { const wait=id==='kix.sound.speak_wait'; speakText(getString(['texto','text'],''),wait,co,now); if(wait) co.ip=blk.next||null; return wait?{yield:true,handled:true}:true; }
    if (id === 'kix.sound.set_speech_lang') { runtime.speechLang=getString(['idioma','language'],'pt-BR')||'pt-BR'; return true; }
    if (id === 'kix.sound.set_channel') { co.actor.data._audioChannel=getString(['canal','channel'],'master'); return true; }
    if (id === 'kix.sound.when_ended') return true;
    if (id === 'kix.sound.crossfade') {
      const sec=Math.max(.05,Number(param(blk,'segundos',1,ctx))||1), neu=playSoundEntry(resolveSound(co.actor.data,getString(['som','sound'],'')),{loop:runtime.soundLoop}), olds=(runtime.sounds||[]).filter(a=>a!==neu).slice();
      if(neu){neu.volume=0;const steps=20;let i=0;const interval=kixSetInterval(()=>{if(!runtime.running){kixClearTimer(interval);return;}if(runtime.paused)return;i++;const t=i/steps;try{olds.forEach(a=>a.volume=Math.max(0,(runtime.soundVolume||1)*(1-t)));neu.volume=(runtime.soundVolume||1)*t;}catch(_){}if(i>=steps){kixClearTimer(interval);olds.forEach(a=>{try{a.pause();}catch(_) {}});runtime.sounds=(runtime.sounds||[]).filter(a=>a===neu||!olds.includes(a));neu.volume=runtime.soundVolume||1;}},sec*1000/steps);} return true;
    }
    if (id === 'kix.sound.fade_out' || id === 'kix.sound.fade_in') {
      const isOut=id==='kix.sound.fade_out', sec=Math.max(.05,Number(param(blk,'segundos',1,ctx))||1), sounds=runtime.sounds||[], key=isOut?'_fadeAudio':'_fadeAudioIn';
      if(!co[key]) co[key]={start:now,dur:sec*1000,starts:isOut?sounds.map(s=>s?s.volume:1):null};
      const t=Math.min(1,(now-co[key].start)/co[key].dur);
      if(!isOut && (now===co[key].start || t===0)) sounds.forEach(s=>{try{if(s){s.volume=0;const p=s.play&&s.play();if(p&&p.catch)p.catch(()=>{});}}catch(_) {}});
      sounds.forEach((s,i)=>{if(s)try{s.volume=isOut?Math.max(0,(co[key].starts[i]!=null?co[key].starts[i]:1)*(1-t)):t;}catch(_) {}});
      if(t<1){co.waitUntil=now+16;return {yield:true,handled:true};}
      if(isOut)sounds.forEach(s=>{try{s.pause();}catch(_) {}}); co[key]=null; return true;
    }
    return false;
  }

  function speakText(text, wait, co, now) {
    try {
      if (!window.speechSynthesis) return;
      const u = new SpeechSynthesisUtterance(String(text || ''));
      u.lang = runtime.speechLang || 'pt-BR';
      u.volume = Math.max(0, Math.min(1, runtime.soundVolume != null ? runtime.soundVolume : 1));
      u.rate = Math.max(0.5, Math.min(2, runtime.soundPitch != null ? runtime.soundPitch : 1));
      if (wait && co) {
        u.onend = () => { co.waitUntil = 0; };
        co.waitUntil = now + 60000; // safety
      }
      window.speechSynthesis.speak(u);
    } catch (e) { console.warn('speak', e); }
  }

  function ensureList(name) {
    const key = String(name || 'lista').replace(/^['"]|['"]$/g, '');
    if (!runtime.lists) runtime.lists = {};
    if (!Array.isArray(runtime.lists[key])) runtime.lists[key] = [];
    return runtime.lists[key];
  }

  function showVarOverlay(name, show) {
    try {
      let layer = document.getElementById('kix-var-overlay');
      if (!layer) {
        layer = document.createElement('div');
        layer.id = 'kix-var-overlay';
        layer.style.cssText = 'position:absolute;left:8px;top:8px;z-index:50;display:flex;flex-direction:column;gap:4px;pointer-events:none;';
        (runtime.stageEl || document.getElementById('play-stage') || document.body).appendChild(layer);
      }
      const id = 'kix-var-' + name;
      let el = document.getElementById(id);
      if (!show) {
        if (el) el.remove();
        return;
      }
      if (!el) {
        el = document.createElement('div');
        el.id = id;
        el.style.cssText = 'background:rgba(0,0,0,0.65);color:#fff;font-size:12px;padding:4px 8px;border-radius:6px;';
        layer.appendChild(el);
      }
      const val = runtime.globals[name];
      el.textContent = name + ' = ' + (val == null ? '' : val);
    } catch (_) {}
  }

  
  // ===== TEXT LAYER =====
  
  
  
  function resolveProjectFile(name) {
    try {
      const key = String(name || '').replace(/^['"]|['"]$/g, '').trim();
      if (!key) return null;
      const files = (runtime.project && runtime.project.files) || [];
      const norm=s=>String(s||'').replace(/\\/g,'/').replace(/^\.?\//,'').trim().toLowerCase();
      const base=s=>norm(s).split('/').pop()||'';
      const k=norm(key), kb=base(key), ks=k.replace(/\.[^.]+$/,'');
      const found = files.find(f => {
        if (!f) return false;
        const fn=norm(f.name), fp=norm(f.path), fb=base(f.name), fs=fn.replace(/\.[^.]+$/,'');
        return fn===k || fp===k || fb===kb || fs===ks;
      });
      return found || null;
    } catch (_) { return null; }
  }

  /** Load font by family name or project file; returns CSS font-family string */
  function loadTextFont(fontRef, onReady) {
    const raw = String(fontRef || '').replace(/^['"]|['"]$/g, '').trim();
    if (!raw) return 'Arial, Helvetica, sans-serif';
    // Already a CSS stack
    if (raw.indexOf(',') >= 0) return raw;
    const file = resolveProjectFile(raw);
    const fam = (file && file.name ? file.name : raw).replace(/\.[^.]+$/, '').replace(/[^a-zA-Z0-9_\- ]/g, '_') || 'KixFont';
    if (file && file.dataUrl) {
      try {
        const face = new FontFace(fam, 'url(' + file.dataUrl + ')');
        face.load().then(function (ff) {
          try { document.fonts.add(ff); } catch (_) {}
          if (typeof onReady === 'function') onReady(fam);
        }).catch(function (e) {
          console.warn('[Kix] font load fail', fam, e);
          if (typeof onReady === 'function') onReady(fam);
        });
      } catch (e) {
        console.warn('[Kix] FontFace', e);
      }
      return '"' + fam + '", Arial, sans-serif';
    }
    // System / web safe font name
    return '"' + raw + '", Arial, Helvetica, sans-serif';
  }


  
  
  function watchDeviceEvents() {
    try {
      if (!runtime.running || runtime.paused) return;
      startDeviceSensors();
      const d = ensureDeviceState();
      // --- Tilt (inclinar) ---
      // beta: front-back, gamma: left-right (degrees)
      const beta = Number(d.gyro.beta) || 0;
      const gamma = Number(d.gyro.gamma) || 0;
      const tiltThreshold = 25;
      let tiltDir = null;
      if (gamma > tiltThreshold) tiltDir = 'direita';
      else if (gamma < -tiltThreshold) tiltDir = 'esquerda';
      else if (beta > tiltThreshold) tiltDir = 'frente';
      else if (beta < -tiltThreshold) tiltDir = 'tras';
      // also accept vertical/horizontal aliases
      if (tiltDir) {
        if (!runtime._lastTilt) runtime._lastTilt = {};
        // fire once per direction until reset to neutral
        if (!runtime._lastTilt[tiltDir]) {
          runtime._lastTilt[tiltDir] = true;
          runtime.actors.forEach(function (ra) {
            startHatsForFiltered(ra, 'Quando inclinar dispositivo', tiltDir);
          });
        }
      } else {
        runtime._lastTilt = {};
      }

      // --- Shake / bater (device motion) ---
      const ax = Number(d.accel.x) || 0;
      const ay = Number(d.accel.y) || 0;
      const az = Number(d.accel.z) || 0;
      const mag = Math.sqrt(ax * ax + ay * ay + az * az);
      // at rest ~9.8; shake spikes higher
      if (mag > 18) {
        const now = performance.now();
        if (!runtime._lastShake || now - runtime._lastShake > 800) {
          runtime._lastShake = now;
          runtime.actors.forEach(function (ra) {
            startHatsFor(ra, 'Quando bater no dispositivo');
            startHatsFor(ra, 'Quando o dispositivo for sacudido');
          });
        }
      }
    } catch (e) {
      console.warn('watchDeviceEvents', e);
    }
  }

  /** Start hats matching name, optionally filtering by direction param for tilt */
  function startHatsForFiltered(ra, hatName, tiltDir) {
    try {
      if (!ra || !ra.data) return;
      let flat = ra.data.scripts;
      if (flat && flat.blocks && flat.stacks) flat = scriptsToFlat(flat);
      if (!Array.isArray(flat)) flat = [];
      try { ensureFlatLoopBoundaries(flat); } catch (_) {}
      ra.data.scripts = flat;
      const norm = function (s) {
        return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();
      };
      const want = norm(hatName);
      for (let i = 0; i < flat.length; i++) {
        const s = flat[i];
        if (!s || s.disabled) continue;
        const n = norm(s.name);
        if (!(n.includes('inclinar') || n === want || n.includes(want))) continue;
        // direction filter
        if (tiltDir) {
          const raw = (s.values && (s.values['direção'] != null ? s.values['direção'] : s.values.direcao != null ? s.values.direcao : s.values.direção)) || '';
          const dir = norm(String(raw).replace(/['"]/g, ''));
          if (dir && dir !== 'qualquer' && dir !== 'any' && dir !== '') {
            // map aliases
            const aliases = {
              direita: ['direita', 'right', 'east'],
              esquerda: ['esquerda', 'left', 'west'],
              frente: ['frente', 'forward', 'cima', 'up', 'portrait'],
              tras: ['tras', 'trás', 'back', 'baixo', 'down']
            };
            const list = aliases[tiltDir] || [tiltDir];
            if (!list.some(function (a) { return dir.includes(a); })) continue;
          }
        }
        // collect following actions until next hat
        const slice = [];
        for (let j = i + 1; j < flat.length; j++) {
          const s2 = flat[j];
          if (!s2) continue;
          const n2 = norm(s2.name);
          if (n2.startsWith('quando ')) break;
          slice.push(s2);
        }
        if (!slice.length) continue;
        runtime.coroutines.push({
          actor: ra,
          flatMode: true,
          flatBlocks: slice,
          flatIndex: 0,
          waitUntil: 0,
          dead: false,
          loopStack: [],
          blocks: {},
          ip: null,
          tree: null
        });
      }
    } catch (e) {
      console.warn('startHatsForFiltered', e);
    }
  }


  
  
  
  function applyEngineCamera() {
    try {
      // Host camera owns the transform while free-camera mode is active.
      // Always normalize camera state first, even when there is no DOM stage (tests/headless).
      const zMin = Math.max(0.01, Number(runtime.camZoomMin != null ? runtime.camZoomMin : 0.25) || 0.25);
      const zMax = Math.max(zMin, Number(runtime.camZoomMax != null ? runtime.camZoomMax : 4) || 4);
      runtime.camZoom = Math.max(zMin, Math.min(zMax, Number(runtime.camZoom) || 1));
      if (runtime.freeCam) return;

      const stage = runtime.stageEl || document.getElementById('play-stage');
      if (!stage) return;
      let x = Number(runtime.camX) || 0;
      let y = Number(runtime.camY) || 0;
      let z = runtime.camZoom;
      let rot = Number(runtime.camRot) || 0;
      const offX = Number(runtime.camOffsetX) || 0;
      const offY = Number(runtime.camOffsetY) || 0;
      const smooth = runtime.camSmooth != null ? Number(runtime.camSmooth) : 1;

      // follow with deadzone + axis lock + look-ahead
      if (runtime._camFollow && runtime._camFollow.data) {
        const td = runtime._camFollow.data;
        let tx = -(Number(td.x) || 0) - offX;
        let ty = (Number(td.y) || 0) + offY;
        // look-ahead
        if (runtime.camLookAhead) {
          const dir = (Number(td.direction) || 90) * Math.PI / 180;
          const la = Number(runtime.camLookAhead) || 0;
          tx -= Math.cos(dir) * la;
          ty += Math.sin(dir) * la;
        }
        // deadzone
        const dzW = Number(runtime.camDeadW) || 0;
        const dzH = Number(runtime.camDeadH) || 0;
        if (dzW > 0 || dzH > 0) {
          const dx = tx - x;
          const dy = ty - y;
          if (Math.abs(dx) > dzW) x = tx - Math.sign(dx) * dzW;
          if (Math.abs(dy) > dzH) y = ty - Math.sign(dy) * dzH;
        } else {
          // smooth lerp
          if (smooth < 1 && smooth > 0) {
            x = x + (tx - x) * smooth;
            y = y + (ty - y) * smooth;
          } else {
            x = tx; y = ty;
          }
        }
        const lock = runtime.camAxisLock || '';
        if (lock === 'x' || lock === 'X') x = Number(runtime.camX) || 0;
        if (lock === 'y' || lock === 'Y') y = Number(runtime.camY) || 0;
        runtime.camX = x;
        runtime.camY = y;
      }

      // Follow the live touch point when requested. This makes the helper block useful
      // on its own without requiring a separate follow target.
      if (runtime._camFollowTouch) {
        const tx = -Number(runtime.touch && runtime.touch.x || 0) - offX;
        const ty = Number(runtime.touch && runtime.touch.y || 0) + offY;
        if (smooth < 1 && smooth > 0) {
          x = x + (tx - x) * smooth;
          y = y + (ty - y) * smooth;
        } else {
          x = tx; y = ty;
        }
        runtime.camX = x; runtime.camY = y;
      }

      // glide camera
      if (runtime._camGlide) {
        const g = runtime._camGlide;
        const t = Math.min(1, (performance.now() - g.start) / g.dur);
        const e = t * t * (3 - 2 * t);
        x = g.fromX + (g.toX - g.fromX) * e;
        y = g.fromY + (g.toY - g.fromY) * e;
        runtime.camX = x;
        runtime.camY = y;
        if (t >= 1) runtime._camGlide = null;
      }

      // zoom glide
      if (runtime._zoomGlide) {
        const g = runtime._zoomGlide;
        const t = Math.min(1, (performance.now() - g.start) / g.dur);
        const e = t * t * (3 - 2 * t);
        z = g.from + (g.to - g.from) * e;
        runtime.camZoom = z;
        if (t >= 1) {
          runtime._zoomGlide = null;
          try {
            runtime.actors.forEach(function (ra) { startHatsFor(ra, 'Quando zoom mudar'); });
          } catch (_) {}
        }
      }

      if (runtime._camBounds) {
        const b = runtime._camBounds;
        x = Math.max(b.minX, Math.min(b.maxX, x));
        y = Math.max(b.minY, Math.min(b.maxY, y));
        runtime.camX = x;
        runtime.camY = y;
      }

      if (runtime._camShake && runtime._camShake.left > 0) {
        const s = runtime._camShake;
        s.left -= 16;
        x += (runtimeRandom() - 0.5) * s.intensity * 2;
        y += (runtimeRandom() - 0.5) * s.intensity * 2;
        if (s.left <= 0) runtime._camShake = null;
      }

      // Public camera coordinates use world space: X is opposite of the render translation,
      // while Y follows the world axis used by actors. Internal camX/camY remain unchanged
      // so existing rendering/follow code keeps working.
      runtime.cameraWorldX = -x;
      runtime.cameraWorldY = y;
      const prev = runtime._lastCamKey;
      const presentationRot = Number(runtime._stagePresentationRotation || 0);
      const cm = projectStageMetrics();
      const key = x.toFixed(1) + ',' + y.toFixed(1) + ',' + z.toFixed(2) + ',' + rot.toFixed(1) + ',' + presentationRot.toFixed(1) + ',' + Number(cm.sx).toFixed(2) + ',' + Number(cm.sy).toFixed(2);
      if (prev !== key) {
        stage.style.transform = 'rotate(' + presentationRot + 'deg) translate(' + (x * cm.sx) + 'px,' + (y * cm.sy) + 'px) scale(' + z + ') rotate(' + rot + 'deg)';
        stage.style.transformOrigin = 'center center';
        try {
          const inner = runtime._stageInner && runtime._stageInner.isConnected ? runtime._stageInner : (runtime._stageInner = stage.querySelector('.stage-inner, #stage-actors, .play-actors'));
          if (inner && inner !== stage) inner.style.transform = 'translate(' + (x * cm.sx) + 'px,' + (y * cm.sy) + 'px) scale(' + z + ')';
        } catch (_) {}
      }
      if (prev && prev !== key) {
        try { runtime.actors.forEach(function (ra) { startHatsFor(ra, 'Quando câmera mover'); }); } catch (_) {}
      }
      runtime._lastCamKey = key;
    } catch (_) {}
  }



  
  function ensureHud() {
    if (!runtime.hud) {
      runtime.hud = { visible:true, x:8, y:8, elements:{}, killfeed:[], score:{A:0,B:0,nameA:'Time A',nameB:'Time B'}, timer:null, theme:'dark' };
    }
    const playCanvas = runtime.stageEl?.parentElement || document.getElementById('play-canvas');
    if (playCanvas && runtime._hudParent !== playCanvas) {
      if (getComputedStyle(playCanvas).position === 'static') playCanvas.style.position = 'relative';
      runtime._hudParent = playCanvas;
    }
    let root = runtime._hudRoot || document.getElementById('kix-hud-root');
    if (!root && playCanvas) {
      root = document.createElement('div');
      root.id = 'kix-hud-root';
      playCanvas.appendChild(root);
    }
    if (root) {
      if (root.parentElement !== playCanvas && playCanvas) playCanvas.appendChild(root);
      if (!root.dataset.kixHudStyled) {
        root.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:30;overflow:hidden;font-family:system-ui,sans-serif;isolation:isolate;';
        root.dataset.kixHudStyled = '1';
      }
      const display = runtime.hud.visible ? '' : 'none';
      if (root.style.display !== display) root.style.display = display;
      runtime._hudRoot = root;
    }
    return runtime.hud;
  }

  function ensureControlsRoot() {
    const playCanvas = runtime.stageEl?.parentElement || document.getElementById('play-canvas') || document.body;
    if (playCanvas && runtime._controlsParent !== playCanvas) {
      if (getComputedStyle(playCanvas).position === 'static') playCanvas.style.position = 'relative';
      runtime._controlsParent = playCanvas;
    }
    let root = runtime._controlsRoot || document.getElementById('kix-controls-root');
    if (!root) {
      root = document.createElement('div');
      root.id = 'kix-controls-root';
      playCanvas.appendChild(root);
    } else if (root.parentElement !== playCanvas) {
      playCanvas.appendChild(root);
    }
    if (!root.dataset.kixControlsStyled) {
      root.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:20;overflow:visible;isolation:isolate;';
      root.dataset.kixControlsStyled = '1';
    }
    runtime._controlsRoot = root;
    return root;
  }

  function ensureVirtualControlsAlive() {
    try {
      const controls = runtime._presets && runtime._presets.controls;
      if (!controls || Object.keys(controls).length === 0) return;
      const root = ensureControlsRoot();
      if (!root) return;
      Object.keys(controls).forEach((id) => {
        const c = controls[id];
        if (!c || !c.el) return;
        if (c.el.parentElement !== root) root.appendChild(c.el);
        if (c.el.dataset.kixControlsAlive !== '1') {
          c.el.style.zIndex = '20';
          c.el.style.pointerEvents = 'auto';
          c.el.style.overflow = 'visible';
          c.el.style.display = 'block';
          c.el.style.visibility = 'visible';
          c.el.dataset.kixControlsAlive = '1';
        }
      });
    } catch (_) {}
  }

  function clearVirtualControls() {
    try {
      const controls = runtime._presets && runtime._presets.controls;
      if (controls) Object.keys(controls).forEach((id) => { try { controls[id]?.el?.remove(); } catch (_) {} });
      if (runtime._controlsRoot) runtime._controlsRoot.innerHTML = '';
      if (runtime._presets) runtime._presets.controls = {};
    } catch (_) {}
  }

  function hudEl(id, tag, css) {
    const hud = ensureHud();
    if (hud.elements[id] && hud.elements[id].el) return hud.elements[id];
    const root = runtime._hudRoot;
    if (!root) return null;
    const el = document.createElement(tag || 'div');
    el.dataset.hudId = id;
    el.style.cssText = (css || '') + ';pointer-events:auto;';
    root.appendChild(el);
    hud.elements[id] = { el: el, id: id };
    return hud.elements[id];
  }

  function updateHudTimer() {
    try {
      const hud = runtime.hud;
      if (!hud || !hud.timer || !hud.timer.running) return;
      ensureHud();
      const left = Math.max(0, hud.timer.end - performance.now());
      const sec = Math.ceil(left / 1000);
      const m = Math.floor(sec / 60);
      const s = sec % 60;
      const text = (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
      const node = hud.elements['timer_partida'];
      if (node && node.el && node.el.textContent !== text) node.el.textContent = text;
      if (left <= 0) {
        hud.timer.running = false;
        try {
          runtime.actors.forEach(function (ra) { startHatsFor(ra, 'Quando timer de partida acabar'); });
        } catch (_) {}
      }
    } catch (_) {}
  }

  function clearAllHud() {
    try {
      const hud = ensureHud();
      Object.keys(hud.elements).forEach(function (id) {
        const e = hud.elements[id];
        if (e && e.el && e.el.parentNode) e.el.parentNode.removeChild(e.el);
      });
      hud.elements = {};
      hud.killfeed = [];
      if (runtime._hudRoot) runtime._hudRoot.innerHTML = '';
    } catch (_) {}
  }


  function ensureParticles() {
    if (!runtime.particles) runtime.particles = [];
    if (!runtime._particleLayer) {
      try {
        const stage = runtime.stageEl || document.getElementById('play-stage');
        if (stage) {
          let layer = stage.querySelector('.kix-particles');
          if (!layer) {
            layer = document.createElement('div');
            layer.className = 'kix-particles';
            layer.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;overflow:visible;z-index:50;';
            stage.appendChild(layer);
          }
          runtime._particleLayer = layer;
        }
      } catch (_) {}
    }
    return runtime.particles;
  }

  function spawnParticle(emitter, x, y) {
    try {
      const list = ensureParticles();
      const layer = runtime._particleLayer;
      const el = document.createElement('div');
      const size = emitter.size || 6;
      const color = emitter.color || '#FFD700';
      el.style.cssText = 'position:absolute;width:' + size + 'px;height:' + size + 'px;border-radius:50%;background:' + color + ';left:0;top:0;pointer-events:none;opacity:1;';
      const angle = (runtimeRandom() * 360) * Math.PI / 180;
      const speed = (emitter.speed || 40) * (0.5 + runtimeRandom());
      const life = emitter.life || 800;
      const p = {
        el: el,
        x: x,
        y: y,
        vx: Math.cos(angle) * speed / 60,
        vy: Math.sin(angle) * speed / 60,
        life: life,
        maxLife: life,
        color: color,
        emitterId: emitter.id
      };
      if (layer) layer.appendChild(el);
      list.push(p);
      // fire "Quando partícula nascer" for actors that have that hat
      try {
        runtime.actors.forEach(function (ra) {
          startHatsFor(ra, 'Quando partícula nascer');
        });
      } catch (_) {}
      return p;
    } catch (e) {
      console.warn('spawnParticle', e);
      return null;
    }
  }

  function updateParticles(dt) {
    try {
      const list = ensureParticles();
      const stage = runtime.stageEl;
      const sw = (stage && stage._stageW) || 360;
      const sh = (stage && stage._stageH) || 640;
      for (let i = list.length - 1; i >= 0; i--) {
        const p = list[i];
        p.life -= dt;
        p.x += p.vx * (dt / 16);
        p.y += p.vy * (dt / 16);
        p.vy -= (Number(p.gravity || 0) * 0.001) * (dt / 16);
        if (p.el) {
          const px = sw / 2 + p.x;
          const py = sh / 2 - p.y;
          const op = Math.max(0, p.life / p.maxLife);
          p.el.style.transform = 'translate(' + px + 'px,' + py + 'px) translate(-50%,-50%)';
          p.el.style.opacity = String(op);
        }
        if (p.life <= 0) {
          if (p.el && p.el.parentNode) p.el.parentNode.removeChild(p.el);
          list.splice(i, 1);
        }
      }
      // Persisted scene particle emitters. They remain compatible with the legacy actor emitter path.
      (runtime.sceneEmitters || []).forEach(function (em) {
        if (!em || em.active === false) return;
        if (em.actorId) { const host=(runtime.actors||[]).find(ra=>ra&&String(ra.data?.kixId||ra.data?.id||ra.data?.name||'')===String(em.actorId)); if(host){em.x=Number(host.data.x)||0;em.y=Number(host.data.y)||0;} }
        em._acc=(em._acc||0)+dt;
        const amount=Math.max(1,Number(em.amount)||80), interval=1000/Math.max(1,amount/(Math.max(.05,Number(em.lifetime)||1)));
        if(em.oneShot && em._fired) return;
        while(em._acc>=interval){em._acc-=interval; const angle=(Number(em.direction)||0)*Math.PI/180+(runtimeRandom()-.5)*(Number(em.spread)||60)*Math.PI/180; const speed=Math.max(0,Number(em.speed)||80); const p=spawnParticle({id:em.id,size:Number(em.size)||8,color:em.color||'#34D399',speed:speed,life:Math.max(50,(Number(em.lifetime)||1)*1000),texture:em.texture,gravity:Number(em.gravity)||0},Number(em.x)||0,Number(em.y)||0); if(p){p.vx=Math.cos(angle)*speed/60;p.vy=Math.sin(angle)*speed/60;p.gravity=Number(em.gravity)||0;} if(em.oneShot){em._fired=true;break;}}
      });
      // emitters on actors
      (runtime.actors || []).forEach(function (ra) {
        if (!ra || !ra.data || !ra.data._emitter || !ra.data._emitter.active) return;
        const em = ra.data._emitter;
        em._acc = (em._acc || 0) + dt;
        const interval = 1000 / Math.max(1, em.rate || 10);
        while (em._acc >= interval) {
          em._acc -= interval;
          spawnParticle(em, Number(ra.data.x) || 0, Number(ra.data.y) || 0);
        }
      });
    } catch (_) {}
  }


  function ensureDeviceState() {
    if (!runtime.device) {
      runtime.device = {
        accel: { x: 0, y: 0, z: 0 },
        gyro: { alpha: 0, beta: 0, gamma: 0 },
        compass: 0,
        gps: { lat: 0, lng: 0, accuracy: 0 },
        light: 100,
        proximity: false,
        battery: 1,
        wakeLock: null,
        sensorsStarted: false
      };
    }
    return runtime.device;
  }

  function startDeviceSensors() {
    const d = ensureDeviceState();
    if (d.sensorsStarted) return;
    d.sensorsStarted = true;
    try {
      window.addEventListener('devicemotion', function (e) {
        const a = e.accelerationIncludingGravity || e.acceleration;
        if (a) {
          d.accel.x = a.x || 0;
          d.accel.y = a.y || 0;
          d.accel.z = a.z || 0;
        }
        if (e.rotationRate) {
          d.gyro.alpha = e.rotationRate.alpha || d.gyro.alpha;
          d.gyro.beta = e.rotationRate.beta || d.gyro.beta;
          d.gyro.gamma = e.rotationRate.gamma || d.gyro.gamma;
        }
      }, true);
    } catch (_) {}
    try {
      window.addEventListener('deviceorientation', function (e) {
        if (e.alpha != null) d.compass = e.alpha;
        d.gyro.alpha = e.alpha || 0;
        d.gyro.beta = e.beta || 0;
        d.gyro.gamma = e.gamma || 0;
      }, true);
    } catch (_) {}
    try {
      if (navigator.getBattery) {
        navigator.getBattery().then(function (b) {
          d.battery = b.level;
          b.addEventListener('levelchange', function () { d.battery = b.level; });
        }).catch(function () {});
      }
    } catch (_) {}
    try {
      if (navigator.geolocation) {
        navigator.geolocation.watchPosition(function (pos) {
          d.gps.lat = pos.coords.latitude;
          d.gps.lng = pos.coords.longitude;
          d.gps.accuracy = pos.coords.accuracy;
        }, function () {}, { enableHighAccuracy: true, maximumAge: 5000 });
      }
    } catch (_) {}
  }

  function deviceSetVar(co, key, value) {
    try {
      if (!co.actor.data._vars) co.actor.data._vars = {};
      co.actor.data._vars[key] = value;
      if (!runtimeDataSet(key, value, co.actor.data)) runtime.globals[key] = value;
    } catch (_) {}
  }

  function markJoystickDirectionVar(co, key, controlId) {
    runtime._joystickDirectionVars = runtime._joystickDirectionVars || {};
    runtime._joystickDirectionVars[String(key)] = { controlId: String(controlId || 'joystick1'), actor: co && co.actor };
  }

  function joystickAxisFromDirectionVar(raw, axis) {
    const key = String(raw == null ? '' : raw).trim().replace(/^['"]|['"]$/g, '');
    const meta = runtime._joystickDirectionVars && runtime._joystickDirectionVars[key];
    if (!meta) return null;
    const c = runtime._presets && runtime._presets.controls && runtime._presets.controls[meta.controlId];
    if (!c) return null;
    return axis === 'y' ? Number(c.axisY) || 0 : Number(c.axisX) || 0;
  }


  function ensureTextLayer() {
    const stage = runtime.stageEl || document.getElementById('play-stage');
    const playCanvas = document.getElementById('play-canvas') || stage?.parentElement;
    if (!stage || !playCanvas) {
      console.error('[Kix] play-stage/play-canvas not found');
      return null;
    }
    runtime.stageEl = stage;
    if (getComputedStyle(playCanvas).position === 'static') playCanvas.style.position = 'relative';

    // Text is a world-space layer: it belongs INSIDE play-stage, so all camera
    // transforms (free camera, zoom, rotation and follow) affect it exactly like sprites.
    let layer = document.getElementById('kix-text-layer-root');
    if (!layer) layer = stage.querySelector('.kix-text-layer');
    if (!layer) {
      layer = document.createElement('div');
      layer.id = 'kix-text-layer-root';
      layer.className = 'kix-text-layer';
    }
    if (layer.parentElement !== stage) stage.appendChild(layer);
    layer.style.cssText = [
      'position:absolute','inset:0','width:100%','height:100%',
      'pointer-events:none','overflow:visible','z-index:60',
      'font-family:Arial,Helvetica,sans-serif','isolation:isolate',
      'background:transparent','background-image:none'
    ].join(';') + ';';
    return layer;
  }

  function textActorId(ra, textId) {
    if (!ra) return 0;
    let base;
    if (ra.id != null) base = ra.id;
    else if (ra.index != null) base = ra.index;
    else if (ra.data && ra.data.id != null) base = ra.data.id;
    else { const idx = runtime.actors.indexOf(ra); base = idx >= 0 ? idx : 0; }
    const tid = String(textId == null || textId === '' ? 'texto1' : textId).replace(/[^a-zA-Z0-9_-]/g, '_');
    return String(base) + '--' + tid;
  }
  function normalizeTextId(id) {
    const s = String(id == null ? '' : id).trim().replace(/^['"]|['"]$/g, '');
    return s || 'texto1';
  }
  function ensureActorTextMap(ra) {
    if (!ra) return {}; if (!ra.data) ra.data = {};
    if (!ra.data._texts || typeof ra.data._texts !== 'object') {
      ra.data._texts = {};
      if (ra.data._text && typeof ra.data._text === 'object') {
        ra.data._texts.texto1 = ra.data._text;
        ra.data._texts.texto1.id = 'texto1';
        if (ra.data._texts.texto1.visible === undefined) ra.data._texts.texto1.visible = true;
      }
    }
    return ra.data._texts;
  }
  function getActorTextState(ra, id) {
    const tid = normalizeTextId(id); const map = ensureActorTextMap(ra);
    if (!map[tid]) map[tid] = {id:tid,content:'',style:{color:'#FFFFFF',fontSize:50,align:'center',opacity:100,x:0,y:0},boundVar:null,boundExpr:null,boundPrefix:'',pulse:null,visible:true,multiline:false};
    if (map[tid].multiline === undefined) map[tid].multiline = false;
    if (tid === 'texto1') ra.data._text = map[tid];
    return map[tid];
  }

  function getOrCreateTextEl(actorId) {
    const layer = ensureTextLayer();
    if (!layer) return null;
    const id = 'kix-text-' + actorId;
    let el = layer.querySelector('#' + CSS.escape(id));
    if (!el) {
      // CSS.escape may fail on old webviews
      el = null;
      for (let i = 0; i < layer.children.length; i++) {
        if (layer.children[i].id === id) { el = layer.children[i]; break; }
      }
    }
    if (!el) {
      el = document.createElement('div');
      el.id = id;
      el.className = 'kix-text-el';
      layer.appendChild(el);
    }
    el.style.position = 'absolute';
    el.style.pointerEvents = 'none';
    el.style.zIndex = '2';
    el.style.display = 'block';
    el.style.visibility = 'visible';
    el.style.margin = '0';
    el.style.padding = '4px 8px';
    el.style.whiteSpace = 'normal';
    el.style.textAlign = 'center';
    el.style.lineHeight = '1.3';
    el.style.boxSizing = 'border-box';
    el.style.maxWidth = '90%';
    el.style.minWidth = '1px';
    el.style.minHeight = '1px';
    el.style.color = el.style.color || '#FFFFFF';
    el.style.fontSize = el.style.fontSize || '32px';
    if (!el.style.fontFamily) el.style.fontFamily = 'Arial, Helvetica, sans-serif';
    el.style.fontWeight = el.style.fontWeight || '700';
    el.style.textShadow = el.style.textShadow || '0 1px 3px rgba(0,0,0,0.85)';
    el.style.webkitTextFillColor = '';
    el.style.backgroundColor = 'transparent';
    el.style.backgroundImage = 'none';
    el.style.border = '0';
    el.style.outline = '0';
    el.style.boxShadow = 'none';
    el.style.textDecoration = 'none';
    el.style.mixBlendMode = 'normal';
    return el;
  }

  function applyTextStyle(el, st) {
    if (!el || !st) return;
    const styleKey = [st.fontFamily||'',st.fontSize,st.__worldLogical===true?1:0,st.bold===true?1:0,st.italic===true?1:0,st.align||'',st.lineHeight,st.opacity,st.maxWidth,st.multiline===true?1:0,st.gradient||'',st.color||'',st.stroke||'',st.strokeWidth,st.shadow ? JSON.stringify(st.shadow) : '',st.glow ? JSON.stringify(st.glow) : '',st.filter||''].join('|');
    if (el.dataset.kixTextStyleKey === styleKey) return;
    el.dataset.kixTextStyleKey = styleKey;
    el.style.display = 'block';
    el.style.visibility = 'visible';
    if (st.fontFamily) {
      el.style.fontFamily = st.fontFamily;
    } else {
      el.style.fontFamily = 'Arial, Helvetica, sans-serif';
    }
    if (st.fontSize != null) {
      const baseSize=Number(st.fontSize)||32;
      const scale=st.__worldLogical ? projectStageMetrics().worldScale : 1;
      el.style.fontSize = (baseSize*scale) + 'px';
    }
    if (st.bold != null) el.style.fontWeight = st.bold ? '700' : '400';
    if (st.italic != null) el.style.fontStyle = st.italic ? 'italic' : 'normal';
    if (st.align) {
      const a = st.align;
      el.style.textAlign = (a === 'centro' || a === 'center') ? 'center' : ((a === 'esquerda' || a === 'left') ? 'left' : ((a === 'direita' || a === 'right') ? 'right' : a));
    }
    if (st.lineHeight != null) el.style.lineHeight = String(st.lineHeight);
    const op = st.opacity != null ? Number(st.opacity) : 100;
    el.style.opacity = String(Math.max(0.15, Math.min(1, op > 1 ? op / 100 : op)));
    if (st.maxWidth != null) {
      const mw = Number(st.maxWidth);
      const wm = st.__worldLogical ? projectStageMetrics() : null;
      const widthScale = wm ? Number.isFinite(wm.worldScale) ? wm.worldScale : 1 : 1;
      el.style.maxWidth = (Number.isFinite(mw) ? Math.max(1, mw * widthScale) : 1) + 'px';
    }
    el.style.whiteSpace = st.multiline ? 'pre-wrap' : 'normal';
    el.style.overflowWrap = 'break-word';

    if (st.gradient) {
      el.style.backgroundImage = st.gradient;
      el.style.webkitBackgroundClip = 'text';
      el.style.backgroundClip = 'text';
      el.style.color = 'transparent';
      el.style.webkitTextFillColor = 'transparent';
    } else {
      el.style.backgroundImage = 'none';
      el.style.webkitBackgroundClip = 'border-box';
      el.style.backgroundClip = 'border-box';
      el.style.webkitTextFillColor = '';
      el.style.color = st.color || '#FFFFFF';
    }
    if (st.stroke && st.strokeWidth) {
      el.style.webkitTextStroke = (st.strokeWidth || 1) + 'px ' + st.stroke;
    } else {
      el.style.webkitTextStroke = '';
    }
    if (st.shadow) {
      const sh = st.shadow;
      el.style.textShadow = (sh.x || 0) + 'px ' + (sh.y || 0) + 'px ' + (sh.blur || 0) + 'px ' + (sh.color || '#000');
    } else {
      el.style.textShadow = 'none';
    }
    if (st.glow) {
      el.style.filter = 'drop-shadow(0 0 ' + (st.glow.intensity || 8) + 'px ' + (st.glow.color || '#fff') + ')';
    } else if (!st.filter) {
      el.style.filter = '';
    }
  }

  /** Position text on stage using same coord system as sprites */
  function updateTextTransform(ra, id) {
    if (!ra || !ra.data) return;
    const t = getActorTextState(ra, id || 'texto1');
    if (!t.content && !t.boundVar) return;
    const el = getOrCreateTextEl(textActorId(ra, id || 'texto1'));
    if (!el) return;
    const stage = runtime.stageEl || document.getElementById('play-stage');
    const sw = (stage && stage._stageW) || (stage && stage.clientWidth) || 360;
    const sh = (stage && stage._stageH) || (stage && stage.clientHeight) || 640;
    // Independent text position (NOT tied to actor movement)
    const tx = (t.style && t.style.x != null && !isNaN(Number(t.style.x))) ? Number(t.style.x) : 0;
    const ty = (t.style && t.style.y != null && !isNaN(Number(t.style.y))) ? Number(t.style.y) : 0;
    const m = projectStageMetrics();
    const world = !!(t.style && t.style.__worldLogical);
    const x = (sw / 2) + (world ? tx * m.worldScale : tx);
    const y = (sh / 2) - (world ? ty * m.worldScale : ty);
    const rot = (t.style && t.style.rotation != null) ? t.style.rotation : 0;
    const sc = (t.style && t.style.scale != null) ? t.style.scale : 1;
    const key = sw + '|' + sh + '|' + x + '|' + y + '|' + rot + '|' + sc + '|' + (t.multiline ? 1 : 0) + '|' + ((t.style && t.style.maxWidth != null) ? (Number(t.style.maxWidth) || 1) : 'none');
    if (el.dataset.kixTextTransformKey === key) return;
    el.dataset.kixTextTransformKey = key;
    el.style.position = 'absolute';
    el.style.left = x + 'px';
    el.style.top = y + 'px';
    el.style.transform = 'translate(-50%,-50%) rotate(' + rot + 'deg) scale(' + sc + ')';
    el.style.whiteSpace = t.multiline ? 'pre-wrap' : 'nowrap';
    el.style.maxWidth = (t.style && t.style.maxWidth != null) ? (Number(t.style.maxWidth) || 1) + 'px' : 'none';
  }

  function escapeHtmlText(v) {
    return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  // Single quotes mark the highlighted portion. Outer double quotes are treated as
  // ordinary formula/string delimiters and are not painted as a highlight range.
  function renderQuotedColorText(el, text, baseColor, quoteColor) {
    if (!el) return;
    const src = String(text == null ? '' : text);
    const renderKey = src + '|' + String(baseColor || '#FFFFFF') + '|' + String(quoteColor || '#FF4444');
    if (el.dataset.kixQuotedRenderKey === renderKey) return;
    el.dataset.kixQuotedRenderKey = renderKey;
    el.innerHTML = '';
    const re = /'([^']*)'/g;
    let last = 0, match;
    while ((match = re.exec(src))) {
      if (match.index > last) el.appendChild(document.createTextNode(src.slice(last, match.index)));
      const span = document.createElement('span');
      span.style.color = String(quoteColor || '#FF4444');
      span.textContent = match[1];
      el.appendChild(span);
      last = re.lastIndex;
    }
    if (last < src.length) el.appendChild(document.createTextNode(src.slice(last)));
    if (!el.childNodes.length) el.textContent = src.replace(/^['"]|['"]$/g,'');
    el.style.color = String(baseColor || '#FFFFFF');
  }

  globalThis.renderQuotedColorText = renderQuotedColorText;

  function ensureActorTextState(ra, id) { return getActorTextState(ra, id || 'texto1'); }

  function refreshActorText(ra, id) {
    try { const tid=normalizeTextId(id||'texto1'); const t=getActorTextState(ra,tid);
      if(t.boundExpr){const v=evalExpr(t.boundExpr,{actor:ra.data,vars:ra.data._vars||{},globals:runtime.globals});showActorText(ra,(t.boundPrefix||'')+(v==null?'':v),null,tid);return;}
      if(t.boundVar){const v=runtime.globals[t.boundVar]!=null?runtime.globals[t.boundVar]:(ra.data._vars&&ra.data._vars[t.boundVar]);showActorText(ra,(t.boundPrefix||'')+(v==null?'':v),null,tid);return;}
      if(t.content!=null&&String(t.content).length)showActorText(ra,t.content,null,tid);
    } catch(e){console.warn('refreshActorText',e);} }

  function showActorText(ra, content, extraStyle, id) {
    try { if(!ra)return null; const tid=normalizeTextId(id||'texto1'); const t=getActorTextState(ra,tid);
      if(content!=null)t.content=String(content); if(extraStyle)Object.keys(extraStyle).forEach(k=>{if(extraStyle[k]!=null)t.style[k]=extraStyle[k]});
      t.followActor=false;t.visible=true; const el=getOrCreateTextEl(textActorId(ra,tid)); if(!el)return null;
      // Ordinary text blocks stay on one visual line unless explicitly multiline.
      // Normalize accidental source newlines/literal \n sequences so they cannot look like drawing lines inside the label.
      const displayContent = t.multiline ? String(t.content||'').replace(/\r\n?/g,'\n') : String(t.content||'').replace(/\r?\n|\\n/g,' ').replace(/\t/g,' ');
      t.content = displayContent;
      el.style.display='block';el.style.visibility='visible';
      el.style.background='transparent'; el.style.backgroundImage='none'; el.style.backgroundClip='border-box'; el.style.webkitBackgroundClip='border-box';
      if(t._quotedMode)renderQuotedColorText(el,displayContent,t._quoteBase||t.style.color,t._quoteCol||'#FF4444');else { el.textContent=displayContent; el.replaceChildren?.(document.createTextNode(displayContent)); }
      applyTextStyle(el,t.style);updateTextTransform(ra,tid); return el;
    }catch(e){console.error('[Kix] showActorText',e);return null;} }
  function hideActorText(ra,id){try{const tid=normalizeTextId(id||'texto1');const t=getActorTextState(ra,tid);t.visible=false;const el=getOrCreateTextEl(textActorId(ra,tid));if(el){el.style.display='none';el.style.visibility='hidden';}return true;}catch(_){return false;}}


  function pruneTextForActor(ra) {
    try {
      if (!ra || !ra.data) return false;
      const map = ensureActorTextMap(ra);
      const flat = Array.isArray(ra.data.scripts) ? ra.data.scripts : (ra.data.scripts && ra.data.scripts.blocks ? scriptsToFlat(ra.data.scripts) : []);
      const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim();
      const sourceRe = /^(mostrar texto|definir texto|definir texto multilinha|criar texto facilitado|texto estilizado|texto hud|titulo de nivel|dano flutuante|aspas coloridas|caixa de dialogo|caixa de dialogo com digitacao pronta|efeito de digitacao|efeito de digitacao em|mostrar dado como texto)/;
      const valid = new Set();
      for (const b of flat) {
        if (!b) continue;
        const n = norm(b.name);
        if (!n) continue;
        const source = sourceRe.test(n) || n.includes('texto multilinha');
        if (!source) continue;
        let id = '';
        const vals = b.values || {};
        for (const k of ['id','ID','identificador']) { if (vals[k] != null && String(vals[k]).trim()) { id=String(vals[k]).trim(); break; } }
        valid.add(normalizeTextId(id || 'texto1'));
      }
      let changed=false;
      Object.keys(map).forEach(tid => {
        const t=map[tid];
        if (valid.has(tid)) return;
        if (t) { t.visible=false; t.content=''; t.boundVar=null; t.boundExpr=null; t.textAnim=null; t.pulse=null; t.gradAnim=null; }
        const el=getOrCreateTextEl(textActorId(ra,tid));
        if (el) { el.textContent=''; el.replaceChildren?.(); el.style.display='none'; el.style.visibility='hidden'; }
        changed=true;
      });
      return changed;
    } catch (_) { return false; }
  }

  function rawBlockValue(blk, key) {
    try { return blk && blk.values && blk.values[key] != null ? String(blk.values[key]).trim() : ''; } catch (_) { return ''; }
  }
  function resolveTextFormulaValue(blk, key, ctx) {
    const raw = rawBlockValue(blk, key);
    if (!raw) return { expression: null, value: '' };

    // Quoted values are always literal text.
    const quoted = /^(?:\"[\s\S]*\"|'[\s\S]*')$/.test(raw);
    if (quoted) return { expression: null, value: paramStr(blk, key, '', ctx) };

    // Operators, parentheses and known multi-word formula phrases are explicit formulas.
    const explicitFormula = /[+\-*\/%<>=()!]/.test(raw) ||
      /^(?:fps|fps atual|valor toque|toque|posição|posicao|posição x|posicao x|posição y|posicao y|tempo|tempo de jogo|tempo decorrido|largura|altura|tamanho|direção|direcao|velocidade|objetos|bateria|acelerômetro|acelerometro|giroscópio|giroscopio|câmera|camera|zoom|variável|variavel|nome da aparência|nome da aparencia|aparência atual|aparencia atual|distância até|distancia ate)$/i.test(raw.trim());
    if (explicitFormula) return { expression: raw, value: evalExpr(raw, ctx) };

    // A single bare identifier is ambiguous. Only treat it as a formula/variable when
    // it actually resolves in the current actor/global context or as a known engine property.
    // Unknown identifiers (e.g. "Oi", "Ola") are literal text and must be displayed.
    const identifier = /^[A-Za-zÀ-ÿ_][A-Za-zÀ-ÿ0-9_]*$/.test(raw);
    if (identifier) {
      const lookup = formulaLookup(raw, ctx);
      if (lookup !== undefined) return { expression: raw, value: lookup };
      return { expression: null, value: paramStr(blk, key, '', ctx) };
    }

    // Any remaining non-empty token is safer as literal text than as a guessed formula.
    return { expression: null, value: paramStr(blk, key, '', ctx) };
  }

  function ensureActorState(actor, index) {
    if (actor.id === undefined || actor.id === null) actor.id = index;
    if (actor.x === undefined || actor.x === null || actor.x === '' || !Number.isFinite(Number(actor.x))) actor.x = 0;
    if (actor.y === undefined || actor.y === null || actor.y === '' || !Number.isFinite(Number(actor.y))) actor.y = 0;
    if (actor.direction === undefined || actor.direction === null || !Number.isFinite(Number(actor.direction))) actor.direction = 90;
    if (actor.size === undefined) actor.size = 100;
    if (actor.pixelArt === undefined) actor.pixelArt = false;
    if (!Array.isArray(actor.folders)) actor.folders = actor.folders || [];
    if (!Array.isArray(actor.looks)) actor.looks = actor.looks || [];
    if (!actor.pixelArtLooks || typeof actor.pixelArtLooks !== 'object') actor.pixelArtLooks = {};
    if (actor.looks.length === 0 && actor.folders.every(f => !Array.isArray(f?.looks) || f.looks.length === 0)) {
      actor.image = null;
      actor.activeAppearance = null;
      actor.costume = 0;
      actor.pixelArt = false;
    }
    if (actor.visible === undefined) actor.visible = true;
    if (actor.costume === undefined) actor.costume = 0;
    if (!Number.isFinite(Number(actor.transparency))) actor.transparency = Math.max(0, Math.min(100, 100 - Number(actor.opacity == null ? 100 : actor.opacity)));
    if (!Number.isFinite(Number(actor.opacity))) actor.opacity = Math.max(0, Math.min(100, 100 - Number(actor.transparency || 0)));
    if (!actor._vars) actor._vars = {};
    try {
      const defs = Array.isArray(runtime.project?.dataDefinitions) ? runtime.project.dataDefinitions : [];
      const key = dataDefinitionActorKey(actor);
      defs.filter(d => d && d.scope === 'object').forEach(d => {
        if (Object.prototype.hasOwnProperty.call(d.valuesByActor || {}, key)) actor._vars[d.name] = d.valuesByActor[key];
        else if (!Object.prototype.hasOwnProperty.call(actor._vars, d.name)) actor._vars[d.name] = d.value;
      });
      defs.filter(d => d && d.scope !== 'object').forEach(d => {
        if (runtime.globals[d.name] === undefined) runtime.globals[d.name] = d.value;
      });
    } catch (_) {}
    return actor;
  }


  function configureProjectStage(project, physicalW, physicalH) {
    const cat = project && project.catrobatStage;
    const normalStage = project && project.stage;
    const orientation=String(project && project.orientation || '').toLowerCase()==='landscape' ? 'landscape' : 'portrait';
    const useLogicalCat = !!cat && Number(cat.width) > 0 && Number(cat.height) > 0;
    const useLogicalNormal = !useLogicalCat && !!normalStage;
    runtime._usesCatrobatStage = useLogicalCat;
    const fallbackW=orientation==='landscape'?800:480, fallbackH=orientation==='landscape'?480:800;
    runtime._logicalStageW = useLogicalCat ? Number(cat.width) : (useLogicalNormal && Number(normalStage.width)>0 ? Number(normalStage.width) : fallbackW);
    runtime._logicalStageH = useLogicalCat ? Number(cat.height) : (useLogicalNormal && Number(normalStage.height)>0 ? Number(normalStage.height) : fallbackH);
    runtime._stageScaleX = 1;
    runtime._stageScaleY = 1;
    runtime._stageOffsetX = 0;
    runtime._stageOffsetY = 0;
    const sxRaw = Number(physicalW || 1) / runtime._logicalStageW;
    const syRaw = Number(physicalH || 1) / runtime._logicalStageH;
    const mode = String((useLogicalCat ? cat.mode : (normalStage && normalStage.mode)) || 'FIT').toUpperCase();
    // Keep logical world coordinates stable across rotations. Even when a Catrobat
    // project declares STRETCH, actor/text/camera geometry uses one uniform world
    // scale so a rotation cannot make an object wider/taller or move it by a
    // different amount simply because the physical viewport dimensions swapped.
    // Once Play begins, freeze the launch scale so a phone rotation/reflow cannot
    // resize every actor or move the logical origin. The stage may rotate visually,
    // but this logical scale is never re-derived from the new viewport.
    const locked = runtime.running && runtime._playViewportLocked && Number(runtime._playLockedWorldScale) > 0;
    const s = locked ? Number(runtime._playLockedWorldScale) : Math.min(sxRaw, syRaw);
    runtime._stageScaleX = s;
    runtime._stageScaleY = s;
    runtime._stageStretchX = sxRaw;
    runtime._stageStretchY = syRaw;
    runtime._stageMode = mode;
    runtime._stageOffsetX = (Number(physicalW || 0) - runtime._logicalStageW * s) / 2;
    runtime._stageOffsetY = (Number(physicalH || 0) - runtime._logicalStageH * s) / 2;
  }

  function projectStageMetrics() {
    const stage = runtime.stageEl;
    const pw = Number((stage && stage._stageW) || 480);
    const ph = Number((stage && stage._stageH) || 800);
    return {
      physicalW: pw, physicalH: ph,
      logicalW: Number(runtime._logicalStageW || pw),
      logicalH: Number(runtime._logicalStageH || ph),
      sx: Number(runtime._stageScaleX || 1),
      sy: Number(runtime._stageScaleY || 1),
      worldScale: Number(runtime._stageScaleX || 1),
      stretchSx: Number(runtime._stageStretchX || runtime._stageScaleX || 1),
      stretchSy: Number(runtime._stageStretchY || runtime._stageScaleY || 1),
      mode: String(runtime._stageMode || 'FIT'),
      ox: Number(runtime._stageOffsetX || 0),
      oy: Number(runtime._stageOffsetY || 0)
    };
  }

  function effectiveStagePresentationOrientation(project) {
    const forced = String(runtime._stagePresentationOrientation || document.documentElement?.dataset?.kixRotation || '').toLowerCase();
    if (forced === 'landscape' || forced === 'portrait') return forced;
    const cat = project && project.catrobatStage;
    const raw = String(project && project.orientation || (cat && cat.orientation) || '').toLowerCase();
    return raw === 'landscape' ? 'landscape' : 'portrait';
  }

  function stagePresentationGeometry(w, h, logicalW, logicalH, orientation) {
    const ow = Math.max(1, Number(logicalW) || 1);
    const oh = Math.max(1, Number(logicalH) || 1);
    const landscape = String(orientation || '').toLowerCase() === 'landscape';
    const viewportLandscape = Number(w) >= Number(h);
    const rotate = landscape !== viewportLandscape;
    const visualW = rotate ? oh : ow;
    const visualH = rotate ? ow : oh;
    const scale = Math.max(0.01, Math.min(Number(w || 1) / visualW, Number(h || 1) / visualH));
    return { rotate: rotate ? (landscape ? 90 : -90) : 0, scale, layoutW: ow * scale, layoutH: oh * scale, visualW: visualW * scale, visualH: visualH * scale };
  }

  function setStagePresentationOrientation(type) {
    const t = String(type || '').toLowerCase();
    if (t !== 'landscape' && t !== 'portrait') return false;
    runtime._stagePresentationOrientation = t;
    try { document.documentElement.dataset.kixRotation = t; } catch (_) {}
    try { syncStageLayout(); } catch (_) {}
    return true;
  }

  function clearStagePresentationOrientation() {
    runtime._stagePresentationOrientation = '';
    try { delete document.documentElement.dataset.kixRotation; } catch (_) {}
    try { syncStageLayout(); } catch (_) {}
    return true;
  }

  function assertProjectOrientationInvariant() {
    const p = String(document.documentElement.dataset.kixProjectOrientation || '').toLowerCase();
    return p === '' || p === 'portrait' || p === 'landscape';
  }

  function applyProjectOrientation(project) {
    try {
      const cat = project && project.catrobatStage;
      const orientation = String(project && project.orientation || (cat && cat.orientation) || '').toLowerCase();
      if (!orientation) return;
      // Project orientation is presentation metadata for the STAGE only. It must
      // never call the Android Activity orientation API: the host shell stays
      // in its current phone orientation while the stage can rotate internally.
      document.documentElement.dataset.kixProjectOrientation = orientation;
      document.documentElement.dataset.orient = orientation;
      runtime._stagePresentationOrientation = orientation;
      document.documentElement.dataset.kixRotation = orientation;
      document.documentElement.dataset.kixScreenWidth = String(cat?.width || project?.stage?.width || '');
      document.documentElement.dataset.kixScreenHeight = String(cat?.height || project?.stage?.height || '');
      document.documentElement.style.setProperty('--kix-project-aspect',(cat?.width||project?.stage?.width||1)+' / '+(cat?.height||project?.stage?.height||1));
    } catch (_) {}
  }

  function syncStageLayout() {
    try {
      const stage = runtime.stageEl || document.getElementById('play-stage');
      const parent = stage && stage.parentElement;
      if (!stage || !parent) return false;
      const rect = parent.getBoundingClientRect ? parent.getBoundingClientRect() : null;
      const w = Number(parent.clientWidth || (rect && rect.width) || 0);
      const h = Number(parent.clientHeight || (rect && rect.height) || 0);
      if (!(w > 0 && h > 0)) return false;
      const project=runtime.project||{};
      const cat=project.catrobatStage;
      const normal=project.stage;
      const orientation=effectiveStagePresentationOrientation(project);
      const mode=String((cat?.mode||normal?.mode||'FIT')).toUpperCase();
      const logicalW=Number(runtime._logicalStageW||((orientation==='landscape')?800:480));
      const logicalH=Number(runtime._logicalStageH||((orientation==='landscape')?480:800));

      // CRITICAL ORIENTATION INVARIANT:
      // Once Play has established the virtual stage, a physical rotation/reflow may
      // recenter or rotate the presentation, but it must NEVER recompute the world
      // scale. Recomputing scale from the new viewport is what made actor size and
      // screen position visibly jump after portrait <-> landscape.
      const lockValid = runtime.running && runtime._playViewportLocked &&
        Number(runtime._playLockedWorldScale) > 0 &&
        Number(runtime._playLockedLogicalW || logicalW) === logicalW &&
        Number(runtime._playLockedLogicalH || logicalH) === logicalH;
      let scale;
      let rotate;
      let visualW;
      let visualH;
      if (lockValid) {
        // The world scale is frozen from the first Play layout. The presentation
        // rotation is recalculated from the CURRENT viewport shape only; this lets
        // a landscape stage rotate inside a portrait phone (and vice versa) without
        // changing any actor x/y/size in logical coordinates.
        scale = Number(runtime._playLockedWorldScale);
        const viewportIsLandscape = w >= h;
        const wantLandscape = orientation === 'landscape';
        rotate = (wantLandscape === viewportIsLandscape) ? 0 : (wantLandscape ? 90 : -90);
        visualW = (rotate === 0 ? logicalW : logicalH) * scale;
        visualH = (rotate === 0 ? logicalH : logicalW) * scale;
      } else {
        // Stage-only orientation: use the RAW physical viewport. The geometry helper
        // returns a 90/-90deg presentation rotation when the project orientation
        // differs from the phone/window shape. No Activity rotation is requested.
        const geom=stagePresentationGeometry(w,h,logicalW,logicalH,orientation);
        scale=geom.scale;
        rotate=geom.rotate;
        visualW=geom.visualW;
        visualH=geom.visualH;
        if (runtime.running && runtime._playViewportLocked) {
          runtime._playLockedWorldScale=scale;
          runtime._playLockedLogicalW=logicalW;
          runtime._playLockedLogicalH=logicalH;
          runtime._playLockedPresentationOrientation=orientation;
        }
      }

      const stageW=logicalW*scale;
      const stageH=logicalH*scale;
      const left=(w-visualW)/2 + (visualW-stageW)/2;
      const top=(h-visualH)/2 + (visualH-stageH)/2;
      runtime._playLockedStageW=stageW;
      runtime._playLockedStageH=stageH;
      runtime._stagePresentationRotation=rotate;
      runtime._lastViewportWidth=w; runtime._lastViewportHeight=h;
      const changed = stage._stageW !== stageW || stage._stageH !== stageH || stage._stageLeft !== left || stage._stageTop !== top;
      stage.style.width=stageW+'px'; stage.style.height=stageH+'px'; stage.style.left=left+'px'; stage.style.top=top+'px';
      stage._stageW=stageW; stage._stageH=stageH; stage._stageLeft=left; stage._stageTop=top;
      configureProjectStage(project, stageW, stageH);
      stage.dataset.projectOrientation=orientation;
      stage.dataset.logicalWidth=String(runtime._logicalStageW||stageW);
      stage.dataset.logicalHeight=String(runtime._logicalStageH||stageH);
      if (typeof ResizeObserver==='function' && runtime.running) {
        if (!runtime._stageResizeObserver || runtime._stageResizeObserver._parent!==parent) {
          try { runtime._stageResizeObserver && runtime._stageResizeObserver.disconnect(); } catch (_) {}
          try {
            const ro=new ResizeObserver(function(){
              if(!runtime.running||runtime._stageResizeSyncing)return;
              runtime._stageResizeSyncing=true;
              const raf=kixRequestAnimationFrame;
              raf(()=>{runtime._stageResizeSyncing=false;syncStageLayout();});
            });
            ro.observe(parent); ro._parent=parent; runtime._stageResizeObserver=ro;
          } catch (_) {}
        }
      }
      if (changed && runtime.actors && runtime.actors.length) runtime.actors.forEach(ra=>{try{updateSpriteTransform(ra,true);}catch(_){}});
      if (changed) { try { const textLayer=document.getElementById('kix-text-layer-root'); if(textLayer) textLayer.querySelectorAll('.kix-text-el').forEach(el=>{ el.dataset.kixRelayout='1'; }); }catch(_){} }
      applyEngineCamera();
      return true;
    } catch (_) { return false; }
  }

  // Runtime actor layering follows Catrobat's ordered sprite stack:
  // first non-background actor = lowest actor layer, later actors = higher layers.
  // All dynamic layer operations below reuse these helpers so data.layer,
  // data.zIndex and the live DOM z-index never diverge.
  function runtimeLayerActors() {
    return (runtime.actors || []).filter(ra => ra && ra.data && !ra.data.isBackground);
  }

  function applyRuntimeActorLayer(ra, z) {
    if (!ra || !ra.data) return;
    const layer = Math.max(0, Math.trunc(Number(z) || 0));
    ra.data.layer = layer;
    ra.data.zIndex = layer;
    if (ra.el) ra.el.style.zIndex = String(layer);
  }

  function normalizeRuntimeLayerStack() {
    const actors = runtimeLayerActors().slice();
    actors.sort((a, b) => {
      const az = Number(a?.data?.layer ?? a?.data?.zIndex);
      const bz = Number(b?.data?.layer ?? b?.data?.zIndex);
      const av = Number.isFinite(az) ? az : Number(a?.index || 0);
      const bv = Number.isFinite(bz) ? bz : Number(b?.index || 0);
      return av - bv || Number(a?.index || 0) - Number(b?.index || 0);
    });
    actors.forEach((ra, idx) => applyRuntimeActorLayer(ra, idx + 1));
    (runtime.actors || []).forEach(ra => {
      if (ra && ra.data && ra.data.isBackground) applyRuntimeActorLayer(ra, 0);
    });
    runtime._zTop = actors.length;
    runtime._zBottom = actors.length ? 1 : 0;
    return actors;
  }

  function moveRuntimeActorToLayer(ra, targetLayer) {
    if (!ra || !ra.data || ra.data.isBackground) return false;
    const actors = normalizeRuntimeLayerStack();
    const current = actors.indexOf(ra);
    if (current < 0) return false;
    const wanted = Math.max(0, Math.min(actors.length - 1, Math.trunc(Number(targetLayer) || 1) - 1));
    if (wanted !== current) {
      actors.splice(current, 1);
      actors.splice(wanted, 0, ra);
    }
    actors.forEach((item, idx) => applyRuntimeActorLayer(item, idx + 1));
    (runtime.actors || []).forEach(item => {
      if (item && item.data && item.data.isBackground) applyRuntimeActorLayer(item, 0);
    });
    runtime._zTop = actors.length;
    runtime._zBottom = actors.length ? 1 : 0;
    return true;
  }

  function moveRuntimeActorByLayers(ra, delta) {
    if (!ra || !ra.data || ra.data.isBackground) return false;
    const actors = normalizeRuntimeLayerStack();
    const current = actors.indexOf(ra);
    if (current < 0) return false;
    const d = Math.trunc(Number(delta) || 0);
    return moveRuntimeActorToLayer(ra, current + 1 + d);
  }

  function goRuntimeActorBack(ra, steps) {
    const n = Math.max(1, Math.trunc(Number(steps) || 1));
    return moveRuntimeActorByLayers(ra, -n);
  }

  function bringRuntimeActorToFront(ra) {
    const actors = normalizeRuntimeLayerStack();
    return moveRuntimeActorToLayer(ra, actors.length);
  }

  function buildStage(project, sceneIndex) {
    const stage = document.getElementById('play-stage');
    if (!stage) return;
    runtime.stageEl = stage;
    // Rebuild in one DOM operation to avoid repeated layout/paint work on start/restart.
    stage.innerHTML = '';
    runtime._collisionBounds = [];
    runtime._collisionBoundsFrame = -1;
    runtime._collisionDebugEls = new Map();
    runtime._collisionDebugFrame = -1;
    // Full available area — no blue box / fixed frame limiting sprites
    const parent = stage.parentElement;
    const pw = (parent && parent.clientWidth) || window.innerWidth || 360;
    const ph = (parent && parent.clientHeight) || window.innerHeight || 640;
    const lw = Number(runtime._logicalStageW || pw);
    const lh = Number(runtime._logicalStageH || ph);
    const orientation = effectiveStagePresentationOrientation(project);
    // Stage-only orientation: do not wait for or request an Activity rotation.
    // Capture one logical world scale from the current viewport and rotate only the
    // stage presentation when its project orientation differs from the phone shape.
    const geom = stagePresentationGeometry(pw, ph, lw, lh, orientation);
    runtime._playViewportLocked = true;
    runtime._playLockedWorldScale = geom.scale;
    runtime._playLockedLogicalW = lw;
    runtime._playLockedLogicalH = lh;
    runtime._playLockedPresentationOrientation = orientation;
    runtime._playLockedStageW = geom.layoutW;
    runtime._playLockedStageH = geom.layoutH;
    runtime._stagePresentationRotation = geom.rotate;
    const lockedStageW = geom.layoutW;
    const lockedStageH = geom.layoutH;
    const lockedLeft = (pw - geom.visualW) / 2 + (geom.visualW - lockedStageW) / 2;
    const lockedTop = (ph - geom.visualH) / 2 + (geom.visualH - lockedStageH) / 2;
    configureProjectStage(project, lockedStageW, lockedStageH);
    stage.style.width = lockedStageW + 'px';
    stage.style.height = lockedStageH + 'px';
    stage.style.position = 'absolute';
    stage.style.left = lockedLeft + 'px';
    stage.style.top = lockedTop + 'px';
    stage.style.background = '#1A1A1A';
    stage.style.overflow = 'visible';
    stage.style.margin = '0';
    stage.style.transform = 'rotate(' + Number(runtime._stagePresentationRotation || 0) + 'deg)';
    stage.dataset.baseScale = 1;
    stage._stageW = lockedStageW;
    stage._stageH = lockedStageH;
    stage._stageLeft = lockedLeft;
    stage._stageTop = lockedTop;
    stage.dataset.projectOrientation = String(project?.orientation || project?.catrobatStage?.orientation || '');
    stage.dataset.logicalWidth = String(runtime._logicalStageW || pw);
    stage.dataset.logicalHeight = String(runtime._logicalStageH || ph);

    const scene = project.scenes[sceneIndex] || project.scenes[0];
    runtime.actors = [];
    // Persisted Kix Tilemaps are rendered before actors so actor layers stay above them.
    try {
      runtime.tilemaps = Array.isArray(scene?.tilemaps) ? scene.tilemaps : [];
      runtime.tilemap = runtime.tilemaps[0] || null;
      if (runtime.tilemap) {
        const tmLayer=document.createElement('div'); tmLayer.className='kix-tilemap-layer'; tmLayer.style.cssText='position:absolute;left:0;top:0;width:100%;height:100%;z-index:0;pointer-events:none;overflow:visible;'; stage.appendChild(tmLayer); runtime._tilemapLayer=tmLayer;
        const cache={};
        (runtime.tilemaps||[]).forEach(tm=>{const ts=(project.tileSets||[]).find(t=>String(t.id)===String(tm.tileSetId)); if(!ts||!ts.image)return; (tm.layers||[]).filter(l=>l.visible!==false).forEach(layer=>{Object.keys(layer.cells||{}).forEach(key=>{const [tx,ty]=key.split(',').map(Number),idx=Number(layer.cells[key]); if(!Number.isFinite(tx)||!Number.isFinite(ty)||!Number.isFinite(idx))return; const im=cache[ts.id]||(cache[ts.id]=new Image()); const draw=()=>{const cw=Number(tm.cellSize?.w||ts.cellW||32),ch=Number(tm.cellSize?.h||ts.cellH||32);const el=document.createElement('div');el.style.cssText='position:absolute;left:calc(50% + '+(tx*cw)+'px);top:calc(50% - '+(ty*ch)+'px);width:'+cw+'px;height:'+ch+'px;transform:translate(-50%,-50%);background-image:url('+ts.image+');background-repeat:no-repeat;background-size:auto;';el.style.backgroundPosition=(-((idx%Math.max(1,ts.columns||1))*Number(ts.cellW||cw)))+'px '+(-(Math.floor(idx/Math.max(1,ts.columns||1))*Number(ts.cellH||ch)))+'px';tmLayer.appendChild(el);}; if(im.complete)draw();else im.onload=draw;im.src=ts.image;});});});
      }
    } catch(e){ console.warn('tilemap render',e); }
    const fragment = document.createDocumentFragment();
    (scene.actors || []).forEach((a, i) => {
      ensureActorState(a, i);
      const el = document.createElement('div');
      el.className = 'actor-sprite';
      if (a.isCamera) {
        el.style.opacity = '0';
        el.style.pointerEvents = 'none';
        el.dataset.camera = '1';
      }
      if (a.isLayer) {
        el.style.opacity = '0';
        el.dataset.layer = '1';
      }
      el.dataset.actorIdx = i;
      el.style.position = 'absolute';
      el.style.left = '0';
      el.style.top = '0';
      el.style.margin = '0';
      const imgSrc = resolveActorImage(a);
      if (imgSrc) {
        const im = document.createElement('img');
        im.src = imgSrc;
        im.draggable = false;
        im.alt = '';
        im.decoding = 'async';
        im.loading = 'eager';
        im.style.display = 'block';
        im.dataset.rawSrc = imgSrc;
        el.appendChild(im);
      } else {
        // No cyan/green "Objeto" ball — transparent placeholder only.
        el.innerHTML = `<div class="sprite-fallback" style="width:48px;height:48px;border-radius:4px;background:transparent;"></div>`;
        el.dataset.noImage = '1';
      }
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        if (runtime._suppressActorClickUntil && performance.now() < runtime._suppressActorClickUntil) return;
        broadcastTouch(i);
      });
      fragment.appendChild(el);
      runtime.actors.push({ data: a, el, imageEl: el.querySelector ? el.querySelector('img') : null, index: i, id: (a.id != null ? a.id : i) });
      // Layer is assigned once after the complete actor list is built, so the
      // scene array is the single source of truth for initial back-to-front order.
      updateSpriteTransform(runtime.actors[i]);
    });
    stage.appendChild(fragment);
    runtime._stageInner = stage.querySelector('.stage-inner, #stage-actors, .play-actors');
    // Catrobat-compatible initial stack: first non-background actor is the
    // lowest actor layer; every following actor receives a higher layer.
    let nextLayer = 1;
    (runtime.actors || []).forEach(ra => {
      if (ra?.data?.isBackground) applyRuntimeActorLayer(ra, 0);
      else applyRuntimeActorLayer(ra, nextLayer++);
    });
    runtime._zTop = Math.max(0, nextLayer - 1);
    runtime._zBottom = runtime._zTop ? 1 : 0;
    (runtime.actors || []).forEach(ra => {
      try { updateSpriteTransform(ra, true); } catch (_) {}
    });
  }

  
  
  function applyAllColorSwaps(ra, src) {
    if (!ra || !src) return src;
    const list = ra.data._colorSwaps;
    if (!list || !list.length) return src;
    // Apply each swap sequentially on canvas
    let currentSrc = src;
    for (let s = 0; s < list.length; s++) {
      const sw = list[s];
      if (!sw || !sw.de) continue;
      const from = hexToRgb(sw.de);
      const to = hexToRgb(sw.para);
      if (!from || !to) continue;
      const thr = (typeof sw.tolerancia === 'number' && !isNaN(sw.tolerancia)) ? Math.max(0, Math.min(255, sw.tolerancia)) : 40;
      const cacheKey = currentSrc + '|' + sw.de + '|' + sw.para + '|' + thr;
      if (!ra.data._swapCache) ra.data._swapCache = {};
      if (ra.data._swapCache[cacheKey]) {
        currentSrc = ra.data._swapCache[cacheKey];
        continue;
      }
      // Sync path using Image if already complete, else kick async and return last known
      // For cache miss we still need async — queue job
      ra.data._pendingSwap = { src: currentSrc, list, fromIndex: s };
      // Try sync decode only if data URL and we can use createImageBitmap later; for now fire async chain
      (function (baseSrc, fromC, toC, thrV, key, chainFrom) {
        const image = new Image();
        image.crossOrigin = 'anonymous';
        const gen = (ra.data._swapGen = (ra.data._swapGen || 0) + 1);
        image.onload = function () {
          if (ra.data._swapGen !== gen) return;
          try {
            const c = document.createElement('canvas');
            c.width = image.naturalWidth || image.width || 64;
            c.height = image.naturalHeight || image.height || 64;
            const ctx = c.getContext('2d');
            if (ctx) ctx.imageSmoothingEnabled = !appearanceIsPixelArt(ra.data, baseSrc);
            ctx.drawImage(image, 0, 0);
            const data = ctx.getImageData(0, 0, c.width, c.height);
            const d = data.data;
            // Apply ALL remaining swaps from chainFrom on this pixel buffer
            const swaps = ra.data._colorSwaps || [];
            for (let si = chainFrom; si < swaps.length; si++) {
              const sw2 = swaps[si];
              if (!sw2 || !sw2.de) continue;
              const f2 = hexToRgb(sw2.de);
              const t2 = hexToRgb(sw2.para);
              if (!f2 || !t2) continue;
              const thr2 = (typeof sw2.tolerancia === 'number' && !isNaN(sw2.tolerancia)) ? sw2.tolerancia : 40;
              for (let i = 0; i < d.length; i += 4) {
                if (d[i + 3] < 10) continue;
                if (colorDist({ r: d[i], g: d[i + 1], b: d[i + 2] }, f2) <= thr2) {
                  d[i] = t2.r; d[i + 1] = t2.g; d[i + 2] = t2.b;
                }
              }
            }
            ctx.putImageData(data, 0, 0);
            const out = c.toDataURL('image/png');
            // Cache full pipeline from original base
            const fullKey = baseSrc + '|ALL|' + swaps.map(x => x.de + '>' + x.para + '@' + (x.tolerancia || 40)).join(',');
            ra.data._swapCache[fullKey] = out;
      // Memory guard: image filters can otherwise retain many full-size base64 images.
      const cacheKeys = Object.keys(ra.data._swapCache);
      if (cacheKeys.length > 12) delete ra.data._swapCache[cacheKeys[0]];
            if (ra.data._swapBase === baseSrc || !ra.data._swapBase) {
              const im = ra.el && ra.el.querySelector('img');
              if (im) {
                im.dataset.rawSrc = baseSrc;
              }
              if (runtime._imageCache) {
                try {
                  const processed = new Image();
                  processed.decoding = 'async';
                  processed.onload = function () { if (runtime._imageCache) runtime._imageCache.set(out, processed); };
                  processed.src = out;
                } catch (_) {}
              }
              setActorImageStable(ra, out);
              ra.data.image = out;
            }
          } catch (e) { console.warn('multi swap', e); }
        };
        image.onerror = function () {};
        image.src = baseSrc;
      })(src, from, to, thr, cacheKey, s);
      break; // async started for rest of chain
    }
    return currentSrc;
  }

  // Stable visual swap: never replace the currently visible image until the next
  // image is loaded/decoded. Pending loads are shared between actors/animation
  // frames so rapid animation changes do not create a burst of Image decoders.
  function setActorImageStable(ra, src) {
    if (!ra || !ra.el || !src) return;
    let img = ra.el.querySelector('img');
    if (!img) {
      img = document.createElement('img');
      img.draggable = false;
      img.alt = '';
      img.decoding = 'async';
      img.style.display = 'block';
      img.style.opacity = '1';
      ra.el.appendChild(img);
      delete ra.el.dataset.noImage;
    }

    const token = (ra._imageSwapToken = (ra._imageSwapToken || 0) + 1);
    img.dataset.rawSrc = src;

    const cached = runtime._imageCache && runtime._imageCache.get(src);
    const commit = function () {
      if (!ra.el || token !== ra._imageSwapToken) return;
      // The old image remains painted until this exact point.
      img.src = src;
      img.style.opacity = '1';
      ra.data.image = src;
      ra.data._lastGoodImage = src;
      updateSpriteTransform(ra, true);
    };

    if (img.src === src && img.complete && (img.naturalWidth || img.width)) {
      ra.data.image = src;
      ra.data._lastGoodImage = src;
      return;
    }
    if (cached && cached.complete && (cached.naturalWidth || cached.width)) {
      commit();
      return;
    }

    const pending = runtime._imageLoads && runtime._imageLoads.get(src);
    if (pending) {
      pending.then(commit).catch(function () {});
      return;
    }

    const next = new Image();
    next.decoding = 'async';
    const promise = new Promise(function (resolve, reject) {
      next.onload = async function () {
        // Do not await HTMLImageElement.decode() here. On mobile browsers decode()
        // can occupy the main thread for a long time and freeze the game frame.
        if (runtime._imageCache) runtime._imageCache.set(src, next);
        if (runtime._imageLoads) runtime._imageLoads.delete(src);
        resolve(next);
      };
      next.onerror = function () {
        if (runtime._imageLoads) runtime._imageLoads.delete(src);
        reject(new Error('image load failed'));
      };
    });
    if (runtime._imageLoads) runtime._imageLoads.set(src, promise);
    next.src = src;
    promise.then(commit).catch(function () {
      // Keep the previous displayed image on load failure.
    });
  }

  function setActorCostume(ra, src) {
    if (!ra || !ra.el || !src) return;
    const source = assetSrc(src);
    if (!source) return;
    const pkey = appearanceKey(source);
    const explicitPixelArt = ra.data.pixelArtLooks && Object.prototype.hasOwnProperty.call(ra.data.pixelArtLooks,pkey);
    ra.data.pixelArt = explicitPixelArt ? !!ra.data.pixelArtLooks[pkey] : appearanceIsPixelArt(ra.data, source);
    applyPixelArtRendering(ra);
    if(!explicitPixelArt && window.KixPixelArt?.schedule) { try { window.KixPixelArt.schedule(ra.data, source); } catch (_) {} }
    ra.data._swapBase = source;
    const swaps = ra.data._colorSwaps;
    if (swaps && swaps.length) {
      const fullKey = source + '|ALL|' + swaps.map(x => x.de + '>' + x.para + '@' + (x.tolerancia || 40)).join(',');
      if (!ra.data._swapCache) ra.data._swapCache = {};
      if (ra.data._swapCache[fullKey]) {
        setActorImageStable(ra, ra.data._swapCache[fullKey]);
        ra.data.image = ra.data._swapCache[fullKey];
        return;
      }
      // Keep previous displayed image until the processed result is ready.
      applyAllColorSwaps(ra, source);
    } else {
      setActorImageStable(ra, source);
      ra.data.image = source;
    }
  }

  // block: Definir tolerância de cor stores default tolerance on actor
  // (handler also in stepCoroutine)
  function swapSpriteColor(ra, fromHex, toHex, tolerance) {
    // Legacy single-call: append to multi list and reapply
    if (!ra.data._colorSwaps) ra.data._colorSwaps = [];
    const thr = (typeof tolerance === 'number' && !isNaN(tolerance)) ? tolerance : (ra.data && ra.data._colorTolerance != null ? ra.data._colorTolerance : 40);
    // Update existing mapping for same "de" or push new
    const de = String(fromHex || '').replace(/['"]/g, '');
    const para = String(toHex || '').replace(/['"]/g, '');
    let found = false;
    for (let i = 0; i < ra.data._colorSwaps.length; i++) {
      if (String(ra.data._colorSwaps[i].de).toLowerCase() === de.toLowerCase()) {
        ra.data._colorSwaps[i] = { de: de, para: para, tolerancia: thr };
        found = true;
        break;
      }
    }
    if (!found) ra.data._colorSwaps.push({ de: de, para: para, tolerancia: thr });
    // Also keep legacy single pointer as last
    ra.data._colorSwap = { de: de, para: para, tolerancia: thr };
    const base = ra.data._swapBase || (ra.el && ra.el.querySelector('img') && ra.el.querySelector('img').dataset.rawSrc) || ra.data._lastGoodImage || ra.data.image;
    if (base) {
      // Invalidate caches that don't include full chain
      ra.data._swapCache = {};
      setActorCostume(ra, base);
    }
  }



  
  // ===== LOOKS + ANIMATION SYSTEM (v3) =====
  // Visual assets are data, never coroutine state. Animation is ticked by the main game loop,
  // so playing a folder can never block the following script blocks.
  function assetSrc(entry) {
    if (entry == null) return '';
    if (typeof entry === 'string') return entry;
    if (typeof entry === 'object') return String(entry.dataUrl || entry.src || entry.image || entry.url || '');
    return String(entry || '');
  }

  function cleanValue(v) {
    return String(v == null ? '' : v).trim().replace(/^['"]|['"]$/g, '');
  }

  function findFolder(actorData, value) {
    const folders = Array.isArray(actorData && actorData.folders) ? actorData.folders : [];
    const raw = cleanValue(value);
    if (!folders.length) return null;
    if (/^\d+$/.test(raw)) {
      const n = Number(raw);
      return folders[n - 1] || folders[n] || null;
    }
    const low = raw.toLowerCase();
    return folders.find(f => f && cleanValue(f.name).toLowerCase() === low)
      || folders.find(f => f && cleanValue(f.name).toLowerCase().includes(low))
      || null;
  }

  function folderFrames(actorData, value) {
    if (!actorData) return [];
    const f = findFolder(actorData, value);
    if (f) {
      const rawFrames = Array.isArray(f.looks) ? f.looks : (Array.isArray(f.frames) ? f.frames : (Array.isArray(f.sprites) ? f.sprites : (Array.isArray(f.aparencias) ? f.aparencias : [])));
      if (rawFrames.length) return rawFrames.map(assetSrc).filter(Boolean);
    }
    const raw = cleanValue(value).toLowerCase();
    // Backward compatible: a folder can be represented by a look object's .folder field.
    if (raw) {
      const flat = Array.isArray(actorData.looks) ? actorData.looks : [];
      const tagged = flat.filter(x => x && typeof x === 'object' && cleanValue(x.folder).toLowerCase() === raw)
        .map(assetSrc).filter(Boolean);
      if (tagged.length) return tagged;
    }
    // A blank folder name uses the only folder, then Idle, then root looks.
    const folders = Array.isArray(actorData.folders) ? actorData.folders : [];
    if (!raw && folders.length === 1 && Array.isArray(folders[0].looks)) return folders[0].looks.map(assetSrc).filter(Boolean);
    if ((!raw || raw === 'idle' || raw === 'padrao' || raw === 'default') && Array.isArray(actorData.looks)) {
      const root = actorData.looks.map(assetSrc).filter(Boolean);
      if (root.length) return root;
    }
    return [];
  }

  function getFolderFrames(actorData, folderName) {
    return folderFrames(actorData, folderName);
  }

  function appearanceKey(src) {
    const text = String(src || '');
    let hash = 2166136261;
    for (let i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619);
    return String(hash >>> 0);
  }

  function appearanceEntries(actorData) {
    const out = [];
    if (!actorData) return out;
    const root = Array.isArray(actorData.looks) ? actorData.looks : [];
    root.forEach((entry, i) => { const src=assetSrc(entry); if(src) out.push({where:'root',folderIdx:null,idx:i,src}); });
    (Array.isArray(actorData.folders) ? actorData.folders : []).forEach((folder, fi) => {
      (Array.isArray(folder?.looks) ? folder.looks : []).forEach((entry, i) => { const src=assetSrc(entry); if(src) out.push({where:'folder',folderIdx:fi,idx:i,src}); });
    });
    return out;
  }

  function appearanceIsPixelArt(actorData, src) {
    if (!actorData || !src) return false;
    const key=appearanceKey(src);
    const map = actorData.pixelArtLooks && typeof actorData.pixelArtLooks === 'object' ? actorData.pixelArtLooks : {};
    if(Object.prototype.hasOwnProperty.call(map,key)) return map[key]===true;
    const auto = actorData.pixelArtAutoLooks && typeof actorData.pixelArtAutoLooks === 'object' ? actorData.pixelArtAutoLooks : {};
    return auto[key]===true;
  }

  function resolveActorImage(actorData) {
    if (!actorData) return null;
    const entries = appearanceEntries(actorData);
    if (!entries.length) return null;
    const active = actorData.activeAppearance;
    if (active) {
      let found = entries.find(e => e.where === active.where && Number(e.folderIdx ?? -1) === Number(active.folderIdx ?? -1) && Number(e.idx) === Number(active.idx));
      if (!found && active.key) found = entries.find(e => appearanceKey(e.src) === String(active.key));
      if (found) return found.src;
    }
    const image = assetSrc(actorData.image);
    if (image) {
      const found = entries.find(e => e.src === image);
      if (found) return found.src;
    }
    const root = rootLooks(actorData);
    if (root.length) {
      const idx = Math.max(0, Math.min(root.length - 1, Number(actorData.costume) || 0));
      return root[idx] || root[0] || null;
    }
    return entries[0]?.src || null;
  }

  function rootLooks(actorData) {
    return Array.isArray(actorData && actorData.looks) ? actorData.looks.map(assetSrc).filter(Boolean) : [];
  }

  function resolveLook(actorData, value, opts) {
    const o = opts || {};
    const raw = cleanValue(value);
    const looks = rootLooks(actorData);
    if (!looks.length) return null;
    if (o.numericOneBased && /^-?\d+(?:\.\d+)?$/.test(raw)) {
      let n = Math.floor(Number(raw));
      if (n <= 0) n = 1;
      return { index: Math.min(looks.length - 1, n - 1), src: looks[Math.min(looks.length - 1, n - 1)] };
    }
    if (/^\d+$/.test(raw)) {
      const n = Number(raw);
      const idx = o.zeroBased ? n : (n > 0 ? n - 1 : 0);
      const i = Math.max(0, Math.min(looks.length - 1, idx));
      return { index: i, src: looks[i] };
    }
    const low = raw.toLowerCase();
    const names = actorData && actorData.lookNames && typeof actorData.lookNames === 'object' ? actorData.lookNames : {};
    let idx = looks.findIndex((src, i) => {
      const candidates = [names[src], names['root:r:' + i], names['root:' + i], assetSrc((actorData.looks || [])[i])];
      return candidates.some(x => x != null && cleanValue(x).toLowerCase() === low);
    });
    if (idx < 0) idx = looks.findIndex(src => src.toLowerCase().includes(low));
    if (idx >= 0) return { index: idx, src: looks[idx] };
    return null;
  }

  function applyAppearance(ra, value, options) {
    if (!ra || !ra.data) return false;
    const r = resolveLook(ra.data, value, options);
    if (!r) return false;
    const prevCostume = Number(ra.data.costume);
    ra.data.costume = r.index;
    setActorCostume(ra, r.src);
    ra._animBaseAppearance = r.src;
    if (ra.data.isBackground && prevCostume !== r.index) {
      try { (runtime.actors || []).forEach(target => startHatsFor(target, 'When background changes to')); } catch (_) {}
    }
    return true;
  }

  // ===== KIX VISUAL STATE MACHINE (v4) =====
  // Appearance changes are instant state operations. Animations are time-based state machines
  // advanced only by the main game loop. No per-block timer/RAF is allowed to own a coroutine.
  const LOOKS_BLOCK_NAMES = new Set([
    'mudar para fantasia/costume','proxima fantasia','mudar tamanho em','definir tamanho para','mostrar','esconder',
    'mudar efeito grafico em','definir efeito para','limpar efeitos graficos','ir para camada','mudar camada em',
    'mudar transparencia em','definir transparencia para','definir aparencia para numero','definir aparencia para nome',
    'espelhar horizontal','espelhar vertical','trocar cor','definir tolerancia de cor','dizer','fade in','fade out',
    'piscar x vezes','definir brilho','outline','criar emissor de particulas','definir taxa de emissao',
    'quando particula nascer','definir cor da particula','reproduzir animacao','repetir animacao',
    'definir pasta como animacao em loop','parar animacao em loop da pasta','aplicar animacao em loop na pasta',
    'tocar pasta uma vez e parar na ultima aparencia','tocar pasta uma vez e voltar pra aparencia original',
    'definir pasta como aparencia atual','inverter ordem da pasta ao tocar','tocar pasta em loop na velocidade',
    'tocar pasta uma vez na velocidade','parar animacao','proximo quadro da animacao','definir quadro da animacao para',
    'esperar animacao terminar','definir velocidade da animacao para','mudar aparencia para','definir cor',
    'restaurar cor original','mudar aparencia','proxima aparencia','aparencia anterior','trazer para frente',
    'enviar para tras','definir opacidade','mudar opacidade em','aparecer gradualmente','desaparecer gradualmente',
    'definir efeito','mudar efeito em','limpar efeitos','espelhar','piscar','emissor de particulas','tocar pasta',
    'proximo quadro','definir quadro','definir velocidade da animacao','inverter ordem da pasta','tintar sprite',
    'flash de hit','sombra','rastro de movimento','modo de mistura','tocar animacao','tocar animacoes','definir gif como aparencia','tocar gif','parar gif','reiniciar gif'
  ]);

  function normalizeLookBlockName(name) {
    return String(name || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
  }

  function isLooksBlockName(name) {
    const n=normalizeLookBlockName(name);
    if (LOOKS_BLOCK_NAMES.has(n)) return true;
    // Compatibility aliases and future names in the Looks category.
    return n.includes('animacao') || n.includes('aparencia') || n.includes('fantasia') ||
           n.includes('pasta') && (n.includes('tocar') || n.includes('animacao') || n.includes('quadro')) ||
           n.includes('efeito grafico') || n.includes('transparencia');
  }

  function getAnimState(ra) {
    if (!ra._lookAnimState) ra._lookAnimState={folder:'',frames:[],index:0,fps:8,loop:false,elapsed:0,playing:false,done:false,holdLast:false,restore:false,restoreSrc:'',serial:0};
    return ra._lookAnimState;
  }

  function syncLegacyAnimationFields(ra, st) {
    if (!ra || !st) return;
    ra._animPlaying=!!st.playing;
    ra._animDone=!!st.done;
    ra._animFolder=st.folder || null;
    ra._animFrame=Number(st.index)||0;
    ra._animFrames=st.frames ? st.frames.slice() : [];
    ra._animLoop=!!st.loop;
    ra._lookAnim=st; // legacy compatibility: external/debug code can inspect the live state
    if (ra.data) ra.data._animSpeed=Number(st.fps)||8;
  }

  function folderNameFromBlock(blk, ctx, def='Idle') {
    const keys=['pasta','nome','animacao','animação','fantasia'];
    for (const k of keys) {
      try {
        const v=param(blk,k,undefined,ctx);
        if (v!==undefined && v!==null && String(v).trim()!=='') return cleanValue(v);
      } catch(_){ }
    }
    // Some old saved blocks put the folder as the first positional value.
    try {
      const vals=blk && blk.values ? Object.values(blk.values) : [];
      for (const v of vals) if (v!==undefined && v!==null && String(v).trim()!=='') return cleanValue(v);
    } catch(_){ }
    return def;
  }

  function animationSpeedFromBlock(blk,ctx,def=12) {
    const keys=['fps','velocidade','valor','speed'];
    for(const k of keys){ try { const v=Number(param(blk,k,undefined,ctx)); if(Number.isFinite(v)) return Math.max(1,Math.min(240,v)); }catch(_){ } }
    return Math.max(1,Math.min(240,Number(def)||12));
  }

  function formulaBoolParam(blk, keys, def, ctx) {
    for (const k of keys || []) {
      try {
        const raw = blk && blk.values && blk.values[k] != null ? String(blk.values[k]) : '';
        if (!raw) continue;
        const n = formulaNormalizeName(raw.replace(/^['"]|['"]$/g,''));
        if (n === 'nao' || n === 'false' || n === 'falso' || n === '0') return false;
        if (n === 'sim' || n === 'true' || n === 'verdadeiro' || n === '1') return true;
        return !!evalExpr(raw, ctx);
      } catch (_) {}
    }
    return !!def;
  }

  function currentAppearanceSrc(ra) {
    try {
      const img=ra && ra.el && ra.el.querySelector('img');
      if(img && img.dataset && img.dataset.rawSrc) return img.dataset.rawSrc;
      if(ra && ra.data && ra.data._lastGoodImage) return assetSrc(ra.data._lastGoodImage);
      const root=rootLooks(ra && ra.data);
      const i=Math.max(0,Math.min(root.length-1,Number(ra && ra.data && ra.data.costume)||0));
      return root[i] || '';
    } catch(_){ return ''; }
  }

  function isGifSource(src) {
    const s = assetSrc(src).trim().toLowerCase();
    return s.startsWith('data:image/gif') || /\.gif(?:[?#].*)?$/.test(s);
  }

  function getGifSource(ra) {
    if (!ra || !ra.data) return '';
    if (ra.data._gifAnimation && ra.data._gifAnimation.src) return ra.data._gifAnimation.src;
    const src = currentAppearanceSrc(ra);
    return isGifSource(src) ? src : '';
  }

  function restartGif(ra, srcOverride) {
    if (!ra || !ra.el) return false;
    const src = assetSrc(srcOverride || getGifSource(ra));
    if (!isGifSource(src)) return false;
    const img = ra.el.querySelector('img');
    if (!img) { setActorCostume(ra, src); return true; }
    if (!ra.data) ra.data = {};
    ra.data._gifAnimation = { src: src, playing: true, pausedFrame: '' };
    img.dataset.rawSrc = src;
    // Reloading the GIF resource is the portable way to reset an animated GIF's timeline.
    try { img.src = ''; } catch (_) {}
    const restart = () => {
      try { img.src = src; } catch (_) {}
      img.style.opacity = '1';
      ra.data.image = src;
      ra.data._lastGoodImage = src;
    };
    if (typeof requestAnimationFrame === 'function') kixRequestAnimationFrame(restart);
    else kixSetTimeout(restart, 0);
    return true;
  }

  function pauseGif(ra) {
    if (!ra || !ra.el) return false;
    const src = getGifSource(ra);
    if (!isGifSource(src)) return false;
    const img = ra.el.querySelector('img');
    if (!img) return false;
    if (!ra.data) ra.data = {};
    const freeze = () => {
      try {
        if (!img.naturalWidth || !img.naturalHeight) return false;
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        const ctx2d = canvas.getContext('2d');
        if (!ctx2d) return false;
        ctx2d.imageSmoothingEnabled = !appearanceIsPixelArt(ra.data, src);
        ctx2d.drawImage(img, 0, 0);
        const png = canvas.toDataURL('image/png');
        ra.data._gifAnimation = { src: src, playing: false, pausedFrame: png };
        img.src = png;
        img.dataset.rawSrc = src;
        ra.data.image = src;
        return true;
      } catch (_) {
        // A canvas security restriction should not destroy the running GIF.
        return false;
      }
    };
    if (img.complete && img.naturalWidth) return freeze();
    img.addEventListener('load', freeze, { once: true });
    return true;
  }

  function stopLookAnimation(ra, opts) {
    if(!ra) return;
    // Cancel any animation handle created by older Kix builds before using the v4 state machine.
    try { if (ra._animHandle && typeof cancelAnimationFrame === 'function') kixClearTimer(ra._animHandle); } catch (_) {}
    ra._animHandle = null;
    const o=opts||{};
    const st=getAnimState(ra);
    if(st.playing && st.restore && st.restoreSrc) setActorCostume(ra,st.restoreSrc);
    else if(st.playing && st.holdLast && st.frames.length) setActorCostume(ra,st.frames[Math.max(0,st.frames.length-1)]);
    st.playing=false;
    st.elapsed=0;
    if(o.reset) st.index=0;
    if(o.done!==undefined) st.done=!!o.done;
    else if(!o.keepDone) st.done=false;
    if(!o.keepFolder) st.folder='';
    st.restore=false; st.restoreSrc=''; st.holdLast=false;
    syncLegacyAnimationFields(ra,st);
  }

  function warmAnimationFrames(frames) {
    try {
      if (!Array.isArray(frames) || !frames.length) return;
      if (!runtime._animationWarm) runtime._animationWarm = new Set();
      frames.forEach(function(src){
        if (!src || runtime._animationWarm.has(src)) return;
        runtime._animationWarm.add(src);
        if (runtime._imageCache && runtime._imageCache.has(src)) return;
        const im = new Image(); im.decoding = 'async'; im.loading = 'eager'; im.src = src;
        im.onload = function(){ try{ runtime._imageCache && runtime._imageCache.set(src, im); }catch(_){} };
        im.onerror = function(){ try{ runtime._animationWarm.delete(src); }catch(_){} };
      });
    } catch (_) {}
  }

  function startLookAnimation(ra, folderName, opts) {
    if(!ra || !ra.data) return false;
    const o=opts||{};
    const folder=cleanValue(folderName || ra.data._activeFolder || 'Idle') || 'Idle';
    let frames=Array.isArray(o.frames) ? o.frames.map(assetSrc).filter(Boolean) : folderFrames(ra.data,folder);
    frames=frames.filter(Boolean);
    if(!frames.length) {
      console.warn('[Kix] Não foi possível tocar a pasta: '+folder);
      stopLookAnimation(ra,{keepFolder:true});
      return false;
    }
    const fps=Math.max(1,Math.min(240,Number(o.speed!=null?o.speed:(ra.data._animSpeed||12))||12));
    const loop=!!o.loop;
    warmAnimationFrames(frames);
    const st=getAnimState(ra);
    const same=st.playing && st.folder.toLowerCase()===folder.toLowerCase() && st.loop===loop &&
      Math.round(st.fps*100)===Math.round(fps*100) && st.frames.length===frames.length && st.frames.every((x,i)=>x===frames[i]);
    if(same && !o.forceRestart) return true;
    // Capture the appearance before playback, not the possibly mutated frame currently on screen.
    const restoreSrc=o.restoreSrc || currentAppearanceSrc(ra);
    st.folder=folder; st.frames=frames.slice(); st.index=0; st.fps=fps; st.loop=loop; st.elapsed=0;
    st.playing=true; st.done=false; st.holdLast=!!o.holdLast; st.restore=!!o.restore; st.restoreSrc=restoreSrc; st.serial++;
    ra.data._animSpeed=fps;
    ra.data._activeFolder=folder;
    setActorCostume(ra,st.frames[0]);
    syncLegacyAnimationFields(ra,st);
    return true;
  }

  function finishLookAnimation(ra,st) {
    st.index=Math.max(0,st.frames.length-1);
    if(st.restore && st.restoreSrc) setActorCostume(ra,st.restoreSrc);
    else if(st.frames.length) setActorCostume(ra,st.frames[st.index]);
    if(st.restore) {
      const r=resolveLook(ra.data,st.restoreSrc,{numericOneBased:false});
      if(r) ra.data.costume=r.index;
    }
    st.playing=false; st.done=true; st.elapsed=0;
    syncLegacyAnimationFields(ra,st);
  }

  function applyKixEase(t, curve) {
    const p=Math.max(0,Math.min(1,Number(t)||0));
    const c=String(curve||'linear').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ');
    if(c==='linear') return p;
    if(c.includes('suave')||c.includes('smooth')||c.includes('smoothstep')) return p*p*(3-2*p);
    if(c.includes('quad')&&c.includes('in')) return p*p;
    if(c.includes('quad')&&c.includes('out')) return 1-(1-p)*(1-p);
    if(c.includes('quad')) return p<.5?2*p*p:1-Math.pow(-2*p+2,2)/2;
    if(c.includes('cubic')&&c.includes('in')) return p*p*p;
    if(c.includes('cubic')&&c.includes('out')) return 1-Math.pow(1-p,3);
    if(c.includes('cubic')) return p<.5?4*p*p*p:1-Math.pow(-2*p+2,3)/2;
    if(c.includes('quart')) return p<.5?8*p*p*p*p:1-Math.pow(-2*p+2,4)/2;
    if(c.includes('quint')) return p<.5?16*p*p*p*p*p:1-Math.pow(-2*p+2,5)/2;
    if(c.includes('sine')||c.includes('seno')) return 1-Math.cos((p*Math.PI)/2);
    if(c.includes('seno out')) return Math.sin((p*Math.PI)/2);
    if(c.includes('bounce')) { const n1=7.5625,n2=2.75; if(p<1/n2)return n1*p*p; if(p<2/n2){const q=p-1.5/n2;return n1*q*q+.75;} if(p<2.5/n2){const q=p-2.25/n2;return n1*q*q+.9375;} const q=p-2.625/n2;return n1*q*q+.984375; }
    if(c.includes('elastic')) { if(p===0||p===1)return p; return Math.pow(2,-10*p)*Math.sin((p*10-.75)*(2*Math.PI)/3)+1; }
    if(c.includes('back')) { const s1=1.70158,s3=s1+1; return 1+s3*Math.pow(p-1,3)+s1*Math.pow(p-1,2); }
    return p;
  }

  function tickLookAnimations(dt) {
    const delta=Math.max(0,Math.min(250,Number(dt)||0));
    if(!delta || runtime.paused) return;
    const actors=runtime.actors||[];
    const now=performance.now();
    for(let i=0;i<actors.length;i++){
      const ra=actors[i]; if(!ra) continue;
      // Tweens are independent of frame animations. Previously this lived behind the
      // animation-state guard, making "Animar propriedade" silently freeze on idle actors.
      if(ra.data && Array.isArray(ra.data._tweens) && ra.data._tweens.length){
        ra.data._tweens=ra.data._tweens.filter(tw=>{
          const p=Math.max(0,Math.min(1,(now-tw.start)/Math.max(1,tw.duration)));
          const e=applyKixEase(p,tw.curve||'suave');
          const v=Number(tw.from)+(Number(tw.to)-Number(tw.from))*e;
          if(['x','y','rotation','direction','size','opacity'].includes(tw.prop)) ra.data[tw.prop]=v;
          if(['x','y','rotation','size','opacity'].includes(tw.prop)) updateSpriteTransform(ra);
          if(p>=1){try{startHatsFor(ra,'Quando animação terminar');}catch(_){}return false;}
          return true;
        });
      }
      const st=ra._lookAnimState;
      if(!st||!st.playing||!st.frames.length) continue;
      st.elapsed+=delta;
      const frameMs=1000/Math.max(1,st.fps);
      let steps=Math.floor(st.elapsed/frameMs);
      if(steps<=0){syncLegacyAnimationFields(ra,st);continue;}
      st.elapsed-=steps*frameMs;
      if(st.loop){
        st.index=((st.index+steps)%st.frames.length+st.frames.length)%st.frames.length;
        if(st.frames[st.index])setActorCostume(ra,st.frames[st.index]);
      }else{
        const last=st.frames.length-1;
        if(st.index+steps>=last)finishLookAnimation(ra,st);
        else{st.index+=steps;if(st.frames[st.index])setActorCostume(ra,st.frames[st.index]);}
      }
      syncLegacyAnimationFields(ra,st);
    }
  }

  function stopAllLookAnimations(){ (runtime.actors||[]).forEach(ra=>stopLookAnimation(ra)); }

  function setFolderAsAppearance(ra,folderName,reverse=false){
    if(!ra||!ra.data) return false;
    const frames=folderFrames(ra.data,folderName).slice();
    if(reverse) frames.reverse();
    if(!frames.length) return false;
    stopLookAnimation(ra,{reset:true});
    const src=frames[0];
    const root=rootLooks(ra.data);
    const idx=root.indexOf(src);
    if(idx>=0) ra.data.costume=idx;
    ra.data._activeFolder=cleanValue(folderName);
    setActorCostume(ra,src);
    return true;
  }

  function stepAnimationFrame(ra,delta){
    const st=getAnimState(ra);
    const frames=(st.frames&&st.frames.length?st.frames:folderFrames(ra.data,st.folder||ra.data._activeFolder||''));
    if(!frames.length) return false;
    st.frames=frames.slice();
    st.index=((Number(st.index)||0)+delta)%st.frames.length;
    if(st.index<0) st.index+=st.frames.length;
    st.done=false;
    setActorCostume(ra,st.frames[st.index]);
    syncLegacyAnimationFields(ra,st);
    return true;
  }

  function setAnimationFrame(ra,n){
    const st=getAnimState(ra);
    const frames=(st.frames&&st.frames.length?st.frames:folderFrames(ra.data,st.folder||ra.data._activeFolder||''));
    if(!frames.length) return false;
    st.frames=frames.slice();
    st.index=Math.max(0,Math.min(frames.length-1,Math.floor(Number(n)||1)-1));
    st.done=false;
    setActorCostume(ra,st.frames[st.index]);
    syncLegacyAnimationFields(ra,st);
    return true;
  }

  function tickLooksEffects(now){
    const tNow=Number(now)||performance.now();
    (runtime.actors||[]).forEach(ra=>{
      if(!ra||!ra.data||!ra.el) return;
      const a=ra.data;
      const blink=a._blinkSpec;
      if(blink){
        let guard=0;
        while(tNow>=blink.next && blink.left>0 && guard++<16){
          blink.visible=!blink.visible; a.visible=blink.visible; blink.left--; blink.next+=Math.max(16,Number(blink.period)||120);
        }
        if(blink.left<=0){a.visible=true;delete a._blinkSpec;}
        updateSpriteTransform(ra,true);
      }
      const fade=a._fadeSpec;
      if(fade){
        const p=Math.max(0,Math.min(1,(tNow-fade.start)/Math.max(1,fade.dur)));
        const op=fade.from+(fade.to-fade.from)*p;
        a.opacity=op*100; ra.el.style.opacity=String(op);
        if(p>=1){if(fade.hide)a.visible=false; delete a._fadeSpec; updateSpriteTransform(ra,true);}
      }
      if(a._flashUntil && tNow>=a._flashUntil) a._flashUntil=0;
      if (a._shader) refreshShader(ra); else refreshVisualFilter(ra);
    });
  }

  function executeLooksBlock(co,blk,ctx,now){
    if(!co||!co.actor||!co.actor.data) return false;
    const rawName=String(blk&&blk.name||'').trim();
    const n=normalizeLookBlockName(rawName);
    const ra=co.actor,a=ra.data;
    if(!isLooksBlockName(rawName)) return false;
    const num=(keys,def)=>{for(const k of keys){try{const v=param(blk,k,undefined,ctx);if(v!==undefined&&v!==null&&Number.isFinite(Number(v)))return Number(v);}catch(_){}}return def;};
    const str=(keys,def)=>{for(const k of keys){try{const v=paramStr(blk,k,'',ctx);if(v!=='')return cleanValue(v);}catch(_){}}return def;};
    const done=()=>({handled:true,advance:true});

    try {
      // --- animated GIF appearances ---
      if (n === 'definir gif como aparencia') {
        const src = str(['imagem','gif'],'');
        if (!isGifSource(src)) return done();
        stopLookAnimation(ra, { keepDone: true });
        a._gifAnimation = { src: src, playing: true, pausedFrame: '' };
        setActorCostume(ra, src);
        // setActorCostume may reuse an already loaded GIF; force its timeline to frame 0.
        kixSetTimeout(() => restartGif(ra, src), 0);
        return done();
      }
      if (n === 'tocar gif') {
        const src = str(['imagem','gif'], getGifSource(ra));
        if (!isGifSource(src)) return done();
        stopLookAnimation(ra, { keepDone: true });
        setActorCostume(ra, src);
        restartGif(ra, src);
        return done();
      }
      if (n === 'parar gif') { pauseGif(ra); return done(); }
      if (n === 'reiniciar gif') { restartGif(ra); return done(); }

      // --- animations / folders ---
      if(n.includes('quando particula nascer')) return done();
      if(n==='definir pasta como animacao em loop'){
        const f=folderNameFromBlock(blk,ctx); a._loopFolders=a._loopFolders||{}; a._loopFolders[f]=true; return done();
      }
      if(n==='parar animacao em loop da pasta'){
        const f=folderNameFromBlock(blk,ctx,'');
        if(a._loopFolders){for(const k of Object.keys(a._loopFolders)) if(!f||k.toLowerCase()===f.toLowerCase()) delete a._loopFolders[k];}
        const st=getAnimState(ra); if(!f||st.folder.toLowerCase()===f.toLowerCase()) stopLookAnimation(ra);
        return done();
      }
      if(n==='aplicar animacao em loop na pasta'){
        const f=folderNameFromBlock(blk,ctx); a._loopFolders=a._loopFolders||{}; a._loopFolders[f]=true;
        startLookAnimation(ra,f,{loop:true,speed:a._animSpeed||12}); a._activeLoopFolder=f; return done();
      }
      if(n==='reproduzir animacao'){
        const f=folderNameFromBlock(blk,ctx);
        const marked=Object.keys(a._loopFolders||{}).find(k=>k.toLowerCase()===f.toLowerCase());
        startLookAnimation(ra,f,{loop:!!marked,speed:a._animSpeed||12}); a._activeLoopFolder=marked||null; return done();
      }
      if(n==='repetir animacao'){
        const f=folderNameFromBlock(blk,ctx); startLookAnimation(ra,f,{loop:true,speed:a._animSpeed||12}); a._activeLoopFolder=f; return done();
      }
      if(n==='tocar animacao'||n==='tocar animacoes'||n.includes('tocar animacao em loop')){
        const f=folderNameFromBlock(blk,ctx); const mode=str(['modo'],'loop').toLowerCase(); const fps=animationSpeedFromBlock(blk,ctx,a._animSpeed||12);
        const loop= n.includes('em loop') || !(mode.includes('uma')||mode.includes('once'));
        a._animSpeed=fps; startLookAnimation(ra,f,{loop,speed:fps,forceRestart:false}); if(loop)a._activeLoopFolder=f; return done();
      }
      if(n==='tocar pasta em loop na velocidade'||n.includes('tocar pasta em loop na velocidade')){
        const f=folderNameFromBlock(blk,ctx); const fps=animationSpeedFromBlock(blk,ctx,12); a._animSpeed=fps; a._loopFolders=a._loopFolders||{}; a._loopFolders[f]=true;
        startLookAnimation(ra,f,{loop:true,speed:fps,forceRestart:false}); a._activeLoopFolder=f; return done();
      }
      if(n==='tocar pasta uma vez na velocidade'||n.includes('tocar pasta uma vez na velocidade')){
        const f=folderNameFromBlock(blk,ctx); const fps=animationSpeedFromBlock(blk,ctx,12); a._animSpeed=fps;
        startLookAnimation(ra,f,{loop:false,speed:fps,forceRestart:true}); return done();
      }
      if(n==='tocar pasta uma vez e parar na ultima aparencia'||n.includes('parar na ultima')){
        const f=folderNameFromBlock(blk,ctx); startLookAnimation(ra,f,{loop:false,speed:a._animSpeed||12,holdLast:true,forceRestart:true}); return done();
      }
      if(n==='tocar pasta uma vez e voltar pra aparencia original'||n.includes('voltar pra aparencia original')){
        const f=folderNameFromBlock(blk,ctx); startLookAnimation(ra,f,{loop:false,speed:a._animSpeed||12,restore:true,restoreSrc:currentAppearanceSrc(ra),forceRestart:true}); return done();
      }
      if(n==='tocar pasta'){
        const f=folderNameFromBlock(blk,ctx);
        const mode=str(['modo'],'loop').toLowerCase();
        const finish=str(['ao terminar'],'parar').toLowerCase();
        const fps=animationSpeedFromBlock(blk,ctx,a._animSpeed||12);
        const loop=!(mode.includes('uma')||mode.includes('once')||mode.includes('single'));
        const restore=!loop && (finish.includes('voltar') || finish.includes('original'));
        a._animSpeed=fps;
        startLookAnimation(ra,f,{loop,speed:fps,forceRestart:false,restore,restoreSrc:restore?currentAppearanceSrc(ra):''});
        if(loop) a._activeLoopFolder=f; else a._activeLoopFolder=null;
        return done();
      }
      if(n==='definir pasta como aparencia atual'){
        setFolderAsAppearance(ra,folderNameFromBlock(blk,ctx)); return done();
      }
      if(n==='inverter ordem da pasta ao tocar'||n==='inverter ordem da pasta'){
        const f=folderNameFromBlock(blk,ctx); const frames=folderFrames(a,f).slice().reverse(); startLookAnimation(ra,f,{frames,loop:false,speed:a._animSpeed||12,forceRestart:true}); return done();
      }
      if(n==='parar animacao'){stopLookAnimation(ra);a._activeLoopFolder=null;return done();}
      if(n==='reiniciar animacao'){
        const st=getAnimState(ra); const f=st.folder||a._activeLoopFolder||a._activeFolder||'Idle'; startLookAnimation(ra,f,{loop:st.loop||!!a._activeLoopFolder,speed:a._animSpeed||12,forceRestart:true}); return done();
      }
      if(n==='proximo quadro da animacao'||n==='proximo quadro'){stepAnimationFrame(ra,1);return done();}
      if(n==='definir quadro da animacao para'||n==='definir quadro'){setAnimationFrame(ra,num(['numero','número','quadro'],1));return done();}
      if(n==='esperar animacao terminar'){
        const st=getAnimState(ra);
        return st.playing && !st.done ? {handled:true,advance:false} : done();
      }
      if(n==='definir velocidade da animacao para'||n==='definir velocidade da animacao'){
        const fps=animationSpeedFromBlock(blk,ctx,8);a._animSpeed=fps;const st=getAnimState(ra);st.fps=fps;if(st.playing)syncLegacyAnimationFields(ra,st);return done();
      }

      // --- appearance selection ---
      if(n==='mudar para fantasia/costume'||n==='mudar aparencia'||n==='mudar aparencia para'){
        stopLookAnimation(ra,{keepDone:true}); const v=str(['valor','costume','nome','fantasia'],'1'); applyAppearance(ra,v,{zeroBased:rawName==='Mudar aparência'}); return done();
      }
      // --- próxima / anterior aparência (circula pelas aparências da raiz) ---
      if(n==='proxima aparencia'||n==='proxima fantasia'||n==='proxima fantasia/costume'||n==='aparencia anterior'||n==='fantasia anterior'||n==='fantasia anterior/costume'){
        stopLookAnimation(ra,{keepDone:true});
        const dir=(n.indexOf('anterior')>=0)?-1:1, looks=rootLooks(a);
        if(looks.length){
          const cur=Number.isFinite(Number(a.costume))?Number(a.costume):0;
          a.costume=(((cur+dir)%looks.length)+looks.length)%looks.length;
          setActorCostume(ra,looks[a.costume]);
        }
        return done();
      }
      if(n==='definir aparencia para numero'){stopLookAnimation(ra);applyAppearance(ra,num(['numero','número'],1),{numericOneBased:true});return done();}
      if(n==='definir aparencia para nome'||n==='mudar aparencia para nome'){stopLookAnimation(ra);applyAppearance(ra,str(['nome'],'1'),{});return done();}
      if(n==='proxima fantasia'||n==='proxima aparencia'){
        stopLookAnimation(ra);const looks=rootLooks(a);if(looks.length){a.costume=((Number(a.costume)||0)+1)%looks.length;setActorCostume(ra,looks[a.costume]);}return done();
      }
      if(n==='aparencia anterior'){stopLookAnimation(ra);const looks=rootLooks(a);if(looks.length){a.costume=((Number(a.costume)||0)-1+looks.length)%looks.length;setActorCostume(ra,looks[a.costume]);}return done();}

      // --- IA / NPCs: cada NPC possui ID estável e configuração própria ---
      if (n === 'criar npc') {
        runtime._npcs = runtime._npcs || {};
        const id = String(paramStr(blk,'id','npc_'+runtimeRandom().toString(36).slice(2,8),ctx)).replace(/["']/g,'') || ('npc_'+runtimeRandom().toString(36).slice(2,8));
        runtime._npcs[id] = runtime._npcs[id] || {id, actor: a.name, state:'idle', behavior:'idle', target:'', objective:'', speed:60, vision:{distance:180,angle:120}, attackRange:40, detectionRange:180, memory:3000, personality:'balanced', aggression:50, intelligence:50, difficulty:'normal', variables:{}};
        a.npcId=id; a.npcConfig=runtime._npcs[id]; return done();
      }
      if (n.includes('npc ') || n.startsWith('definir comportamento do npc') || n.startsWith('definir estado do npc') || n.startsWith('definir objetivo do npc') || n.startsWith('definir alvo do npc')) {
        runtime._npcs = runtime._npcs || {};
        const id = String(paramStr(blk,'id',a.npcId || '',ctx)).replace(/["']/g,'') || a.npcId;
        if (!id) return done();
        const npc = runtime._npcs[id] || (runtime._npcs[id]={id,actor:a.name,variables:{}}); a.npcId=id; a.npcConfig=npc;
        const val=(k,d)=>paramStr(blk,k,d,ctx);
        if(n==='definir comportamento do npc') npc.behavior=val('comportamento','idle');
        else if(n==='definir estado do npc') npc.state=val('estado','idle');
        else if(n==='definir objetivo do npc') npc.objective=val('objetivo','');
        else if(n==='definir alvo do npc') npc.target=val('alvo','');
        else if(n==='npc perseguir alvo'){npc.behavior='chase';npc.target=val('alvo',npc.target);npc.speed=Number(param(blk,'velocidade',60,ctx))||60;}
        else if(n==='npc fugir do alvo'){npc.behavior='flee';npc.target=val('alvo',npc.target);npc.speed=Number(param(blk,'velocidade',60,ctx))||60;}
        else if(n==='npc patrulhar rota'){npc.behavior='patrol';npc.route=val('rota','');npc.speed=Number(param(blk,'velocidade',60,ctx))||60;}
        else if(n==='npc seguir caminho'){npc.behavior='path';npc.destination=val('destino','');npc.speed=Number(param(blk,'velocidade',60,ctx))||60;}
        else if(n==='npc tomar decisão'){npc.lastDecision=runtimeNow();}
        else if(n==='npc parar'){npc.behavior='idle';npc.velocity={x:0,y:0};}
        else if(n==='npc atacar alvo'){npc.action='attack';npc.target=val('alvo',npc.target);}
        else if(n==='npc defender'){npc.action='defend';}
        else if(n==='npc esquivar'){npc.action='dodge';}
        else if(n==='npc chamar aliados'){npc.action='call_allies';npc.callDistance=Number(param(blk,'distância',180,ctx))||180;}
        else if(n==='npc evitar obstáculo'){npc.avoidDistance=Number(param(blk,'distância',80,ctx))||80;npc.avoidObstacles=true;}
        else if(n==='npc conversar'){npc.dialogue=val('texto','');}
        else if(n==='npc emitir som'){npc.sound=val('som','');}
        else if(n==='npc usar habilidade'){npc.skill=val('habilidade','');}
        else if(n==='npc usar item'){npc.item=val('item','');}
        else if(n==='npc trocar estado automaticamente'){npc.autoState=true;}
        else if(n==='npc copiar configuração'){const src=String(val('origem','')).replace(/["']/g,'');if(runtime._npcs[src]) Object.assign(npc,JSON.parse(JSON.stringify(runtime._npcs[src])),{id});}
        else if(n==='npc definir variável'){npc.variables[val('nome','variavel')]=val('valor','');}
        else if(n==='definir visão do npc'){npc.vision={distance:Number(param(blk,'distância',180,ctx))||180,angle:Number(param(blk,'ângulo',120,ctx))||120};}
        else if(n==='definir alcance de ataque do npc') npc.attackRange=Number(param(blk,'distância',40,ctx))||40;
        else if(n==='definir alcance de detecção do npc') npc.detectionRange=Number(param(blk,'distância',180,ctx))||180;
        else if(n==='definir memória do npc') npc.memory=Number(param(blk,'tempo',3000,ctx))||3000;
        else if(n==='npc lembrar alvo') npc.memoryTarget=val('alvo',npc.target);
        else if(n==='npc esquecer alvo') npc.memoryTarget='';
        else if(n==='definir personalidade do npc') npc.personality=val('personalidade','balanced');
        else if(n==='definir agressividade do npc') npc.aggression=Math.max(0,Math.min(100,Number(param(blk,'valor',50,ctx))||50));
        else if(n==='definir inteligência do npc') npc.intelligence=Math.max(0,Math.min(100,Number(param(blk,'valor',50,ctx))||50));
        else if(n==='definir dificuldade do npc') npc.difficulty=val('nível','normal');
        else if(n==='definir reação do npc') npc.reactions=Object.assign({},npc.reactions,{[val('evento','evento')]:val('ação','ação')});
        return done();
      }

      // --- Shaders: efeitos reais e leves usando filtros CSS; parâmetros ficam no ator ---
      if (n === 'aplicar shader ao ator' || n === 'aplicar shader na cena inteira' || n === 'aplicar blur' || n === 'aplicar contorno' || n === 'aplicar distorção de onda' || n === 'aplicar pixelização' || n === 'aplicar escala de cinza' || n === 'aplicar sépia') {
        const shader = a._shader || (a._shader={effects:[],uniforms:{},time:0,resolution:{w:runtime.stageEl?runtime.stageEl._stageW:360,h:runtime.stageEl?runtime.stageEl._stageH:640},paused:false});
        if(n==='aplicar blur') shader.effects.push('blur('+Math.max(0,Number(param(blk,'raio',2,ctx))||2)+'px)');
        else if(n==='aplicar contorno') shader.effects.push('drop-shadow(0 0 2px '+paramStr(blk,'cor','#fff',ctx)+')');
        else if(n==='aplicar escala de cinza') shader.effects.push('grayscale(1)');
        else if(n==='aplicar sépia') shader.effects.push('sepia(1)');
        else if(n==='aplicar pixelização') { const px=Math.max(1,Number(param(blk,'tamanho',4,ctx))||4); shader.effects.push('contrast(1.15)'); shader.pixelSize=px; }
        else if(n==='aplicar distorção de onda') shader.wave=Number(param(blk,'amplitude',4,ctx))||4;
        else shader.active=true;
        refreshShader(ra);
        if(n==='aplicar shader na cena inteira') { runtime._sceneShader=Object.assign({},shader,{_sourceActorId:a.id||a.name||''}); refreshSceneShader(); }
        return done();
      }
      if(n==='remover shader') { const oldShader=a._shader; a._shader=null; if(ra.el) { refreshVisualFilter(ra); ra.el.style.removeProperty('image-rendering'); } if(runtime._sceneShader && runtime._sceneShader._sourceActorId===String(a.id||a.name||'')) runtime._sceneShader=null; else if(runtime._sceneShader===oldShader) runtime._sceneShader=null; refreshSceneShader(); return done(); }
      if(n==='definir uniform do shader' || n==='definir uniform texto') { const sh=a._shader||(a._shader={effects:[],uniforms:{}}); sh.uniforms[paramStr(blk,'nome','u_value',ctx)]=param(blk,'valor',0,ctx); refreshShader(ra); return done(); }
      if(n==='definir tempo do shader') { const sh=a._shader||(a._shader={effects:[],uniforms:{}}); sh.time=Number(param(blk,'valor',0,ctx))||0; refreshShader(ra); if(runtime._sceneShader) refreshSceneShader(); return done(); }
      if(n==='definir intensidade do efeito') { const sh=a._shader||(a._shader={effects:[],uniforms:{}}); sh.intensity=Math.max(0,Math.min(1,Number(param(blk,'valor',1,ctx))||1)); refreshShader(ra); return done(); }
      if(n==='definir resolução do shader') { const sh=a._shader||(a._shader={effects:[],uniforms:{}}); sh.resolution={w:Number(param(blk,'largura',360,ctx))||360,h:Number(param(blk,'altura',640,ctx))||640}; refreshShader(ra); return done(); }
      if(n==='shader personalizado (glsl)') { const sh=a._shader||(a._shader={effects:[],uniforms:{}}); sh.glsl=paramStr(blk,'código','',ctx); sh.custom=true; refreshShader(ra); return done(); }
      if(n==='pausar shader'){if(a._shader)a._shader.paused=true;return done();}
      if(n==='retomar shader'){if(a._shader)a._shader.paused=false;return done();}

      // --- visuals/effects, all intentionally non-blocking ---
      if(n==='mostrar'){a.visible=true;updateSpriteTransform(ra,true);return done();}
      if(n==='esconder'){a.visible=false;updateSpriteTransform(ra,true);return done();}
      if(n==='mudar tamanho em'){
        const current=Number.isFinite(Number(a.size))?Number(a.size):100;
        const delta=num(['valor'],0);
        a.size=Math.max(1,Math.min(1000,current+(Number.isFinite(Number(delta))?Number(delta):0)));
        updateSpriteTransform(ra,true);
        return done();
      }
      if(n==='definir tamanho para'){
        const value=num(['valor'],100);
        a.size=Math.max(1,Math.min(1000,Number.isFinite(Number(value))?Number(value):100));
        updateSpriteTransform(ra,true);
        return done();
      }
      if(n==='definir opacidade'){a.opacity=Math.max(0,Math.min(100,num(['valor'],100)));ra.el.style.opacity=String(a.opacity/100);return done();}
      if(n==='mudar opacidade em'){a.opacity=Math.max(0,Math.min(100,(Number(a.opacity)==null?100:Number(a.opacity))+num(['valor'],10)));ra.el.style.opacity=String(a.opacity/100);return done();}
      if(n==='definir transparencia para'){const t=Math.max(0,Math.min(100,num(['valor'],0)));a.transparency=t;a.opacity=100-t;ra.el.style.opacity=String(a.opacity/100);return done();}
      if(n==='mudar transparencia em'){const deltaRaw=num(['valor'],10);const delta=Number.isFinite(deltaRaw)?deltaRaw:10;setActorTransparency(ra,Number(a.transparency||0)+delta);return done();}
      if(n==='ir para camada'){
        moveRuntimeActorToLayer(ra, Number(num(['camada','valor'],1)) || 1);
        return done();
      }
      if(n==='mudar camada em'){
        moveRuntimeActorByLayers(ra, num(['valor'],1));
        return done();
      }
      if(n==='trazer para frente'){ bringRuntimeActorToFront(ra); return done(); }
      if(n==='enviar para tras'){ moveRuntimeActorByLayers(ra, -1); return done(); }
      if(n==='espelhar horizontal'||n==='espelhar vertical'||n==='espelhar'){const e=str(['eixo'],n.includes('vertical')?'vertical':'horizontal').toLowerCase();if(e.includes('vert'))a.flipY=!a.flipY;else a.flipX=!a.flipX;updateSpriteTransform(ra,true);return done();}
      if(n==='piscar'||n==='piscar x vezes'){const vezes=Math.max(1,Math.floor(num(['vezes'],3)));const period=Math.max(16,n==='piscar'?num(['segundos'],.12)*1000:240);a._blinkSpec={left:vezes*2,period,next:now,visible:true};return done();}
      if(n==='fade in'||n==='aparecer gradualmente'){const sec=Math.max(.01,num(['segundos'],.5));a.visible=true;a._fadeSpec={from:0,to:1,start:now,dur:sec*1000};return done();}
      if(n==='fade out'||n==='desaparecer gradualmente'){const sec=Math.max(.01,num(['segundos'],.5));a._fadeSpec={from:(Number(a.opacity)==null?1:Number(a.opacity)/100),to:0,start:now,dur:sec*1000,hide:true};return done();}
      if(n==='definir brilho'){a.brightness=Math.max(0,num(['valor'],100));refreshVisualFilter(ra);return done();}
      if(n==='outline'){a.outline={color:str(['cor'],'#fff'),width:Math.max(0,num(['espessura'],2))};refreshVisualFilter(ra);return done();}
      if(n==='limpar efeitos'||n==='limpar efeitos graficos'){a.effects={};a.brightness=100;a.outline=null;a._tint='';a._tintFilter='';a._shadow=null;a.blendMode='';if(ra.el){ra.el.style.filter='';ra.el.style.mixBlendMode='';}return done();}
      if(n==='definir efeito para'||n==='definir efeito'||n==='mudar efeito grafico em'||n==='mudar efeito em'){const e=str(['efeito'],'brightness').toLowerCase();const v=num(['valor'],0);a.effects=a.effects||{};a.effects[e]=v;if(e.includes('brilho'))a.brightness=v;refreshVisualFilter(ra);return done();}
      if(n==='trocar cor'||n==='definir cor'){swapSpriteColor(ra,str(['de','origem'],'#ffffff'),str(['para','destino'],'#000000'),Math.max(0,Math.min(255,num(['tolerancia','tolerância'],a._colorTolerance||40))));return done();}
      if(n==='definir tolerancia de cor'){a._colorTolerance=Math.max(0,Math.min(255,num(['valor','tolerancia','tolerância'],40)));return done();}
      if(n==='restaurar cor original'){a._colorSwaps=[];a._swapCache={};const base=resolveActorImage(a)||rootLooks(a)[Number(a.costume)||0]||a._origImage||a._lastGoodImage;if(base)setActorCostume(ra,base);return done();}
      if(n==='dizer'||n.startsWith('dizer ')){
        const txt=paramStr(blk,'texto',paramStr(blk,'mensagem','...',ctx),ctx);const sec=Math.max(.1,num(['segundos'],2));let b=ra.el.querySelector('.say-bubble');
        if(!b){b=document.createElement('div');b.className='say-bubble';b.style.cssText='position:absolute;left:50%;bottom:100%;transform:translateX(-50%);background:#fff;color:#222;padding:4px 8px;border-radius:8px;font-size:11px;white-space:nowrap;margin-bottom:4px;z-index:20';ra.el.appendChild(b);} b.textContent=txt;kixClearTimer(b._kixTimer);b._kixTimer=kixSetTimeout(()=>{try{b.remove();}catch(_){}},sec*1000);return done();
      }
      if(n==='criar emissor de particulas'||n==='emissor de particulas'){a._emitter=a._emitter||{id:'em_'+runtimeNow().toString(36),active:true,rate:12,color:'#FFD700',size:6,speed:50,life:900,_acc:0};a._emitter.active=true;return done();}
      if(n==='definir taxa de emissao'){a._emitter=a._emitter||{active:true,rate:12,color:'#FFD700',size:6,speed:50,life:900,_acc:0};a._emitter.rate=Math.max(0,num(['valor','taxa'],12));return done();}
      if(n==='definir cor da particula'){a._emitter=a._emitter||{active:true,rate:12,color:'#FFD700',size:6,speed:50,life:900,_acc:0};a._emitter.color=str(['cor'],'#FFD700');return done();}
      if(n==='tintar sprite'){a._tint=str(['cor'],'#ff0000');a._tintStrength=Math.max(0,Math.min(1,num(['intensidade'],50)/100));refreshVisualFilter(ra);return done();}
      if(n==='flash de hit'){a._flashUntil=now+Math.max(1,num(['frames'],3))*32;refreshVisualFilter(ra);return done();}
      if(n==='sombra'){a._shadow={color:str(['cor'],'rgba(0,0,0,.45)'),x:num(['offsetX'],4),y:num(['offsetY'],6),blur:num(['blur'],6)};refreshVisualFilter(ra);return done();}
      if(n==='rastro de movimento'){a._trail={opacity:Math.max(.05,Math.min(1,num(['opacidade'],40)/100)),last:[],enabled:true};return done();}
      if(n==='modo de mistura'){const m=str(['modo'],'normal');a.blendMode=m;ra.el.style.mixBlendMode=m==='add'?'plus-lighter':m;return done();}
      runtimeDiagnostic('UNSUPPORTED_LOOKS_BRICK', `Brick Looks não suportado no runtime Android: ${rawName}`, {block:rawName});
      return done();
    } catch(e) {
      console.warn('[Kix] Looks block safely skipped:',rawName,e);
      try{reportEngineError({actor:a.name,error:e,block:rawName});}catch(_){ }
      return done();
    }
  }

  function ensureKixShaderDefs() {
    let svg=document.getElementById('kix-shader-defs');
    if(svg) return svg;
    try {
      svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
      svg.id='kix-shader-defs';
      svg.setAttribute('aria-hidden','true');
      svg.style.cssText='position:absolute;width:0;height:0;overflow:hidden;pointer-events:none;';
      svg.innerHTML='<defs><filter id=\"kix-wave-filter\" x=\"-20%\" y=\"-20%\" width=\"140%\" height=\"140%\"><feTurbulence id=\"kix-wave-noise\" type=\"fractalNoise\" baseFrequency=\"0.012 0.08\" numOctaves=\"1\" seed=\"2\" result=\"noise\"/><feDisplacementMap id=\"kix-wave-map\" in=\"SourceGraphic\" in2=\"noise\" scale=\"0\" xChannelSelector=\"R\" yChannelSelector=\"G\"/></filter></defs>';
      document.body.appendChild(svg);
    } catch (_) {}
    return svg;
  }
  function classifyGlslToCss(glsl) {
    const t=String(glsl||'').toLowerCase(); const fx=[];
    if(/grayscale|luminance|dot\s*\(.*0\.299/.test(t)) fx.push('grayscale(1)');
    if(/sepia/.test(t)) fx.push('sepia(1)');
    if(/invert/.test(t)) fx.push('invert(1)');
    if(/brightness/.test(t)) fx.push('brightness(1.2)');
    if(/contrast/.test(t)) fx.push('contrast(1.2)');
    if(/saturat/.test(t)) fx.push('saturate(1.35)');
    if(/hue.?rotate|hue/.test(t)) fx.push('hue-rotate(45deg)');
    if(/blur|gaussian/.test(t)) fx.push('blur(2px)');
    return fx;
  }
  function shaderCssFilters(sh) {
    const intensity=sh.intensity==null?1:Math.max(0,Math.min(1,Number(sh.intensity)||0));
    let fx=[...(sh.effects||[]),...(sh.filters||[])].map(x=>String(x));
    fx=fx.map(x=>{
      const m=x.match(/^blur\(([-+0-9.]+)px\)$/i);
      return m ? 'blur('+(Math.max(0,Number(m[1])||0)*intensity)+'px)' : x;
    });
    if(sh.custom && sh.glsl && !sh._webglReady) fx.push(...classifyGlslToCss(sh.glsl));
    const u=sh.uniforms||{};
    const brightness=Number(u.brightness ?? u.u_brightness); if(Number.isFinite(brightness)) fx.push('brightness('+Math.max(.05,1+brightness*intensity)+')');
    const contrast=Number(u.contrast ?? u.u_contrast); if(Number.isFinite(contrast)) fx.push('contrast('+Math.max(.05,contrast)+')');
    return fx.filter(Boolean);
  }

  // --- Real custom GLSL path -------------------------------------------------
  // Standard effects use CSS filters because they are fast and deterministic.
  // A user supplied GLSL fragment shader, however, is compiled and rendered on
  // a WebGL canvas instead of merely being classified by keywords. This keeps
  // the block honest: valid GLSL changes pixels, invalid GLSL falls back to a
  // visible CSS approximation and never breaks the scene.
  const KIX_GLSL_VERTEX = 'attribute vec2 a_position; attribute vec2 a_uv; varying vec2 v_texCoord; void main(){ v_texCoord=a_uv; gl_Position=vec4(a_position,0.0,1.0); }';
  function ensureShaderCanvas(ra){
    if(!ra||!ra.el) return null;
    let c=ra.el.querySelector('.kix-shader-canvas');
    if(c) return c;
    c=document.createElement('canvas');
    c.className='kix-shader-canvas';
    c.setAttribute('aria-hidden','true');
    c.style.cssText='position:absolute;inset:0;width:100%;height:100%;display:none;pointer-events:none;';
    ra.el.insertBefore(c,ra.el.firstChild||null);
    return c;
  }
  function compileKixShader(ra,sh){
    const c=ensureShaderCanvas(ra); if(!c||!sh||!sh.glsl) return null;
    const src=String(sh.glsl||'').trim();
    if(!src) return null;
    if(sh._glProgram && sh._glSource===src) return sh._glProgram;
    let gl=sh._gl;
    if(!gl){
      try{ gl=c.getContext('webgl',{premultipliedAlpha:true,alpha:true,antialias:false})||c.getContext('experimental-webgl'); }catch(_){gl=null;}
      if(!gl) return null; sh._gl=gl;
    }
    const needed=[];
    if(!/uniform\s+sampler2D\s+u_texture\s*;/.test(src)) needed.push('uniform sampler2D u_texture;');
    if(!/uniform\s+vec2\s+u_resolution\s*;/.test(src)) needed.push('uniform vec2 u_resolution;');
    if(!/uniform\s+float\s+u_time\s*;/.test(src)) needed.push('uniform float u_time;');
    if(!/uniform\s+float\s+u_intensity\s*;/.test(src)) needed.push('uniform float u_intensity;');
    if(!/uniform\s+float\s+u_value\s*;/.test(src)) needed.push('uniform float u_value;');
    const fragHeader=['precision mediump float;',...needed,'varying vec2 v_texCoord;'].join('\n');
    let frag=src;
    if(!/\bvoid\s+main\s*\(/.test(frag) && /\bmainImage\s*\(/.test(frag)){
      frag += '\nvoid main(){ mainImage(gl_FragColor, v_texCoord*u_resolution); }';
    }
    // Common Shadertoy names are mapped to the runtime uniforms.
    const macros=[];
    if(!/\b(iTime)\b/.test(src)) macros.push('#define iTime u_time');
    if(!/\b(iResolution)\b/.test(src)) macros.push('#define iResolution u_resolution');
    if(!/\b(iChannel0)\b/.test(src)) macros.push('#define iChannel0 u_texture');
    if(!/\b(iIntensity)\b/.test(src)) macros.push('#define iIntensity u_intensity');
    if(!/\b(iValue)\b/.test(src)) macros.push('#define iValue u_value');
    frag='// Kix GLSL compatibility\n'+fragHeader+'\n'+macros.join('\n')+'\n'+frag;
    const vs=gl.createShader(gl.VERTEX_SHADER), fs=gl.createShader(gl.FRAGMENT_SHADER);
    gl.shaderSource(vs,KIX_GLSL_VERTEX); gl.compileShader(vs);
    gl.shaderSource(fs,frag); gl.compileShader(fs);
    if(!gl.getShaderParameter(vs,gl.COMPILE_STATUS)||!gl.getShaderParameter(fs,gl.COMPILE_STATUS)){
      sh._glError=String(gl.getShaderInfoLog(fs)||gl.getShaderInfoLog(vs)||'GLSL compile failed');
      try{gl.deleteShader(vs);gl.deleteShader(fs);}catch(_){}
      sh._glProgram=null; sh._glSource=src; return null;
    }
    const program=gl.createProgram(); gl.attachShader(program,vs); gl.attachShader(program,fs); gl.linkProgram(program);
    if(!gl.getProgramParameter(program,gl.LINK_STATUS)){ sh._glError=String(gl.getProgramInfoLog(program)||'GLSL link failed'); try{gl.deleteProgram(program);}catch(_){} return null; }
    sh._glProgram=program; sh._glSource=src; sh._glError='';
    sh._glLoc={pos:gl.getAttribLocation(program,'a_position'),uv:gl.getAttribLocation(program,'a_uv'),tex:gl.getUniformLocation(program,'u_texture'),res:gl.getUniformLocation(program,'u_resolution'),time:gl.getUniformLocation(program,'u_time'),intensity:gl.getUniformLocation(program,'u_intensity'),value:gl.getUniformLocation(program,'u_value')};
    return program;
  }
  function renderKixGlsl(ra,sh){
    if(!ra||!ra.el||!sh||!sh.custom||!sh.glsl||sh.paused) return false;
    const img=ra.el.querySelector('img'); const c=ensureShaderCanvas(ra);
    if(!img||!c||!img.complete||!(img.naturalWidth||img.width)) return false;
    const program=compileKixShader(ra,sh); if(!program||!sh._gl) return false;
    const gl=sh._gl,w=img.naturalWidth||img.width||1,h=img.naturalHeight||img.height||1;
    if(c.width!==w||c.height!==h){c.width=w;c.height=h;}
    gl.viewport(0,0,w,h); gl.useProgram(program);
    let buf=sh._glBuf; if(!buf){buf=sh._glBuf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,0,0,1,-1,1,0,-1,1,0,1,1,1,1,1]),gl.STATIC_DRAW);} else gl.bindBuffer(gl.ARRAY_BUFFER,buf);
    const L=sh._glLoc||{};
    if(L.pos>=0){gl.enableVertexAttribArray(L.pos);gl.vertexAttribPointer(L.pos,2,gl.FLOAT,false,16,0);}
    if(L.uv>=0){gl.enableVertexAttribArray(L.uv);gl.vertexAttribPointer(L.uv,2,gl.FLOAT,false,16,8);}
    let tex=sh._glTex; if(!tex){tex=sh._glTex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);} else gl.bindTexture(gl.TEXTURE_2D,tex);
    try{gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,true);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,img);}catch(_){return false;}
    if(L.tex)gl.uniform1i(L.tex,0); if(L.res)gl.uniform2f(L.res,w,h); if(L.time)gl.uniform1f(L.time,Number(sh.time)||0); if(L.intensity)gl.uniform1f(L.intensity,Number(sh.intensity==null?1:sh.intensity)||1); if(L.value)gl.uniform1f(L.value,Number(sh.uniforms?.u_value ?? sh.uniforms?.value ?? 0)||0);
    // Best-effort binding of declared numeric uniforms.
    const decl=srcUniforms(sh.glsl); for(const u of decl){ const loc=gl.getUniformLocation(program,u.name); const v=sh.uniforms&&sh.uniforms[u.name]!=null?sh.uniforms[u.name]:0; const nums=Array.isArray(v)?v.map(Number):String(v).split(',').map(Number); if(!loc)continue; if(u.type==='float')gl.uniform1f(loc,Number(nums[0])||0); else if(u.type==='int'||u.type==='bool')gl.uniform1i(loc,Number(nums[0])||0); else if(u.type==='vec2')gl.uniform2f(loc,Number(nums[0])||0,Number(nums[1])||0); else if(u.type==='vec3')gl.uniform3f(loc,Number(nums[0])||0,Number(nums[1])||0,Number(nums[2])||0); else if(u.type==='vec4')gl.uniform4f(loc,Number(nums[0])||0,Number(nums[1])||0,Number(nums[2])||0,Number(nums[3])||0); }
    gl.drawArrays(gl.TRIANGLE_STRIP,0,4);
    img.style.display='none'; c.style.display='block'; sh._webglReady=true; return true;
  }
  function srcUniforms(src){ const out=[]; const re=/uniform\s+(float|int|bool|vec2|vec3|vec4)\s+([A-Za-z_][A-Za-z0-9_]*)\s*;/g; let m; while((m=re.exec(String(src||''))))out.push({type:m[1],name:m[2]}); return out; }
  function shaderPresetFilters(name){
    const n=String(name||'').toLowerCase();
    if(n.includes('blur')) return ['blur(4px)']; if(n.includes('contorno')||n.includes('outline')) return ['drop-shadow(0 0 3px #fff)'];
    if(n.includes('pixel')) return ['contrast(1.12)']; if(n.includes('cinza')||n.includes('gray')) return ['grayscale(1)']; if(n.includes('sépia')||n.includes('sepia')) return ['sepia(1)'];
    if(n.includes('invert')) return ['invert(1)']; if(n.includes('brightness')||n.includes('brilho')) return ['brightness(1.2)']; if(n.includes('contrast')) return ['contrast(1.25)'];
    if(n.includes('satur')) return ['saturate(1.35)']; return [];
  }
  function refreshShader(ra) {
    if (!ra || !ra.el) return;
    const sh=ra.data && ra.data._shader;
    if(!sh){ refreshVisualFilter(ra); ra.el.style.removeProperty('image-rendering'); ra.el.style.removeProperty('--kix-shader-time'); const c=ra.el.querySelector('.kix-shader-canvas'); const i=ra.el.querySelector('img'); if(c)c.style.display='none'; if(i)i.style.display='block'; return; }
    const customOk=renderKixGlsl(ra,sh);
    const fx=shaderCssFilters(sh);
    const hasWave=Number(sh.wave||0)>0 && !sh.paused;
    const defs=hasWave ? ensureKixShaderDefs() : null;
    if(hasWave && defs){
      const map=defs.querySelector('#kix-wave-map'), noise=defs.querySelector('#kix-wave-noise');
      const amp=Math.max(0,Math.min(60,Number(sh.wave)||0))*Math.max(.1,Number(sh.intensity==null?1:sh.intensity)||1);
      if(map) map.setAttribute('scale',String(amp)); if(noise) noise.setAttribute('seed',String(Math.max(1,Math.round((Number(sh.time)||0)%100000)))); fx.push('url(#kix-wave-filter)');
    }
    if(Number(sh.pixelSize||sh.pixel||0)>1){ ra.el.style.imageRendering='pixelated'; fx.push('contrast(1.12)'); } else ra.el.style.removeProperty('image-rendering');
    if(sh.enabled && !fx.length && !customOk && !sh.custom) fx.push('saturate(1.04) contrast(1.03)');
    const target=customOk ? ra.el.querySelector('.kix-shader-canvas') : ra.el;
    if(target) target.style.filter=fx.join(' ')||'';
    if(customOk && fx.length) ra.el.style.filter=''; else if(!customOk) ra.el.style.filter=fx.join(' ')||'';
    ra.el.style.setProperty('--kix-shader-time',String(Number(sh.time)||0));
  }
  function refreshSceneShader() {
    const stage=runtime.stageEl || document.getElementById('play-stage');
    if(!stage) return;
    const sh=runtime._sceneShader;
    if(!sh){ stage.style.removeProperty('filter'); stage.style.removeProperty('image-rendering'); return; }
    const fx=shaderCssFilters(sh);
    if(Number(sh.wave||0)>0) { ensureKixShaderDefs(); fx.push('url(#kix-wave-filter)'); }
    if(Number(sh.pixelSize||sh.pixel||0)>1) stage.style.imageRendering='pixelated';
    else stage.style.removeProperty('image-rendering');
    stage.style.filter=fx.join(' ')||'';
  }

  function refreshVisualFilter(ra) {
    if (!ra || !ra.el) return;
    const a=ra.data||{};
    const f=[];
    if(a._tintFilter) f.push(a._tintFilter);
    if(a.brightness!=null && Number(a.brightness)!==100) f.push('brightness('+(Number(a.brightness)/100)+')');
    if(a.outline && a.outline.width>0) f.push('drop-shadow(0 0 '+a.outline.width+'px '+a.outline.color+')');
    if(a._shadow) f.push('drop-shadow('+a._shadow.x+'px '+a._shadow.y+'px '+a._shadow.blur+'px '+a._shadow.color+')');
    if(a._flashUntil && performance.now()<a._flashUntil) f.push('brightness(2.4) saturate(0)');
    ra.el.style.filter=f.join(' ')||'';
    if(a.blendMode) ra.el.style.mixBlendMode=a.blendMode==='add'?'plus-lighter':a.blendMode;
  }

function actorPositionSet(ra, x, y, force) {
    if (!ra || !ra.data) return false;
    const ox=Number(ra.data.x)||0, oy=Number(ra.data.y)||0;
    const nx = Number(x); const ny = Number(y);
    ra.data.x = Number.isFinite(nx) ? nx : 0;
    ra.data.y = Number.isFinite(ny) ? ny : 0;
    ra.data.vx = 0;
    ra.data.vy = 0;
    ra._lastKey = null;
    updateSpriteTransform(ra, force !== false);
    try { catCompatRecordPlotMove(ra, ox, oy, ra.data.x, ra.data.y); } catch (_) {}
    return true;
  }

  function actorPositionMove(ra, dx, dy, force) {
    if (!ra || !ra.data) return false;
    const ox=Number(ra.data.x)||0, oy=Number(ra.data.y)||0;
    const mx = Number(dx); const my = Number(dy);
    ra.data.x = (Number.isFinite(Number(ra.data.x)) ? Number(ra.data.x) : 0) + (Number.isFinite(mx) ? mx : 0);
    ra.data.y = (Number.isFinite(Number(ra.data.y)) ? Number(ra.data.y) : 0) + (Number.isFinite(my) ? my : 0);
    ra.data.vx = 0;
    ra.data.vy = 0;
    ra._lastKey = null;
    updateSpriteTransform(ra, force !== false);
    try { catCompatRecordPlotMove(ra, ox, oy, ra.data.x, ra.data.y); } catch (_) {}
    return true;
  }

  function runtimeMotionFrameScale() {
    const raw = Number(runtime.frameMs);
    if (!Number.isFinite(raw) || raw <= 0) return 1;
    return Math.max(0.1, Math.min(2.5, raw / (1000 / 60)));
  }

  /** Keep sprite scaling crisp when the user explicitly marks an appearance as pixel art. */
  function applyPixelArtRendering(ra, force) {
    if (!ra || !ra.el) return;
    const enabled = !!(ra.data && ra.data.pixelArt);
    const key = enabled ? 'pixelated' : '';
    if (!force && ra._pixelArtKey === key) return;
    const img = ra.imageEl || (ra.el.querySelector ? ra.el.querySelector('img') : null);
    if (img) img.style.imageRendering = key;
    ra.el.style.imageRendering = key;
    ra._pixelArtKey = key;
  }

  function setActorOpacity(ra, value) {
    if (!ra || !ra.data) return 100;
    const raw = Number(value);
    const op = Number.isFinite(raw) ? Math.max(0, Math.min(100, raw)) : 100;
    ra.data.opacity = op;
    ra.data.transparency = 100 - op;
    if (ra.el) ra.el.style.opacity = String(op / 100);
    return op;
  }

  function setActorTransparency(ra, value) {
    if (!ra || !ra.data) return 0;
    const tRaw = Number(value);
    const t = Number.isFinite(tRaw) ? Math.max(0, Math.min(100, tRaw)) : 0;
    ra.data.transparency = t;
    ra.data.opacity = 100 - t;
    if (ra.el) ra.el.style.opacity = String((100 - t) / 100);
    return t;
  }

  function updateSpriteTransform(ra, force) {
    if (!ra || !ra.el) return;
    const a = ra.data;
    applyPixelArtRendering(ra);
    const rawSize = Number(a.size);
    const scale = (Number.isFinite(rawSize) ? rawSize : 100) / 100;
    const m = projectStageMetrics();
    const x = (m.physicalW / 2) + (Number(a.x) || 0) * m.sx;
    const y = (m.physicalH / 2) - (Number(a.y) || 0) * m.sy;
    const rawDirection = Number(a.direction);
    const direction = Number.isFinite(rawDirection) ? rawDirection : 90;
    let rot = 90 - direction;
    const vis = a.visible !== false;
    const rstyle = a.rotationStyle || 'all-around';
    let scaleX = scale;
    if (rstyle === 'none') {
      rot = 0;
    } else if (rstyle === 'left-right') {
      // face left/right only
      const dir = direction;
      const facingLeft = Math.cos(dir * Math.PI / 180) < 0;
      rot = 0;
      scaleX = facingLeft ? -Math.abs(scale) : Math.abs(scale);
    }
    // NO viewport culling — objects far outside still keep DOM + transform
    const key = x.toFixed(2) + ',' + y.toFixed(2) + ',' + rot.toFixed(2) + ',' + scaleX.toFixed(4) + ',' + scale.toFixed(4) + ',' + vis + ',' + rstyle;
    if (!force && ra._lastKey === key) return;
    ra._lastKey = key;
    const fx = a.flipX ? -1 : 1;
    const fy = a.flipY ? -1 : 1;
    const renderScaleX = scaleX * m.worldScale;
    const renderScaleY = scale * m.worldScale;
    ra.el.style.transform = 'translate3d(' + x + 'px,' + y + 'px,0) translate(-50%,-50%) rotate(' + rot + 'deg) scale(' + (renderScaleX * fx) + ',' + (renderScaleY * fy) + ')';
    ra.el.style.visibility = vis ? 'visible' : 'hidden';
    ra.el.style.pointerEvents = vis ? 'auto' : 'none';
    ra.el.style.display = vis ? '' : 'none';
    // Always keep in DOM even when far off-screen. Re-apply shader after any transform
    // so the per-frame transform path cannot erase shader filters.
    if (a._shader && typeof refreshShader === 'function') refreshShader(ra);
    else if (a._tintFilter) ra.el.style.filter = a._tintFilter;
  }

  /** Softly move toward target (follow) instead of teleport */
  function lerpToward(current, target, factor) {
    const c = Number(current) || 0;
    const t = Number(target) || 0;
    const f = Math.max(0.05, Math.min(1, factor == null ? 0.35 : factor));
    const d = t - c;
    if (Math.abs(d) < 0.15) return t; // snap when close
    return c + d * f;
  }

  function broadcastTouch(actorIdx) {
    const now = performance.now();
    // Debounce duplicate touch+mouse same frame
    if (runtime._lastTouchAt && now - runtime._lastTouchAt < 40) return;
    runtime._lastTouchAt = now;
    runtime.actors.forEach((ra, i) => {
      if (i !== actorIdx) return;
      startHatsFor(ra, 'Quando tocado');
      if (!ra._tapTimes) ra._tapTimes = [];
      const windowMs = runtime.multiTapWindow || 550;
      // Drop old taps outside window from last tap
      if (ra._tapTimes.length) {
        const last = ra._tapTimes[ra._tapTimes.length - 1];
        if (now - last > windowMs) ra._tapTimes = [];
      }
      ra._tapTimes.push(now);
      // streak = consecutive taps each within windowMs
      let streak = 1;
      for (let ti = ra._tapTimes.length - 1; ti > 0; ti--) {
        if (ra._tapTimes[ti] - ra._tapTimes[ti - 1] <= windowMs) streak++;
        else break;
      }
      ra._tapStreak = streak;
      try { startMultiTapScripts(ra, streak); } catch (err) { console.warn('multiTap', err); }
    });
  }

  function startMultiTapScripts(ra, streak) {
    try {
      if (!ra || !ra.data) return;
      let flat = ra.data.scripts;
      if (flat && flat.blocks) flat = scriptsToFlat(flat);
      if (!Array.isArray(flat)) return;

      // Only fire when streak exactly hits need (transition), not while staying >= need
      flat.forEach((s, i) => {
        if (!s || s.disabled) return;
        if (s.name !== 'Se tocado X vezes seguidamente' && !(s.name && s.name.includes('seguidamente'))) return;
        const need = Math.max(1, Math.floor(Number((s.values && s.values.vezes) || 2) || 2));
        const key = '_mt_fired_' + i + '_' + need;
        // Reset fired flag if streak dropped below need (window expired / restarted)
        if (streak < need) {
          ra.data[key] = false;
          return;
        }
        // Fire only once when reaching exactly `need` (or first time crossing)
        if (streak === need && !ra.data[key]) {
          ra.data[key] = true;
          // Run following action blocks until next hat/control
          const runList = [];
          for (let j = i + 1; j < flat.length; j++) {
            const n = flat[j];
            if (!n) break;
            if (n.name && (n.name.startsWith('Quando ') || n.name === 'Se tocado X vezes seguidamente' || n.name === 'Sempre' || n.name.startsWith('Repita') || n.name.startsWith('Se ...'))) break;
            runList.push(n);
          }
          if (!runList.length) return;
          const blocks = {};
          let prev = null;
          runList.forEach((blk, k) => {
            const id = 'mt_' + i + '_' + k + '_' + runtimeNow().toString(36);
            blocks[id] = {
              id, type: 'action', name: blk.name, color: blk.color,
              params: blk.params || [], values: Object.assign({}, blk.values || {}), next: null
            };
            if (prev) blocks[prev].next = id;
            prev = id;
          });
          const firstId = Object.keys(blocks)[0];
          runtime.coroutines.push({
            actor: ra, tree: { blocks, stacks: [firstId] }, blocks,
            ip: firstId, waitUntil: 0, dead: false, loopStack: []
          });
        }
        // If streak went past need without reset, do not re-fire until streak drops
        if (streak > need) ra.data[key] = true;
      });
    } catch (e) { console.warn('startMultiTapScripts', e); }
  }

  
  function startHatsFor(ra, hatName) {
    try {
      if (!ra || !ra.data) return;
      let flat = ra.data.scripts;
      if (flat && flat.blocks && flat.stacks) {
        flat = scriptsToFlat(flat);
        ra.data.scripts = flat;
      }
      if (!Array.isArray(flat)) flat = [];
      // Runtime must establish the render loop independently.
      // boundaries. Complete the persisted flat structure before launch.
      try { ensureFlatLoopBoundaries(flat); } catch (_) {}
      ra.data.scripts = flat;

      const norm = (s) => String(s || '').toLowerCase()
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/\s+/g, ' ').trim();

      const want = norm(hatName || 'quando a cena comecar');
      const isSceneStart = !hatName || want.includes('cena comecar') || want.includes('cena começar') || want.includes('iniciar');

      // Find matching hat indices in flat list
      const hatIndices = [];
      for (let i = 0; i < flat.length; i++) {
        const s = flat[i];
        if (!s || s.disabled) continue;
        const n = norm(s.name || '');
        const isHat = (s.type === 'hat') || n.startsWith('quando ') || n.startsWith('quando') ||
          (typeof blockType === 'function' && blockType(s.name) === 'hat');
        if (!isHat) continue;
        if (isSceneStart && (n.includes('cena comecar') || n.includes('cena começar') || n.includes('cena inicia') || n === 'quando a cena comecar' || n.startsWith('quando a cena'))) {
          hatIndices.push(i);
        } else if (hatName && (n === want || n.includes(want) || want.includes(n))) {
          hatIndices.push(i);
        } else if (hatName && norm(s.name) === norm(hatName)) {
          hatIndices.push(i);
        }
      }
      // Fallback: any hat on scene start
      if (isSceneStart && !hatIndices.length) {
        for (let i = 0; i < flat.length; i++) {
          const s = flat[i];
          if (!s || s.disabled) continue;
          const n = norm(s.name || '');
          if (n.startsWith('quando ') || s.type === 'hat') hatIndices.push(i);
        }
      }

      // Launch coroutine: flatMode with stable block list (reliable)
      hatIndices.forEach(hi => {
        const slice = [];
        for (let j = hi + 1; j < flat.length; j++) {
          const s = flat[j];
          if (!s) continue;
          const n = norm(s.name);
          const isHat = n.startsWith('quando ') || (typeof blockType === 'function' && blockType(s.name) === 'hat');
          if (isHat) break;
          // ensure id
          if (!s.id) s.id = 'b' + j;
          slice.push(s);
        }
        if (!slice.length) return;
        runtime.coroutines.push({
          actor: ra,
          flatMode: true,
          flatBlocks: slice,
          flatIndex: 0,
          waitUntil: 0,
          dead: false,
          loopStack: [],
          blocks: {},
          ip: null,
          tree: null
        });
      });

      // No hat at all: run whole flat list once on scene start
      if (isSceneStart && !hatIndices.length && flat.length) {
        const onlyActions = flat.filter(s => {
          if (!s || s.disabled) return false;
          const n = norm(s.name);
          return !n.startsWith('quando ');
        });
        if (onlyActions.length) {
          runtime.coroutines.push({
            actor: ra,
            flatMode: true,
            flatBlocks: onlyActions,
            flatIndex: 0,
            waitUntil: 0,
            dead: false,
            loopStack: [],
            blocks: {},
            ip: null,
            tree: null
          });
        }
      }
    
      // SAFETY: if scene start and still no coroutines, run all non-hat blocks
      if (isSceneStart && !(runtime.coroutines || []).some(function(c){ return c.actor === ra && !c.dead; })) {
        const slice = flat.filter(function(s) {
          if (!s || s.disabled) return false;
          const n = norm(s.name || '');
          return !(n.startsWith('quando ') || s.type === 'hat');
        });
        if (slice.length) {
          runtime.coroutines.push({
            actor: ra,
            flatMode: true,
            flatBlocks: slice,
            flatIndex: 0,
            waitUntil: 0,
            dead: false,
            loopStack: [],
            blocks: {},
            ip: null,
            tree: null
          });
        }
      }

    } catch (e) {
      console.error('startHatsFor', e);
    }
  }



  // ============================================================
  // Production block handlers
  // These handlers are opcode-oriented. Names are only used for
  // backwards compatibility with projects created before opcodes.
  // ============================================================
  function productionDrawing() {
    if (!runtime._drawing) runtime._drawing = { strokes: [], penDown: false, color: '#ffffff', width: 4, opacity: 1 };
    if (!runtime._drawingCanvas) {
      const stage = runtime.stageEl || document.getElementById('play-stage');
      if (stage && typeof document !== 'undefined') {
        const c = document.createElement('canvas');
        c.className = 'kix-drawing-layer';
        const m = projectStageMetrics(); c.width = Math.max(1,Math.round(m.logicalW)); c.height = Math.max(1,Math.round(m.logicalH));
        c.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:20;isolation:isolate;';
        stage.appendChild(c);
        runtime._drawingCanvas = c;
        runtime._drawingCtx = c.getContext('2d');
      }
    }
    return runtime._drawing;
  }
  function drawCommitStroke(stroke) {
    const d = productionDrawing(), c = runtime._drawingCtx;
    if (!d || !c || !stroke) return;
    c.save(); c.globalAlpha = d.opacity; c.strokeStyle = d.color; c.lineWidth = d.width;
    c.lineCap='round'; c.lineJoin='round'; c.beginPath();
    const dm=projectStageMetrics(), dw=dm.logicalW, dh=dm.logicalH;
    (stroke.points||[]).forEach((p,i)=> i ? c.lineTo(p.x + dw/2, dh/2 - p.y) : c.moveTo(p.x + dw/2, dh/2 - p.y));
    c.stroke(); c.restore();
  }
  function clearDrawing() {
    productionDrawing();
    const c=runtime._drawingCtx;
    if(c) c.clearRect(0,0,runtime._drawingCanvas.width,runtime._drawingCanvas.height);
    if(runtime._drawing) runtime._drawing.strokes=[];
  }
  function actorById(id) {
    const q=String(id==null?'':id).replace(/^['"]|['"]$/g,'');
    return runtime.actors.find(a => a && (String(a.data.id||a.data.name)===q)) || null;
  }
  function productionParticle(x,y,opts) {
    const list=ensureParticles();
    const p=Object.assign({x:Number(x)||0,y:Number(y)||0,vx:0,vy:0,life:.6,maxLife:.6,size:5,text:'',color:'#fff'},opts||{});
    list.push(p);
    if(runtime._particleLayer && typeof document!=='undefined'){
      const el=document.createElement('div'); el.style.cssText='position:absolute;width:'+p.size+'px;height:'+p.size+'px;border-radius:50%;background:'+p.color+';pointer-events:none;';
      runtime._particleLayer.appendChild(el); p.el=el;
    }
  }
  function productionNpc(ra, name, blk, ctx) {
    const d=ra.data, id=paramStr(blk,'id',d.id||d.name||'npc',ctx).replace(/['"]/g,'')||d.id||d.name||'npc';
    runtime.npcs=runtime.npcs||Object.create(null);
    const n=runtime.npcs[id]||(runtime.npcs[id]={id,x:Number(d.x)||0,y:Number(d.y)||0, state:'idle',behavior:'idle',target:'',goal:'',speed:2,vision:200,attackRange:32,detectRange:240,memory:2000,personality:'neutral',aggression:0.5,intelligence:0.5,difficulty:1,variables:{},config:{},ra});
    const value=(k,def)=>paramStr(blk,k,def,ctx).replace(/^['"]|['"]$/g,'');
    const num=(k,def)=>Number(param(blk,k,def,ctx))||def;
    const target=value('alvo',value('objetivo',''));
    switch(name){
      case 'Criar NPC': n.ra=ra; break;
      case 'Definir comportamento do NPC': n.behavior=value('comportamento','idle'); break;
      case 'Definir estado do NPC': n.state=value('estado','idle'); break;
      case 'Definir objetivo do NPC': n.goal=value('objetivo',''); break;
      case 'Definir alvo do NPC': n.target=target; break;
      case 'NPC perseguir alvo': n.target=value('alvo',''); n.speed=num('velocidade',2); n.state='chase'; break;
      case 'NPC fugir do alvo': n.target=value('alvo',''); n.speed=num('velocidade',2); n.state='flee'; break;
      case 'NPC patrulhar rota': n.config.route=value('rota',''); n.speed=num('velocidade',2); n.state='patrol'; break;
      case 'NPC seguir caminho': n.goal=value('destino',''); n.speed=num('velocidade',2); n.state='path'; break;
      case 'Definir visão do NPC': n.vision=num('distância',200); n.config.angle=num('ângulo',120); break;
      case 'Definir alcance de ataque do NPC': n.attackRange=num('distância',32); break;
      case 'Definir alcance de detecção do NPC': n.detectRange=num('distância',240); break;
      case 'Definir memória do NPC': n.memory=num('tempo',2000); break;
      case 'NPC lembrar alvo': n.target=value('alvo',''); n.config.rememberedAt=performance.now(); break;
      case 'NPC esquecer alvo': if(!target||n.target===target)n.target=''; break;
      case 'Definir personalidade do NPC': n.personality=value('personalidade','neutral'); break;
      case 'Definir agressividade do NPC': n.aggression=Math.max(0,Math.min(1,num('valor',.5))); break;
      case 'Definir inteligência do NPC': n.intelligence=Math.max(0,Math.min(1,num('valor',.5))); break;
      case 'Definir dificuldade do NPC': n.difficulty=Math.max(1,num('nível',1)); break;
      case 'Definir reação do NPC': n.config.reaction={event:value('evento',''),action:value('ação','')}; break;
      case 'NPC tomar decisão': n.state=n.target?'chase':(n.behavior||'idle'); break;
      case 'NPC escolher alvo mais próximo': {
        let best=null,bd=Infinity; runtime.actors.forEach(o=>{if(o===ra)return;const dx=(o.data.x||0)-(d.x||0),dy=(o.data.y||0)-(d.y||0),dd=Math.hypot(dx,dy);if(dd<bd&&dd<=n.detectRange){bd=dd;best=o;}});
        n.target=best?(best.data.id||best.data.name||''):'';
      } break;
      case 'NPC escolher caminho': n.goal=value('destino',''); n.state='path'; break;
      case 'NPC parar': n.state='idle'; n.vx=n.vy=0; break;
      case 'NPC atacar alvo': n.state='attack'; n.target=value('alvo',n.target); break;
      case 'NPC defender': n.state='defend'; break;
      case 'NPC esquivar': n.state='dodge'; break;
      case 'NPC chamar aliados': n.config.callDistance=num('distância',120); runtime.actors.forEach(o=>{if(o!==ra && Math.hypot((o.data.x||0)-d.x,(o.data.y||0)-d.y)<=n.config.callDistance){const od=runtime.npcs[o.data.id||o.data.name];if(od)od.target=n.target;}}); break;
      case 'NPC evitar obstáculo': n.config.avoidDistance=num('distância',24); break;
      case 'NPC conversar': n.config.dialogue=value('texto',''); break;
      case 'NPC emitir som': { const s=value('som',''); try{ if(typeof Audio!=='undefined'&&s){const a=new Audio(s);a.play().catch(()=>{});} }catch(_){} } break;
      case 'NPC usar habilidade': n.config.ability=value('habilidade',''); break;
      case 'NPC usar item': n.config.item=value('item',''); break;
      case 'NPC trocar estado automaticamente': n.config.autoState=true; break;
      case 'NPC copiar configuração': { const src=runtime.npcs[value('origem','')]; if(src)n.config=JSON.parse(JSON.stringify(src.config||{})); } break;
      case 'NPC definir variável': n.variables[value('nome','')]=param(blk,'valor',0,ctx); break;
      case 'Quando NPC detectar objeto': n.config.hat='detect'; break;
      case 'Quando NPC perder o alvo': n.config.hat='lost'; break;
      case 'Quando NPC chegar ao destino': n.config.hat='arrive'; break;
      case 'Quando NPC sofrer dano': n.config.hat='damage'; break;
      case 'Quando NPC atacar': n.config.hat='attack'; break;
    }
    return true;
  }
  function productionShader(name,blk,ctx,ra) {
    const id=paramStr(blk,'id',ra.data.id||ra.data.name||'actor',ctx).replace(/['"]/g,'');
    const d=ra.data; d._shader=d._shader||{filters:[],uniforms:{},time:0,intensity:1,paused:false};
    const q=(k,def)=>paramStr(blk,k,def,ctx).replace(/^['"]|['"]$/g,'');
    const num=(k,def)=>Number(param(blk,k,def,ctx));
    switch(name){
      case 'Aplicar blur': d._shader.filters.push('blur('+Math.max(0,num('raio',4))+'px)'); break;
      case 'Aplicar contorno': d._shader.filters.push('drop-shadow(0 0 3px '+q('cor','#fff')+')'); break;
      case 'Aplicar pixelização': d._shader.pixel=Math.max(1,num('tamanho',4)); break;
      case 'Aplicar escala de cinza': d._shader.filters.push('grayscale(1)'); break;
      case 'Aplicar sépia': d._shader.filters.push('sepia(1)'); break;
      case 'Aplicar distorção de onda': d._shader.wave=num('amplitude',5); break;
      case 'Definir intensidade do efeito': d._shader.intensity=num('valor',1); break;
      case 'Definir tempo do shader': d._shader.time=num('valor',0); break;
      case 'Definir uniform do shader': d._shader.uniforms[q('nome','u_value')]=param(blk,'valor',0,ctx); break;
      case 'Definir uniform texto': d._shader.uniforms[q('nome','u_text')]=q('valor',''); break;
      case 'Definir resolução do shader': d._shader.resolution=[num('largura',Number(runtime._logicalStageW)||STAGE_W),num('altura',Number(runtime._logicalStageH)||STAGE_H)]; break;
      case 'Pausar shader': d._shader.paused=true; break;
      case 'Retomar shader': d._shader.paused=false; break;
      case 'Shader personalizado (GLSL)': d._shader.glsl=q('código',''); d._shader.custom=true; break;
      case 'Remover shader':
        d._shader={filters:[],uniforms:{},time:0,intensity:1,paused:false};
        if(runtime._sceneShader && String(runtime._sceneShader._sourceActorId||'')===String(id)) runtime._sceneShader=null;
        break;
      case 'Combinar shaders': d._shader.combined=true; d._shader.filters=d._shader.filters||[]; break;
      case 'Misturar dois shaders': {
        const aa=q('a',''),bb=q('b',''); d._shader.mix=[aa,bb];
        d._shader.filters=(d._shader.filters||[]).concat(shaderPresetFilters(aa),shaderPresetFilters(bb));
      } break;
      case 'Aplicar shader ao ator': d._shader.enabled=true; refreshShader(ra); break;
      case 'Aplicar shader na cena inteira': runtime._sceneShader=Object.assign({},d._shader,{_sourceActorId:String(id)}); refreshSceneShader(); break;
      case 'Pré-visualizar shader': runtime._shaderPreview=true; d._shader.preview=true; refreshShader(ra); break;
      case 'Carregar shader de arquivo': {
        const file=q('caminho',''); d._shader.file=file;
        if(file && typeof fetch==='function'){ fetch(file).then(r=>r.text()).then(src=>{ if(d._shader && d._shader.file===file){ d._shader.glsl=src; d._shader.custom=true; d._shader._webglReady=false; refreshShader(ra); } }).catch(()=>{}); }
      } break;
      case 'Exportar preview do shader': {
        const nm=q('nome','shader-preview'); d._shader.exportName=nm;
        const c=ra.el && ra.el.querySelector('.kix-shader-canvas');
        try{ const src=c&&c.toDataURL ? c.toDataURL('image/png') : null; if(src && typeof document!=='undefined'){ const a=document.createElement('a'); a.href=src; a.download=(nm||'shader-preview')+'.png'; a.click(); } }catch(_){}
      } break;
      case 'Quando shader aplicar': d._shader.hat=true; break;
    }
    if(runtime._sceneShader && String(runtime._sceneShader._sourceActorId||'')===String(id)) runtime._sceneShader=Object.assign({},d._shader,{_sourceActorId:String(id)});
    if(typeof refreshShader==='function') refreshShader(ra);
    if(name==='Aplicar shader na cena inteira' || name==='Pré-visualizar shader' || runtime._sceneShader) refreshSceneShader();
    return true;
  }
  // Canonical Preset runtime. Every preset has one implementation path so a later
  // legacy dispatcher cannot partially override it. Presets are configuration helpers,
  // but they still create real runtime state and interactive DOM where applicable.
  const CANONICAL_SHADER_NAMES = new Set([
    'Aplicar shader ao ator','Remover shader','Shader personalizado (GLSL)','Definir uniform do shader',
    'Definir tempo do shader','Aplicar blur','Aplicar contorno','Aplicar distorção de onda','Aplicar pixelização',
    'Aplicar escala de cinza','Aplicar sépia','Definir intensidade do efeito','Combinar shaders',
    'Aplicar shader na cena inteira','Pré-visualizar shader','Quando shader aplicar','Definir uniform texto',
    'Carregar shader de arquivo','Misturar dois shaders','Definir resolução do shader','Pausar shader','Retomar shader','Exportar preview do shader'
  ]);
  function isCanonicalShader(name){ return CANONICAL_SHADER_NAMES.has(String(name||'')); }

  const CANONICAL_PRESET_NAMES = new Set([
    'Criar joystick virtual','Definir posição do joystick','Definir tamanho do joystick',
    'Ler direção do joystick','Ler eixo X do joystick','Ler eixo Y do joystick','Ler força do joystick (analógico)','Criar botão de ação','Criar D-pad','Criar D-Pad',
    'Remover controles virtuais','Definir sprite da base','Definir sprite do manípulo','Definir sprite dos botões',
    'Trocar skin do joystick','Definir opacidade do joystick','Definir cor de tint do joystick','Restaurar sprite padrão',
    'Trocar skin do D-pad','Definir sprites do D-Pad','Definir sprite da seta do D-pad','Definir opacidade do D-pad','Definir cor do D-pad','Restaurar sprite padrão do D-pad',
    'Criar câmera de seguimento','Definir alvo da câmera','Definir zoom da câmera','Câmera com suavização','Câmera com paralaxe',
    'Preset de checkpoint','Preset de objetivo da fase','Transição fade in/out','Transição cortinas (wipe)',
    'Transição deslizar (slide)','Transição zoom','Transição de cena aleatória','Definir duração da transição',
    'Preset de tela de carregamento','Preset de menu pausado','Preset de tela de game over',
    'Objeto sólido','Parede','Plataforma','Coletável','Dano por contato',
    'Empurrão','Sensor','Projétil','Plataforma móvel','Zona de teleporte',
    'Preset de tela de lobby','Preset de busca de partida','Preset de lista de jogadores na sala',
    'Indicador de conexão (ping/status)','Preset de botão pronto','Preset de contagem regressiva de início',
    'Preset de tela de resultado da partida','Preset de convite de amigo','Preset de chat rápido','Preset de indicador de host'
  ]);

  function isCanonicalPreset(name) {
    return CANONICAL_PRESET_NAMES.has(String(name || ''));
  }

  function presetClean(v) { return String(v == null ? '' : v).replace(/^['"]|['"]$/g, '').trim(); }
  function presetNum(blk, key, def, ctx) {
    const v = Number(param(blk, key, def, ctx));
    return Number.isFinite(v) ? v : def;
  }
  function presetString(blk, key, def, ctx) { return presetClean(paramStr(blk, key, def, ctx)); }

  function executePresetBlock(co, blk, ctx, now) {
    const name = canonicalBlockName(blk && (blk.name || blk.legacyName) || '');
    if (!isCanonicalPreset(name)) return false;
    const actor = co.actor;
    const d = actor && actor.data ? actor.data : {};
    const preset = runtime._presets || (runtime._presets = {controls:{},transitions:{},screens:{},multiplayer:{},camera:{},collision:{}});
    preset.controls = preset.controls || {};
    preset.screens = preset.screens || {};
    preset.multiplayer = preset.multiplayer || {};
    preset.camera = preset.camera || {};
    preset.collision = preset.collision || {};

    const controlId = presetString(blk, 'id', 'joystick1', ctx) || 'joystick1';
    const hud = ensureHud();
    const control = (id, kind) => {
      const requestedKind = kind || null; // semantic kind; null means reuse existing control
      const c0 = preset.controls[id];
      // Runtime state is authoritative. A temporary DOM detach must NOT recreate the
      // control, because doing so resets joystick direction/axes and can make reads
      // suddenly jump back to the initial state. Reattach the same element/state.
      if (c0 && (!requestedKind || c0.type === requestedKind)) {
        if (!c0.el) {
          const domTag = requestedKind === 'button' ? 'button' : 'div';
          c0.el = document.createElement(domTag);
          c0.el.dataset.kixPreset = id;
        }
        const root = ensureControlsRoot();
        if (c0.el.parentElement !== root) root.appendChild(c0.el);
        c0.el.style.pointerEvents = 'auto';
        c0.el.style.overflow = 'visible';
        return c0;
      }

      if (c0 && c0.el) try { c0.el.remove(); } catch (_) {}
      const domTag = requestedKind === 'button' ? 'button' : 'div';
      const el = document.createElement(domTag);
      el.dataset.kixPreset = id;
      el.style.cssText = 'position:absolute;left:0;top:0;z-index:20;user-select:none;touch-action:none;pointer-events:auto;box-sizing:border-box;overflow:visible;';
      ensureControlsRoot().appendChild(el);
      const c = {id,el,type:requestedKind || 'generic',size:110,opacity:1,dx:0,dy:0,axisX:0,axisY:0,force:0,direction:0,lastDirection:0,active:false};
      preset.controls[id] = c;
      return c;
    };

    const ensureJoystickParts = (c) => {
      if (!c || !c.el) return { surface:null, thumb:null };
      let surface = c.el.querySelector('[data-joystick-surface]');
      let thumb = c.el.querySelector('[data-thumb]');
      if (!surface || !thumb) {
        c.el.innerHTML = '';
        surface = document.createElement('div');
        surface.dataset.joystickSurface = '1';
        surface.style.cssText = 'position:absolute;inset:0;border-radius:50%;overflow:hidden;z-index:1;pointer-events:none;box-sizing:border-box;';
        thumb = document.createElement('div');
        thumb.dataset.thumb = '1';
        thumb.style.cssText = 'position:absolute;left:50%;top:50%;width:42%;height:42%;margin:-21% 0 0 -21%;border-radius:50%;z-index:2;pointer-events:none;box-sizing:border-box;background:rgba(255,255,255,.72);box-shadow:0 2px 10px rgba(0,0,0,.25);';
        c.el.appendChild(surface);
        c.el.appendChild(thumb);
      }
      c.el.style.overflow = 'visible';
      return {surface, thumb};
    };

    const ensureDpadParts = (c) => {
      if (!c || !c.el) return {buttons:{}};
      const dirs = ['cima','esquerda','direita','baixo'];
      let buttons = {};
      dirs.forEach(dir => { const el = c.el.querySelector('[data-dir="'+dir+'"]'); if (el) buttons[dir] = el; });
      if (Object.keys(buttons).length !== 4) {
        c.el.innerHTML=['','cima','','esquerda','centro','direita','','baixo',''].map((dir,i)=>dir
          ? '<button type="button" data-dir="'+dir+'" style="font-size:12px;background:rgba(20,20,20,.72);color:#fff;border:1px solid rgba(255,255,255,.2);border-radius:8px"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+(dir==='cima'?'<path d="M5 15l7-7 7 7"/>':dir==='baixo'?'<path d="M5 9l7 7 7-7"/>':dir==='esquerda'?'<path d="M15 5l-7 7 7 7"/>':dir==='direita'?'<path d="M9 5l7 7-7 7"/>':'<circle cx="12" cy="12" r="4"/>')+'</svg></button>'
          : '<span></span>').join('');
        dirs.forEach(dir => { const el=c.el.querySelector('[data-dir="'+dir+'"]'); if(el) buttons[dir]=el; });
      }
      c.el.style.overflow='visible';
      c.el.style.width=c.el.style.width||'126px';
      c.el.style.height=c.el.style.height||'126px';
      c.el.style.display='grid';
      c.el.style.gridTemplateColumns='repeat(3,42px)';
      c.el.style.gridTemplateRows='repeat(3,42px)';
      return {buttons};
    };

    const bindDpad = (c, co, vars) => {
      if (!c) return {buttons:{}};
      const cleanVars = vars || {};
      c._dpadBindings = c._dpadBindings || [];
      const existing = c._dpadBindings.find(b => b.actor === co.actor);
      if (existing) Object.assign(existing.vars, cleanVars);
      else c._dpadBindings.push({actor:co.actor,vars:Object.assign({},cleanVars)});
      Object.values(cleanVars).forEach(v => { if (v) deviceSetVar(co,v,0); });
      const parts=ensureDpadParts(c);
      const dirs=Object.keys(parts.buttons);
      c._dpadPressed=c._dpadPressed||new Set();
      c._dpadHandlers=c._dpadHandlers||{};
      dirs.forEach(dir=>{
        const btn=parts.buttons[dir];
        if(!btn)return;
        const press=(ev)=>{
          try { if (ev && ev.pointerId != null && btn.setPointerCapture) btn.setPointerCapture(ev.pointerId); } catch (_) {}
          c._dpadPressed.add(dir);
          runtime._dpad=runtime._dpad||{};
          runtime._dpad[c.id]=dir;
          c.direction=dir;
          runtime._lastPresetAction=c.id;
          (c._dpadBindings||[]).forEach(binding=>{
            const key=binding.vars&&binding.vars[dir];
            if(key) deviceSetVar({actor:binding.actor},key,1);
          });
          (runtime.actors||[]).forEach(ra=>startHatsFor(ra,'Quando botão pressionado'));
        };
        const release=()=>{
          c._dpadPressed.delete(dir);
          (c._dpadBindings||[]).forEach(binding=>{
            const key=binding.vars&&binding.vars[dir];
            if(key) deviceSetVar({actor:binding.actor},key,0);
          });
          const next=Array.from(c._dpadPressed)[0]||'';
          c.direction=next;
          runtime._dpad=runtime._dpad||{};
          runtime._dpad[c.id]=next;
        };
        btn.onpointerdown=press;
        btn.onpointerup=release;
        btn.onpointercancel=release;
        btn.onpointerleave=(ev)=>{ if(ev.buttons===0 && c._dpadPressed.has(dir)) release(); };
        c._dpadHandlers[dir]={press,release};
      });
      dirs.forEach(dir=>{ if(cleanVars[dir]) deviceSetVar(co,cleanVars[dir],0); });
      return parts;
    };

    const applyDpadSkin = (c, style) => {
      const parts=ensureDpadParts(c);
      const key=String(style||'escuro').toLowerCase();
      const skins={
        'escuro':{base:'rgba(10,10,10,.72)',button:'rgba(40,40,40,.88)',color:'#fff',border:'rgba(255,255,255,.2)'},
        'dark':{base:'rgba(10,10,10,.72)',button:'rgba(40,40,40,.88)',color:'#fff',border:'rgba(255,255,255,.2)'},
        'claro':{base:'rgba(240,240,240,.82)',button:'rgba(255,255,255,.95)',color:'#111',border:'rgba(0,0,0,.18)'},
        'light':{base:'rgba(240,240,240,.82)',button:'rgba(255,255,255,.95)',color:'#111',border:'rgba(0,0,0,.18)'},
        'vidro':{base:'rgba(255,255,255,.12)',button:'rgba(255,255,255,.18)',color:'#fff',border:'rgba(255,255,255,.28)'},
        'glass':{base:'rgba(255,255,255,.12)',button:'rgba(255,255,255,.18)',color:'#fff',border:'rgba(255,255,255,.28)'}
      };
      const sk=skins[key]||skins.escuro;
      c.dpadSkin=key;
      c.dpadBase=sk.base;
      c.dpadButton=sk.button;
      c.dpadColor=sk.color;
      c.el.style.background=sk.base;
      c.el.style.borderRadius='10px';
      Object.values(parts.buttons).forEach(btn=>{
        btn.style.background=sk.button;
        btn.style.color=sk.color;
        btn.style.borderColor=sk.border;
      });
      return sk;
    };

    if (name === 'Criar joystick virtual') {
      const c=control(controlId,'joystick');
      c.size=Math.max(40,Math.min(320,presetNum(blk,'tamanho',110,ctx)));
      c.el.style.left=presetNum(blk,'x',0,ctx)+'px';
      c.el.style.top=presetNum(blk,'y',0,ctx)+'px';
      c.el.style.bottom='auto';
      const coupledSkin=presetString(blk,'estilo','glass',ctx).toLowerCase();
      const coupledSkins={glass:['rgba(255,255,255,.12)','rgba(255,255,255,.72)'],dark:['rgba(10,10,10,.72)','rgba(80,80,80,.92)'],light:['rgba(240,240,240,.82)','rgba(255,255,255,1)']};
      const coupledSkinValue=coupledSkins[coupledSkin]||coupledSkins.glass;
      c.skinBase=coupledSkinValue[0]; c.skinThumb=coupledSkinValue[1];
      const parts=ensureJoystickParts(c);
      c.el.style.width=c.size+'px'; c.el.style.height=c.size+'px';
      c.el.style.border='none'; c.el.style.borderRadius='50%'; c.el.style.background='transparent'; c.el.style.display='block';
      if(parts.surface){
        parts.surface.style.background=c.skinBase||'rgba(255,255,255,.12)';
        parts.surface.style.border='2px solid rgba(255,255,255,.55)';
        parts.surface.style.boxShadow='';
      }
      if(parts.thumb){
        parts.thumb.style.background=c.skinThumb||'rgba(255,255,255,.72)';
        parts.thumb.style.border='none';
        parts.thumb.style.boxShadow='0 2px 10px rgba(0,0,0,.25)';
      }
      const move=(ev)=>{
        if(runtime.paused)return;
        const r=c.el.getBoundingClientRect(); const pt=ev.touches?ev.touches[0]:ev;
        if(!pt)return;
        const dx=pt.clientX-(r.left+r.width/2), dy=pt.clientY-(r.top+r.height/2), lim=Math.max(1,r.width*.42), len=Math.hypot(dx,dy)||1, m=Math.min(1,lim/len);
        const nx=Math.max(-1,Math.min(1,(dx/lim)*m));
        const ny=Math.max(-1,Math.min(1,(dy/lim)*m));
        c.dx=nx; c.dy=ny; c.axisX=nx; c.axisY=-ny; c.force=Math.min(1,Math.hypot(nx,ny)); c.active=c.force>0.03;
        if(c.active){ c.direction=(Math.atan2(c.axisY,c.axisX)*180/Math.PI+360)%360; c.lastDirection=c.direction; }
        const t=c.el.querySelector('[data-thumb]'); if(t)t.style.transform='translate('+(dx*m)+'px,'+(dy*m)+'px)';
        runtime._joysticks=runtime._joysticks||{}; runtime._joysticks[controlId]=c;
      };
      const end=()=>{c.dx=0;c.dy=0;c.axisX=0;c.axisY=0;c.force=0;c.active=false;c.direction=0;const t=c.el.querySelector('[data-thumb]');if(t)t.style.transform='';};
      c.el.onpointerdown=(e)=>{try{c.el.setPointerCapture?.(e.pointerId)}catch(_){};move(e);};
      c.el.onpointermove=(e)=>{if(e.buttons)move(e);}; c.el.onpointerup=end; c.el.onpointercancel=end;
      c.el.ontouchstart=move; c.el.ontouchmove=move; c.el.ontouchend=end;
      return true;
    }
    if (name === 'Definir posição do joystick') {
      const c=control(controlId); c.el.style.left=presetNum(blk,'x',0,ctx)+'px'; c.el.style.top=presetNum(blk,'y',0,ctx)+'px'; c.el.style.bottom='auto'; return true;
    }
    if (name === 'Definir tamanho do joystick') { const c=control(controlId); c.size=Math.max(40,Math.min(320,presetNum(blk,'tamanho',110,ctx))); c.el.style.width=c.size+'px';c.el.style.height=c.size+'px'; return true; }
    if (name === 'Ler direção do joystick') { const c=control(controlId); const vn=presetString(blk,'variável','joystick_direcao',ctx); deviceSetVar(co,vn,Number(c.direction)||0); markJoystickDirectionVar(co,vn,controlId); return true; }
    if (name === 'Ler eixo X do joystick') { const c=control(controlId); deviceSetVar(co,presetString(blk,'variável','joystick_x',ctx),Number(c.axisX)||0); return true; }
    if (name === 'Ler eixo Y do joystick') { const c=control(controlId); deviceSetVar(co,presetString(blk,'variável','joystick_y',ctx),Number(c.axisY)||0); return true; }
    if (name === 'Ler força do joystick (analógico)') { const c=control(controlId); deviceSetVar(co,presetString(blk,'variável','joystick_forca',ctx),Number(c.force)||0); return true; }
    if (name === 'Criar botão de ação') {
      const c=control(controlId,'button'); c.el.textContent=presetString(blk,'texto','Ação',ctx); c.el.style.cssText+=';padding:14px 18px;border:1px solid rgba(255,255,255,.3);border-radius:50%;background:rgba(20,20,20,.78);color:#fff;font-weight:700;';
      c.el.onclick=()=>{runtime._lastPresetAction=controlId; runtime._lastPresetActionTime=performance.now(); (runtime.actors||[]).forEach(ra=>startHatsFor(ra,'Quando botão pressionado'));};
      return true;
    }
    if (name === 'Criar D-pad') {
      const c=control(controlId,'dpad');
      c.el.style.cssText+=';width:126px;height:126px;display:grid;grid-template-columns:repeat(3,42px);grid-template-rows:repeat(3,42px);';
      bindDpad(c,co,{});
      return true;
    }
    if (name === 'Criar D-Pad') {
      const c=control(controlId,'dpad');
      c.el.style.cssText+=';width:126px;height:126px;display:grid;grid-template-columns:repeat(3,42px);grid-template-rows:repeat(3,42px);';
      const vars={cima:presetString(blk,'cima','dpad_cima',ctx),esquerda:presetString(blk,'esquerda','dpad_esquerda',ctx),direita:presetString(blk,'direita','dpad_direita',ctx),baixo:presetString(blk,'baixo','dpad_baixo',ctx)};
      const parts=bindDpad(c,co,vars);
      c.dpadVars=vars;
      Object.keys(parts.buttons).forEach(dir=>{ if(vars[dir]) deviceSetVar(co,vars[dir],0); });
      return true;
    }
    if (name === 'Trocar skin do D-pad') {
      const c=control(controlId,'dpad');
      applyDpadSkin(c,presetString(blk,'estilo','escuro',ctx));
      return true;
    }
    if (name === 'Definir sprites do D-Pad') {
      const c=control(controlId,'dpad');
      const parts=ensureDpadParts(c);
      const fundo=presetString(blk,'fundo','',ctx);
      const setImage=(el,src)=>{ if(!el || !src)return; el.style.backgroundImage='url(\"'+src.replace(/\"/g,'%22')+'\")'; el.style.backgroundSize='cover'; el.style.backgroundPosition='center'; el.style.backgroundRepeat='no-repeat'; el.style.overflow='hidden'; el.style.border='none'; el.style.boxShadow='none'; };
      if(fundo) setImage(c.el,fundo);
      ['cima','baixo','esquerda','direita'].forEach(dir=>{const src=presetString(blk,dir,'',ctx);if(src)setImage(parts.buttons[dir],src);});
      return true;
    }
    if (name === 'Definir sprite da seta do D-pad') {
      const c=control(controlId,'dpad');
      const parts=ensureDpadParts(c);
      const dir=presetString(blk,'direção','cima',ctx).toLowerCase();
      const src=presetString(blk,'imagem','',ctx);
      const target=parts.buttons[dir];
      if(target && src){ target.style.backgroundImage='url(\"'+src.replace(/\"/g,'%22')+'\")'; target.style.backgroundSize='cover'; target.style.backgroundPosition='center'; target.style.backgroundRepeat='no-repeat'; target.style.overflow='hidden'; target.style.border='none'; target.style.boxShadow='none'; }
      return true;
    }
    if (name === 'Definir opacidade do D-pad') {
      const c=control(controlId,'dpad'); c.opacity=Math.max(0,Math.min(1,presetNum(blk,'opacidade',1,ctx))); c.el.style.opacity=c.opacity; return true;
    }
    if (name === 'Definir cor do D-pad') {
      const c=control(controlId,'dpad'); const color=presetString(blk,'cor','#FFFFFF',ctx)||'#FFFFFF'; c.tint=color; const parts=ensureDpadParts(c); Object.values(parts.buttons).forEach(btn=>{btn.style.color=color;btn.style.borderColor=color;}); return true;
    }
    if (name === 'Restaurar sprite padrão do D-pad') {
      const c=control(controlId,'dpad'); const parts=ensureDpadParts(c);
      c.el.style.backgroundImage=''; c.el.style.backgroundRepeat=''; c.el.style.backgroundSize=''; c.el.style.backgroundPosition='';
      applyDpadSkin(c,c.dpadSkin||'escuro');
      Object.values(parts.buttons).forEach(btn=>{btn.style.backgroundImage='';btn.style.backgroundRepeat='';btn.style.backgroundSize='';btn.style.backgroundPosition='';btn.style.boxShadow='none';});
      c.sprite=''; return true;
    }
    if (name === 'Remover controles virtuais') {
      const id=presetString(blk,'id','todos',ctx).toLowerCase();
      const ids=(id==='todos'||id==='*')?Object.keys(preset.controls):[controlId];
      ids.forEach(k=>{try{preset.controls[k]?.el?.remove();}catch(_){};delete preset.controls[k];}); return true;
    }
    if (name === 'Definir sprite da base' || name === 'Definir sprite do manípulo' || name === 'Definir sprite dos botões') {
      const c=control(controlId); const src=presetString(blk,'imagem','',ctx); c.sprite=src;
      const isBase=name==='Definir sprite da base';
      const isHandle=name==='Definir sprite do manípulo';
      if (isBase || isHandle) {
        const parts=ensureJoystickParts(c);
        const target=isBase?parts.surface:parts.thumb;
        if (src && target) {
          target.style.backgroundImage='url("'+src.replace(/"/g,'%22')+'")';
          target.style.backgroundSize='cover';
          target.style.backgroundPosition='center';
          target.style.backgroundRepeat='no-repeat';
          target.style.overflow='hidden';
          target.style.border='none';
          target.style.boxShadow='none';
          target.style.borderRadius='50%';
          // The handle is a sibling above the base, so the base surface can clip its own image
          // without ever cutting the handle.
          if(isHandle) { target.style.zIndex='2'; target.style.pointerEvents='none'; }
          if(isBase) { target.style.zIndex='1'; target.style.pointerEvents='none'; }
        }
      } else if (src) {
        c.el.style.backgroundImage='url("'+src.replace(/"/g,'%22')+'")';
        c.el.style.backgroundSize='cover'; c.el.style.backgroundPosition='center'; c.el.style.backgroundRepeat='no-repeat';
        c.el.style.overflow='visible'; c.el.style.border='none'; c.el.style.boxShadow='none';
        c.el.style.borderRadius='50%';
      }
      return true;
    }
    if (name === 'Trocar skin do joystick') { const c=control(controlId); const sk=presetString(blk,'preset','glass',ctx).toLowerCase(); const skins={glass:['rgba(255,255,255,.12)','rgba(255,255,255,.72)'],dark:['rgba(10,10,10,.72)','rgba(80,80,80,.92)'],light:['rgba(240,240,240,.82)','rgba(255,255,255,1)']}; const v=skins[sk]||skins.glass;c.skinBase=v[0];c.skinThumb=v[1];const parts=ensureJoystickParts(c);if(parts.surface)parts.surface.style.background=v[0];if(parts.thumb)parts.thumb.style.background=v[1];return true; }
    if (name === 'Definir opacidade do joystick') { const c=control(controlId); c.opacity=Math.max(0,Math.min(1,presetNum(blk,'opacidade',1,ctx)));c.el.style.opacity=c.opacity;return true; }
    if (name === 'Definir cor de tint do joystick') { const c=control(controlId); c.tint=presetString(blk,'cor','#ffffff',ctx);c.el.style.borderColor=c.tint;return true; }
    if (name === 'Restaurar sprite padrão') {
      const c=control(controlId);
      const parts=ensureJoystickParts(c);
      c.el.style.backgroundImage=''; c.el.style.backgroundRepeat=''; c.el.style.backgroundSize=''; c.el.style.backgroundPosition='';
      c.el.style.overflow='visible'; c.el.style.filter=''; c.el.style.border='none'; c.el.style.boxShadow='';
      if(parts.surface){
        parts.surface.style.backgroundImage=''; parts.surface.style.backgroundRepeat=''; parts.surface.style.backgroundSize=''; parts.surface.style.backgroundPosition='';
        parts.surface.style.overflow='hidden'; parts.surface.style.border='2px solid rgba(255,255,255,.55)';
        parts.surface.style.boxShadow=''; parts.surface.style.background=c.skinBase||'rgba(255,255,255,.12)';
      }
      if(parts.thumb){
        parts.thumb.style.backgroundImage=''; parts.thumb.style.backgroundRepeat=''; parts.thumb.style.backgroundSize=''; parts.thumb.style.backgroundPosition='';
        parts.thumb.style.overflow='hidden'; parts.thumb.style.border='none'; parts.thumb.style.boxShadow='0 2px 10px rgba(0,0,0,.25)';
        parts.thumb.style.background=c.skinThumb||'rgba(255,255,255,.72)'; parts.thumb.style.zIndex='2';
      }
      c.sprite='';
      return true;
    }

    if (name === 'Criar câmera de seguimento') { const id=presetString(blk,'id','main',ctx)||'main';preset.camera[id]={target:presetString(blk,'ator','',ctx),smooth:.2,parallax:1};return true; }
    if (name === 'Definir alvo da câmera') { const id=presetString(blk,'id','main',ctx)||'main';const nm=presetString(blk,'ator','',ctx);const target=(runtime.actors||[]).find(a=>a?.data&&String(a.data.name||'').toLowerCase()===nm.toLowerCase())||co.actor;preset.camera[id]=preset.camera[id]||{};preset.camera[id].target=target;runtime._camFollow=target;return true; }
    if (name === 'Definir zoom da câmera') { runtime.camZoom=Math.max(.25,Math.min(4,presetNum(blk,'valor',1,ctx)));applyEngineCamera();return true; }
    if (name === 'Câmera com suavização') { runtime.camSmooth=Math.max(.01,Math.min(1,presetNum(blk,'valor',.2,ctx)));return true; }
    if (name === 'Câmera com paralaxe') { runtime.camParallax=presetNum(blk,'fator',1,ctx);return true; }

    if (name === 'Preset de checkpoint') { runtime.checkpoint={id:presetString(blk,'id','checkpoint',ctx),x:Number(d.x)||0,y:Number(d.y)||0,actor:actor};preset.checkpoint=runtime.checkpoint;return true; }
    if (name === 'Preset de objetivo da fase') { runtime.levelObjective=presetString(blk,'texto','Objetivo',ctx);return true; }
    if (name === 'Definir duração da transição') { runtime._transitionDuration=Math.max(.01,presetNum(blk,'segundos',.5,ctx));return true; }
    if (name.startsWith('Transição ')) {
      const sec=Math.max(.01,presetNum(blk,'segundos',runtime._transitionDuration||.5,ctx));runtime._transitionDuration=sec;
      const overlay=runtime._transitionOverlay||(runtime._transitionOverlay=document.createElement('div'));if(!overlay.parentNode)document.body.appendChild(overlay);
      overlay.style.cssText='position:fixed;inset:0;z-index:99999;pointer-events:none;background:#000;opacity:0;transform:translate(0,0) scale(1);transition:none;';
      const dir=presetString(blk,'direção','left',ctx).toLowerCase(),mode=presetString(blk,'modo','out',ctx).toLowerCase();
      overlay.style.transition='opacity '+sec+'s ease,transform '+sec+'s ease';
      if(name==='Transição fade in/out'){overlay.style.opacity=mode.includes('in')?'1':'0';kixRequestAnimationFrame(()=>overlay.style.opacity=mode.includes('in')?'0':'1');}
      else if(name==='Transição zoom'){overlay.style.opacity='1';overlay.style.transform=mode.includes('in')?'scale(1.5)':'scale(.65)';kixRequestAnimationFrame(()=>{overlay.style.opacity='0';overlay.style.transform='scale(1)';});}
      else {const axis=(dir==='up'||dir==='down')?'Y':'X',sign=(dir==='right'||dir==='down')?1:-1;overlay.style.opacity='1';overlay.style.transform='translate'+axis+'('+(sign*100)+'%)';kixRequestAnimationFrame(()=>{overlay.style.opacity='0';overlay.style.transform='translate'+axis+'(0)';});}
      return true;
    }

    if (name.startsWith('Preset:')) {
      const kind=name.slice(7).trim();d.collisionShape=Object.assign({},d.collisionShape||{type:'rect'},{enabled:true});d._collisionPreset=kind;preset.collision[actor.id||d.name||'actor']={kind,actor};
      if(kind==='objeto sólido'){d.collisionResponse='parar';d.collisionShape.width=Math.max(1,presetNum(blk,'largura',48,ctx));d.collisionShape.height=Math.max(1,presetNum(blk,'altura',48,ctx));}
      else if(kind==='parede'){d.collisionResponse='parar';d.collisionPushForce=presetNum(blk,'força',0,ctx);d.collisionPushDirection=presetNum(blk,'direção',0,ctx);}
      else if(kind==='plataforma'){d.collisionResponse='platform';d.collisionShape.height=Math.max(1,presetNum(blk,'altura',24,ctx));d.friction=Math.max(0,presetNum(blk,'atrito',.2,ctx));}
      else if(kind==='coletável'){d.collisionResponse='collect';d.collisionValue=param(blk,'valor',1,ctx);d.collisionVariable=presetString(blk,'variável','pontos',ctx);}
      else if(kind==='dano por contato'){d.collisionResponse='damage';d.collisionDamage=Math.max(0,presetNum(blk,'dano',10,ctx));d.collisionInterval=Math.max(0,presetNum(blk,'intervalo',500,ctx));}
      else if(kind==='empurrão'){d.collisionResponse='push';d.collisionPushForce=presetNum(blk,'força',8,ctx);d.collisionPushDirection=presetNum(blk,'direção',0,ctx);}
      else if(kind==='sensor'){d.collisionResponse='sensor';d.collisionSensorVariable=presetString(blk,'variável','colidiu',ctx);}
      else if(kind==='projétil'){d.collisionResponse='projectile';d.collisionDamage=Math.max(0,presetNum(blk,'dano',10,ctx));d.collisionProjectileSpeed=Math.max(0,presetNum(blk,'velocidade',10,ctx));}
      else if(kind==='plataforma móvel'){d.collisionResponse='platform';d._movingPlatform={distance:Math.max(0,presetNum(blk,'distância',100,ctx)),speed:Math.max(0,presetNum(blk,'velocidade',2,ctx)),startX:Number(d.x)||0,startY:Number(d.y)||0};}
      else if(kind==='zona de teleporte'){d.collisionResponse='teleport';d.teleportScene=presetString(blk,'cena','',ctx);d.teleportX=presetNum(blk,'x',0,ctx);d.teleportY=presetNum(blk,'y',0,ctx);}
      runtime._collisionBoundsFrame=-1;return true;
    }

    // Multiplayer/UI presets are real HUD components, not just metadata.
    const boxId=controlId||('preset_'+name.replace(/[^a-z0-9]+/gi,'_').toLowerCase());
    const node=hudEl(boxId,'div','position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);min-width:220px;max-width:90%;padding:18px;background:rgba(12,12,16,.94);color:#fff;border:1px solid rgba(255,255,255,.16);border-radius:14px;z-index:50;text-align:center;font-family:system-ui,sans-serif;white-space:pre-line;');
    if(node){
      let title='';
      if(name==='Preset de tela de carregamento')title=presetString(blk,'texto','Carregando...',ctx);
      else if(name==='Preset de menu pausado')title=presetString(blk,'título','Pausado',ctx);
      else if(name==='Preset de tela de game over')title=presetString(blk,'título','Game Over',ctx);
      else if(name==='Preset de tela de lobby')title=presetString(blk,'título','Lobby',ctx);
      else if(name==='Preset de busca de partida')title=presetString(blk,'texto','Procurando partida...',ctx);
      else if(name==='Preset de lista de jogadores na sala')title='Jogadores\n'+((runtime.network?.firebase?.uid)?'1. Você':'1. Jogador');
      else if(name==='Indicador de conexão (ping/status)')title='Conexão: '+(runtime.network?.firebase?.status||'desconectado');
      else if(name==='Preset de botão pronto')title=presetString(blk,'texto','PRONTO',ctx);
      else if(name==='Preset de contagem regressiva de início')title=String(Math.max(0,Math.floor(presetNum(blk,'segundos',3,ctx))));
      else if(name==='Preset de tela de resultado da partida')title=presetString(blk,'título','Resultado',ctx);
      else if(name==='Preset de convite de amigo')title=presetString(blk,'texto','Convidar amigo',ctx);
      else if(name==='Preset de chat rápido')title='GG  •  Boa!  •  Vamos!';
      else if(name==='Preset de indicador de host')title='Host: '+presetString(blk,'nome','Host',ctx);
      node.el.textContent=title;
      preset.screens[boxId]={name,node:node.el};
      if(name==='Preset de contagem regressiva de início'){
        const end=performance.now()+Math.max(0,Math.floor(presetNum(blk,'segundos',3,ctx)))*1000;node.el.dataset.end=String(end);
        const timer=()=>{if(!node.el.isConnected)return;const left=Math.max(0,Math.ceil((end-performance.now())/1000));node.el.textContent=String(left);if(left<=0){node.el.remove();return;}kixRequestAnimationFrame(timer);};kixRequestAnimationFrame(timer);
      }
    }
    preset.multiplayer[name]=Object.fromEntries((blk.params||[]).map(p=>{const k=typeof p==='string'?p:p.name;return [k,param(blk,k,0,ctx)];}));
    return true;
  }

  function executeProductionBlock(co,blk,ctx,now) {
    const name=blk.legacyName || blk.name || '';
    const n=canonicalBlockName(name);
    const d=co.actor.data;
    if (executePresetBlock(co, blk, ctx, now)) return true;
    if(n==='Reproduzir animação da pasta'||n==='Repetir animação da pasta'||n==='Repetir animação da pasta em loop'||n==='Parar animação da pasta'){
      const folder=paramStr(blk,'pasta',d._activeFolder||'',ctx).replace(/^['"]|['"]$/g,'');
      if(n==='Parar animação da pasta'){stopLookAnimation(co.actor);return true;}
      setFolderAsAppearance(co.actor,folder,false);
      const loop=n!=='Reproduzir animação da pasta';
      startLookAnimation(co.actor,folder,{loop,fps:Number(param(blk,'fps',12,ctx))||12});
      return true;
    }
    // Joystick/virtual-control presets are handled exclusively by executePresetBlock above.
    if(n==='Criar câmera de seguimento'||n==='Definir alvo da câmera'||n==='Definir zoom da câmera'||n==='Câmera com suavização'||n==='Câmera com paralaxe'){
      runtime._cameraPresets=runtime._cameraPresets||{};const id=paramStr(blk,'id','main',ctx).replace(/['"]/g,'')||'main';const c=runtime._cameraPresets[id]||(runtime._cameraPresets[id]={});
      if(n==='Criar câmera de seguimento')c.target=paramStr(blk,'ator','',ctx).replace(/['"]/g,'');
      if(n==='Definir alvo da câmera')c.target=paramStr(blk,'ator','',ctx).replace(/['"]/g,'');
      if(n==='Definir zoom da câmera')runtime.camZoom=Math.max(.05,Number(param(blk,'valor',1,ctx))||1);
      if(n==='Câmera com suavização')runtime.camSmoothing=Math.max(0,Math.min(1,Number(param(blk,'valor',.2,ctx))||.2));
      if(n==='Câmera com paralaxe')runtime.camParallax=Number(param(blk,'fator',1,ctx))||1;
      applyEngineCamera();return true;
    }
    if(n==='Preset de checkpoint'){runtime.checkpoint={id:paramStr(blk,'id','checkpoint',ctx).replace(/['"]/g,''),x:d.x,y:d.y};return true;}
    if(n==='Preset de objetivo da fase'){runtime.levelObjective=paramStr(blk,'texto','Objetivo',ctx);return true;}
    if(n.startsWith('Transição ')||n==='Definir duração da transição'){runtime._transition=runtime._transition||{};runtime._transition.type=n;runtime._transition.seconds=Number(param(blk,'segundos',.5,ctx))||.5;return true;}
    if(n.startsWith('Preset de tela de')||n==='Preset de menu pausado'){const id='preset_'+n.replace(/\W+/g,'_');const h=hudEl(id,'div','position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.72);color:#fff;font-size:22px;font-weight:600;pointer-events:auto;');if(h)h.el.textContent=paramStr(blk,'texto',paramStr(blk,'título','',ctx),ctx);return true;}
    if(n.startsWith('Preset:')){runtime._presets=runtime._presets||{};runtime._presets[n]=Object.fromEntries((blk.params||[]).map(p=>[typeof p==='string'?p:p.name,param(blk,typeof p==='string'?p:p.name,0,ctx)]));if(n.includes('coletável'))runtime.globals.coletaveis=(Number(runtime.globals.coletaveis)||0)+1;if(n.includes('dano por contato'))d._damageOnContact=Number(param(blk,'dano',1,ctx))||1;if(n.includes('empurrão')){d.vx+=Math.cos(Number(param(blk,'direção',0,ctx))*Math.PI/180)*(Number(param(blk,'força',4,ctx))||4);d.vy+=Math.sin(Number(param(blk,'direção',0,ctx))*Math.PI/180)*(Number(param(blk,'força',4,ctx))||4);}if(n.includes('zona de teleporte')){d.x=Number(param(blk,'x',d.x,ctx));d.y=Number(param(blk,'y',d.y,ctx));updateSpriteTransform(co.actor);}return true;}
    if(n==='Indicador de conexão (ping/status)'||n.startsWith('Preset de sala')||n.startsWith('Preset de busca')||n.startsWith('Preset de lista')||n.startsWith('Preset de botão pronto')||n.startsWith('Preset de contagem')||n.startsWith('Preset de tela de resultado')||n.startsWith('Preset de convite')||n.startsWith('Preset de chat')||n.startsWith('Preset de indicador de host')){runtime._presets=runtime._presets||{controls:{},transitions:{},screens:{},multiplayer:{}};runtime._presets.multiplayer[n]=Object.assign({},blk.values||{});return true;}

    // Movement/physics
    if(n==='Ir para X: Y:' || n==='Ir para X e Y'){ actorPositionSet(co.actor, Number(param(blk,'x',0,ctx)), Number(param(blk,'y',0,ctx)), true); return true; }
    if(n==='Definir Gravidade Custom' || n==='Definir gravidade personalizada'){ runtime.physics=runtime.physics||{}; runtime.physics.gravity=Number(param(blk,'valor',param(blk,'gravidade',9.8,ctx),ctx)); return true; }
    if(n==='Definir Restituição'){ d.restitution=Math.max(0,Math.min(1,Number(param(blk,'valor',.5,ctx)))); return true; }
    if(n==='Otimizar Mundo Físico'){ runtime.physics=runtime.physics||{}; runtime.physics.optimized=true; runtime.physics.gridSize=Math.max(16,Number(param(blk,'tamanho',64,ctx))||64); return true; }
    if(n==='Criar Joint/Mola'){ runtime.joints=runtime.joints||[]; runtime.joints.push({a:paramStr(blk,'a','',ctx),b:paramStr(blk,'b','',ctx),stiffness:Number(param(blk,'força',.5,ctx)),length:Number(param(blk,'comprimento',50,ctx))}); return true; }
    if(n==='Física de Veículo' || n==='Configurar física de veículo'){ d.vehicle={engine:Number(param(blk,'motor',1,ctx)),grip:Number(param(blk,'aderência',1,ctx)),brake:Number(param(blk,'freio',1,ctx))}; return true; }
    if(n==='Simular Explosão' || n==='Simular explosão'){ const x=Number(param(blk,'x',d.x,ctx)),y=Number(param(blk,'y',d.y,ctx)),r=Math.max(1,Number(param(blk,'raio',100,ctx))); runtime.actors.forEach(a=>{if(a===co.actor)return;const dx=a.data.x-x,dy=a.data.y-y,dist=Math.hypot(dx,dy);if(dist<=r){const f=(1-dist/r)*(Number(param(blk,'força',10,ctx))||10);a.data.vx=(a.data.vx||0)+(dx/(dist||1))*f;a.data.vy=(a.data.vy||0)+(dy/(dist||1))*f;}}); for(let i=0;i<18;i++)productionParticle(x,y,{vx:(runtimeRandom()-.5)*8,vy:(runtimeRandom()-.5)*8,life:.5,maxLife:.5,size:4,color:'#ff8a00'}); return true; }
    if(n==='Detectar Contato'){ d._lastContact=runtime.actors.some(a=>a!==co.actor&&checkCollision(co.actor,a)); return true; }
    if(n==='Path de Física'){ d._physicsPath=paramStr(blk,'caminho','',ctx); return true; }
    // Drawings
    const drawNames=new Set(['Desenhar linha','Desenhar círculo','Desenhar retângulo','Desenhar polígono','Preencher forma com cor','Desenhar texto vetorial','Carimbar (stamp)']);
    if(drawNames.has(n)){ const dr=productionDrawing(),c=runtime._drawingCtx; if(!c)return true; const dm=projectStageMetrics(),dw=dm.logicalW,dh=dm.logicalH; const x=Number(param(blk,'x',d.x,ctx)),y=Number(param(blk,'y',d.y,ctx)); c.save();c.globalAlpha=dr.opacity;c.strokeStyle=dr.color;c.fillStyle=dr.color;c.lineWidth=dr.width;c.beginPath(); if(n==='Desenhar linha'){c.moveTo(d.x+dw/2,dh/2-d.y);c.lineTo(x+dw/2,dh/2-y);c.stroke();} else if(n==='Desenhar círculo'){const r=Math.max(0,Number(param(blk,'raio',20,ctx)));c.arc(x+dw/2,dh/2-y,r,0,Math.PI*2);paramStr(blk,'preencher','',ctx)?c.fill():c.stroke();} else if(n==='Desenhar retângulo'){const rw=Number(param(blk,'largura',40,ctx)),rh=Number(param(blk,'altura',40,ctx));c.rect(x+dw/2-rw/2,dh/2-y-rh/2,rw,rh);paramStr(blk,'preencher','',ctx)?c.fill():c.stroke();} else if(n==='Desenhar polígono'){const pts=String(paramStr(blk,'pontos','',ctx)).split(/[;|]/).map(v=>v.split(',').map(Number));pts.forEach((q,i)=>i?c.lineTo(q[0]+dw/2,dh/2-q[1]):c.moveTo(q[0]+dw/2,dh/2-q[1]));c.closePath();c.stroke();} else if(n==='Preencher forma com cor'){c.fillRect(x+dw/2,y*-1+dh/2,Number(param(blk,'largura',20,ctx)),Number(param(blk,'altura',20,ctx)));} else if(n==='Desenhar texto vetorial'){c.font=(Number(param(blk,'tamanho',20,ctx))||20)+'px sans-serif';c.fillText(paramStr(blk,'texto','',ctx),x+dw/2,dh/2-y);} else { const text=String(d._looksText||'');c.font='16px sans-serif';c.fillText(text,x+dw/2,dh/2-y);} c.restore(); return true; }
    if(n==='Definir espessura do traço'){productionDrawing().width=Math.max(.5,Number(param(blk,'valor',4,ctx)));return true;}
    if(n==='Definir tamanho da caneta'){productionDrawing().width=Math.max(.5,Number(param(blk,'tamanho',4,ctx)));return true;}
    if(n==='Definir opacidade da caneta'){productionDrawing().opacity=Math.max(0,Math.min(1,Number(param(blk,'valor',1,ctx))));return true;}
    if(n==='Abaixar caneta'){productionDrawing().penDown=true;return true;} if(n==='Levantar caneta'){productionDrawing().penDown=false;return true;}
    if(n==='Limpar desenho'||n==='Limpar tudo'){clearDrawing();return true;}
    // NPCs
    if(n==='Criar NPC'||n.startsWith('Definir comportamento do NPC')||n.startsWith('Definir estado do NPC')||n.startsWith('Definir objetivo do NPC')||n.startsWith('Definir alvo do NPC')||n.startsWith('NPC ')||n.startsWith('Definir visão do NPC')||n.startsWith('Definir alcance')||n.startsWith('Definir memória')||n.startsWith('Definir personalidade')||n.startsWith('Definir agressividade')||n.startsWith('Definir inteligência')||n.startsWith('Definir dificuldade')||n.startsWith('Definir reação')||n.startsWith('Quando NPC')) return productionNpc(co.actor,n,blk,ctx);
    // Shaders
    if(n==='Aplicar shader ao ator'||n==='Remover shader'||n.includes('shader')||n.includes('Shader')) return productionShader(n,blk,ctx,co.actor);
    // Phone: haptics, sharing and language
    if(n==='Vibrar curto'||n==='Vibrar longo'||n==='Padrão de vibração customizado'||n==='Parar vibração'){ const pattern=n==='Vibrar curto'?[60]:n==='Vibrar longo'?[220]:n==='Parar vibração'?[]:String(paramStr(blk,'padrão','',ctx)).split(',').map(Number); try{navigator.vibrate?.(pattern);}catch(_){} runtime._vibrationPattern=pattern; return true; }
    if(n==='Quando vibração terminar'){runtime._vibrationDoneHat=true;return true;}
    if(n==='Quando compartilhar ok'){runtime._shareDoneHat=true;return true;}
    if(n==='Quando swipe'||n==='Quando pinça'||n==='Detectar toque duplo'){runtime.gestures=runtime.gestures||{};runtime.gestures.hats=runtime.gestures.hats||{};runtime.gestures.hats[n]=true;return true;}
    if(n==='Compartilhar pontuação'||n==='Compartilhar vídeo curto'){const score=runtime.globals.score??0,text=n==='Compartilhar pontuação'?String(score):paramStr(blk,'texto','',ctx);try{if(navigator.share)navigator.share({title:'Kix',text}).then(()=>{runtime._shareDoneHat=true;}).catch(()=>{});}catch(_){}return true;}
    if(n==='Renderizar sprite otimizado'){runtime.renderQuality=runtime.renderQuality||{};runtime.renderQuality.spriteOptimized=true;return true;}
    if(n==='Ativar modo de desenho em lote'){runtime.renderQuality=runtime.renderQuality||{};runtime.renderQuality.batch=true;return true;}
    if(n==='Definir qualidade de renderização'){runtime.renderQuality=runtime.renderQuality||{};runtime.renderQuality.quality=paramStr(blk,'qualidade','alta',ctx).replace(/['"]/g,'');return true;}
    if(n==='Pré-carregar textura'){const src=paramStr(blk,'caminho','',ctx).replace(/['"]/g,'');if(src){const im=new Image();im.src=src;globalImageCache.set(src,im);}return true;}
    if(n==='Liberar textura da memória'){const src=paramStr(blk,'caminho','',ctx).replace(/['"]/g,'');if(src)globalImageCache.delete(src);return true;}
    if(n==='Definir taxa de quadros alvo (FPS)'){runtime.targetFps=Math.max(1,Number(param(blk,'fps',60,ctx))||60);return true;}
    if(n==='Esconder texto'){const id=paramStr(blk,'id','texto',ctx).replace(/['"]/g,'');const h=ensureHud().elements[id];if(h?.el)h.el.style.display='none';return true;}
    if(n==='Definir alinhamento'){const id=paramStr(blk,'id','texto',ctx).replace(/['"]/g,'');const h=ensureHud().elements[id];if(h?.el)h.el.style.textAlign=paramStr(blk,'alinhamento','center',ctx).replace(/['"]/g,'');return true;}
    if(n==='Gradiente animado do texto'||n==='Iniciar animacao de texto'||n==='Iniciar animação de texto'||n==='Animacao de texto em loop'||n==='Animação de texto em loop'){const id=paramStr(blk,'id','texto',ctx).replace(/['"]/g,'');const h=ensureHud().elements[id];if(h?.el){h.el.style.backgroundImage='linear-gradient(90deg,currentColor,transparent,currentColor)';h.el.style.backgroundSize='200% 100%';h.el.style.animation='kixTextGradient 1.5s linear infinite';}return true;}
    if(n==='Finalizar animacao de texto'||n==='Finalizar animação de texto'){const id=paramStr(blk,'id','texto',ctx).replace(/['"]/g,'');const h=ensureHud().elements[id];if(h?.el)h.el.style.animation='none';return true;}
    if(n==='Definir texto com aspas coloridas'){const id=paramStr(blk,'id','texto',ctx).replace(/['"]/g,'');const h=ensureHud().elements[id];if(h?.el)renderQuotedColorText(h.el,paramStr(blk,'texto','',ctx),'#fff','#facc15');return true;}
    if(n==='Texto HUD rapido'||n==='Texto HUD rápido'){const id=paramStr(blk,'id','hud_texto',ctx).replace(/['"]/g,'');const h=hudEl(id,'div','position:absolute;left:50%;top:8px;transform:translateX(-50%);color:#fff;font-size:16px;');if(h)h.el.textContent=paramStr(blk,'texto','',ctx);return true;}
    if(n==='Titulo de nivel pronto'||n==='Título de nível pronto'){const h=hudEl('level_title','div','position:absolute;left:50%;top:25%;transform:translate(-50%,-50%);color:#fff;font-size:28px;font-weight:700;');if(h)h.el.textContent=paramStr(blk,'texto',runtime.level||'Nível',ctx);return true;}
    if(n==='Texto de dano flutuante'){const x=d.x,y=d.y;productionParticle(x,y,{text:paramStr(blk,'texto','-'+(param(blk,'dano',0,ctx)||0),ctx),size:0,life:1,maxLife:1,color:'#ef4444'});return true;}
    if(n==='Caixa de dialogo com digitacao pronta'||n==='Caixa de diálogo com digitação pronta'){const id=paramStr(blk,'id','dialogo',ctx).replace(/['"]/g,'');const h=hudEl(id,'div','position:absolute;left:50%;bottom:24px;transform:translateX(-50%);max-width:90%;padding:14px;background:rgba(15,15,20,.92);color:#fff;border-radius:10px;');if(h){h.el.textContent='';const txt=paramStr(blk,'texto','',ctx);let i=0;kixClearTimer(h.timer);h.timer=kixSetInterval(()=>{h.el.textContent=txt.slice(0,++i);if(i>=txt.length)kixClearTimer(h.timer);},30);}return true;}
    if(n==='Criptografar texto'||n==='Descriptografar texto'||n==='Gerar hash'){
      const input=paramStr(blk,'texto',paramStr(blk,'entrada',runtime.globals.texto_criptografado||'',ctx),ctx);
      const subtle=global.crypto&&global.crypto.subtle;
      const b64=u8=>{let s='';u8.forEach(x=>s+=String.fromCharCode(x));return btoa(s);};
      const ub64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
      if(subtle&&n==='Gerar hash') subtle.digest('SHA-256',new TextEncoder().encode(input)).then(b=>{runtime.globals.resultado_hash=Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('');});
      else if(subtle&&n==='Criptografar texto'){const iv=crypto.getRandomValues(new Uint8Array(12));subtle.generateKey({name:'AES-GCM',length:256},true,['encrypt','decrypt']).then(key=>Promise.all([subtle.exportKey('raw',key),subtle.encrypt({name:'AES-GCM',iv},key,new TextEncoder().encode(input))])).then(([kb,ct])=>{runtime.globals.chave_criptografia=b64(new Uint8Array(kb));runtime.globals.texto_criptografado=b64(new Uint8Array(ct));runtime.globals.iv_criptografia=b64(iv);runtime.globals.status_seguranca='concluído';});}
      else if(subtle&&n==='Descriptografar texto'){try{const keyBytes=ub64(runtime.globals.chave_criptografia||'');const iv=ub64(runtime.globals.iv_criptografia||'');const ct=ub64(runtime.globals.texto_criptografado||input);subtle.importKey('raw',keyBytes,{name:'AES-GCM'},false,['decrypt']).then(key=>subtle.decrypt({name:'AES-GCM',iv},key,ct)).then(pt=>{runtime.globals.texto_descriptografado=new TextDecoder().decode(pt);runtime.globals.status_seguranca='concluído';}).catch(()=>runtime.globals.status_seguranca='erro: chave ou dados inválidos');}catch(_){runtime.globals.status_seguranca='erro: dados de criptografia inválidos';}}
      else runtime.globals.texto_seguro=btoa(unescape(encodeURIComponent(input)));
      return true;
    }
    if(n==='Quando autenticação ok'){runtime._authOkHat=true;return true;}
    if(n==='Adicionar moedas'){runtime.globals.moedas=(Number(runtime.globals.moedas)||0)+(Number(param(blk,'quantidade',param(blk,'valor',0,ctx),ctx))||0);return true;}
    if(n==='Gastar moedas'){const q=Number(param(blk,'quantidade',param(blk,'valor',0,ctx),ctx))||0;if((Number(runtime.globals.moedas)||0)>=q)runtime.globals.moedas-=q;return true;}
    if(n==='Definir preço'){const id=paramStr(blk,'item','item',ctx).replace(/['"]/g,'');runtime.prices=runtime.prices||{};runtime.prices[id]=Number(param(blk,'preço',param(blk,'valor',0,ctx),ctx))||0;return true;}
    if(n==='Quando compra concluída'){runtime._purchaseDoneHat=true;return true;}
    if(n==='Definir idioma do jogo'||n==='Trocar idioma em tempo real'){ runtime.language=paramStr(blk,'idioma','pt-BR',ctx).replace(/['"]/g,''); startHatsFor(co.actor,'Quando idioma mudar'); return true; }
    if(n==='Detectar idioma do dispositivo'){runtime.deviceLanguage=(navigator.language||'pt-BR');return true;}
    if(n==='Texto traduzido por chave'){const key=paramStr(blk,'chave','',ctx).replace(/['"]/g,'');const dict=runtime.translations||{};d._lastTranslation=(dict[runtime.language]&&dict[runtime.language][key])||dict[key]||key;return true;}
    if(n==='Feedback tátil por evento'){runtime._hapticEvents=runtime._hapticEvents||{};runtime._hapticEvents[paramStr(blk,'evento','',ctx).replace(/['"]/g,'')]=Number(param(blk,'duração',60,ctx));return true;}
    if(n.includes('Compartilhar')||n==='Convidar amigo com link/código'){const text=paramStr(blk,'texto',paramStr(blk,'código',paramStr(blk,'pontuação',String(runtime.globals.score||0),ctx),ctx),ctx);if(n==='Compartilhar print da tela'&&navigator.share){navigator.share({title:'Kix',text}).catch(()=>{});}else if(navigator.share){navigator.share({title:'Kix',text}).catch(()=>{});}else{runtime._shareText=text;}return true;}
    // Gestures
    if(['Detectar pinça (pinch)','Arrastar com dois dedos','Swipe (direção)','Toque duplo','Pressionar e segurar','Rotação por gesto'].includes(n)){runtime.gestures=runtime.gestures||{};runtime.gestures.last=n;return true;}
    // Persistence
    if(n==='Salvar variável no dispositivo'){const key=paramStr(blk,'nome','valor',ctx).replace(/['"]/g,'');localStorage.setItem('kix.var.'+key,JSON.stringify(param(blk,'valor',0,ctx)));return true;}
    if(n==='Ler variável do dispositivo'){const key=paramStr(blk,'nome','valor',ctx).replace(/['"]/g,'');const v=JSON.parse(localStorage.getItem('kix.var.'+key)||'null');runtime.globals[key]=v==null?0:v;return true;}
    if(n==='Apagar dados salvos'){const key=paramStr(blk,'nome','',ctx).replace(/['"]/g,'');if(key)localStorage.removeItem('kix.var.'+key);else Object.keys(localStorage).filter(k=>k.startsWith('kix.var.')).forEach(k=>localStorage.removeItem(k));return true;}
    if(n==='Quando dados forem salvos'){runtime._dataSavedHat=true;return true;}
    // Debug
    if(n==='Log de texto'){console.log('[Kix]',paramStr(blk,'texto','',ctx));return true;}
    if(n==='Mostrar FPS'){runtime.showFps=true;return true;}
    if(n==='Assertar condição'){const ok=!!param(blk,'condição',0,ctx);if(!ok)console.error('[Kix assert]',paramStr(blk,'mensagem','Condição falsa',ctx));return true;}
    if(n==='Iniciar timer'){runtime.timers=runtime.timers||{};const id=paramStr(blk,'id','timer',ctx).replace(/['"]/g,'');runtime.timers[id]=performance.now()+Math.max(0,Number(param(blk,'segundos',1,ctx))*1000);return true;}
    if(n==='Quando timer acabar'){runtime._timerHat=true;return true;}
    if(n==='Quando erro ocorrer'){runtime._errorHat=true;return true;}
    // Levels
    if(n==='Carregar nível'){runtime.level=paramStr(blk,'nível',paramStr(blk,'id','1',ctx),ctx).replace(/['"]/g,'');return true;}
    if(n==='Próximo nível'){runtime.level=String(Number(runtime.level||0)+1);return true;}
    if(n==='Reiniciar nível'){runtime.level=runtime.level||'1';runtime._restartLevel=true;return true;}
    if(n==='Quando nível completo'){runtime._levelCompleteHat=true;return true;}
    // Layers
    if(n==='Mover para camada'){d.layer=Number(param(blk,'camada',0,ctx));updateSpriteTransform(co.actor);return true;}
    if(n==='Quando camada mudar'){runtime._layerChanged=true;return true;}
    // Animation advanced
    if(n==='Animar propriedade'){const prop=paramStr(blk,'propriedade','x',ctx).replace(/['"]/g,'');const to=Number(param(blk,'valor',0,ctx)),dur=Math.max(1,Number(param(blk,'duração',500,ctx)));d._tweens=d._tweens||[];d._tweens.push({prop,from:Number(d[prop])||0,to,start:now,duration:dur,curve:paramStr(blk,'curva','suave',ctx)});return true;}
    if(n==='Definir curva de animação'){d._animationCurve=paramStr(blk,'curva','suave',ctx).replace(/['"]/g,'');return true;}
    if(n==='Quando animação terminar'){d._animationDoneHat=true;return true;}
    return false;
  }

  // ===== Catrobat compatibility runtime =====
  // This layer is intentionally additive: legacy project names/behavior remain the
  // primary path. New conceptual Catrobat IDs are dispatched only for blocks that
  // were missing from the native catalog.
  function catCompatNorm(v) {
    return String(v == null ? '' : v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
  }
  function catCompatId(blk) {
    if (blk && blk.compatId) return String(blk.compatId);
    try {
      const aliases = global.KixCatrobatBrickAliases || {};
      return aliases[catCompatNorm(blk && blk.name)] || '';
    } catch (_) { return ''; }
  }
  function catCompatDef(blk) {
    const id = catCompatId(blk);
    if (!id) return null;
    try { return (global.KixCatrobatBrickRegistry || {})[id] || null; } catch (_) { return null; }
  }
  function catCompatEnsureState() {
    if (!runtime.catrobat) runtime.catrobat = {};
    const c = runtime.catrobat;
    if (!c.sound) c.sound = { tempo: 120, instrument: 'piano' };
    if (!c.plot) c.plot = { active: false, paths: [], lastByActor: {} };
    if (!c.embroidery) c.embroidery = { threadColor: '#000000', commands: [], running: false };
    if (!c.looks) c.looks = { cameraFacing: 'environment', cameraStream: null, cameraVideo: null, cameraCanvas: null };
    return c;
  }
  function catCompatClean(v) { return String(v == null ? '' : v).replace(/^['"]|['"]$/g,'').trim(); }
  function catCompatValue(blk, keys, def, ctx) {
    const arr = Array.isArray(keys) ? keys : [keys];
    for (const k of arr) { try { const v = blk && blk.values && blk.values[k] !== undefined ? param(blk,k,undefined,ctx) : undefined; if (v !== undefined && v !== null) return v; } catch (_) {} }
    return def;
  }
  function catCompatStr(blk, keys, def, ctx) {
    const arr = Array.isArray(keys) ? keys : [keys];
    for (const k of arr) { try { const v = blk && blk.values && blk.values[k] !== undefined ? paramStr(blk,k,'',ctx) : ''; if (v !== '') return catCompatClean(v); } catch (_) {} }
    return catCompatClean(def == null ? '' : def);
  }
  function catCompatBool(v, def) {
    if (v == null || v === '') return !!def;
    const s = catCompatNorm(v);
    if (['false','0','nao','não','off','desligado','desativado'].includes(s)) return false;
    if (['true','1','sim','on','ligado','ativado'].includes(s)) return true;
    return !!v;
  }
  function catCompatSetVar(co, name, value) {
    const n = catCompatClean(name || 'resposta') || 'resposta';
    try { deviceSetVar(co, n, value); } catch (_) { runtime.globals[n] = value; }
    return value;
  }
  function catCompatGetActor(name, fallback) {
    const key = catCompatClean(name || '');
    const actors = runtime.actors || [];
    if (!key) return fallback || null;
    return actors.find(a => a && a.data && String(a.data.name || '').toLowerCase() === key.toLowerCase()) ||
      actors.find(a => a && a.data && String(a.data.name || '').toLowerCase().includes(key.toLowerCase())) || fallback || null;
  }
  function catCompatDownloadText(filename, content, mime) {
    const data = String(content == null ? '' : content);
    const fn = String(filename || 'arquivo.txt').replace(/[\\/:*?"<>|]/g,'_');
    try {
      if (global.Android && typeof global.Android.beginFile === 'function') {
        const bytes = new TextEncoder().encode(data);
        const chunkSize = 48 * 1024;
        global.Android.beginFile(fn, mime || 'text/plain;charset=utf-8');
        for (let i=0;i<bytes.length;i+=chunkSize) {
          const chunk=bytes.subarray(i,i+chunkSize); let bin='';
          for(let j=0;j<chunk.length;j++) bin+=String.fromCharCode(chunk[j]);
          if (typeof global.Android.appendFileChunk === 'function') global.Android.appendFileChunk(btoa(bin));
        }
        if (typeof global.Android.finishFile === 'function') global.Android.finishFile();
        return true;
      }
      const blob = new Blob([data], {type:mime || 'text/plain;charset=utf-8'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href=url; a.download=fn; a.click();
      kixSetTimeout(()=>{try{URL.revokeObjectURL(url);}catch(_){}},1000);
      return true;
    } catch (e) { console.warn('[Catrobat] file export',e); return false; }
  }

  function catCompatToneFrequency(note) {
    const raw=catCompatClean(note);
    const names={c:0,'c#':1,db:1,d:2,'d#':3,eb:3,e:4,f:5,'f#':6,gb:6,g:7,'g#':8,ab:8,a:9,'a#':10,bb:10,b:11};
    const m=raw.toLowerCase().replace(/♯/g,'#').match(/^([a-g](?:#|b)?)(-?\d+)?$/);
    if(m){const oct=Number(m[2]==null?'4':m[2]);const semi=(oct+1)*12+(names[m[1].toLowerCase()]??0);return 440*Math.pow(2,(semi-69)/12);}
    const n=Number(raw); if(Number.isFinite(n)) return n>20 ? n : 440*Math.pow(2,(n-9)/12);
    const scale={do:0,ré:2,re:2,mi:4,fá:5,fa:5,sol:7,la:9,si:11};
    const k=catCompatNorm(raw); if(scale[k]!=null) return 440*Math.pow(2,((4+1)*12+scale[k]-69)/12);
    return 440;
  }
  function catCompatAudioContext() {
    const c=catCompatEnsureState();
    if(c.sound.audio) return c.sound.audio;
    try {
      const Ctx=global.AudioContext||global.webkitAudioContext;
      if(!Ctx) return null;
      c.sound.audio=new Ctx();
      return c.sound.audio;
    } catch (_) { return null; }
  }
  function catCompatPlayTone(freq, seconds, kind, volume) {
    const ctx=catCompatAudioContext(); const sec=Math.max(0.02,Number(seconds)||0.2); const vol=Math.max(0,Math.min(1,Number(volume==null?runtime.soundVolume:volume)||0));
    if(!ctx) return false;
    try {
      if(ctx.state==='suspended') ctx.resume().catch(()=>{});
      const osc=ctx.createOscillator(), gain=ctx.createGain();
      osc.type=kind || 'sine'; osc.frequency.value=Math.max(20,Math.min(20000,Number(freq)||440));
      gain.gain.setValueAtTime(Math.max(0.0001,vol),ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001,ctx.currentTime+sec);
      osc.connect(gain); gain.connect(ctx.destination); osc.start(); osc.stop(ctx.currentTime+sec+0.02);
      return true;
    } catch (_) { return false; }
  }
  function catCompatPlayDrum(drum, seconds, volume) {
    const ctx=catCompatAudioContext(); const sec=Math.max(0.03,Number(seconds)||0.15); if(!ctx) return false;
    try {
      if(ctx.state==='suspended') ctx.resume().catch(()=>{});
      const len=Math.max(1,Math.floor(ctx.sampleRate*sec)); const buf=ctx.createBuffer(1,len,ctx.sampleRate); const data=buf.getChannelData(0);
      for(let i=0;i<len;i++){ const t=i/len; data[i]=(runtimeRandom()*2-1)*Math.pow(1-t,3); }
      const src=ctx.createBufferSource(), filter=ctx.createBiquadFilter(), gain=ctx.createGain();
      const d=catCompatNorm(drum); filter.type=d.includes('hi')||d.includes('hat')?'highpass':'lowpass'; filter.frequency.value=d.includes('hi')||d.includes('hat')?5000:900;
      gain.gain.value=Math.max(0,Math.min(1,Number(volume==null?runtime.soundVolume:volume)||0)); src.buffer=buf; src.connect(filter); filter.connect(gain); gain.connect(ctx.destination); src.start();
      return true;
    } catch (_) { return false; }
  }
  function catCompatBeatSeconds() { const c=catCompatEnsureState(); return 60/Math.max(20,Math.min(400,Number(c.sound.tempo)||120)); }

  function catCompatRecordPlotMove(ra, fromX, fromY, toX, toY) {
    const c=catCompatEnsureState(); if(!c.plot.active || !ra || !ra.data) return;
    if(!c.plot.paths.length || c.plot.lastActor!==ra) { c.plot.paths.push([]); c.plot.lastActor=ra; }
    const path=c.plot.paths[c.plot.paths.length-1];
    if(!path.length) path.push({x:Number(fromX)||0,y:Number(fromY)||0});
    path.push({x:Number(toX)||0,y:Number(toY)||0});
  }
  function catCompatPlotSvg() {
    const c=catCompatEnsureState();
    const paths=c.plot.paths||[];
    const lines=paths.filter(p=>p&&p.length).map(p=>'<polyline fill="none" stroke="black" stroke-width="1" points="'+p.map(q=>`${Number(q.x)||0},${-(Number(q.y)||0)}`).join(' ')+'"/>').join('');
    return '<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" viewBox="-240 -400 480 800">'+lines+'</svg>';
  }

  function catCompatCreateClone(source) {
    if(!source || !source.data || !source.el || !runtime.stageEl) return null;
    try {
      const a=JSON.parse(JSON.stringify(source.data));
      a.isClone=true; a.cloneOf=a.kixId||a.id||a.name||source.index; a.name=String(a.name||'Objeto')+' (clone)';
      a.id='clone_'+runtimeNow().toString(36)+'_'+runtimeRandom().toString(36).slice(2,8);
      const el=source.el.cloneNode(true); el.dataset.clone='1'; el.dataset.actorIdx=String(runtime.actors.length); el.style.opacity='';
      const ra={data:a,el,index:runtime.actors.length,id:a.id};
      el.addEventListener('click',e=>{e.stopPropagation(); if(runtime._suppressActorClickUntil && performance.now()<runtime._suppressActorClickUntil)return; broadcastTouch(ra.index);});
      runtime.stageEl.appendChild(el); runtime.actors.push(ra); updateSpriteTransform(ra,true);
      // clone starts from its own clone-start hats
      startHatsFor(ra,'Quando começar como clone');
      return ra;
    } catch(e){ console.warn('[Catrobat] clone',e); return null; }
  }

  function catCompatSequenceNormalize(sequence) {
    if(!Array.isArray(sequence)) return [];
    return sequence.map((x,i)=>{
      if(typeof x==='string') return {id:'seq_'+i,name:x,params:[],values:{}};
      const o=x||{};
      const out={
        id:String(o.id||('seq_'+i)),
        name:String(o.name||''),
        params:Array.isArray(o.params)?o.params.slice():[],
        values:o.values&&typeof o.values==='object'?Object.assign({},o.values):{},
        disabled:o.disabled===true
      };
      ['type','loopEndId','ifEndId','ifElseId','customBrickId','brickType'].forEach(key=>{if(o[key]!=null&&o[key]!=='' )out[key]=String(o[key]);});
      ['loopBoundaryExplicit','ifBoundaryExplicit','ifElseExplicit'].forEach(key=>{if(o[key]===true)out[key]=true;});
      if(o.catrobat&&typeof o.catrobat==='object'){out.catrobat={};['sourceType','adapted','adaptedFrom','sourcePreserved','userDefinedBrickId'].forEach(key=>{if(o.catrobat[key]!=null)out.catrobat[key]=o.catrobat[key];});}
      return out;
    }).filter(x=>x.name);
  }
  function catCompatFindCustom(project,idOrName) {
    const defs=Array.isArray(project&&project.customBricks)?project.customBricks:[];
    const q=catCompatClean(idOrName||'');
    return defs.find(d=>String(d.id)===q)||defs.find(d=>String(d.name).toLowerCase()===q.toLowerCase())||null;
  }
  function catCompatSubstitute(v, blk, ctx) {
    if(typeof v!=='string') return v;
    return v.replace(/\{([^}]+)\}/g,(m,k)=>{
      const key=String(k).trim();
      if(blk && blk.values && blk.values[key]!==undefined) return String(blk.values[key]);
      try { return String(paramStr(blk,key,m,ctx)); } catch(_) { return m; }
    });
  }
  function catCompatExpandCustom(co, blk, ctx) {
    const def=catCompatFindCustom(runtime.project, blk && blk.customBrickId ? blk.customBrickId : blk && blk.name);
    if(!def) return null;
    const seq=catCompatSequenceNormalize(def.sequence);
    if(!seq.length) return {first:null,ids:[]};
    // Prevent unbounded self-recursive custom-brick expansion from taking the
    // interpreter into an infinite allocation loop. Nested custom calls still work.
    const expansionStack=Array.isArray(blk?.customExpansionStack) ? blk.customExpansionStack.map(String) : [];
    const defKey=String(def.id||def.name||'');
    if (defKey && expansionStack.includes(defKey)) {
      console.warn('[Catrobat] recursão de bloco personalizado detectada', def.name);
      return {first:null,ids:[]};
    }
    const nextExpansionStack=defKey ? expansionStack.concat(defKey) : expansionStack.slice();

    const ids=[];
    const idMap=new Map();
    const base='__custom_'+String(blk.id||runtimeNow())+'_';
    for(let i=0;i<seq.length;i++){
      const oldId=String(seq[i].id||('seq_'+i));
      const newId=base+i;
      ids.push(newId);
      idMap.set(oldId,newId);
    }

    const expanded=[];
    for(let i=0;i<seq.length;i++){
      const src=seq[i];
      const b={
        id:ids[i],
        name:src.name,
        params:src.params||[],
        values:{},
        type:src.type&&['hat','action','loop','if','note','custom'].includes(String(src.type)) ? String(src.type) : blockType(src.name),
        disabled:src.disabled===true,
        customExpandedFrom:String(blk.id||''),
        customExpansionStack:nextExpansionStack.slice(),
        catrobat:src.catrobat&&typeof src.catrobat==='object'?Object.assign({},src.catrobat):undefined
      };
      Object.keys(src.values||{}).forEach(k=>b.values[k]=catCompatSubstitute(src.values[k],blk,ctx));
      if(src.loopEndId!=null) { b.loopEndId=idMap.get(String(src.loopEndId)) || null; b.loopBoundaryExplicit=src.loopBoundaryExplicit===true; }
      if(src.ifEndId!=null) { b.ifEndId=idMap.get(String(src.ifEndId)) || null; b.ifBoundaryExplicit=src.ifBoundaryExplicit===true; }
      if(src.ifElseId!=null) { b.ifElseId=idMap.get(String(src.ifElseId)) || null; b.ifElseExplicit=src.ifElseExplicit===true; }
      if(src.customBrickId) b.customBrickId=String(src.customBrickId);
      if(src.brickType) b.brickType=String(src.brickType);
      b.customExpansionStack=nextExpansionStack.slice();
      if(b.catrobat&&src.userDefinedBrickId&&!b.catrobat.userDefinedBrickId)b.catrobat.userDefinedBrickId=src.userDefinedBrickId;
      expanded.push(b);
    }

    // Reconstruct the same tree that normal imported scripts use. This is critical
    // for loops/IFs inside YourBricks; simply linking next pointers would flatten
    // nested control semantics and lose body/bodyElse.
    const tree=migrateScripts(expanded);
    const treeIds=Object.keys(tree.blocks||{});
    treeIds.forEach(id=>{
      const src=expanded.find(x=>String(x.id)===String(id));
      if(src?.customExpandedFrom) tree.blocks[id].customExpandedFrom=src.customExpandedFrom;
      if(Array.isArray(src?.customExpansionStack)) tree.blocks[id].customExpansionStack=src.customExpansionStack.slice();
      if(src?.catrobat && !tree.blocks[id].catrobat) tree.blocks[id].catrobat=Object.assign({},src.catrobat);
    });
    treeIds.forEach(id=>{ if(tree.blocks[id]?.customBrickId) tree.blocks[id].customBrickId=String(tree.blocks[id].customBrickId); });

    const rootId=(tree.stacks||[])[0] || null;
    if(!rootId) return {first:null,ids:[]};
    if (!co.blocks || typeof co.blocks !== 'object') co.blocks={};
    Object.assign(co.blocks,tree.blocks);
    let tail=rootId;
    const seen=new Set();
    while(tail && !seen.has(String(tail))){
      seen.add(String(tail));
      const next=co.blocks?.[tail]?.next;
      if(!next) break;
      tail=next;
    }
    if(co.blocks?.[tail]) co.blocks[tail].next=blk.next||null;
    return {first:rootId,ids:treeIds};
  }

  function executeCatrobatCompatBlock(co, blk, ctx, now) {
    if(!blk || !co) return false;
    // Custom/user-defined bricks are project-scoped and can be nested inside loops/ifs.
    if(blk.customBrickId || catCompatId(blk)==='yourbricks.dynamic') {
      const exp=catCompatExpandCustom(co,blk,ctx);
      if(exp && exp.first){ co.ip=exp.first; return {jump:true,handled:true}; }
      return true;
    }
    const id=catCompatId(blk); if(!id) return false;
    const def=catCompatDef(blk);
    if(!def || def.compatNative!==false) return false;

    // ---- EVENT ----
    if(id==='event.when_background_changes' || id==='event.when_condition_true' || id==='motion.when_bounce') return false; // hats are dispatched by watchers

    // ---- CONTROL ----
    if(id==='control.continue_scene'){ runtime.running=true; return true; }
    if(id==='control.create_clone') { const target=catCompatGetActor(catCompatStr(blk,['object','target'],'',ctx),co.actor); catCompatCreateClone(target); return true; }
    if(id==='control.finish_stage') { stopAll(); runtime.running=false; return true; }
    if(id==='control.start_scene') {
      const wanted=catCompatStr(blk,['scene'],'',ctx);
      try { if(typeof global.KixChangeScene==='function') global.KixChangeScene(wanted); else if(global.currentProject&&Array.isArray(global.currentProject.scenes)){ const idx=Math.max(0,global.currentProject.scenes.findIndex(s=>String(s.name).toLowerCase()===wanted.toLowerCase())); restartEngine(global.currentProject,idx,global.currentProject.vars||runtime.globals); } } catch(_) {}
      return true;
    }
    if(id==='control.stop') { co.dead=true; return true; }
    if(id==='control.wait_until_scripts_stopped') {
      const alive=(runtime.coroutines||[]).some(c=>c&&c!==co&&!c.dead);
      if(alive){ co.waitUntil=now+50; return {yield:true,handled:true}; }
      return true;
    }
    if(id==='control.for_each' || id==='control.for_range') {
      const body=Array.isArray(blk.body)?blk.body:[];
      if(!body.length){co.ip=blk.next||null;return {jump:true,handled:true};}
      if(blk._compatLoopInit!==true){
        blk._compatLoopInit=true;
        let values=[];
        if(id==='control.for_each'){
          const raw=catCompatStr(blk,['source'],'',ctx);
          const key=raw.replace(/^['"]|['"]$/g,'');
          const list=runtime.lists&&Array.isArray(runtime.lists[key])?runtime.lists[key]:((runtime.globals||{})['__list_'+key]);
          if(Array.isArray(list)) values=list.slice(); else values=String(raw||'').split(',').map(s=>s.trim()).filter(Boolean);
        } else {
          const from=Number(catCompatValue(blk,['from'],1,ctx)); const to=Number(catCompatValue(blk,['to'],10,ctx)); const step=from<=to?1:-1; for(let v=from;step>0?v<=to:v>=to;v+=step) values.push(v);
        }
        blk._compatLoopValues=values; blk._compatLoopIndex=0; blk._compatLoopVar=catCompatStr(blk,['value'],'valor',ctx);
      }
      const vals=blk._compatLoopValues||[]; const ix=Number(blk._compatLoopIndex)||0;
      if(ix>=vals.length){blk._compatLoopInit=false;blk._compatLoopValues=null;co.ip=blk.next||null;return {jump:true,handled:true};}
      catCompatSetVar(co,blk._compatLoopVar,vals[ix]);
      co.loopStack=co.loopStack||[];
      co.loopStack.push({kind:'compat_foreach',blockId:blk.id,bodyStart:body[0],after:blk.next});
      co.ip=body[0];
      return {jump:true,handled:true};
    }

    // ---- MOTION ----
    if(id==='motion.go_back_layer') {
      goRuntimeActorBack(co.actor, catCompatValue(blk,['layers'],1,ctx));
      co.actor._lastKey=null; updateSpriteTransform(co.actor,true); return true;
    }
    if(id==='motion.go_to_front') {
      bringRuntimeActorToFront(co.actor);
      co.actor._lastKey=null; updateSpriteTransform(co.actor,true); return true;
    }
    if(id==='motion.set_velocity') { co.actor.data.vx=Number(catCompatValue(blk,['x'],0,ctx))||0; co.actor.data.vy=Number(catCompatValue(blk,['y'],0,ctx))||0; return true; }
    if(id==='motion.set_motion_type') { co.actor.data.motionType=catCompatStr(blk,['type'],'normal',ctx); return true; }
    if(id==='motion.spin_left' || id==='motion.spin_right') { const v=Number(catCompatValue(blk,['degreesPerSecond'],0,ctx))||0; const sign=id==='motion.spin_left'?1:-1; co.actor.data.direction=(Number(co.actor.data.direction)||0)+sign*v*(runtime.frameMs/1000); co.actor._lastKey=null; updateSpriteTransform(co.actor,true); return true; }
    if(id==='motion.vibrate') {
      const sec=Math.max(0.01,Number(catCompatValue(blk,['seconds'],0.2,ctx))||0.2); co.actor.data._vibrateUntil=now+sec*1000;
      try { if(global.navigator?.vibrate) global.navigator.vibrate(Math.max(1,Math.floor(sec*1000))); } catch(_) {}
      return true;
    }
    if(id==='motion.set_bounce_factor'){co.actor.data.bounceFactor=Math.max(0,Number(catCompatValue(blk,['percent'],100,ctx))/100);return true;}
    if(id==='motion.set_friction'){co.actor.data.friction=Math.max(0,Number(catCompatValue(blk,['percent'],0,ctx))/100);return true;}
    if(id==='motion.set_gravity'){runtime.gravity=Number(catCompatValue(blk,['gravity'],9.8,ctx))||0;(runtime.actors||[]).forEach(a=>{a.data.gravity=runtime.gravity;});return true;}
    if(id==='motion.set_mass'){co.actor.data.mass=Math.max(0.001,Number(catCompatValue(blk,['kilogram'],1,ctx))||1);return true;}

    // ---- SOUND ----
    if(id==='sound.play_note') { const beats=Math.max(0.01,Number(catCompatValue(blk,['beats'],1,ctx))||1); const sec=beats*catCompatBeatSeconds(); catCompatPlayTone(catCompatToneFrequency(catCompatValue(blk,['note'],'A4',ctx)),sec,'sine'); co.waitUntil=now+sec*1000; return {yield:true,handled:true}; }
    if(id==='sound.play_drum') { const beats=Math.max(0.01,Number(catCompatValue(blk,['beats'],1,ctx))||1); const sec=beats*catCompatBeatSeconds(); catCompatPlayDrum(catCompatValue(blk,['drum'],'bass',ctx),Math.min(sec,0.6)); co.waitUntil=now+sec*1000; return {yield:true,handled:true}; }
    if(id==='sound.set_instrument'){catCompatEnsureState().sound.instrument=catCompatStr(blk,['instrument'],'piano',ctx);return true;}
    if(id==='sound.change_tempo'){const c=catCompatEnsureState();c.sound.tempo=Math.max(20,Math.min(400,(Number(c.sound.tempo)||120)+(Number(catCompatValue(blk,['bpm'],0,ctx))||0)));return true;}
    if(id==='sound.set_tempo'){catCompatEnsureState().sound.tempo=Math.max(20,Math.min(400,Number(catCompatValue(blk,['bpm'],120,ctx))||120));return true;}
    if(id==='sound.pause_beats'){const sec=Math.max(0.01,Number(catCompatValue(blk,['beats'],1,ctx))||1)*catCompatBeatSeconds();co.waitUntil=now+sec*1000;return {yield:true,handled:true};}
    if(id==='sound.stop'){ const key=catCompatStr(blk,['sound'],'',ctx); const entry=resolveSound(co.actor.data,key); (runtime.sounds||[]).forEach(a=>{try{if(!key||a._kixSoundName===key)a.pause();}catch(_) {}}); if(entry&&entry.audio)try{entry.audio.pause();}catch(_){} return true; }

    // ---- LOOKS ----
    const a=co.actor.data;
    if(id==='looks.ask_store'){
      const question=catCompatStr(blk,['question'],'',ctx), vn=catCompatStr(blk,['variable'],'resposta',ctx);
      try{
        const initial=String((ctx.vars && ctx.vars[vn] !== undefined ? ctx.vars[vn] : '') ?? '');
        if(typeof global.openRuntimeInputOverlay==='function'){
          global.openRuntimeInputOverlay({
            title:question || 'Entrada de texto', value:initial, multiline:false, confirmText:'Enviar',
            onInput:v=>{catCompatSetVar(co,vn,v);},
            onConfirm:v=>{catCompatSetVar(co,vn,v);},
            onCancel:v=>{catCompatSetVar(co,vn,v);}
          });
        }
      }catch(_){ }
      return true;
    }
    if(id==='looks.focus_point'){a.focusPoint={horizontal:Math.max(0,Math.min(100,Number(catCompatValue(blk,['horizontal'],50,ctx))||50)),vertical:Math.max(0,Math.min(100,Number(catCompatValue(blk,['vertical'],50,ctx))||50))};return true;}
    if(id==='looks.change_brightness'){a.brightness=(Number(a.brightness)||100)+(Number(catCompatValue(blk,['percent'],0,ctx))||0);refreshVisualFilter(co.actor);return true;}
    if(id==='looks.change_color'){a._hueShift=(Number(a._hueShift)||0)+(Number(catCompatValue(blk,['value'],0,ctx))||0);a._tintFilter='hue-rotate('+a._hueShift+'deg)';refreshVisualFilter(co.actor);return true;}
    if(id==='looks.change_size'){
      const current=Number.isFinite(Number(a.size))?Number(a.size):100;
      const delta=Number(catCompatValue(blk,['percent'],0,ctx));
      a.size=Math.max(1,Math.min(1000,current+(Number.isFinite(delta)?delta:0)));
      updateSpriteTransform(co.actor,true);
      return true;
    }
    if(id==='looks.change_transparency'){setActorTransparency(co.actor,Number(a.transparency||0)+(Number(catCompatValue(blk,['percent'],0,ctx))||0));return true;}
    if(id==='looks.clear_effects'){a.brightness=100;a.transparency=0;a._tintFilter='';a._shadow=null;refreshVisualFilter(co.actor);return true;}
    if(id==='looks.copy_look'){const src=resolveActorImage(a)||rootLooks(a)[Number(a.costume)||0];if(src){a.looks=Array.isArray(a.looks)?a.looks:[];a.looks.push(src);a.lookNames=a.lookNames||{};a.lookNames['root:r:'+(a.looks.length-1)]=catCompatStr(blk,['name'],'Copy',ctx);}return true;}
    if(id==='looks.delete_look'){const r=resolveLook(a,catCompatStr(blk,['look'],'',ctx),{numericOneBased:true});if(r&&Array.isArray(a.looks)&&a.looks.length>1){a.looks.splice(r.index,1);a.costume=Math.max(0,Math.min(a.looks.length-1,Number(a.costume)||0));setActorCostume(co.actor,a.looks[a.costume]);}return true;}
    if(id==='looks.edit_look'){a._lookEditRequested=catCompatStr(blk,['look'],'',ctx);runtimeDiagnostic('EXTERNAL_LOOK_BRICK','Brick looks.edit_look requer edição externa e não é executável no runtime de APK.',{blockId:blk.id,actor:a.name,look:a._lookEditRequested});return true;}
    if(id==='looks.fade_particle'){const sec=Math.max(0.01,Number(catCompatValue(blk,['seconds'],1,ctx))||1);a._particleFadeUntil=now+sec*1000;return true;}
    if(id==='looks.get_image_current'){const src=catCompatStr(blk,['source'],'',ctx);if(src){a.looks=Array.isArray(a.looks)?a.looks:[];a.looks.push(src);a.costume=a.looks.length-1;setActorCostume(co.actor,src);}return true;}
    if(id==='looks.next_look'){const looks=rootLooks(a);if(looks.length){a.costume=((Number(a.costume)||0)+1)%looks.length;setActorCostume(co.actor,looks[a.costume]);}return true;}
    if(id==='looks.paint_new_look'){const name=catCompatStr(blk,['name'],'Novo look',ctx);a.looks=Array.isArray(a.looks)?a.looks:[];const src=resolveActorImage(a)||'';if(src){a.looks.push(src);a.lookNames=a.lookNames||{};a.lookNames['root:r:'+(a.looks.length-1)]=name;a.costume=a.looks.length-1;setActorCostume(co.actor,src);}a._newLookName=name;return true;}
    if(id==='looks.previous_look'){const looks=rootLooks(a);if(looks.length){a.costume=((Number(a.costume)||0)-1+looks.length)%looks.length;setActorCostume(co.actor,looks[a.costume]);}return true;}
    if(id==='looks.say' || id==='looks.say_wait' || id==='looks.think' || id==='looks.think_wait'){const txt=catCompatStr(blk,['text'],'',ctx);a._text=txt;a._textMode=(id.includes('think')?'think':'say');refreshActorText(co.actor);if(id.endsWith('wait')){const sec=Math.max(0,Number(catCompatValue(blk,['seconds'],2,ctx))||2);co.waitUntil=now+sec*1000;return {yield:true,handled:true};}return true;}
    if(id==='looks.set_background' || id==='looks.set_background_wait'){const bg=(runtime.actors||[]).find(x=>x&&x.data&&x.data.isBackground)||null;if(bg){const v=catCompatStr(blk,['background'],'',ctx);if(v)applyAppearance(bg,v,{numericOneBased:true});}if(id.endsWith('_wait')){co.waitUntil=now+50;return {yield:true,handled:true};}return true;}
    if(id==='looks.set_background_number' || id==='looks.switch_look_number' || id==='looks.set_background_number_wait'){const n=Math.max(1,Math.floor(Number(catCompatValue(blk,['number'],1,ctx))||1));const target=id.startsWith('looks.set_background')?((runtime.actors||[]).find(x=>x&&x.data&&x.data.isBackground)||null):co.actor;if(target){const looks=rootLooks(target.data);if(looks.length){target.data.costume=Math.min(looks.length-1,n-1);setActorCostume(target,looks[target.data.costume]);}}if(id.endsWith('_wait')){co.waitUntil=now+50;return {yield:true,handled:true};}return true;}
    if(id==='looks.set_brightness'){a.brightness=Math.max(0,Math.min(200,Number(catCompatValue(blk,['percent'],100,ctx))||100));refreshVisualFilter(co.actor);return true;}
    if(id==='looks.set_color'){a._tintFilter='hue-rotate('+String(catCompatValue(blk,['color'],'0',ctx))+')';refreshVisualFilter(co.actor);return true;}
    if(id==='looks.set_particle_color'){a.particleColor=catCompatStr(blk,['color'],'#FFFFFF',ctx);return true;}
    if(id==='looks.set_size'){
      const value=Number(catCompatValue(blk,['percent'],100,ctx));
      a.size=Math.max(1,Math.min(1000,Number.isFinite(value)?value:100));
      updateSpriteTransform(co.actor,true);
      return true;
    }
    if(id==='looks.set_transparency'){setActorTransparency(co.actor,Number(catCompatValue(blk,['percent'],0,ctx))||0);return true;}
    if(id==='looks.show'){a.visible=true;updateSpriteTransform(co.actor,true);return true;}
    if(id==='looks.hide'){a.visible=false;updateSpriteTransform(co.actor,true);return true;}
    if(id==='looks.switch_look'){const v=catCompatStr(blk,['look'],'',ctx);applyAppearance(co.actor,v,{numericOneBased:true});return true;}
    if(id==='looks.think_wait'){return true;}
    if(id==='looks.turn_camera'){const c=catCompatEnsureState();c.looks.cameraRotation=(Number(c.looks.cameraRotation)||0)+(Number(catCompatValue(blk,['degrees'],0,ctx))||0);return true;}
    if(id==='looks.particle_additivity'){a.particleAdditive=catCompatBool(catCompatValue(blk,['state'],true,ctx),true);return true;}
    if(id==='looks.turn_flashlight'){const on=catCompatBool(catCompatValue(blk,['state'],true,ctx),true);const c=catCompatEnsureState();c.looks.flashlight=on;try{const track=c.looks.cameraStream&&c.looks.cameraStream.getVideoTracks()[0]; if(track&&track.applyConstraints)track.applyConstraints({advanced:[{torch:on}]}).catch(()=>{});}catch(_){}return true;}
    if(id==='looks.use_camera'){
      const facing=catCompatClean(catCompatValue(blk,['camera'],'environment',ctx))||'environment'; const c=catCompatEnsureState();c.looks.cameraFacing=facing;
      if(global.navigator?.mediaDevices?.getUserMedia){
        if(c.looks.cameraStream){try{c.looks.cameraStream.getTracks().forEach(t=>t.stop());}catch(_){} }
        try{ global.navigator.mediaDevices.getUserMedia({video:{facingMode:facing},audio:false}).then(stream=>{c.looks.cameraStream=stream;}).catch(()=>{}); }catch(_){}
      }
      return true;
    }

    // ---- DATA ----
    if(id==='data.write_variable_file' || id==='data.write_variable_device'){
      const vn=catCompatStr(blk,['variable','variável','variavel'],'valor',ctx), file=catCompatStr(blk,['file','arquivo'],'kix-'+vn+'.json',ctx);
      const value=runtime.globals[vn]??co.actor.data._vars?.[vn]??'';
      try{localStorage.setItem('kix.cat.var.'+catCompatClean(file||vn),JSON.stringify(value));}catch(_){}
      catCompatDownloadText(file,JSON.stringify(value),'application/json');return true;
    }
    if(id==='data.read_variable_file' || id==='data.read_variable_device'){
      const vn=catCompatStr(blk,['variable','variável','variavel'],'valor',ctx), file=catCompatStr(blk,['file','arquivo'],vn,ctx); const key='kix.cat.var.'+catCompatClean(file||vn); let v='';try{v=localStorage.getItem(key);if(v!=null)try{v=JSON.parse(v);}catch(_){} }catch(_){}catCompatSetVar(co,vn,v);return true;
    }
    if(id==='data.read_list_device' || id==='data.write_list_device'){
      const name=catCompatStr(blk,['list','lista'],'lista',ctx), key='kix.cat.list.'+name;
      if(id==='data.write_list_device'){try{localStorage.setItem(key,JSON.stringify(ensureList(name)));}catch(_){} } else {try{const v=JSON.parse(localStorage.getItem(key)||'[]');runtime.lists[name]=Array.isArray(v)?v:[];}catch(_){runtime.lists[name]=[];}}return true;
    }
    if(id==='data.web_request_store'){
      const url=String(catCompatStr(blk,['url'],'',ctx)),vn=catCompatStr(blk,['variable'],'resposta',ctx);if(!url){catCompatSetVar(co,vn,'');return true;}const ctl=new AbortController();const timer=kixSetTimeout(()=>ctl.abort(),Math.max(100,Number(runtime.network?.timeout)||5000));fetch(url,{signal:ctl.signal}).then(r=>r.text()).then(t=>catCompatSetVar(co,vn,t)).catch(e=>catCompatSetVar(co,vn,'' )).finally(()=>kixClearTimer(timer));return true;
    }
    if(id==='data.show_variable_xy' || id==='data.show_variable_style'){
      const vn=catCompatStr(blk,['variable'],'valor',ctx);if(!runtime.varVisible)runtime.varVisible={};runtime.varVisible[vn]=true;showVarOverlay(vn,true);const el=document.getElementById('kix-var-'+vn);if(el){if(id==='data.show_variable_xy'){el.style.left=Number(catCompatValue(blk,['x'],0,ctx))+'px';el.style.top=Number(catCompatValue(blk,['y'],0,ctx))+'px';}else{el.style.left=Number(catCompatValue(blk,['x'],0,ctx))+'px';el.style.top=Number(catCompatValue(blk,['y'],0,ctx))+'px';el.style.fontSize=Math.max(1,Number(catCompatValue(blk,['size'],12,ctx))||12)+'px';el.style.color=catCompatStr(blk,['color'],'#FFFFFF',ctx);el.style.textAlign=catCompatStr(blk,['aligned'],'left',ctx);}}return true;
    }
    if(id==='data.store_csv_column'){
      const col=Math.max(1,Math.floor(Number(catCompatValue(blk,['column'],1,ctx))||1))-1;const csv=String(catCompatValue(blk,['csv'],'',ctx));const rows=csv.split(/\r?\n/).map(r=>r.split(','));runtime.lists['csv_column']=rows.map(r=>r[col]==null?'':r[col]);return true;
    }
    if(id==='data.delete_item_list' || id==='data.delete_all_list' || id==='data.add_to_list' || id==='data.insert_list' || id==='data.replace_item_list' || id==='data.set_variable' || id==='data.change_variable' || id==='data.hide_variable') return false; // native aliases cover these

    // ---- PEN ----
    if(id==='pen.clear'){const layer=runtime.stageEl&&runtime.stageEl.querySelector('.pen-layer');if(layer)layer.innerHTML='';return true;}
    if(id==='pen.down'){co.actor.data.penDown=true;return true;}
    if(id==='pen.up'){co.actor.data.penDown=false;return true;}
    if(id==='pen.set_size'){co.actor.data.penSize=Number(catCompatValue(blk,['size'],1,ctx))||1;return true;}
    if(id==='pen.stamp'){try{const im=co.actor.el.querySelector('img');const layer=runtime.stageEl&&runtime.stageEl.querySelector('.pen-layer');if(im&&layer){const c=document.createElement('img');c.src=im.src;c.style.cssText='position:absolute;transform:translate(-50%,-50%);left:50%;top:50%;width:'+Math.max(1,(Number(a.size)||100))+'px;opacity:'+(1-(Number(a.transparency)||0)/100)+';';layer.appendChild(c);}}catch(_){}return true;}
    if(id==='pen.set_color'){const rgb=['red','green','blue'].map(k=>Math.max(0,Math.min(255,Number(catCompatValue(blk,[k],0,ctx))||0)));co.actor.data.penColor='rgb('+rgb.join(',')+')';return true;}

    // ---- EMBROIDERY ----
    if(id.startsWith('embroidery.')){const e=catCompatEnsureState().embroidery;
      if(id==='embroidery.set_thread_color')e.threadColor=catCompatStr(blk,['color'],'#000000',ctx);
      else if(id==='embroidery.running_stitch')e.commands.push({type:'running',length:Number(catCompatValue(blk,['length'],1,ctx))||1,color:e.threadColor});
      else if(id==='embroidery.zigzag_stitch')e.commands.push({type:'zigzag',length:Number(catCompatValue(blk,['length'],1,ctx))||1,width:Number(catCompatValue(blk,['width'],1,ctx))||1,color:e.threadColor});
      else if(id==='embroidery.triple_stitch')e.commands.push({type:'triple',length:Number(catCompatValue(blk,['length'],1,ctx))||1,color:e.threadColor});
      else if(id==='embroidery.sew_up')e.running=true;
      else if(id==='embroidery.stop_current_stitch')e.running=false;
      else if(id==='embroidery.write_file'){const file=catCompatStr(blk,['file'],'embroidery.json',ctx);catCompatDownloadText(file,JSON.stringify(e,null,2),'application/json');}
      else if(id==='embroidery.stitch')e.commands.push({type:'stitch',x:Number(catCompatValue(blk,['x'],0,ctx))||0,y:Number(catCompatValue(blk,['y'],0,ctx))||0,color:e.threadColor});
      return true;
    }

    // ---- PLOT ----
    if(id==='plot.start'){const c=catCompatEnsureState();c.plot.active=true;c.plot.paths=[];c.plot.lastActor=null;return true;}
    if(id==='plot.stop'){catCompatEnsureState().plot.active=false;return true;}
    if(id==='plot.save_svg'){const file=catCompatStr(blk,['file'],'plot.svg',ctx);catCompatDownloadText(file,catCompatPlotSvg(),'image/svg+xml');return true;}
    return false;
  }

  function stepCoroutine(co, now) {
    if (co.dead) return;
    if (now == null || isNaN(now)) now = performance.now();
    if (co.waitUntil) {
      if (now < co.waitUntil) return; // still waiting
      co.waitUntil = 0; // resume — clear so we don't stick
    }

    

    // ===== FLAT → TREE: use full handler set for every block =====
    if (co.flatMode) {
      try {
        const list = (co.flatBlocks || []).slice(co.flatIndex || 0).filter(function (s) { return s && !s.disabled; });
        if (!list.length) { co.dead = true; return; }
        list.forEach(function (s, i) {
          if (!s.id) s.id = 'fb' + i;
        });
        const tree = migrateScripts(list);
        // First block id
        let startId = list[0].id;
        if (!tree.blocks[startId]) {
          const keys = Object.keys(tree.blocks);
          startId = keys.length ? keys[0] : null;
          // prefer non-hat if first is hat
          if (startId && tree.blocks[startId] && tree.blocks[startId].type === 'hat' && tree.blocks[startId].next) {
            startId = tree.blocks[startId].next;
          }
        } else if (tree.blocks[startId].type === 'hat' && tree.blocks[startId].next) {
          startId = tree.blocks[startId].next;
        }
        if (!startId || !tree.blocks[startId]) { co.dead = true; return; }
        co.blocks = tree.blocks;
        co.tree = tree;
        co.ip = startId;
        co.flatMode = false;
        co.loopStack = co.loopStack || [];
        co.waitUntil = co.waitUntil || 0;
      } catch (e) {
        console.warn('[Kix] flat→tree', e);
        co.dead = true;
        return;
      }
      // fall through into full tree handler loop below
    }


    let steps = 0;
    while (steps++ < 32) {
      if (!co.ip) {
        // end of chain — check loop stack
        if (co.loopStack.length) {
          const L = co.loopStack[co.loopStack.length - 1];
          if (L.kind === 'forever') {
            co.ip = L.bodyStart;
            // yield one frame per forever iteration
            return;
          }
          if (L.kind === 'repeat') {
            L.count--;
            if (L.count > 0) {
              co.ip = L.bodyStart;
              return;
            }
            co.loopStack.pop();
            co.ip = L.after;
            continue;
          }
          if (L.kind === 'until' || L.type === 'until') {
            const owner = (co.blocks || {})[L.blockId];
            if (!owner) { co.loopStack.pop(); co.ip = L.after || null; continue; }
            const raw = param(owner, 'condição', param(owner, 'condicao', 0, {actor:co.actor.data,runtimeActor:co.actor,vars:co.actor.data._vars,globals:runtime.globals}), {actor:co.actor.data,runtimeActor:co.actor,vars:co.actor.data._vars,globals:runtime.globals});
            const truthy = !(raw === 0 || raw === '0' || raw === false || raw === 'false' || raw === '');
            const repeatWhile = String(owner.name||'') === 'Repita enquanto';
            const shouldContinue = repeatWhile ? truthy : !truthy;
            if (shouldContinue && L.bodyStart) { co.ip = L.bodyStart; return; }
            co.loopStack.pop();
            co.ip = L.after || owner.next || null;
            continue;
          }
          if (L.kind === 'compat_foreach') {
            const owner = (co.blocks || {})[L.blockId];
            if (!owner) { co.loopStack.pop(); co.ip = L.after || null; continue; }
            const vals = Array.isArray(owner._compatLoopValues) ? owner._compatLoopValues : [];
            const nextIndex = (Number(owner._compatLoopIndex) || 0) + 1;
            owner._compatLoopIndex = nextIndex;
            if (nextIndex < vals.length) {
              catCompatSetVar(co, owner._compatLoopVar || 'valor', vals[nextIndex]);
              co.ip = L.bodyStart;
              return;
            }
            owner._compatLoopInit = false; owner._compatLoopValues = null; owner._compatLoopIndex = 0;
            co.loopStack.pop();
            co.ip = L.after || owner.next || null;
            continue;
          }
        }
        co.dead = true;
        return;
      }

      const blk = (co.blocks || (co.tree && co.tree.blocks) || {})[co.ip];
      if (!blk) {
        co.ip = null;
        continue;
      }
      if (blk.disabled) {
        // Catrobat structural terminators are semantic boundaries, not disabled actions.
        // Loop ends return to the interpreter's loopStack so repeat counts are decremented;
        // IF ends jump to the block after the IF. Ordinary disabled blocks still skip normally.
        if (blk.boundaryKind === 'loop') {
          co.ip = null;
          continue;
        }
        if (blk.boundaryKind === 'ifElse') {
          const owner = blk.boundaryOwnerId && (co.blocks || {})[blk.boundaryOwnerId];
          co.ip = owner?.ifEndId || blk.next || null;
          continue;
        }
        if (blk.boundaryKind === 'if') {
          co.ip = blk.boundaryAfter || null;
          continue;
        }
        co.ip = blk.next || null;
        continue;
      }

      const ctx = {
        actor: co.actor.data,
        runtimeActor: co.actor,
        vars: co.actor.data._vars,
        globals: runtime.globals
      };
      // Resolve stable opcode first; legacy projects are migrated by name.
      blk.opcode = blk.opcode || stableOpcode(blk.name);
      const name = blk.name || '';
      const nname = (typeof normBlockName === 'function' ? normBlockName(name) : String(name).toLowerCase());
      let advanced = false;
      // Phase 3 hook is runtime-only and intentionally lives outside this interpreter.
      try {
        const p3 = global.KixPhase3Runtime?.beforeBlock?.({co, blk, ctx, now, name, nname, runtime});
        if (p3?.handled) {
          if (p3.advance !== false && co.ip === blk.id) co.ip = blk.next || null;
          if (p3.yield) return;
          continue;
        }
      } catch (phase3Error) {
        try { global.KixDiagnostics?.report?.('PHASE3_HOOK', String(phase3Error?.message || phase3Error), { actorId:co.actor?.id ?? null, actorName:co.actor?.data?.name ?? null, blockId:blk?.id ?? null }); } catch (_) {}
      }
      // Live text input: opens an in-play keyboard overlay without pausing the runtime or coroutine.
      if (name === 'Escrever texto em tempo real') {
        const variableName = paramStr(blk,'variável',paramStr(blk,'variavel','texto_digitado',ctx),ctx).replace(/^["']|["']$/g,'').trim() || 'texto_digitado';
        const x = Number(param(blk,'x',0,ctx)) || 0;
        const y = Number(param(blk,'y',0,ctx)) || 0;
        const size = Math.max(1, Number(param(blk,'tamanho',32,ctx)) || 32);
        const color = paramStr(blk,'cor','#FFFFFF',ctx);
        const font = paramStr(blk,'fonte','',ctx).replace(/^["']|["']$/g,'');
        const degrees = Number(param(blk,'graus',0,ctx)) || 0;
        const tid = 'texto_digitado';
        try {
          const textState = ensureActorTextState(co.actor, tid);
          textState.multiline = true;
          textState.style.x = x; textState.style.y = y; textState.style.fontSize = size;
          textState.style.color = color; textState.style.rotation = degrees;
          let initialFontFamily;
          if (font) initialFontFamily = loadTextFont(font, function(fam){ textState.style.fontFamily = '"' + fam + '", Arial, sans-serif'; refreshActorText(co.actor, tid); });
          const initial = String((ctx.vars && ctx.vars[variableName] !== undefined ? ctx.vars[variableName] : '') ?? '');
          showActorText(co.actor, initial, {x,y,fontSize:size,color,rotation:degrees,fontFamily:initialFontFamily}, tid);
          if (typeof window.openRuntimeInputOverlay === 'function') {
            window.openRuntimeInputOverlay({
              title:'Escrever texto → ' + variableName, value:initial, multiline:true, confirmText:'Concluir',
              onInput:function(v){ catCompatSetVar(co,variableName,v); const st=ensureActorTextState(co.actor,tid); st.multiline=true; showActorText(co.actor,v,{x,y,fontSize:size,color,rotation:degrees},tid); },
              onConfirm:function(v){ catCompatSetVar(co,variableName,v); const st=ensureActorTextState(co.actor,tid); st.multiline=true; showActorText(co.actor,v,{x,y,fontSize:size,color,rotation:degrees},tid); },
              onCancel:function(v){ catCompatSetVar(co,variableName,v); }
            });
          }
        } catch (_) {}
        co.ip = blk.next || null;
        continue;
      }

      // Question block: non-modal in-play input. Runtime and this coroutine continue immediately.
      if (name === 'Perguntar ao usuário') {
        const pergunta = paramStr(blk,'pergunta','Digite sua resposta',ctx);
        const vn = paramStr(blk,'variável',paramStr(blk,'variavel','resposta',ctx),ctx).replace(/^["']|["']$/g,'').trim() || 'resposta';
        try {
          const initial = String((ctx.vars && ctx.vars[vn] !== undefined ? ctx.vars[vn] : '') ?? '');
          if (typeof window.openRuntimeInputOverlay === 'function') {
            window.openRuntimeInputOverlay({
              title:pergunta || 'Perguntar', value:initial, multiline:false, confirmText:'Enviar',
              onInput:function(v){ deviceSetVar(co,vn,v); },
              onConfirm:function(v){ deviceSetVar(co,vn,v); },
              onCancel:function(v){ deviceSetVar(co,vn,v); }
            });
          }
        } catch (_) {}
        co.ip = blk.next || null;
        continue;
      }

      // Pure JavaScript block: async-safe inside the coroutine, including loops.
      // It intentionally runs in the WebView JS realm; it is not a sandbox.
      if (name === 'Executar JavaScript') {
        if (co._codeState) {
          if (!co._codeState.done) { co.waitUntil=now+40; return; }
          co._codeState=null;
          co.ip=blk.next||null;
          continue;
        }
        const source = paramStr(blk,'código',paramStr(blk,'codigo','',ctx),ctx).replace(/^["']|["']$/g,'');
        co._codeState={done:false};
        co.waitUntil=now+40;
        try {
          const api={
            actor:co.actor?.data||null, runtimeActor:co.actor||null, vars:co.actor?.data?._vars||{}, globals:runtime.globals, runtime,
            get:function(key,fallback){return this.vars[key]!==undefined?this.vars[key]:(this.globals[key]!==undefined?this.globals[key]:fallback);},
            set:function(key,value){catCompatSetVar(co,String(key),value); return value;},
            toast:function(message){try{window.toast?.(String(message));}catch(_){ }},
            log:function(){try{console.log('[Kix JS]',...arguments);}catch(_){ }},
            wait:function(ms){return new Promise(resolve=>kixSetTimeout(resolve,Math.max(0,Number(ms)||0)));},
            say:function(text){showActorText(co.actor,String(text??''),null,'texto1');}
          };
          const AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;
          const fn = new AsyncFunction('kix', source);
          Promise.resolve(fn(api)).then(()=>{if(co._codeState)co._codeState.done=true;co.waitUntil=0;}).catch(err=>{console.error('[Kix JavaScript block]',err);catCompatSetVar(co,'__last_code_error',String(err?.message||err));if(co._codeState)co._codeState.done=true;co.waitUntil=0;});
        } catch (err) { console.error('[Kix JavaScript block init]',err); catCompatSetVar(co,'__last_code_error',String(err?.message||err)); co._codeState.done=true; co.waitUntil=0; }
        return;
      }

      // AskBrick: non-modal in-play input. It never pauses runtime or the current coroutine.
      if (name === 'Pedir texto ao usuário' || nname.includes('pedir texto')) {
        const pergunta = paramStr(blk, 'pergunta', 'Digite:', ctx);
        const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'resposta', ctx), ctx).replace(/["']/g,'') || 'resposta';
        try {
          const initial = String((ctx.vars && ctx.vars[vn] !== undefined ? ctx.vars[vn] : '') ?? '');
          if(typeof window.openRuntimeInputOverlay === 'function') {
            window.openRuntimeInputOverlay({
              title:pergunta || 'Entrada de texto', value:initial, multiline:false, confirmText:'Enviar',
              onInput:function(v){ deviceSetVar(co,vn,v); },
              onConfirm:function(v){ deviceSetVar(co,vn,v); },
              onCancel:function(v){ deviceSetVar(co,vn,v); }
            });
          }
        } catch (_) {}
        co.ip=blk.next||null;
        continue;
      }

      // Kix Plugins dispatcher runs before built-in compatibility/production paths.
      // A plugin can add a new block or override a native block by name.
      try {
        const pluginResult = global.KixPluginRuntime?.executeBlock?.(co, blk, ctx, now);
        if (pluginResult) {
          if (pluginResult.yield) return;
          if (pluginResult.jump) continue;
          if (!co.dead) co.ip = blk.next;
          continue;
        }
      } catch (e) {
        console.error('[Kix plugin]', name, e);
        co.ip = blk.next;
        continue;
      }

      // Central sound dispatcher runs before compatibility/production paths. The older
      // legacy sound branches remain below only as a compatibility fallback.
      try {
        const soundResult = executeSoundBlock(co, blk, ctx, now);
        if (soundResult) {
          if (soundResult.yield) return;
          if (soundResult.jump) continue;
          if (!co.dead) co.ip = blk.next;
          continue;
        }
      } catch (e) {
        console.error('[Kix sound]', name, e);
        co.ip = blk.next;
        continue;
      }

      // Catrobat compatibility dispatcher runs before legacy production dispatch.
      // It only claims blocks marked compatNative=false or dynamic YourBricks.
      try {
        const compatResult = executeCatrobatCompatBlock(co, blk, ctx, now);
        if (compatResult) {
          if (compatResult.yield) return;
          if (compatResult.jump) continue;
          if (!co.dead) co.ip = blk.next;
          continue;
        }
      } catch (e) {
        console.error('[Kix Catrobat compat]', name, e);
        co.ip = blk.next;
        continue;
      }

      try {
        if (executeProductionBlock(co, blk, ctx, now)) {
          co.ip = blk.next;
          continue;
        }
      } catch (e) {
        console.error('[Kix production block]', name, e);
        co.ip = blk.next;
        continue;
      }

      // Explicit variable scopes.
      if (name === 'Definir variável local para' || name === 'Mudar variável local em' ||
          name === 'Definir variável global para' || name === 'Mudar variável global em') {
        const local = name.includes('local');
        const vn = paramStr(blk,'variável',local?'local':'global',ctx).replace(/['"]/g,'') || (local?'local':'global');
        const val = Number(param(blk,'valor',0,ctx));
        if (local) {
          co.actor.data._vars = co.actor.data._vars || {};
          if (name.includes('Mudar')) co.actor.data._vars[vn]=(Number(co.actor.data._vars[vn])||0)+(Number.isFinite(val)?val:0);
          else co.actor.data._vars[vn]=val;
        } else {
          if (name.includes('Mudar')) runtime.globals[vn]=(Number(runtime.globals[vn])||0)+(Number.isFinite(val)?val:0);
          else runtime.globals[vn]=val;
        }
        co.ip=blk.next; continue;
      }

      // Core data dispatcher: these blocks must always advance even when legacy handlers evolve.
      // It also prevents an appearance/animation handler from accidentally swallowing the next block.
      try {
        if (name === 'Definir variável para') {
          const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'pontos', ctx), ctx).replace(/[\'\"]/g,'') || 'pontos';
          const val = param(blk, 'valor', 0, ctx);
          const handled = runtimeDataSet(vn, val, co.actor.data);
          if (!handled) {
            runtime.globals[vn] = val;
            co.actor.data._vars = co.actor.data._vars || {};
            co.actor.data._vars[vn] = val;
          }
          co.ip = blk.next;
          continue;
        }
        if (name === 'Mudar variável em' || name.includes('Mudar variável') || name.includes('Alterar variável')) {
          const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'pontos', ctx), ctx).replace(/[\'\"]/g,'') || 'pontos';
          const current = Number(runtimeDataGet(vn, co.actor.data, runtime.globals[vn])) || 0;
          const d = Number(param(blk, 'valor', 1, ctx));
          const delta = Number.isFinite(d) ? d : 0;
          const next = current + delta;
          const handled = runtimeDataSet(vn, next, co.actor.data);
          if (!handled) {
            runtime.globals[vn] = next;
            co.actor.data._vars = co.actor.data._vars || {};
            co.actor.data._vars[vn] = next;
          }
          co.ip = blk.next;
          continue;
        }
      } catch (e) {
        console.warn('[Kix] core data block recovered:', name, e);
        co.ip = blk.next;
        continue;
      }

      // ---- IA (5 blocos reais) ----
      // A chamada é assíncrona e nunca bloqueia o game loop. A resposta fica em
      // global "resposta_ia" e também no estado do ator, e dispara o hat
      // "Quando IA responder". O endpoint usa a API compatível com Responses;
      // a chave/modelo podem ser definidos pelos blocos.
      try {
        const aiKey = (runtime.globals && (runtime.globals.__kixAIKey || runtime.globals['chave_ia'])) || co.actor.data._aiKey || '';
        if (name === 'Definir chave de API') {
          const key = paramStr(blk, 'chave', '', ctx).replace(/^['"]|['"]$/g, '');
          runtime.globals.__kixAIKey = key;
          co.actor.data._aiKey = key;
          co.ip = blk.next;
          continue;
        }
        if (name === 'Definir modelo de IA') {
          const model = paramStr(blk, 'modelo', 'gpt-4.1-mini', ctx).replace(/^['"]|['"]$/g, '') || 'gpt-4.1-mini';
          runtime.globals.__kixAIModel = model;
          co.actor.data._aiModel = model;
          co.ip = blk.next;
          continue;
        }
        if (name === 'Cancelar pedido de IA') {
          const req = co.actor.data._aiRequest;
          if (req && req.controller) { try { req.controller.abort(); } catch (_) {} }
          co.actor.data._aiRequest = null;
          runtime.globals.__kixAIStatus = 'cancelado';
          co.ip = blk.next;
          continue;
        }
        if (name === 'Perguntar à IA') {
          const existing = co.actor.data._aiRequest;
          if (existing && existing.done) {
            runtime.globals['resposta_ia'] = existing.text || '';
            co.actor.data._aiLastResponse = existing.text || '';
            co.actor.data._aiRequest = null;
            co.ip = blk.next;
            continue;
          }
          if (existing && !existing.done) {
            co.waitUntil = now + 100;
            return;
          }
          if (!aiKey) {
            runtime.globals.__kixAIStatus = 'erro: chave de API não definida';
            co.ip = blk.next;
            continue;
          }
          const prompt = paramStr(blk, 'prompt', '', ctx).replace(/^['"]|['"]$/g, '');
          const model = runtime.globals.__kixAIModel || co.actor.data._aiModel || 'gpt-4.1-mini';
          const controller = new AbortController();
          const req = { controller, done: false, text: '', error: '' };
          co.actor.data._aiRequest = req;
          runtime.globals.__kixAIStatus = 'processando';
          fetch('https://api.openai.com/v1/responses', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + aiKey },
            body: JSON.stringify({ model: model, input: prompt, store: false }),
            signal: controller.signal
          }).then(r => r.json().then(j => ({ ok: r.ok, data: j })))
            .then(result => {
              if (!result.ok) throw new Error((result.data && result.data.error && result.data.error.message) || 'Falha na IA');
              const d = result.data || {};
              let textOut = d.output_text || '';
              if (!textOut && Array.isArray(d.output)) {
                d.output.forEach(item => (item.content || []).forEach(c => { if (c && c.text) textOut += c.text; }));
              }
              req.text = String(textOut || '');
              req.done = true;
              runtime.globals['resposta_ia'] = req.text;
              runtime.globals.__kixAIStatus = 'concluído';
              try { runtime.actors.forEach(ra => startHatsFor(ra, 'Quando IA responder')); } catch (_) {}
            })
            .catch(err => {
              req.error = err && err.name === 'AbortError' ? 'cancelado' : String(err && err.message || err);
              req.done = true;
              runtime.globals.__kixAIStatus = 'erro: ' + req.error;
            });
          co.waitUntil = now + 100;
          return;
        }
      } catch (aiErr) {
        runtime.globals.__kixAIStatus = 'erro: ' + String(aiErr && aiErr.message || aiErr);
        co.ip = blk.next;
        continue;
      }

      // Central Looks dispatcher: visual blocks always advance the script unless the user explicitly
      // placed 'Esperar animação terminar'. This prevents appearance code from swallowing later blocks.
      try {
        const looksResult = executeLooksBlock(co, blk, ctx, now);
        if (looksResult && looksResult.handled) {
          if (looksResult.advance !== false) co.ip = blk.next;
          continue;
        }
      } catch (e) {
        console.error('[Kix] looks block error', name, e);
        try { reportEngineError({actor: co.actor.data && co.actor.data.name, error:e, block:name}); } catch (_) {}
        co.ip = blk.next;
        continue;
      }

      // ---- PRESETS (quick assembly) ----
      // All preset blocks are intentionally immediate/non-blocking: they configure a small,
      // reusable runtime component and always advance to blk.next.
      const pn = normalizeLookBlockName(name);
      // Joystick/virtual-control presets are handled only by executePresetBlock.

      if (pn.includes('criar camera de seguimento') || pn.includes('definir alvo da camera') || pn.includes('definir zoom da camera') ||
          pn.includes('definir limites da camera') || pn.includes('camera com suavizacao') || pn.includes('shake de camera') || pn.includes('camera com paralaxe')) {
        const id=paramStr(blk,'id','camera1',ctx).replace(/["']/g,'')||'camera1';
        const num=(key,def)=>Number(param(blk,key,def,ctx)) || def;
        if(pn.includes('criar camera de seguimento')) runtime._presetCameras=runtime._presetCameras||{}, runtime._presetCameras[id]={target:null,smooth:.12,parallax:1};
        if(pn.includes('definir alvo da camera')) { const nm=paramStr(blk,'ator','',ctx).replace(/["']/g,''); const target=(runtime.actors||[]).find(a=>a?.data&&String(a.data.name).toLowerCase()===nm.toLowerCase())||co.actor; runtime._camFollow=target; if(runtime._presetCameras?.[id])runtime._presetCameras[id].target=target; }
        if(pn.includes('definir zoom da camera')) { runtime.camZoom=Math.max(.25,Math.min(4,num('valor',1)));applyEngineCamera(); }
        if(pn.includes('definir limites da camera')) runtime._camBounds={minX:num('minX',-9999),maxX:num('maxX',9999),minY:num('minY',-9999),maxY:num('maxY',9999)};
        if(pn.includes('camera com suavizacao')) runtime.camSmooth=Math.max(.01,Math.min(1,num('valor',.12)));
        if(pn.includes('shake de camera')) { const i=Math.max(0,num('intensidade',8)),d=Math.max(.01,num('segundos',.25));runtime._camShake={intensity:i,start:performance.now(),duration:d*1000}; }
        if(pn.includes('camera com paralaxe')) runtime.camParallax=Number(num('fator',1))||1;
        co.ip=blk.next; continue;
      }

      if (pn.includes('transicao fade') || pn.includes('transicao cortinas') || pn.includes('transicao deslizar') || pn.includes('transicao zoom') || pn.includes('transicao de cena aleatoria') || pn.includes('duracao da transicao')) {
        const root=runtime.stageEl||document.body; const overlay=runtime._transitionOverlay||(runtime._transitionOverlay=document.createElement('div')); if(!overlay.parentNode)document.body.appendChild(overlay); overlay.style.cssText='position:fixed;inset:0;z-index:99999;pointer-events:none;opacity:0;background:#000;transform:translate(0,0) scale(1);transition:none;';
        const sec=Math.max(.05,Number(param(blk,'segundos',runtime._transitionDuration||.35,ctx))||.35); runtime._transitionDuration=sec;
        if(pn.includes('duracao da transicao')) { co.ip=blk.next;continue; }
        const mode=paramStr(blk,'modo','out',ctx).toLowerCase(),dir=paramStr(blk,'direcao','left',ctx).toLowerCase(); overlay.style.transition='opacity '+sec+'s ease,transform '+sec+'s ease';
        if(pn.includes('fade')) { overlay.style.opacity=mode.includes('in')?'1':'0'; kixRequestAnimationFrame(()=>overlay.style.opacity=mode.includes('in')?'0':'1'); }
        else if(pn.includes('zoom')) { overlay.style.opacity='1';overlay.style.transform=mode.includes('in')?'scale(1.6)':'scale(.6)';kixRequestAnimationFrame(()=>{overlay.style.opacity='0';overlay.style.transform='scale(1)';}); }
        else { const axis=dir.includes('up')||dir.includes('down')?'Y':'X'; const sign=(dir.includes('right')||dir.includes('down'))?1:-1; overlay.style.opacity='1';overlay.style.transform='translate'+axis+'('+(sign*100)+'%)';kixRequestAnimationFrame(()=>{overlay.style.opacity='0';overlay.style.transform='translate'+axis+'(0)';}); }
        co.ip=blk.next; continue;
      }

      if (pn.includes('preset de tela') || pn.includes('indicador de conexao') || pn.includes('preset de busca de partida') || pn.includes('preset de lista de jogadores') || pn.includes('preset de botao pronto') || pn.includes('preset de contagem regressiva') || pn.includes('preset de convite de amigo') || pn.includes('preset de chat rápido') || pn.includes('preset de indicador de host')) {
        const root=ensureHud(); const id=paramStr(blk,'id','preset_ui',ctx).replace(/["']/g,'')||'preset_ui'; const box=hudEl(id,'div','position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);min-width:220px;max-width:90%;padding:18px;background:rgba(12,12,16,.94);color:#fff;border:1px solid rgba(255,255,255,.16);border-radius:14px;z-index:50;text-align:center;font-family:system-ui,sans-serif;');
        if(box){ let title='Kix'; if(pn.includes('carregamento'))title=paramStr(blk,'texto','Carregando...',ctx); else if(pn.includes('pausado'))title=paramStr(blk,'título','Pausado',ctx); else if(pn.includes('game over'))title=paramStr(blk,'título','Game Over',ctx); else if(pn.includes('lobby'))title=paramStr(blk,'título','Lobby',ctx); else if(pn.includes('busca'))title=paramStr(blk,'texto','Procurando partida...',ctx); else if(pn.includes('resultado'))title=paramStr(blk,'título','Resultado',ctx); else if(pn.includes('host'))title='Host: '+paramStr(blk,'nome','Host',ctx); else if(pn.includes('conexao'))title='● Conectado  •  0 ms'; else if(pn.includes('pronto'))title=paramStr(blk,'texto','PRONTO',ctx); else if(pn.includes('convite'))title=paramStr(blk,'texto','Convidar amigo',ctx); else if(pn.includes('chat'))title='GG  •  Boa!  •  Vamos!'; else if(pn.includes('jogadores'))title='Jogadores\n1. Jogador'; box.el.textContent=title; }
        if(pn.includes('contagem regressiva')) { let left=Math.max(1,Math.floor(Number(param(blk,'segundos',3,ctx))||3)); const node=box.el; node.style.fontSize='42px'; const tick=()=>{if(runtime.paused)return;node.textContent=String(left--);if(left<0){kixClearTimer(timer);node.remove();}};const timer=kixSetInterval(tick,1000);tick();}
        co.ip=blk.next; continue;
      }

      // ---- TEXT (priority dispatch — never miss) ----
      if (nname === 'mostrar texto' || nname === 'definir texto' || nname.includes('texto multilinha') ||
          nname.includes('texto estilizado') || nname.includes('texto hud') ||
          nname.includes('titulo de nivel') || nname.includes('título de nível') ||
          nname.includes('dano flutuante') || nname.includes('aspas coloridas') ||
          nname.includes('caixa de dialogo') || nname.includes('caixa de diálogo') ||
          nname.includes('efeito de digitacao') || nname.includes('efeito de digitação') ||
          nname.includes('mostrar dado como texto') || nname.includes('criar texto facilitado') || nname.includes('sombra no texto') || nname.includes('pulsar texto') ||
          nname.includes('gradiente animado do texto') || nname.includes('iniciar animacao de texto') ||
          nname.includes('iniciar animação de texto') || nname.includes('animacao de texto em loop') ||
          nname.includes('animação de texto em loop') || nname.includes('finalizar animacao de texto') ||
          nname.includes('finalizar animação de texto') || nname.includes('definir fonte') ||
          nname.includes('definir tamanho da fonte') || nname.includes('definir cor do texto') ||
          nname.includes('definir contorno') || nname.includes('definir sombra do texto') ||
          nname.includes('definir glow') || nname.includes('definir gradiente do texto') ||
          nname.includes('definir opacidade do texto') || nname.includes('rotacionar texto') ||
          nname.includes('definir posicao x do texto') || nname.includes('definir posição x do texto') ||
          nname.includes('definir posicao y do texto') || nname.includes('definir posição y do texto') ||
          nname.includes('mudar x do texto') || nname.includes('mudar y do texto') ||
          nname.includes('definir alinhamento') || nname.includes('definir negrito') ||
          nname.includes('parar gradiente animado') || nname.includes('interpol') ||
          nname.includes('quebra de linha') || nname.includes('medir largura') ||
          nname.includes('definir texto rico') || nname.includes('definir espacamento') ||
          nname.includes('definir espaçamento')) {
        try {
          if (nname.startsWith('mostrar texto') || nname === 'definir texto' || nname.includes('texto multilinha')) {
            const tid = normalizeTextId(paramStr(blk, 'id', 'texto1', ctx));
            const resolved = resolveTextFormulaValue(blk, 'texto', ctx);
            const t = ensureActorTextState(co.actor, tid);
            t.boundExpr = resolved.expression; t.boundVar = null; t._quotedMode = false;
            let content = String(resolved.value == null ? '' : resolved.value).replace(/\\n/g, '\n');
            showActorText(co.actor, content, null, tid);
          } else if (nname.startsWith('esconder texto')) {
            hideActorText(co.actor, paramStr(blk, 'id', 'texto1', ctx));
          } else if (nname.includes('texto estilizado')) {

            const fontRef = paramStr(blk, 'fonte', 'Arial', ctx);
            const fam = loadTextFont(fontRef, function (f) {
              showActorText(co.actor, paramStr(blk, 'texto', 'Kix', ctx), {
                fontFamily: '"' + f + '", Arial, sans-serif',
                fontSize: Number(param(blk, 'tamanho', 50, ctx)) || 50,
                color: paramStr(blk, 'cor', '#FFFFFF', ctx),
                stroke: paramStr(blk, 'contorno', '#000000', ctx),
                strokeWidth: 2,
                shadow: { color: 'rgba(0,0,0,0.6)', x: 2, y: 2, blur: 4 }
              });
            });
            showActorText(co.actor, paramStr(blk, 'texto', 'Kix', ctx), {
              fontFamily: fam,
              fontSize: Number(param(blk, 'tamanho', 50, ctx)) || 50,
              color: paramStr(blk, 'cor', '#FFFFFF', ctx),
              stroke: paramStr(blk, 'contorno', '#000000', ctx),
              strokeWidth: 2,
              shadow: { color: 'rgba(0,0,0,0.6)', x: 2, y: 2, blur: 4 }
            });
          } else if (nname.includes('texto hud')) {
            const tid=normalizeTextId(paramStr(blk,'id','hud1',ctx));
            const key = paramStr(blk, 'variavel', 'pontos', ctx);
            const label = paramStr(blk, 'rotulo', paramStr(blk, 'rótulo', 'Vida', ctx), ctx);
            const val = runtime.globals[key] != null ? runtime.globals[key] : (co.actor.data._vars && co.actor.data._vars[key]);
            showActorText(co.actor, label + ': ' + (val != null ? val : 0), { fontSize: 22, color: '#FFFFFF', x: -120, y: 200 }, tid);
          } else if (nname.includes('titulo de nivel') || nname.includes('título de nível')) {
            const tid=normalizeTextId(paramStr(blk,'id','titulo1',ctx));
            showActorText(co.actor, paramStr(blk, 'texto', 'Fase 1', ctx), { fontSize: 40, color: '#FFD700' }, tid);
          } else if (nname.includes('dano flutuante')) {
            const tid=normalizeTextId(paramStr(blk,'id','dano1',ctx));
            showActorText(co.actor, paramStr(blk, 'texto', '-10', ctx), {
              color: paramStr(blk, 'cor', '#FF4444', ctx),
              fontSize: 28,
              x: Number(param(blk, 'x', 0, ctx)) || 0,
              y: Number(param(blk, 'y', 0, ctx)) || 0
            }, tid);
          } else if (nname.includes('aspas coloridas')) {
            const tid = normalizeTextId(paramStr(blk, 'id', 'texto1', ctx));
            const t = ensureActorTextState(co.actor, tid);
            t.content = paramStr(blk, 'texto', '', ctx);
            t._quotedMode = true;
            t._quoteBase = paramStr(blk, 'cor base', '#FFFFFF', ctx);
            t._quoteCol = paramStr(blk, 'cor aspas', '#FF4444', ctx);
            const el = getOrCreateTextEl(textActorId(co.actor, tid));
            applyTextStyle(el, Object.assign({}, t.style, { color: t._quoteBase }));
            if (typeof renderQuotedColorText === 'function') renderQuotedColorText(el, t.content, t._quoteBase, t._quoteCol);
            else showActorText(co.actor, t.content.replace(/"/g, '').replace(/'/g, ''), { color: t._quoteBase }, tid);
          } else if (nname.includes('caixa de dialogo') || nname.includes('caixa de diálogo') || nname.includes('digitacao') || nname.includes('digitação')) {
            const tid = normalizeTextId(paramStr(blk,'id','dialogo1',ctx));
            const full = paramStr(blk, 'texto', 'Ola!', ctx);
            const speed = Math.max(10, Number(param(blk, 'velocidade', 30, ctx)) || 30);
            showActorText(co.actor, '', { fontSize: 22, color: '#FFFFFF' }, tid);
            const el = getOrCreateTextEl(textActorId(co.actor, tid));
            let i = 0;
            const iv = kixSetInterval(() => {
              if (!runtime.running) { kixClearTimer(iv); return; }
              if (runtime.paused) return;
              i++;
              if (el) el.textContent = full.slice(0, i);
              if (i >= full.length) kixClearTimer(iv);
            }, speed);
          } else if (nname.includes('mostrar dado como texto')) {
            const tid=normalizeTextId(paramStr(blk,'id','texto1',ctx));
            const key = paramStr(blk, 'variavel', 'pontos', ctx);
            const prefix = paramStr(blk, 'prefixo', '', ctx);
            const t = ensureActorTextState(co.actor, tid);
            t.boundVar = null; t.boundExpr = key; t.boundPrefix = prefix;
            const val = evalExpr(key, ctx);
            showActorText(co.actor, prefix + (val == null ? '' : val), null, tid);
          } else if (nname.includes('definir cor do texto')) {
            const t = ensureActorTextState(co.actor);
            t.style.color = paramStr(blk, 'cor', '#FFFFFF', ctx);
            t.style.gradient = null;
            refreshActorText(co.actor);
          } else if (nname.includes('definir tamanho da fonte')) {
            const t = ensureActorTextState(co.actor);
            t.style.fontSize = Number(param(blk, 'tamanho', 50, ctx)) || 50;
            refreshActorText(co.actor);
          } else if (nname.includes('definir fonte')) {
            const t = ensureActorTextState(co.actor);
            const fontRef = paramStr(blk, 'fonte', 'Arial', ctx);
            t.style.fontFamily = loadTextFont(fontRef, function (fam) {
              t.style.fontFamily = '"' + fam + '", Arial, sans-serif';
              refreshActorText(co.actor);
            });
            refreshActorText(co.actor);
          } else if (nname.includes('definir opacidade do texto')) {
            const t = ensureActorTextState(co.actor);
            t.style.opacity = Number(param(blk, 'opacidade', 100, ctx)) || 100;
            refreshActorText(co.actor);
          } else if (nname.includes('posicao x do texto') || nname.includes('posição x do texto')) {
            const t = ensureActorTextState(co.actor);
            t.style.x = Number(param(blk, 'x', 0, ctx)) || 0;
            refreshActorText(co.actor);
          } else if (nname.includes('posicao y do texto') || nname.includes('posição y do texto')) {
            const t = ensureActorTextState(co.actor);
            t.style.y = Number(param(blk, 'y', 0, ctx)) || 0;
            refreshActorText(co.actor);
          } else if (nname.includes('mudar x do texto')) {
            const t = ensureActorTextState(co.actor);
            t.style.x = (Number(t.style.x) || 0) + (Number(param(blk, 'valor', 10, ctx)) || 0);
            refreshActorText(co.actor);
          } else if (nname.includes('mudar y do texto')) {
            const t = ensureActorTextState(co.actor);
            t.style.y = (Number(t.style.y) || 0) + (Number(param(blk, 'valor', 10, ctx)) || 0);
            refreshActorText(co.actor);
          } else if (nname.includes('pulsar texto')) {
            const t = ensureActorTextState(co.actor);
            t.pulse = {
              min: Number(param(blk, 'escala minima', 0.9, ctx)) || 0.9,
              max: Number(param(blk, 'escala maxima', 1.1, ctx)) || 1.1,
              speed: Number(param(blk, 'velocidade', 1, ctx)) || 1
            };
            refreshActorText(co.actor);
          } else if (nname.includes('iniciar animacao de texto') || nname.includes('iniciar animação de texto') || nname.includes('animacao de texto em loop') || nname.includes('animação de texto em loop')) {
            const t = ensureActorTextState(co.actor);
            t.textAnim = {
              type: paramStr(blk, 'tipo', 'shake', ctx).toLowerCase(),
              intensity: Number(param(blk, 'intensidade', 8, ctx)) || 8,
              speed: Number(param(blk, 'velocidade', 1, ctx)) || 1,
              loop: nname.includes('loop')
            };
            refreshActorText(co.actor);
          } else if (nname.includes('finalizar animacao') || nname.includes('finalizar animação')) {
            const t = ensureActorTextState(co.actor);
            t.textAnim = null;
            t.pulse = null;
            refreshActorText(co.actor);
          } else if (nname.includes('gradiente animado')) {
            const t = ensureActorTextState(co.actor);
            t.gradAnim = {
              c1: paramStr(blk, 'cor inicio', paramStr(blk, 'cor início', '#FF0000', ctx), ctx),
              c2: paramStr(blk, 'cor fim', '#0000FF', ctx),
              dir: paramStr(blk, 'direcao', paramStr(blk, 'direção', 'direita', ctx), ctx).toLowerCase(),
              speed: Number(param(blk, 'velocidade', 1, ctx)) || 1
            };
            refreshActorText(co.actor);
          } else if (nname.includes('parar gradiente')) {
            const t = ensureActorTextState(co.actor);
            t.gradAnim = null;
          } else if (nname.includes('definir contorno')) {
            const t = ensureActorTextState(co.actor);
            t.style.stroke = paramStr(blk, 'cor', '#000000', ctx);
            t.style.strokeWidth = Number(param(blk, 'espessura', 2, ctx)) || 2;
            refreshActorText(co.actor);
          } else if (nname.includes('sombra no texto')) {
            const t = ensureActorTextState(co.actor);
            const enabled = formulaBoolParam(blk, ['valor','sombra'], true, ctx);
            t.style.shadow = enabled ? { color: 'rgba(0,0,0,0.65)', x: 2, y: 2, blur: 4 } : null;
            refreshActorText(co.actor);
          } else if (nname.includes('criar texto facilitado') || nname.includes('texto estilizado')) {
            const tid=normalizeTextId(paramStr(blk,'id','texto1',ctx));
            const t = ensureActorTextState(co.actor, tid);
            const shadow = formulaBoolParam(blk, ['sombra'], true, ctx);
            const resolvedText = resolveTextFormulaValue(blk, 'texto', ctx);
            t.boundExpr = resolvedText.expression;
            t.boundVar = null;
            t._quotedMode = false;
            t.content = String(resolvedText.value == null ? '' : resolvedText.value);
            t.style.fontSize = Number(param(blk, 'tamanho', 50, ctx)) || 50;
            t.style.color = paramStr(blk, 'cor', '#FFFFFF', ctx);
            t.style.x = Number(param(blk, 'x', t.style.x || 0, ctx)) || 0;
            t.style.y = Number(param(blk, 'y', t.style.y || 0, ctx)) || 0;
            const fontRef = paramStr(blk, 'fonte', '', ctx);
            if(fontRef){ t.style.fontFamily = loadTextFont(fontRef, function(fam){ t.style.fontFamily='"'+fam+'", Arial, sans-serif'; refreshActorText(co.actor, tid); }); }
            t.style.stroke = paramStr(blk, 'contorno', '#000000', ctx);
            t.style.strokeWidth = 2;
            t.style.shadow = shadow ? { color: 'rgba(0,0,0,0.65)', x: 2, y: 2, blur: 4 } : null;
            refreshActorText(co.actor, tid);
          } else if (nname.includes('definir sombra')) {
            const t = ensureActorTextState(co.actor);
            t.style.shadow = {
              color: paramStr(blk, 'cor', '#000000', ctx),
              x: Number(param(blk, 'deslocamento x', 2, ctx)) || 2,
              y: Number(param(blk, 'deslocamento y', 2, ctx)) || 2,
              blur: Number(param(blk, 'desfoque', 4, ctx)) || 4
            };
            refreshActorText(co.actor);
          } else if (nname.includes('rotacionar texto')) {
            const t = ensureActorTextState(co.actor);
            t.style.rotation = Number(param(blk, 'graus', 0, ctx)) || 0;
            refreshActorText(co.actor);
          } else if (nname.includes('definir alinhamento')) {
            const t = ensureActorTextState(co.actor);
            t.style.align = paramStr(blk, 'alinhamento', 'centro', ctx);
            refreshActorText(co.actor);
          } else if (nname.includes('definir negrito')) {
            const t = ensureActorTextState(co.actor);
            t.style.bold = /sim|true|1|s/i.test(paramStr(blk, 'negrito', 'nao', ctx));
            t.style.italic = /sim|true|1|s/i.test(paramStr(blk, 'italico', paramStr(blk, 'itálico', 'nao', ctx), ctx));
            refreshActorText(co.actor);
          } else {
            // style-only unknown text block: still try to refresh
            const t = ensureActorTextState(co.actor);
            refreshActorText(co.actor);
          }
        } catch (err) {
          console.error('[Kix] text block error', name, err);
          try { reportEngineError({ actor: co.actor.data && co.actor.data.name, error: err, block: name }); } catch(_){}
        }
        co.ip = blk.next;
        continue;
      }


      // ---- CONTROL ----
      if (name === 'Sempre') {
        const bodyStart = (blk.body && blk.body[0]) || null;
        co.loopStack.push({ kind: 'forever', bodyStart, after: blk.next });
        co.ip = bodyStart;
        return; // yield frame
      }
      if (name === 'Repita X vezes' || name.startsWith('Repita X')) {
        const n = Math.max(0, Math.floor(Number(param(blk, 'vezes', 10, ctx)) || 10));
        const bodyStart = (blk.body && blk.body[0]) || null;
        if (n > 0 && bodyStart) {
          co.loopStack.push({ kind: 'repeat', count: n, bodyStart, after: blk.next });
          co.ip = bodyStart;
          return;
        }
        co.ip = blk.next;
        continue;
      }
      if (
        name === 'Esperar X segundos' || name.startsWith('Esperar X') ||
        nname === 'esperar x segundos' || nname.startsWith('esperar x') ||
        (nname.startsWith('esperar') && (nname.includes('segundo') || nname.includes('seg'))) ||
        nname === 'aguardar' || nname.startsWith('aguardar ')
      ) {
        let sec = Number(param(blk, 'segundos', undefined, ctx));
        if (sec == null || isNaN(sec)) sec = Number(param(blk, 'segundo', undefined, ctx));
        if (sec == null || isNaN(sec)) sec = Number(param(blk, 'tempo', undefined, ctx));
        if (sec == null || isNaN(sec)) sec = Number(param(blk, 'x', undefined, ctx));
        if (sec == null || isNaN(sec)) {
          // try first param value
          try {
            const keys = blk.values ? Object.keys(blk.values) : [];
            if (keys.length) sec = Number(evalExpr(blk.values[keys[0]], ctx));
          } catch (_) {}
        }
        if (sec == null || isNaN(sec) || sec < 0) sec = 1;
        co.waitUntil = now + sec * 1000;
        // Advance to NEXT block (e.g. Mostrar texto) so it runs after wait
        co.ip = blk.next || null;
        if (!co.ip) {
          console.warn('[Kix] Esperar sem próximo bloco (next=null). scripts não linkados?');
        }
        return; // yield until waitUntil
      }

      if (name === 'Esperar até' || name.startsWith('Esperar até') || nname === 'esperar ate' || nname.includes('esperar até')) {
        // Wait until condition is truthy (variable or expression in values)
        const condKey = Object.keys(blk.values || {}).find(k => /cond|até|ate|valor|variavel|variável/i.test(k)) || 'condição';
        const raw = (blk.values && blk.values[condKey] != null) ? blk.values[condKey] : param(blk, 'condição', 1, ctx);
        let ok = false;
        try {
          if (typeof raw === 'boolean') ok = raw;
          else if (typeof raw === 'number') ok = !!raw;
          else {
            const s = String(raw).replace(/['"]/g, '').trim();
            if (s === 'true' || s === '1' || s === 'sim') ok = true;
            else if (s === 'false' || s === '0' || s === 'nao' || s === 'não') ok = false;
            else if (runtime.globals[s] != null) ok = !!runtime.globals[s];
            else if (co.actor.data._vars && co.actor.data._vars[s] != null) ok = !!co.actor.data._vars[s];
            else {
              const n = Number(evalExpr(raw, ctx));
              ok = !isNaN(n) && !!n;
            }
          }
        } catch (_) { ok = false; }
        if (!ok) {
          // stay on this block
          co.waitUntil = now + 50;
          return;
        }
        co.ip = blk.next || null;
        return;
      }
      if (name === 'Esperar um frame' || nname === 'esperar um frame') {
        co.waitUntil = now + 16;
        co.ip = blk.next || null;
        return;
      }
      if (name === 'Repetir para sempre com delay' || nname.includes('repetir para sempre com delay')) {
        const sec = Math.max(0.05, Number(param(blk, 'segundos', 1, ctx)) || 1);
        const bodyStart = (blk.body && blk.body[0]) || blk.next;
        // emulate forever with delay: push loop and wait
        if (!co._delayForever) {
          co._delayForever = true;
          co.loopStack.push({ kind: 'forever', bodyStart: bodyStart, after: null });
        }
        co.waitUntil = now + sec * 1000;
        co.ip = bodyStart;
        return;
      }
      if (name === 'Se variável = faça' || nname.includes('se variavel =') || nname.includes('se variável =')) {
        const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'novo', ctx), ctx).replace(/['"]/g, '');
        const want = param(blk, 'valor', 0, ctx);
        const cur = runtime.globals[vn] != null ? runtime.globals[vn] : (co.actor.data._vars && co.actor.data._vars[vn]);
        const eq = (String(cur) === String(want)) || (Number(cur) === Number(want));
        if (eq) {
          const bodyStart = (blk.body && blk.body[0]) || null;
          if (bodyStart) { co.ip = bodyStart; continue; }
        }
        co.ip = blk.next;
        continue;
      }
      if (name === 'Sair de todos os loops' || nname.includes('sair de todos os loops')) {
        co.loopStack = [];
        co.ip = null;
        co.dead = true;
        return;
      }
      if (name === 'Executar uma vez' || nname === 'executar uma vez') {
        const key = '_once_' + (blk.id || name);
        if (co.actor.data[key]) {
          co.ip = blk.next;
          continue;
        }
        co.actor.data[key] = true;
        const bodyStart = (blk.body && blk.body[0]) || null;
        if (bodyStart) { co.ip = bodyStart; continue; }
        co.ip = blk.next;
        continue;
      }



      if (name === 'Se está tocando' || nname.includes('se esta tocando') || nname.includes('se está tocando')) {
        const alvo = paramStr(blk, 'objeto', paramStr(blk, 'nome', '', ctx), ctx).replace(/['"]/g, '');
        let hit = false;
        try {
          const others = (runtime.actors || []).filter(function (a) {
            return a && a !== co.actor && a.data && !a.data.isBackground;
          });
          for (let oi = 0; oi < others.length; oi++) {
            const o = others[oi];
            if (alvo && String(o.data.name || '').toLowerCase() !== alvo.toLowerCase()) continue;
            if (typeof checkCollision === 'function' && checkCollision(co.actor, o)) {
              hit = true;
              break;
            }
          }
        } catch (_) {}
        if (hit) {
          const bodyStart = (blk.body && blk.body[0]) || null;
          if (bodyStart) { co.ip = bodyStart; continue; }
          // flat: execute next until next hat/end handled by sequential
        }
        co.ip = blk.next;
        continue;
      }

      if (name === 'Mudar para cena' || nname.includes('mudar para cena')) {
        const cena = paramStr(blk, 'cena', paramStr(blk, 'nome', '0', ctx), ctx);
        try {
          if (typeof window.KixChangeScene === 'function') window.KixChangeScene(cena);
          else if (typeof window.kixChangeScene === 'function') window.kixChangeScene(cena);
        } catch (e) { console.error('Mudar para cena', e); }
        co.dead = true;
        return;
      } else if (name === 'Próxima cena' || nname === 'proxima cena' || nname === 'próxima cena') {
        try { if (window.KixChangeScene) window.KixChangeScene('next'); } catch (_) {}
        co.dead = true;
        return;
      } else if (name === 'Cena anterior' || nname === 'cena anterior') {
        try { if (window.KixChangeScene) window.KixChangeScene('prev'); } catch (_) {}
        co.dead = true;
        return;
      } else if (name === 'Reiniciar cena atual' || nname.includes('reiniciar cena')) {
        try { if (window.KixChangeScene) window.KixChangeScene('restart'); } catch (_) {}
        co.dead = true;
        return;
      }
      if (name === 'Transição fade para cena' || name === 'Transição fade para [cena] em [segundos]' || nname.includes('transicao fade') || nname.includes('transição fade') || nname.includes('transicao fase') || nname.includes('transição fase')) {
        const cena = paramStr(blk, 'cena', paramStr(blk, 'nome', '0', ctx), ctx);
        const sec = Math.max(0.05, Number(param(blk, 'segundos', param(blk, 'tempo', 0.5, ctx), ctx)) || 0.5);
        const cor = paramStr(blk, 'cor', paramStr(blk, 'color', '#000000', ctx), ctx) || '#000000';
        const estilo = paramStr(blk, 'estilo', paramStr(blk, 'style', paramStr(blk, 'tipo', 'fade', ctx), ctx), ctx) || 'fade';
        try {
          if (typeof window.KixChangeScene === 'function') {
            window.KixChangeScene(cena, { fade: sec, seconds: sec, color: cor, cor: cor, style: estilo, estilo: estilo, forceFade: true });
          }
        } catch (e) { console.error('Transição fade', e); }
        co.dead = true;
        return;
      }

      if (name === 'Parar este script') { co.dead = true; return; }
      if (name === 'Parar todos os scripts') { stopAll(); return; }
      if (name.startsWith('Se ...')) {
        // minimal: always take body if condition truthy (default true)
        const cond = param(blk, 'condição', 1, ctx);
        const truthy = !!cond && cond !== '0' && cond !== 'false';
        if (truthy && blk.body && blk.body[0]) {
          // run body then continue to next
          // push a one-shot: after body, go to next
          const bodyIds = blk.body;
          for (let k = 0; k < bodyIds.length - 1; k++) {
            if (co.tree.blocks[bodyIds[k]]) co.tree.blocks[bodyIds[k]].next = bodyIds[k + 1];
          }
          if (bodyIds.length) {
            const last = co.tree.blocks[bodyIds[bodyIds.length - 1]];
            if (last) last.next = blk.next;
            co.ip = bodyIds[0];
            continue;
          }
        }
        co.ip = blk.next;
        continue;
      }

      // ---- MOTION ----
      if (name === 'Seguir joystick') {
        const id = paramStr(blk, 'id', 'joystick1', ctx) || 'joystick1';
        const apontar = paramStr(blk, 'apontar', 'sim', ctx).toLowerCase();
        const speedValue = Number(param(blk, 'velocidade', 6, ctx));
        const maxSpeed = Number.isFinite(speedValue) ? Math.max(0, speedValue) : 6;
        const c = runtime._presets && runtime._presets.controls && runtime._presets.controls[id];
        if (c) {
          const force = Math.max(0, Math.min(1, Number(c.force) || 0));
          const ax = Math.max(-1, Math.min(1, Number(c.axisX) || 0));
          const ay = Math.max(-1, Math.min(1, Number(c.axisY) || 0));
          const frameScale = runtimeMotionFrameScale();
          const step = maxSpeed * force * frameScale;
          actorPositionMove(co.actor, ax * step, ay * step, true);
          if (apontar.includes('sim') || apontar.includes('yes') || apontar === '1' || apontar.includes('sempre')) {
            if (force > 0.03) {
              const angle = Math.atan2(ay, ax) * 180 / Math.PI;
              co.actor.data.direction = ((angle % 360) + 360) % 360;
            }
          }
        }
      } else if (name === 'Mover X passos' || name.startsWith('Mover X')) {
        const rawSteps = Number(param(blk, 'passos', 10, ctx));
        const stepsN = Number.isFinite(rawSteps) ? rawSteps : 10;
        const rawDir = Number(co.actor.data.direction);
        const dir = Number.isFinite(rawDir) ? rawDir : 90;
        const rad = (dir * Math.PI) / 180;
        actorPositionMove(co.actor, Math.cos(rad) * stepsN, Math.sin(rad) * stepsN, true);
      } else if (name === 'Girar direita X graus' || name.includes('Girar direita')) {
        const rawG = Number(param(blk, 'graus', 15, ctx));
        const g = Number.isFinite(rawG) ? rawG : 15;
        const rawDir = Number(co.actor.data.direction);
        const dir = Number.isFinite(rawDir) ? rawDir : 90;
        co.actor.data.direction = dir - g;
        co.actor._lastKey = null;
        updateSpriteTransform(co.actor);
      } else if (name === 'Girar esquerda X graus' || name.includes('Girar esquerda')) {
        const rawG = Number(param(blk, 'graus', 15, ctx));
        const g = Number.isFinite(rawG) ? rawG : 15;
        const rawDir = Number(co.actor.data.direction);
        const dir = Number.isFinite(rawDir) ? rawDir : 90;
        co.actor.data.direction = dir + g;
        co.actor._lastKey = null;
        updateSpriteTransform(co.actor);
      } else if (name.startsWith('Ir para X')) {
        actorPositionSet(co.actor, Number(param(blk, 'x', 0, ctx)), Number(param(blk, 'y', 0, ctx)), true);
      } else if (name === 'Definir X para') {
        const rawValor = blk.values && blk.values.valor !== undefined ? blk.values.valor : (blk.values && blk.values.x !== undefined ? blk.values.x : '');
        const joyAxis = joystickAxisFromDirectionVar(rawValor, 'x');
        if (joyAxis !== null) {
          const forceMeta = runtime._presets && runtime._presets.controls && runtime._presets.controls[(runtime._joystickDirectionVars[String(rawValor).trim().replace(/^['"]|['"]$/g,'')] || {}).controlId];
          const step = 6 * (forceMeta ? Math.max(0, Math.min(1, Number(forceMeta.force) || 0)) : 0);
          actorPositionMove(co.actor, joyAxis * step, 0, true);
        } else {
          const tx = Number(param(blk, 'valor', param(blk, 'x', 0, ctx), ctx));
          actorPositionSet(co.actor, Number.isFinite(tx) ? tx : 0, co.actor.data.y, true);
        }
      } else if (name === 'Definir Y para') {
        const rawValor = blk.values && blk.values.valor !== undefined ? blk.values.valor : (blk.values && blk.values.y !== undefined ? blk.values.y : '');
        const joyAxis = joystickAxisFromDirectionVar(rawValor, 'y');
        if (joyAxis !== null) {
          const forceMeta = runtime._presets && runtime._presets.controls && runtime._presets.controls[(runtime._joystickDirectionVars[String(rawValor).trim().replace(/^['"]|['"]$/g,'')] || {}).controlId];
          const step = 6 * (forceMeta ? Math.max(0, Math.min(1, Number(forceMeta.force) || 0)) : 0);
          actorPositionMove(co.actor, 0, joyAxis * step, true);
        } else {
          const ty = Number(param(blk, 'valor', param(blk, 'y', 0, ctx), ctx));
          actorPositionSet(co.actor, co.actor.data.x, Number.isFinite(ty) ? ty : 0, true);
        }
      } else if (name === 'Mudar X em') {
        const v = Number(param(blk, 'valor', 10, ctx));
        actorPositionMove(co.actor, Number.isFinite(v) ? v : 10, 0, true);
      } else if (name === 'Mudar Y em') {
        const v = Number(param(blk, 'valor', 10, ctx));
        actorPositionMove(co.actor, 0, Number.isFinite(v) ? v : 10, true);
      } else if (name === 'Apontar para direção X' || name.includes('Apontar para direção')) {
        const d = Number(param(blk, 'direção', param(blk, 'graus', param(blk, 'valor', 90, ctx), ctx), ctx));
        co.actor.data.direction = isNaN(d) ? 90 : d;
        co.actor._lastKey = null;
        updateSpriteTransform(co.actor, true);
      } else if (name === 'Ir para posição aleatória' || (typeof nname === 'string' && nname.includes('posicao aleatoria')) || (typeof nname === 'string' && nname.includes('posição aleatória'))) {
        const sw = (runtime.stageEl && runtime.stageEl._stageW) || 360;
        const sh = (runtime.stageEl && runtime.stageEl._stageH) || 640;
        const margin = 40;
        actorPositionSet(co.actor, (runtimeRandom() * (sw - margin * 2)) - (sw / 2) + margin, (runtimeRandom() * (sh - margin * 2)) - (sh / 2) + margin, true);
      } else if (name === 'Ir para outro objeto' || (typeof nname === 'string' && nname.includes('ir para outro objeto'))) {
        const targetName = paramStr(blk, 'objeto', paramStr(blk, 'nome', '', ctx), ctx).replace(/^['"]|['"]$/g, '');
        const others = (runtime.actors || []).filter(a => a && a !== co.actor && a.data && !a.data.isBackground);
        let target = null;
        if (targetName) {
          target = others.find(a => String(a.data.name || '').toLowerCase() === targetName.toLowerCase());
        }
        if (!target && others.length) target = others[Math.floor(runtimeRandom() * others.length)];
        if (target) {
          const tx = Number(target.data.x);
          const ty = Number(target.data.y);
          actorPositionSet(co.actor, Number.isFinite(tx) ? tx : 0, Number.isFinite(ty) ? ty : 0, true);
        }
      } else if (name === 'Apontar em direção a' || (typeof nname === 'string' && nname.includes('apontar em direcao a')) || (typeof nname === 'string' && nname.includes('apontar em direção a'))) {
        const targetName = paramStr(blk, 'objeto', paramStr(blk, 'nome', paramStr(blk, 'direção', '', ctx), ctx), ctx).replace(/^['"]|['"]$/g, '');
        let tx = null, ty = null;
        if (targetName && (targetName.toLowerCase() === 'toque' || targetName.toLowerCase() === 'mouse' || targetName.toLowerCase() === 'pointer')) {
          tx = (runtime.touch && runtime.touch.x != null) ? runtime.touch.x : 0;
          ty = (runtime.touch && runtime.touch.y != null) ? runtime.touch.y : 0;
        } else {
          const others = (runtime.actors || []).filter(a => a && a !== co.actor && a.data && !a.data.isBackground);
          let target = targetName ? others.find(a => String(a.data.name || '').toLowerCase() === targetName.toLowerCase()) : null;
          if (!target && others.length) target = others[0];
          if (target) { tx = Number(target.data.x) || 0; ty = Number(target.data.y) || 0; }
        }
        if (tx != null && ty != null) {
          const dx = tx - (Number(co.actor.data.x) || 0);
          const dy = ty - (Number(co.actor.data.y) || 0);
          co.actor.data.direction = Math.atan2(dy, dx) * 180 / Math.PI;
          co.actor._lastKey = null;
          updateSpriteTransform(co.actor, true);
        }
      } else if (name === 'Se estiver na borda, volte' || (typeof nname === 'string' && nname.includes('borda') && nname.includes('volte'))) {
        const sw = (runtime.stageEl && runtime.stageEl._stageW) || 360;
        const sh = (runtime.stageEl && runtime.stageEl._stageH) || 640;
        const halfW = sw / 2;
        const halfH = sh / 2;
        const size = (Number(co.actor.data.size) || 100) / 100;
        const pad = 24 * size;
        let x = Number(co.actor.data.x) || 0;
        let y = Number(co.actor.data.y) || 0;
        const rawDir = Number(co.actor.data.direction);
        let dir = Number.isFinite(rawDir) ? rawDir : 90;
        let bounced = false;
        if (x > halfW - pad) { x = halfW - pad; dir = 180 - dir; bounced = true; }
        if (x < -halfW + pad) { x = -halfW + pad; dir = 180 - dir; bounced = true; }
        if (y > halfH - pad) { y = halfH - pad; dir = -dir; bounced = true; }
        if (y < -halfH + pad) { y = -halfH + pad; dir = -dir; bounced = true; }
        if (bounced) {
          actorPositionSet(co.actor, x, y, true);
          co.actor.data.direction = ((dir % 360) + 360) % 360;
          if (co.actor.data.direction > 180) co.actor.data.direction -= 360;
          co.actor._lastKey = null;
          updateSpriteTransform(co.actor, true);
        }
      } else if (name === 'Definir estilo de rotação' || (typeof nname === 'string' && nname.includes('estilo de rotacao')) || (typeof nname === 'string' && nname.includes('estilo de rotação'))) {
        const estilo = paramStr(blk, 'estilo', paramStr(blk, 'valor', 'girar', ctx), ctx).toLowerCase().replace(/['"]/g, '');
        // girar | esquerda-direita | não girar
        if (estilo.includes('esquerda') || estilo.includes('direita') || estilo === 'left-right') {
          co.actor.data.rotationStyle = 'left-right';
        } else if (estilo.includes('não') || estilo.includes('nao') || estilo.includes('none') || estilo.includes('don')) {
          co.actor.data.rotationStyle = 'none';
        } else {
          co.actor.data.rotationStyle = 'all-around';
        }
        co.actor._lastKey = null;
        updateSpriteTransform(co.actor, true);
      } else if (name === 'Mover em direção ao toque' || (typeof nname === 'string' && nname.includes('direcao ao toque')) || (typeof nname === 'string' && nname.includes('direção ao toque'))) {
        const rawSteps = Number(param(blk, 'passos', param(blk, 'valor', 10, ctx), ctx));
        const stepsN = Number.isFinite(rawSteps) ? rawSteps : 10;
        const tx = (runtime.touch && runtime.touch.x != null) ? Number(runtime.touch.x) : (Number(co.actor.data.x) || 0);
        const ty = (runtime.touch && runtime.touch.y != null) ? Number(runtime.touch.y) : (Number(co.actor.data.y) || 0);
        const dx = tx - (Number(co.actor.data.x) || 0);
        const dy = ty - (Number(co.actor.data.y) || 0);
        const len = Math.hypot(dx, dy);
        if (len > 0 && stepsN !== 0) {
          actorPositionMove(co.actor, (dx / len) * stepsN, (dy / len) * stepsN, true);
          co.actor.data.direction = Math.atan2(dy, dx) * 180 / Math.PI;
        }
        co.actor._lastKey = null;
        updateSpriteTransform(co.actor, true);
      } else if (name === 'Deslizar em X segundos até X: Y:' || name.startsWith('Deslizar em') || (typeof nname === 'string' && nname.includes('deslizar'))) {
        const sec = Math.max(0.05, Number(param(blk, 'segundos', param(blk, 'tempo', 1, ctx), ctx)) || 1);
        const tx = Number(param(blk, 'x', 0, ctx));
        const ty = Number(param(blk, 'y', 0, ctx));
        const fromX = Number(co.actor.data.x) || 0;
        const fromY = Number(co.actor.data.y) || 0;
        const toX = isNaN(tx) ? fromX : tx;
        const toY = isNaN(ty) ? fromY : ty;
        // multi-frame glide via waitUntil + progress stored on coroutine
        if (!co._glide) {
          co._glide = { fromX, fromY, toX, toY, start: now, dur: sec * 1000 };
          co.actor.data.vx = 0;
          co.actor.data.vy = 0;
          co.waitUntil = now + 16; // resume next frames
          // do NOT advance ip yet — stay on this block
          return;
        }
        const g = co._glide;
        const t = Math.min(1, (now - g.start) / g.dur);
        const ease = t * t * (3 - 2 * t); // smoothstep
        co.actor.data.vx = 0;
        co.actor.data.vy = 0;
        actorPositionSet(co.actor, g.fromX + (g.toX - g.fromX) * ease, g.fromY + (g.toY - g.fromY) * ease, true);
        if (t < 1) {
          co.waitUntil = now + 16;
          return; // keep same block
        }
        actorPositionSet(co.actor, g.toX, g.toY, true);
        co._glide = null;
        // fall through to advance ip
      } else if (name === 'Mudar direção em' || (typeof nname === 'string' && nname.includes('mudar direcao em')) || (typeof nname === 'string' && nname.includes('mudar direção em'))) {
        const rawG = Number(param(blk, 'graus', param(blk, 'valor', 15, ctx), ctx));
        const g = Number.isFinite(rawG) ? rawG : 15;
        const rawDir = Number(co.actor.data.direction);
        const dir = Number.isFinite(rawDir) ? rawDir : 90;
        co.actor.data.direction = dir + g;
        co.actor._lastKey = null;
        updateSpriteTransform(co.actor, true);
      } else if (name === 'Definir direção para' || (typeof nname === 'string' && nname.includes('definir direcao para')) || (typeof nname === 'string' && nname.includes('definir direção para'))) {
        const g = Number(param(blk, 'graus', param(blk, 'valor', param(blk, 'direção', 90, ctx), ctx), ctx));
        co.actor.data.direction = isNaN(g) ? 90 : g;
        co.actor._lastKey = null;
        updateSpriteTransform(co.actor, true);
      } else if (name === 'Mover na direção' || (typeof nname === 'string' && nname === 'mover na direcao') || (typeof nname === 'string' && nname.includes('mover na direção'))) {
        const deg = Number(param(blk, 'graus', param(blk, 'direção', 90, ctx), ctx));
        const rawSteps = Number(param(blk, 'passos', 10, ctx));
        const stepsN = Number.isFinite(rawSteps) ? rawSteps : 10;
        const safeDeg = Number.isFinite(deg) ? deg : 90;
        const rad = safeDeg * Math.PI / 180;
        actorPositionMove(co.actor, Math.cos(rad) * stepsN, Math.sin(rad) * stepsN, true);
        co.actor.data.direction = safeDeg;
        co.actor._lastKey = null;
        updateSpriteTransform(co.actor, true);
      } else if (name === 'Seguir objeto' || (typeof nname === 'string' && nname.includes('seguir objeto'))) {
        const targetName = paramStr(blk, 'objeto', paramStr(blk, 'nome', '', ctx), ctx).replace(/['"]/g, '');
        const rawSteps = Number(param(blk, 'passos', param(blk, 'valor', 5, ctx), ctx));
        const stepsN = Number.isFinite(rawSteps) ? rawSteps : 5;
        const others = (runtime.actors || []).filter(a => a && a !== co.actor && a.data && !a.data.isBackground);
        let target = targetName ? others.find(a => String(a.data.name || '').toLowerCase() === targetName.toLowerCase()) : null;
        if (!target && others.length) target = others[0];
        if (target) {
          const dx = (Number(target.data.x) || 0) - (Number(co.actor.data.x) || 0);
          const dy = (Number(target.data.y) || 0) - (Number(co.actor.data.y) || 0);
          const len = Math.hypot(dx, dy) || 1;
          actorPositionMove(co.actor, (dx / len) * stepsN, (dy / len) * stepsN, true);
          co.actor.data.direction = Math.atan2(dy, dx) * 180 / Math.PI;
          co.actor._lastKey = null;
          updateSpriteTransform(co.actor, true);
        }
      } else if (name === 'Afastar de objeto' || (typeof nname === 'string' && nname.includes('afastar de'))) {
        const targetName = paramStr(blk, 'objeto', paramStr(blk, 'nome', '', ctx), ctx).replace(/['"]/g, '');
        const rawSteps = Number(param(blk, 'passos', param(blk, 'valor', 5, ctx), ctx));
        const stepsN = Number.isFinite(rawSteps) ? rawSteps : 5;
        const others = (runtime.actors || []).filter(a => a && a !== co.actor && a.data && !a.data.isBackground);
        let target = targetName ? others.find(a => String(a.data.name || '').toLowerCase() === targetName.toLowerCase()) : null;
        if (!target && others.length) target = others[0];
        if (target) {
          const dx = (Number(co.actor.data.x) || 0) - (Number(target.data.x) || 0);
          const dy = (Number(co.actor.data.y) || 0) - (Number(target.data.y) || 0);
          const len = Math.hypot(dx, dy) || 1;
          actorPositionMove(co.actor, (dx / len) * stepsN, (dy / len) * stepsN, true);
          co.actor.data.direction = Math.atan2(dy, dx) * 180 / Math.PI;
          co.actor._lastKey = null;
          updateSpriteTransform(co.actor, true);
        }
      } else if (name === 'Ir para o toque' || (typeof nname === 'string' && nname.includes('ir para o toque'))) {
        const tx = (runtime.touch && runtime.touch.x != null) ? Number(runtime.touch.x) : 0;
        const ty = (runtime.touch && runtime.touch.y != null) ? Number(runtime.touch.y) : 0;
        actorPositionSet(co.actor, tx, ty, true);
      } else if (name === 'Limitar à tela' || name === 'Limitar a tela' || (typeof nname === 'string' && nname.includes('limitar') && nname.includes('tela'))) {
        const sw = (runtime.stageEl && runtime.stageEl._stageW) || 360;
        const sh = (runtime.stageEl && runtime.stageEl._stageH) || 640;
        const pad = 20;
        let x = Number(co.actor.data.x) || 0;
        let y = Number(co.actor.data.y) || 0;
        const maxX = sw / 2 - pad, maxY = sh / 2 - pad;
        if (x > maxX) x = maxX;
        if (x < -maxX) x = -maxX;
        if (y > maxY) y = maxY;
        if (y < -maxY) y = -maxY;
        actorPositionSet(co.actor, x, y, true);
      } else if (name === 'Definir velocidade X' || nname.includes('definir velocidade x')) {
        co.actor.data.vx = Number(param(blk, 'valor', 0, ctx)) || 0;
      } else if (name === 'Definir velocidade Y' || nname.includes('definir velocidade y')) {
        co.actor.data.vy = Number(param(blk, 'valor', 0, ctx)) || 0;
      } else if (name === 'Parar movimento' || nname === 'parar movimento') {
        co.actor.data.vx = 0;
        co.actor.data.vy = 0;
      } else if (name === 'Mover em círculo' || nname.includes('mover em circulo') || nname.includes('mover em círculo')) {
        const rawRadius = Number(param(blk, 'raio', 50, ctx));
        const radius = Number.isFinite(rawRadius) ? rawRadius : 50;
        const rawGraus = Number(param(blk, 'graus', 10, ctx));
        const graus = Number.isFinite(rawGraus) ? rawGraus : 10;
        if (co.actor.data._orbitAngle == null) co.actor.data._orbitAngle = 0;
        if (co.actor.data._orbitCx == null) {
          co.actor.data._orbitCx = Number(co.actor.data.x) || 0;
          co.actor.data._orbitCy = Number(co.actor.data.y) || 0;
        }
        co.actor.data._orbitAngle += graus;
        const rad = co.actor.data._orbitAngle * Math.PI / 180;
        actorPositionSet(co.actor, co.actor.data._orbitCx + Math.cos(rad) * radius, co.actor.data._orbitCy + Math.sin(rad) * radius, true);
        co.actor.data.direction = co.actor.data._orbitAngle + 90;
        co.actor._lastKey = null;
        updateSpriteTransform(co.actor, true);
      } else if (name === 'Empurrar com força' || nname.includes('empurrar com forca') || nname.includes('empurrar com força')) {
        const rawForce = Number(param(blk, 'força', param(blk, 'forca', 5, ctx), ctx));
        const force = Number.isFinite(rawForce) ? rawForce : 5;
        const currentDirection = Number(co.actor.data.direction);
        const dir = Number(param(blk, 'direção', param(blk, 'direcao', Number.isFinite(currentDirection) ? currentDirection : 90, ctx), ctx));
        const rad = (isNaN(dir) ? 90 : dir) * Math.PI / 180;
        co.actor.data.vx = (Number(co.actor.data.vx) || 0) + Math.cos(rad) * force;
        co.actor.data.vy = (Number(co.actor.data.vy) || 0) + Math.sin(rad) * force;
      }

      // ---- COLLISION / PHYSICS ----
      else if (name === 'Verificar colisão com') {
        const targetName=fbClean(paramStr(blk,'objeto','',ctx)); const key=fbClean(paramStr(blk,'variável','colidiu',ctx)) || 'colidiu';
        const target=targetName ? (runtime.actors||[]).find(a=>a&&a.data&&String(a.data.name).toLowerCase()===targetName.toLowerCase()) : null;
        fbStore(co,key,!!(target && checkCollision(co.actor,target)));
      } else if (name === 'Parar ao colidir com') {
        const targetName=fbClean(paramStr(blk,'objeto','',ctx)); const target=(runtime.actors||[]).find(a=>a&&a.data&&String(a.data.name).toLowerCase()===targetName.toLowerCase());
        if(target && checkCollision(co.actor,target)){ co.actor.data.vx=0; co.actor.data.vy=0; }
      } else if (name === 'Desfazer movimento se colidir') {
        if(checkCollision(co.actor,co.actor._collisionLastAgainst)){ const last=co.actor.data._collisionPreviousPosition; if(last){actorPositionSet(co.actor,last.x,last.y,true);} }
      } else if (name === 'Empurrar ao colidir') {
        const force=Number(param(blk,'força',5,ctx))||5; const hit=(runtime.actors||[]).find(a=>a&&a!==co.actor&&a.data&&!a.data.isCamera&&checkCollision(co.actor,a));
        if(hit){ const dx=(Number(hit.data.x)||0)-(Number(co.actor.data.x)||0),dy=(Number(hit.data.y)||0)-(Number(co.actor.data.y)||0),len=Math.hypot(dx,dy)||1; hit.data.vx=(Number(hit.data.vx)||0)+(dx/len)*force; hit.data.vy=(Number(hit.data.vy)||0)+(dy/len)*force; }
      } else if (name === 'Mover até colidir') {
        const targetName=fbClean(paramStr(blk,'objeto','',ctx)); const steps=Number(param(blk,'passos',5,ctx))||5; const target=(runtime.actors||[]).find(a=>a&&a.data&&String(a.data.name).toLowerCase()===targetName.toLowerCase());
        if(target){ const old={x:Number(co.actor.data.x)||0,y:Number(co.actor.data.y)||0}; const dir=(Number(co.actor.data.direction)||0)*Math.PI/180; actorPositionMove(co.actor,Math.cos(dir)*steps,Math.sin(dir)*steps,true); if(checkCollision(co.actor,target)){actorPositionSet(co.actor,old.x,old.y,true);} }
      } else if (name === 'Definir resposta de colisão') {
        co.actor.data.collisionResponse=fbClean(paramStr(blk,'modo','parar',ctx)).toLowerCase();
      } else if (name === 'Definir camada de colisão' || name === 'Camadas de Colisão') {
        co.actor.data.collisionLayer=Math.max(0,Number(param(blk,'camada',1,ctx))||1);
      } else if (name === 'Definir máscara de colisão') {
        co.actor.data.collisionMask=Number(param(blk,'máscara',-1,ctx));
      } else if (name === 'Definir tamanho da colisão') {
        const cs=co.actor.data.collisionShape||{type:'rect'}; cs.type='rect'; cs.width=Math.max(1,Number(param(blk,'largura',48,ctx))||48); cs.height=Math.max(1,Number(param(blk,'altura',48,ctx))||48); cs.enabled=true; co.actor.data.collisionShape=cs; runtime._collisionBoundsFrame=-1;
      } else if (name === 'Definir deslocamento da colisão') {
        const cs=co.actor.data.collisionShape||{type:'rect'}; cs.offsetX=Number(param(blk,'x',0,ctx))||0; cs.offsetY=Number(param(blk,'y',0,ctx))||0; cs.enabled=true; co.actor.data.collisionShape=cs; runtime._collisionBoundsFrame=-1;
      } else if (name === 'Raycast') {
        const ox=Number(co.actor.data.x)||0, oy=Number(co.actor.data.y)||0;
        const dxRaw=Number(param(blk,'x',100,ctx))||100, dyRaw=Number(param(blk,'y',0,ctx))||0;
        const length=Math.max(1,Math.hypot(dxRaw,dyRaw));
        const angle=Number(param(blk,'ângulo',param(blk,'angulo',co.actor.data.direction||0,ctx),ctx))||0;
        const r=angle*Math.PI/180, dx=Math.cos(r)*length, dy=Math.sin(r)*length;
        let closest=null,best=Infinity;
        (runtime.actors||[]).forEach(other=>{
          if(!other||other===co.actor||!other.data||other.data.isCamera||other.data.visible===false)return;
          const b=getActorBounds(other); if(!b)return; const bb=aabbForShape(b);
          const invX=Math.abs(dx)<1e-9?Infinity:1/dx, invY=Math.abs(dy)<1e-9?Infinity:1/dy;
          let tmin=(bb.x-ox)*invX, tmax=(bb.x+bb.w-ox)*invX; if(tmin>tmax)[tmin,tmax]=[tmax,tmin];
          let tymin=(bb.y-oy)*invY, tymax=(bb.y+bb.h-oy)*invY; if(tymin>tymax)[tymin,tymax]=[tymax,tymin];
          tmin=Math.max(tmin,tymin,0); tmax=Math.min(tmax,tymax,1);
          if(tmax>=tmin && tmin*length<best){best=tmin*length;closest=other;}
        });
        co.actor.data._raycastHit=closest?closest.data.name:'';
        co.actor.data._raycastDistance=closest?best:-1;
      } else if (name === 'Ativar Colisão Trigger') {
        co.actor.data.collisionShape=Object.assign({},co.actor.data.collisionShape||{type:'rect'},{enabled:true}); runtime._collisionBoundsFrame=-1;
      } else if (name === 'Sensor de Colisão Contínua') {
        co.actor.data.continuousCollision=true;
      } else if (name === 'Pausar Física do Objeto') {
        co.actor.data.physicsPaused=true;
      } else if (name === 'Aplicar Impulso') {
        co.actor.data.vx=(Number(co.actor.data.vx)||0)+(Number(param(blk,'x',0,ctx))||0); co.actor.data.vy=(Number(co.actor.data.vy)||0)+(Number(param(blk,'y',0,ctx))||0);
      } else if (name === 'Definir Massa/Atrito') {
        co.actor.data.mass=Math.max(0.01,Number(param(blk,'massa',1,ctx))||1); co.actor.data.friction=Math.max(0,Number(param(blk,'atrito',0.1,ctx))||0.1);
      } else if (name === 'Pausar Física do Objeto') { co.actor.data.physicsPaused=true; }
      
      // ---- PRESETS DE COLISÃO ----
      else if (name.startsWith('Preset:')) {
        const preset=name.slice(7).trim(); const d=co.actor.data; d.collisionShape=d.collisionShape||{type:'rect',enabled:true}; d.collisionShape.enabled=true; d._collisionPreset=preset;
        if(preset==='objeto sólido'){ d.collisionResponse='parar'; d.collisionShape.width=Math.max(1,Number(param(blk,'largura',48,ctx))||48); d.collisionShape.height=Math.max(1,Number(param(blk,'altura',48,ctx))||48); }
        else if(preset==='parede'){ d.collisionResponse='parar'; d.collisionPushForce=Number(param(blk,'força',0,ctx))||0; }
        else if(preset==='plataforma'){ d.collisionResponse='platform'; d.collisionShape.height=Math.max(1,Number(param(blk,'altura',24,ctx))||24); d.friction=Math.max(0,Number(param(blk,'atrito',0.2,ctx))||0.2); }
        else if(preset==='coletável'){ d.collisionResponse='collect'; d.collisionValue=param(blk,'valor',1,ctx); d.collisionVariable=fbClean(paramStr(blk,'variável','pontos',ctx)); }
        else if(preset==='dano por contato'){ d.collisionResponse='damage'; d.collisionDamage=Number(param(blk,'dano',10,ctx))||10; d.collisionInterval=Math.max(0,Number(param(blk,'intervalo',500,ctx))||500); }
        else if(preset==='empurrão'){ d.collisionResponse='push'; d.collisionPushForce=Number(param(blk,'força',8,ctx))||8; d.collisionPushDirection=Number(param(blk,'direção',0,ctx))||0; }
        else if(preset==='sensor'){ d.collisionResponse='sensor'; d.collisionSensorVariable=fbClean(paramStr(blk,'variável','colidiu',ctx)); }
        else if(preset==='projétil'){ d.collisionResponse='projectile'; d.collisionDamage=Number(param(blk,'dano',10,ctx))||10; d.collisionProjectileSpeed=Number(param(blk,'velocidade',10,ctx))||10; }
        else if(preset==='plataforma móvel'){ d.collisionResponse='platform'; d._movingPlatform={distance:Number(param(blk,'distância',100,ctx))||100,speed:Number(param(blk,'velocidade',2,ctx))||2}; }
        else if(preset==='zona de teleporte'){ d.collisionResponse='teleport'; d.teleportScene=fbClean(paramStr(blk,'cena','',ctx)); d.teleportX=Number(param(blk,'x',0,ctx))||0; d.teleportY=Number(param(blk,'y',0,ctx))||0; }
        runtime._collisionBoundsFrame=-1;
      }

      // ---- LOOKS ----
      else if (name === 'Mostrar') {
        co.actor.data.visible = true;
        updateSpriteTransform(co.actor);
      } else if (name === 'Esconder') {
        co.actor.data.visible = false;
        updateSpriteTransform(co.actor);
      } else if (name === 'Definir tamanho para') {
        const value=Number(param(blk, 'valor', 100, ctx));
        co.actor.data.size=Math.max(1,Math.min(1000,Number.isFinite(value)?value:100));
        updateSpriteTransform(co.actor);
      } else if (name === 'Mudar tamanho em') {
        const current=Number.isFinite(Number(co.actor.data.size))?Number(co.actor.data.size):100;
        const delta=Number(param(blk, 'valor', 0, ctx));
        co.actor.data.size=Math.max(1,Math.min(1000,current+(Number.isFinite(delta)?delta:0)));
        updateSpriteTransform(co.actor);
      } else if (name === 'Próxima fantasia') {
        const looks = co.actor.data.looks || [];
        if (looks.length) {
          co.actor.data.costume = ((co.actor.data.costume || 0) + 1) % looks.length;
          const src = looks[co.actor.data.costume];
          if (src) setActorCostume(co.actor, src);
        }



      } else if (name === 'Definir posição da câmera' || nname.includes('definir posicao da camera') || nname.includes('definir posição da câmera')) {
        const worldX = Number(param(blk, 'x', 0, ctx)) || 0;
        const worldY = Number(param(blk, 'y', 0, ctx)) || 0;
        runtime.camX = -worldX;
        runtime.camY = worldY;
        runtime._camFollow = null;
        applyEngineCamera();
      } else if (name === 'Mudar posição da câmera em' || nname.includes('mudar posicao da camera') || nname.includes('mudar posição da câmera')) {
        runtime.camX = (Number(runtime.camX) || 0) - (Number(param(blk, 'x', 0, ctx)) || 0);
        runtime.camY = (Number(runtime.camY) || 0) + (Number(param(blk, 'y', 0, ctx)) || 0);
        applyEngineCamera();
      } else if (name === 'Deslizar câmera até' || nname.includes('deslizar camera') || nname.includes('deslizar câmera')) {
        // User x,y = world/actor coords to center on → camera translate is inverted
        const lookX = Number(param(blk, 'x', 0, ctx)) || 0;
        const lookY = Number(param(blk, 'y', 0, ctx)) || 0;
        const sec = Math.max(0.05, Number(param(blk, 'segundos', 0.5, ctx)) || 0.5);
        const toX = -lookX;
        const toY = lookY;
        runtime._camFollow = null;
        runtime._camGlide = {
          fromX: Number(runtime.camX) || 0,
          fromY: Number(runtime.camY) || 0,
          toX: toX, toY: toY,
          start: performance.now(),
          dur: sec * 1000
        };
      } else if (name === 'Zoom suave até' || nname.includes('zoom suave')) {
        const to = Math.max(0.25, Math.min(4, Number(param(blk, 'valor', param(blk, 'zoom', 1, ctx), ctx)) || 1));
        const sec = Math.max(0.15, Number(param(blk, 'segundos', param(blk, 'tempo', 0.5, ctx), ctx)) || 0.5);
        runtime._zoomGlide = {
          from: Number(runtime.camZoom) || 1,
          to: to,
          start: performance.now(),
          dur: sec * 1000
        };
      } else if (name === 'Resetar câmera' || nname === 'resetar camera' || nname === 'resetar câmera') {
        runtime.camX = 0; runtime.camY = 0; runtime.camZoom = 1; runtime.cameraWorldX = 0; runtime.cameraWorldY = 0; runtime.camRot = 0; runtime.camZoomMin = 0.25; runtime.camZoomMax = 4; runtime._camFollowTouch = false;
        runtime.camOffsetX = 0; runtime.camOffsetY = 0;
        runtime._camFollow = null; runtime._camGlide = null; runtime._zoomGlide = null;
        runtime._camShake = null; runtime.camLookAhead = 0;
        applyEngineCamera();
      } else if (name === 'Centralizar no ator' || nname.includes('centralizar no ator')) {
        const nome = paramStr(blk, 'ator', '', ctx).replace(/['"]/g, '');
        let target = nome ? (runtime.actors || []).find(function (a) {
          return a && a.data && String(a.data.name || '').toLowerCase() === nome.toLowerCase();
        }) : co.actor;
        if (!target) target = co.actor;
        if (target && target.data) {
          runtime.camX = -(Number(target.data.x) || 0);
          runtime.camY = (Number(target.data.y) || 0);
          runtime._camFollow = null;
          applyEngineCamera();
        }
      } else if (name === 'Definir offset da câmera' || nname.includes('offset da camera') || nname.includes('offset da câmera')) {
        runtime.camOffsetX = Number(param(blk, 'x', 0, ctx)) || 0;
        runtime.camOffsetY = Number(param(blk, 'y', 0, ctx)) || 0;
      } else if (name === 'Rotacionar câmera' || nname.includes('rotacionar camera') || nname.includes('rotacionar câmera')) {
        runtime.camRot = Number(param(blk, 'graus', 0, ctx)) || 0;
        applyEngineCamera();
      } else if (name === 'Definir suavidade do follow' || nname.includes('suavidade do follow')) {
        const v = Number(param(blk, 'valor', 0.15, ctx));
        runtime.camSmooth = isNaN(v) ? 0.15 : Math.max(0.01, Math.min(1, v));
      } else if (name === 'Definir deadzone do follow' || nname.includes('deadzone')) {
        runtime.camDeadW = Number(param(blk, 'largura', 40, ctx)) || 0;
        runtime.camDeadH = Number(param(blk, 'altura', 40, ctx)) || 0;
      } else if (name === 'Travar eixo da câmera' || nname.includes('travar eixo')) {
        const eixo = paramStr(blk, 'eixo', 'nenhum', ctx).toLowerCase().replace(/['"]/g, '');
        if (eixo.includes('x') && !eixo.includes('y')) runtime.camAxisLock = 'x';
        else if (eixo.includes('y') && !eixo.includes('x')) runtime.camAxisLock = 'y';
        else runtime.camAxisLock = '';
      } else if (name === 'Parar shake da câmera' || nname.includes('parar shake')) {
        runtime._camShake = null;
        applyEngineCamera();
      } else if (name === 'Empurrar câmera' || nname.includes('empurrar camera') || nname.includes('empurrar câmera')) {
        runtime.camX = (Number(runtime.camX) || 0) + (Number(param(blk, 'x', 0, ctx)) || 0);
        runtime.camY = (Number(runtime.camY) || 0) + (Number(param(blk, 'y', 0, ctx)) || 0);
        applyEngineCamera();
      } else if (name === 'Zoom no toque' || nname.includes('zoom no toque')) {
        const z = Math.max(0.25, Math.min(4, Number(param(blk, 'valor', 1.5, ctx)) || 1.5));
        if (runtime.touch) {
          runtime.camX = -(Number(runtime.touch.x) || 0);
          runtime.camY = (Number(runtime.touch.y) || 0);
        }
        runtime.camZoom = z;
        runtime._camFollow = null;
        applyEngineCamera();
      } else if (name === 'Look-ahead da câmera' || nname.includes('look-ahead') || nname.includes('look ahead')) {
        runtime.camLookAhead = Number(param(blk, 'distância', param(blk, 'distancia', 40, ctx), ctx)) || 0;
      } else if (name === 'Quando zoom mudar' || nname.includes('quando zoom mudar')) {
        // hat
      } else if (name === 'Obter posição X da câmera' || nname.includes('posicao x da camera') || nname.includes('posição x da câmera')) {
        const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'camera_x', ctx), ctx).replace(/['"]/g,'') || 'camera_x';
        deviceSetVar(co, vn, -Number(runtime.camX || 0));
      } else if (name === 'Obter posição Y da câmera' || nname.includes('posicao y da camera') || nname.includes('posição y da câmera')) {
        const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'camera_y', ctx), ctx).replace(/['"]/g,'') || 'camera_y';
        deviceSetVar(co, vn, Number(runtime.camY) || 0);
      } else if (name === 'Obter zoom da câmera' || nname.includes('obter zoom')) {
        const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'camera_zoom', ctx), ctx).replace(/['"]/g,'') || 'camera_zoom';
        deviceSetVar(co, vn, Number(runtime.camZoom) || 1);
      } else if (name === 'Obter rotação da câmera' || nname.includes('obter rotacao da camera') || nname.includes('obter rotação da câmera')) {
        const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'camera_rotacao', ctx), ctx).replace(/['"]/g,'') || 'camera_rotacao';
        deviceSetVar(co, vn, Number(runtime.camRot) || 0);
      } else if (name === 'Obter largura da tela' || nname.includes('obter largura da tela')) {
        const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'tela_largura', ctx), ctx).replace(/['"]/g,'') || 'tela_largura';
        deviceSetVar(co, vn, Number((runtime.stageEl && runtime.stageEl._stageW) || 0));
      } else if (name === 'Obter altura da tela' || nname.includes('obter altura da tela')) {
        const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'tela_altura', ctx), ctx).replace(/['"]/g,'') || 'tela_altura';
        deviceSetVar(co, vn, Number((runtime.stageEl && runtime.stageEl._stageH) || 0));
      } else if (name === 'Facilitador: câmera no jogador' || nname.includes('camera no jogador') || nname.includes('câmera no jogador')) {
        const nome = paramStr(blk, 'ator', 'Jogador', ctx).replace(/['"]/g, '');
        let target = (runtime.actors || []).find(function (a) {
          return a && a.data && String(a.data.name || '').toLowerCase() === nome.toLowerCase();
        }) || co.actor;
        runtime._camFollow = target;
        runtime.camSmooth = 0.12;
        runtime.camOffsetX = 0; runtime.camOffsetY = 0;
      } else if (name === 'Facilitador: reset completo da câmera' || nname.includes('reset completo da camera') || nname.includes('reset completo da câmera')) {
        runtime.camX = 0; runtime.camY = 0; runtime.camZoom = 1; runtime.cameraWorldX = 0; runtime.cameraWorldY = 0; runtime.camRot = 0; runtime.camZoomMin = 0.25; runtime.camZoomMax = 4; runtime._camFollowTouch = false;
        runtime.camOffsetX = 0; runtime.camOffsetY = 0; runtime.camSmooth = 1;
        runtime.camDeadW = 0; runtime.camDeadH = 0; runtime.camAxisLock = '';
        runtime.camLookAhead = 0; runtime._camFollow = null;
        runtime._camGlide = null; runtime._zoomGlide = null; runtime._camShake = null;
        runtime._camBounds = null;
        applyEngineCamera();
      } else if (name === 'Facilitador: zoom de impacto' || nname.includes('zoom de impacto')) {
        const z = Math.max(0.25, Math.min(4, Number(param(blk, 'valor', 1.25, ctx)) || 1.25));
        const sec = Math.max(0.05, Number(param(blk, 'segundos', 0.25, ctx)) || 0.25);
        const from = Number(runtime.camZoom) || 1;
        runtime._zoomGlide = { from: from, to: z, start: performance.now(), dur: sec * 500 };
        kixSetTimeout(function () {
          runtime._zoomGlide = { from: z, to: from, start: performance.now(), dur: sec * 500 };
        }, sec * 500);
      } else if (name === 'Facilitador: seguir com suavidade' || nname.includes('seguir com suavidade')) {
        const nome = paramStr(blk, 'ator', '', ctx).replace(/['"]/g, '');
        const sm = Number(param(blk, 'suavidade', 0.1, ctx));
        let target = nome ? (runtime.actors || []).find(function (a) {
          return a && a.data && String(a.data.name || '').toLowerCase() === nome.toLowerCase();
        }) : co.actor;
        runtime._camFollow = target || co.actor;
        runtime.camSmooth = isNaN(sm) ? 0.1 : Math.max(0.01, Math.min(1, sm));
      } else if (name === 'Facilitador: bounds do palco' || nname.includes('bounds do palco')) {
        const sw = (runtime.stageEl && runtime.stageEl._stageW) || 360;
        const sh = (runtime.stageEl && runtime.stageEl._stageH) || 640;
        runtime._camBounds = { minX: -sw, maxX: sw, minY: -sh, maxY: sh };

      } else if (name === 'Criar barra de vida flutuante' || nname.includes('barra de vida flutuante')) {
        const id = paramStr(blk, 'id', 'hp1', ctx).replace(/['"]/g, '') || 'hp1';
        const max = Number(param(blk, 'max', 100, ctx)) || 100;
        const hud = ensureHud();
        const node = hudEl(id, 'div', 'position:absolute;left:' + (hud.x) + 'px;top:' + (hud.y) + 'px;width:120px;height:14px;background:rgba(0,0,0,0.55);border-radius:7px;overflow:hidden;border:1px solid rgba(255,255,255,0.2);');
        if (node) {
          node.max = max; node.value = max;
          node.el.innerHTML = '<div data-fill style="height:100%;width:100%;background:linear-gradient(90deg,#22c55e,#16a34a);border-radius:7px;transition:width 0.2s;"></div>';
        }
      } else if (name === 'Atualizar barra de vida' || nname.includes('atualizar barra de vida')) {
        const id = paramStr(blk, 'id', 'hp1', ctx).replace(/['"]/g, '') || 'hp1';
        const val = Number(param(blk, 'valor', 100, ctx));
        const hud = ensureHud();
        const node = hud.elements[id];
        if (node && node.el) {
          node.value = isNaN(val) ? 0 : val;
          const max = node.max || 100;
          const pct = Math.max(0, Math.min(100, (node.value / max) * 100));
          const fill = node.el.querySelector('[data-fill]');
          if (fill) {
            fill.style.width = pct + '%';
            fill.style.background = pct > 50 ? 'linear-gradient(90deg,#22c55e,#16a34a)' : pct > 25 ? 'linear-gradient(90deg,#eab308,#ca8a04)' : 'linear-gradient(90deg,#ef4444,#b91c1c)';
          }
        }
      } else if (name === 'Criar killfeed' || nname === 'criar killfeed') {
        const hud = ensureHud();
        const node = hudEl('killfeed', 'div', 'position:absolute;right:8px;top:8px;width:200px;max-height:160px;overflow:hidden;display:flex;flex-direction:column;gap:4px;align-items:flex-end;');
        if (node) node.el.innerHTML = '';
        hud.killfeed = [];
      } else if (name === 'Adicionar entrada ao killfeed' || nname.includes('entrada ao killfeed')) {
        const texto = paramStr(blk, 'texto', '', ctx);
        const hud = ensureHud();
        ensureHud();
        let node = hud.elements['killfeed'];
        if (!node) {
          node = hudEl('killfeed', 'div', 'position:absolute;right:8px;top:8px;width:200px;max-height:160px;overflow:hidden;display:flex;flex-direction:column;gap:4px;align-items:flex-end;');
        }
        if (node && node.el) {
          const row = document.createElement('div');
          row.style.cssText = 'background:rgba(0,0,0,0.65);color:#fff;font-size:11px;padding:4px 8px;border-radius:4px;opacity:1;transition:opacity 0.4s;';
          row.textContent = texto;
          node.el.appendChild(row);
          hud.killfeed.push(row);
          while (hud.killfeed.length > 6) {
            const old = hud.killfeed.shift();
            if (old && old.parentNode) old.parentNode.removeChild(old);
          }
          kixSetTimeout(function () {
            row.style.opacity = '0';
            kixSetTimeout(function () { if (row.parentNode) row.parentNode.removeChild(row); }, 400);
          }, 3500);
        }
      } else if (name === 'Criar timer de partida' || nname.includes('timer de partida')) {
        const sec = Number(param(blk, 'segundos', 180, ctx)) || 180;
        const hud = ensureHud();
        hud.timer = { end: performance.now() + sec * 1000, running: true };
        const node = hudEl('timer_partida', 'div', 'position:absolute;left:50%;top:8px;transform:translateX(-50%);background:rgba(0,0,0,0.7);color:#fff;font-size:18px;font-weight:700;padding:6px 14px;border-radius:8px;letter-spacing:1px;');
        if (node) node.el.textContent = '00:00';
      } else if (name === 'Criar placar por time' || nname.includes('placar por time')) {
        const a = paramStr(blk, 'timeA', 'Time A', ctx);
        const b = paramStr(blk, 'timeB', 'Time B', ctx);
        const hud = ensureHud();
        hud.score.nameA = a; hud.score.nameB = b; hud.score.A = 0; hud.score.B = 0;
        const node = hudEl('placar', 'div', 'position:absolute;left:50%;top:44px;transform:translateX(-50%);display:flex;gap:12px;align-items:center;background:rgba(0,0,0,0.7);color:#fff;padding:6px 16px;border-radius:8px;font-weight:700;font-size:16px;');
        if (node) node.el.innerHTML = '<span data-a>' + a + ' 0</span><span style="opacity:0.5">×</span><span data-b>0 ' + b + '</span>';
      } else if (name === 'Atualizar placar' || nname.includes('atualizar placar')) {
        const time = paramStr(blk, 'time', 'A', ctx).toUpperCase().replace(/['"]/g, '');
        const pts = Number(param(blk, 'pontos', 0, ctx)) || 0;
        const hud = ensureHud();
        if (time === 'A' || time.includes(String(hud.score.nameA || '').toUpperCase().slice(0, 1))) hud.score.A = pts;
        else hud.score.B = pts;
        const node = hud.elements['placar'];
        if (node && node.el) {
          const ea = node.el.querySelector('[data-a]');
          const eb = node.el.querySelector('[data-b]');
          if (ea) ea.textContent = hud.score.nameA + ' ' + hud.score.A;
          if (eb) eb.textContent = hud.score.B + ' ' + hud.score.nameB;
        }
      } else if (name === 'Indicador de dano recebido' || nname.includes('indicador de dano')) {
        const val = paramStr(blk, 'valor', '10', ctx);
        const hud = ensureHud();
        const root = runtime._hudRoot;
        if (root) {
          const flash = document.createElement('div');
          flash.style.cssText = 'position:absolute;inset:0;background:rgba(220,38,38,0.25);pointer-events:none;animation:kixDmg 0.35s ease-out forwards;';
          root.appendChild(flash);
          const label = document.createElement('div');
          label.style.cssText = 'position:absolute;left:50%;top:40%;transform:translate(-50%,-50%);color:#fca5a5;font-size:28px;font-weight:800;text-shadow:0 2px 8px #000;pointer-events:none;';
          label.textContent = '-' + val;
          root.appendChild(label);
          kixSetTimeout(function () {
            if (flash.parentNode) flash.parentNode.removeChild(flash);
            if (label.parentNode) label.parentNode.removeChild(label);
          }, 400);
        }
      } else if (name === 'Mostrar HUD' || nname === 'mostrar hud') {
        ensureHud().visible = true;
        if (runtime._hudRoot) runtime._hudRoot.style.display = '';
      } else if (name === 'Esconder HUD' || nname === 'esconder hud') {
        ensureHud().visible = false;
        if (runtime._hudRoot) runtime._hudRoot.style.display = 'none';
      } else if (name === 'Definir posição do HUD' || nname.includes('posicao do hud') || nname.includes('posição do hud')) {
        const hud = ensureHud();
        hud.x = Number(param(blk, 'x', 8, ctx)) || 8;
        hud.y = Number(param(blk, 'y', 8, ctx)) || 8;
      } else if (name === 'Criar botão' || nname === 'criar botao' || nname === 'criar botão') {
        const id = paramStr(blk, 'id', 'btn1', ctx).replace(/['"]/g, '') || 'btn1';
        const texto = paramStr(blk, 'texto', 'Botão', ctx);
        const node = hudEl(id, 'button', 'position:absolute;left:12px;bottom:12px;padding:10px 18px;border:none;border-radius:10px;background:#10b981;color:#fff;font-weight:600;font-size:14px;cursor:pointer;');
        if (node) {
          node.el.textContent = texto;
          node.el.onclick = function () {
            try {
              runtime._lastUiButton = id;
              runtime.actors.forEach(function (ra) { startHatsFor(ra, 'Quando botão pressionado'); });
            } catch (_) {}
          };
        }
      } else if (name === 'Criar slider' || nname === 'criar slider') {
        const id = paramStr(blk, 'id', 'sl1', ctx).replace(/['"]/g, '') || 'sl1';
        const min = Number(param(blk, 'min', 0, ctx)) || 0;
        const max = Number(param(blk, 'max', 100, ctx)) || 100;
        const node = hudEl(id, 'input', 'position:absolute;left:12px;bottom:56px;width:140px;');
        if (node) {
          node.el.type = 'range'; node.el.min = min; node.el.max = max; node.el.value = (min + max) / 2;
          node.el.oninput = function () {
            runtime._sliderVals = runtime._sliderVals || {};
            runtime._sliderVals[id] = Number(node.el.value);
            try { runtime.actors.forEach(function (ra) { startHatsFor(ra, 'Quando slider mudar'); }); } catch (_) {}
          };
        }
      } else if (name === 'Criar texto na UI' || nname.includes('criar texto na ui')) {
        const id = paramStr(blk, 'id', 'txt1', ctx).replace(/['"]/g, '') || 'txt1';
        const texto = paramStr(blk, 'texto', '', ctx);
        const node = hudEl(id, 'div', 'position:absolute;left:12px;top:12px;color:#fff;font-size:14px;text-shadow:0 1px 3px #000;');
        if (node) node.el.textContent = texto;
      } else if (name === 'Criar barra de progresso' || nname.includes('barra de progresso')) {
        const id = paramStr(blk, 'id', 'prog1', ctx).replace(/['"]/g, '') || 'prog1';
        const max = Number(param(blk, 'max', 100, ctx)) || 100;
        const node = hudEl(id, 'div', 'position:absolute;left:12px;top:40px;width:160px;height:10px;background:rgba(0,0,0,0.5);border-radius:5px;overflow:hidden;');
        if (node) {
          node.max = max; node.value = 0;
          node.el.innerHTML = '<div data-fill style="height:100%;width:0%;background:#3b82f6;transition:width 0.2s;"></div>';
        }
      } else if (name === 'Atualizar barra de progresso' || nname.includes('atualizar barra de progresso')) {
        const id = paramStr(blk, 'id', 'prog1', ctx).replace(/['"]/g, '') || 'prog1';
        const val = Number(param(blk, 'valor', 0, ctx)) || 0;
        const node = ensureHud().elements[id];
        if (node && node.el) {
          const pct = Math.max(0, Math.min(100, (val / (node.max || 100)) * 100));
          const fill = node.el.querySelector('[data-fill]');
          if (fill) fill.style.width = pct + '%';
        }
      } else if (name === 'Criar minimapa' || nname === 'criar minimapa') {
        const node = hudEl('minimapa', 'div', 'position:absolute;right:8px;bottom:8px;width:100px;height:100px;background:rgba(0,0,0,0.55);border:1px solid rgba(255,255,255,0.25);border-radius:8px;overflow:hidden;');
        if (node) node.el.innerHTML = '';
      } else if (name === 'Atualizar ponto no minimapa' || nname.includes('ponto no minimapa')) {
        const id = paramStr(blk, 'id', 'p1', ctx).replace(/['"]/g, '') || 'p1';
        const x = Number(param(blk, 'x', 0, ctx)) || 0;
        const y = Number(param(blk, 'y', 0, ctx)) || 0;
        const map = ensureHud().elements['minimapa'];
        if (map && map.el) {
          let dot = map.el.querySelector('[data-dot="' + id + '"]');
          if (!dot) {
            dot = document.createElement('div');
            dot.dataset.dot = id;
            dot.style.cssText = 'position:absolute;width:6px;height:6px;border-radius:50%;background:#22c55e;';
            map.el.appendChild(dot);
          }
          const sw = (runtime.stageEl && runtime.stageEl._stageW) || 360;
          const sh = (runtime.stageEl && runtime.stageEl._stageH) || 640;
          const px = ((x + sw / 2) / sw) * 100;
          const py = ((-y + sh / 2) / sh) * 100;
          dot.style.left = Math.max(0, Math.min(94, px)) + '%';
          dot.style.top = Math.max(0, Math.min(94, py)) + '%';
        }
      } else if (name === 'Criar diálogo' || nname.includes('criar dialogo') || nname.includes('criar diálogo')) {
        const id = paramStr(blk, 'id', 'dlg1', ctx).replace(/['"]/g, '') || 'dlg1';
        const texto = paramStr(blk, 'texto', '', ctx);
        const node = hudEl(id, 'div', 'position:absolute;left:50%;bottom:24px;transform:translateX(-50%);max-width:90%;background:rgba(15,15,20,0.92);color:#fff;padding:14px 18px;border-radius:12px;font-size:14px;border:1px solid rgba(255,255,255,0.12);');
        if (node) node.el.textContent = texto;
      } else if (name === 'Fechar diálogo' || nname.includes('fechar dialogo') || nname.includes('fechar diálogo')) {
        const id = paramStr(blk, 'id', 'dlg1', ctx).replace(/['"]/g, '') || 'dlg1';
        const node = ensureHud().elements[id];
        if (node && node.el) node.el.style.display = 'none';
      } else if (name === 'Criar menu de pausa' || nname.includes('menu de pausa')) {
        const node = hudEl('menu_pausa', 'div', 'position:absolute;inset:0;background:rgba(0,0,0,0.65);display:none;align-items:center;justify-content:center;flex-direction:column;gap:12px;pointer-events:auto;');
        if (node) {
          node.el.innerHTML = '<div style="color:#fff;font-size:22px;font-weight:700;">Pausa</div><button data-resume style="padding:10px 20px;border:none;border-radius:8px;background:#10b981;color:#fff;font-weight:600;">Continuar</button>';
          const btn = node.el.querySelector('[data-resume]');
          if (btn) btn.onclick = function () {
            node.el.style.display = 'none';
            try { if (runtime.paused) togglePause(); } catch (_) {}
          };
        }
      } else if (name === 'Mostrar menu de pausa' || nname.includes('mostrar menu de pausa')) {
        const node = ensureHud().elements['menu_pausa'];
        if (node && node.el) {
          node.el.style.display = 'flex';
          try { if (!runtime.paused) togglePause(); } catch (_) {}
        }
      } else if (name === 'Esconder menu de pausa' || nname.includes('esconder menu de pausa')) {
        const node = ensureHud().elements['menu_pausa'];
        if (node && node.el) node.el.style.display = 'none';
      } else if (name === 'Criar contador' || nname.includes('criar contador')) {
        const id = paramStr(blk, 'id', 'cnt1', ctx).replace(/['"]/g, '') || 'cnt1';
        const val = paramStr(blk, 'valor', '0', ctx);
        const node = hudEl(id, 'div', 'position:absolute;right:12px;top:12px;color:#fff;font-size:20px;font-weight:700;text-shadow:0 1px 4px #000;');
        if (node) node.el.textContent = val;
      } else if (name === 'Atualizar contador' || nname.includes('atualizar contador')) {
        const id = paramStr(blk, 'id', 'cnt1', ctx).replace(/['"]/g, '') || 'cnt1';
        const val = paramStr(blk, 'valor', '0', ctx);
        const node = ensureHud().elements[id];
        if (node && node.el) node.el.textContent = val;
      } else if (name === 'Criar ícone de status' || nname.includes('icone de status') || nname.includes('ícone de status')) {
        const id = paramStr(blk, 'id', 'st1', ctx).replace(/['"]/g, '') || 'st1';
        const icon = paramStr(blk, 'ícone', paramStr(blk, 'icone', 'Ícone', ctx), ctx);
        const node = hudEl(id, 'div', 'position:absolute;left:12px;top:60px;font-size:22px;');
        if (node) node.el.textContent = icon;
      } else if (name === 'Criar cooldown radial' || nname.includes('cooldown radial')) {
        const id = paramStr(blk, 'id', 'cd1', ctx).replace(/['"]/g, '') || 'cd1';
        const sec = Number(param(blk, 'segundos', 3, ctx)) || 3;
        const node = hudEl(id, 'div', 'position:absolute;right:16px;bottom:16px;width:48px;height:48px;border-radius:50%;background:conic-gradient(#10b981 0deg,rgba(255,255,255,0.2) 0deg);border:2px solid rgba(255,255,255,0.3);');
        if (node) {
          const start = performance.now();
          const tick = function () {
            const t = Math.min(1, (performance.now() - start) / (sec * 1000));
            const deg = t * 360;
            node.el.style.background = 'conic-gradient(#10b981 ' + deg + 'deg, rgba(255,255,255,0.2) ' + deg + 'deg)';
            if (t < 1) kixRequestAnimationFrame(tick);
          };
          kixRequestAnimationFrame(tick);
        }
      } else if (name === 'Criar crosshair' || nname === 'criar crosshair') {
        const node = hudEl('crosshair', 'div', 'position:absolute;left:50%;top:50%;width:20px;height:20px;margin:-10px 0 0 -10px;pointer-events:none;');
        if (node) node.el.innerHTML = '<div style="position:absolute;left:50%;top:0;width:2px;height:100%;background:#fff;transform:translateX(-50%);opacity:0.8;"></div><div style="position:absolute;top:50%;left:0;height:2px;width:100%;background:#fff;transform:translateY(-50%);opacity:0.8;"></div>';
      } else if (name === 'Mostrar tooltip' || nname.includes('mostrar tooltip')) {
        const texto = paramStr(blk, 'texto', '', ctx);
        const node = hudEl('tooltip_tmp', 'div', 'position:absolute;left:50%;bottom:80px;transform:translateX(-50%);background:rgba(0,0,0,0.8);color:#fff;padding:6px 12px;border-radius:6px;font-size:12px;');
        if (node) {
          node.el.textContent = texto;
          node.el.style.display = '';
          kixSetTimeout(function () { if (node.el) node.el.style.display = 'none'; }, 2000);
        }
      } else if (name === 'Criar notificação toast UI' || nname.includes('notificacao toast ui') || nname.includes('notificação toast ui')) {
        const texto = paramStr(blk, 'texto', '', ctx);
        try { if (typeof window.toast === 'function') window.toast(texto); } catch (_) {}
      } else if (name === 'Definir estilo do HUD' || nname.includes('estilo do hud')) {
        const tema = paramStr(blk, 'tema', 'dark', ctx).toLowerCase();
        ensureHud().theme = tema;
        if (runtime._hudRoot) {
          runtime._hudRoot.style.filter = tema.includes('light') ? 'invert(1) hue-rotate(180deg)' : '';
        }
      } else if (name === 'Quando botão pressionado' || nname.includes('quando botao pressionado') || nname.includes('quando botão pressionado')) {
        // hat
      } else if (name === 'Quando slider mudar' || nname.includes('quando slider mudar')) {
        // hat
      } else if (name === 'Obter valor do slider' || nname.includes('obter valor do slider')) {
        const id = paramStr(blk, 'id', 'sl1', ctx).replace(/['"]/g, '') || 'sl1';
        const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'slider', ctx), ctx).replace(/['"]/g, '');
        const v = (runtime._sliderVals && runtime._sliderVals[id] != null) ? runtime._sliderVals[id] : 0;
        deviceSetVar(co, vn || 'slider', v);
      } else if (name === 'Mostrar elemento UI' || nname.includes('mostrar elemento ui')) {
        const id = paramStr(blk, 'id', '', ctx).replace(/['"]/g, '');
        const node = ensureHud().elements[id];
        if (node && node.el) node.el.style.display = '';
      } else if (name === 'Esconder elemento UI' || nname.includes('esconder elemento ui')) {
        const id = paramStr(blk, 'id', '', ctx).replace(/['"]/g, '');
        const node = ensureHud().elements[id];
        if (node && node.el) node.el.style.display = 'none';
      } else if (name === 'Definir posição da UI' || nname.includes('definir posicao da ui') || nname.includes('definir posição da ui')) {
        const id = paramStr(blk, 'id', '', ctx).replace(/['"]/g, '');
        const x = Number(param(blk, 'x', 0, ctx)) || 0;
        const y = Number(param(blk, 'y', 0, ctx)) || 0;
        const node = ensureHud().elements[id];
        if (node && node.el) {
          node.el.style.left = x + 'px';
          node.el.style.top = y + 'px';
          node.el.style.bottom = 'auto';
          node.el.style.right = 'auto';
          node.el.style.transform = 'none';
        }
      } else if (name === 'Definir tamanho da UI' || nname.includes('tamanho da ui')) {
        const id = paramStr(blk, 'id', '', ctx).replace(/['"]/g, '');
        const w = Number(param(blk, 'largura', 100, ctx)) || 100;
        const h = Number(param(blk, 'altura', 40, ctx)) || 40;
        const node = ensureHud().elements[id];
        if (node && node.el) {
          node.el.style.width = w + 'px';
          node.el.style.height = h + 'px';
        }
      } else if (name === 'Animar UI' || nname.includes('animar ui')) {
        const id = paramStr(blk, 'id', '', ctx).replace(/['"]/g, '');
        const tipo = paramStr(blk, 'tipo', 'pulse', ctx).toLowerCase();
        const node = ensureHud().elements[id];
        if (node && node.el) {
          node.el.style.transition = 'transform 0.25s, opacity 0.25s';
          if (tipo.includes('pulse')) {
            node.el.style.transform = 'scale(1.08)';
            kixSetTimeout(function () { node.el.style.transform = 'scale(1)'; }, 250);
          } else if (tipo.includes('fade')) {
            node.el.style.opacity = '0.3';
            kixSetTimeout(function () { node.el.style.opacity = '1'; }, 250);
          }
        }
      } else if (name === 'Criar lista de inventário' || nname.includes('lista de inventario') || nname.includes('lista de inventário')) {
        const slots = Math.max(1, Math.min(12, Number(param(blk, 'slots', 5, ctx)) || 5));
        const node = hudEl('inventario', 'div', 'position:absolute;left:50%;bottom:12px;transform:translateX(-50%);display:flex;gap:6px;');
        if (node) {
          node.el.innerHTML = '';
          for (let i = 0; i < slots; i++) {
            const slot = document.createElement('div');
            slot.dataset.slot = String(i);
            slot.style.cssText = 'width:40px;height:40px;background:rgba(0,0,0,0.55);border:1px solid rgba(255,255,255,0.25);border-radius:6px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:11px;';
            node.el.appendChild(slot);
          }
        }
      } else if (name === 'Definir item do inventário' || nname.includes('item do inventario') || nname.includes('item do inventário')) {
        const slot = Number(param(blk, 'slot', 0, ctx)) || 0;
        const nome = paramStr(blk, 'nome', '', ctx);
        const inv = ensureHud().elements['inventario'];
        if (inv && inv.el) {
          const el = inv.el.querySelector('[data-slot="' + slot + '"]');
          if (el) el.textContent = nome;
        }
      } else if (name === 'Criar barra de XP' || nname.includes('barra de xp')) {
        const id = paramStr(blk, 'id', 'xp1', ctx).replace(/['"]/g, '') || 'xp1';
        const max = Number(param(blk, 'max', 100, ctx)) || 100;
        const node = hudEl(id, 'div', 'position:absolute;left:12px;bottom:100px;width:140px;height:8px;background:rgba(0,0,0,0.5);border-radius:4px;overflow:hidden;');
        if (node) {
          node.max = max;
          node.el.innerHTML = '<div data-fill style="height:100%;width:0%;background:#a855f7;transition:width 0.25s;"></div>';
        }
      } else if (name === 'Atualizar barra de XP' || nname.includes('atualizar barra de xp')) {
        const id = paramStr(blk, 'id', 'xp1', ctx).replace(/['"]/g, '') || 'xp1';
        const val = Number(param(blk, 'valor', 0, ctx)) || 0;
        const node = ensureHud().elements[id];
        if (node && node.el) {
          const pct = Math.max(0, Math.min(100, (val / (node.max || 100)) * 100));
          const fill = node.el.querySelector('[data-fill]');
          if (fill) fill.style.width = pct + '%';
        }
      } else if (name === 'Criar radar' || nname === 'criar radar') {
        const alcance = Number(param(blk, 'alcance', 200, ctx)) || 200;
        const node = hudEl('radar', 'div', 'position:absolute;right:8px;top:120px;width:80px;height:80px;border-radius:50%;background:rgba(0,40,0,0.5);border:1px solid #22c55e;');
        if (node) { node.alcance = alcance; node.el.innerHTML = ''; }
      } else if (name === 'Marcar no radar' || nname.includes('marcar no radar')) {
        const id = paramStr(blk, 'id', 'r1', ctx).replace(/['"]/g, '') || 'r1';
        const x = Number(param(blk, 'x', 0, ctx)) || 0;
        const y = Number(param(blk, 'y', 0, ctx)) || 0;
        const radar = ensureHud().elements['radar'];
        if (radar && radar.el) {
          let dot = radar.el.querySelector('[data-r="' + id + '"]');
          if (!dot) {
            dot = document.createElement('div');
            dot.dataset.r = id;
            dot.style.cssText = 'position:absolute;width:5px;height:5px;border-radius:50%;background:#fbbf24;';
            radar.el.appendChild(dot);
          }
          const alc = radar.alcance || 200;
          const px = 40 + (x / alc) * 35;
          const py = 40 - (y / alc) * 35;
          dot.style.left = Math.max(2, Math.min(74, px)) + 'px';
          dot.style.top = Math.max(2, Math.min(74, py)) + 'px';
        }
      } else if (name === 'Facilitador: HUD de combate completo' || nname.includes('hud de combate completo')) {
        // hp + killfeed + crosshair + timer
        ensureHud();
        // inline minimal setup
        try {
          const max = 100;
          const node = hudEl('hp1', 'div', 'position:absolute;left:8px;top:8px;width:120px;height:14px;background:rgba(0,0,0,0.55);border-radius:7px;overflow:hidden;');
          if (node) {
            node.max = max; node.value = max;
            node.el.innerHTML = '<div data-fill style="height:100%;width:100%;background:#22c55e;border-radius:7px;"></div>';
          }
          hudEl('killfeed', 'div', 'position:absolute;right:8px;top:8px;width:180px;display:flex;flex-direction:column;gap:4px;align-items:flex-end;');
          const ch = hudEl('crosshair', 'div', 'position:absolute;left:50%;top:50%;width:16px;height:16px;margin:-8px 0 0 -8px;pointer-events:none;');
          if (ch) ch.el.innerHTML = '<div style="position:absolute;left:50%;top:0;width:2px;height:100%;background:#fff;transform:translateX(-50%);"></div><div style="position:absolute;top:50%;left:0;height:2px;width:100%;background:#fff;transform:translateY(-50%);"></div>';
        } catch (_) {}
      } else if (name === 'Facilitador: placar 2 times' || nname.includes('placar 2 times')) {
        const a = paramStr(blk, 'nomeA', 'Azul', ctx);
        const b = paramStr(blk, 'nomeB', 'Vermelho', ctx);
        const hud = ensureHud();
        hud.score = { A: 0, B: 0, nameA: a, nameB: b };
        const node = hudEl('placar', 'div', 'position:absolute;left:50%;top:8px;transform:translateX(-50%);display:flex;gap:12px;background:rgba(0,0,0,0.7);color:#fff;padding:6px 16px;border-radius:8px;font-weight:700;');
        if (node) node.el.innerHTML = '<span data-a>' + a + ' 0</span><span>×</span><span data-b>0 ' + b + '</span>';
      } else if (name === 'Facilitador: timer countdown' || nname.includes('timer countdown')) {
        const sec = Number(param(blk, 'segundos', 60, ctx)) || 60;
        const hud = ensureHud();
        hud.timer = { end: performance.now() + sec * 1000, running: true };
        const node = hudEl('timer_partida', 'div', 'position:absolute;left:50%;top:48px;transform:translateX(-50%);background:rgba(0,0,0,0.7);color:#fff;font-size:18px;font-weight:700;padding:6px 14px;border-radius:8px;');
        if (node) node.el.textContent = '00:00';
      } else if (name === 'Facilitador: barra de vida no jogador' || nname.includes('barra de vida no jogador')) {
        const max = Number(param(blk, 'max', 100, ctx)) || 100;
        const node = hudEl('hp_player', 'div', 'position:absolute;left:8px;top:8px;width:140px;height:16px;background:rgba(0,0,0,0.55);border-radius:8px;overflow:hidden;border:1px solid rgba(255,255,255,0.2);');
        if (node) {
          node.max = max; node.value = max;
          node.el.innerHTML = '<div data-fill style="height:100%;width:100%;background:#22c55e;border-radius:8px;"></div>';
        }
      } else if (name === 'Facilitador: limpar toda a UI' || nname.includes('limpar toda a ui')) {
        clearAllHud();
      } else if (name === 'Seguir ator com câmera' || nname.includes('seguir ator com camera') || nname.includes('seguir ator com câmera')) {
        const nome = paramStr(blk, 'ator', paramStr(blk, 'objeto', '', ctx), ctx).replace(/['"]/g, '');
        let target = null;
        if (nome) {
          target = (runtime.actors || []).find(function (a) {
            return a && a.data && String(a.data.name || '').toLowerCase() === nome.toLowerCase();
          });
        }
        if (!target) target = co.actor;
        runtime._camFollow = target;
        if (target && target.data) {
          // center camera on target (stage translate inverse)
          try {
            if (typeof camX !== 'undefined') {
              // Host free-camera vars may not exist in the runtime state — use runtime state.
            }
            runtime.camX = -(Number(target.data.x) || 0);
            runtime.camY = (Number(target.data.y) || 0);
            applyEngineCamera();
          } catch (_) {}
        }
      } else if (name === 'Desligar follow da câmera' || nname.includes('desligar follow')) {
        runtime._camFollow = null;
        runtime._camFollowTouch = false;
        applyEngineCamera();
      } else if (name === 'Destravar câmera' || nname.includes('destravar camera') || nname.includes('destravar câmera')) {
        runtime.freeCam = false; runtime._camFree = false;
        runtime._camFollow = null; runtime._camFollowTouch = false;
        try { window.__kixFreeCam = false; } catch (_) {}
        applyEngineCamera();
      } else if (name === 'Câmera mirar em ator' || nname.includes('camera mirar em ator') || nname.includes('câmera mirar em ator')) {
        const nome = paramStr(blk, 'ator', '', ctx).replace(/['"]/g, '');
        const target = nome ? (runtime.actors || []).find(a => a && a.data && String(a.data.name || '').toLowerCase() === nome.toLowerCase()) : co.actor;
        if (target) {
          runtime._camFollow = target;
          runtime._camFollowTouch = false;
          runtime.camSmooth = 1;
          applyEngineCamera();
        }
      } else if (name === 'Definir zoom mínimo e máximo' || nname.includes('definir zoom minimo e maximo') || nname.includes('definir zoom mínimo e máximo')) {
        runtime.camZoomMin = Math.max(0.05, Number(param(blk, 'mínimo', param(blk, 'minimo', 0.25, ctx), ctx)) || 0.25);
        runtime.camZoomMax = Math.max(runtime.camZoomMin, Number(param(blk, 'máximo', param(blk, 'maximo', 4, ctx), ctx)) || 4);
        runtime.camZoom = Math.max(runtime.camZoomMin, Math.min(runtime.camZoomMax, Number(runtime.camZoom) || 1));
        applyEngineCamera();
      } else if (name === 'Obter centro X da câmera' || nname.includes('obter centro x da camera') || nname.includes('obter centro x da câmera')) {
        const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'camera_centro_x', ctx), ctx).replace(/['"]/g,'') || 'camera_centro_x';
        const sw = Number(runtime._logicalStageW || (runtime.stageEl && runtime.stageEl._stageW) || 480) / 2;
        deviceSetVar(co, vn, -Number(runtime.camX || 0) + sw);
      } else if (name === 'Obter centro Y da câmera' || nname.includes('obter centro y da camera') || nname.includes('obter centro y da câmera')) {
        const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'camera_centro_y', ctx), ctx).replace(/['"]/g,'') || 'camera_centro_y';
        const sh = Number(runtime._logicalStageH || (runtime.stageEl && runtime.stageEl._stageH) || 800) / 2;
        deviceSetVar(co, vn, Number(runtime.camY || 0) + sh);
      } else if (name === 'Câmera seguir toque' || nname.includes('camera seguir toque') || nname.includes('câmera seguir toque')) {
        runtime._camFollowTouch = true;
        runtime._camFollow = null;
      } else if (name === 'Centralizar no toque' || nname.includes('centralizar no toque')) {
        runtime.camX = -(Number(runtime.touch.x) || 0);
        runtime.camY = (Number(runtime.touch.y) || 0);
        runtime._camFollow = null;
        applyEngineCamera();
      } else if (name === 'Limitar zoom da câmera' || nname.includes('limitar zoom')) {
        runtime.camZoomMin = Math.max(0.05, Number(param(blk, 'mínimo', param(blk, 'minimo', 0.25, ctx), ctx)) || 0.25);
        runtime.camZoomMax = Math.max(runtime.camZoomMin, Number(param(blk, 'máximo', param(blk, 'maximo', 4, ctx), ctx)) || 4);
        runtime.camZoom = Math.max(runtime.camZoomMin, Math.min(runtime.camZoomMax, Number(runtime.camZoom) || 1));
        applyEngineCamera();
      } else if (name === 'Zoom da câmera' || nname.includes('zoom da camera') || nname.includes('zoom da câmera')) {
        const z = Number(param(blk, 'valor', 1, ctx));
        const minZ = Number(runtime.camZoomMin != null ? runtime.camZoomMin : 0.25) || 0.25;
        const maxZ = Math.max(minZ, Number(runtime.camZoomMax != null ? runtime.camZoomMax : 4) || 4);
        runtime.camZoom = Math.max(minZ, Math.min(maxZ, isNaN(z) ? 1 : z));
        applyEngineCamera();
      } else if (name === 'Shake de câmera' || nname.includes('shake de camera') || nname.includes('shake de câmera') || nname.includes('tremer camera') || nname.includes('tremer câmera') || nname.includes('balancar camera')) {
        const intensity = Number(param(blk, 'intensidade', param(blk, 'valor', 8, ctx), ctx)) || 8;
        runtime._camShake = { left: Math.max(200, intensity * 40), intensity: intensity, start: performance.now() };
      } else if (name === 'Câmera livre' || name === 'Camera livre' || nname.includes('camera livre') || nname.includes('câmera livre')) {
        runtime._camFree = true;
        runtime.freeCam = true;
        runtime._camFollow = null;
        try { window.__kixFreeCam = true; } catch (_) {}
      } else if (name === 'Definir limites da câmera' || nname.includes('limites da camera') || nname.includes('limites da câmera')) {
        runtime._camBounds = {
          minX: Number(param(blk, 'minX', param(blk, 'x', -9999, ctx), ctx)),
          maxX: Number(param(blk, 'maxX', 9999, ctx)),
          minY: Number(param(blk, 'minY', param(blk, 'y', -9999, ctx), ctx)),
          maxY: Number(param(blk, 'maxY', 9999, ctx))
        };
      } else if (name === 'Quando câmera mover' || nname.includes('quando camera mover') || nname.includes('quando câmera mover')) {
        // hat — fired from applyEngineCamera when position changes
      } else if (name === 'Ativar câmera AR' || nname.includes('ativar camera ar') || nname.includes('ativar câmera ar')) {
        // Web mock: toast only
        try { if (typeof window.toast === 'function') window.toast('AR: disponível em app nativo'); } catch(_){}
        runtime._ar = true;
      } else if (name === 'Detectar plano AR' || nname.includes('detectar plano ar')) {
        deviceSetVar(co, 'ar_plano', runtime._ar ? 1 : 0);
      } else if (name === 'Colocar objeto no AR' || nname.includes('colocar objeto no ar')) {
        // mock: place at touch
        if (runtime.touch) {
          actorPositionSet(co.actor, Number(runtime.touch.x) || 0, Number(runtime.touch.y) || 0, true);
          updateSpriteTransform(co.actor, true);
        } else if (name === 'Definir tolerância de cor' || nname.includes('tolerancia de cor') || nname.includes('tolerância de cor')) {
        const t = Number(param(blk, 'tolerância', param(blk, 'tolerancia', param(blk, 'valor', 40, ctx), ctx), ctx));
        co.actor.data._colorTolerance = isNaN(t) ? 40 : Math.max(0, Math.min(255, t));
      } else if (name === 'Criar emissor de partículas' || nname.includes('criar emissor')) {
        if (!co.actor.data._emitter) {
          co.actor.data._emitter = {
            id: 'em_' + (co.actor.index || 0) + '_' + runtimeNow().toString(36),
            active: true,
            rate: 12,
            color: '#FFD700',
            size: 6,
            speed: 50,
            life: 900,
            _acc: 0
          };
        } else {
          co.actor.data._emitter.active = true;
        }
      } else if (name === 'Definir taxa de emissão' || nname.includes('taxa de emissao') || nname.includes('taxa de emissão')) {
        const rate = Math.max(0, Number(param(blk, 'taxa', param(blk, 'valor', 12, ctx), ctx)) || 12);
        if (!co.actor.data._emitter) {
          co.actor.data._emitter = { id: 'em_' + runtimeNow().toString(36), active: true, rate: rate, color: '#FFD700', size: 6, speed: 50, life: 900, _acc: 0 };
        } else {
          co.actor.data._emitter.rate = rate;
        }
      } else if (name === 'Quando partícula nascer' || nname.includes('quando particula nascer') || nname.includes('quando partícula nascer')) {
        // hat — handled by spawnParticle -> startHatsFor
      } else if (name === 'Definir cor da partícula' || nname.includes('cor da particula') || nname.includes('cor da partícula')) {
        const cor = paramStr(blk, 'cor', paramStr(blk, 'valor', '#FFD700', ctx), ctx);
        if (!co.actor.data._emitter) {
          co.actor.data._emitter = { id: 'em_' + runtimeNow().toString(36), active: false, rate: 12, color: cor, size: 6, speed: 50, life: 900, _acc: 0 };
        } else {
          co.actor.data._emitter.color = cor;
        }
      } else if (name === 'Emitir partículas' || nname.includes('emitir particulas') || nname.includes('emitir partículas')) {
        const count=Math.max(1,Math.min(1000,Number(param(blk,'quantidade',1,ctx))||1));
        if(!co.actor.data._emitter) co.actor.data._emitter={id:'em_'+runtimeNow().toString(36),active:false,rate:12,color:'#FFD700',size:6,speed:50,life:900,_acc:0};
        for(let pi=0;pi<count;pi++) spawnParticle(co.actor.data._emitter,Number(co.actor.data.x)||0,Number(co.actor.data.y)||0);
      } else if (name === 'Parar partículas' || nname.includes('parar particulas') || nname.includes('parar partículas')) {
        if(co.actor.data._emitter) co.actor.data._emitter.active=false;
      } else if (name === 'Definir quantidade de partículas' || nname.includes('definir quantidade de particulas') || nname.includes('definir quantidade de partículas')) {
        const q=Math.max(1,Math.min(1000,Number(param(blk,'quantidade',80,ctx))||80));
        co.actor.data._emitter=co.actor.data._emitter||{id:'em_'+runtimeNow().toString(36),active:true,rate:12,color:'#FFD700',size:6,speed:50,life:900,_acc:0};co.actor.data._emitter.rate=q;
      } else if (name === 'Definir velocidade das partículas' || nname.includes('definir velocidade das particulas') || nname.includes('definir velocidade das partículas')) {
        const v=Math.max(0,Number(param(blk,'velocidade',50,ctx))||50);co.actor.data._emitter=co.actor.data._emitter||{id:'em_'+runtimeNow().toString(36),active:true,rate:12,color:'#FFD700',size:6,speed:50,life:900,_acc:0};co.actor.data._emitter.speed=v;
      } else if (name === 'Definir tamanho das partículas' || nname.includes('definir tamanho das particulas') || nname.includes('definir tamanho das partículas')) {
        const v=Math.max(1,Number(param(blk,'tamanho',6,ctx))||6);co.actor.data._emitter=co.actor.data._emitter||{id:'em_'+runtimeNow().toString(36),active:true,rate:12,color:'#FFD700',size:6,speed:50,life:900,_acc:0};co.actor.data._emitter.size=v;
      } else if (name === 'Definir duração das partículas' || nname.includes('definir duracao das particulas') || nname.includes('definir duração das partículas')) {
        const v=Math.max(.05,Number(param(blk,'segundos',1,ctx))||1);co.actor.data._emitter=co.actor.data._emitter||{id:'em_'+runtimeNow().toString(36),active:true,rate:12,color:'#FFD700',size:6,speed:50,life:900,_acc:0};co.actor.data._emitter.life=v*1000;
      } else if (name === 'Mostrar partículas' || nname.includes('mostrar particulas') || nname.includes('mostrar partículas')) {
        if(co.actor.data._emitter) co.actor.data._emitter.active=true;
      } else if (name === 'Esconder partículas' || nname.includes('esconder particulas') || nname.includes('esconder partículas')) {
        if(co.actor.data._emitter) co.actor.data._emitter.active=false;
      } else if (
        name === 'Mudar aparência' || name === 'Mudar aparência para' ||
        name === 'Mudar para fantasia/costume' || name === 'Definir aparência para nome' ||
        name === 'Definir aparência para número' || name.includes('Mudar para fantasia') ||
        nname.includes('mudar aparencia') || nname.includes('mudar aparência')
      ) {
        const raw = param(blk, 'valor', param(blk, 'nome', param(blk, 'número', param(blk, 'costume', 0, ctx), ctx), ctx), ctx);
        const looks = co.actor.data.looks || [];
        if (typeof raw === 'number' || (typeof raw === 'string' && /^\d+$/.test(String(raw).trim()))) {
          const idx = Math.max(0, Math.min(looks.length - 1, Number(raw)));
          co.actor.data.costume = idx;
          if (looks[idx]) setActorCostume(co.actor, looks[idx]);
        } else {
          const nome = String(raw || '').replace(/['"]/g, '');
          const idx = looks.findIndex(function (L, i) {
            if (typeof L === 'string' && L === nome) return true;
            if (L && L.name && String(L.name).toLowerCase() === nome.toLowerCase()) return true;
            return false;
          });
          if (idx >= 0) {
            co.actor.data.costume = idx;
            setActorCostume(co.actor, looks[idx]);
          } else if (nome && (nome.startsWith('data:') || nome.startsWith('http') || nome.startsWith('blob:'))) {
            setActorCostume(co.actor, nome);
          }
        }
      } else if (name === 'Próxima aparência' || name === 'Próxima fantasia' || nname.includes('proxima aparencia') || nname.includes('próxima aparência') || nname.includes('proxima fantasia')) {
        const looks = co.actor.data.looks || [];
        if (looks.length) {
          co.actor.data.costume = ((co.actor.data.costume || 0) + 1) % looks.length;
          setActorCostume(co.actor, looks[co.actor.data.costume]);
        }
      } else if (name === 'Aparência anterior' || nname.includes('aparencia anterior') || nname.includes('aparência anterior')) {
        const looks = co.actor.data.looks || [];
        if (looks.length) {
          co.actor.data.costume = ((co.actor.data.costume || 0) - 1 + looks.length) % looks.length;
          setActorCostume(co.actor, looks[co.actor.data.costume]);
        }
      } else if (name === 'Mudar opacidade em' || nname.includes('mudar opacidade') || name === 'Mudar transparência em' || nname.includes('mudar transparencia') || nname.includes('mudar transparência')) {
        const dRaw = Number(param(blk, 'valor', 10, ctx));
        const d = Number.isFinite(dRaw) ? dRaw : 10;
        const isTransp = nname.includes('transpar');
        const currentTransp = Number(co.actor.data.transparency != null ? co.actor.data.transparency : 100 - Number(co.actor.data.opacity == null ? 100 : co.actor.data.opacity));
        setActorTransparency(co.actor, isTransp ? currentTransp + d : 100 - (100 - currentTransp + d));
      } else if (name === 'Definir transparência para' || nname.includes('definir transparencia') || nname.includes('definir transparência')) {
        const t = Number(param(blk, 'valor', 0, ctx)) || 0;
        setActorTransparency(co.actor, t);
      } else if (name === 'Enviar para trás' || nname.includes('enviar para tras') || nname.includes('enviar para trás')) {
        moveRuntimeActorByLayers(co.actor, -1);
      } else if (name === 'Espelhar' || name === 'Espelhar horizontal' || name === 'Espelhar vertical' || nname.includes('espelhar')) {
        const eixo = paramStr(blk, 'eixo', 'horizontal', ctx).toLowerCase();
        if (eixo.includes('vert') || name.includes('vertical')) {
          co.actor.data.flipY = !co.actor.data.flipY;
        } else {
          co.actor.data.flipX = !co.actor.data.flipX;
        }
        co.actor._lastKey = null;
        updateSpriteTransform(co.actor, true);
      } else if (name === 'Emissor de partículas' || nname.includes('emissor de particulas') || nname.includes('emissor de partículas') || name === 'Criar emissor de partículas') {
        const ligadoRaw = paramStr(blk, 'ligado', 'sim', ctx).toLowerCase();
        const ligado = !(ligadoRaw === 'nao' || ligadoRaw === 'não' || ligadoRaw === '0' || ligadoRaw === 'off' || ligadoRaw === 'false');
        const taxa = Number(param(blk, 'taxa', 12, ctx)) || 12;
        const cor = paramStr(blk, 'cor', '#FFD700', ctx) || '#FFD700';
        if (!co.actor.data._emitter) {
          co.actor.data._emitter = { id: 'em_' + runtimeNow().toString(36), active: ligado, rate: taxa, color: cor, size: 6, speed: 50, life: 900, _acc: 0 };
        } else {
          co.actor.data._emitter.active = ligado;
          co.actor.data._emitter.rate = taxa;
          co.actor.data._emitter.color = cor;
        }
      } else if (name === 'Tocar pasta' || nname === 'tocar pasta') {
        // Legacy single block: animation is an asynchronous visual state and MUST NOT block the script chain.
        const pasta = paramStr(blk, 'pasta', '', ctx).replace(/['"]|$/g, '').trim();
        const frames = getFolderFrames(co.actor.data, pasta);
        if (frames.length) {
          startLookAnimation(co.actor, pasta, { loop: false, speed: co.actor.data._animSpeed || 8 });
        } else {
          console.warn('[Kix] Tocar pasta: pasta sem frames', pasta);
        }
      } else if (name === 'Tintar sprite' || nname.includes('tintar')) {
        const cor = paramStr(blk, 'cor', '#ff0000', ctx);
        const inten = Math.max(0, Math.min(100, Number(param(blk, 'intensidade', 50, ctx)) || 50));
        co.actor.data._tint = cor;
        co.actor.data._tintStrength = inten / 100;
        if (co.actor.el) {
          co.actor.el.style.filter = 'sepia(1) saturate(' + (1 + inten / 25) + ') hue-rotate(0deg)';
          // approximate tint via drop-shadow + opacity overlay harder; use CSS filter
          try {
            const hex = cor.replace('#', '');
            const r = parseInt(hex.substring(0, 2), 16) || 255;
            const g = parseInt(hex.substring(2, 4), 16) || 0;
            const b = parseInt(hex.substring(4, 6), 16) || 0;
            const deg = Math.atan2(Math.sqrt(3) * (g - b), 2 * r - g - b) * 180 / Math.PI;
            co.actor.el.style.filter = 'sepia(' + (inten / 100) + ') saturate(3) hue-rotate(' + (deg) + 'deg)';
            co.actor.data._tintFilter = co.actor.el.style.filter;
          } catch (_) {}
        }
      } else if (name === 'Flash de hit' || nname.includes('flash de hit')) {
        const cor = paramStr(blk, 'cor', '#ffffff', ctx);
        const frames = Math.max(1, Math.floor(Number(param(blk, 'frames', 3, ctx)) || 3));
        if (co.actor.el) {
          const prev = co.actor.el.style.filter || '';
          co.actor.el.style.filter = (prev ? prev + ' ' : '') + 'brightness(2.5) saturate(0)';
          const el = co.actor.el;
          kixSetTimeout(function () {
            try { el.style.filter = co.actor.data._tintFilter || prev || ''; } catch (_) {}
          }, frames * 32);
        }
      } else if (name === 'Sombra' || nname === 'sombra') {
        const cor = paramStr(blk, 'cor', 'rgba(0,0,0,0.45)', ctx);
        const ox = Number(param(blk, 'offsetX', 4, ctx)) || 0;
        const oy = Number(param(blk, 'offsetY', 6, ctx)) || 0;
        const blur = Number(param(blk, 'blur', 6, ctx)) || 0;
        if (co.actor.el) {
          co.actor.el.style.filter = (co.actor.data._tintFilter ? co.actor.data._tintFilter + ' ' : '') +
            'drop-shadow(' + ox + 'px ' + oy + 'px ' + blur + 'px ' + cor + ')';
        }
      } else if (name === 'Rastro de movimento' || nname.includes('rastro')) {
        const ligado = paramStr(blk, 'ligado', 'sim', ctx).toLowerCase();
        const on = !(ligado === 'nao' || ligado === 'não' || ligado === '0' || ligado === 'off');
        const op = Math.max(0.05, Math.min(1, (Number(param(blk, 'opacidade', 40, ctx)) || 40) / 100));
        co.actor.data._trail = on ? { opacity: op, last: [] } : null;
      } else if (name === 'Modo de mistura' || nname.includes('modo de mistura') || nname.includes('blend')) {
        const modo = paramStr(blk, 'modo', 'normal', ctx).toLowerCase().replace(/['"]/g, '');
        const map = {
          normal: 'normal', multiply: 'multiply', screen: 'screen', add: 'plus-lighter',
          overlay: 'overlay', darken: 'darken', lighten: 'lighten', difference: 'difference'
        };
        const bm = map[modo] || modo || 'normal';
        if (co.actor.el) co.actor.el.style.mixBlendMode = bm;
        co.actor.data.blendMode = bm;
      } else if (name === 'Definir opacidade' || nname.includes('definir opacidade')) {
        const v = Math.max(0, Math.min(100, Number(param(blk, 'valor', 100, ctx)) || 100));
        co.actor.data.opacity = v;
        if (co.actor.el) co.actor.el.style.opacity = String(v / 100);
      } else if (name === 'Trazer para frente' || nname.includes('trazer para frente')) {
        bringRuntimeActorToFront(co.actor);
      } else if (name === 'Piscar' || nname === 'piscar') {
        const vezes = Math.max(1, Math.floor(Number(param(blk, 'vezes', 3, ctx)) || 3));
        const sec = Math.max(0.05, Number(param(blk, 'segundos', 0.2, ctx)) || 0.2);
        if (!co._blink) {
          co._blink = { left: vezes * 2, next: now, vis: true };
        }
        if (now < co._blink.next) return;
        co._blink.vis = !co._blink.vis;
        co.actor.data.visible = co._blink.vis;
        updateSpriteTransform(co.actor, true);
        co._blink.left--;
        if (co._blink.left <= 0) {
          co.actor.data.visible = true;
          updateSpriteTransform(co.actor, true);
          co._blink = null;
          co.ip = blk.next;
          return;
        }
        co._blink.next = now + sec * 1000;
        return;
      } else if (name === 'Aparecer gradualmente' || nname.includes('aparecer gradualmente')) {
        const sec = Math.max(0.05, Number(param(blk, 'segundos', 0.5, ctx)) || 0.5);
        if (!co._fadeIn) {
          co._fadeIn = { start: now, dur: sec * 1000 };
          co.actor.data.visible = true;
          if (co.actor.el) co.actor.el.style.opacity = '0';
        }
        const t = Math.min(1, (now - co._fadeIn.start) / co._fadeIn.dur);
        if (co.actor.el) co.actor.el.style.opacity = String(t);
        co.actor.data.opacity = t * 100;
        if (t < 1) { co.waitUntil = now + 16; return; }
        co._fadeIn = null;
        co.ip = blk.next;
        return;
      } else if (name === 'Desaparecer gradualmente' || nname.includes('desaparecer gradualmente')) {
        const sec = Math.max(0.05, Number(param(blk, 'segundos', 0.5, ctx)) || 0.5);
        if (!co._fadeOut) {
          co._fadeOut = { start: now, dur: sec * 1000 };
        }
        const t = Math.min(1, (now - co._fadeOut.start) / co._fadeOut.dur);
        if (co.actor.el) co.actor.el.style.opacity = String(1 - t);
        co.actor.data.opacity = (1 - t) * 100;
        if (t < 1) { co.waitUntil = now + 16; return; }
        co.actor.data.visible = false;
        updateSpriteTransform(co.actor, true);
        co._fadeOut = null;
        co.ip = blk.next;
        return;
      }

      // ---- LOOKS SAFETY / COMPLETENESS ----
      else if (name === 'Trocar cor' || nname.includes('trocar cor')) {
        const from = paramStr(blk, 'de', '#ffffff', ctx);
        const to = paramStr(blk, 'para', '#000000', ctx);
        const tol = Number(param(blk, 'tolerância', param(blk, 'tolerancia', 40, ctx), ctx)) || 40;
        swapSpriteColor(co.actor, from, to, Math.max(0, Math.min(255, tol)));
      } else if (name === 'Definir cor' && !nname.includes('partícula')) {
        const from = paramStr(blk, 'de', '#ffffff', ctx);
        const to = paramStr(blk, 'para', '#000000', ctx);
        const tol = Number(param(blk, 'tolerância', param(blk, 'tolerancia', 40, ctx), ctx)) || 40;
        swapSpriteColor(co.actor, from, to, Math.max(0, Math.min(255, tol)));
      } else if (name === 'Restaurar cor original' || nname.includes('restaurar cor')) {
        co.actor.data._colorSwaps = []; co.actor.data._colorSwap = null; co.actor.data._swapCache = {};
        const base = resolveActorImage(co.actor.data) || co.actor.data._origImage || co.actor.data._lastGoodImage || co.actor.data.looks?.[co.actor.data.costume || 0];
        if (base) setActorCostume(co.actor, base);
      } else if (name === 'Limpar efeitos' || name === 'Limpar efeitos gráficos' || nname === 'limpar efeitos') {
        co.actor.data.effects = {};
        co.actor.data._tintFilter = '';
        if (co.actor.el) { co.actor.el.style.filter = ''; co.actor.el.style.mixBlendMode = ''; }
      } else if (name === 'Definir brilho' || nname.includes('definir brilho')) {
        const v = Math.max(0, Number(param(blk, 'valor', 100, ctx)) || 100);
        if (co.actor.el) co.actor.el.style.filter = 'brightness(' + (v / 100) + ')';
        co.actor.data.brightness = v;
      } else if (name === 'Outline' || nname.includes('outline')) {
        const cor = paramStr(blk, 'cor', '#ffffff', ctx);
        const esp = Math.max(0, Number(param(blk, 'espessura', 2, ctx)) || 2);
        if (co.actor.el) co.actor.el.style.filter = 'drop-shadow(0 0 ' + esp + 'px ' + cor + ')';
      }

      // ---- DATA ----
      else if (name === 'Definir variável para') {
        const vn = String(param(blk, 'variável', 'novo', ctx));
        const val = param(blk, 'valor', 0, ctx);
        if (!runtimeDataSet(vn, val, co.actor.data)) runtime.globals[vn] = val;
        co.actor.data._vars = co.actor.data._vars || {};
        co.actor.data._vars[vn] = val;
      } else if (name === 'Mudar variável em' || name.includes('Mudar variável') || name.includes('Alterar variável')) {
        const vn = String(param(blk, 'variável', 'novo', ctx));
        const val = Number(param(blk, 'valor', 1, ctx)) || 1;
        const next = (Number(runtimeDataGet(vn, co.actor.data, runtime.globals[vn])) || 0) + val;
        if (!runtimeDataSet(vn, next, co.actor.data)) runtime.globals[vn] = next;
        co.actor.data._vars[vn] = next;
      }

      // ---- SOUND ----
      else if (false) { /* replaced by SOUND+ FULL */ }

      // ---- EVENTS: Enviar mensagem ----
      else if (name.startsWith('Enviar mensagem')) {
        const msg = String(param(blk, 'mensagem', '', ctx));
        runtime.messages.push(msg);
        // wake receivers
        runtime.actors.forEach(ra2 => {
          const tree = migrateScripts(ra2.data.scripts || []);
          Object.values(tree.blocks).forEach(b => {
            if (b.name === 'Quando receber mensagem') {
              runtime.coroutines.push({
                actor: ra2, tree, ip: b.next, waitUntil: 0, loopStack: [], dead: false
              });
            }
          });
        });
      }

      
      // ---- PHONE / DEVICE ----
      else if (name === 'Forçar orientação da tela' || name.includes('orientação da tela') || name.includes('orientacao da tela')) {
        const orient = String(param(blk, 'orientação', param(blk, 'orientacao', 'vertical', ctx), ctx)).toLowerCase();
        try {
          const type = (orient.includes('horiz') || orient.includes('landscape') || orient.includes('horizontal')) ? 'landscape' : 'portrait';
          // This is an explicit stage-presentation control. It never changes the
          // project's logical actor coordinates; normal Play orientation comes from Android.
          setStagePresentationOrientation(type);
          document.documentElement.dataset.orient = type;
        } catch (_) {}
      } else if (name === 'Vibrar' || name.startsWith('Vibrar') || name === 'Vibrar por X segundos' || (typeof nname === 'string' && nname.includes('vibrar'))) {
        try {
          startDeviceSensors();
          let ms = Number(param(blk, 'ms', undefined, ctx));
          if (ms == null || isNaN(ms)) {
            const sec = Number(param(blk, 'segundos', 0.2, ctx));
            ms = (isNaN(sec) ? 0.2 : sec) * 1000;
          }
          if (navigator.vibrate) navigator.vibrate(Math.max(10, Math.min(5000, ms || 200)));
        } catch (_) {}
      } else if (name === 'Pausar todos os sons' || nname.includes('pausar todos os sons')) {
        try {
          (runtime.sounds || []).forEach(function (s) { try { if (s && s.pause) s.pause(); } catch(_){} });
          runtime._soundsPaused = true;
        } catch (_) {}
      } else if (name === 'Retomar todos os sons' || nname.includes('retomar todos os sons')) {
        try {
          (runtime.sounds || []).forEach(function (s) { try { if (s && s.play) s.play(); } catch(_){} });
          runtime._soundsPaused = false;
        } catch (_) {}
      } else if (name === 'Tocar som com volume' || nname.includes('tocar som com volume')) {
        const som = paramStr(blk, 'som', '', ctx);
        const vol = Math.max(0, Math.min(1, (Number(param(blk, 'volume', 100, ctx)) || 100) / 100));
        try {
          const entry = resolveSound(co.actor.data, som);
          const a = playSoundEntry(entry, { loop: runtime.soundLoop });
          if (a) a.volume = vol;
        } catch (_) {}
      } else if (name === 'Fade out em' || nname.includes('fade out')) {
        const sec = Math.max(0.05, Number(param(blk, 'segundos', 1, ctx)) || 1);
        const sounds = runtime.sounds || [];
        if (!co._fadeAudio) {
          co._fadeAudio = { start: now, dur: sec * 1000, mode: 'out', starts: sounds.map(function(s){ return s ? s.volume : 1; }) };
        }
        const t = Math.min(1, (now - co._fadeAudio.start) / co._fadeAudio.dur);
        sounds.forEach(function (s, i) {
          if (s) try { s.volume = Math.max(0, (co._fadeAudio.starts[i] != null ? co._fadeAudio.starts[i] : 1) * (1 - t)); } catch(_){}
        });
        if (t < 1) { co.waitUntil = now + 16; return; }
        sounds.forEach(function (s) { try { if (s && s.pause) s.pause(); } catch(_){} });
        co._fadeAudio = null;
        co.ip = blk.next;
        return;
      } else if (name === 'Fade in em' || nname.includes('fade in')) {
        const sec = Math.max(0.05, Number(param(blk, 'segundos', 1, ctx)) || 1);
        const sounds = runtime.sounds || [];
        if (!co._fadeAudioIn) {
          co._fadeAudioIn = { start: now, dur: sec * 1000 };
          sounds.forEach(function (s) { try { if (s) { s.volume = 0; s.play && s.play(); } } catch(_){} });
        }
        const t = Math.min(1, (now - co._fadeAudioIn.start) / co._fadeAudioIn.dur);
        sounds.forEach(function (s) { if (s) try { s.volume = t; } catch(_){} });
        if (t < 1) { co.waitUntil = now + 16; return; }
        co._fadeAudioIn = null;
        co.ip = blk.next;
        return;
      } else if (name === 'Mostrar toast' || name.startsWith('Mostrar toast') || (typeof nname === 'string' && nname.includes('mostrar toast'))) {
        const msg = String(param(blk, 'mensagem', param(blk, 'texto', 'Toast', ctx), ctx));
        try {
          if (typeof window.toast === 'function') window.toast(msg);
          else if (typeof toast === 'function') toast(msg);
          else console.log('[toast]', msg);
        } catch (_) { console.log('[toast]', msg); }
      } else if (name === 'Definir brilho da tela' || (typeof nname === 'string' && nname.includes('brilho'))) {
        // Web cannot set system brightness — simulate with overlay
        const v = Math.max(0, Math.min(100, Number(param(blk, 'valor', 100, ctx)) || 100));
        try {
          let ov = document.getElementById('kix-brightness-overlay');
          if (!ov) {
            ov = document.createElement('div');
            ov.id = 'kix-brightness-overlay';
            ov.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:99998;transition:opacity 0.2s;';
            document.body.appendChild(ov);
          }
          // value 100 = no darken, 0 = almost black
          ov.style.background = 'rgba(0,0,0,' + (1 - v / 100) * 0.85 + ')';
        } catch (_) {}
      } else if (name === 'Tirar foto' || (typeof nname === 'string' && nname.includes('tirar foto'))) {
        try {
          startDeviceSensors();
          const input = document.createElement('input');
          input.type = 'file';
          input.accept = 'image/*';
          input.capture = 'environment';
          input.style.display = 'none';
          document.body.appendChild(input);
          input.onchange = function () {
            const f = input.files && input.files[0];
            if (!f) { try { document.body.removeChild(input); } catch(_){} return; }
            const r = new FileReader();
            r.onload = function () {
              deviceSetVar(co, 'foto', r.result);
              deviceSetVar(co, 'ultima_foto', r.result);
              try {
                if (co.actor && co.actor.data) {
                  if (!Array.isArray(co.actor.data.looks)) co.actor.data.looks = [];
                  co.actor.data.looks.push(r.result);
                  setActorCostume(co.actor, r.result);
                }
              } catch (_) {}
              try { document.body.removeChild(input); } catch(_){}
            };
            r.readAsDataURL(f);
          };
          input.click();
        } catch (e) { console.warn('Tirar foto', e); }
      } else if (name === 'Ler valor do acelerômetro' || (typeof nname === 'string' && nname.includes('aceler'))) {
        startDeviceSensors();
        const d = ensureDeviceState();
        deviceSetVar(co, 'acel_x', d.accel.x);
        deviceSetVar(co, 'acel_y', d.accel.y);
        deviceSetVar(co, 'acel_z', d.accel.z);
        deviceSetVar(co, 'acelerometro', d.accel.x);
      } else if (name === 'Ler valor do giroscópio' || (typeof nname === 'string' && nname.includes('giroscop'))) {
        startDeviceSensors();
        const d = ensureDeviceState();
        deviceSetVar(co, 'giro_alpha', d.gyro.alpha);
        deviceSetVar(co, 'giro_beta', d.gyro.beta);
        deviceSetVar(co, 'giro_gamma', d.gyro.gamma);
        deviceSetVar(co, 'giroscopio', d.gyro.beta);
      } else if (name === 'Ler valor da bússola' || (typeof nname === 'string' && nname.includes('bussola')) || (typeof nname === 'string' && nname.includes('bússola'))) {
        startDeviceSensors();
        const d = ensureDeviceState();
        deviceSetVar(co, 'bussola', d.compass);
        deviceSetVar(co, 'bússola', d.compass);
      } else if (name === 'Ler GPS' || (typeof nname === 'string' && nname.includes('ler gps'))) {
        startDeviceSensors();
        const d = ensureDeviceState();
        deviceSetVar(co, 'gps_lat', d.gps.lat);
        deviceSetVar(co, 'gps_lng', d.gps.lng);
        deviceSetVar(co, 'gps_precisao', d.gps.accuracy);
        // also one-shot
        try {
          if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function (pos) {
              d.gps.lat = pos.coords.latitude;
              d.gps.lng = pos.coords.longitude;
              d.gps.accuracy = pos.coords.accuracy;
              deviceSetVar(co, 'gps_lat', d.gps.lat);
              deviceSetVar(co, 'gps_lng', d.gps.lng);
            }, function () {});
          }
        } catch (_) {}
      } else if (name === 'Ler sensor de luz' || (typeof nname === 'string' && nname.includes('sensor de luz'))) {
        startDeviceSensors();
        const d = ensureDeviceState();
        deviceSetVar(co, 'luz', d.light);
        try {
          if (window.AmbientLightSensor) {
            const s = new AmbientLightSensor();
            s.onreading = function () { d.light = s.illuminance; deviceSetVar(co, 'luz', d.light); };
            s.start();
          }
        } catch (_) {}
      } else if (name === 'Ler sensor de proximidade' || (typeof nname === 'string' && nname.includes('proximidade'))) {
        startDeviceSensors();
        const d = ensureDeviceState();
        deviceSetVar(co, 'proximidade', d.proximity ? 1 : 0);
      } else if (name === 'Enviar notificação' || (typeof nname === 'string' && nname.includes('notificacao')) || (typeof nname === 'string' && nname.includes('notificação'))) {
        const texto = paramStr(blk, 'texto', paramStr(blk, 'mensagem', 'Kix', ctx), ctx);
        try {
          if (typeof Notification !== 'undefined') {
            if (Notification.permission === 'granted') {
              new Notification('Kix', { body: texto });
            } else if (Notification.permission !== 'denied') {
              Notification.requestPermission().then(function (p) {
                if (p === 'granted') new Notification('Kix', { body: texto });
              });
            }
          }
          if (typeof window.toast === 'function') window.toast(texto);
        } catch (_) {
          try { if (typeof window.toast === 'function') window.toast(texto); } catch(__){}
        }
      } else if (name === 'Abrir outro aplicativo' || (typeof nname === 'string' && nname.includes('abrir outro'))) {
        const app = paramStr(blk, 'app', paramStr(blk, 'url', '', ctx), ctx).replace(/['"]/g, '');
        try {
          if (!app) return;
          let url = app;
          if (/^https?:\/\//i.test(app) || app.startsWith('mailto:') || app.startsWith('tel:')) url = app;
          else if (app.includes('.')) url = 'https://' + app;
          else url = app; // custom scheme e.g. whatsapp://
          window.open(url, '_blank');
        } catch (e) { console.warn('Abrir app', e); }
      } else if (name === 'Ler QR code' || (typeof nname === 'string' && nname.includes('qr'))) {
        // BarcodeDetector if available; else prompt mock
        try {
          if (window.BarcodeDetector) {
            // needs camera frame — store placeholder request
            deviceSetVar(co, 'qr_code', '');
            if (typeof window.toast === 'function') window.toast('Aponte a câmera ao QR (suporte limitado na web)');
          } else {
            if (typeof window.openActionScreen === 'function') {
              window.openActionScreen({title:'Ler QR code',message:'Cole o valor do QR code para continuar.',value:'',input:true,confirmText:'Usar valor',onConfirm:function(v){deviceSetVar(co,'qr_code',v||'');}});
            }
          }
        } catch (_) {
          deviceSetVar(co, 'qr_code', '');
        }
      } else if (name === 'Ler nível de bateria' || (typeof nname === 'string' && nname.includes('bateria'))) {
        startDeviceSensors();
        const d = ensureDeviceState();
        const pct = Math.round((d.battery || 0) * 100);
        deviceSetVar(co, 'bateria', pct);
        try {
          if (navigator.getBattery) {
            navigator.getBattery().then(function (b) {
              d.battery = b.level;
              deviceSetVar(co, 'bateria', Math.round(b.level * 100));
            }).catch(function () {});
          }
        } catch (_) {}
      } else if (name === 'Manter tela ligada' || (typeof nname === 'string' && nname.includes('manter tela'))) {
        try {
          const d = ensureDeviceState();
          if (navigator.wakeLock && navigator.wakeLock.request) {
            navigator.wakeLock.request('screen').then(function (lock) {
              d.wakeLock = lock;
            }).catch(function () {});
          }
        } catch (_) {}
      } else if (name === 'Copiar texto' || (typeof nname === 'string' && nname.includes('copiar texto'))) {
        const texto = paramStr(blk, 'texto', '', ctx);
        try {
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(texto);
          }
          if (typeof window.toast === 'function') window.toast('Copiado');
        } catch (_) {}
      } else if (name === 'Detectar se está online' || nname.includes('esta online') || nname.includes('está online')) {
        const on = typeof navigator !== 'undefined' ? !!navigator.onLine : true;
        deviceSetVar(co, 'online', on ? 1 : 0);
      } else if (name === 'Obter data/hora' || nname.includes('obter data')) {
        const fmt = paramStr(blk, 'formato', 'iso', ctx).toLowerCase();
        const d = runtimeDate();
        let out = d.toISOString();
        if (fmt.includes('hora')) out = d.toLocaleTimeString();
        else if (fmt.includes('data') && !fmt.includes('hora')) out = d.toLocaleDateString();
        else if (fmt.includes('local')) out = d.toLocaleString();
        deviceSetVar(co, 'data_hora', out);
        deviceSetVar(co, 'timestamp', d.getTime());
      } else if (name === 'Compartilhar texto' || nname.includes('compartilhar texto')) {
        const texto = paramStr(blk, 'texto', '', ctx);
        try {
          if (navigator.share) navigator.share({ text: texto }).catch(function(){});
          else if (navigator.clipboard) { navigator.clipboard.writeText(texto); if (window.toast) window.toast('Copiado para compartilhar'); }
        } catch (_) {}
      } else if (name === 'Gerar número aleatório' || nname.includes('numero aleatorio') || nname.includes('número aleatório')) {
        const min = Number(param(blk, 'min', 1, ctx));
        const max = Number(param(blk, 'max', 10, ctx));
        const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'aleatorio', ctx), ctx).replace(/['"]/g, '');
        const lo = isNaN(min) ? 1 : min;
        const hi = isNaN(max) ? 10 : max;
        const val = Math.floor(runtimeRandom() * (hi - lo + 1)) + lo;
        deviceSetVar(co, vn || 'aleatorio', val);
      } else if (name === 'Pedir texto ao usuário' || nname.includes('pedir texto')) {
        const pergunta = paramStr(blk, 'pergunta', 'Digite:', ctx);
        const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'resposta', ctx), ctx).replace(/["']/g, '') || 'resposta';
        try {
          const initial = String((ctx.vars && ctx.vars[vn] !== undefined ? ctx.vars[vn] : '') ?? '');
          if (typeof window.openRuntimeInputOverlay === 'function') {
            window.openRuntimeInputOverlay({title:pergunta || 'Entrada de texto',value:initial,multiline:false,confirmText:'Enviar',onInput:function(v){deviceSetVar(co,vn,v);},onConfirm:function(v){deviceSetVar(co,vn,v);},onCancel:function(v){deviceSetVar(co,vn,v);}});
          }
        } catch (_) {}
      } else if (name === 'Pedir permissão de sensores' || (typeof nname === 'string' && nname.includes('permissao de sensores')) || (typeof nname === 'string' && nname.includes('permissão de sensores'))) {
        try {
          startDeviceSensors();
          if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
            DeviceOrientationEvent.requestPermission().catch(function () {});
          }
          if (typeof DeviceMotionEvent !== 'undefined' && typeof DeviceMotionEvent.requestPermission === 'function') {
            DeviceMotionEvent.requestPermission().catch(function () {});
          }
          if (typeof Notification !== 'undefined' && Notification.requestPermission) {
            Notification.requestPermission().catch(function () {});
          }
          if (typeof window.toast === 'function') window.toast('Permissões solicitadas');
        } catch (_) {}
      }

      // ---- MORE MOTION ----
      else if (name === 'Apontar para' || name.startsWith('Apontar para [')) {
        // point toward 0,0 as simple default
        const tx = Number(param(blk, 'x', 0, ctx)) || 0;
        const ty = Number(param(blk, 'y', 0, ctx)) || 0;
        const dx = tx - co.actor.data.x;
        const dy = ty - co.actor.data.y;
        co.actor.data.direction = Math.atan2(dy, dx) * 180 / Math.PI;
        updateSpriteTransform(co.actor);
      } else if (name.includes('Deslizar em') || name.startsWith('Deslizar')) {
        const rawSec = Number(param(blk, 'segundos', 1, ctx));
        const sec = Number.isFinite(rawSec) ? Math.max(0.05, rawSec) : 1;
        const rawX = Number(param(blk, 'x', 0, ctx));
        const rawY = Number(param(blk, 'y', 0, ctx));
        const tx = Number.isFinite(rawX) ? rawX : 0;
        const ty = Number.isFinite(rawY) ? rawY : 0;
        actorPositionSet(co.actor, tx, ty, true);
        co.waitUntil = now + sec * 1000;
        co.ip = blk.next;
        return;
      } else if (name === 'Ir para a frente' || name.includes('Ir para a frente')) {
        moveRuntimeActorByLayers(co.actor, 1);
      } else if (name.includes('Retornar') && name.includes('camadas')) {
        moveRuntimeActorByLayers(co.actor, -(Number(param(blk, 'camadas', 1, ctx)) || 1));
      }

      // ---- MORE LOOKS ----
      else if (name === 'Mudar para fantasia' || name.includes('fantasia') || name.includes('aparência') && name.includes('Mudar')) {
        const looks = co.actor.data.looks || [];
        let idx = Number(param(blk, 'índice', param(blk, 'fantasia', 1, ctx), ctx)) - 1;
        if (isNaN(idx)) idx = 0;
        if (looks.length) {
          co.actor.data.costume = ((idx % looks.length) + looks.length) % looks.length;
          const src = looks[co.actor.data.costume];
          if (src) setActorCostume(co.actor, src);
        }
      } else if (name === 'Definir cor' || (name.includes('Definir cor') && name.includes('tolerância'))) {
        // Per-block tolerance — NEVER touches global or other blocks' hex values
        const de = String(param(blk, 'de', param(blk, 'origem', '#000000', ctx), ctx));
        const para = String(param(blk, 'para', param(blk, 'destino', '#FFFFFF', ctx), ctx));
        const thr = Number(param(blk, 'tolerância', param(blk, 'tolerancia', param(blk, 'valor', 10, ctx), ctx), ctx));
        if (!co.actor.data._origImage) {
          const img = co.actor.el.querySelector('img');
          co.actor.data._origImage = resolveActorImage(co.actor.data) || null;
        }
        // Use copy of original base so we don't stack permanent pixel edits incorrectly
        const base = resolveActorImage(co.actor.data) || co.actor.data._origImage || null;
        if (base) setActorCostume(co.actor, base);
        co.actor.data._colorSwap = { de: de, para: para, tolerancia: isNaN(thr) ? 10 : thr };
        swapSpriteColor(co.actor, de, para, isNaN(thr) ? 10 : thr);
      } else if (name === 'Restaurar cor original' || name.includes('Restaurar cor')) {
        co.actor.data._colorSwap = null; co.actor.data._colorSwaps = []; co.actor.data._swapCache = {};
        const base = resolveActorImage(co.actor.data) || co.actor.data._origImage || co.actor.data._lastGoodImage || null;
        if (base) {
          const img = co.actor.el.querySelector('img');
          setActorImageStable(co.actor, base);
        }
      } else if (name === 'Trocar cor' || (name.includes('Trocar cor') && name.includes('para'))) {
        const de = String(param(blk, 'de', '#000000', ctx));
        const para = String(param(blk, 'para', '#FFFFFF', ctx));
        // Optional per-block tolerância if present; default 40 local only
        const thrLocal = (blk.values && (blk.values.tolerância != null || blk.values.tolerancia != null))
          ? Number(blk.values.tolerância != null ? blk.values.tolerância : blk.values.tolerancia)
          : 40;
        if (!co.actor.data._origImage) {
          const img = co.actor.el.querySelector('img');
          co.actor.data._origImage = resolveActorImage(co.actor.data) || null;
        }
        const thr = (thrLocal != null && !isNaN(thrLocal)) ? thrLocal : 80;
        co.actor.data._colorSwap = { de: de, para: para, tolerancia: thr };
        co.actor.data._colorTolerance = thr;
        swapSpriteColor(co.actor, de, para, thr);
        // ensure base image exists
        try {
          const img = co.actor.el && co.actor.el.querySelector('img');
          const base = (img && (img.dataset.rawSrc || img.src)) || co.actor.data.image;
          if (base && (!img || !img.src || img.src.indexOf('data:') < 0)) {
            setActorCostume(co.actor, base);
          }
        } catch (_) {}
      } else if (name === 'Definir transparência para' || name.includes('transparência')) {
        const v = Math.max(0, Math.min(100, Number(param(blk, 'valor', 0, ctx)) || 0));
        setActorTransparency(co.actor, v);
      } else if (name === 'Dizer' || name.startsWith('Dizer ')) {
        const txt = String(param(blk, 'texto', param(blk, 'mensagem', '...', ctx), ctx));
        let bubble = co.actor.el.querySelector('.say-bubble');
        if (!bubble) {
          bubble = document.createElement('div');
          bubble.className = 'say-bubble';
          bubble.style.cssText = 'position:absolute;left:50%;bottom:100%;transform:translateX(-50%);background:#fff;color:#222;padding:4px 8px;border-radius:8px;font-size:11px;white-space:nowrap;margin-bottom:4px;';
          co.actor.el.appendChild(bubble);
        }
        bubble.textContent = txt;
        const sec = Number(param(blk, 'segundos', 2, ctx)) || 2;
        kixSetTimeout(() => { if (bubble && bubble.parentNode) bubble.remove(); }, sec * 1000);
      }

      // ---- PEN ----
      else if (name === 'Descer caneta' || name === 'Caneta para baixo') {
        co.actor.data.penDown = true;
      } else if (name === 'Subir caneta' || name === 'Caneta para cima') {
        co.actor.data.penDown = false;
      } else if (name === 'Definir cor da caneta' || name.includes('cor da caneta')) {
        co.actor.data.penColor = String(param(blk, 'cor', '#fff', ctx));
      } else if (name === 'Limpar') {
        const layer = runtime.stageEl && runtime.stageEl.querySelector('.pen-layer');
        if (layer) layer.innerHTML = '';
      }

      // ---- CONTROL extras ----
      else if (name === 'Aguardar até' || name.startsWith('Aguardar até')) {
        const cond = param(blk, 'condição', param(blk, 'condicao', 0, ctx), ctx);
        if (!cond || cond === '0' || cond === 'false') {
          // stay on this block
          return;
        }
        co.ip = blk.next;
        continue;
      } else if (name === 'Criar clone' || name.includes('Clonar')) {
        // visual clone of sprite
        try {
          const clone = co.actor.el.cloneNode(true);
          clone.style.opacity = '0.85';
          runtime.stageEl.appendChild(clone);
          kixSetTimeout(() => clone.remove(), 5000);
        } catch (_) {}
      }

      // ---- DATA lists ----
      else if (name === 'Adicionar à lista' || name.includes('Adicionar') && name.includes('lista')) {
        const listName = String(param(blk, 'lista', 'lista', ctx));
        const val = param(blk, 'item', param(blk, 'valor', '', ctx), ctx);
        if (!runtime.globals['__list_' + listName]) runtime.globals['__list_' + listName] = [];
        runtime.globals['__list_' + listName].push(val);
      } else if (name === 'Apagar tudo da lista' || name.includes('Apagar') && name.includes('lista')) {
        const listName = String(param(blk, 'lista', 'lista', ctx));
        runtime.globals['__list_' + listName] = [];
      }

      // ---- TIMERS ----
      else if (name === 'Reiniciar cronômetro') {
        runtime._timer0 = now;
      } else if (name === 'Cronômetro' || name === 'Ler cronômetro') {
        // value available via eval if needed
        runtime.globals['cronômetro'] = ((now - (runtime._timer0 || now)) / 1000);
      }

      // ---- LAYERS ----
      else if (name === 'Mostrar camada' || name.includes('Mostrar camada')) {
        const n = String(param(blk, 'nome', '', ctx));
        runtime.actors.forEach(ra => {
          if (ra.data.isLayer && ra.data.name === n) {
            ra.data.visible = true;
            updateSpriteTransform(ra);
        try {
          const t = ra.data && ra.data._text;
          if (t) {
            const el = getOrCreateTextEl(textActorId(ra));
            if (el) {
              if (t.boundVar) {
                const v = runtime.globals[t.boundVar];
                const nextText = (t.boundPrefix || '') + (v == null ? '' : v); if (el.textContent !== String(nextText)) el.textContent = String(nextText);
              }
              if (t.pulse && !runtime.paused) {
                const p = t.pulse;
                const s = p.min + (p.max - p.min) * (0.5 + 0.5 * Math.sin((performance.now() / 1000) * p.speed * Math.PI * 2));
                t.style.scale = s;
              }
              // Animated gradient (moving)
              if (t.gradAnim && !runtime.paused) {
                const g = t.gradAnim;
                const tm = (performance.now() / 1000) * (g.speed || 1);
                const ang = g.baseAngle + tm * 60; // degrees sweep
                // shift color stops for direction
                let pos = (tm * 40) % 200;
                if (g.dir === 'esquerda' || g.dir === 'left') pos = 200 - pos;
                if (g.dir === 'cima' || g.dir === 'up') {
                  t.style.gradient = 'linear-gradient(' + (270 + tm * 30) + 'deg, ' + g.c1 + ' ' + (pos-50) + '%, ' + g.c2 + ' ' + (pos+50) + '%)';
                } else if (g.dir === 'baixo' || g.dir === 'down') {
                  t.style.gradient = 'linear-gradient(' + (90 + tm * 30) + 'deg, ' + g.c1 + ' ' + (pos-50) + '%, ' + g.c2 + ' ' + (pos+50) + '%)';
                } else if (g.dir === 'esquerda' || g.dir === 'left') {
                  t.style.gradient = 'linear-gradient(' + (180) + 'deg, ' + g.c1 + ' ' + (pos-50) + '%, ' + g.c2 + ' ' + (pos+50) + '%)';
                } else {
                  t.style.gradient = 'linear-gradient(90deg, ' + g.c1 + ' ' + (pos-50) + '%, ' + g.c2 + ' ' + (pos+50) + '%)';
                }
              }
              // Text motion animations (shake, bubble, wave, float)
              if (t.textAnim && !runtime.paused) {
                const a = t.textAnim;
                const tm = (performance.now() / 1000) * (a.speed || 1);
                const int = a.intensity || 8;
                let ox = t.style.x || 0, oy = t.style.y || 0;
                let sc = t.style.scale != null ? t.style.scale : 1;
                let rot = t.style.rotation || 0;
                if (a.type === 'shake') {
                  ox += Math.sin(tm * 40) * int;
                  oy += Math.cos(tm * 37) * int * 0.6;
                } else if (a.type === 'bubble' || a.type === 'bubbles') {
                  sc = 1 + Math.sin(tm * 3) * (int / 40);
                  oy += Math.sin(tm * 2) * int * 0.3;
                } else if (a.type === 'wave') {
                  rot = Math.sin(tm * 4) * int;
                  ox += Math.sin(tm * 2) * int * 0.5;
                } else if (a.type === 'float') {
                  oy += Math.sin(tm * 2) * int;
                } else if (a.type === 'bounce') {
                  oy += Math.abs(Math.sin(tm * 5)) * int;
                } else if (a.type === 'pulse') {
                  sc = 1 + Math.sin(tm * 4) * (int / 50);
                } else if (a.type === 'glitch') {
                  ox += (runtimeRandom() - 0.5) * int;
                  oy += (runtimeRandom() - 0.5) * int * 0.5;
                }
                // Apply the animation offset on top of the stored text position.
                // Imported Catrobat text uses logical world coordinates, so both the base
                // position and animation offsets must use the same stage scaling as sprites.
                const el2 = el;
                const baseX = Number(t.style.x != null ? t.style.x : 0) || 0;
                const baseY = Number(t.style.y != null ? t.style.y : 0) || 0;
                const m = projectStageMetrics();
                const world = !!t.style.__worldLogical;
                const pxX = (sw / 2) + (world ? (ox * (Number(m.sx) || 1)) : ox);
                const pxY = (sh / 2) - (world ? (oy * (Number(m.sy) || 1)) : oy);
                el2.style.left = pxX + 'px';
                el2.style.top = pxY + 'px';
                el2.style.transform = 'translate(-50%,-50%) rotate(' + rot + 'deg) scale(' + sc + ')';
              }
              applyTextStyle(el, t.style);
            }
          }
        } catch (_) {}
          }
        });
      } else if (name === 'Esconder camada' || name.includes('Esconder camada')) {
        const n = String(param(blk, 'nome', '', ctx));
        runtime.actors.forEach(ra => {
          if (ra.data.isLayer && ra.data.name === n) {
            ra.data.visible = false;
            updateSpriteTransform(ra);
          }
        });
      }

      // ---- GESTURE / follow already via toque x in Definir X ----

      
      // ---- CONTROL FULL ----
      else if (name === 'Repita até' || name === 'Repita enquanto') {
        const condName = name === 'Repita até' ? true : false;
        // até: stop when condition true; enquanto: continue while true
        const raw = param(blk, 'condição', param(blk, 'condicao', 0, ctx), ctx);
        const truthy = !(raw === 0 || raw === '0' || raw === false || raw === 'false' || raw === '');
        const shouldContinue = name === 'Repita enquanto' ? truthy : !truthy;
        if (shouldContinue) {
          const body = blk.body || [];
          if (body.length) {
            co.loopStack = co.loopStack || [];
            co.loopStack.push({ type: 'until', blockId: blk.id, bodyStart: body[0] });
            co.ip = body[0];
            continue;
          }
          // flat: stay on block (re-check next frame) after running next chain once
          co.ip = blk.next;
          // re-queue this block after
          return;
        }
        co.ip = blk.next;
        continue;
      } else if (name === 'Se ... então ... senão' || name === 'Se [Fórmula] for verdadeira então...' || (name.includes('então') && name.includes('senão'))) {
        const raw = param(blk, 'condição', param(blk, 'condicao', 0, ctx), ctx);
        const truthy = !(raw === 0 || raw === '0' || raw === false || raw === 'false' || raw === '');
        if (truthy) {
          if (blk.body && blk.body[0]) { co.ip = blk.body[0]; continue; }
        } else {
          if (blk.bodyElse && blk.bodyElse[0]) { co.ip = blk.bodyElse[0]; continue; }
        }
        co.ip = blk.next;
        continue;
      } else if (name === 'Parar outros scripts deste objeto') {
        runtime.coroutines.forEach(c => {
          if (c !== co && c.actor === co.actor) c.dead = true;
        });
      } else if (name === 'Sair do loop') {
        // jump out: find next after loop
        if (co.loopStack && co.loopStack.length) {
          co.loopStack.pop();
        }
        // advance to end
        co.ip = blk.next;
        continue;
      } else if (name === 'Continuar próxima iteração') {
        if (co.loopStack && co.loopStack.length) {
          const L = co.loopStack[co.loopStack.length - 1];
          if (L.bodyStart) { co.ip = L.bodyStart; continue; }
        }
        co.ip = blk.next;
        continue;
      } else if (name === 'Iniciar thread') {
        const tname = String(param(blk, 'nome', 'thread', ctx));
        // fork: start a parallel coroutine from next
        if (blk.next) {
          runtime.coroutines.push({
            actor: co.actor, ip: blk.next, blocks: co.blocks,
            waitUntil: 0, dead: false, loopStack: [], threadName: tname
          });
        }
        co.ip = blk.next;
        continue;
      } else if (name === 'Aguardar thread') {
        const tname = String(param(blk, 'nome', 'thread', ctx));
        const alive = runtime.coroutines.some(c => !c.dead && c.threadName === tname);
        if (alive) return; // wait
        co.ip = blk.next;
        continue;
      } else if (name === 'Parar thread') {
        const tname = String(param(blk, 'nome', 'thread', ctx));
        runtime.coroutines.forEach(c => {
          if (c.threadName === tname) c.dead = true;
        });
      } else if (name === 'Apagar este clone') {
        if (co.actor.data.isClone) {
          co.actor.el.remove();
          runtime.actors = runtime.actors.filter(a => a !== co.actor);
          co.dead = true;
          return;
        }
      } else if (name === 'Nota') {
      } else if (name === 'Debounce por X ms') {
        const ms = Number(param(blk, 'ms', 300, ctx)) || 300;
        const key = '_deb_' + (blk.id || name);
        const last = co.actor.data[key] || 0;
        if (now - last < ms) { co.dead = true; return; }
        co.actor.data[key] = now;
      } else if (name === 'Throttle a cada X ms') {
        const ms = Number(param(blk, 'ms', 100, ctx)) || 100;
        const key = '_thr_' + (blk.id || name);
        const last = co.actor.data[key] || 0;
        if (now - last < ms) { return; } // wait without dying
        co.actor.data[key] = now;
      } else if (name === 'Tentar ... se erro') {
        // just continue; errors already caught
      } else if (name === 'Executar após frames') {
        const frames = Number(param(blk, 'quadros', 1, ctx)) || 1;
        if (!co._frameWait) co._frameWait = frames;
        co._frameWait--;
        if (co._frameWait > 0) return;
        co._frameWait = 0;
      } else if (name === 'Com chance % faça') {
        const pct = Number(param(blk, 'porcentagem', 50, ctx)) || 50;
        if (runtimeRandom() * 100 > pct) {
          // skip body - go next
          co.ip = blk.next;
          continue;
        }
      } else if (name === 'Enviar mensagem' || name === 'Enviar mensagem e esperar') {
        const msg = String(param(blk, 'mensagem', '', ctx));
        runtime.messages.push(msg);
        runtime.actors.forEach(ra => {
          try { startHatsFor(ra, 'Quando receber mensagem'); } catch (_) {}
        });
        if (name.includes('esperar')) {
          co.waitUntil = now + 50;
        }
      }

      
      // ---- SOUND+ FULL ----
      else if (name === 'Tocar som' || (name.startsWith('Tocar som') && !name.includes('esperar'))) {
        const key = paramStr(blk, 'som', '', ctx);
        const entry = resolveSound(co.actor.data, key);
        playSoundEntry(entry, { loop: runtime.soundLoop });
      } else if (name === 'Tocar som e esperar terminar' || name.includes('Tocar som e esperar')) {
        const key = paramStr(blk, 'som', '', ctx);
        const entry = resolveSound(co.actor.data, key);
        const audio = playSoundEntry(entry, { loop: false });
        if (audio) {
          co.waitUntil = now + 120000;
          audio.addEventListener('ended', () => { co.waitUntil = 0; }, { once: true });
          return; // wait
        }
      } else if (name === 'Parar todos os sons' || name.includes('Parar todos os sons')) {
        (runtime.sounds || []).forEach(a => { try { a.pause(); a.currentTime = 0; } catch (_) {} });
        runtime.sounds = [];
        try { if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (_) {}
      } else if (name === 'Parar este som') {
        const last = runtime.sounds && runtime.sounds[runtime.sounds.length - 1];
        if (last) { try { last.pause(); last.currentTime = 0; } catch (_) {} }
        runtime.sounds = (runtime.sounds || []).filter(a => a !== last);
      } else if (name === 'Pausar som') {
        (runtime.sounds || []).forEach(a => { try { a.pause(); } catch (_) {} });
      } else if (name === 'Retomar som') {
        (runtime.sounds || []).forEach(a => { try { a.play().catch(()=>{}); } catch (_) {} });
      } else if (name === 'Mudar volume em') {
        const d = Number(param(blk, 'valor', 10, ctx)) || 0;
        runtime.soundVolume = Math.max(0, Math.min(1, (runtime.soundVolume != null ? runtime.soundVolume : 1) + d / 100));
        (runtime.sounds || []).forEach(a => { try { a.volume = runtime.soundVolume; } catch (_) {} });
      } else if (name === 'Definir volume para') {
        const v = Number(param(blk, 'valor', 100, ctx));
        runtime.soundVolume = Math.max(0, Math.min(1, (isNaN(v) ? 100 : v) / 100));
        (runtime.sounds || []).forEach(a => { try { a.volume = runtime.soundVolume; } catch (_) {} });
      } else if (name === 'Mudar tom (pitch) em' || name.includes('Mudar tom')) {
        const d = Number(param(blk, 'valor', 10, ctx)) || 0;
        runtime.soundPitch = Math.max(0.25, Math.min(4, (runtime.soundPitch != null ? runtime.soundPitch : 1) + d / 100));
        (runtime.sounds || []).forEach(a => { try { a.playbackRate = runtime.soundPitch; } catch (_) {} });
      } else if (name === 'Definir tom para' || name.includes('Definir tom')) {
        const v = Number(param(blk, 'valor', 100, ctx));
        runtime.soundPitch = Math.max(0.25, Math.min(4, (isNaN(v) ? 100 : v) / 100));
        (runtime.sounds || []).forEach(a => { try { a.playbackRate = runtime.soundPitch; } catch (_) {} });
      } else if (name === 'Definir loop do som' || name.includes('loop do som')) {
        const sim = String(paramStr(blk, 'sim', paramStr(blk, 'sim/não', 'sim', ctx), ctx)).toLowerCase();
        runtime.soundLoop = (sim === 'sim' || sim === 'true' || sim === '1' || sim === 'yes');
      } else if (name === 'Falar (texto para voz)' || name.startsWith('Falar (texto')) {
        speakText(paramStr(blk, 'texto', '', ctx), false, co, now);
      } else if (name === 'Falar e esperar') {
        speakText(paramStr(blk, 'texto', '', ctx), true, co, now);
        return;
      } else if (name === 'Definir idioma da fala') {
        runtime.speechLang = paramStr(blk, 'idioma', 'pt-BR', ctx) || 'pt-BR';
      } else if (name === 'Crossfade') {
        const key = paramStr(blk, 'som', '', ctx);
        const sec = Math.max(0.05, Number(param(blk, 'segundos', 1, ctx)) || 1);
        const entry = resolveSound(co.actor.data, key);
        const olds = (runtime.sounds || []).slice();
        const neu = playSoundEntry(entry, { loop: runtime.soundLoop });
        if (neu) {
          neu.volume = 0;
          const steps = 20;
          let i = 0;
          const id = kixSetInterval(() => {
            if (!runtime.running) { kixClearTimer(id); return; }
            if (runtime.paused) return;
            i++;
            const t = i / steps;
            try {
              olds.forEach(a => { a.volume = Math.max(0, (runtime.soundVolume || 1) * (1 - t)); });
              neu.volume = (runtime.soundVolume || 1) * t;
            } catch (_) {}
            if (i >= steps) {
              kixClearTimer(id);
              olds.forEach(a => { try { a.pause(); } catch (_) {} });
              runtime.sounds = (runtime.sounds || []).filter(a => a === neu || !olds.includes(a));
              neu.volume = runtime.soundVolume || 1;
            }
          }, (sec * 1000) / steps);
        }
      } else if (name === 'Definir canal') {
        co.actor.data._audioChannel = paramStr(blk, 'canal', 'master', ctx);
      } else if (name === 'Quando som terminar') {
        // hat - handled via ended listener
      }

      // ---- DADOS FULL ----
      else if (name === 'Definir variável para') {
        const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'pontos', ctx), ctx);
        const val = param(blk, 'valor', 0, ctx);
        if (!runtimeDataSet(vn, val, co.actor.data)) runtime.globals[vn] = val;
        if (co.actor.data) {
          if (!co.actor.data.vars) co.actor.data.vars = {};
          co.actor.data.vars[vn] = val;
        }
        if (runtime.varVisible && runtime.varVisible[vn]) showVarOverlay(vn, true);
      } else if (name === 'Mudar variável em' || name.includes('Mudar variável')) {
        const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'pontos', ctx), ctx);
        const d = Number(param(blk, 'valor', 1, ctx)) || 0;
        const cur = Number(runtimeDataGet(vn, co.actor.data, runtime.globals[vn]) || 0);
        const next = cur + d;
        if (!runtimeDataSet(vn, next, co.actor.data)) runtime.globals[vn] = next;
        if (runtime.varVisible && runtime.varVisible[vn]) showVarOverlay(vn, true);
      } else if (name === 'Mostrar variável' || name.includes('Mostrar variável')) {
        const vn = paramStr(blk, 'variável', 'pontos', ctx);
        if (!runtime.varVisible) runtime.varVisible = {};
        runtime.varVisible[vn] = true;
        showVarOverlay(vn, true);
      } else if (name === 'Esconder variável' || name.includes('Esconder variável')) {
        const vn = paramStr(blk, 'variável', 'pontos', ctx);
        if (runtime.varVisible) runtime.varVisible[vn] = false;
        showVarOverlay(vn, false);
      } else if (name === 'Criar lista') {
        ensureList(paramStr(blk, 'lista', 'lista', ctx));
      } else if (name === 'Adicionar à lista' || (name.includes('Adicionar') && name.includes('lista'))) {
        const list = ensureList(paramStr(blk, 'lista', 'lista', ctx));
        list.push(param(blk, 'item', '', ctx));
      } else if (name === 'Apagar de lista' || name.includes('Apagar de lista') || name.includes('Excluir item')) {
        const list = ensureList(paramStr(blk, 'lista', 'lista', ctx));
        let idx = Math.floor(Number(param(blk, 'índice', param(blk, 'indice', 1, ctx), ctx)) || 1) - 1;
        if (idx >= 0 && idx < list.length) list.splice(idx, 1);
      } else if (name === 'Apagar tudo da lista' || name.includes('Apagar tudo') || name.includes('Excluir todos')) {
        const key = paramStr(blk, 'lista', 'lista', ctx);
        runtime.lists[key] = [];
      } else if (name === 'Inserir em lista' || name.includes('Inserir')) {
        const list = ensureList(paramStr(blk, 'lista', 'lista', ctx));
        let idx = Math.floor(Number(param(blk, 'índice', 1, ctx)) || 1) - 1;
        const item = param(blk, 'item', '', ctx);
        if (idx < 0) idx = 0;
        if (idx > list.length) idx = list.length;
        list.splice(idx, 0, item);
      } else if (name === 'Substituir item da lista' || name.includes('Substituir item')) {
        const list = ensureList(paramStr(blk, 'lista', 'lista', ctx));
        let idx = Math.floor(Number(param(blk, 'índice', 1, ctx)) || 1) - 1;
        if (idx >= 0 && idx < list.length) list[idx] = param(blk, 'item', '', ctx);
      } else if (name === 'Item da lista') {
        // reporter-like: store in temp for formula use
        const list = ensureList(paramStr(blk, 'lista', 'lista', ctx));
        let idx = Math.floor(Number(param(blk, 'índice', 1, ctx)) || 1) - 1;
        runtime.globals['__last_item'] = (idx >= 0 && idx < list.length) ? list[idx] : '';
      } else if (name === 'Tamanho da lista') {
        const list = ensureList(paramStr(blk, 'lista', 'lista', ctx));
        runtime.globals['__list_len'] = list.length;
        // also set named size var
        runtime.globals['tamanho_' + paramStr(blk, 'lista', 'lista', ctx)] = list.length;
      } else if (name === 'Lista contém' || name.includes('contém') || name.includes('contem')) {
        const list = ensureList(paramStr(blk, 'lista', 'lista', ctx));
        const item = param(blk, 'item', '', ctx);
        runtime.globals['__list_has'] = list.some(x => String(x) === String(item)) ? 1 : 0;
      } else if (name === 'Mostrar lista') {
        const key = paramStr(blk, 'lista', 'lista', ctx);
        const list = ensureList(key);
        showVarOverlay('lista:' + key, true);
        const el = document.getElementById('kix-var-lista:' + key);
        if (el) el.textContent = key + ' = [' + list.join(', ') + ']';
      } else if (name === 'Esconder lista') {
        const key = paramStr(blk, 'lista', 'lista', ctx);
        showVarOverlay('lista:' + key, false);
      }

      // Color map without changing sprite pixels (code-only registry)
      

      
      // ---- TEXTO FULL (25) ----
      
      else if (name === 'Mostrar texto' || nname === 'mostrar texto') {
        try {
          const content = paramStr(blk, 'texto', 'Ola!', ctx);
          const t = ensureActorTextState(co.actor);
          const vals = blk && blk.values ? blk.values : {};
          const hasWorld = !!(blk?.catrobat?.worldText || blk?.catrobat?.sourceType==='ShowTextBrick' || blk?.catrobat?.sourceType==='ShowTextColorSizeAlignmentBrick' || blk?.catrobat?.sourceType==='ShowTextFontBrick');
          if (hasWorld || vals.x != null || vals.y != null || vals.tamanho != null || vals.fonte != null || vals.cor != null) {
            t.style.__worldLogical = hasWorld;
            if (vals.x != null) t.style.x = Number(param(blk,'x',t.style.x||0,ctx)) || 0;
            if (vals.y != null) t.style.y = Number(param(blk,'y',t.style.y||0,ctx)) || 0;
            if (vals.tamanho != null) { const fs=Number(param(blk,'tamanho',t.style.fontSize||32,ctx)); if(Number.isFinite(fs)&&fs>0)t.style.fontSize=fs; }
            if (vals.cor != null) t.style.color = paramStr(blk,'cor',t.style.color||'#FFFFFF',ctx);
            if (vals.fonte != null) {
              const fontRef=paramStr(blk,'fonte','',ctx);
              if(fontRef) t.style.fontFamily=loadTextFont(fontRef,function(fam){t.style.fontFamily='"'+fam+'", Arial, sans-serif';refreshActorText(co.actor);});
            }
          }
          showActorText(co.actor, content);
        } catch (err) {
          console.error('Mostrar texto', err);
          try { reportEngineError({ actor: co.actor.data && co.actor.data.name, error: err, block: name }); } catch(_){}
        }
      }

      else if (name === 'Definir fonte' || nname === 'definir fonte' || name.startsWith('Definir fonte')) {
        const t = ensureActorTextState(co.actor);
        const fontRef = paramStr(blk, 'fonte', 'Arial', ctx);
        t.style.fontFamily = loadTextFont(fontRef, function (fam) {
          t.style.fontFamily = '"' + fam + '", Arial, sans-serif';
          refreshActorText(co.actor);
        });
        refreshActorText(co.actor);
      } else if (name === 'Definir tamanho da fonte' || nname === 'definir tamanho da fonte' || nname === 'definir tamanho do texto' || name.includes('tamanho da fonte') || name === 'Definir tamanho do texto') {
        const t = ensureActorTextState(co.actor);
        t.style.fontSize = Number(param(blk, 'tamanho', param(blk, 'valor', 50, ctx), ctx)) || 50;
        applyTextStyle(getOrCreateTextEl(textActorId(co.actor)), t.style);
      } else if (name === 'Definir cor do texto' || nname === 'definir cor do texto') {
        const t = ensureActorTextState(co.actor);
        t.style.color = paramStr(blk, 'cor', '#FFFFFF', ctx);
        t.style.gradient = null;
        applyTextStyle(getOrCreateTextEl(textActorId(co.actor)), t.style);
      } else if (nname.includes('negrito') || name.includes('negrito')) {
        const t = ensureActorTextState(co.actor);
        const nb = paramStr(blk, 'negrito', 'não', ctx).toLowerCase();
        const it = paramStr(blk, 'itálico', 'não', ctx).toLowerCase();
        t.style.bold = (nb === 'sim' || nb === 'true' || nb === '1');
        t.style.italic = (it === 'sim' || it === 'true' || it === '1');
        applyTextStyle(getOrCreateTextEl(textActorId(co.actor)), t.style);
      } else if (nname.includes('alinhamento') || nname === 'alinhar texto') {
        const t = ensureActorTextState(co.actor);
        let a = paramStr(blk, 'alinhamento', 'centro', ctx).toLowerCase();
        if (a.includes('esq')) a = 'left';
        else if (a.includes('dir')) a = 'right';
        else a = 'center';
        t.style.align = a;
        applyTextStyle(getOrCreateTextEl(textActorId(co.actor)), t.style);
      } else if (name === 'Definir espaçamento entre linhas') {
        const t = ensureActorTextState(co.actor);
        t.style.lineHeight = Number(param(blk, 'espaçamento', 1.3, ctx)) || 1.3;
        applyTextStyle(getOrCreateTextEl(textActorId(co.actor)), t.style);
      } else if (name === 'Definir contorno (stroke)' || name.includes('contorno')) {
        const t = ensureActorTextState(co.actor);
        t.style.stroke = paramStr(blk, 'cor', '#000000', ctx);
        t.style.strokeWidth = Number(param(blk, 'espessura', 2, ctx)) || 2;
        applyTextStyle(getOrCreateTextEl(textActorId(co.actor)), t.style);
      } else if (name === 'Definir sombra do texto' || name.includes('sombra do texto')) {
        const t = ensureActorTextState(co.actor);
        t.style.shadow = {
          color: paramStr(blk, 'cor', '#000000', ctx),
          x: Number(param(blk, 'deslocamento x', 2, ctx)) || 0,
          y: Number(param(blk, 'deslocamento y', 2, ctx)) || 0,
          blur: Number(param(blk, 'desfoque', 4, ctx)) || 0
        };
        applyTextStyle(getOrCreateTextEl(textActorId(co.actor)), t.style);
      } else if (name === 'Definir glow do texto' || name.includes('glow')) {
        const t = ensureActorTextState(co.actor);
        t.style.glow = {
          color: paramStr(blk, 'cor', '#FFFFFF', ctx),
          intensity: Number(param(blk, 'intensidade', 10, ctx)) || 10
        };
        applyTextStyle(getOrCreateTextEl(textActorId(co.actor)), t.style);
      } else if (name === 'Definir gradiente do texto' || name.includes('gradiente do texto')) {
        const t = ensureActorTextState(co.actor);
        const c1 = paramStr(blk, 'cor início', '#FF0000', ctx);
        const c2 = paramStr(blk, 'cor fim', '#0000FF', ctx);
        const ang = Number(param(blk, 'ângulo', 90, ctx)) || 90;
        t.style.gradient = 'linear-gradient(' + ang + 'deg, ' + c1 + ', ' + c2 + ')';
        applyTextStyle(getOrCreateTextEl(textActorId(co.actor)), t.style);
      } else if (name === 'Efeito de digitação (typewriter)' || name.includes('digitação') || name.includes('typewriter')) {
        const full = paramStr(blk, 'texto', '', ctx);
        const speed = Math.max(1, Number(param(blk, 'velocidade', 20, ctx)) || 20);
        const t = ensureActorTextState(co.actor);
        const el = getOrCreateTextEl(textActorId(co.actor));
        applyTextStyle(el, t.style);
        let i = 0;
        el.textContent = '';
        t.content = full;
        const delay = 1000 / speed;
        const step = () => {
          if (!runtime.running) return;
          i++;
          el.textContent = full.slice(0, i);
          if (i < full.length) {
            co.waitUntil = performance.now() + delay;
          } else {
            co.waitUntil = 0;
          }
        };
        // use wait loop: set content progressively via waitUntil
        co._typewriter = { full, i: 0, delay, el };
        co.waitUntil = now + delay;
        // monkey: use interval
        const iv = kixSetInterval(() => {
          if (!runtime.running || !co._typewriter) { kixClearTimer(iv); return; }
          if (runtime.paused) return;
          co._typewriter.i++;
          el.textContent = full.slice(0, co._typewriter.i);
          if (co._typewriter.i >= full.length) {
            kixClearTimer(iv);
            co._typewriter = null;
            co.waitUntil = 0;
          }
        }, delay);
        return;
      } else if (name === 'Quebra de linha automática') {
        const t = ensureActorTextState(co.actor);
        t.style.maxWidth = Number(param(blk, 'largura máxima', 200, ctx)) || 200;
        applyTextStyle(getOrCreateTextEl(textActorId(co.actor)), t.style);
      } else if (nname.includes('texto multilinha') || nname === 'definir texto' || name === 'Definir texto multilinha' || name === 'Definir texto') {
        try {
          const isMultiline = nname.includes('texto multilinha') || name === 'Definir texto multilinha';
          let content = String(paramStr(blk, 'texto', '', ctx));
          content = content.replace(/\\n/g, '\n').replace(/\r\n?/g, '\n');
          if (!isMultiline) content = content.replace(/\n+/g, ' ').replace(/\s+/g, ' ').trim();
          const t = ensureActorTextState(co.actor);
          t.multiline = isMultiline;
          showActorText(co.actor, content);
          applyTextStyle(getOrCreateTextEl(textActorId(co.actor)), t.style);
        } catch (err) { console.error('Definir texto', err); }
      } else if (name === 'Rotacionar texto') {
        const t = ensureActorTextState(co.actor);
        t.style.rotation = Number(param(blk, 'graus', 0, ctx)) || 0;
        applyTextStyle(getOrCreateTextEl(textActorId(co.actor)), t.style);
      } else if (name === 'Definir opacidade do texto') {
        const t = ensureActorTextState(co.actor);
        t.style.opacity = Number(param(blk, 'opacidade', 100, ctx));
        applyTextStyle(getOrCreateTextEl(textActorId(co.actor)), t.style);
      } else if (name === 'Interpolar texto (fade in/out)' || name.includes('Interpolar texto')) {
        const t = ensureActorTextState(co.actor);
        const de = Number(param(blk, 'de', 0, ctx));
        const para = Number(param(blk, 'para', 100, ctx));
        const dur = Math.max(50, Number(param(blk, 'duração', 500, ctx)) || 500);
        const el = getOrCreateTextEl(textActorId(co.actor));
        const start = performance.now();
        const tick = () => {
          if (!runtime.running) return;
          const p = Math.min(1, (performance.now() - start) / dur);
          t.style.opacity = de + (para - de) * p;
          applyTextStyle(el, t.style);
          if (p < 1) kixRequestAnimationFrame(tick);
        };
        tick();
      } else if (name === 'Definir texto rico (tags)' || name.includes('texto rico')) {
        const t = ensureActorTextState(co.actor);
        let raw = paramStr(blk, 'texto', '', ctx);
        // simple tags: <b>, <i>, <color=#hex>
        raw = raw.replace(/<b>(.*?)<\/b>/gi, '<strong>$1</strong>')
                 .replace(/<i>(.*?)<\/i>/gi, '<em>$1</em>')
                 .replace(/<color=(#[0-9A-Fa-f]{3,8})>(.*?)<\/color>/gi, '<span style="color:$1">$2</span>');
        t.content = raw;
        const el = getOrCreateTextEl(textActorId(co.actor));
        el.innerHTML = raw;
        applyTextStyle(el, t.style);
      } else if (name === 'Medir largura do texto') {
        const el = getOrCreateTextEl(textActorId(co.actor));
        const w = el ? el.offsetWidth : 0;
        runtime.globals['__text_width'] = w;
        runtime.globals['largura_texto'] = w;
      } else if (name === 'Mostrar dado como texto') {
        const t = ensureActorTextState(co.actor);
        t.boundVar = paramStr(blk, 'variável', 'pontos', ctx);
        t.boundPrefix = paramStr(blk, 'prefixo', '', ctx);
        const el = getOrCreateTextEl(textActorId(co.actor));
        const v = runtime.globals[t.boundVar];
        el.textContent = t.boundPrefix + (v == null ? '' : v);
        applyTextStyle(el, t.style);
      } else if (name === 'Pulsar texto') {
        const t = ensureActorTextState(co.actor);
        t.pulse = {
          min: Number(param(blk, 'escala mínima', 0.9, ctx)) || 0.9,
          max: Number(param(blk, 'escala máxima', 1.1, ctx)) || 1.1,
          speed: Number(param(blk, 'velocidade', 1, ctx)) || 1
        };
      } else if (nname.includes('texto estilizado') || name === 'Texto estilizado rápido' || name === 'Texto estilizado rapido') {
        try {
          const content = paramStr(blk, 'texto', 'Kix', ctx);
          const style = {
            fontSize: Number(param(blk, 'tamanho', 50, ctx)) || 50,
            color: paramStr(blk, 'cor', '#FFFFFF', ctx),
            stroke: paramStr(blk, 'contorno', '#000000', ctx),
            strokeWidth: 2
          };
          const sh = paramStr(blk, 'sombra', 'sim', ctx).toLowerCase();
          if (sh === 'sim' || sh === 'true' || sh === '1') {
            style.shadow = { color: 'rgba(0,0,0,0.6)', x: 2, y: 2, blur: 4 };
          }
          showActorText(co.actor, content, style);
        } catch (err) { console.error('Texto estilizado', err); }
      } else if (nname.includes('texto hud') || name === 'Texto HUD rápido') {
        const t = ensureActorTextState(co.actor);
        t.boundVar = paramStr(blk, 'variável', 'pontos', ctx);
        const rotulo = paramStr(blk, 'rótulo', '', ctx);
        t.boundPrefix = rotulo ? (rotulo + ': ') : '';
        t.style.fontSize = 16;
        t.style.color = '#FFFFFF';
        t.style.shadow = { color: 'rgba(0,0,0,0.6)', x: 1, y: 1, blur: 3 };
        const pos = paramStr(blk, 'posição', 'canto superior esquerdo', ctx).toLowerCase();
        const el = getOrCreateTextEl(textActorId(co.actor));
        el.style.background = 'rgba(0,0,0,0.45)';
        el.style.padding = '6px 10px';
        el.style.borderRadius = '8px';
        if (pos.includes('esquerdo') || pos.includes('esquerda')) { t.style.x = -140; t.style.y = 280; }
        else if (pos.includes('direito') || pos.includes('direita')) { t.style.x = 140; t.style.y = 280; }
        else { t.style.x = 0; t.style.y = 280; }
        const v = runtime.globals[t.boundVar];
        el.textContent = t.boundPrefix + (v == null ? '' : v);
        applyTextStyle(el, t.style);
      } else if (nname.includes('titulo de nivel') || nname.includes('título de nível')) {
        const t = ensureActorTextState(co.actor);
        t.content = paramStr(blk, 'texto', 'Fase 1', ctx);
        t.style.fontSize = 40;
        t.style.gradient = 'linear-gradient(90deg, #FFD700, #FF6B00)';
        t.style.glow = { color: '#FFD700', intensity: 12 };
        t.style.color = null;
        const el = getOrCreateTextEl(textActorId(co.actor));
        el.textContent = t.content;
        t.style.scale = 0;
        applyTextStyle(el, t.style);
        const start = performance.now();
        const anim = () => {
          if (!runtime.running) return;
          const p = Math.min(1, (performance.now() - start) / 600);
          // elastic-ish
          const s = p === 1 ? 1 : 1 - Math.pow(2, -10 * p) * Math.cos((p * 10 - 0.75) * ((2 * Math.PI) / 3));
          t.style.scale = Math.max(0, s);
          applyTextStyle(el, t.style);
          if (p < 1) kixRequestAnimationFrame(anim);
        };
        anim();
      } else if (nname.includes('dano flutuante')) {
        const layer = ensureTextLayer();
        if (layer) {
          const el = document.createElement('div');
          el.textContent = paramStr(blk, 'texto', '-10', ctx);
          el.style.cssText = 'position:absolute;color:' + paramStr(blk, 'cor', '#FF4444', ctx) +
            ';font-size:22px;font-weight:700;text-shadow:0 1px 2px #000;pointer-events:none;transition:transform 0.8s ease-out,opacity 0.8s ease-out;';
          const x = Number(param(blk, 'x', 0, ctx)) || 0;
          const y = Number(param(blk, 'y', 0, ctx)) || 0;
          const sw = (runtime.stageEl && runtime.stageEl._stageW) || 360;
          const sh = (runtime.stageEl && runtime.stageEl._stageH) || 640;
          el.style.left = (sw / 2 + x) + 'px';
          el.style.top = (sh / 2 - y) + 'px';
          el.style.transform = 'translate(-50%,-50%)';
          layer.appendChild(el);
          kixRequestAnimationFrame(() => {
            el.style.transform = 'translate(-50%,-120%)';
            el.style.opacity = '0';
          });
          kixSetTimeout(() => { try { el.remove(); } catch (_) {} }, 900);
        }
      } 
      else if (nname.includes('posicao x do texto') || nname.includes('posição x do texto')) {
        const t = ensureActorTextState(co.actor);
        t.style.x = Number(param(blk, 'x', 0, ctx)) || 0;
        const el = getOrCreateTextEl(textActorId(co.actor));
        applyTextStyle(el, t.style);
      } else if (nname.includes('posicao y do texto') || nname.includes('posição y do texto')) {
        const t = ensureActorTextState(co.actor);
        t.style.y = Number(param(blk, 'y', 0, ctx)) || 0;
        const el = getOrCreateTextEl(textActorId(co.actor));
        applyTextStyle(el, t.style);
      } else if (
        name === 'Definir posicao X do texto' || name === 'Definir posição X do texto' ||
        nname.includes('definir posicao x do texto') || nname.includes('definir posição x do texto')
      ) {
        const t = ensureActorTextState(co.actor);
        const v = Number(param(blk, 'x', param(blk, 'valor', param(blk, 'posição', 0, ctx), ctx), ctx));
        if (!isNaN(v)) t.style.x = v;
        t.followActor = false;
        try {
          const el = getOrCreateTextEl(textActorId(co.actor));
          applyTextStyle(el, t.style);
          updateTextTransform(co.actor);
        } catch (_) {}
      } else if (
        name === 'Definir posicao Y do texto' || name === 'Definir posição Y do texto' ||
        nname.includes('definir posicao y do texto') || nname.includes('definir posição y do texto')
      ) {
        const t = ensureActorTextState(co.actor);
        const v = Number(param(blk, 'y', param(blk, 'valor', param(blk, 'posição', 0, ctx), ctx), ctx));
        if (!isNaN(v)) t.style.y = v;
        t.followActor = false;
        try {
          const el = getOrCreateTextEl(textActorId(co.actor));
          applyTextStyle(el, t.style);
          updateTextTransform(co.actor);
        } catch (_) {}
      } else if (name === 'Mudar X do texto em' || nname.includes('mudar x do texto')) {
        const t = ensureActorTextState(co.actor);
        t.style.x = (Number(t.style.x) || 0) + (Number(param(blk, 'valor', param(blk, 'x', 10, ctx), ctx)) || 0);
        t.followActor = false;
        try {
          const el = getOrCreateTextEl(textActorId(co.actor));
          applyTextStyle(el, t.style);
          updateTextTransform(co.actor);
        } catch (_) {}
      } else if (name === 'Mudar Y do texto em' || nname.includes('mudar y do texto')) {
        const t = ensureActorTextState(co.actor);
        t.style.y = (Number(t.style.y) || 0) + (Number(param(blk, 'valor', param(blk, 'y', 10, ctx), ctx)) || 0);
        t.followActor = false;
        try {
          const el = getOrCreateTextEl(textActorId(co.actor));
          applyTextStyle(el, t.style);
          updateTextTransform(co.actor);
        } catch (_) {}
      } else if (nname.includes('gradiente animado')) {
        const t = ensureActorTextState(co.actor);
        t.gradAnim = {
          c1: paramStr(blk, 'cor início', '#FF0000', ctx),
          c2: paramStr(blk, 'cor fim', '#0000FF', ctx),
          dir: paramStr(blk, 'direção', 'direita', ctx).toLowerCase(),
          speed: Number(param(blk, 'velocidade', 1, ctx)) || 1,
          baseAngle: 90
        };
        t.style.gradient = 'linear-gradient(90deg, ' + t.gradAnim.c1 + ', ' + t.gradAnim.c2 + ')';
        applyTextStyle(getOrCreateTextEl(textActorId(co.actor)), t.style);
      } else if (name === 'Parar gradiente animado') {
        const t = ensureActorTextState(co.actor);
        t.gradAnim = null;
      } else if (nname.includes('iniciar animacao de texto') || nname.includes('iniciar animação de texto')) {
        const t = ensureActorTextState(co.actor);
        t.textAnim = {
          type: paramStr(blk, 'tipo', 'shake', ctx).toLowerCase(),
          intensity: Number(param(blk, 'intensidade', 8, ctx)) || 8,
          speed: Number(param(blk, 'velocidade', 1, ctx)) || 1,
          loop: false
        };
      } else if (nname.includes('animacao de texto em loop') || nname.includes('animação de texto em loop')) {
        const t = ensureActorTextState(co.actor);
        t.textAnim = {
          type: paramStr(blk, 'tipo', 'pulse', ctx).toLowerCase(),
          intensity: Number(param(blk, 'intensidade', 8, ctx)) || 8,
          speed: Number(param(blk, 'velocidade', 1, ctx)) || 1,
          loop: true
        };
      } else if (nname.includes('finalizar animacao de texto') || nname.includes('finalizar animação de texto')) {
        const t = ensureActorTextState(co.actor);
        t.textAnim = null;
        t.pulse = null;
        const el = getOrCreateTextEl(textActorId(co.actor));
        if (el && t.style) {
          // reset transform offsets
          applyTextStyle(el, t.style);
          el.style.left = 'calc(50% + ' + (t.style.x || 0) + 'px)';
          el.style.top = 'calc(50% + ' + (-(t.style.y || 0)) + 'px)';
        }
      } else if (nname.includes('aspas coloridas')) {
        const t = ensureActorTextState(co.actor);
        const text = paramStr(blk, 'texto', '', ctx);
        const base = paramStr(blk, 'cor base', '#FFFFFF', ctx);
        const qcol = paramStr(blk, 'cor aspas', '#FF4444', ctx);
        t.content = text;
        t.boundVar = null; t.boundExpr = null;
        t.quoteColor = qcol;
        t.style.color = base;
        t.style.gradient = null; // solid base; quotes use spans
        t._quotedMode = true;
        t._quoteBase = base;
        t._quoteCol = qcol;
        const el = getOrCreateTextEl(textActorId(co.actor));
        applyTextStyle(el, t.style);
        renderQuotedColorText(el, text, base, qcol);
        updateTextTransform(co.actor);
      }

      else if (nname.includes('caixa de dialogo') || nname.includes('caixa de diálogo')) {
        const layer = ensureTextLayer();
        const full = paramStr(blk, 'texto', '', ctx);
        const speed = Math.max(1, Number(param(blk, 'velocidade', 18, ctx)) || 18);
        if (layer) {
          let box = document.getElementById('kix-dialog-box');
          if (!box) {
            box = document.createElement('div');
            box.id = 'kix-dialog-box';
            box.style.cssText = 'position:absolute;left:5%;right:5%;bottom:8%;background:rgba(10,10,20,0.85);border:2px solid #34D399;border-radius:12px;padding:14px 16px;color:#fff;font-size:16px;min-height:64px;pointer-events:none;';
            layer.appendChild(box);
          }
          box.textContent = '';
          let i = 0;
          const delay = 1000 / speed;
          const iv = kixSetInterval(() => {
            if (!runtime.running) { kixClearTimer(iv); return; }
            if (runtime.paused) return;
            i++;
            box.textContent = full.slice(0, i);
            if (i >= full.length) kixClearTimer(iv);
          }, delay);
        }
      }

      // Legacy Looks handlers removed: executeLooksBlock above is the single appearance/animation dispatcher.
} else if (name === 'Carregar tilemap' || nname.includes('carregar tilemap')) {
        const src = paramStr(blk, 'imagem', paramStr(blk, 'src', '', ctx), ctx).replace(/['"]/g, '');
        const tw = Math.max(4, Number(param(blk, 'tileW', param(blk, 'largura', 32, ctx), ctx)) || 32);
        const th = Math.max(4, Number(param(blk, 'tileH', param(blk, 'altura', 32, ctx), ctx)) || 32);
        runtime.tilemap = runtime.tilemap || { src: src, tileW: tw, tileH: th, grid: {} }; runtime.tilemap.src=src; runtime.tilemap.tileW=tw; runtime.tilemap.tileH=th; runtime.tilemap.grid=runtime.tilemap.grid||{};
        try {
          if (src && runtime.stageEl) {
            let layer = runtime.stageEl.querySelector('.kix-tilemap-layer');
            if (!layer) {
              layer = document.createElement('div');
              layer.className = 'kix-tilemap-layer';
              layer.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;z-index:0;pointer-events:none;';
              runtime.stageEl.insertBefore(layer, runtime.stageEl.firstChild);
            }
            layer.style.backgroundImage = src ? ('url(' + src + ')') : '';
            layer.style.backgroundSize = 'auto';
          }
        } catch (_) {}
      } else if (name === 'Definir tile' || nname.includes('definir tile')) {
        if (!runtime.tilemap) runtime.tilemap = { grid: {} };
        if (!runtime.tilemap.grid) runtime.tilemap.grid = {};
        const tx = Math.floor(Number(param(blk, 'x', 0, ctx)) || 0);
        const ty = Math.floor(Number(param(blk, 'y', 0, ctx)) || 0);
        const id = paramStr(blk, 'id', paramStr(blk, 'tile', '0', ctx), ctx);
        runtime.tilemap.grid[tx + ',' + ty] = id;
      } else if (name === 'Ler tile em' || nname.includes('ler tile')) {
        const tx = Math.floor(Number(param(blk, 'x', 0, ctx)) || 0);
        const ty = Math.floor(Number(param(blk, 'y', 0, ctx)) || 0);
        const key = tx + ',' + ty;
        const val = (runtime.tilemap && runtime.tilemap.grid && runtime.tilemap.grid[key]) || 0;
        const vn = paramStr(blk, 'variável', paramStr(blk, 'variavel', 'tile', ctx), ctx).replace(/['"]/g, '');
        runtime.globals[vn] = val;
      } else if (name === 'Quando colidir com tile' || nname.includes('colidir com tile')) {
        // hat-like: check each frame via runtime flag - store condition on actor
        co.actor.data._tileCollisionWatch = paramStr(blk, 'id', paramStr(blk, 'tile', '', ctx), ctx);

      } else if (name === 'Spritesheet' || nname === 'spritesheet' || nname.includes('usar spritesheet')) {
        const srcRaw = paramStr(blk, 'imagem', paramStr(blk, 'costume', paramStr(blk, 'src', '', ctx), ctx), ctx);
        const cols = Math.max(1, Math.floor(Number(param(blk, 'colunas', 4, ctx)) || 4));
        const rows = Math.max(1, Math.floor(Number(param(blk, 'linhas', 1, ctx)) || 1));
        const fps = Math.max(1, Number(param(blk, 'fps', 8, ctx)) || 8);
        const modo = paramStr(blk, 'modo', 'loop', ctx).toLowerCase();
        let src = srcRaw.replace(/['"]/g, '');
        if (!src && co.actor.data.image) src = co.actor.data.image;
        if (!src && co.actor.data.looks && co.actor.data.looks[0]) {
          const L = co.actor.data.looks[0];
          src = typeof L === 'string' ? L : (L.dataUrl || L.src || L.image || '');
        }
        co.actor.data._sheet = {
          src: src, cols: cols, rows: rows, fps: fps,
          frame: 0, acc: 0, playing: true,
          mode: (modo.includes('uma') || modo === 'once') ? 'once' : 'loop',
          useBg: true
        };
        applySpritesheetFrame(co.actor);
      } else if (name === 'Animar spritesheet' || nname.includes('animar spritesheet')) {
        if (co.actor.data._sheet) {
          co.actor.data._sheet.playing = true;
          co.actor.data._sheet.mode = 'loop';
        }
      } else if (name === 'Parar spritesheet' || nname.includes('parar spritesheet')) {
        if (co.actor.data._sheet) co.actor.data._sheet.playing = false;
      } else if (name === 'Definir quadro do spritesheet' || nname.includes('quadro do spritesheet')) {
        const n = Math.max(0, Math.floor(Number(param(blk, 'número', param(blk, 'quadro', 0, ctx), ctx)) || 0));
        if (co.actor.data._sheet) {
          co.actor.data._sheet.frame = n;
          co.actor.data._sheet.playing = false;
          applySpritesheetFrame(co.actor);
        }
      } else if (name === 'Spritesheet da pasta' || nname.includes('spritesheet da pasta')) {
        const pasta = paramStr(blk, 'pasta', '', ctx).replace(/['"]/g, '');
        const fps = Math.max(1, Number(param(blk, 'fps', 8, ctx)) || 8);
        const looks = co.actor.data.looks || [];
        let frames = looks.map(function (L) {
          if (typeof L === 'string') return L;
          if (L && (L.dataUrl || L.src || L.image)) return L.dataUrl || L.src || L.image;
          return null;
        }).filter(Boolean);
        if (pasta) {
          const filtered = looks.filter(function (L) {
            if (!L || typeof L === 'string') return false;
            return L.folder && String(L.folder).toLowerCase() === pasta.toLowerCase();
          }).map(function (L) { return L.dataUrl || L.src || L.image; }).filter(Boolean);
          if (filtered.length) frames = filtered;
        }
        co.actor.data._sheet = {
          folderFrames: frames, cols: frames.length || 1, rows: 1, fps: fps,
          frame: 0, acc: 0, playing: true, mode: 'loop', useBg: false
        };
        applySpritesheetFrame(co.actor);
      } else if (name === 'Spritesheet da pasta em grade' || nname.includes('spritesheet da pasta em grade')) {
        const pasta = paramStr(blk, 'pasta', '', ctx).replace(/['"]/g, '');
        const cols = Math.max(1, Math.floor(Number(param(blk, 'colunas', 4, ctx)) || 4));
        const rows = Math.max(1, Math.floor(Number(param(blk, 'linhas', 1, ctx)) || 1));
        const fps = Math.max(1, Number(param(blk, 'fps', 8, ctx)) || 8);
        const looks = co.actor.data.looks || [];
        let src = '';
        for (let li = 0; li < looks.length; li++) {
          const L = looks[li];
          if (!L) continue;
          if (pasta && L.folder && String(L.folder).toLowerCase() !== pasta.toLowerCase()) continue;
          src = typeof L === 'string' ? L : (L.dataUrl || L.src || L.image || '');
          if (src) break;
        }
        if (!src && co.actor.data.image) src = co.actor.data.image;
        co.actor.data._sheet = {
          src: src, cols: cols, rows: rows, fps: fps,
          frame: 0, acc: 0, playing: true, mode: 'loop', useBg: true
        };
        applySpritesheetFrame(co.actor);

      } else if (name === 'Parar animação') {
        stopLookAnimation(co.actor);
        co.actor.data._activeLoopFolder = null;
      } else if (name === 'Reiniciar animação') {
        const folder = co.actor._animFolder || co.actor.data._activeLoopFolder;
        if (folder) {
          startLookAnimation(co.actor, folder, {
            loop: !!co.actor._animLoop,
            speed: co.actor.data._animSpeed || 8
          });
        }
      } else if (name === 'Aplicar animação em loop na pasta' || name.includes('Aplicar animação em loop')) {
        const folder = paramStr(blk, 'pasta', paramStr(blk, 'nome', 'Idle', ctx), ctx);
        if (!co.actor.data._loopFolders) co.actor.data._loopFolders = {};
        co.actor.data._loopFolders[folder] = true;
        if (!(co.actor._animPlaying && (co.actor._animFolder || '').toLowerCase() === folder.toLowerCase() && co.actor._animLoop)) {
          startLookAnimation(co.actor, folder, { loop: true, speed: co.actor.data._animSpeed || 8 });
          co.actor.data._activeLoopFolder = folder;
        }
      } else if (name === 'Tocar pasta uma vez e parar na última aparência' || name.includes('parar na última')) {
        const folder = paramStr(blk, 'pasta', paramStr(blk, 'nome', 'Idle', ctx), ctx);
        startLookAnimation(co.actor, folder, { loop: false, speed: co.actor.data._animSpeed || 8, holdLast: true });
      } else if (name === 'Tocar pasta uma vez e voltar pra aparência original' || name.includes('voltar pra aparência original')) {
        const folder = paramStr(blk, 'pasta', paramStr(blk, 'nome', 'Idle', ctx), ctx);
        const img = co.actor.el.querySelector('img');
        const orig = img ? img.src : (co.actor.data.image || null);
        co.actor.data._animRestore = orig;
        startLookAnimation(co.actor, folder, { loop: false, speed: co.actor.data._animSpeed || 8, restore: true });
      } else if (name === 'Definir pasta como aparência atual' || name.includes('como aparência atual')) {
        const folder = paramStr(blk, 'pasta', paramStr(blk, 'nome', 'Idle', ctx), ctx);
        const frames = getFolderFrames(co.actor.data, folder);
        if (frames.length) {
          stopLookAnimation(co.actor);
          setActorCostume(co.actor, frames[0]);
          co.actor._animFolder = folder;
          co.actor._animFrames = frames;
          co.actor._animFrame = 0;
        }
      } else if (name === 'Inverter ordem da pasta ao tocar' || name.includes('Inverter ordem')) {
        const folder = paramStr(blk, 'pasta', paramStr(blk, 'nome', 'Idle', ctx), ctx);
        const frames = getFolderFrames(co.actor.data, folder).slice().reverse();
        if (frames.length) {
          stopLookAnimation(co.actor);
          // temporarily play reversed
          const speed = co.actor.data._animSpeed || 8;
          co.actor._animFolder = folder;
          co.actor._animFrames = frames;
          co.actor._animFrame = 0;
          co.actor._animLoop = false;
          co.actor._animPlaying = true;
          co.actor._animDone = false;
          setActorCostume(co.actor, frames[0]);
          const frameMs = Math.max(16, 1000 / speed);
          co.actor._animLastTime = performance.now();
          const reverseTick = (now) => {
            if (!runtime.running || !co.actor._animPlaying) { stopLookAnimation(co.actor); return; }
            if (runtime.paused) { co.actor._animHandle = kixRequestAnimationFrame(reverseTick); return; }
            if (now - co.actor._animLastTime < frameMs) { co.actor._animHandle = kixRequestAnimationFrame(reverseTick); return; }
            co.actor._animLastTime = now;
            co.actor._animFrame++;
            if (co.actor._animFrame >= frames.length) {
              co.actor._animFrame = frames.length - 1;
              co.actor._animDone = true;
              stopLookAnimation(co.actor);
              return;
            }
            setActorCostume(co.actor, frames[co.actor._animFrame]);
            co.actor._animHandle = kixRequestAnimationFrame(reverseTick);
          };
          co.actor._animHandle = kixRequestAnimationFrame(reverseTick);
        }
      } else if (name === 'Tocar pasta em loop na velocidade' || name.includes('em loop na velocidade')) {
        const folder = paramStr(blk, 'pasta', paramStr(blk, 'nome', 'Idle', ctx), ctx);
        const fps = Math.max(1, Number(param(blk, 'fps', param(blk, 'valor', 12, ctx), ctx)) || 12);
        co.actor.data._animSpeed = fps;
        if (!co.actor.data._loopFolders) co.actor.data._loopFolders = {};
        co.actor.data._loopFolders[folder] = true;
        startLookAnimation(co.actor, folder, { loop: true, speed: fps });
        co.actor.data._activeLoopFolder = folder;
      } else if (name === 'Tocar pasta uma vez na velocidade' || name.includes('uma vez na velocidade')) {
        const folder = paramStr(blk, 'pasta', paramStr(blk, 'nome', 'Idle', ctx), ctx);
        const fps = Math.max(1, Number(param(blk, 'fps', param(blk, 'valor', 12, ctx), ctx)) || 12);
        co.actor.data._animSpeed = fps;
        startLookAnimation(co.actor, folder, { loop: false, speed: fps });
      } else if (name === 'Próximo quadro da animação') {
        const frames = co.actor._animFrames || getFolderFrames(co.actor.data, co.actor._animFolder || '');
        if (frames.length) {
          co.actor._animFrame = ((co.actor._animFrame || 0) + 1) % frames.length;
          setActorCostume(co.actor, frames[co.actor._animFrame]);
        }
      } else if (name === 'Definir quadro da animação para') {
        const frames = co.actor._animFrames || getFolderFrames(co.actor.data, co.actor._animFolder || '');
        let n = Math.floor(Number(param(blk, 'número', param(blk, 'quadro', 1, ctx), ctx)) || 1) - 1;
        if (frames.length) {
          n = ((n % frames.length) + frames.length) % frames.length;
          co.actor._animFrame = n;
          setActorCostume(co.actor, frames[n]);
        }
      } else if (name === 'Esperar animação terminar') {
        if (co.actor._animPlaying && !co.actor._animDone) return; // wait
      } else if (name === 'Definir velocidade da animação para') {
        co.actor.data._animSpeed = Math.max(1, Number(param(blk, 'valor', 8, ctx)) || 8);
        if (co.actor._animPlaying && co.actor._animFolder) {
          startLookAnimation(co.actor, co.actor._animFolder, { loop: co.actor._animLoop, speed: co.actor.data._animSpeed });
        }
      } else if (name === 'Mudar aparência para' || (name.includes('Mudar aparência') && name.includes('nome'))) {
        const nm = String(param(blk, 'nome', '', ctx));
        const looks = co.actor.data.looks || [];
        const names = co.actor.data.lookNames || {};
        let found = looks.find(s => s && (names[s] === nm || s.includes(nm)));
        if (!found) {
          // search folders
          (co.actor.data.folders || []).forEach(f => {
            if (found) return;
            if (f.name === nm && f.looks && f.looks[0]) found = f.looks[0];
            else (f.looks || []).forEach((s, li) => {
              if (!found && names['folder:' + f.name + ':' + li] === nm) found = s;
            });
          });
        }
        if (found) setActorCostume(co.actor, found);
      }

      else if (name === 'Espelhar horizontal') {
        co.actor.data.flipX = !co.actor.data.flipX;
        const sx = co.actor.data.flipX ? -1 : 1;
        const sy = co.actor.data.flipY ? -1 : 1;
        co.actor.el.style.transform += '';
        co.actor.data._scaleX = sx;
        co.actor._lastKey = null;
        // apply via filter scale in update - store and use
        const a = co.actor.data;
        const scale = (a.size || 100) / 100;
        co.actor.el.style.transform = co.actor.el.style.transform; // force
        updateSpriteTransform(co.actor);
        co.actor.el.style.scale = sx + ' ' + sy;
      } else if (name === 'Espelhar vertical') {
        co.actor.data.flipY = !co.actor.data.flipY;
        const sx = co.actor.data.flipX ? -1 : 1;
        const sy = co.actor.data.flipY ? -1 : 1;
        co.actor.el.style.scale = sx + ' ' + sy;
      } else if (name === 'Ir para camada') {
        moveRuntimeActorToLayer(co.actor, Number(param(blk, 'camada', 1, ctx)) || 1);
      } else if (name === 'Mudar camada em') {
        moveRuntimeActorByLayers(co.actor, Number(param(blk, 'valor', 1, ctx)) || 1);
      } else if (name === 'Mudar transparência em') {
        const deltaRaw=Number(param(blk, 'valor', 10, ctx));
        const delta=Number.isFinite(deltaRaw)?deltaRaw:10;
        const t=Number(co.actor.data.transparency != null ? co.actor.data.transparency : 100-Number(co.actor.data.opacity == null ? 100 : co.actor.data.opacity));
        setActorTransparency(co.actor,t+delta);
      } else if (name === 'Definir aparência para número' || name.includes('fantasia/costume') || name === 'Mudar para fantasia/costume') {
        const looks = co.actor.data.looks || [];
        let idx = Number(param(blk, 'número', param(blk, 'costume', param(blk, 'fantasia', 1, ctx), ctx), ctx)) - 1;
        if (isNaN(idx)) idx = 0;
        if (looks.length) {
          idx = ((idx % looks.length) + looks.length) % looks.length;
          co.actor.data.costume = idx;
          if (looks[idx]) {
            setActorCostume(co.actor, looks[idx]);
          }
        }
      } else if (name === 'Definir aparência para nome') {
        const looks = co.actor.data.looks || [];
        const nm = String(param(blk, 'nome', '', ctx));
        const names = co.actor.data.lookNames || {};
        let idx = looks.findIndex((_, i) => names['root:r:' + i] === nm);
        if (idx < 0) idx = 0;
        if (looks[idx]) {
          co.actor.data.costume = idx;
          setActorCostume(co.actor, looks[idx]);
        }
      } else if (name === 'Definir efeito para' || name === 'Mudar efeito gráfico em' || name === 'Mudar efeito em' || name === 'Definir efeito') {
        const efeito = String(param(blk, 'efeito', 'cor', ctx)).toLowerCase();
        const valor = Number(param(blk, 'valor', 0, ctx)) || 0;
        if (!co.actor.data.effects) co.actor.data.effects = {};
        if (name.includes('Mudar')) {
          co.actor.data.effects[efeito] = (co.actor.data.effects[efeito] || 0) + valor;
        } else {
          co.actor.data.effects[efeito] = valor;
        }
        const ef = co.actor.data.effects;
        const filters = [];
        if (ef.cor || ef.color) filters.push('hue-rotate(' + (ef.cor || ef.color) + 'deg)');
        if (ef.brilho || ef.brightness) filters.push('brightness(' + (1 + (ef.brilho || ef.brightness) / 100) + ')');
        if (ef.fantasma || ef.ghost) filters.push('opacity(' + (1 - (ef.fantasma || ef.ghost) / 100) + ')');
        co.actor.el.style.filter = filters.join(' ') || '';
      } else if (name === 'Fade in') {
        const sec = Number(param(blk, 'segundos', 0.5, ctx)) || 0.5;
        co.actor.el.style.transition = 'opacity ' + sec + 's linear';
        co.actor.el.style.opacity = '0';
        co.actor.data.visible = true;
        updateSpriteTransform(co.actor);
        kixRequestAnimationFrame(() => { co.actor.el.style.opacity = '1'; });
        co.waitUntil = now + sec * 1000;
      } else if (name === 'Fade out') {
        const sec = Number(param(blk, 'segundos', 0.5, ctx)) || 0.5;
        co.actor.el.style.transition = 'opacity ' + sec + 's linear';
        co.actor.el.style.opacity = '0';
        co.waitUntil = now + sec * 1000;
        // hide after
        const actor = co.actor;
        kixSetTimeout(() => { actor.data.visible = false; updateSpriteTransform(actor); }, sec * 1000);
      } else if (name === 'Piscar X vezes') {
        const times = Number(param(blk, 'vezes', 3, ctx)) || 3;
        const el = co.actor.el;
        let n = 0;
        const id = kixSetInterval(() => {
          if (!runtime.running) { kixClearTimer(id); return; }
          if (runtime.paused) return;
          el.style.visibility = (n % 2 === 0) ? 'hidden' : 'visible';
          n++;
          if (n >= times * 2) { kixClearTimer(id); el.style.visibility = 'visible'; }
        }, 120);
        co.waitUntil = now + times * 240;
      } else if (name === 'Definir brilho') {
        const v = Number(param(blk, 'valor', 100, ctx)) || 100;
        co.actor.el.style.filter = 'brightness(' + (v / 100) + ')';
      } else if (name === 'Outline') {
        const cor = String(param(blk, 'cor', '#ffffff', ctx));
        const esp = Number(param(blk, 'espessura', 2, ctx)) || 2;
        co.actor.el.style.filter = 'drop-shadow(0 0 ' + esp + 'px ' + cor + ')';
      } else if (name === 'Quando receber mensagem') {
        // hat handled elsewhere
      }

      // ---- FIREBASE ----
      else if (name === 'Configurar Firebase') {
        const raw=paramStr(blk,'configuração','{}',ctx); let cfg={}; try{cfg=JSON.parse(fbClean(raw)||'{}');}catch(e){runtime.network.firebase.error='Configuração Firebase inválida';}
        runtime.network.firebase.config=cfg; fbSetStatus('configured');
      } else if (name === 'Conectar Firebase') {
        if(fbBase()) fbSetStatus('connected'); else fbSetStatus('error','Configure o Firebase primeiro');
      } else if (name === 'Desconectar Firebase') {
        Object.values(runtime.network.firebase.listeners||{}).forEach(id=>{try{kixClearTimer(id);}catch(_){}}); runtime.network.firebase.listeners={}; runtime.network.firebase.token=null; runtime.network.firebase.uid=null; fbSetStatus('disconnected');
      } else if (name === 'Status Firebase') { fbStore(co,'firebase_status',runtime.network.firebase.status); }
      else if (name === 'Definir caminho Firebase') { runtime.network.firebase.path=fbClean(paramStr(blk,'caminho','',ctx)).replace(/^\/+|\/+$/g,''); }
      else if (name === 'Entrar anonimamente no Firebase') { fbAuth('signUp',{returnSecureToken:true}).then(d=>fbStore(co,'firebase_uid',d.localId||'')).catch(e=>fbSetStatus('error',e)); }
      else if (name === 'Entrar no Firebase com email') { fbAuth('signInWithPassword',{email:fbClean(paramStr(blk,'email','',ctx)),password:fbClean(paramStr(blk,'senha','',ctx)),returnSecureToken:true}).then(d=>fbStore(co,'firebase_uid',d.localId||'')).catch(e=>fbSetStatus('error',e)); }
      else if (name === 'Sair do Firebase') { runtime.network.firebase.token=null; runtime.network.firebase.uid=null; fbSetStatus('configured'); }
      else if (name === 'Ler UID do jogador') { fbStore(co,'firebase_uid',runtime.network.firebase.uid||''); }
      else if (name === 'Ler erro do Firebase') { fbStore(co,'firebase_erro',runtime.network.firebase.error||''); }
      else if (name === 'Salvar dados no Firebase') { fbFetch('',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(fbDataValue(paramStr(blk,'dados','',ctx)))}).then(d=>fbStore(co,'firebase_resposta',d)).catch(e=>fbSetStatus('error',e)); }
      else if (name === 'Ler dados do Firebase') { fbFetch(paramStr(blk,'caminho','',ctx)).then(d=>fbStore(co,'firebase_dados',d)).catch(e=>fbSetStatus('error',e)); }
      else if (name === 'Atualizar dados no Firebase') { fbFetch(paramStr(blk,'caminho','',ctx),{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(fbDataValue(paramStr(blk,'dados','',ctx)))}).then(d=>fbStore(co,'firebase_resposta',d)).catch(e=>fbSetStatus('error',e)); }
      else if (name === 'Excluir dados do Firebase') { fbFetch(paramStr(blk,'caminho','',ctx),{method:'DELETE'}).then(d=>fbStore(co,'firebase_resposta',d)).catch(e=>fbSetStatus('error',e)); }
      else if (name === 'Adicionar jogador à sala') { const room=paramStr(blk,'sala','sala',ctx), uid=runtime.network.firebase.uid||('guest_'+runtimeRandom().toString(36).slice(2,8)); fbFetch(fbRoomPath(room,'jogadores/'+uid),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({nome:fbClean(paramStr(blk,'nome','Jogador',ctx)),uid,online:true})}).catch(e=>fbSetStatus('error',e)); }
      else if (name === 'Remover jogador da sala') { const room=paramStr(blk,'sala','sala',ctx),uid=runtime.network.firebase.uid||''; fbFetch(fbRoomPath(room,'jogadores/'+uid),{method:'DELETE'}).catch(e=>fbSetStatus('error',e)); }
      else if (name === 'Definir dado do jogador') { const key=fbClean(paramStr(blk,'nome','estado',ctx)); fbFetch(fbRoomPath(runtime.network.firebase.path||'sala','jogadores/'+(runtime.network.firebase.uid||'local')+'/'+key),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(fbDataValue(paramStr(blk,'valor','',ctx)))}).catch(e=>fbSetStatus('error',e)); }
      else if (name === 'Ler dado do jogador') { const uid=fbClean(paramStr(blk,'jogador','',ctx)), key=fbClean(paramStr(blk,'nome','estado',ctx)); fbFetch(fbRoomPath(runtime.network.firebase.path||'sala','jogadores/'+uid+'/'+key)).then(d=>fbStore(co,'jogador_dado',d)).catch(e=>fbSetStatus('error',e)); }
      else if (name === 'Listar jogadores da sala') { const room=paramStr(blk,'sala','sala',ctx); fbFetch(fbRoomPath(room,'jogadores')).then(d=>fbStore(co,'jogadores',d||{})).catch(e=>fbSetStatus('error',e)); }
      else if (name === 'Criar sala multiplayer') { const room=fbClean(paramStr(blk,'sala','sala',ctx)); fbFetch(fbRoomPath(room),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({estado:'lobby',host:runtime.network.firebase.uid||'local',criadaEm:runtimeNow()})}).catch(e=>fbSetStatus('error',e)); }
      else if (name === 'Entrar em sala multiplayer') { runtime.network.firebase.path=fbClean(paramStr(blk,'sala','sala',ctx)); }
      else if (name === 'Sair da sala multiplayer') { const room=fbClean(paramStr(blk,'sala',runtime.network.firebase.path||'sala',ctx)),uid=runtime.network.firebase.uid||''; if(uid) fbFetch(fbRoomPath(room,'jogadores/'+uid),{method:'DELETE'}).catch(()=>{}); runtime.network.firebase.path=''; }
      else if (name === 'Definir estado da sala') { fbFetch(fbRoomPath(runtime.network.firebase.path||'sala','estado'),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(fbDataValue(paramStr(blk,'estado','lobby',ctx)))}).catch(e=>fbSetStatus('error',e)); }
      else if (name === 'Ler estado da sala') { const room=paramStr(blk,'sala',runtime.network.firebase.path||'sala',ctx); fbFetch(fbRoomPath(room,'estado')).then(d=>fbStore(co,'estado_sala',d)).catch(e=>fbSetStatus('error',e)); }
      else if (name === 'Enviar evento multiplayer') { const event=fbClean(paramStr(blk,'evento','evento',ctx)); fbFetch(fbRoomPath(runtime.network.firebase.path||'sala','eventos'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({evento:event,dados:fbDataValue(paramStr(blk,'dados','',ctx)),uid:runtime.network.firebase.uid||'local',tempo:runtimeNow()})}).catch(e=>fbSetStatus('error',e)); }
      else if (name === 'Ler último evento multiplayer') { fbFetch(fbRoomPath(runtime.network.firebase.path||'sala','eventos')).then(d=>{const vals=d?Object.values(d):[]; vals.sort((a,b)=>(b?.tempo||0)-(a?.tempo||0)); fbStore(co,'ultimo_evento',vals[0]||null);}).catch(e=>fbSetStatus('error',e)); }
      else if (name === 'Escutar mudanças da sala') { const room=fbClean(paramStr(blk,'sala',runtime.network.firebase.path||'sala',ctx)); const id='room:'+room; if(runtime.network.firebase.listeners[id]) kixClearTimer(runtime.network.firebase.listeners[id]); runtime.network.firebase.listeners[id]=kixSetInterval(()=>fbFetch(fbRoomPath(room)).then(d=>runtime.network.firebase.lastRoom=d).catch(()=>{}),1000); }
      else if (name === 'Parar de escutar a sala') { const room=fbClean(paramStr(blk,'sala',runtime.network.firebase.path||'sala',ctx)); const id='room:'+room; if(runtime.network.firebase.listeners[id]){kixClearTimer(runtime.network.firebase.listeners[id]);delete runtime.network.firebase.listeners[id];} }

      // ---- MULTIPLAYER / NETWORK ----
      else if (name === 'Conectar WebSocket') { netOpenWs(netEndpoint(paramStr(blk,'url','',ctx))); }
      else if (name === 'Desconectar WebSocket') { try{runtime.network.ws?.close();}catch(_){} runtime.network.ws=null; runtime.network.wsStatus='closed'; }
      else if (name === 'Enviar WebSocket') { netSendWs(paramStr(blk,'mensagem','',ctx)); }
      else if (name === 'Ler última mensagem WebSocket') { netSetVar(co,'rede_mensagem',runtime.network.lastMessage||''); }
      else if (name === 'Status WebSocket') { netSetVar(co,'rede_status',runtime.network.wsStatus); }
      else if (name === 'Conectar TCP') { const ep=netEndpoint(paramStr(blk,'endpoint','',ctx)); runtime.network.tcpStatus='bridge'; runtime.network.tcp=ep; if(global.kixNetwork?.tcpConnect) { try{Promise.resolve(global.kixNetwork.tcpConnect(ep)).then(()=>runtime.network.tcpStatus='open').catch(()=>runtime.network.tcpStatus='error');}catch(_){runtime.network.tcpStatus='error';} } else if(/^wss?:\/\//i.test(ep)) { netOpenWs(ep); runtime.network.tcpStatus='websocket-bridge'; } else runtime.network.tcpStatus='unavailable'; }
      else if (name === 'Enviar TCP') { const d=param(blk,'dados','',ctx); if(global.kixNetwork?.tcpSend){try{global.kixNetwork.tcpSend(runtime.network.tcp,d);}catch(_){}} else netSendWs(d); }
      else if (name === 'Ler TCP') { netSetVar(co,'tcp_dados',runtime.network.lastMessage||''); }
      else if (name === 'Fechar TCP') { if(global.kixNetwork?.tcpClose){try{global.kixNetwork.tcpClose(runtime.network.tcp);}catch(_){}} runtime.network.tcp=null; runtime.network.tcpStatus='closed'; }
      else if (name === 'Status TCP') { netSetVar(co,'tcp_status',runtime.network.tcpStatus); }
      else if (name === 'Enviar UDP') { const ep=netEndpoint(paramStr(blk,'endpoint','',ctx)), d=param(blk,'dados','',ctx); runtime.network.udpStatus='sending'; if(global.kixNetwork?.udpSend){try{Promise.resolve(global.kixNetwork.udpSend(ep,d)).then(()=>runtime.network.udpStatus='open').catch(()=>runtime.network.udpStatus='error');}catch(_){runtime.network.udpStatus='error';}} else if(/^wss?:\/\//i.test(ep)){netSendWs(d);runtime.network.udpStatus='websocket-bridge';} else runtime.network.udpStatus='unavailable'; }
      else if (name === 'Escutar UDP') { const port=Number(param(blk,'porta',0,ctx)); if(global.kixNetwork?.udpListen){try{global.kixNetwork.udpListen(port,(d)=>runtime.network.lastUDP=typeof d==='string'?d:JSON.stringify(d));runtime.network.udpStatus='open';}catch(_){runtime.network.udpStatus='error';}} else runtime.network.udpStatus='unavailable'; }
      else if (name === 'Ler último UDP') { netSetVar(co,'udp_dados',runtime.network.lastUDP||''); }
      else if (name === 'Parar escuta UDP') { if(global.kixNetwork?.udpClose){try{global.kixNetwork.udpClose();}catch(_){}} runtime.network.udpStatus='closed'; }
      else if (name === 'Status UDP') { netSetVar(co,'udp_status',runtime.network.udpStatus); }
      else if (name === 'Requisição HTTP GET' || name === 'Requisição HTTP POST') { const url=netEndpoint(paramStr(blk,'url','',ctx)); const method=name.includes('POST')?'POST':'GET'; const body=method==='POST'?String(param(blk,'corpo','',ctx)):undefined; const ctl=new AbortController(); const timer=kixSetTimeout(()=>ctl.abort(),Math.max(100,Number(runtime.network.timeout)||5000)); runtime.network.lastError=''; fetch(url,{method,body,headers:method==='POST'?{'Content-Type':'application/json'}:undefined,signal:ctl.signal}).then(r=>r.text()).then(t=>{runtime.network.lastMessage=t;runtime.network.inputs.http=t;}).catch(e=>{runtime.network.lastError=String(e&&e.message||e);}).finally(()=>kixClearTimer(timer)); }
      else if (name === 'Codificar JSON') { try{netSetVar(co,'json_saida',JSON.stringify(param(blk,'valor','',ctx)));}catch(_){netSetVar(co,'json_saida','null');} }
      else if (name === 'Decodificar JSON') { try{netSetVar(co,'json_valor',JSON.parse(String(param(blk,'texto','',ctx))));}catch(_){netSetVar(co,'json_valor',null);} }
      else if (name === 'Definir timeout de rede') { runtime.network.timeout=Math.max(100,Number(param(blk,'milissegundos',5000,ctx))||5000); }
      else if (name === 'Definir entrada de rede') { const c=paramStr(blk,'canal','default',ctx); runtime.network.inputs[c]=param(blk,'valor','',ctx); }
      else if (name === 'Ler entrada de rede') { const c=paramStr(blk,'canal','default',ctx); netSetVar(co,'entrada_rede',runtime.network.inputs[c]??''); }
      else if (name === 'Enviar saída de rede') { const c=paramStr(blk,'canal','default',ctx); const v=param(blk,'valor','',ctx); runtime.network.outputs[c]=v; netSendWs(JSON.stringify({channel:c,value:v})); }
      else if (name === 'Ping servidor') { const url=netEndpoint(paramStr(blk,'url','',ctx)); const t0=performance.now(); fetch(url,{method:'HEAD',cache:'no-store'}).then(()=>netSetVar(co,'ping_ms',Math.round(performance.now()-t0))).catch(()=>netSetVar(co,'ping_ms',-1)); }
      else if (name === 'Transmitir evento de rede') { const ev=paramStr(blk,'evento','evento',ctx), d=param(blk,'dados','',ctx); netSendWs(JSON.stringify({type:'kix-event',event:ev,data:d})); runtime.messages.push({type:'network',event:ev,data:d}); }


      // default: advance
      if (blk.body && blk.body.length && (blk.type === 'loop' || blk.type === 'if')) {
        // already handled
      }
      co.ip = blk.next;
      // after finishing body of loop, handled by loopStack
    }
  }

  function watchProEvents(ts) {
    try {
      if (!runtime._timer0) runtime._timer0 = ts;
      const elapsed = (ts - runtime._timer0) / 1000;
      runtime.globals['cronômetro'] = elapsed;
      // FPS estimate
      if (!runtime._fpsLast) { runtime._fpsLast = ts; runtime._fpsFrames = 0; runtime._fps = 60; }
      runtime._fpsFrames++;
      if (ts - runtime._fpsLast >= 500) {
        runtime._fps = runtime._fpsFrames * 1000 / (ts - runtime._fpsLast);
        runtime._fpsFrames = 0;
        runtime._fpsLast = ts;
      }
      runtime.actors.forEach(ra => {
        if (!ra.scripts) return;
        const list = Array.isArray(ra.scripts) ? ra.scripts : [];
        // region enter/exit
        const x = Number(ra.data.x) || 0, y = Number(ra.data.y) || 0;
        list.forEach(s => {
          if (!s || s.disabled) return;
          if (s.name === 'Quando entrar na região' || s.name === 'Quando sair da região') {
            const rx = Number(s.values?.x || 0), ry = Number(s.values?.y || 0);
            const rw = Number(s.values?.largura || 100), rh = Number(s.values?.altura || 100);
            const inside = x >= rx && x <= rx + rw && y >= ry && y <= ry + rh;
            const key = '_reg_' + (s.id || s.name);
            const was = !!ra.data[key];
            if (s.name === 'Quando entrar na região' && inside && !was) {
              ra.data[key] = true;
              startHatsFor(ra, s.name);
            } else if (s.name === 'Quando sair da região' && !inside && was) {
              ra.data[key] = false;
              startHatsFor(ra, s.name);
            } else if (inside) ra.data[key] = true;
            else ra.data[key] = false;
          }
          if (s.name === 'Quando cronômetro >') {
            const need = Number(s.values?.segundos || 1);
            const key = '_t_' + (s.id || need);
            if (elapsed >= need && !ra.data[key]) {
              ra.data[key] = true;
              startHatsFor(ra, s.name);
            }
          }
          if (s.name === 'Quando FPS <') {
            const need = Number(s.values?.fps || 30);
            if ((runtime._fps || 60) < need) {
              const key = '_fps_' + (s.id || need);
              if (!ra.data[key]) {
                ra.data[key] = true;
                startHatsFor(ra, s.name);
                kixSetTimeout(() => { ra.data[key] = false; }, 1000);
              }
            }
          }
          if (s.name === 'Quando variável mudar') {
            const vn = String(s.values?.variável || s.values?.variavel || '');
            if (!vn) return;
            const cur = runtime.globals[vn];
            const key = '_var_' + vn;
            if (ra.data[key] !== undefined && ra.data[key] !== cur) {
              startHatsFor(ra, s.name);
            }
            ra.data[key] = cur;
          }
          const cid = s.compatId || (global.KixCatrobatBrickAliases && global.KixCatrobatBrickAliases[String(s.name||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[.……]/g,'').replace(/[^a-z0-9]+/g,' ').trim()]);
          if (cid === 'event.when_condition_true') {
            let raw=0; try { raw=param(s,'condition',param(s,'condição',param(s,'condicao',0,{actor:ra.data,vars:ra.data._vars||{},globals:runtime.globals}),{actor:ra.data,vars:ra.data._vars||{},globals:runtime.globals}),{actor:ra.data,vars:ra.data._vars||{},globals:runtime.globals}); } catch (_) {}
            const truthy=!(raw===0||raw==='0'||raw===false||raw==='false'||raw===''); const key='_cat_cond_'+String(s.id||'');
            if(truthy && !ra.data[key]) startHatsFor(ra,s.name);
            ra.data[key]=truthy;
          }
          if (cid === 'motion.when_bounce') {
            const target=String(s.values?.object||s.values?.target||'').replace(/^['"]|['"]$/g,'').trim().toLowerCase();
            const bounds=prepareCollisionBounds(); const mine=getActorBounds(ra);
            let hit=false;
            if(mine){
              for(let ai=0;ai<(runtime.actors||[]).length;ai++){ const other=runtime.actors[ai]; if(!other||other===ra) continue; const on=String(other.data?.name||'').toLowerCase(); if(target && !on.includes(target)) continue; const ob=bounds[ai]||getActorBounds(other); if(checkCollisionBounds(mine,ob)){hit=true;break;} }
            }
            const key='_cat_bounce_'+String(s.id||''); if(hit && !ra.data[key]) startHatsFor(ra,s.name); ra.data[key]=hit;
          }
        });
      });
    } catch (e) { console.warn('watchProEvents', e); }
  }

  
  // ===== COLLISION =====
  function pointInActorBounds(ra, x, y) {
    const b = getActorBounds(ra);
    if (!b) return false;
    if (b.type === 'circle') {
      const dx = Number(x) - b.x, dy = Number(y) - b.y;
      return dx * dx + dy * dy <= b.r * b.r;
    }
    return Number(x) >= b.x && Number(x) <= b.x + b.w && Number(y) >= b.y && Number(y) <= b.y + b.h;
  }

  function actorCollidesWithStageEdge(ra) {
    if (!ra || !ra.data) return false;
    const b = getActorBounds(ra);
    if (!b) return false;
    const w = Number(runtime._logicalStageW || 480);
    const h = Number(runtime._logicalStageH || 800);
    const ax = b.type === 'circle' ? b.x - b.r : b.x;
    const ay = b.type === 'circle' ? b.y - b.r : b.y;
    const aw = b.type === 'circle' ? b.r * 2 : b.w;
    const ah = b.type === 'circle' ? b.r * 2 : b.h;
    return ax <= -w/2 || ax + aw >= w/2 || ay <= -h/2 || ay + ah >= h/2;
  }

  function getActorBounds(ra) {
    if (!ra || !ra.data) return null;
    const a = ra.data;
    if (a.isCamera) return null;
    const cx = Number(a.x) || 0;
    const cy = Number(a.y) || 0;
    const size = Math.max(0.01, (Number(a.size) || 100) / 100);
    const shape = (a.collisionShape && typeof a.collisionShape === 'object') ? a.collisionShape : { type: 'rect' };
    if (shape.enabled === false) return null;

    // Do not call getBoundingClientRect() from the game loop: it can force a layout
    // and was a major source of startup/runtime stutter on mobile.
    let w = 48 * size, h = 48 * size;
    const img = ra.el && ra.el.querySelector ? ra.el.querySelector('img') : null;
    if (img && img.naturalWidth > 0 && img.naturalHeight > 0) {
      w = img.naturalWidth * size;
      h = img.naturalHeight * size;
    }

    if (shape.type === 'rect') {
      w = (shape.width != null ? Number(shape.width) : 48) * size * (Number(shape.scale) || 1);
      h = (shape.height != null ? Number(shape.height) : 48) * size * (Number(shape.scale) || 1);
      const ox = Number(shape.offsetX) || 0;
      const oy = Number(shape.offsetY) || 0;
      return { x: cx + ox - w / 2, y: cy + oy - h / 2, w, h, type: 'rect', ra };
    }
    if (shape.type === 'circle') {
      const r = (Number(shape.radius) || (Math.max(w, h) / 2 / size)) * size * (Number(shape.scale) || 1);
      return { x: cx + (Number(shape.offsetX) || 0), y: cy + (Number(shape.offsetY) || 0), r, type: 'circle', ra };
    }
    return { x: cx + (Number(shape.offsetX) || 0) - w / 2, y: cy + (Number(shape.offsetY) || 0) - h / 2, w, h, type: 'rect', pixel: true, ra };
  }

  function prepareCollisionBounds() {
    const frame = runtime._frame || 0;
    const actors = runtime.actors || [];
    if (runtime._collisionBoundsFrame === frame && runtime._collisionBounds && runtime._collisionBounds.length === actors.length) {
      return runtime._collisionBounds;
    }
    const bounds = (runtime._collisionBounds && runtime._collisionBounds.length === actors.length) ? runtime._collisionBounds : new Array(actors.length);
    for (let i = 0; i < actors.length; i++) {
      const ra = actors[i];
      bounds[i] = (!ra || !ra.data || ra.data.isCamera || ra.data.visible === false) ? undefined : getActorBounds(ra);
    }
    runtime._collisionBounds = bounds;
    runtime._collisionBoundsFrame = frame;
    return bounds;
  }

  function aabbForShape(b) {
    if (!b) return null;
    if (b.type === 'circle') return { x: b.x - b.r, y: b.y - b.r, w: b.r * 2, h: b.r * 2 };
    return b;
  }

  function aabbOverlap(a, b) {
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  }

  function circleOverlap(a, b) {
    const dx = a.x - b.x, dy = a.y - b.y;
    const rr = a.r + b.r;
    return (dx * dx + dy * dy) < rr * rr;
  }

  function rectCircleOverlap(rect, cir) {
    const nx = Math.max(rect.x, Math.min(cir.x, rect.x + rect.w));
    const ny = Math.max(rect.y, Math.min(cir.y, rect.y + rect.h));
    const dx = cir.x - nx, dy = cir.y - ny;
    return (dx * dx + dy * dy) < cir.r * cir.r;
  }

  function checkCollisionBounds(A, B) {
    if (!A || !B) return false;
    const broadA = aabbForShape(A), broadB = aabbForShape(B);
    if (!aabbOverlap(broadA, broadB)) return false;
    if (A.type === 'circle' && B.type === 'circle') return circleOverlap(A, B);
    if (A.type === 'circle' && B.type === 'rect') return rectCircleOverlap(B, A);
    if (A.type === 'rect' && B.type === 'circle') return rectCircleOverlap(A, B);
    return aabbOverlap(A, B);
  }

  function checkCollision(raA, raB) {
    try {
      if (!raA || !raB || raA === raB) return false;
      if (raA.data && raA.data.visible === false) return false;
      if (raB.data && raB.data.visible === false) return false;
      if (raA.data && raA.data.isCamera) return false;
      if (raB.data && raB.data.isCamera) return false;
      const list=prepareCollisionBounds(); const ia=(runtime.actors||[]).indexOf(raA), ib=(runtime.actors||[]).indexOf(raB); return checkCollisionBounds(ia>=0?list[ia]:getActorBounds(raA), ib>=0?list[ib]:getActorBounds(raB));
    } catch (e) {
      console.warn('checkCollision', e);
      return false;
    }
  }

  function processCollisions() {
    if (runtime.paused || !runtime.running) return;
    const actors = runtime.actors || [];
    const n = actors.length;
    if (n < 2) return;
    const bounds = prepareCollisionBounds();
    const cellSize = 160;
    const grid = runtime._collisionGrid || (runtime._collisionGrid = new Map());
    const candidates = runtime._collisionCandidates || (runtime._collisionCandidates = new Set());
    const largeIndices = runtime._collisionLargeIndices || (runtime._collisionLargeIndices = []);
    grid.clear(); candidates.clear(); largeIndices.length = 0;

    for (let i = 0; i < n; i++) {
      const ra = actors[i], b = bounds[i];
      if (!ra || !ra.data || ra.data.isCamera || ra.data.isBackground || !b) continue;
      const bb = aabbForShape(b);
      const minX = Math.floor(bb.x / cellSize), maxX = Math.floor((bb.x + bb.w) / cellSize);
      const minY = Math.floor(bb.y / cellSize), maxY = Math.floor((bb.y + bb.h) / cellSize);
      const cells = Math.min(64, (maxX - minX + 1) * (maxY - minY + 1));
      if (cells > 64) {
        // Very large collider: keep it in a dedicated bucket so it remains correct.
        largeIndices.push(i);
        continue;
      }
      for (let gx = minX; gx <= maxX; gx++) for (let gy = minY; gy <= maxY; gy++) {
        const key = gx + ':' + gy;
        let bucket = grid.get(key);
        if (!bucket) grid.set(key, bucket = []);
        bucket.push(i);
      }
    }

    grid.forEach(bucket => {
      for (let bi = 0; bi < bucket.length; bi++) {
        for (let bj = bi + 1; bj < bucket.length; bj++) {
          const a = bucket[bi], b = bucket[bj];
          if (a === b) continue;
          const lo = Math.min(a, b), hi = Math.max(a, b);
          candidates.add(lo + '|' + hi);
        }
      }
    });
    // Large colliders cannot be represented efficiently by the grid; pair them
    // with every actor so optimization never changes collision behavior.
    for (let li = 0; li < largeIndices.length; li++) {
      const a = largeIndices[li];
      for (let b = 0; b < n; b++) {
        if (a === b || !bounds[b]) continue;
        const lo = Math.min(a, b), hi = Math.max(a, b);
        candidates.add(lo + '|' + hi);
      }
    }

    candidates.forEach(pair => {
      const [ai, bi] = pair.split('|').map(Number);
      const ra = actors[ai], rb = actors[bi];
      if (!ra || !rb || !ra.data || !rb.data) return;
      const layerA = Number(ra.data.collisionLayer == null ? 1 : ra.data.collisionLayer) || 0;
      const layerB = Number(rb.data.collisionLayer == null ? 1 : rb.data.collisionLayer) || 0;
      const maskA = Number(ra.data.collisionMask == null ? -1 : ra.data.collisionMask);
      const maskB = Number(rb.data.collisionMask == null ? -1 : rb.data.collisionMask);
      if (!(maskA < 0 || maskB < 0 || ((maskA & layerB) !== 0 && (maskB & layerA) !== 0))) return;
      const hit = checkCollisionBounds(bounds[ai], bounds[bi]);
      if (hit) {
        ra._collisionLastAgainst = rb; rb._collisionLastAgainst = ra;
        const now=performance.now();
        const applyPreset=(actor,other)=>{ const d=actor.data||{}, p=d._collisionPreset; if(!p) return; if(p==='collect' || d.collisionResponse==='collect'){ actor.data.visible=false; actor.data._collected=true; actor.data._collisionPreset=null; updateSpriteTransform(actor); } else if(p==='damage' || d.collisionResponse==='damage'){ const key='__damage_'+(other.data.name||'x'); if(!actor._damageStamp)actor._damageStamp={}; if(!actor._damageStamp[key] || now-actor._damageStamp[key]>=Math.max(0,Number(d.collisionInterval)||500)){actor._damageStamp[key]=now; other.data._vars=other.data._vars||{}; other.data._vars.vida=(Number(other.data._vars.vida)||100)-(Number(d.collisionDamage)||10);} } else if(p==='push' || d.collisionResponse==='push'){ const dx=(Number(other.data.x)||0)-(Number(actor.data.x)||0),dy=(Number(other.data.y)||0)-(Number(actor.data.y)||0),len=Math.hypot(dx,dy)||1,f=Number(d.collisionPushForce)||8; other.data.vx=(Number(other.data.vx)||0)+(dx/len)*f; other.data.vy=(Number(other.data.vy)||0)+(dy/len)*f; } else if(p==='solid' || d.collisionResponse==='parar'){ other.data.vx=0; other.data.vy=0; } else if(p==='sensor'){ const k=d.collisionSensorVariable||'colidiu'; runtime.globals[k]=true; } else if(p==='teleport' || d.collisionResponse==='teleport'){ other.data.x=Number(d.teleportX)||0; other.data.y=Number(d.teleportY)||0; updateSpriteTransform(other,true); if(d.teleportScene && typeof window.kixChangeScene==='function') window.kixChangeScene(d.teleportScene); } };
        applyPreset(ra,rb); applyPreset(rb,ra);
      }
      if (!ra._collidingWith) ra._collidingWith = {};
      if (!rb._collidingWith) rb._collidingWith = {};
      const keyA = rb.data.name || String(bi);
      const keyB = ra.data.name || String(ai);
      const wasA = !!ra._collidingWith[keyA];
      const wasB = !!rb._collidingWith[keyB];
      if (hit) {
        if (!wasA) { ra._collidingWith[keyA] = true; try { startHatsFor(ra, 'Quando colidir com'); } catch (_) {} }
        if (!wasB) { rb._collidingWith[keyB] = true; try { startHatsFor(rb, 'Quando colidir com'); } catch (_) {} }
      } else {
        if (wasA) ra._collidingWith[keyA] = false;
        if (wasB) rb._collidingWith[keyB] = false;
      }
    });
  }

  function renderCollisionDebug() {
    const stage = runtime.stageEl || document.getElementById('play-stage');
    if (!stage) return;
    let layer = stage.querySelector('[data-kix-collision-debug]');
    if (!layer) {
      layer = document.createElement('div');
      layer.dataset.kixCollisionDebug = '1';
      layer.style.cssText = 'position:absolute;inset:0;pointer-events:none;z-index:9999;display:none;';
      stage.appendChild(layer);
    }
    if (runtime.debugCollisions === false) {
      layer.style.display = 'none';
      return;
    }
    layer.style.display = 'block';
    const bounds = prepareCollisionBounds();
    const actors = runtime.actors || [];
    const active = new Set();
    for (let i = 0; i < actors.length; i++) {
      const ra = actors[i], b = bounds[i];
      if (!ra || !ra.data || ra.data.isCamera || ra.data.visible === false || !b) continue;
      const key = String(ra.id != null ? ra.id : i);
      active.add(key);
      let d = runtime._collisionDebugEls.get(key);
      if (!d) {
        d = document.createElement('div');
        d.style.cssText = 'position:absolute;box-sizing:border-box;border:3px solid #FF1F1F;background:rgba(255,31,31,.14);box-shadow:0 0 0 1px rgba(255,31,31,.9),0 0 12px rgba(255,31,31,.55);opacity:.98;pointer-events:none;will-change:transform;';
        layer.appendChild(d);
        runtime._collisionDebugEls.set(key, d);
      }
      if (b.type === 'circle') {
        const w = b.r * 2;
        d.style.width = w + 'px';
        d.style.height = w + 'px';
        d.style.borderRadius = '50%';
        d.style.transform = 'translate3d(' + ((stage._stageW || 360) / 2 + b.x - b.r) + 'px,' + ((stage._stageH || 640) / 2 - b.y - b.r) + 'px,0)';
      } else {
        d.style.width = b.w + 'px';
        d.style.height = b.h + 'px';
        d.style.borderRadius = '0';
        d.style.transform = 'translate3d(' + ((stage._stageW || 360) / 2 + b.x) + 'px,' + ((stage._stageH || 640) / 2 - (b.y + b.h)) + 'px,0)';
      }
    }
    runtime._collisionDebugEls.forEach((el, key) => {
      if (!active.has(key)) { try { el.remove(); } catch (_) {} runtime._collisionDebugEls.delete(key); }
    });
    runtime._collisionDebugFrame = runtime._frame || 0;
  }


  function reportEngineError(info) {
    try {
      const msg = 'Erro' + (info && info.actor ? (' em ' + info.actor) : '') + ': ' + (info && info.error && (info.error.message || info.error) || 'script');
      if (typeof window !== 'undefined' && window.toast) window.toast(msg, 4000);
      else console.error(msg);
    } catch (_) {}
  }

  
  // ===== SPRITESHEET =====
  function applySpritesheetFrame(ra) {
    try {
      if (!ra || !ra.data || !ra.data._sheet) return;
      const sh = ra.data._sheet;
      if (!sh.playing && sh.mode !== 'hold') return;
      const img = ra.el && ra.el.querySelector('img');
      const el = ra.el;
      if (!el) return;
      // Prefer CSS background sheet on the actor element
      if (sh.useBg) {
        const fw = 100 / sh.cols;
        const fh = 100 / sh.rows;
        const c = sh.frame % sh.cols;
        const r = Math.floor(sh.frame / sh.cols) % sh.rows;
        el.style.backgroundImage = 'url(' + sh.src + ')';
        el.style.backgroundSize = (sh.cols * 100) + '% ' + (sh.rows * 100) + '%';
        el.style.backgroundPosition = (c * fw) + '% ' + (r * fh) + '%';
        el.style.backgroundRepeat = 'no-repeat';
        if (img) img.style.opacity = '0';
      } else if (sh.folderFrames && sh.folderFrames.length) {
        const src = sh.folderFrames[sh.frame % sh.folderFrames.length];
        if (src) setActorCostume(ra, src);
      }
    } catch (e) { console.warn('sheet frame', e); }
  }

  function tickSpritesheets(dt) {
    try {
      (runtime.actors || []).forEach(function (ra) {
        if (!ra || !ra.data || !ra.data._sheet) return;
        const sh = ra.data._sheet;
        if (!sh.playing) return;
        sh.acc = (sh.acc || 0) + dt;
        const frameDur = 1000 / Math.max(1, sh.fps || 8);
        while (sh.acc >= frameDur) {
          sh.acc -= frameDur;
          sh.frame++;
          const total = sh.folderFrames ? sh.folderFrames.length : (sh.cols * sh.rows);
          if (sh.frame >= total) {
            if (sh.mode === 'loop') sh.frame = 0;
            else { sh.frame = total - 1; sh.playing = false; }
          }
          applySpritesheetFrame(ra);
        }
      });
    } catch (_) {}
  }


  function gameLoop(ts) {
    if (!runtime.running) return;
    const __kixFrameStart = performance.now();
    runtime._frame = (runtime._frame || 0) + 1;
    try { ensureVirtualControlsAlive(); } catch (_) {}
    const frameDelta = Math.max(1, Math.min(250, Number(ts - (runtime._lastFrameTs || ts)) || 16.67));
    runtime._lastFrameTs = ts;
    runtime.frameMs = runtime.frameMs * 0.9 + frameDelta * 0.1;
    runtime.fps = runtime.fps ? (runtime.fps * 0.9 + (1000 / frameDelta) * 0.1) : (1000 / frameDelta);
    if (!runtime._timer0) runtime._timer0 = ts;
    if (!runtime.paused) {
      runtime.elapsedMs = Math.max(0, ts - runtime._timer0);
      runtime.elapsedSeconds = runtime.elapsedMs / 1000;
    }
    if (runtime.showFps && (!runtime._fpsDomTs || ts - runtime._fpsDomTs >= 250)) { try { const fpsEl = document.getElementById('play-fps-display'); if (fpsEl) fpsEl.textContent = Math.max(0, Math.round(Number(runtime.fps) || 0)) + ' FPS'; runtime._fpsDomTs = ts; } catch (_) {} }
    if (!runtime.paused) {
      try { processCollisions(); } catch (_) {}
    }
    // Collision visualization is a diagnostic overlay. Do not touch the DOM every
    // frame when it is disabled; this matters on mobile and on large scenes.
    if (runtime.debugCollisions) { try { renderCollisionDebug(); } catch (_) {} }
    if (!runtime.paused) {
      try { applyEngineCamera(); } catch (_) {}
      try {
        const at = runtime._lookAnimTs || ts;
        const adt = Math.min(100, Math.max(0, ts - at));
        runtime._lookAnimTs = ts;
        tickLookAnimations(adt);
        tickLooksEffects(ts);
      } catch (_) {}
      try { tickSpritesheets(Math.min(100, Math.max(0, (runtime._sheetTs ? ts - runtime._sheetTs : 16)))); runtime._sheetTs = ts; } catch (_) {}
      try { updateParticles(frameDelta); } catch (_) {}
      try { updateHudTimer(); } catch (_) {}
      // Keep text visible on stage every frame
      try {
        for (let ti = 0; ti < (runtime.actors || []).length; ti++) {
          const ra = runtime.actors[ti];
          if (!ra || !ra.data) continue;
          const map = ra.data._texts && typeof ra.data._texts === 'object' ? ra.data._texts : (ra.data._text ? {texto1:ra.data._text} : {});
          for (const tid of Object.keys(map)) {
          const t = map[tid];
          if (!t || t.visible === false || (!t.content && !t.boundVar && !t.boundExpr)) continue;
          const el = getOrCreateTextEl(textActorId(ra,tid));
          if (!el) continue;
          if (t.boundExpr) {
            const v = evalExpr(t.boundExpr, {actor: ra.data, vars: ra.data._vars || {}, globals: runtime.globals});
            el.textContent = (t.boundPrefix || '') + (v == null ? '' : v);
          } else if (t.boundVar) {
            const v = runtime.globals[t.boundVar] != null ? runtime.globals[t.boundVar] : (ra.data._vars && ra.data._vars[t.boundVar]);
            el.textContent = (t.boundPrefix || '') + (v == null ? '' : v);
          } else if (!t._quotedMode) {
            if (el.textContent !== String(t.content)) el.textContent = String(t.content);
          } else if (t._quotedMode) {
            renderQuotedColorText(el, t.content, t._quoteBase, t._quoteCol);
          }
          if (t.pulse && !runtime.paused) {
            const p = t.pulse;
            t.style.scale = p.min + (p.max - p.min) * (0.5 + 0.5 * Math.sin((performance.now() / 1000) * p.speed * Math.PI * 2));
          }
          applyTextStyle(el, t.style);
          updateTextTransform(ra,tid);
          }
        }
      } catch (_) {}
      watchProEvents(ts);
      // Limit active coroutines for large projects
      const cos = runtime.coroutines;
      let live = 0;
      for (let i = 0; i < cos.length; i++) {
        if (cos[i].dead) continue;
        const beforeIp = cos[i].ip;
        try { stepCoroutine(cos[i], ts); } catch (err) {
          console.error('Erro no script do ator "' + (cos[i].actor && cos[i].actor.data && cos[i].actor.data.name || '?') + '":', err);
          cos[i].dead = true;
          try {
            if (typeof reportEngineError === 'function') {
              reportEngineError({ actor: cos[i].actor && cos[i].actor.data && cos[i].actor.data.name, error: err });
            }
          } catch (_) {}
        }
        // Safety watchdog: a normal action that accidentally leaves the instruction pointer on itself
        // for several frames must not freeze the script. Explicit waits/loops are exempt.
        try {
          const afterIp = cos[i].ip;
          if (!cos[i].dead && beforeIp && beforeIp === afterIp && !cos[i].waitUntil) {
            const tree = cos[i].tree;
            const stuckBlock = tree && tree.blocks && tree.blocks[afterIp];
            const bt = stuckBlock && stuckBlock.type;
            // Último bloco do corpo de um loop: voltar ao mesmo bloco a cada quadro é o comportamento normal.
            const loopTail = !!(cos[i].loopStack && cos[i].loopStack.length && stuckBlock && !stuckBlock.next);
            const intentional = loopTail || bt === 'loop' || bt === 'if' || /^(esperar|repetir|sempre|deslizar)/i.test(String(stuckBlock && stuckBlock.name || ''));
            if (!intentional) {
              if (cos[i]._stallIp === afterIp) cos[i]._stallFrames = (cos[i]._stallFrames || 0) + 1;
              else { cos[i]._stallIp = afterIp; cos[i]._stallFrames = 1; }
              if (cos[i]._stallFrames >= 6 && stuckBlock) {
                console.warn('[Kix] Auto-advance stalled block:', stuckBlock.name);
                cos[i].ip = stuckBlock.next || null;
                cos[i]._stallIp = null;
                cos[i]._stallFrames = 0;
              }
            } else {
              cos[i]._stallIp = null; cos[i]._stallFrames = 0;
            }
          } else {
            cos[i]._stallIp = null; cos[i]._stallFrames = 0;
          }
        } catch (_) {}
        live++;
        // soft cap: max 200 script steps groups per frame handled inside stepCoroutine
      }
      // compact dead coroutines every 30 frames
      if (runtime._frame % 30 === 0) {
        runtime.coroutines = cos.filter(c => !c.dead);
      }
      // Update sprites
      const acts = runtime.actors;
      for (let i = 0; i < acts.length; i++) {
        const ra = acts[i];
        if (ra && ra.data && (ra.data.vx || ra.data.vy)) {
          const dt = Math.max(0.1, Math.min(2.5, (Number(runtime.frameMs) || 16.67) / (1000 / 60)));
          ra.data.x = (Number(ra.data.x) || 0) + (Number(ra.data.vx) || 0) * dt;
          ra.data.y = (Number(ra.data.y) || 0) + (Number(ra.data.vy) || 0) * dt;
          ra._lastKey = null;
        }
        updateSpriteTransform(ra);
      }
    }
    const __kixFrameMs = performance.now() - __kixFrameStart;
    try {
      global.KixProfiler?.record?.('runtime.frame', __kixFrameMs);
      if (runtime._frame % 60 === 0) global.KixDebugger?.emit?.({type:'runtime.frame',time:runtimeNow(),frame:runtime._frame,frameMs:__kixFrameMs,fps:runtime.fps,coroutines:runtime.coroutines?.length||0});
    } catch (_) {}
    runtime.raf = kixRequestAnimationFrame(gameLoop);
  }

  
  
  function hexToRgb(hex) {
    if (hex == null) return null;
    let s = String(hex).trim().replace(/['"]/g, '');
    if (s.charAt(0) === '#') s = s.slice(1);
    if (s.indexOf('rgb') === 0) {
      const m = s.match(/(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);
      if (m) return { r: +m[1], g: +m[2], b: +m[3] };
    }
    if (s.length === 3) s = s[0]+s[0]+s[1]+s[1]+s[2]+s[2];
    if (s.length !== 6) return null;
    const n = parseInt(s, 16);
    if (isNaN(n)) return null;
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
  }


  function colorDist(a, b) {
    return Math.abs(a.r - b.r) + Math.abs(a.g - b.g) + Math.abs(a.b - b.b);
  }

  
  


  function snapshotActors() {
    runtime.initialSnapshots = runtime.actors.map(ra => {
      const src = resolveActorImage(ra.data);
      ra.data._origImage = src || null;
      return {
        x: ra.data.x,
        y: ra.data.y,
        direction: ra.data.direction,
        size: ra.data.size,
        visible: ra.data.visible !== false,
        costume: ra.data.costume || 0,
        layer: Number(ra.data.layer || 0),
        zIndex: Number(ra.data.zIndex || ra.data.layer || 0),
        name: ra.data.name,
        image: src || null
      };
    });
  }

  function restoreActors() {
    runtime.actors.forEach(ra => {
      ra._tapTimes = [];
      ra._tapStreak = 0;
      ra._lastFiredStreak = null;
      ra._lastFiredFlat = null;
    });

    runtime.actors.forEach((ra, i) => {
      const s = runtime.initialSnapshots[i];
      if (!s) return;
      ra.data.x = s.x;
      ra.data.y = s.y;
      ra.data.direction = s.direction;
      ra.data.size = s.size;
      ra.data.visible = s.visible;
      ra.data.costume = s.costume;
      ra.data.layer = Number(s.layer || 0);
      ra.data.zIndex = Number(s.zIndex || s.layer || 0);
      if (ra.el) ra.el.style.zIndex = String(ra.data.zIndex);
      ra.data.vx = 0;
      ra.data.vy = 0;
      // Reset visual color effects
      ra.el.style.filter = '';
      ra.data._tintFilter = null;
      ra.data._colorSwaps = [];
      ra._lastKey = null;
      const desired = ra.data._origImage || s.image || null;
      const validDesired = desired && appearanceEntries(ra.data).some(e => e.src === assetSrc(desired));
      const orig = validDesired ? assetSrc(desired) : resolveActorImage(ra.data);
      ra.data._origImage = orig || null;
      ra.data._lastGoodImage = null;
      ra.data._swapBase = orig || null;
      if (orig) {
        setActorCostume(ra, orig);
      } else {
        const img = ra.el.querySelector('img');
        try { img?.remove(); } catch (_) {}
        ra.el.dataset.noImage = '1';
        ra.data.image = null;
      }
      updateSpriteTransform(ra);
    });
  }

  function stagePointToWorld(clientX, clientY) {
    const stage = runtime.stageEl || document.getElementById('play-stage');
    if (!stage || !stage.getBoundingClientRect) return { x: 0, y: 0 };
    const r = stage.getBoundingClientRect();
    const dx = Number(clientX) - (r.left + r.width / 2);
    const dy = Number(clientY) - (r.top + r.height / 2);
    const rot = Number(runtime._stagePresentationRotation || 0) * Math.PI / 180;
    const cos = Math.cos(-rot), sin = Math.sin(-rot);
    const ux = dx * cos - dy * sin;
    const uy = dx * sin + dy * cos;
    const scale = Math.max(0.0001, Number(runtime._playLockedWorldScale || 1));
    return { x: ux / scale, y: -(uy / scale) };
  }

  function setupStageTouch() {
    const stage = runtime.stageEl;
    if (!stage || stage._touchBound) return;
    stage._touchBound = true;
    stage.style.touchAction = 'none';

    const toLocal = (clientX, clientY) => stagePointToWorld(clientX, clientY);
    const visibleObjects = () => (runtime.actors || []).filter(ra => ra && ra.data && ra.data.visible !== false && !ra.data.isBackground && !ra.data.isCamera);
    const hit = p => {
      const objects = visibleObjects();
      for (const ra of objects) if (pointInActorBounds(ra, p.x, p.y)) return ra;
      return null;
    };
    const updatePoint = e => {
      let t = e;
      if (e && e.touches) t = e.touches[0];
      if (!t) return null;
      const p = toLocal(t.clientX, t.clientY);
      runtime.touch.x = p.x;
      runtime.touch.y = p.y;
      runtime.touch.lastFingerIndex = Number(t.pointerId != null ? t.pointerId : 0) || 0;
      return p;
    };
    const down = e => {
      if (e && e.pointerType === 'mouse' && e.button !== 0) return;
      const p = updatePoint(e); if (!p) return;
      if (e && e.cancelable) e.preventDefault();
      try { if (e.pointerId != null && stage.setPointerCapture) stage.setPointerCapture(e.pointerId); } catch (_) {}
      runtime.touch.down = true;
      runtime.touch.active = true;
      runtime.touch.targetActor = hit(p);
      runtime.touch.targetActorId = runtime.touch.targetActor ? runtime.touch.targetActor.id : null;
      runtime.touch.targetActorIndex = runtime.touch.targetActor ? runtime.touch.targetActor.index : -1;
      runtime._suppressActorClickUntil = performance.now() + 700;
      try { (runtime.actors || []).forEach(ra => startHatsFor(ra, 'Quando a tela for pressionada')); } catch (_) {}
      try { if (runtime.touch.targetActor) startHatsFor(runtime.touch.targetActor, 'Quando tocado'); } catch (_) {}
    };
    const move = e => {
      const p = updatePoint(e); if (!p) return;
      if (!runtime.touch.down) return;
      if (e && e.cancelable) e.preventDefault();
      try { (runtime.actors || []).forEach(ra => startHatsFor(ra, 'Quando o dedo mover na tela')); } catch (_) {}
      try { const over = hit(p); if (over) startHatsFor(over, 'Quando o dedo mover sobre o sprite'); } catch (_) {}
    };
    const up = e => {
      if (e && e.cancelable) e.preventDefault();
      const target = runtime.touch.targetActor || (runtime.touch.targetActorIndex >= 0 ? runtime.actors[runtime.touch.targetActorIndex] : null);
      runtime.touch.down = false;
      runtime.touch.active = false;
      try { if (e && e.pointerId != null && stage.releasePointerCapture) stage.releasePointerCapture(e.pointerId); } catch (_) {}
      try { if (target) startHatsFor(target, 'Quando o sprite for solto'); } catch (_) {}
      runtime.touch.targetActor = null;
      runtime.touch.targetActorId = null;
      runtime.touch.targetActorIndex = -1;
    };

    if (typeof window.PointerEvent === 'function') {
      stage.addEventListener('pointerdown', down, { passive:false });
      stage.addEventListener('pointermove', move, { passive:false });
      stage.addEventListener('pointerup', up, { passive:false });
      stage.addEventListener('pointercancel', up, { passive:false });
    } else {
      stage.addEventListener('touchstart', down, { passive:false });
      stage.addEventListener('touchmove', move, { passive:false });
      stage.addEventListener('touchend', up, { passive:false });
      stage.addEventListener('touchcancel', up, { passive:false });
      stage.addEventListener('mousedown', down, { passive:false });
      stage.addEventListener('mousemove', move, { passive:false });
      window.addEventListener('mouseup', up, { passive:false });
    }
  }

  function installOrientationGuard() {
    if (runtime._orientationGuardInstalled) return;
    runtime._orientationGuardInstalled = true;
    const refresh = function () {
      if (!runtime.running) return;
      // Layout-only signal: recenter the immutable logical stage. Never edit actor state.
      try { syncStageLayout(); } catch (_) {}
      try { (runtime.actors || []).forEach(function (ra) { if (ra) { ra._lastKey = null; updateSpriteTransform(ra, true); } }); } catch (_) {}
    };
    try { window.addEventListener('orientationchange', refresh, { passive: true }); } catch (_) {}
    try { window.addEventListener('resize', refresh, { passive: true }); } catch (_) {}
    try { window.visualViewport && window.visualViewport.addEventListener('resize', refresh, { passive: true }); } catch (_) {}
  }

  window.KixOrientationGuard = { refresh: function(){ try { syncStageLayout(); } catch (_) {} } };

  function startEngine(project, sceneIndex, globals, options) {
    stopEngine();
    // The host normally normalizes the project before execution. Keep one
    // additional integration guard here so direct engine callers cannot bypass
    // the mandatory Catroid/NewCatroid compatibility binding. This delegates to
    // the existing host bridge; no second plugin registry is created here.
    try { global.KixPluginRuntime?.ensureBuiltinPlugins?.(); } catch (_) {}
    try {
      if (global.KixCatroidCompatibility?.isCatrobatProject?.(project)) {
        global.KixCatroidCompatibility.ensureProject(project);
      }
    } catch (_) {}
    runtime.project = project;
    try { global.KixPhase3Runtime?.init?.(project); } catch (e) { try { global.KixDiagnostics?.report?.('PHASE3_INIT', String(e?.message || e)); } catch (_) {} }
    const projectPlugins = Array.isArray(project?.plugins) ? project.plugins : [];
    runtime.catroidCompatibility = {
      enabled: projectPlugins.some(p=>p&&p.id==='kix.catroid.compat'&&p.enabled!==false),
      pluginId: global.KixCatroidCompatibility?.pluginId || 'kix.catroid.compat',
      version: global.KixCatroidCompatibility?.pluginVersion || '1.0.0'
    };
    installOrientationGuard();
    try {
      const files=Array.isArray(project?.files)?project.files:[];
      files.filter(f=>f&&f.dataUrl&&(f.kind==='font'||/\.(ttf|otf|woff2?|ttc)$/i.test(String(f.name||'')))).forEach(f=>{
        const fam=String(f.fontFamily||f.name||'KixFont').replace(/\.[^.]+$/,'').replace(/[^a-zA-Z0-9_\- ]/g,'_')||'KixFont';
        try { const face=new FontFace(fam,'url('+f.dataUrl+')'); face.load().then(ff=>{try{document.fonts.add(ff);}catch(_){} }).catch(()=>{}); } catch(_) {}
      });
    } catch(_) {}
    runtime._logicalStageW = Number(project?.catrobatStage?.width || project?.stage?.width || (String(project?.orientation||'portrait').toLowerCase()==='landscape'?800:480));
    runtime._logicalStageH = Number(project?.catrobatStage?.height || project?.stage?.height || (String(project?.orientation||'portrait').toLowerCase()==='landscape'?480:800));
    runtime._stageScaleX = 1;
    runtime._stageScaleY = 1;
    runtime._stageOffsetX = 0;
    runtime._stageOffsetY = 0;
    runtime._usesCatrobatStage = !!project?.catrobatStage;
    applyProjectOrientation(project);
    const engineOptions = options && typeof options === 'object' ? options : {};
    runtime.running = true;
    try { global.KixDebugger?.emit?.({type:'runtime.start',time:runtimeNow(),mode:String(engineOptions.mode||'play')}); } catch (_) {}
    runtime.paused = engineOptions.mode === 'visual-position';
    runtime.mode = String(engineOptions.mode || 'play');
    runtime._skipSceneStart = engineOptions.mode === 'visual-position' || engineOptions.skipSceneStart === true;
    runtime.globals = globals || {};
    try {
      const sc=project?.scenes?.[sceneIndex] || project?.scenes?.[0];
      runtime.sceneEmitters=(sc?.particleEmitters||[]).map(em=>{const x=Object.assign({},em);x.active=x.enabled!==false;x._acc=0;x._fired=false;return x;});
      (runtime.sceneEmitters||[]).forEach(em=>{if(!em.oneShot)em._fired=false;});
    } catch(_) { runtime.sceneEmitters=[]; }
    runtime.catrobat = { sound:{tempo:120,instrument:'piano'}, plot:{active:false,paths:[],lastByActor:{}}, embroidery:{threadColor:'#000000',commands:[],running:false}, looks:{cameraFacing:'environment',cameraStream:null,cameraVideo:null,cameraCanvas:null} };
    runtime.coroutines = [];
    runtime._imageCache = globalImageCache;
    runtime._imageLoads = globalImageLoads;
    runtime.camX = 0;
    runtime.camY = 0;
    runtime.camZoom = 1;
    runtime.cameraWorldX = 0;
    runtime.cameraWorldY = 0;
    runtime.camZoomMin = 0.25;
    runtime.camZoomMax = 4;
    runtime.camRot = 0;
    runtime.fps = 0; runtime.frameMs = 16.67; runtime.elapsedMs = 0; runtime.elapsedSeconds = 0; runtime.showFps = false;
    runtime._lastFrameTs = 0; runtime._lookAnimTs = 0;
    runtime._camFollow = null;
    runtime._camFollowTouch = false;
    runtime.freeCam = false;
    runtime._camFree = false;
    runtime._camShake = null;
    runtime._camGlide = null;
    runtime._zoomGlide = null;
    buildStage(project, sceneIndex);
    try { ensureControlsRoot(); ensureHud(); ensureTextLayer(); } catch (_) {}
    snapshotActors();
    setupStageTouch();
    // Let the stage paint before starting sensors and scene-start scripts.
    // This reduces the visible hitch when starting/restarting larger scenes.
    const launchSceneScripts = () => {
      if (!runtime.running) return;
      if (runtime._skipSceneStart) return;
      try { startDeviceSensors(); } catch (_) {}
      try { runtime.actors.forEach(ra => startHatsFor(ra, 'Quando a cena começar')); } catch (_) {}
    };
    if (typeof requestAnimationFrame === 'function') kixRequestAnimationFrame(() => {
      try { syncStageLayout(); } catch (_) {}
      kixSetTimeout(launchSceneScripts, 0);
    });
    else kixSetTimeout(() => { try { syncStageLayout(); } catch (_) {} launchSceneScripts(); }, 0);
    // Safety: force text facilitators onto stage if script had them
    // Safety only refreshes text already set by scripts (does not skip Esperar)
    kixSetTimeout(() => {
      try {
        if (!runtime.running) return;
        runtime.actors.forEach(ra => { try { refreshActorText(ra); } catch(_){} });
      } catch (e) { console.warn('text safety', e); }
    }, 50);
    try {
      const st = document.getElementById('play-status');
      if (st) st.style.display = 'none';
    } catch (_) {}
    runtime.raf = kixRequestAnimationFrame(gameLoop);
  }

  function stopAll() {
    try {
      if (runtime.coroutines) {
        runtime.coroutines.forEach(c => { if (c) c.dead = true; });
        runtime.coroutines = [];
      runtime._collisionBounds = []; runtime._collisionBoundsFrame = -1; runtime._collisionDebugEls = new Map(); runtime._collisionDebugFrame = -1;
    runtime.camX = runtime.camX || 0;
    runtime.camY = runtime.camY || 0;
    runtime.camZoom = runtime.camZoom || 1;
    runtime._camFollow = null;
    runtime._camShake = null;
      }
      // stop web audio if any
      if (runtime.sounds && runtime.sounds.length) {
        runtime.sounds.forEach(s => {
          try { if (s && s.pause) s.pause(); } catch (_) {}
        });
        runtime.sounds = [];
      }
      stopPreviewSound();
      runtime.messages = [];
    } catch (e) {
      console.warn('stopAll', e);
      runtime.coroutines = [];
    runtime.camX = runtime.camX || 0;
    runtime.camY = runtime.camY || 0;
    runtime.camZoom = runtime.camZoom || 1;
    runtime._camFollow = null;
    runtime._camShake = null;
    }
  }

  function stopEngine() {
    try { global.KixPhase3Runtime?.stop?.(); } catch (_) {}
    try { if (runtime.running) global.KixDebugger?.emit?.({type:'runtime.stop',time:runtimeNow(),frame:runtime._frame||0}); } catch (_) {}
    // Phase 2 lifecycle invariant: no runtime-owned timer may survive a stop/restart.
    kixClearScope();
    try { window.closeAllRuntimeInputOverlays?.(true); } catch (_) {}
    try { clearVirtualControls(); } catch (_) {}
    try { clearAllHud(); } catch (_) {}

    // Clear ALL on-stage text (so deleted scripts don't leave ghosts)
    try {
      const layer = document.getElementById('kix-text-layer') || document.querySelector('.kix-text-layer');
      if (layer) layer.innerHTML = '';
      document.querySelectorAll('[id^="kix-text-"], .kix-actor-text, .kix-text-el').forEach(function (el) {
        try { if (el.parentNode) el.parentNode.removeChild(el); } catch (_) {}
      });
      if (runtime.actors) {
        runtime.actors.forEach(function (ra) {
          if (ra && ra.data) {
            ra.data._text = null;
            delete ra.data._text;
          }
        });
      }
    } catch (_) {}

    // Reset camera
    try {
      runtime.camX = 0;
      runtime.camY = 0;
      runtime.camZoom = 1;
      runtime.cameraWorldX = 0;
      runtime.cameraWorldY = 0;
      runtime.camZoomMin = 0.25;
      runtime.camZoomMax = 4;
      runtime.camRot = 0;
      runtime.fps = 0; runtime.frameMs = 16.67; runtime.elapsedMs = 0; runtime.elapsedSeconds = 0; runtime.showFps = false;
      runtime._camFollow = null;
      runtime._camShake = null;
      runtime._camGlide = null;
      runtime._zoomGlide = null;
      runtime.camOffsetX = 0;
      runtime.camOffsetY = 0;
      runtime._timer0 = 0; runtime._lastFrameTs = 0; runtime._lookAnimTs = 0; runtime._lastCamKey = '';
      const stage = runtime.stageEl || document.getElementById('play-stage');
      if (stage) {
        stage.style.transform = '';
      }
    } catch (_) {}

    try {
      if (runtime.particles) {
        runtime.particles.forEach(function (p) { try { if (p.el && p.el.parentNode) p.el.parentNode.removeChild(p.el); } catch(_){} });
        runtime.particles = [];
      }
      if (runtime._particleLayer && runtime._particleLayer.parentNode) {
        try { runtime._particleLayer.innerHTML = ''; } catch(_){}
      }
      runtime.actors && runtime.actors.forEach(function (ra) {
        if (ra && ra.data && ra.data._emitter) ra.data._emitter.active = false;
      });
    } catch (_) {}

    try {
      try { runtime._stageResizeObserver && runtime._stageResizeObserver.disconnect(); } catch (_) {}
      runtime._stageResizeObserver = null;
      runtime._stageResizeSyncing = false;
      runtime._playViewportLocked = false;
      runtime._playLockedStageW = 0;
      runtime._playLockedStageH = 0;
      runtime._playLockedWorldScale = 1;
      runtime._playLockedLogicalW = 0;
      runtime._playLockedLogicalH = 0;
      runtime._playLockedPresentationOrientation = '';
      runtime._lastViewportWidth = 0;
      runtime._lastViewportHeight = 0;
      runtime._stagePresentationOrientation = '';
      runtime._stagePresentationRotation = 0;
      try { delete document.documentElement.dataset.kixRotation; } catch (_) {}
      runtime.running = false;
      runtime.paused = false;
      runtime.mode = 'idle';
      runtime._skipSceneStart = false;
      runtime.sceneEmitters = [];
      runtime.tilemaps = [];
      runtime.tilemap = null;
      runtime._tilemapLayer = null;
      if (runtime.raf) kixClearTimer(runtime.raf);
      runtime.raf = null;
      runtime.coroutines = [];
    runtime.camX = runtime.camX || 0;
    runtime.camY = runtime.camY || 0;
    runtime.camZoom = runtime.camZoom || 1;
    runtime._camFollow = null;
    runtime._camShake = null;
      runtime.messages = [];
      try { stopAllLookAnimations(); } catch (_) {}
      try {
        (runtime.sounds || []).forEach(a => { try { a.pause(); } catch (_) {} });
        runtime.sounds = [];
        if (window.speechSynthesis) window.speechSynthesis.cancel();
      } catch (_) {}
      runtime.soundVolume = 1;
      runtime.soundPitch = 1;
      runtime.soundLoop = false;
      runtime.lists = {};
      runtime.varVisible = {};
      try {
        const ov = document.getElementById('kix-var-overlay');
        if (ov) ov.innerHTML = '';
      } catch (_) {}
      try {
        const stage = runtime.stageEl || document.getElementById('play-stage');
        if (stage) {
          const layer = stage.querySelector('.kix-text-layer');
          if (layer) layer.innerHTML = '';
        }
        const orphan = document.getElementById('kix-text-layer-root');
        if (orphan) orphan.innerHTML = '';
      } catch (_) {}
      (runtime.actors || []).forEach(ra => {
        if (!ra) return;
        try { stopLookAnimation(ra); } catch (_) {}
        ra._tapTimes = [];
        ra._tapStreak = 0;
        ra._lastKey = null;
        ra._animPlaying = false;
        ra._lookAnim = null;
        ra._animFrames = [];
        ra._animFolder = null;
        ra._animDone = false;
        if (ra.data) {
          Object.keys(ra.data).forEach(k => {
            if (/^(_mt_fired_|_reg_|_t_|_fps_|_var_|_loop)/.test(k)) delete ra.data[k];
          });
          if (ra.data._text) {
            ra.data._text.pulse = null;
            ra.data._text.textAnim = null;
            ra.data._text.gradAnim = null;
            ra.data._text.boundVar = null;
          }
          ra.data._loopFolders = {};
          ra.data._activeLoopFolder = null;
          delete ra.data._blinkSpec;
          if (ra.data._text) { ra.data._text.boundExpr = null; ra.data._text._quotedMode = false; }
          delete ra.data._fadeSpec;
          delete ra.data._flashUntil;
          // keep _colorSwap? clear on hard reset
          ra.data._colorSwap = null;
          ra.data._colorSwaps = [];
          ra.data._swapCache = {};
          ra.data._origImage = null;
        }
      });
      try { restoreActors(); } catch (_) {}
      (runtime.actors || []).forEach(ra => {
        try { updateSpriteTransform(ra, true); } catch (_) {}
      });
    } catch (e) {
      console.error('stopEngine', e);
    }
  }

  function restartEngine(project, sceneIndex, globals) {
    try {
      // startEngine already performs the single required stop/reset. Avoid the old
      // double-stop + DOM clear cycle, which caused a visible hitch on mobile.
      startEngine(project, sceneIndex, globals || {});
    } catch (e) {
      console.error('restartEngine', e);
    }
  }

  function togglePause() {
    runtime.paused = !runtime.paused;
    runtime._lastFrameTs = performance.now(); runtime._lookAnimTs = runtime._lastFrameTs; runtime._sheetTs = runtime._lastFrameTs;
    try {
      if (runtime.paused) {
        runtime._pausedMedia=[];
        (runtime.sounds||[]).forEach(s=>{if(s&&typeof s.pause==='function'&&!s.paused){runtime._pausedMedia.push(s);try{s.pause();}catch(_){}}});
        if(window.speechSynthesis&&window.speechSynthesis.pause){try{window.speechSynthesis.pause();runtime._speechWasPlaying=true;}catch(_) {}}
        try { document.querySelectorAll('#play-stage *, #kix-hud-root *, .kix-text-layer *').forEach(el=>{ if(el.style) el.style.animationPlayState='paused'; }); } catch(_) {}
      } else {
        (runtime._pausedMedia||[]).forEach(s=>{try{const p=s&&s.play?s.play():null;if(p&&p.catch)p.catch(()=>{});}catch(_){}}); runtime._pausedMedia=[];
        if(runtime._speechWasPlaying&&window.speechSynthesis&&window.speechSynthesis.resume){try{window.speechSynthesis.resume();}catch(_){}} runtime._speechWasPlaying=false;
        try { document.querySelectorAll('#play-stage *, #kix-hud-root *, .kix-text-layer *').forEach(el=>{ if(el.style) el.style.animationPlayState='running'; }); } catch(_) {}
      }
    } catch (_) {}
    return runtime.paused;
  }

  // Built-in deterministic smoke test. It validates the interpreter without touching the user's project.
  function selfTest() {
    const results = [];
    const saved = {
      actors: runtime.actors, stageEl: runtime.stageEl, presets: runtime._presets, controlsRoot: runtime._controlsRoot, hudRoot: runtime._hudRoot,
      hud: runtime.hud, sounds: runtime.sounds, previewAudio: runtime.previewAudio, soundVolume: runtime.soundVolume, soundPitch: runtime.soundPitch, soundLoop: runtime.soundLoop, globals: runtime.globals, camX: runtime.camX, camY: runtime.camY, camZoom: runtime.camZoom, camRot: runtime.camRot,
      freeCam: runtime.freeCam, camFree: runtime._camFree, touch: runtime.touch, fps: runtime.fps, frameMs: runtime.frameMs,
      cameraWorldX: runtime.cameraWorldX, cameraWorldY: runtime.cameraWorldY, elapsedSeconds: runtime.elapsedSeconds, elapsedMs: runtime.elapsedMs, project: runtime.project
    };
    const sandbox = document.createElement('div');
    sandbox.id = 'kix-selftest-sandbox';
    sandbox.style.cssText = 'position:fixed;left:-10000px;top:-10000px;width:480px;height:800px;overflow:hidden;pointer-events:none;';
    const sandboxStage = document.createElement('div');
    sandboxStage.id = 'kix-selftest-stage';
    sandbox.appendChild(sandboxStage);
    const liveCanvas = document.getElementById('play-canvas');
    const liveControlRootsBefore = liveCanvas ? liveCanvas.querySelectorAll('#kix-controls-root').length : 0;
    try { document.body.appendChild(sandbox); } catch (_) {}
    // From this point on, every test gets its own runtime state. The user's running scene,
    // controls, HUD, globals and touch state are never borrowed or temporarily moved.
    runtime.actors = [];
    runtime.sounds = [];
    runtime.previewAudio = null;
    runtime.soundVolume = 1;
    runtime.soundPitch = 1;
    runtime.soundLoop = false;
    runtime.stageEl = sandboxStage;
    runtime._controlsRoot = null;
    runtime._hudRoot = null;
    runtime._presets = null;
    runtime.hud = null;
    runtime.globals = {};
    runtime.touch = {x:0,y:0,down:false,active:false};
    const check = (name, fn) => { try { const value = fn(); results.push({name, ok: value !== false}); } catch (e) { results.push({name, ok:false, error:String(e && e.message || e)}); } };
    try {
    check('runtime', () => !!runtime && Array.isArray(runtime.actors));
    check('data object scope isolates objects', () => {
      runtime.project = { dataDefinitions: [{id:'d1',name:'score',value:0,scope:'object',valuesByActor:{}}] };
      const a={id:'a'}; const b={id:'b'};
      runtimeDataSet('score',7,a);
      return runtimeDataGet('score',a,null)===7 && runtimeDataGet('score',b,null)===0;
    });
    check('data project scope is shared', () => {
      runtime.project = { dataDefinitions: [{id:'d2',name:'coins',value:3,scope:'project',valuesByActor:{}}] };
      const a={id:'a'}; const b={id:'b'};
      runtimeDataSet('coins',9,a);
      return runtimeDataGet('coins',a,null)===9 && runtimeDataGet('coins',b,null)===9;
    });
    check('data formula arithmetic uses current values', () => {
      runtime.project = { dataDefinitions: [
        {id:'da',name:'a',value:12,scope:'project',valuesByActor:{}},
        {id:'db',name:'b',value:7,scope:'project',valuesByActor:{}}
      ] };
      runtime.globals = {a:12,b:7};
      return evalExpr('a + b', {vars:{}, globals:runtime.globals}) === 19;
    });
    check('data formula follows rapidly changing current value', () => {
      runtime.project = { dataDefinitions: [{id:'df',name:'fast',value:1,scope:'project',valuesByActor:{}}] };
      runtime.globals = {fast:1};
      const first = evalExpr('fast + 2', {vars:{}, globals:runtime.globals});
      runtimeDataSet('fast',98,{id:'probe'});
      const second = evalExpr('fast + 2', {vars:{}, globals:runtime.globals});
      return first === 3 && second === 100;
    });
    check('script migration', () => { const t=migrateScripts([{id:'a',name:'Mostrar'},{id:'b',name:'Mover X passos'}]); return t.blocks.a && t.blocks.b; });
    check('folder animation resolver', () => getFolderFrames({folders:[{name:'Run',looks:['a','b']} ]}, 'Run').length===2);
    check('folder object asset resolver', () => getFolderFrames({folders:[{name:'Run',looks:[{dataUrl:'a'},{src:'b'}]}]}, 'Run').join(',')==='a,b');
    check('sound playback and preview dispatch', () => {
      const SavedAudio = global.Audio;
      const created = [];
      class TestAudio {
        constructor(src){ this.src=src; this.volume=1; this.playbackRate=1; this.loop=false; this.paused=true; this.currentTime=0; this.listeners={}; created.push(this); }
        play(){ this.paused=false; return Promise.resolve(); }
        pause(){ this.paused=true; }
        addEventListener(n,fn){ (this.listeners[n]||(this.listeners[n]=[])).push(fn); }
        dispatch(n){ (this.listeners[n]||[]).slice().forEach(fn=>fn()); }
      }
      const ra={data:{name:'SoundTest',sounds:[{name:'probe.wav',data:'data:audio/wav;base64,UklGRgAAAAA='}],_vars:{}},el:document.createElement('div')};
      runtime.actors=[ra]; runtime.sounds=[]; runtime.previewAudio=null; runtime.soundVolume=1; runtime.soundPitch=1; runtime.soundLoop=false;
      global.Audio=TestAudio;
      let co={actor:ra,blocks:{a:{id:'a',name:'Tocar som',values:{som:"'probe.wav'"},next:null}},tree:{blocks:{}},ip:'a',waitUntil:0,dead:false,loopStack:[]};
      co.tree.blocks=co.blocks; stepCoroutine(co,1000);
      const playOk=created.length===1 && runtime.sounds.length===1 && co.dead===true;
      const waitBlock={id:'w',name:'Tocar som e esperar terminar',values:{som:"'probe.wav'"},next:'after'};
      const afterBlock={id:'after',name:'Definir variável para',values:{variável:'afterAudio',valor:7},next:null};
      co={actor:ra,blocks:{w:waitBlock,after:afterBlock},tree:{blocks:{w:waitBlock,after:afterBlock}},ip:'w',waitUntil:0,dead:false,loopStack:[]};
      stepCoroutine(co,1000); const waitAudio=created[created.length-1]; waitAudio.dispatch('ended');
      const waitOk=co.waitUntil===0 && co.ip==='after';
      stepCoroutine(co,120001); const chainOk=co.dead===true && runtime.globals.afterAudio===7;
      const previewResult=previewSound(ra.data.sounds[0]);
      const previewOk=runtime.previewAudio && runtime.previewAudio.src===ra.data.sounds[0].data && previewResult && typeof previewResult.then==='function';
      stopPreviewSound(); runtime.sounds=[]; global.Audio=SavedAudio; return !!(playOk&&waitOk&&chainOk&&previewOk);
    });
    check('animation start is non-blocking', () => { const fakeEl={innerHTML:'',_img:null,dataset:{},querySelector(){return this._img;},appendChild(n){this._img=n;return n;}}; const ra={data:{folders:[{name:'Run',looks:['a','b']}],looks:['a'],_animSpeed:12,_colorSwaps:[],_swapCache:{}},el:fakeEl}; return !!startLookAnimation(ra,'Run',{loop:true,speed:12}) && !!ra._lookAnim && ra._lookAnim.loop===true; });
    check('appearance numeric resolver', () => resolveLook({looks:['a','b']},2,{numericOneBased:true}).src==='b');
    check('animation can advance frames', () => { const fakeEl={innerHTML:'',_img:null,dataset:{},querySelector(){return this._img;},appendChild(n){this._img=n;return n;}}; const ra={data:{folders:[{name:'Run',looks:['a','b']}],looks:['a'],_animSpeed:10,_colorSwaps:[],_swapCache:{}},el:fakeEl}; runtime.actors.push(ra); startLookAnimation(ra,'Run',{loop:true,speed:10}); const before=ra._animFrame; tickLookAnimations(110); const ok=ra._animFrame!==before; runtime.actors.pop(); return ok; });
    check('appearance → data chain', () => { const fakeEl=document.createElement('div'); const img=document.createElement('img'); fakeEl.appendChild(img); const ra={data:{looks:['a'],folders:[{name:'Run',looks:['a','b']}],size:100,_vars:{}},el:fakeEl}; const tree={blocks:{a:{id:'a',name:'Tocar animação',values:{pasta:'Run',modo:'loop',fps:10},next:'b'},b:{id:'b',name:'Definir variável para',values:{variável:'qa',valor:1},next:null}}}; const co={actor:ra,blocks:tree.blocks,tree,ip:'a',waitUntil:0,dead:false,loopStack:[]}; runtime.actors.push(ra); const t0=performance.now(); stepCoroutine(co,t0); stepCoroutine(co,t0+1); const ok=runtime.globals.qa===1 && co.ip===null; runtime.actors.pop(); return ok; });
    check('collision normalization', () => ['rect','circle','pixel'].includes('rect'));
    check('camera state', () => { runtime.camX=0; runtime.camY=0; runtime.camZoom=1; return runtime.camZoom===1; });
    check('expression arithmetic', () => evalExpr('2+3*4', {vars:{}})===14);
    check('expression touch y', () => { runtime.touch.y=321; return evalExpr('valor toque y', {vars:{}})===321; });
    check('expression touch y arithmetic', () => { runtime.touch.y=321; return evalExpr('valor toque y + 9', {vars:{}})===330; });
    check('expression actor x', () => evalExpr('posição x + 5', {actor:{x:7},vars:{}})===12);
    check('expression FPS', () => { runtime.fps=59.4; return Math.round(evalExpr('FPS',{vars:{}}))===59; });
    check('expression NOT', () => evalExpr('NÃO(0)', {vars:{}})===1 && evalExpr('NÃO(1)', {vars:{}})===0);
    check('expression AND/OR', () => evalExpr('E(1,1) + OU(0,1)', {vars:{}})===2);
    check('expression variable function', () => evalExpr('valor("score") + 2', {vars:{score:8}})===10);
    check('expression text concat', () => evalExpr('juntar("FPS: ", FPS)', {vars:{}}).startsWith('FPS: '));
    check('expression conditional', () => evalExpr('se(1,42,7)', {vars:{}})===42 && evalExpr('se(0,42,7)', {vars:{}})===7);
    check('expression camera center', () => { runtime.camX=-10; runtime.camY=20; runtime.stageEl={_stageW:480,_stageH:800}; return evalExpr('centro x da câmera',{vars:{}})===250 && evalExpr('centro y da câmera',{vars:{}})===420; });
    check('expression FPS formula', () => { runtime.fps=72; return evalExpr('fps()',{vars:{}})===72; });
    check('quoted text renderer exists', () => typeof renderQuotedColorText === 'function');
    check('camera getter state', () => { runtime.camZoom=1.75; return evalExpr('zoom da câmera',{vars:{}})===1.75; });
    check('camera zoom limits', () => { runtime.camZoomMin=0.5; runtime.camZoomMax=2; runtime.camZoom=5; applyEngineCamera(); return runtime.camZoom<=2; });
    check('camera free toggle state', () => { runtime.freeCam=true; runtime._camFree=true; runtime.freeCam=false; runtime._camFree=false; return !runtime.freeCam && !runtime._camFree; });
    check('camera world origin', () => { runtime.camX=0; runtime.camY=0; runtime.cameraWorldX=-runtime.camX; runtime.cameraWorldY=runtime.camY; return runtime.cameraWorldX===0 && runtime.cameraWorldY===0; });
    check('camera origin layout 1', () => { const p=document.createElement('div'); const s=document.createElement('div'); document.body.appendChild(p); p.appendChild(s); Object.defineProperty(p,'clientWidth',{configurable:true,value:400}); Object.defineProperty(p,'clientHeight',{configurable:true,value:700}); s.parentElement=p; runtime.stageEl=s; runtime.camX=0; runtime.camY=0; runtime.actors=[]; const ok=syncStageLayout() && s._stageW===400 && s._stageH===700; p.remove(); return ok; });
    check('camera origin layout 2', () => { const p=document.createElement('div'); const s=document.createElement('div'); document.body.appendChild(p); p.appendChild(s); Object.defineProperty(p,'clientWidth',{configurable:true,value:412}); Object.defineProperty(p,'clientHeight',{configurable:true,value:760}); runtime.stageEl=s; runtime.actors=[{data:{x:0,y:0},el:document.createElement('div')}]; runtime.camX=0; runtime.camY=0; const ok=syncStageLayout() && s._stageW===412 && s._stageH===760; p.remove(); return ok; });
    check('camera origin layout 3', () => { runtime.camX=0; runtime.camY=0; runtime.cameraWorldX=0; runtime.cameraWorldY=0; return runtime.cameraWorldX===0 && runtime.cameraWorldY===0; });
    check('camera origin layout 4', () => { const p=document.createElement('div'); const s=document.createElement('div'); document.body.appendChild(p); p.appendChild(s); Object.defineProperty(p,'clientWidth',{configurable:true,value:360}); Object.defineProperty(p,'clientHeight',{configurable:true,value:640}); runtime.stageEl=s; runtime.actors=[{data:{x:0,y:0},el:document.createElement('div')}]; runtime.camX=0; runtime.camY=0; const ok=syncStageLayout() && s._stageW/2===180 && s._stageH/2===320; p.remove(); return ok; });
    check('camera origin layout 5', () => { runtime.camX=0; runtime.camY=0; runtime.cameraWorldX=-runtime.camX; runtime.cameraWorldY=runtime.camY; return runtime.cameraWorldX===0 && runtime.cameraWorldY===0; });
    check('camera world X is not render translation', () => { runtime.camX=-120; runtime.camY=35; runtime.cameraWorldX=-runtime.camX; runtime.cameraWorldY=runtime.camY; return runtime.cameraWorldX===120 && runtime.cameraWorldY===35; });
    check('camera does not mutate actor world position', () => {
      const ra={data:{x:75,y:-20,vx:0,vy:0,visible:true},el:document.createElement('div')};
      runtime.stageEl={_stageW:400,_stageH:700}; runtime.camX=120; runtime.camY=-60;
      updateSpriteTransform(ra);
      return ra.data.x===75 && ra.data.y===-20;
    });
    check('default actor position is origin', () => { const a=ensureActorState({},7); return a.x===0 && a.y===0; });
    check('camera follows touch', () => { runtime.stageEl={_stageW:480,_stageH:800,style:{},querySelector(){return null;}}; runtime.camX=0; runtime.camY=0; runtime._camFollowTouch=true; runtime.touch.x=30; runtime.touch.y=-40; applyEngineCamera(); runtime._camFollowTouch=false; return runtime.camX===-30 && runtime.camY===-40; });
    check('folder variants', () => getFolderFrames({folders:[{name:'R',frames:['a','b']} ]}, 'R').length===2);
    check('loop animation does not block', () => { const ra={data:{folders:[{name:'R',looks:['a','b']}],looks:['a'],_colorSwaps:[],_swapCache:{}},el:document.createElement('div')}; runtime.actors.push(ra); runtime.globals.after=0; const co={actor:ra,blocks:{a:{id:'a',name:'Tocar animação',values:{pasta:'R',modo:'loop',fps:12},next:'b'},b:{id:'b',name:'Definir variável para',values:{variável:'after',valor:7},next:null}},ip:'a',waitUntil:0,dead:false,loopStack:[],tree:{blocks:{}}}; co.tree.blocks=co.blocks; stepCoroutine(co,performance.now()); const ok = runtime.globals.after===7 && (!co.ip || co.ip===null); runtime.actors.pop(); delete runtime.globals.after; return ok; });    check('legacy joystick direction → variable → X flow', () => {
      const root=document.createElement('div'); root.id='kix-selftest-controls-root'; document.body.appendChild(root);
      const stage=document.createElement('div'); stage.id='play-stage'; root.appendChild(stage);
      runtime.stageEl=stage; runtime._controlsRoot=null; runtime._presets={controls:{joy:{id:'joy',el:document.createElement('div'),type:'joystick',axisX:1,axisY:0,force:1,active:true,direction:0}},screens:{},transitions:{},multiplayer:{},camera:{},collision:{}};
      runtime._joystickDirectionVars={}; runtime.actors=[];
      const ra={data:{name:'JoyLegacy',x:0,y:0,vx:0,vy:0,direction:0,visible:true,_vars:{}},el:document.createElement('div')}; runtime.actors.push(ra);
      const blocks={
        b:{id:'b',name:'Ler direção do joystick',values:{id:'joy','variável':'dir'},next:'c'},
        c:{id:'c',name:'Definir X para',values:{valor:'dir'},next:null}
      };
      const makeCo=()=>({actor:ra,blocks,tree:{blocks},ip:'b',waitUntil:0,dead:false,loopStack:[]});
      stepCoroutine(makeCo(),performance.now());
      const x1=ra.data.x;
      stepCoroutine(makeCo(),performance.now()+16); const x2=ra.data.x;
      const ok = runtime.globals.dir===0 && x1===6 && x2===12;
      try{root.remove();}catch(_){} runtime.actors.pop(); runtime._presets=null; runtime._controlsRoot=null; runtime._joystickDirectionVars=null;
      return ok;
    });
    check('joystick movement facilitator uses force and optional facing', () => {
      const root=document.createElement('div'); root.id='kix-selftest-controls-root'; document.body.appendChild(root); const stage=document.createElement('div'); stage.id='play-stage'; root.appendChild(stage); runtime.stageEl=stage; runtime._controlsRoot=null; runtime._presets={controls:{},screens:{},transitions:{},multiplayer:{},camera:{},collision:{}}; runtime.actors=[];
      const ra={data:{name:'JoyFac',x:0,y:0,vx:0,vy:0,direction:90,visible:true,_vars:{}},el:document.createElement('div')}; runtime.actors.push(ra); runtime._presets.controls.joy={id:'joy',el:document.createElement('div'),type:'joystick',axisX:1,axisY:0,force:.5,active:true,direction:0};
      runtime.frameMs=1000/60;
      const blk={id:'m',name:'Seguir joystick',values:{id:'joy',apontar:'sim',velocidade:10},next:null}; const co={actor:ra,blocks:{m:blk},tree:{blocks:{m:blk}},ip:'m',waitUntil:0,dead:false,loopStack:[]}; stepCoroutine(co,performance.now()); const ok=ra.data.x===5 && ra.data.y===0 && ra.data.direction===0; try{root.remove();}catch(_){} runtime.actors.pop(); runtime._presets=null; runtime._controlsRoot=null; return ok;
    });
    check('joystick up increases world Y', () => { const root=document.createElement('div'); root.id='kix-selftest-controls-root'; document.body.appendChild(root); const stage=document.createElement('div'); stage.id='play-stage'; root.appendChild(stage); runtime.stageEl=stage; runtime._controlsRoot=null; runtime._presets={controls:{},screens:{},transitions:{},multiplayer:{},camera:{},collision:{}}; runtime.actors=[]; const ra={data:{name:'JoyY',x:0,y:0,vx:0,vy:0,direction:90,visible:true,_vars:{}},el:document.createElement('div')}; runtime.actors.push(ra); runtime._presets.controls.joy={id:'joy',el:document.createElement('div'),type:'joystick',axisX:0,axisY:1,force:1,active:true,direction:90}; runtime.frameMs=1000/60; const blk={id:'m',name:'Seguir joystick',values:{id:'joy',apontar:'sim',velocidade:10},next:null}; const co={actor:ra,blocks:{m:blk},tree:{blocks:{m:blk}},ip:'m',waitUntil:0,dead:false,loopStack:[]}; stepCoroutine(co,performance.now()); const ok=ra.data.y===10; try{root.remove();}catch(_){} runtime.actors.pop(); runtime._presets=null; runtime._controlsRoot=null; return ok; });
    check('formula string substitution', () => evalExpr('substituir("a-b-b","-",":")',{vars:{}})==='a:b:b');
    check('formula expanded functions', () => evalExpr('clamp(20,0,10)',{vars:{}})===10 && evalExpr('lerp(0,100,0.25)',{vars:{}})===25 && evalExpr('log base(100,10)',{vars:{}})===2);
    check('formula expanded lists', () => evalExpr('tamanho da lista("a,b,c")',{vars:{}})===3 && evalExpr('lista contém("a,b","b")',{vars:{}})===1 && evalExpr('contar item("a,b,b","b")',{vars:{}})===2);
    check('formula expanded dates', () => { const y=runtimeDate().getFullYear(); return evalExpr('ano',{vars:{}})===y && evalExpr('mês',{vars:{}})>=1 && evalExpr('mês',{vars:{}})<=12; });
    check('direct position changes X and Y', () => {
      const ra={data:{x:0,y:0,vx:9,vy:9,visible:true},el:document.createElement('div')};
      runtime.actors.push(ra);
      actorPositionSet(ra,40,-25,true);
      const ok=ra.data.x===40 && ra.data.y===-25 && ra.data.vx===0 && ra.data.vy===0;
      actorPositionMove(ra,10,15,true);
      const ok2=ra.data.x===50 && ra.data.y===-10;
      runtime.actors.pop();
      return ok && ok2;
    });
    check('joystick follows smoothly with frame scale', () => {
      const root=document.createElement('div'); root.id='kix-selftest-controls-root'; document.body.appendChild(root);
      const stage=document.createElement('div'); stage.id='play-stage'; root.appendChild(stage);
      runtime.stageEl=stage; runtime._presets={controls:{joy:{id:'joy',el:document.createElement('div'),type:'joystick',axisX:1,axisY:0,force:1,active:true,direction:0}},screens:{},transitions:{},multiplayer:{},camera:{},collision:{}};
      const ra={data:{name:'Smooth',x:0,y:0,vx:0,vy:0,direction:90,visible:true,_vars:{}},el:document.createElement('div')}; runtime.actors.push(ra);
      const blk={id:'m',name:'Seguir joystick',values:{id:'joy',apontar:'sim',velocidade:10},next:null};
      const makeCo=()=>({actor:ra,blocks:{m:blk},tree:{blocks:{m:blk}},ip:'m',waitUntil:0,dead:false,loopStack:[]});
      runtime.frameMs=1000/60; stepCoroutine(makeCo(),1000); const x60=ra.data.x;
      runtime.frameMs=1000/30; stepCoroutine(makeCo(),1016.666); const x30=ra.data.x;
      runtime.frameMs=1000/60; stepCoroutine(makeCo(),1050); const x60b=ra.data.x;
      try{root.remove();}catch(_){} runtime.actors.pop(); runtime._presets=null; runtime.frameMs=16.67;
      return x60===10 && x30===30 && x60b===40;
    });
    check('direction zero is valid for movement', () => { const ra={data:{x:0,y:0,direction:0,vx:0,vy:0},el:document.createElement('div')}; runtime.actors.push(ra); const blk={id:'m',name:'Mover X passos',values:{passos:10},next:null}; const co={actor:ra,blocks:{m:blk},tree:{blocks:{m:blk}},ip:'m',waitUntil:0,dead:false,loopStack:[]}; stepCoroutine(co,performance.now()); const ok=ra.data.x===10 && ra.data.y===0; runtime.actors.pop(); return ok; });
    check('repeat loop keeps executing its body', () => {
      const ra={data:{x:0,y:0,vx:0,vy:0,direction:90,visible:true,_vars:{}},el:document.createElement('div')};
      const blocks={l:{id:'l',name:'Sempre',values:{},next:null,body:['m']},m:{id:'m',name:'Mover X passos',values:{passos:5},next:null}};
      const co={actor:ra,blocks,tree:{blocks},ip:'l',waitUntil:0,dead:false,loopStack:[]};
      stepCoroutine(co,performance.now());
      co.ip='m'; stepCoroutine(co,performance.now()+16); const afterOne=ra.data.y;
      co.ip='m'; stepCoroutine(co,performance.now()+32); const afterTwo=ra.data.y;
      return afterOne===5 && afterTwo===10;
    });
    check('property tween advances without frame animation', () => { const ra={data:{x:0,y:0,size:100,_tweens:[{prop:'x',from:0,to:100,start:performance.now()-500,duration:500,curve:'suave'}]},el:document.createElement('div')}; runtime.actors.push(ra); tickLookAnimations(16); const ok=ra.data.x===100 && (!ra.data._tweens||ra.data._tweens.length===0); runtime.actors.pop(); return ok; });
    check('all canonical presets have one route', () => CANONICAL_PRESET_NAMES.size===60);
    check('all canonical shaders have one route', () => CANONICAL_SHADER_NAMES.size===23);
    check('shader routes execute without throwing', () => {
      const ra={data:{id:'shader_test',name:'ShaderTest',x:0,y:0,direction:90,visible:true},el:document.createElement('div')};
      const co={actor:ra,blocks:{},tree:{blocks:{}},ip:null,waitUntil:0,dead:false,loopStack:[]};
      let ok=true;
      const values={id:'shader_test',raio:4,cor:'#fff',amplitude:5,tamanho:4,valor:1,nome:'u_test',código:'',largura:320,altura:180,a:'blur',b:'gray',caminho:'',segundos:1};
      for(const name of CANONICAL_SHADER_NAMES){ try{ const blk={id:'s',name,values,next:null}; productionShader(name,blk,{},ra); }catch(_){ ok=false; break; } }
      return ok;
    });
    check('deleted appearance never returns as runtime image', () => {
      const dead='data:image/png;base64,DELETE_ME';
      const live='data:image/png;base64,KEEP_ME';
      const a={looks:[dead,live],folders:[],image:dead,costume:0,activeAppearance:{where:'root',folderIdx:null,idx:0,key:appearanceKey(dead)}};
      a.looks.splice(0,1); a.image=dead; a.costume=0;
      return resolveActorImage(a)===live;
    });
    check('pixel art follows the selected appearance', () => {
      const a={looks:['a','b'],folders:[],image:'a',costume:0,pixelArt:false,pixelArtLooks:{[appearanceKey('b')]:true}};
      return appearanceIsPixelArt(a,'a')===false && appearanceIsPixelArt(a,'b')===true;
    });
    check('self-test D-pad is isolated from live scene', () => {
      const live = document.getElementById('play-canvas');
      const after = live ? live.querySelectorAll('#kix-controls-root').length : 0;
      return after === liveControlRootsBefore && document.querySelectorAll('#kix-selftest-controls-root').length === 0;
    });
    check('appearance swap resolver uses active folder', () => {
      const a={looks:['root'],folders:[{name:'Run',looks:['r1','r2']}],image:'root',costume:0,activeAppearance:{where:'folder',folderIdx:0,idx:1,key:appearanceKey('r2')}};
      return resolveActorImage(a)==='r2';
    });

    check('D-pad facilitator maps four variables', () => {
      const root=document.createElement('div'); root.id='kix-selftest-controls-root'; document.body.appendChild(root);
      const stage=document.createElement('div'); stage.id='play-stage'; root.appendChild(stage);
      runtime.stageEl=stage; runtime._controlsRoot=null; runtime._presets={controls:{},screens:{},transitions:{},multiplayer:{},camera:{},collision:{}}; runtime.actors=[];
      const ra={data:{name:'DpadTest',x:0,y:0,vx:0,vy:0,direction:90,visible:true,_vars:{}},el:document.createElement('div')}; runtime.actors.push(ra);
      const blk={id:'d',name:'Criar D-Pad',values:{id:'pad',cima:'up',esquerda:'left',direita:'right',baixo:'down'},next:null}; const co={actor:ra,blocks:{d:blk},tree:{blocks:{d:blk}},ip:'d',waitUntil:0,dead:false,loopStack:[]};
      const okCreate=executePresetBlock(co,blk,{},performance.now()); const c=runtime._presets.controls.pad; const up=c?.el?.querySelector('[data-dir="cima"]');
      if(up?.onpointerdown) up.onpointerdown(); const pressed=ra.data._vars.up===1 && ra.data._vars.left===0 && ra.data._vars.down===0;
      if(up?.onpointerup) up.onpointerup(); const released=ra.data._vars.up===0;
      try{root.remove();}catch(_){} runtime.actors.pop(); runtime._presets=null; runtime._controlsRoot=null; return !!(okCreate&&pressed&&released);
    });
    check('D-pad skin keeps each arrow independently skinnable', () => {
      const root=document.createElement('div'); root.id='kix-selftest-controls-root'; document.body.appendChild(root); const stage=document.createElement('div'); stage.id='play-stage'; root.appendChild(stage);
      runtime.stageEl=stage; runtime._controlsRoot=null; runtime._presets={controls:{},screens:{},transitions:{},multiplayer:{},camera:{},collision:{}}; runtime.actors=[];
      const ra={data:{name:'DpadSkin',x:0,y:0,vx:0,vy:0,direction:90,visible:true,_vars:{}},el:document.createElement('div')}; runtime.actors.push(ra);
      const mk=(name,values)=>({id:'x',name,values,next:null}); const co={actor:ra,blocks:{},tree:{blocks:{}},ip:null,waitUntil:0,dead:false,loopStack:[]};
      executePresetBlock(co,mk('Criar D-pad',{id:'skin'}),{},performance.now());
      executePresetBlock(co,mk('Trocar skin do D-pad',{id:'skin',estilo:'vidro'}),{},performance.now());
      executePresetBlock(co,mk('Definir sprite da seta do D-pad',{id:'skin',direção:'cima',imagem:'up.png'}),{},performance.now());
      const btn=runtime._presets.controls.skin.el.querySelector('[data-dir="cima"]'); const ok=runtime._presets.controls.skin.dpadSkin==='vidro' && /up\.png/.test(btn?.style.backgroundImage||'');
      try{root.remove();}catch(_){} runtime.actors.pop(); runtime._presets=null; runtime._controlsRoot=null; return ok;
    });
    check('all canonical presets advance and configure', () => {
      const names=Array.from(CANONICAL_PRESET_NAMES); let ok=true;
      runtime.stageEl=sandboxStage; runtime._controlsRoot=null; runtime._presets={controls:{},screens:{},transitions:{},multiplayer:{},camera:{},collision:{}}; runtime.actors=[];
      for (const pn of names) {
        const ra={id:'preset_test',data:{name:'PresetActor',x:0,y:0,vx:0,vy:0,visible:true,looks:[],folders:[],_vars:{}},el:document.createElement('div')};
        const co={actor:ra,blocks:{p:{id:'p',name:pn,values:{id:'test',x:20,y:30,tamanho:100,variável:'v',variavel:'v',texto:'Teste',preset:'glass',segundos:1,força:5,direção:0,largura:40,altura:40,atrito:.2,valor:1,dano:1,intervalo:10,velocidade:2,distância:10,cena:'Cena',título:'Teste',ator:'PresetActor',fator:1},next:null}},ip:'p',waitUntil:0,dead:false,loopStack:[],tree:{blocks:{}}};
        co.tree.blocks=co.blocks; runtime.actors=[ra];
        try { stepCoroutine(co,performance.now()); if(co.ip!==null) ok=false; } catch (_) { ok=false; break; }
      }
      try { sandboxStage.innerHTML=''; } catch (_) {}
      return ok;
    });
    return {ok: results.every(r=>r.ok), results};
    } finally {
      try { document.querySelectorAll('#kix-selftest-sandbox, #kix-selftest-controls-root').forEach(el => { try { el.remove(); } catch (_) {} }); } catch (_) {}
      runtime.actors = saved.actors; runtime.stageEl = saved.stageEl; runtime._presets = saved.presets; runtime._controlsRoot = saved.controlsRoot;
      runtime._hudRoot = saved.hudRoot; runtime.hud = saved.hud; runtime.sounds = saved.sounds; runtime.previewAudio = saved.previewAudio; runtime.soundVolume = saved.soundVolume; runtime.soundPitch = saved.soundPitch; runtime.soundLoop = saved.soundLoop; runtime.globals = saved.globals; runtime.camX = saved.camX; runtime.camY = saved.camY;
      runtime.camZoom = saved.camZoom; runtime.camRot = saved.camRot; runtime.freeCam = saved.freeCam; runtime._camFree = saved.camFree;
      runtime.touch = saved.touch; runtime.fps = saved.fps; runtime.frameMs = saved.frameMs; runtime.cameraWorldX = saved.cameraWorldX; runtime.cameraWorldY = saved.cameraWorldY;
      runtime.elapsedSeconds = saved.elapsedSeconds; runtime.elapsedMs = saved.elapsedMs; runtime.project = saved.project;
    }
  }

  // Ensure old flat scripts acquire explicit loop boundaries. This keeps the
  // runtime deterministic: once a user moves a block below Fim de loop, it
  // stays outside instead of being pulled back into the loop by a heuristic.
  function ensureFlatLoopBoundaries(scripts) {
    if (!Array.isArray(scripts)) return false;
    let changed = false;
    for (let i = 0; i < scripts.length; i++) {
      const b = scripts[i];
      if (!b || blockType(b.name) !== 'loop') continue;
      if (b.loopBoundaryExplicit === true) {
        if (b.loopEndId != null && b.loopEndId !== '') {
          const exists = scripts.some(x => x && String(x.id || '') === String(b.loopEndId));
          if (exists) continue;
          b.loopEndId = null;
          changed = true;
        }
        continue;
      }
      if (b.loopEndId != null && b.loopEndId !== '') {
        const exists = scripts.some(x => x && String(x.id || '') === String(b.loopEndId));
        if (exists) continue;
        b.loopEndId = null;
        changed = true;
      }
      if (b.loopEndId == null || b.loopEndId === '') {
        let end = i;
        for (let j = i + 1; j < scripts.length; j++) {
          const n = scripts[j];
          if (!n) continue;
          const name = String(n.name || '');
          if (blockType(name) === 'hat' || blockType(name) === 'loop' || blockType(name) === 'if') break;
          end = j;
        }
        const endBlock = scripts[end];
        b.loopEndId = endBlock && end > i ? String(endBlock.id || '') : null;
        b.loopBoundaryExplicit = true;
        changed = true;
      }
    }
    return changed;
  }

  // Export helpers for host integration
  function scriptsToFlat(tree) {
    if (!tree || !tree.blocks) return [];
    const out = [];
    const seen = new Set();
    const visit = (id) => {
      const key = String(id == null ? '' : id);
      if (!key || seen.has(key)) return;
      const b = tree.blocks[id] || tree.blocks[key];
      if (!b) return;
      seen.add(key);
      const flat = {
        id: b.id, opcode: b.opcode || stableOpcode(b.name), name: b.name, legacyName: b.legacyName, color: b.color,
        params: b.params, values: b.values, disabled: b.disabled,
        type: b.type,
        loopEndId: b.type === 'loop' ? (b.loopEndId != null ? String(b.loopEndId) : null) : undefined,
        loopBoundaryExplicit: b.type === 'loop' ? (b.loopBoundaryExplicit === true) : undefined,
        ifEndId: b.type === 'if' ? (b.ifEndId != null ? String(b.ifEndId) : null) : undefined,
        ifBoundaryExplicit: b.type === 'if' ? (b.ifBoundaryExplicit === true) : undefined,
        ifElseId: b.type === 'if' ? (b.ifElseId != null ? String(b.ifElseId) : null) : undefined,
        ifElseExplicit: b.type === 'if' ? (b.ifElseExplicit === true) : undefined,
        compatId: b.compatId, catrobatName:b.catrobatName, catrobatCategory:b.catrobatCategory, compatNative:b.compatNative,
        pluginId:b.pluginId, pluginBlockId:b.pluginBlockId, pluginLanguage:b.pluginLanguage,
        heightY:b.heightY, multiline:b.multiline, template:b.template, example:b.example, useCategoryColor:b.useCategoryColor,
        customBrickId:b.customBrickId, brickType:b.brickType, canContainChildren:b.canContainChildren, canBeChild:b.canBeChild,
        allowedParent:Array.isArray(b.allowedParent)?b.allowedParent.slice():undefined, allowedChildren:Array.isArray(b.allowedChildren)?b.allowedChildren.slice():undefined
      };
      // Preserve importer metadata when a tree is flattened again. This includes
      // Catrobat source types, imported world-text flags and end-marker metadata.
      if (b.catrobat && typeof b.catrobat === 'object') {
        try { flat.catrobat = JSON.parse(JSON.stringify(b.catrobat)); } catch (_) { flat.catrobat = b.catrobat; }
      }
      out.push(flat);
      if (Array.isArray(b.body)) b.body.forEach(cid => visit(cid));
      if (b.type === 'if' && b.ifElseId) {
        const elseBlock = tree.blocks[b.ifElseId] || tree.blocks[String(b.ifElseId)];
        if (elseBlock) visit(b.ifElseId);
      }
      if (b.type === 'if' && Array.isArray(b.bodyElse)) b.bodyElse.forEach(cid => visit(cid));
      if (b.type === 'if' && b.ifEndId) {
        const endBlock = tree.blocks[b.ifEndId] || tree.blocks[String(b.ifEndId)];
        if (endBlock) visit(b.ifEndId);
      }
      if (b.next) visit(b.next);
    };
    (tree.stacks || []).forEach(s => visit(s));
    return out;
  }

  // Kix Game API host facade. It wraps existing runtime systems; it is not a second engine.
  const gameApiHost = {
    networking: {
      websocket: {
        connect(url){ return netOpenWs(netEndpoint(url)); },
        send(data){ return netSendWs(data); },
        close(){ try{runtime.network.ws?.close();}catch(_){} runtime.network.ws=null; runtime.network.wsStatus='closed'; return true; },
        status(){ return String(runtime.network.wsStatus||'closed'); },
        lastMessage(){ return runtime.network.lastMessage==null?'':runtime.network.lastMessage; },
        lastError(){ return runtime.network.lastError==null?'':runtime.network.lastError; },
        on(type,handler){ const ws=runtime.network.ws; if(!ws||typeof ws.addEventListener!=='function'||typeof handler!=='function')return false; const ev=['open','message','error','close'].includes(String(type))?String(type):''; if(!ev)return false; ws.addEventListener(ev,handler); return ()=>{try{ws.removeEventListener(ev,handler);}catch(_){}}; }
      },
      http: {
        async request(url,options){
          if(typeof fetch!=='function')throw new Error('Fetch não está disponível nesta build');
          const o=Object.assign({},options||{}); const timeout=Math.max(100,Math.min(120000,Number(o.timeout)||Number(runtime.network.timeout)||5000)); delete o.timeout;
          const ctl=typeof AbortController==='function'?new AbortController():null; let timer=null; if(ctl){o.signal=o.signal||ctl.signal;timer=kixSetTimeout(()=>{try{ctl.abort();}catch(_){}},timeout);}
          try{const res=await fetch(String(url||''),o);const text=await res.text();let data=text;try{data=text?JSON.parse(text):null;}catch(_){}const headers={};try{res.headers?.forEach?.((v,k)=>headers[k]=v);}catch(_){}return{ok:!!res.ok,status:Number(res.status)||0,data,text,headers};}
          finally{if(timer)kixClearTimer(timer);}
        }
      },
      tcp: {
        connect(endpoint){runtime.network.tcp=netEndpoint(endpoint);if(global.kixNetwork?.tcpConnect){runtime.network.tcpStatus='bridge';try{return Promise.resolve(global.kixNetwork.tcpConnect(runtime.network.tcp)).then(()=>{runtime.network.tcpStatus='open';return true;}).catch(e=>{runtime.network.tcpStatus='error';throw e;});}catch(e){runtime.network.tcpStatus='error';return Promise.reject(e);}}if(/^wss?:\/\//i.test(runtime.network.tcp)){const ok=netOpenWs(runtime.network.tcp);runtime.network.tcpStatus=ok?'websocket-bridge':'error';return ok;}runtime.network.tcpStatus='unavailable';return false;},
        send(data){if(global.kixNetwork?.tcpSend){try{return !!global.kixNetwork.tcpSend(runtime.network.tcp,data);}catch(_){return false;}}return netSendWs(data);},
        readLast(){return runtime.network.lastMessage==null?'':runtime.network.lastMessage;},
        close(){if(global.kixNetwork?.tcpClose){try{global.kixNetwork.tcpClose(runtime.network.tcp);}catch(_){} }runtime.network.tcp=null;runtime.network.tcpStatus='closed';return true;},
        status(){return String(runtime.network.tcpStatus||'closed');}
      },
      udp: {
        send(endpoint,data){runtime.network.udpStatus='sending';if(global.kixNetwork?.udpSend){try{return Promise.resolve(global.kixNetwork.udpSend(netEndpoint(endpoint),data)).then(()=>{runtime.network.udpStatus='open';return true;}).catch(e=>{runtime.network.udpStatus='error';throw e;});}catch(e){runtime.network.udpStatus='error';return Promise.reject(e);}}if(/^wss?:\/\//i.test(netEndpoint(endpoint))){const ok=netSendWs(data);runtime.network.udpStatus=ok?'websocket-bridge':'error';return ok;}runtime.network.udpStatus='unavailable';return false;},
        listen(port,handler){if(!global.kixNetwork?.udpListen){runtime.network.udpStatus='unavailable';return false;}try{global.kixNetwork.udpListen(Number(port)||0,handler);runtime.network.udpStatus='open';return true;}catch(_){runtime.network.udpStatus='error';return false;}},
        close(){if(global.kixNetwork?.udpClose){try{global.kixNetwork.udpClose();}catch(_){} }runtime.network.udpStatus='closed';return true;},
        lastMessage(){return runtime.network.lastUDP==null?'':runtime.network.lastUDP;},
        status(){return String(runtime.network.udpStatus||'closed');}
      }
    },
    multiplayer: {
      firebase: {
        configure(config){runtime.network.firebase.config=(config&&typeof config==='object')?config:{};fbSetStatus('configured');return true;},
        connect(){if(!fbBase()){fbSetStatus('error','Configure o Firebase primeiro');return false;}fbSetStatus('connected');return true;},
        disconnect(){Object.values(runtime.network.firebase.listeners||{}).forEach(id=>{try{kixClearTimer(id);}catch(_){}});runtime.network.firebase.listeners={};runtime.network.firebase.token=null;runtime.network.firebase.uid=null;fbSetStatus('disconnected');return true;},
        signInAnonymously(){return fbAuth('signUp',{returnSecureToken:true});},
        signInEmail(email,password){return fbAuth('signInWithPassword',{email:fbClean(email),password:fbClean(password),returnSecureToken:true});},
        signOut(){runtime.network.firebase.token=null;runtime.network.firebase.uid=null;fbSetStatus('configured');return true;},
        status(){return String(runtime.network.firebase.status||'disconnected');}, uid(){return runtime.network.firebase.uid||null;},
        setPath(path){runtime.network.firebase.path=fbClean(path).replace(/^\/+|\/+$/g,'');return runtime.network.firebase.path;}, error(){return runtime.network.firebase.error||'';},
        get(path=''){return fbFetch(path);},
        set(path,value){return fbFetch(path,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(value)});},
        update(path,value){return fbFetch(path,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(value)});},
        remove(path){return fbFetch(path,{method:'DELETE'});}
      },
      localPlayerId(){if(runtime.network.firebase.uid)return runtime.network.firebase.uid;if(!runtime.network.firebase.guestId)runtime.network.firebase.guestId='guest_'+runtimeRandom().toString(36).slice(2,10);return runtime.network.firebase.guestId;},
      createRoom(room){const r=fbClean(room||'sala');return fbFetch(fbRoomPath(r),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({estado:'lobby',host:this.localPlayerId(),criadaEm:runtimeNow()})});},
      joinRoom(room,name='Jogador'){const r=fbClean(room||'sala');runtime.network.firebase.path=r;const uid=this.localPlayerId();return fbFetch(fbRoomPath(r,'jogadores/'+uid),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({nome:fbClean(name||'Jogador'),uid,online:true})});},
      leaveRoom(room){const r=fbClean(room||runtime.network.firebase.path||'sala'),uid=this.localPlayerId();return (uid?fbFetch(fbRoomPath(r,'jogadores/'+uid),{method:'DELETE'}):Promise.resolve(null)).then(v=>{if(runtime.network.firebase.path===r)runtime.network.firebase.path='';return v;});},
      setPlayerData(room,key,value){const r=fbClean(room||runtime.network.firebase.path||'sala'),uid=this.localPlayerId();return fbFetch(fbRoomPath(r,'jogadores/'+uid+'/'+fbClean(key||'estado')),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(value)});},
      getPlayerData(room,player,key){const r=fbClean(room||runtime.network.firebase.path||'sala'),uid=fbClean(player||this.localPlayerId());return fbFetch(fbRoomPath(r,'jogadores/'+uid+'/'+fbClean(key||'estado')));},
      listPlayers(room){const r=fbClean(room||runtime.network.firebase.path||'sala');return fbFetch(fbRoomPath(r,'jogadores'));},
      setRoomState(stateValue,room){const r=fbClean(room||runtime.network.firebase.path||'sala');return fbFetch(fbRoomPath(r,'estado'),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(stateValue)});},
      getRoomState(room){const r=fbClean(room||runtime.network.firebase.path||'sala');return fbFetch(fbRoomPath(r,'estado'));},
      sendEvent(event,data,room){const r=fbClean(room||runtime.network.firebase.path||'sala');return fbFetch(fbRoomPath(r,'eventos'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({evento:fbClean(event||'evento'),dados:data,uid:this.localPlayerId(),tempo:runtimeNow()})});},
      async getLastEvent(room){const r=fbClean(room||runtime.network.firebase.path||'sala'),d=await fbFetch(fbRoomPath(r,'eventos')),vals=d?Object.values(d):[];vals.sort((a,b)=>(b?.tempo||0)-(a?.tempo||0));return vals[0]||null;},
      watchRoom(room,handler,intervalMs){const r=fbClean(room||runtime.network.firebase.path||'sala'),id='gameapi:'+r;if(runtime.network.firebase.listeners[id])kixClearTimer(runtime.network.firebase.listeners[id]);const ms=Math.max(250,Math.min(10000,Number(intervalMs)||1000));const poll=()=>fbFetch(fbRoomPath(r)).then(data=>{runtime.network.firebase.lastRoom=data;if(typeof handler==='function')handler(data);}).catch(e=>fbSetStatus('error',e));runtime.network.firebase.listeners[id]=kixSetInterval(poll,ms);poll();return id;},
      stopWatchRoom(room){const r=fbClean(room||runtime.network.firebase.path||'sala'),id='gameapi:'+r;if(runtime.network.firebase.listeners[id]){kixClearTimer(runtime.network.firebase.listeners[id]);delete runtime.network.firebase.listeners[id];return true;}return false;}
    },
    dispatchEvent(name,payload){const eventName=String(name||'').trim();if(!eventName)return 0;runtime.messages=Array.isArray(runtime.messages)?runtime.messages:[];runtime.messages.push({type:'game-api-event',event:eventName,data:payload,time:runtimeNow()});let fired=0;try{(runtime.actors||[]).forEach(ra=>{startHatsFor(ra,eventName);fired++;});}catch(_){}return fired;}
  };

  global.KixEngine = {
    migrateScripts,
    startEngine,
    stagePointToWorld,
    applyEngineCamera,
    syncStageLayout,
    configureProjectStage, projectStageMetrics, applyProjectOrientation, setStagePresentationOrientation, clearStagePresentationOrientation, assertProjectOrientationInvariant,
    stopEngine,
    stopAll,
    restartEngine,
    restoreActors,
    snapshotActors,
    togglePause,
    renderCollisionDebug,
    pruneTextForActor,
    scriptsToFlat,
    ensureFlatLoopBoundaries,
    blockType,
    selfTest,
    stepCoroutine,
    newId,
    opcodeFor,
    evalFormula: evalExpr,
    canonicalBlockName,
    runtime,
    actorPositionSet,
    actorPositionMove,
    version: KIX_APP_VERSION,
    checkCollision,
    resolveLook,
    previewSound,
    stopPreviewSound,
    getFolderFrames,
    startLookAnimation,
    stopLookAnimation,
    tickLookAnimations,
    isLooksBlockName,
    productionShader,
    refreshShader,
    refreshSceneShader,
    stepCoroutine,
    STAGE_W,
    STAGE_H,
    setActorCostume,
    setActorOpacity,
    setActorTransparency,
    updateSpriteTransform,
    applyAppearance,
    gameApi: gameApiHost,
    snapshotRuntimeState:()=>global.KixPhase3Runtime?.runtimeState?.() || null,
    restoreRuntimeState:(state)=>global.KixPhase3Runtime?.applyRuntimeState?.(state) || false,
    undo:()=>global.KixPhase3Runtime?.undo?.() || false,
    redo:()=>global.KixPhase3Runtime?.redo?.() || false
  };
  try {
    if (typeof window !== 'undefined') window.KixEngine = global.KixEngine;
  } catch (_) {}
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this));
