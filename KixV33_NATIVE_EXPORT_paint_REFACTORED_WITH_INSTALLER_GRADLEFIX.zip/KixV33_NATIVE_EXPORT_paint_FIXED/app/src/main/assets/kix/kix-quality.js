/* Kix Quality Layer 1.1
 * Diagnostics, project health and publishing manifest.
 * This module deliberately consumes the authoritative KixProjectAPI instead of
 * maintaining a second project state.
 */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const api = () => window.KixProjectAPI;
  const SVG = {
    check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4 4L19 7.5"/></svg>',
    warn:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4l9 16H3L12 4z"/><path d="M12 9v5M12 17h.01"/></svg>',
    info:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 10v6M12 7h.01"/></svg>',
    build:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 3h10v4H7z"/><path d="M5 7h14v14H5z"/><path d="M9 11h6M9 15h6"/></svg>',
    chev:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg>',
    back:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 19l-7-7 7-7"/></svg>'
  };

  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function allBricks(project){
    const out=[];
    for(const scene of (project?.scenes||[])) for(const actor of (scene?.actors||[])) {
      for(const script of (actor?.scripts||[])) for(const b of (script?.blocks||script?.bricks||[])) out.push({scene,actor,script,b});
    }
    return out;
  }
  function analyze(project){
    const issues=[], warnings=[], infos=[];
    if(!project){issues.push({id:'project.missing',title:'Nenhum projeto aberto',detail:'Abra ou crie um projeto antes de analisar.'});return {issues,warnings,infos,stats:{}};}
    const scenes=Array.isArray(project.scenes)?project.scenes:[];
    if(!scenes.length) issues.push({id:'project.no-scenes',title:'Projeto sem cenas',detail:'O projeto precisa de pelo menos uma cena.'});
    let actors=0,scripts=0,bricks=0,emptyScripts=0;
    const ids=new Map();
    for(const scene of scenes){
      for(const actor of (scene?.actors||[])){
        actors++;
        if(actor?.id){ids.set(actor.id,(ids.get(actor.id)||0)+1);}
        for(const script of (actor?.scripts||[])){
          scripts++; const list=script?.blocks||script?.bricks||[]; bricks+=Array.isArray(list)?list.length:0;
          if(!list?.length) emptyScripts++;
          if(script?.id) ids.set(script.id,(ids.get(script.id)||0)+1);
          for(const b of (list||[])) if(b?.id) ids.set(b.id,(ids.get(b.id)||0)+1);
        }
      }
    }
    const duplicateIds=[...ids.entries()].filter(([,n])=>n>1);
    if(duplicateIds.length) issues.push({id:'ids.duplicate',title:`${duplicateIds.length} IDs duplicados`,detail:'IDs estáveis são necessários para drag/drop, undo, importação e publicação.',ids:duplicateIds.map(([id])=>String(id))});
    if(emptyScripts) warnings.push({id:'scripts.empty',title:`${emptyScripts} script(s) vazio(s)`,detail:'Scripts vazios não executam nada e podem indicar uma edição incompleta.'});
    const entries=allBricks(project);
    let adapted=0,preserved=0;
    for(const x of entries){
      const c=x.b?.catrobat;
      if(c?.adapted){adapted++; if(c.adaptedFrom==='safe-note-fallback') preserved++;}
    }
    if(adapted) warnings.push({id:'bricks.adapted',title:`${adapted} Brick(s) adaptado(s)`,detail:'A adaptação pode não reproduzir a semântica original. Revise antes de publicar.'});
    if(preserved) issues.push({id:'bricks.preserved',title:`${preserved} Brick(s) preservado(s) sem execução equivalente`,detail:'O código-fonte foi mantido para compatibilidade, mas o runtime Kix ainda não possui comportamento equivalente.'});
    const assets=[];
    for(const scene of scenes) for(const actor of (scene?.actors||[])){
      for(const look of (actor?.looks||[])) if(look) assets.push(look);
      for(const sound of (actor?.sounds||[])) if(sound) assets.push(sound);
    }
    if(!assets.length) infos.push({title:'Projeto sem recursos multimídia',detail:'Isso é válido para projetos de lógica, mas jogos normalmente precisam de imagens ou sons.'});
    const report=project.catrobatSource || project.catrobatImport ? project.importReport || project.catrobatReport : null;
    if(report?.unsupportedTypes && Object.keys(report.unsupportedTypes).length) warnings.push({title:`${Object.keys(report.unsupportedTypes).length} tipo(s) Catrobat não suportado(s)`,detail:'A importação preservou metadados, mas a execução equivalente não está garantida.'});
    infos.push({title:`${scenes.length} cena(s), ${actors} objeto(s), ${scripts} script(s), ${bricks} Brick(s)`,detail:'Contagem estrutural do projeto atual.'});
    return {issues,warnings,infos,stats:{scenes:scenes.length,actors,scripts,bricks,assets:assets.length,adapted,preserved}};
  }
  function statusRow(kind,item){
    const icon=kind==='error'?SVG.warn:kind==='warning'?SVG.warn:SVG.info;
    const cls=kind==='error'?'error':kind==='warning'?'warning':'info';
    return `<button type="button" class="kix-health-row ${cls}" data-kix-diagnostic-id="${esc(item.id||'')}"><span class="kix-health-icon">${icon}</span><div class="kix-health-copy"><div class="kix-health-title">${esc(item.title)}</div><div class="kix-health-detail">${esc(item.detail)}</div></div></div></button>`;
  }
  // ---- Saúde do projeto -------------------------------------------------
  // Dois estados: "pick" (lista de projetos para escolher) e "report" (análise
  // do projeto escolhido). Pelo menu da Home sempre abre a lista; pelas opções
  // de um projeto abre direto o relatório daquele projeto.
  const health = { mode: 'pick', project: null, viaPicker: false };

  function projectCounts(p){
    let actors=0; const scenes=Array.isArray(p?.scenes)?p.scenes:[];
    for(const sc of scenes) for(const a of (sc?.actors||[])) if(a && !a.isBackground) actors++;
    return {scenes:scenes.length, actors};
  }
  function renderPicker(){
    const body=$('kix-health-body'); if(!body)return;
    const list=api()?.getProjects?.()||[];
    health.mode='pick'; health.project=null;
    setHealthTitle('Saúde do projeto');
    body.innerHTML='';
    if(!list.length){
      body.innerHTML='<div class="kix-health-center"><div class="kix-health-center-icon">'+SVG.info+'</div><div class="kix-health-center-title">Nenhum projeto aberto</div><div class="kix-health-center-sub">Crie ou importe um projeto para ver a saúde dele.</div></div>';
      return;
    }
    const head=document.createElement('div'); head.className='kix-health-pick-head'; head.textContent='Escolha um projeto para analisar';
    body.appendChild(head);
    const cur=api()?.getCurrentProject?.();
    list.forEach((p,idx)=>{
      if(!p) return;
      const c=projectCounts(p);
      const row=document.createElement('button'); row.type='button'; row.className='kix-health-row info kix-health-pick-row';
      row.innerHTML='<span class="kix-health-icon">'+SVG.build+'</span><div class="kix-health-copy"><div class="kix-health-title"></div><div class="kix-health-detail"></div></div><span class="kix-health-chevron">'+SVG.chev+'</span>';
      row.querySelector('.kix-health-title').textContent=p.name||'Projeto';
      row.querySelector('.kix-health-detail').textContent=c.scenes+' cena(s) · '+c.actors+' objeto(s)'+(p===cur?' · aberto agora':'');
      row.addEventListener('click',()=>renderReport(p,true));
      body.appendChild(row);
    });
  }
  function setHealthTitle(t){
    const span=document.querySelector('#screen-project-health #btn-health-back')?.parentElement?.querySelector('span:last-child');
    if(span) span.textContent=t;
  }
  function renderReport(project, viaPicker){
    const body=$('kix-health-body'); if(!body)return;
    health.mode='report'; health.project=project; health.viaPicker=!!viaPicker;
    const r=analyze(project); const stats=r.stats||{};
    setHealthTitle('Saúde do projeto');
    body.innerHTML='';
    const bar=document.createElement('div'); bar.className='kix-health-project-bar';
    bar.innerHTML='<div class="kix-health-project-name"></div><button type="button" class="kix-health-switch">Trocar</button>';
    bar.querySelector('.kix-health-project-name').textContent=project?.name||'Projeto';
    bar.querySelector('.kix-health-switch').addEventListener('click',renderPicker);
    body.appendChild(bar);
    const summary=document.createElement('div'); summary.className='kix-health-summary';
    summary.innerHTML=`<div><strong>${stats.scenes||0}</strong><span>Cenas</span></div><div><strong>${stats.actors||0}</strong><span>Objetos</span></div><div><strong>${stats.scripts||0}</strong><span>Scripts</span></div><div><strong>${stats.bricks||0}</strong><span>Bricks</span></div>`;
    body.appendChild(summary);
    if(r.issues.length||r.warnings.length||r.infos.length){
      r.issues.forEach(x=>body.insertAdjacentHTML('beforeend',statusRow('error',x)));
      r.warnings.forEach(x=>body.insertAdjacentHTML('beforeend',statusRow('warning',x)));
      r.infos.forEach(x=>body.insertAdjacentHTML('beforeend',statusRow('info',x)));
    } else body.insertAdjacentHTML('beforeend','<div class="kix-health-empty">Nenhum problema encontrado.</div>');
    body.querySelectorAll('[data-kix-diagnostic-id]').forEach(row=>row.addEventListener('click',()=>{
      const id=row.dataset.kixDiagnosticId;
      if(id==='ids.duplicate'||id.startsWith('bricks.')){
        // O inspetor trabalha sobre o projeto aberto: abre o projeto analisado antes.
        if(api()?.getCurrentProject?.()!==project){
          const idx=(api()?.getProjects?.()||[]).indexOf(project);
          if(idx>=0){ api()?.openProject?.(idx); }
        }
        window.KixPhase2?.openInspector?.(); return;
      }
      api()?.toast?.('Diagnóstico: '+(row.querySelector('.kix-health-title')?.textContent||id));
    }));
    const footer=document.createElement('div'); footer.className='kix-health-footer'; footer.textContent='Itens de diagnóstico são navegáveis quando existe uma origem selecionável.'; body.appendChild(footer);
  }
  function renderHealth(){
    if(health.mode==='report' && health.project && (api()?.getProjects?.()||[]).includes(health.project)) renderReport(health.project,health.viaPicker);
    else renderPicker();
  }
  function healthBack(){
    if(health.mode==='report' && health.viaPicker){ renderPicker(); return; }
    if(api()?.back) api().back(); else api()?.show?.('project-options');
  }
  // opts.pick = true força a lista (menu da Home). Sem opts, usa o projeto aberto.
  function openHealth(opts){
    const enabled = api()?.getAppOptions?.()?.kixQualityEnabled === true;
    if(!enabled){ api()?.toast?.('Ative Kix Quality em Configurações'); api()?.show?.('settings'); return; }
    const pick = !!(opts && opts.pick);
    const cur = api()?.getCurrentProject?.();
    api()?.show?.('project-health');
    if(pick || !cur) renderPicker(); else renderReport(cur,false);
  }

  let publishIconOverride = null;
  function slug(v){return String(v||'jogo').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'.').replace(/^\.+|\.+$/g,'').slice(0,50)||'jogo';}
  function buildManifest(){
    const p=api()?.getCurrentProject?.()||{}; const settings=loadPublishSettings();
    const name=String(settings.name||p.name||'Jogo Kix').trim()||'Jogo Kix';
    const packageId=String(settings.packageId||('com.kixgames.'+slug(name))).toLowerCase();
    return {schema:'kix-android-build-v1',createdAt:new Date().toISOString(),runtime:{name:'Kix Android Runtime',version:String(window.KIX_APP_VERSION||'current')},project:{id:String(p.kixId||p.id||''),name,version:String(settings.version||p.version||'1.0.0')},android:{packageId,orientation:settings.orientation||p.orientation||'portrait',minSdk:Number(settings.minSdk||24),targetSdk:Number(settings.targetSdk||35),abis:['arm64-v8a','armeabi-v7a'],fullscreen:settings.fullscreen!==false},permissions:{internet:!!settings.internet,microphone:!!settings.microphone,camera:!!settings.camera,location:!!settings.location},signing:{mode:settings.signingMode||'managed'},artifacts:{debugApk:true,releaseApk:true},icon:{source:publishIconOverride?'export-override':'project',dataUrl:String(publishIconOverride||p.icon||'')}};
  }
  function loadPublishSettings(){try{return JSON.parse(localStorage.getItem('kix_publish_settings')||'{}')||{};}catch(_){return {};}}
  function savePublishSettings(){
    const s={name:$('publish-name')?.value||'',packageId:$('publish-package')?.value||'',version:$('publish-version')?.value||'1.0.0',orientation:$('publish-orientation')?.value||'portrait',minSdk:$('publish-minsdk')?.value||24,targetSdk:$('publish-targetsdk')?.value||35,fullscreen:$('publish-fullscreen')?.checked!==false,internet:$('publish-internet')?.checked===true,microphone:$('publish-microphone')?.checked===true,camera:$('publish-camera')?.checked===true,location:$('publish-location')?.checked===true,signingMode:$('publish-signing')?.value||'managed'};
    try{localStorage.setItem('kix_publish_settings',JSON.stringify(s));}catch(_){} return s;
  }
  function validateManifest(m){
    const errors=[]; const warnings=[];
    if(!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(m.android.packageId)) errors.push('Package ID inválido. Use algo como com.exemplo.jogo.');
    if(!/^\d+\.\d+\.\d+$/.test(m.project.version)) warnings.push('A versão não segue semantic versioning estrito.');
    if(!m.project.name.trim()) errors.push('Nome do jogo vazio.');
    if(!m.project.id) warnings.push('Projeto ainda não possui um ID persistente detectável.');
    return {errors,warnings};
  }
  function downloadJSON(filename,data){const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  function renderPublishIcon(){
    const p=api()?.getCurrentProject?.()||{}; const src=publishIconOverride||p.icon||''; const el=$('publish-icon-preview'); if(!el)return;
    el.innerHTML=src?`<img src="${String(src).replace(/"/g,'')}" alt="">`:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><rect x="4" y="4" width="16" height="16" rx="4"/><path d="m8 15 2.5-3 2 2 1.5-1.5L16 15"/></svg>`;
  }
  function openPublish(){
    publishIconOverride=null;
    const s=loadPublishSettings(),p=api()?.getCurrentProject?.()||{};
    renderPublishIcon();
    if($('publish-name'))$('publish-name').value=s.name||p.name||'';
    if($('publish-package'))$('publish-package').value=s.packageId||('com.kixgames.'+slug(p.name||'jogo'));
    if($('publish-version'))$('publish-version').value=s.version||p.version||'1.0.0';
    if($('publish-orientation'))$('publish-orientation').value=s.orientation||p.orientation||'portrait';
    if($('publish-minsdk'))$('publish-minsdk').value=s.minSdk||24;
    if($('publish-targetsdk'))$('publish-targetsdk').value=s.targetSdk||35;
    if($('publish-fullscreen'))$('publish-fullscreen').checked=s.fullscreen!==false;
    ['internet','microphone','camera','location'].forEach(k=>{if($('publish-'+k))$('publish-'+k).checked=s[k]===true;});
    if($('publish-signing'))$('publish-signing').value=s.signingMode||'managed';
    refreshPublish(); api()?.show?.('publish');
  }
  function refreshPublish(){
    const m=buildManifest(),v=validateManifest(m),el=$('publish-validation'); if(!el)return;
    el.innerHTML='';
    v.errors.forEach(x=>el.insertAdjacentHTML('beforeend',`<div class="kix-publish-check error">${SVG.warn}<span>${esc(x)}</span></div>`));
    v.warnings.forEach(x=>el.insertAdjacentHTML('beforeend',`<div class="kix-publish-check warning">${SVG.warn}<span>${esc(x)}</span></div>`));
    if(!v.errors.length&&!v.warnings.length)el.innerHTML=`<div class="kix-publish-check ok">${SVG.check}<span>Tudo certo para gerar o arquivo de publicação.</span></div>`;
    const action=$('btn-publish-manifest');
    if(action){
      const blocked=v.errors.length>0;
      action.title=blocked?'Corrija os problemas acima antes de exportar o APK':'Exportar APK';
      action.disabled=blocked;
      action.setAttribute('aria-disabled',blocked?'true':'false');
    }
    $('publish-manifest-preview').textContent=JSON.stringify(m,null,2);
  }
  let buildBusy=false,currentBuildJob=null,lastOutputUri=null;
  function nativeBuilder(){try{return window.Android&&typeof window.Android.startBuild==='function'?window.Android:null;}catch(_){return null;}}
  function buildStatusEl(){
    let el=$('publish-build-status');
    if(!el){
      el=document.createElement('div');el.id='publish-build-status';el.className='kix-publish-card';el.style.display='none';
      el.innerHTML='<div id="publish-build-text" style="font-size:12px;line-height:17px;color:#C5C9CE;word-break:break-word"></div><div style="height:6px;background:#2A2D31;border-radius:3px;margin-top:8px;overflow:hidden"><div id="publish-build-bar" style="height:100%;width:0;background:#10b981;transition:width .2s"></div></div><div id="publish-build-actions" style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap"></div>';
      const cta=$('btn-publish-manifest');if(cta)cta.insertAdjacentElement('afterend',el);
    }
    return el;
  }
  function buildBtn(label,fn){const b=document.createElement('button');b.type='button';b.textContent=label;b.style.cssText='padding:9px 14px;border-radius:11px;border:1px solid #3A3F46;background:#23262B;color:#F0F1F3;font-size:12px';b.addEventListener('click',fn);return b;}
  function setBuildUi(o){
    const el=buildStatusEl();el.style.display='block';
    const t=$('publish-build-text'),bar=$('publish-build-bar'),act=$('publish-build-actions');
    t.textContent=o.text||'';t.style.color=o.error?'#F2A0A0':'#C5C9CE';
    if(typeof o.percent==='number')bar.style.width=Math.max(0,Math.min(100,o.percent))+'%';
    bar.style.background=o.error?'#b45454':'#10b981';
    act.innerHTML='';
    buildBusy=!!o.busy;
    const cta=$('btn-publish-manifest');if(cta){cta.disabled=buildBusy;cta.setAttribute('aria-disabled',buildBusy?'true':'false');}
    if(o.busy)act.appendChild(buildBtn('Cancelar',()=>{try{nativeBuilder()?.cancelBuild(currentBuildJob);}catch(_){}}));
    if(o.install){act.appendChild(buildBtn('Instalar',()=>{
      try{const r=JSON.parse(nativeBuilder().installApk(o.install));if(r&&r.ok===false)api()?.toast?.(r.error||'Não foi possível instalar');}catch(_){api()?.toast?.('Não foi possível instalar');}
    }));}
  }
  window.KixBuildEvent=function(raw){
    let ev;try{ev=typeof raw==='string'?JSON.parse(raw):raw;}catch(_){return;}
    if(!ev||(currentBuildJob&&ev.jobId&&ev.jobId!==currentBuildJob))return;
    if(ev.type==='progress'){setBuildUi({text:ev.message||'Compilando…',percent:ev.percent,busy:true});}
    else if(ev.type==='done'){
      currentBuildJob=null;lastOutputUri=ev.outputUri||null;
      const where=ev.installable?'Downloads/Kix/':'a pasta de downloads do Kix';
      setBuildUi({text:'APK pronto: '+(ev.name||'')+' (salvo em '+where+')'+(ev.warning?' — '+ev.warning:''),percent:100,install:ev.installable?ev.outputUri:null});
      api()?.toast?.('APK gerado com sucesso');
    }
    else if(ev.type==='error'){currentBuildJob=null;setBuildUi({text:ev.message||'Falha ao gerar o APK.',percent:0,error:true});api()?.toast?.('Falha ao gerar o APK');}
  };
  async function exportManifest(){
    const m=buildManifest(),v=validateManifest(m);
    if(v.errors.length){api()?.toast?.('Corrija os erros do APK');return;}
    savePublishSettings();
    let project;
    try { project=api()?.normalize?.(api()?.getCurrentProject?.()) || api()?.getCurrentProject?.(); }
    catch(e){ api()?.toast?.('Não foi possível preparar o projeto para o APK'); return; }
    const native=nativeBuilder();
    if(native){
      if(buildBusy){api()?.toast?.('Já existe uma exportação em andamento');return;}
      if(m.signing?.mode==='custom')api()?.toast?.('Chave própria ainda não está disponível no app; usando a chave gerenciada.');
      let projectJson;
      try{projectJson=JSON.stringify(project);}catch(_){api()?.toast?.('Não foi possível serializar o projeto');return;}
      setBuildUi({text:'Preparando…',percent:2,busy:true});
      let res;
      try{res=JSON.parse(native.startBuild(JSON.stringify({schema:'kix-apk-build-request-v1',manifest:m,projectJson})));}
      catch(e){console.error('Android.startBuild',e);setBuildUi({text:'Falha ao iniciar a exportação.',error:true});return;}
      if(!res||res.ok===false){setBuildUi({text:(res&&res.error)||'A exportação foi recusada.',error:true});return;}
      currentBuildJob=res.jobId;
      return;
    }
    const request={schema:'kix-apk-build-request-v1',manifest:m,project};
    // Browser/dev mode only: there is no on-device compiler, so use the local Kix builder service (Node + Gradle).
    const base=String(window.KIX_APK_BUILDER_URL||'http://127.0.0.1:8787').replace(/\/$/,'');
    try{
      api()?.toast?.('Compilando APK…');
      const response=await fetch(base+'/build',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(request)});
      const type=response.headers.get('content-type')||'';
      if(!response.ok){
        let message='Falha ao compilar o APK';
        if(type.includes('application/json')){try{const j=await response.json();message=j.error||message;}catch(_){}}
        throw new Error(message);
      }
      if(!type.includes('application/vnd.android.package-archive') && !type.includes('application/octet-stream')) throw new Error('O compilador não retornou um APK.');
      const blob=await response.blob();
      const url=URL.createObjectURL(blob); const a=document.createElement('a');
      a.href=url; a.download=slug(m.project.name)+'-release.apk'; a.click();
      setTimeout(()=>URL.revokeObjectURL(url),30000);
      api()?.toast?.('APK gerado com sucesso');
    }catch(e){
      console.error('Kix APK builder',e);
      const msg=String(e?.message||e||'Falha ao compilar o APK');
      api()?.toast?.(msg.includes('Failed to fetch')||msg.includes('NetworkError')?'No navegador a exportação precisa do Kix APK Builder (node tools/kix-apk-builder-server.mjs). No app Kix para Android ela é nativa.':msg);
    }
  }
  function init(){
    $('btn-open-health')?.addEventListener('click',()=>openHealth());
    $('btn-open-publish')?.addEventListener('click',openPublish);
    $('btn-health-back')?.addEventListener('click',healthBack);
    $('btn-publish-back')?.addEventListener('click',()=>api()?.show?.('project-options'));
    $('btn-publish-manifest')?.addEventListener('click',exportManifest);
    $('publish-icon-button')?.addEventListener('click',()=>$('input-publish-icon')?.click());
    $('input-publish-icon')?.addEventListener('change',async(e)=>{
      const f=e.target.files?.[0]; if(!f)return;
      if(!/^image\/(png|jpeg|webp)$/i.test(f.type)){api()?.toast?.('Escolha PNG, JPG ou WebP'); e.target.value=''; return;}
      if(f.size>4*1024*1024){api()?.toast?.('O ícone deve ter até 4 MB'); e.target.value=''; return;}
      try{publishIconOverride=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result||''));r.onerror=reject;r.readAsDataURL(f);}); renderPublishIcon(); refreshPublish(); api()?.toast?.('Ícone usado somente nesta exportação');}
      catch(_){api()?.toast?.('Não foi possível carregar o ícone');}
      e.target.value='';
    });
    document.querySelectorAll('#screen-publish input,#screen-publish select').forEach(el=>el.addEventListener('input',refreshPublish));
    $('btn-health-refresh')?.addEventListener('click',renderHealth);
    document.querySelectorAll('[data-action="diagnostics"]').forEach(el=>el.addEventListener('click',e=>{e.preventDefault();openHealth({pick:true});}));
    document.querySelectorAll('[data-action="publish"]').forEach(el=>el.addEventListener('click',e=>{e.preventDefault();openPublish();}));
    $('project-options-name')?.addEventListener('input',()=>setTimeout(refreshPublish,0));
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
  window.KixQuality=Object.freeze({analyze,openHealth,openPublish,buildManifest,validateManifest,diagnostic(id){const r=analyze(api()?.getCurrentProject?.());return [...r.issues,...r.warnings,...r.infos].find(x=>x.id===String(id))||null;}});
})();
