package com.kix.engine;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.*;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.zip.*;

/** Rewrites a ZIP/APK with controlled alignment and appends an APK Signature Scheme v2 block. Pure Java. */
public final class ApkPackager {
    public static final class Entry { public String name; public byte[] data; public boolean stored; public Entry(String n, byte[] d, boolean s) { name = n; data = d; stored = s; } }

    /** Reads every entry of an APK (ignores any signing block, drops META-INF signatures). */
    public static LinkedHashMap<String, byte[]> read(File apk) throws IOException {
        LinkedHashMap<String, byte[]> m = new LinkedHashMap<>();
        try (ZipFile z = new ZipFile(apk)) {
            for (Enumeration<? extends ZipEntry> en = z.entries(); en.hasMoreElements();) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String n = e.getName();
                if (n.startsWith("META-INF/") && (n.endsWith(".SF") || n.endsWith(".RSA") || n.endsWith(".DSA") || n.endsWith(".EC") || n.endsWith("MANIFEST.MF"))) continue;
                try (InputStream in = z.getInputStream(e)) { m.put(n, readAll(in)); }
            }
        }
        return m;
    }
    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream(); byte[] b = new byte[65536]; int r;
        while ((r = in.read(b)) > 0) o.write(b, 0, r); return o.toByteArray();
    }
    private static boolean mustStore(String n) { return n.equals("resources.arsc") || n.endsWith(".so") || n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".webp") || n.endsWith(".ogg") || n.endsWith(".mp3"); }

    private static void le16(ByteArrayOutputStream o, int v) { o.write(v & 0xff); o.write((v >> 8) & 0xff); }
    private static void le32(ByteArrayOutputStream o, long v) { le16(o, (int) (v & 0xffff)); le16(o, (int) ((v >> 16) & 0xffff)); }

    /** Builds a signed APK. */
    public static byte[] build(Map<String, byte[]> files, PrivateKey key, X509Certificate cert) throws Exception {
        ByteArrayOutputStream sec1 = new ByteArrayOutputStream();
        ByteArrayOutputStream cd = new ByteArrayOutputStream();
        int count = 0;
        List<String> names = new ArrayList<>(files.keySet());
        // resources.arsc first is not required, but keep dex/manifest order stable
        for (String name : names) {
            byte[] data = files.get(name);
            boolean stored = mustStore(name);
            byte[] comp = data; int method = 0;
            if (!stored) { Deflater d = new Deflater(Deflater.BEST_COMPRESSION, true); d.setInput(data); d.finish(); ByteArrayOutputStream co = new ByteArrayOutputStream(); byte[] buf = new byte[65536]; while (!d.finished()) { int n = d.deflate(buf); co.write(buf, 0, n); } d.end(); comp = co.toByteArray(); method = 8; if (comp.length >= data.length) { comp = data; method = 0; } }
            CRC32 crc = new CRC32(); crc.update(data);
            byte[] nb = name.getBytes("UTF-8");
            long offset = sec1.size();
            int extra = 0;
            if (method == 0) { int dataStart = (int) offset + 30 + nb.length; int al = name.endsWith(".so") ? 4096 : 4; extra = (al - (dataStart % al)) % al; }
            le32(sec1, 0x04034b50L); le16(sec1, 20); le16(sec1, 0x0800); le16(sec1, method); le16(sec1, 0); le16(sec1, 0x21);
            le32(sec1, crc.getValue()); le32(sec1, comp.length); le32(sec1, data.length); le16(sec1, nb.length); le16(sec1, extra);
            sec1.write(nb); for (int i = 0; i < extra; i++) sec1.write(0); sec1.write(comp);
            le32(cd, 0x02014b50L); le16(cd, 0x0314); le16(cd, 20); le16(cd, 0x0800); le16(cd, method); le16(cd, 0); le16(cd, 0x21);
            le32(cd, crc.getValue()); le32(cd, comp.length); le32(cd, data.length); le16(cd, nb.length); le16(cd, 0); le16(cd, 0); le16(cd, 0); le16(cd, 0); le32(cd, 0); le32(cd, offset); cd.write(nb);
            count++;
        }
        byte[] s1 = sec1.toByteArray(), s3 = cd.toByteArray();
        ByteArrayOutputStream eocd = new ByteArrayOutputStream();
        le32(eocd, 0x06054b50L); le16(eocd, 0); le16(eocd, 0); le16(eocd, count); le16(eocd, count); le32(eocd, s3.length); le32(eocd, s1.length); le16(eocd, 0);
        byte[] s4 = eocd.toByteArray(); // CD offset == s1.length for digest purposes (offset of signing block)

        byte[] digest = contentDigest(s1, s3, s4);
        byte[] block = signingBlock(digest, key, cert);
        // final EOCD: cd offset moves after the signing block
        ByteBuffer fe = ByteBuffer.wrap(s4.clone()).order(ByteOrder.LITTLE_ENDIAN);
        fe.putInt(16, s1.length + block.length);
        ByteArrayOutputStream out = new ByteArrayOutputStream(s1.length + block.length + s3.length + s4.length);
        out.write(s1); out.write(block); out.write(s3); out.write(fe.array());
        return out.toByteArray();
    }

    private static byte[] contentDigest(byte[]... sections) throws Exception {
        List<byte[]> digests = new ArrayList<>();
        for (byte[] s : sections) {
            for (int off = 0; off < s.length || (off == 0 && s.length == 0); off += 1 << 20) {
                int len = Math.min(1 << 20, s.length - off);
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                md.update((byte) 0xa5); md.update(le32b(len)); md.update(s, off, len);
                digests.add(md.digest());
                if (s.length == 0) break;
            }
        }
        MessageDigest top = MessageDigest.getInstance("SHA-256");
        top.update((byte) 0x5a); top.update(le32b(digests.size()));
        for (byte[] d : digests) top.update(d);
        return top.digest();
    }
    private static byte[] le32b(int v) { return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v).array(); }
    private static byte[] lp(byte[]... parts) { int n = 0; for (byte[] p : parts) n += p.length; ByteBuffer b = ByteBuffer.allocate(4 + n).order(ByteOrder.LITTLE_ENDIAN); b.putInt(n); for (byte[] p : parts) b.put(p); return b.array(); }

    private static byte[] signingBlock(byte[] contentDigest, PrivateKey key, X509Certificate cert) throws Exception {
        final int ALGO = 0x0103; // RSASSA-PKCS1-v1_5 + SHA2-256
        byte[] digestEntry = lp(le32b(ALGO), lp(contentDigest));
        byte[] signedData = lp(lp(digestEntry), lp(lp(cert.getEncoded())), lp());
        Signature sg = Signature.getInstance("SHA256withRSA"); sg.initSign(key); sg.update(signedData, 4, signedData.length - 4);
        byte[] sig = sg.sign();
        byte[] signer = lp(signedData, lp(lp(le32b(ALGO), lp(sig))), lp(cert.getPublicKey().getEncoded()));
        byte[] value = lp(signer);
        // pair: u64 len(id+value), u32 id, value
        ByteBuffer pair = ByteBuffer.allocate(8 + 4 + value.length).order(ByteOrder.LITTLE_ENDIAN);
        pair.putLong(4 + value.length).putInt(0x7109871a).put(value);
        long size = pair.capacity() + 8 + 16;
        ByteBuffer blk = ByteBuffer.allocate((int) size + 8).order(ByteOrder.LITTLE_ENDIAN);
        blk.putLong(size).put(pair.array()).putLong(size).put("APK Sig Block 42".getBytes("US-ASCII"));
        return blk.array();
    }

    /** Re-parses the finished APK and recomputes the v2 digest. Throws if anything is inconsistent. */
    public static void verify(byte[] d, X509Certificate expected) throws Exception {
        ByteBuffer b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
        int e = -1; for (int i = d.length - 22; i >= Math.max(0, d.length - 70000); i--) if (b.getInt(i) == 0x06054b50) { e = i; break; }
        if (e < 0) throw new IOException("EOCD ausente");
        int cdSize = b.getInt(e + 12), cdOff = b.getInt(e + 16);
        byte[] magic = Arrays.copyOfRange(d, cdOff - 16, cdOff);
        if (!new String(magic, "US-ASCII").equals("APK Sig Block 42")) throw new IOException("Bloco de assinatura ausente");
        long bsize = b.getLong(cdOff - 24); int bstart = (int) (cdOff - bsize - 8);
        if (b.getLong(bstart) != bsize) throw new IOException("Bloco de assinatura corrompido");
        int p = bstart + 8, end = cdOff - 24; byte[] v2 = null;
        while (p < end) { long l = b.getLong(p); int id = b.getInt(p + 8); if (id == 0x7109871a) v2 = Arrays.copyOfRange(d, p + 12, (int) (p + 8 + l)); p += 8 + (int) l; }
        if (v2 == null) throw new IOException("Assinatura v2 ausente");
        ByteBuffer v = ByteBuffer.wrap(v2).order(ByteOrder.LITTLE_ENDIAN);
        v.getInt(); v.getInt(); // signers len, signer len
        int sdLen = v.getInt(); byte[] sd = new byte[sdLen]; v.get(sd);
        int sigsLen = v.getInt(); byte[] sigs = new byte[sigsLen]; v.get(sigs);
        ByteBuffer s = ByteBuffer.wrap(sd).order(ByteOrder.LITTLE_ENDIAN);
        s.getInt(); s.getInt(); s.getInt(); s.getInt(); byte[] dig = new byte[32]; s.get(dig); // digests len, entry len, algo, digest len
        s.getInt(); int cl = s.getInt(); byte[] cder = new byte[cl]; s.get(cder);
        X509Certificate cert = (X509Certificate) java.security.cert.CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(cder));
        if (!Arrays.equals(cert.getEncoded(), expected.getEncoded())) throw new IOException("Certificado inesperado");
        ByteBuffer sb = ByteBuffer.wrap(sigs).order(ByteOrder.LITTLE_ENDIAN); sb.getInt(); sb.getInt(); int sl = sb.getInt(); byte[] sig = new byte[sl]; sb.get(sig);
        Signature sv = Signature.getInstance("SHA256withRSA"); sv.initVerify(cert.getPublicKey()); sv.update(sd); if (!sv.verify(sig)) throw new IOException("Assinatura inválida");
        byte[] s4 = Arrays.copyOfRange(d, e, d.length); ByteBuffer.wrap(s4).order(ByteOrder.LITTLE_ENDIAN).putInt(16, bstart);
        byte[] again = contentDigest(Arrays.copyOfRange(d, 0, bstart), Arrays.copyOfRange(d, cdOff, cdOff + cdSize), s4);
        if (!Arrays.equals(again, dig)) throw new IOException("Digest do conteúdo não confere");
    }
}
