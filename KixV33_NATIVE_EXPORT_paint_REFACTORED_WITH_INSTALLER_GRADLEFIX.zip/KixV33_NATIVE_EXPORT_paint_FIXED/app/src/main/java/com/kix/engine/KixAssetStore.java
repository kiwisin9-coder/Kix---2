package com.kix.engine;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Synchronizes the editor's public web assets into an app-private directory.
 * Remote updates are opt-in: an HTTPS manifest URL must be supplied at build time.
 */
public final class KixAssetStore implements Closeable {
    private static final String TAG = "KixAssetStore";
    private static final String PREFS = "kix_asset_updates";
    private static final String KEY_APK_VERSION = "apk_version";
    private static final String KEY_ASSET_VERSION = "asset_version";
    private static final int MAX_MANIFEST_BYTES = 512 * 1024;
    private static final int MAX_FILES = 512;
    private static final long MAX_FILE_BYTES = 16L * 1024L * 1024L;
    private static final long MAX_TOTAL_BYTES = 128L * 1024L * 1024L;
    private static final int CONNECT_TIMEOUT_MS = 15000;
    private static final int READ_TIMEOUT_MS = 20000;

    public interface Callback { void onComplete(boolean updated, String error); }

    private final Context app;
    private final SharedPreferences prefs;
    private final String manifestUrl;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile boolean closed;

    public KixAssetStore(Context context, String updateManifestUrl) {
        app = context.getApplicationContext();
        prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        manifestUrl = updateManifestUrl == null ? "" : updateManifestUrl.trim();
    }

    public File getRootDirectory() { return new File(app.getFilesDir(), "kix"); }

    /** First launch copies APK assets; APK upgrades reset to that signed baseline. */
    public synchronized void prepareFromApk(long apkVersion) throws IOException {
        File root = getRootDirectory();
        if (root.isDirectory() && new File(root, "index.html").isFile()
                && prefs.getLong(KEY_APK_VERSION, -1L) == apkVersion) return;

        File parent = root.getParentFile();
        if (parent == null || (!parent.exists() && !parent.mkdirs()))
            throw new IOException("Não foi possível criar o diretório privado do Kix.");
        File staged = new File(parent, ".kix-apk-stage-" + UUID.randomUUID());
        File backup = new File(parent, ".kix-apk-backup-" + UUID.randomUUID());
        deleteRecursively(staged);
        if (!staged.mkdirs()) throw new IOException("Não foi possível preparar os assets do Kix.");
        try {
            copyAssetTree(app.getAssets(), "kix", staged);
            if (!new File(staged, "index.html").isFile())
                throw new IOException("O APK não contém kix/index.html.");
            swapDirectories(staged, root, backup);
            prefs.edit().putLong(KEY_APK_VERSION, apkVersion).remove(KEY_ASSET_VERSION).commit();
        } catch (IOException | RuntimeException e) {
            deleteRecursively(staged);
            if (!root.exists() && backup.exists()) backup.renameTo(root);
            throw e;
        } finally {
            deleteRecursively(staged);
            // Preserve the previous tree if rollback failed and the live path is absent.
            if (root.exists()) deleteRecursively(backup);
        }
    }

    /** No configured endpoint, remote checks are intentionally disabled, not faked. */
    public void checkForUpdate(Callback callback) {
        if (closed) return;
        if (manifestUrl.isEmpty()) {
            post(callback, false, null);
            return;
        }
        executor.execute(() -> {
            boolean changed = false;
            String error = null;
            try { changed = downloadAndApplyUpdate(); }
            catch (Exception e) {
                error = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                Log.w(TAG, "Atualização de assets não aplicada: " + error);
            }
            post(callback, changed, error);
        });
    }

    private boolean downloadAndApplyUpdate() throws Exception {
        URL endpoint = requireHttps(manifestUrl);
        byte[] manifestBytes = readUrl(endpoint, MAX_MANIFEST_BYTES);
        JSONObject manifest = new JSONObject(new String(manifestBytes, java.nio.charset.StandardCharsets.UTF_8));
        long version = manifest.optLong("version", -1L);
        if (version < 1L) throw new IOException("Manifesto inválido: versão ausente.");
        if (version <= prefs.getLong(KEY_ASSET_VERSION, 0L)) return false;

        JSONArray files = manifest.optJSONArray("files");
        if (files == null || files.length() < 1 || files.length() > MAX_FILES)
            throw new IOException("Manifesto inválido: lista de arquivos fora do limite.");

        Set<String> seen = new HashSet<>();
        boolean hasIndex = false;
        long total = 0L;
        for (int i = 0; i < files.length(); i++) {
            JSONObject item = files.getJSONObject(i);
            String path = validateRelativePath(item.optString("path", ""));
            if (!seen.add(path)) throw new IOException("Manifesto contém caminho duplicado: " + path);
            if ("index.html".equals(path)) hasIndex = true;
            long size = item.optLong("size", -1L);
            String sha = item.optString("sha256", "").toLowerCase(Locale.ROOT);
            if (size < 0 || size > MAX_FILE_BYTES || !sha.matches("[a-f0-9]{64}"))
                throw new IOException("Manifesto contém tamanho/hash inválido: " + path);
            total += size;
            if (total > MAX_TOTAL_BYTES) throw new IOException("Atualização excede o limite total de tamanho.");
            requireHttps(item.optString("url", ""));
        }
        if (!hasIndex) throw new IOException("Manifesto não inclui index.html.");

        File root = getRootDirectory();
        File parent = root.getParentFile();
        File staged = new File(parent, ".kix-update-stage-" + UUID.randomUUID());
        File backup = new File(parent, ".kix-update-backup-" + UUID.randomUUID());
        if (!staged.mkdirs()) throw new IOException("Não foi possível criar a pasta temporária da atualização.");
        boolean swapped = false;
        try {
            long completed = 0L;
            for (int i = 0; i < files.length(); i++) {
                JSONObject item = files.getJSONObject(i);
                String relative = validateRelativePath(item.getString("path"));
                long expectedSize = item.getLong("size");
                byte[] payload = readUrl(requireHttps(item.getString("url")), expectedSize);
                if (payload.length != expectedSize)
                    throw new IOException("Tamanho divergente no arquivo: " + relative);
                String expectedHash = item.getString("sha256").toLowerCase(Locale.ROOT);
                if (!expectedHash.equals(sha256(payload)))
                    throw new IOException("SHA-256 divergente no arquivo: " + relative);
                File target = new File(staged, relative);
                File canonical = target.getCanonicalFile();
                String stageRoot = staged.getCanonicalPath() + File.separator;
                if (!canonical.getCanonicalPath().startsWith(stageRoot))
                    throw new IOException("Caminho de arquivo fora da pasta temporária.");
                File directory = target.getParentFile();
                if (directory == null || (!directory.isDirectory() && !directory.mkdirs()))
                    throw new IOException("Não foi possível criar diretório de asset: " + relative);
                try (FileOutputStream out = new FileOutputStream(target)) { out.write(payload); out.getFD().sync(); }
                completed += payload.length;
            }
            if (!new File(staged, "index.html").isFile()) throw new IOException("index.html ausente após download.");
            swapDirectories(staged, root, backup);
            swapped = true;
            if (!prefs.edit().putLong(KEY_ASSET_VERSION, version).commit())
                throw new IOException("Não foi possível salvar a versão ativa dos assets.");
            deleteRecursively(backup);
            Log.i(TAG, "Assets atualizados para versão " + version + " (" + completed + " bytes).");
            return true;
        } catch (Exception e) {
            if (swapped) {
                deleteRecursively(root);
                if (backup.exists() && !backup.renameTo(root))
                    Log.e(TAG, "Falha crítica: não foi possível restaurar o backup dos assets.");
            }
            throw e;
        } finally {
            deleteRecursively(staged);
            // Never erase the recovery copy when both activation and rollback failed.
            if (root.exists()) deleteRecursively(backup);
        }
    }

    private static void swapDirectories(File staged, File target, File backup) throws IOException {
        boolean hadTarget = target.exists();
        if (hadTarget && !target.renameTo(backup)) throw new IOException("Não foi possível isolar a versão atual dos assets.");
        if (!staged.renameTo(target)) {
            if (hadTarget && backup.exists() && !backup.renameTo(target))
                throw new IOException("Falha ao instalar e restaurar assets; backup preservado em " + backup.getName());
            throw new IOException("Não foi possível ativar os assets preparados.");
        }
    }

    private static URL requireHttps(String value) throws Exception {
        URL url = new URL(value);
        if (!"https".equalsIgnoreCase(url.getProtocol()) || url.getHost() == null || url.getHost().isEmpty()
                || url.getUserInfo() != null) throw new IOException("Somente URLs HTTPS válidas são aceitas para atualização.");
        return url;
    }

    private static byte[] readUrl(URL initial, long maxBytes) throws IOException {
        URL current = initial;
        for (int redirects = 0; redirects <= 3; redirects++) {
            HttpURLConnection connection = (HttpURLConnection) current.openConnection();
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json, application/octet-stream, */*");
            try {
                int status = connection.getResponseCode();
                if (status >= 300 && status <= 399) {
                    String location = connection.getHeaderField("Location");
                    if (location == null || redirects == 3) throw new IOException("Redirecionamento HTTPS inválido/excessivo.");
                    try { current = requireHttps(new URL(current, location).toExternalForm()); }
                    catch (Exception e) { throw new IOException("Redirecionamento inseguro rejeitado.", e); }
                    continue;
                }
                if (status < 200 || status >= 300) throw new IOException("Servidor de atualização respondeu HTTP " + status + ".");
                long declared = connection.getContentLengthLong();
                if (declared > maxBytes) throw new IOException("Download excede o limite permitido.");
                try (InputStream in = connection.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[16384];
                    int count;
                    while ((count = in.read(buffer)) != -1) {
                        if (out.size() + (long) count > maxBytes) throw new IOException("Download excede o limite permitido.");
                        out.write(buffer, 0, count);
                    }
                    return out.toByteArray();
                }
            } finally { connection.disconnect(); }
        }
        throw new IOException("Não foi possível concluir o download.");
    }

    private static String validateRelativePath(String path) throws IOException {
        if (path == null || path.isEmpty() || path.length() > 240 || path.startsWith("/")
                || path.contains("\\") || path.contains(":") || path.indexOf('\0') >= 0)
            throw new IOException("Caminho de asset inválido.");
        String[] parts = path.split("/", -1);
        for (String part : parts) {
            if (part.isEmpty() || ".".equals(part) || "..".equals(part))
                throw new IOException("Caminho de asset inseguro: " + path);
        }
        return path;
    }

    private static String sha256(byte[] payload) throws Exception {
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(payload);
        StringBuilder value = new StringBuilder(digest.length * 2);
        for (byte b : digest) value.append(String.format(Locale.ROOT, "%02x", b & 0xff));
        return value.toString();
    }

    private static void copyAssetTree(AssetManager assets, String assetPath, File destination) throws IOException {
        String[] children = assets.list(assetPath);
        if (children != null && children.length > 0) {
            if (!destination.exists() && !destination.mkdirs()) throw new IOException("Falha criando pasta: " + destination.getName());
            for (String child : children) copyAssetTree(assets, assetPath + "/" + child, new File(destination, child));
            return;
        }
        try (InputStream in = assets.open(assetPath)) {
            File parent = destination.getParentFile();
            if (parent != null && !parent.isDirectory() && !parent.mkdirs()) throw new IOException("Falha criando diretório de asset.");
            try (FileOutputStream out = new FileOutputStream(destination)) {
                byte[] buffer = new byte[16384]; int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                out.getFD().sync();
            }
        } catch (IOException e) {
            // AssetManager returns an empty list for an empty directory; preserve that directory if present.
            if (children != null && children.length == 0) {
                if (!destination.isDirectory() && !destination.mkdirs()) throw e;
            } else throw e;
        }
    }

    private static void deleteRecursively(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteRecursively(child);
        }
        if (!file.delete() && file.exists()) Log.w(TAG, "Não foi possível remover temporário: " + file.getName());
    }

    private void post(Callback callback, boolean updated, String error) {
        if (callback == null || closed) return;
        main.post(() -> { if (!closed) callback.onComplete(updated, error); });
    }

    @Override public void close() {
        closed = true;
        executor.shutdownNow();
    }
}
