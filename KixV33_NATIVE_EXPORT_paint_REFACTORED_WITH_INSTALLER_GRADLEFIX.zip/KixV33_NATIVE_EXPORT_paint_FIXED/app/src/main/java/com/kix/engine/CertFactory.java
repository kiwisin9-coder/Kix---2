package com.kix.engine;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Date;

/** Builds a self-signed X.509 v3 certificate with hand-written DER (no BouncyCastle needed). */
public final class CertFactory {
    private static byte[] tlv(int tag, byte[]... parts) {
        int n = 0; for (byte[] p : parts) n += p.length;
        ByteArrayOutputStream o = new ByteArrayOutputStream(); o.write(tag);
        if (n < 128) o.write(n); else if (n < 256) { o.write(0x81); o.write(n); } else if (n < 65536) { o.write(0x82); o.write(n >> 8); o.write(n & 0xff); } else { o.write(0x83); o.write(n >> 16); o.write((n >> 8) & 0xff); o.write(n & 0xff); }
        for (byte[] p : parts) o.write(p, 0, p.length);
        return o.toByteArray();
    }
    private static final byte[] OID_SHA256_RSA = {0x06,0x09,0x2a,(byte)0x86,0x48,(byte)0x86,(byte)0xf7,0x0d,0x01,0x01,0x0b};
    private static final byte[] OID_CN = {0x06,0x03,0x55,0x04,0x03};
    private static byte[] algId() { return tlv(0x30, OID_SHA256_RSA, new byte[]{0x05,0x00}); }
    private static byte[] name(String cn) { return tlv(0x30, tlv(0x31, tlv(0x30, OID_CN, tlv(0x0c, utf8(cn))))); }
    private static byte[] utf8(String s) { try { return s.getBytes("UTF-8"); } catch (Exception e) { throw new RuntimeException(e); } }
    private static byte[] time(long ms) { java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyyMMddHHmmss'Z'"); f.setTimeZone(java.util.TimeZone.getTimeZone("UTC")); return tlv(0x18, utf8(f.format(new Date(ms)))); }

    public static X509Certificate selfSigned(KeyPair kp, String cn, long validYears) throws Exception {
        long now = System.currentTimeMillis() - 86400000L, end = now + validYears * 365L * 86400000L;
        byte[] serial = new BigInteger(120, new SecureRandom()).add(BigInteger.ONE).toByteArray();
        byte[] tbs = tlv(0x30,
            tlv(0xa0, tlv(0x02, new byte[]{2})),           // v3
            tlv(0x02, serial), algId(), name(cn),
            tlv(0x30, time(now), time(end)), name(cn),
            kp.getPublic().getEncoded());
        Signature s = Signature.getInstance("SHA256withRSA"); s.initSign(kp.getPrivate()); s.update(tbs);
        byte[] sig = s.sign();
        byte[] bits = new byte[sig.length + 1]; System.arraycopy(sig, 0, bits, 1, sig.length);
        byte[] der = tlv(0x30, tbs, algId(), tlv(0x03, bits));
        return (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(der));
    }
}
