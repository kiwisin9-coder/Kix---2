package com.kix.engine;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.ByteBuffer;
import java.security.*;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Device-local signing identity. The RSA private key is stored only AES-GCM-encrypted; the AES key lives in the
 * Android Keystore (non-exportable). Nothing secret is ever put in project JSON or logs.
 */
final class KixSigningKeys {
    private static final String ALIAS = "kix_wrap_v1", PREFS = "kix_signing", K_KEY = "key", K_CERT = "cert";
    final PrivateKey privateKey; final X509Certificate cert;
    private KixSigningKeys(PrivateKey k, X509Certificate c) { privateKey = k; cert = c; }

    static synchronized KixSigningKeys loadOrCreate(Context ctx) throws Exception {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String k = sp.getString(K_KEY, null), c = sp.getString(K_CERT, null);
        if (k != null && c != null) {
            try {
                byte[] pkcs8 = decrypt(Base64.decode(k, Base64.NO_WRAP));
                PrivateKey pk = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(pkcs8));
                X509Certificate cert = (X509Certificate) java.security.cert.CertificateFactory.getInstance("X.509")
                        .generateCertificate(new java.io.ByteArrayInputStream(Base64.decode(c, Base64.NO_WRAP)));
                return new KixSigningKeys(pk, cert);
            } catch (Exception broken) {
                // Wrapping key lost (e.g. lock-screen reset). A NEW identity would break updates, so refuse silently replacing.
                throw new IllegalStateException("A chave de assinatura deste aparelho não pôde ser lida. Apps já exportados não poderão ser atualizados com uma chave nova.", broken);
            }
        }
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA"); g.initialize(2048, new SecureRandom());
        KeyPair kp = g.generateKeyPair();
        X509Certificate cert = CertFactory.selfSigned(kp, "Kix Managed Key", 30);
        sp.edit().putString(K_KEY, Base64.encodeToString(encrypt(kp.getPrivate().getEncoded()), Base64.NO_WRAP))
                .putString(K_CERT, Base64.encodeToString(cert.getEncoded(), Base64.NO_WRAP)).apply();
        return new KixSigningKeys(kp.getPrivate(), cert);
    }

    static String fingerprint(X509Certificate c) throws Exception {
        byte[] h = MessageDigest.getInstance("SHA-256").digest(c.getEncoded());
        StringBuilder s = new StringBuilder(); for (byte b : h) s.append(String.format("%02X", b)); return s.toString();
    }

    private static SecretKey wrapKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());
            kg.generateKey();
        }
        return (SecretKey) ks.getKey(ALIAS, null);
    }
    private static byte[] encrypt(byte[] plain) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, wrapKey());
        byte[] iv = c.getIV(), ct = c.doFinal(plain);
        return ByteBuffer.allocate(1 + iv.length + ct.length).put((byte) iv.length).put(iv).put(ct).array();
    }
    private static byte[] decrypt(byte[] blob) throws Exception {
        int n = blob[0] & 0xff; Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, wrapKey(), new GCMParameterSpec(128, blob, 1, n));
        return c.doFinal(blob, 1 + n, blob.length - 1 - n);
    }
}
