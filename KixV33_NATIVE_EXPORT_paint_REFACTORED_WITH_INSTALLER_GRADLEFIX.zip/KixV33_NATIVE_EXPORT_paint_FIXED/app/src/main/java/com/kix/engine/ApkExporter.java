package com.kix.engine;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;

import org.json.JSONObject;

import java.io.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.regex.Pattern;

/**
 * On-device "compiler": re-packages THIS app's own APK as a game APK.
 * Editor assets are dropped, the project/runtime are kept, the binary manifest is patched,
 * the launcher icon is replaced, and the result is signed (APK Signature Scheme v2) with a device-local key.
 */
final class ApkExporter {
    interface Progress { void on(String phase, int percent, String message); boolean cancelled(); }
    static final class Result { String uri, name, sha256, packageId, fingerprint; int versionCode; boolean installable; String warning; }
    static final class BuildException extends Exception { BuildException(String m) { super(m); } BuildException(String m, Throwable c) { super(m, c); } }

    private static final String[] KEEP = {"kix/runtime.html", "kix/runtime.js", "kix/kix-runtime-services.js", "kix/kix-data-format.js", "kix/kix-phase3-runtime.js"};
    private static final Pattern PKG = Pattern.compile("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$");
    private static final Pattern ICON = Pattern.compile("^res/mipmap-(m|h|xh|xxh|xxxh)dpi(-v\\d+)?/ic_launcher\\.png$");
    private static final long MAX_REQUEST = 80L * 1024 * 1024;

    static Result export(Context ctx, JSONObject req, Progress pr) throws BuildException {
        try {
            pr.on("validate", 3, "Validando projeto…");
            if (!"kix-apk-build-request-v1".equals(req.optString("schema"))) throw new BuildException("Pedido de build inválido (schema).");
            JSONObject manifest = req.getJSONObject("manifest");
            JSONObject proj = manifest.optJSONObject("project") == null ? new JSONObject() : manifest.getJSONObject("project");
            JSONObject and = manifest.getJSONObject("android");
            JSONObject perm = manifest.optJSONObject("permissions") == null ? new JSONObject() : manifest.getJSONObject("permissions");
            String projectJson = req.getString("projectJson");
            if (projectJson.length() < 2 || projectJson.length() > MAX_REQUEST) throw new BuildException("Projeto vazio ou grande demais.");
            String pkg = and.optString("packageId");
            if (!PKG.matcher(pkg).matches() || pkg.length() > 120) throw new BuildException("Identificação do app inválida. Use algo como com.exemplo.jogo.");
            if (pkg.equals(ctx.getPackageName())) throw new BuildException("A identificação não pode ser a mesma do editor Kix.");
            String name = proj.optString("name", "").trim();
            if (name.isEmpty() || name.length() > 80 || name.matches(".*[\\r\\n<>\"'`$\\\\].*")) throw new BuildException("Nome do app vazio ou com caracteres proibidos.");
            String version = proj.optString("version", "1.0.0").trim();
            if (version.isEmpty() || version.length() > 30 || version.matches(".*[\\r\\n<>\"'`$\\\\].*")) throw new BuildException("Versão inválida.");
            int min = and.optInt("minSdk", 24), target = and.optInt("targetSdk", 35);
            if (min < 24 || min > 35) throw new BuildException("Android mínimo deve estar entre 24 e 35.");
            if (target < min || target > 35) throw new BuildException("Android alvo deve estar entre o mínimo e 35.");
            int orientation = "landscape".equalsIgnoreCase(and.optString("orientation", "portrait")) ? 0 : 1;

            // Permissions: derive from project exactly like tools/kix-apk-compiler.mjs (declared must match needed).
            String low = java.text.Normalizer.normalize(projectJson, java.text.Normalizer.Form.NFD).toLowerCase(Locale.ROOT);
            boolean nInternet = Pattern.compile("https?:|firebase|websocket|fetch\\(").matcher(low).find(),
                    nMic = Pattern.compile("loudness|microfone").matcher(low).find(),
                    nCam = Pattern.compile("camera|face|c\u00e2mera").matcher(low).find(),
                    nLoc = Pattern.compile("gps|localiza|latitude|longitude").matcher(low).find();
            // The checkboxes on the Export screen are the source of truth. The text heuristic (which can false-positive,
            // e.g. "face" inside "surface") is only used when the manifest does not say anything about a permission.
            String[] ks = {"internet", "microphone", "camera", "location"}; boolean[] need = {nInternet, nMic, nCam, nLoc};
            for (int i = 0; i < 4; i++) if (perm.has(ks[i])) need[i] = perm.optBoolean(ks[i], false);
            Set<String> keep = new HashSet<>();
            if (need[0]) keep.add("android.permission.INTERNET");
            if (need[1]) keep.add("android.permission.RECORD_AUDIO");
            if (need[2]) keep.add("android.permission.CAMERA");
            if (need[3]) keep.add("android.permission.ACCESS_FINE_LOCATION");

            // Icon
            String dataUrl = manifest.optJSONObject("icon") != null ? manifest.getJSONObject("icon").optString("dataUrl", "") : "";
            java.util.regex.Matcher im = Pattern.compile("^data:image/(png|webp|jpeg);base64,([A-Za-z0-9+/=]+)$").matcher(dataUrl);
            if (!im.matches()) throw new BuildException("Ícone ausente: escolha uma imagem PNG, JPG ou WebP.");
            Bitmap src = BitmapFactory.decodeByteArray(Base64.decode(im.group(2), Base64.DEFAULT), 0, Base64.decode(im.group(2), Base64.DEFAULT).length);
            if (src == null) throw new BuildException("Não foi possível ler a imagem do ícone.");

            // Version code / identity history
            SharedPreferences hist = ctx.getSharedPreferences("kix_exports", Context.MODE_PRIVATE);
            String hk = "p_" + sha256Hex(pkg.getBytes("UTF-8")).substring(0, 24);
            int last = hist.getInt(hk + "_vc", 0);
            int requested = and.has("versionCode") && !and.isNull("versionCode") ? and.optInt("versionCode", 0) : 0;
            int vc = requested > 0 ? requested : Math.max(1, last + 1);
            if (vc <= last) throw new BuildException("versionCode " + vc + " não é maior que o último (" + last + "); atualização bloqueada.");
            KixSigningKeys keys = KixSigningKeys.loadOrCreate(ctx);
            String fp = KixSigningKeys.fingerprint(keys.cert);
            String prevFp = hist.getString(hk + "_fp", null);
            if (prevFp != null && !prevFp.equals(fp)) throw new BuildException("A chave de assinatura mudou desde a última exportação deste app; o Android recusaria a atualização.");

            if (pr.cancelled()) throw new BuildException("Cancelado.");
            pr.on("template", 15, "Lendo o modelo do aplicativo…");
            File self = new File(ctx.getApplicationInfo().sourceDir);
            LinkedHashMap<String, byte[]> all = ApkPackager.read(self);
            if (all.containsKey("assets/kix/exported.flag")) throw new BuildException("Este app já é um jogo exportado; use o editor Kix para exportar.");
            if (!all.containsKey("assets/kix/index.html")) throw new BuildException("Modelo inválido: editor não encontrado no APK.");
            LinkedHashMap<String, byte[]> out = new LinkedHashMap<>();
            Set<String> keepAssets = new HashSet<>(); for (String k : KEEP) keepAssets.add("assets/" + k);
            for (Map.Entry<String, byte[]> en : all.entrySet()) {
                String n = en.getKey();
                if (n.startsWith("assets/kix/")) { if (keepAssets.contains(n)) out.put(n, en.getValue()); continue; }
                out.put(n, en.getValue());
            }
            for (String k : keepAssets) if (!out.containsKey(k)) throw new BuildException("Modelo incompleto: falta " + k);

            pr.on("assets", 35, "Gravando projeto…");
            byte[] pj = projectJson.getBytes("UTF-8");
            out.put("assets/kix/project.json", pj);
            out.put("assets/kix/project.sha256", (sha256Hex(pj) + "\n").getBytes("UTF-8"));
            out.put("assets/kix/format.json", "{\n  \"formatVersion\": 2,\n  \"runtimeVersion\": 3\n}\n".getBytes("UTF-8"));
            out.put("assets/kix/exported.flag", "1\n".getBytes("UTF-8"));

            pr.on("icon", 50, "Gerando ícones…");
            int[] sizes = {48, 72, 96, 144, 192}; String[] dens = {"m", "h", "xh", "xxh", "xxxh"}; int replaced = 0;
            for (String n : new ArrayList<>(out.keySet())) {
                java.util.regex.Matcher m = ICON.matcher(n);
                if (m.matches()) { int s = sizes[Arrays.asList(dens).indexOf(m.group(1))]; out.put(n, png(src, s)); replaced++; }
            }
            String warning = replaced == 0 ? "Não encontrei os ícones do modelo; o app usará o ícone padrão do Kix." : null;

            pr.on("manifest", 62, "Ajustando o manifesto…");
            AxmlPatcher.Edit ed = new AxmlPatcher.Edit();
            ed.packageName = pkg; ed.versionName = version; ed.versionCode = vc; ed.label = name; ed.minSdk = min; ed.targetSdk = target; ed.orientation = orientation; ed.keepPermissions = keep;
            byte[] man = out.get("AndroidManifest.xml");
            if (man == null) throw new BuildException("Modelo sem AndroidManifest.xml.");
            out.put("AndroidManifest.xml", AxmlPatcher.patch(man, ed));

            if (pr.cancelled()) throw new BuildException("Cancelado.");
            pr.on("sign", 75, "Assinando (v2)…");
            byte[] apk = ApkPackager.build(out, keys.privateKey, keys.cert);
            pr.on("verify", 88, "Verificando assinatura…");
            ApkPackager.verify(apk, keys.cert);
            // structural re-read
            File tmp = File.createTempFile("kixexp", ".apk", ctx.getCacheDir());
            try (FileOutputStream fo = new FileOutputStream(tmp)) { fo.write(apk); }
            try (java.util.zip.ZipFile z = new java.util.zip.ZipFile(tmp)) {
                for (String must : new String[]{"AndroidManifest.xml", "classes.dex", "resources.arsc", "assets/kix/project.json"})
                    if (z.getEntry(must) == null) throw new BuildException("APK gerado sem " + must + ".");
            } finally { tmp.delete(); }

            pr.on("save", 94, "Salvando em Downloads…");
            String fileName = safeFile(name) + "-" + safeFile(version) + ".apk";
            Result r = new Result(); r.name = fileName; r.packageId = pkg; r.versionCode = vc; r.fingerprint = fp; r.sha256 = sha256Hex(apk); r.warning = warning;
            r.uri = save(ctx, fileName, apk);
            r.installable = r.uri.startsWith("content:");
            hist.edit().putInt(hk + "_vc", vc).putString(hk + "_fp", fp).apply();
            pr.on("done", 100, "APK pronto.");
            return r;
        } catch (BuildException e) { throw e;
        } catch (org.json.JSONException e) { throw new BuildException("Pedido de build incompleto: " + e.getMessage(), e);
        } catch (OutOfMemoryError e) { throw new BuildException("Memória insuficiente para montar o APK. Feche outros apps e tente de novo.");
        } catch (Exception e) { throw new BuildException(e.getMessage() == null ? e.toString() : e.getMessage(), e); }
    }

    private static byte[] png(Bitmap src, int size) {
        int s = Math.min(src.getWidth(), src.getHeight());
        Bitmap sq = Bitmap.createBitmap(src, (src.getWidth() - s) / 2, (src.getHeight() - s) / 2, s, s);
        Bitmap sc = Bitmap.createScaledBitmap(sq, size, size, true);
        ByteArrayOutputStream o = new ByteArrayOutputStream(); sc.compress(Bitmap.CompressFormat.PNG, 100, o); return o.toByteArray();
    }
    private static String safeFile(String s) { String t = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD).replaceAll("[^A-Za-z0-9._-]+", "-").replaceAll("^-+|-+$", ""); return t.isEmpty() ? "jogo" : (t.length() > 40 ? t.substring(0, 40) : t); }
    static String sha256Hex(byte[] b) throws Exception { StringBuilder s = new StringBuilder(); for (byte x : MessageDigest.getInstance("SHA-256").digest(b)) s.append(String.format("%02x", x)); return s.toString(); }

    private static String save(Context ctx, String fileName, byte[] apk) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = ctx.getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, fileName); v.put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive");
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Kix"); v.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) throw new IOException("Não foi possível criar o arquivo em Downloads.");
            try (OutputStream o = cr.openOutputStream(u)) { if (o == null) throw new IOException("Falha ao abrir o arquivo."); o.write(apk); }
            v.clear(); v.put(MediaStore.Downloads.IS_PENDING, 0); cr.update(u, v, null, null);
            return u.toString();
        }
        File dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS); if (dir == null) dir = ctx.getFilesDir();
        File f = new File(dir, fileName); try (FileOutputStream o = new FileOutputStream(f)) { o.write(apk); }
        return f.getAbsolutePath();
    }
}
