package com.kix.engine;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Edits a compiled (binary) AndroidManifest.xml in place without aapt.
 * Strategy: strings are only APPENDED to the string pool (indices of existing strings never change),
 * attributes are re-pointed or have their int payload overwritten, and unwanted
 * <uses-permission> elements are cut out of the chunk stream. Pure Java, no Android deps.
 */
public final class AxmlPatcher {
    public static final class Edit {
        public String packageName, versionName, label;
        public Integer versionCode, minSdk, targetSdk, orientation; // orientation: android int (0 landscape, 1 portrait)
        public boolean dropForeignDeclarations = true;
        public Set<String> keepPermissions; // null = keep all; otherwise only these android.permission.* names survive
    }

    private static final int RES_XML = 0x0003, STRING_POOL = 0x0001, RESMAP = 0x0180,
            START_NS = 0x0100, END_NS = 0x0101, START_EL = 0x0102, END_EL = 0x0103;
    private static final int RID_NAME = 0x01010003, RID_LABEL = 0x01010001, RID_ORIENT = 0x0101001e,
            RID_MINSDK = 0x0101020c, RID_TARGET = 0x01010270, RID_VCODE = 0x0101021b, RID_VNAME = 0x0101021c;
    private static final int T_STRING = 0x03, T_INT_DEC = 0x10;

    private static final class Pool {
        boolean utf8; List<String> strings = new ArrayList<>();
        int add(String s) { strings.add(s); return strings.size() - 1; }
    }

    public static byte[] patch(byte[] in, Edit e) {
        ByteBuffer b = ByteBuffer.wrap(in).order(ByteOrder.LITTLE_ENDIAN);
        if (b.getShort(0) != RES_XML) throw new IllegalArgumentException("Manifest não é AXML.");
        int pos = b.getShort(2) & 0xffff;
        int poolStart = pos;
        if (b.getShort(pos) != STRING_POOL) throw new IllegalArgumentException("String pool ausente.");
        int poolSize = b.getInt(pos + 4);
        Pool pool = readPool(b, pos);
        pos += poolSize;

        // resource map
        int[] resIds = new int[0]; byte[] resChunk = new byte[0];
        if (b.getShort(pos) == RESMAP) {
            int sz = b.getInt(pos + 4);
            int n = (sz - 8) / 4; resIds = new int[n];
            for (int i = 0; i < n; i++) resIds[i] = b.getInt(pos + 8 + i * 4);
            resChunk = Arrays.copyOfRange(in, pos, pos + sz);
            pos += sz;
        }
        ByteArrayOutputStream body = new ByteArrayOutputStream();
        boolean sawManifest = false;
        int skipDepth = 0;
        int depth = 0;
        while (pos < in.length) {
            int type = b.getShort(pos) & 0xffff, hdr = b.getShort(pos + 2) & 0xffff, size = b.getInt(pos + 4);
            byte[] chunk = Arrays.copyOfRange(in, pos, pos + size);
            ByteBuffer c = ByteBuffer.wrap(chunk).order(ByteOrder.LITTLE_ENDIAN);
            if (skipDepth > 0) { // inside a removed element
                if (type == START_EL) skipDepth++;
                else if (type == END_EL) skipDepth--;
                pos += size; continue;
            }
            if (type == START_EL) {
                String el = str(pool, c.getInt(20));
                int attrStart = c.getShort(24) & 0xffff, attrSize = c.getShort(26) & 0xffff, attrCount = c.getShort(28) & 0xffff;
                int base = hdr + attrStart;
                // Library-contributed <permission>/<provider> embed the ORIGINAL applicationId (e.g. androidx.core's
                // DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION). Two apps with different signatures declaring the same name
                // fail to install (INSTALL_FAILED_DUPLICATE_PERMISSION / CONFLICTING_PROVIDER), so they are removed.
                if (("permission".equals(el) || "provider".equals(el)) && e.dropForeignDeclarations) { skipDepth = 1; pos += size; continue; }
                if ("uses-permission".equals(el) || "uses-permission-sdk-23".equals(el)) {
                    if (e.keepPermissions != null) {
                        String pname = null;
                        for (int i = 0; i < attrCount; i++) {
                            int o = base + i * attrSize;
                            if (resId(resIds, c.getInt(o + 4)) == RID_NAME) pname = valueString(pool, c, o);
                        }
                        if (pname != null && !e.keepPermissions.contains(pname)) { skipDepth = 1; pos += size; continue; }
                    }
                }
                for (int i = 0; i < attrCount; i++) {
                    int o = base + i * attrSize;
                    int nameIdx = c.getInt(o + 4);
                    int rid = resId(resIds, nameIdx);
                    String aname = str(pool, nameIdx);
                    if ("manifest".equals(el)) {
                        sawManifest = true;
                        if (rid == RID_VCODE && e.versionCode != null) setInt(c, o, e.versionCode);
                        else if (rid == RID_VNAME && e.versionName != null) setStr(c, o, pool.add(e.versionName));
                        else if (rid == 0 && "package".equals(aname) && e.packageName != null) setStr(c, o, pool.add(e.packageName));
                    } else if ("uses-sdk".equals(el)) {
                        if (rid == RID_MINSDK && e.minSdk != null) setInt(c, o, e.minSdk);
                        else if (rid == RID_TARGET && e.targetSdk != null) setInt(c, o, e.targetSdk);
                    } else if ("application".equals(el)) {
                        if (rid == RID_LABEL && e.label != null) setStr(c, o, pool.add(e.label));
                    } else if ("activity".equals(el)) {
                        if (rid == RID_ORIENT && e.orientation != null) setInt(c, o, e.orientation);
                        else if (rid == RID_LABEL && e.label != null) setStr(c, o, pool.add(e.label));
                    }
                }
            }
            body.write(chunk, 0, chunk.length);
            pos += size;
        }
        if (!sawManifest) throw new IllegalArgumentException("Elemento <manifest> não encontrado.");
        byte[] poolBytes = writePool(pool);
        int total = 8 + poolBytes.length + resChunk.length + body.size();
        ByteBuffer out = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN);
        out.putShort((short) RES_XML).putShort((short) 8).putInt(total);
        out.put(poolBytes).put(resChunk).put(body.toByteArray());
        return out.array();
    }

    private static int resId(int[] ids, int nameIdx) { return nameIdx >= 0 && nameIdx < ids.length ? ids[nameIdx] : 0; }
    private static String str(Pool p, int i) { return i >= 0 && i < p.strings.size() ? p.strings.get(i) : null; }
    private static String valueString(Pool p, ByteBuffer c, int o) {
        int raw = c.getInt(o + 8);
        if (raw >= 0) return str(p, raw);
        return (c.get(o + 15) & 0xff) == T_STRING ? str(p, c.getInt(o + 16)) : null;
    }
    private static void setInt(ByteBuffer c, int o, int v) { c.putInt(o + 8, -1); c.putShort(o + 12, (short) 8); c.put(o + 14, (byte) 0); c.put(o + 15, (byte) T_INT_DEC); c.putInt(o + 16, v); }
    private static void setStr(ByteBuffer c, int o, int idx) { c.putInt(o + 8, idx); c.putShort(o + 12, (short) 8); c.put(o + 14, (byte) 0); c.put(o + 15, (byte) T_STRING); c.putInt(o + 16, idx); }

    // ---- string pool ----
    private static Pool readPool(ByteBuffer b, int base) {
        int hdr = b.getShort(base + 2) & 0xffff, count = b.getInt(base + 8), styles = b.getInt(base + 12), flags = b.getInt(base + 16), strStart = b.getInt(base + 20);
        if (styles != 0) throw new IllegalArgumentException("String pool com estilos não suportado no manifesto.");
        Pool p = new Pool(); p.utf8 = (flags & 0x100) != 0;
        for (int i = 0; i < count; i++) {
            int off = base + strStart + b.getInt(base + hdr + i * 4);
            p.strings.add(p.utf8 ? readUtf8(b, off) : readUtf16(b, off));
        }
        return p;
    }
    private static String readUtf16(ByteBuffer b, int off) {
        int len = b.getShort(off) & 0xffff, o = off + 2;
        if ((len & 0x8000) != 0) { len = ((len & 0x7fff) << 16) | (b.getShort(o) & 0xffff); o += 2; }
        char[] ch = new char[len];
        for (int i = 0; i < len; i++) ch[i] = (char) (b.getShort(o + i * 2) & 0xffff);
        return new String(ch);
    }
    private static String readUtf8(ByteBuffer b, int off) {
        int o = off, u = b.get(o++) & 0xff; if ((u & 0x80) != 0) { o++; }
        int l = b.get(o++) & 0xff; if ((l & 0x80) != 0) { l = ((l & 0x7f) << 8) | (b.get(o++) & 0xff); }
        byte[] d = new byte[l]; for (int i = 0; i < l; i++) d[i] = b.get(o + i);
        return new String(d, StandardCharsets.UTF_8);
    }
    private static byte[] writePool(Pool p) {
        int n = p.strings.size();
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        int[] offs = new int[n];
        for (int i = 0; i < n; i++) {
            offs[i] = data.size();
            String s = p.strings.get(i);
            if (p.utf8) {
                byte[] u = s.getBytes(StandardCharsets.UTF_8);
                lenUtf8(data, s.length()); lenUtf8(data, u.length); data.write(u, 0, u.length); data.write(0);
            } else {
                int l = s.length();
                if (l > 0x7fff) { data.write(((l >> 16) | 0x80) & 0xff); data.write((l >> 24) & 0xff); data.write(l & 0xff); data.write((l >> 8) & 0xff); }
                else { data.write(l & 0xff); data.write((l >> 8) & 0xff); }
                for (int k = 0; k < l; k++) { char ch = s.charAt(k); data.write(ch & 0xff); data.write(ch >> 8); }
                data.write(0); data.write(0);
            }
        }
        while (data.size() % 4 != 0) data.write(0);
        int hdr = 28, strStart = hdr + n * 4, total = strStart + data.size();
        ByteBuffer o = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN);
        o.putShort((short) STRING_POOL).putShort((short) hdr).putInt(total).putInt(n).putInt(0).putInt(p.utf8 ? 0x100 : 0).putInt(strStart).putInt(0);
        for (int x : offs) o.putInt(x);
        o.put(data.toByteArray());
        return o.array();
    }
    private static void lenUtf8(ByteArrayOutputStream o, int l) { if (l > 0x7f) { o.write(((l >> 8) & 0x7f) | 0x80); o.write(l & 0xff); } else o.write(l); }
}
