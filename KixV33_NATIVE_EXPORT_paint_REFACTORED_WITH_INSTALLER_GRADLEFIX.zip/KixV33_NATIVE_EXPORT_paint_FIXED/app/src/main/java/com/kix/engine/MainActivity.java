package com.kix.engine;
import android.app.Activity;import android.content.pm.PackageManager;import android.os.Bundle;import android.Manifest;import android.view.View;import android.webkit.PermissionRequest;import android.webkit.WebChromeClient;import android.webkit.WebSettings;import android.webkit.WebView;import android.webkit.WebResourceRequest;import android.webkit.WebResourceResponse;import android.webkit.RenderProcessGoneDetail;import android.widget.Toast;import androidx.webkit.WebViewAssetLoader;import androidx.webkit.WebViewClientCompat;import android.webkit.JavascriptInterface;import android.content.SharedPreferences;import android.webkit.ConsoleMessage;import android.webkit.ValueCallback;import android.content.Intent;import android.net.Uri;import org.json.JSONObject;import java.util.ArrayList;import android.hardware.Sensor;import android.hardware.SensorEvent;import android.hardware.SensorEventListener;import android.hardware.SensorManager;import android.location.Location;import android.location.LocationManager;import android.content.Context;import android.os.Build;import java.util.Locale;import java.util.concurrent.ConcurrentHashMap;import java.util.concurrent.ExecutorService;import java.util.concurrent.Executors;import java.util.concurrent.atomic.AtomicBoolean;import android.provider.Settings;
public class MainActivity extends Activity{
 private WebView webView;private KixAssetStore kixAssetStore;private boolean privateAssetsReady;private volatile String currentUrl="";private boolean exportedApp;private final ExecutorService buildExec=Executors.newSingleThreadExecutor();private final ConcurrentHashMap<String,AtomicBoolean> buildJobs=new ConcurrentHashMap<>();private WebViewAssetLoader assetLoader;private ValueCallback<Uri[]> filePathCallback;private static final int FILE_CHOOSER_CODE=7104;private SharedPreferences prefs;private SensorManager sensorManager;private LocationManager locationManager;private final float[] accel=new float[3],gyro=new float[3],mag=new float[3];private static final String STATE_KEY="runtime_state";private static final String[] SENSOR_PERMS={Manifest.permission.RECORD_AUDIO,Manifest.permission.CAMERA,Manifest.permission.ACCESS_FINE_LOCATION};
 @Override public void onCreate(Bundle state){super.onCreate(state);prefs=getSharedPreferences("kix_runtime",MODE_PRIVATE);exportedApp=assetExists("kix/exported.flag");sensorManager=(SensorManager)getSystemService(Context.SENSOR_SERVICE);locationManager=(LocationManager)getSystemService(Context.LOCATION_SERVICE);if(!exportedApp){try{kixAssetStore=new KixAssetStore(this,BuildConfig.KIX_UPDATE_MANIFEST_URL);kixAssetStore.prepareFromApk(BuildConfig.VERSION_CODE);privateAssetsReady=true;}catch(Exception e){android.util.Log.e("KixRuntime","Não foi possível preparar assets privados; usando os assets do APK.",e);privateAssetsReady=false;}}setupWebView();if(state!=null&&webView!=null)webView.restoreState(state);else loadRuntime();if(kixAssetStore!=null&&privateAssetsReady)kixAssetStore.checkForUpdate((updated,error)->{if(error!=null)android.util.Log.w("KixRuntime","Atualização de assets não aplicada: "+error);if(updated&&!isFinishing()&&webView!=null&&!exportedApp){webView.clearCache(true);webView.clearHistory();loadRuntime();}});}
 private WebViewAssetLoader.PathHandler withModuleMime(WebViewAssetLoader.PathHandler delegate){return new WebViewAssetLoader.PathHandler(){@Override public WebResourceResponse handle(String path){WebResourceResponse response=delegate.handle(path);if(response!=null&&response.getData()!=null&&path!=null&&path.toLowerCase(Locale.ROOT).endsWith(".mjs"))return new WebResourceResponse("application/javascript","UTF-8",response.getData());return response;}};}
 private void setupWebView(){WebViewAssetLoader.PathHandler apkHandler=withModuleMime(new WebViewAssetLoader.AssetsPathHandler(this));WebViewAssetLoader.Builder loaderBuilder=new WebViewAssetLoader.Builder().addPathHandler("/assets/",apkHandler);if(!exportedApp&&privateAssetsReady)loaderBuilder.addPathHandler("/kix/",withModuleMime(new WebViewAssetLoader.InternalStoragePathHandler(this,new java.io.File(getFilesDir(),"kix"))));assetLoader=loaderBuilder.build();webView=new WebView(this);WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setTextZoom(100);s.setDomStorageEnabled(true);s.setDatabaseEnabled(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);s.setMediaPlaybackRequiresUserGesture(false);s.setBuiltInZoomControls(false);s.setDisplayZoomControls(false);webView.setBackgroundColor(0xFF0D0D0F);webView.setOverScrollMode(View.OVER_SCROLL_NEVER);webView.addJavascriptInterface(new AndroidRuntimeBridge(),"AndroidRuntimeBridge");if(!exportedApp)webView.addJavascriptInterface(new KixBuilderBridge(),"Android");webView.setWebViewClient(new WebViewClientCompat(){@Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap f){currentUrl=url==null?"":url;super.onPageStarted(v,url,f);}@Override public void onPageFinished(WebView v,String url){super.onPageFinished(v,url);if(!exportedApp&&privateAssetsReady&&url!=null&&url.startsWith("https://appassets.androidplatform.net/assets/kix/index.html")){v.post(()->{if(webView==v&&!isFinishing()){v.clearHistory();loadRuntime();}});}}@Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){return assetLoader.shouldInterceptRequest(r.getUrl());}@Override public boolean onRenderProcessGone(WebView v,RenderProcessGoneDetail d){showRuntimeFailure(d!=null&&d.didCrash()?"WebView renderer crashed":"WebView renderer exited");return true;}});webView.setWebChromeClient(new WebChromeClient(){
@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> callback,FileChooserParams params){
    if(filePathCallback!=null)filePathCallback.onReceiveValue(null);
    filePathCallback=callback;
    try{
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        startActivityForResult(i,FILE_CHOOSER_CODE);
    }catch(Exception e){
        filePathCallback=null;
        callback.onReceiveValue(null);
    }
    return true;
}@Override public void onPermissionRequest(final PermissionRequest r){runOnUiThread(()->{ArrayList<String> allowed=new ArrayList<>();for(String x:r.getResources()){if(PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(x)&&declaredGranted(Manifest.permission.RECORD_AUDIO))allowed.add(x);if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(x)&&declaredGranted(Manifest.permission.CAMERA))allowed.add(x);}if(allowed.isEmpty())r.deny();else r.grant(allowed.toArray(new String[0]));});}@Override public boolean onConsoleMessage(ConsoleMessage m){if(m!=null){if(m.messageLevel()==ConsoleMessage.MessageLevel.ERROR)showRuntimeFailure(m.message());else android.util.Log.d("KixRuntime","JS: "+m.message());}return true;}});setContentView(webView);applyFullscreen();}
 private boolean declaredGranted(String p){return getPackageManager().checkPermission(p,getPackageName())==PackageManager.PERMISSION_GRANTED&&(android.os.Build.VERSION.SDK_INT<23||checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED);}
 private void loadRuntime(){webView.loadUrl(exportedApp?"https://appassets.androidplatform.net/assets/kix/runtime.html":(privateAssetsReady?"https://appassets.androidplatform.net/kix/index.html":"https://appassets.androidplatform.net/assets/kix/index.html"));}
 private void applyFullscreen(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}
 private void showRuntimeFailure(String m){runOnUiThread(()->{if(webView!=null)webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('kix-native-error',{detail:"+JSONObject.quote(String.valueOf(m))+"}));",null);Toast.makeText(this,"Kix: "+m,Toast.LENGTH_LONG).show();});}
 @Override protected void onStart(){super.onStart();if(webView!=null)webView.resumeTimers();registerSensors();}@Override protected void onResume(){super.onResume();if(webView!=null)webView.onResume();}@Override protected void onPause(){if(webView!=null)webView.onPause();super.onPause();}@Override protected void onStop(){unregisterSensors();if(webView!=null)webView.pauseTimers();super.onStop();}@Override public void onWindowFocusChanged(boolean f){super.onWindowFocusChanged(f);if(f)applyFullscreen();}@Override protected void onSaveInstanceState(Bundle out){if(webView!=null)webView.saveState(out);super.onSaveInstanceState(out);}@Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    if(requestCode==FILE_CHOOSER_CODE){
        if(filePathCallback!=null){
            Uri[] results=null;
            if(resultCode==RESULT_OK&&data!=null){
                if(data.getClipData()!=null){
                    int n=data.getClipData().getItemCount();results=new Uri[n];
                    for(int i=0;i<n;i++)results[i]=data.getClipData().getItemAt(i).getUri();
                }else if(data.getData()!=null){results=new Uri[]{data.getData()};}
            }
            filePathCallback.onReceiveValue(results);filePathCallback=null;
        }
    }
    super.onActivityResult(requestCode,resultCode,data);
}
@Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){super.onRequestPermissionsResult(requestCode,permissions,grantResults);String kind=requestCode==7101?"camera":requestCode==7102?"microphone":requestCode==7103?"location":null;if(kind!=null&&webView!=null){boolean granted=grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED;webView.evaluateJavascript("window.KixAndroidPermissionResult&&window.KixAndroidPermissionResult("+JSONObject.quote(kind)+","+granted+")",null);}}@Override protected void onDestroy(){unregisterSensors();if(webView!=null){webView.stopLoading();webView.loadUrl("about:blank");webView.destroy();webView=null;}buildExec.shutdownNow();if(kixAssetStore!=null)kixAssetStore.close();super.onDestroy();}@Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}@Override public void onMultiWindowModeChanged(boolean multi){super.onMultiWindowModeChanged(multi);if(webView!=null)webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('kix-window-mode',{detail:"+multi+"}));",null);}
 public final class AndroidRuntimeBridge{
  @JavascriptInterface public String loadRuntimeState(){return prefs.getString(STATE_KEY,"");}
  @JavascriptInterface public void saveRuntimeState(String json){if(json!=null)prefs.edit().putString(STATE_KEY,json).apply();}
  @JavascriptInterface public void clearRuntimeState(){prefs.edit().remove(STATE_KEY).apply();}
  @JavascriptInterface public double readSensor(String name){if(name==null)return 0;switch(name){case "acelerometro_x":return accel[0];case "acelerometro_y":return accel[1];case "acelerometro_z":return accel[2];case "giroscopio_alpha":return gyro[0];case "giroscopio_beta":return gyro[1];case "giroscopio_gamma":return gyro[2];case "bussola":return compass();case "inclinacao_x":return tiltX();case "inclinacao_y":return tiltY();case "inclinacao_z":return accel[2];case "gps_latitude":case "gps_longitude":case "gps_precisao":return locationValue(name);default:return 0;}}
  @JavascriptInterface public boolean requestSensorPermission(String kind){String p=permissionFor(kind);if(p==null||Build.VERSION.SDK_INT<23)return p==null||Build.VERSION.SDK_INT<23||checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED;if(checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED)return true;requestPermissions(new String[]{p},requestCode(p));return false;}
  @JavascriptInterface public boolean hasSensorPermission(String kind){String p=permissionFor(kind);return p==null||Build.VERSION.SDK_INT<23||checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED;}
  private String permissionFor(String kind){if("camera".equals(kind))return Manifest.permission.CAMERA;if("microphone".equals(kind))return Manifest.permission.RECORD_AUDIO;if("location".equals(kind))return Manifest.permission.ACCESS_FINE_LOCATION;return null;}
  private int requestCode(String p){return Manifest.permission.CAMERA.equals(p)?7101:Manifest.permission.RECORD_AUDIO.equals(p)?7102:7103;}
}

 private boolean assetExists(String path){try(java.io.InputStream i=getAssets().open(path)){return true;}catch(Exception e){return false;}}
 private void emitBuild(JSONObject o){final String js="window.KixBuildEvent&&window.KixBuildEvent("+JSONObject.quote(o.toString())+")";runOnUiThread(()->{if(webView!=null)webView.evaluateJavascript(js,null);});}
 private static final String ORIGIN="https://appassets.androidplatform.net/";
 public final class KixBuilderBridge{
  @JavascriptInterface public String getBuilderCapabilities(){try{JSONObject o=new JSONObject();o.put("nativeBuild",true);o.put("signing","v2");o.put("customKey",false);o.put("canInstall",Build.VERSION.SDK_INT<26||getPackageManager().canRequestPackageInstalls());return o.toString();}catch(Exception e){return "{}";}}
  @JavascriptInterface public String startBuild(final String requestJson){
   try{
    if(currentUrl==null||!currentUrl.startsWith(ORIGIN))return err("Origem não autorizada.");
    if(requestJson==null||requestJson.length()>80*1024*1024)return err("Pedido vazio ou grande demais.");
    final JSONObject req=new JSONObject(requestJson);final String id=java.util.UUID.randomUUID().toString();final AtomicBoolean cancel=new AtomicBoolean(false);
    if(!buildJobs.isEmpty())return err("Já existe uma exportação em andamento.");
    buildJobs.put(id,cancel);
    buildExec.execute(()->{
     try{
      ApkExporter.Result r=ApkExporter.export(MainActivity.this,req,new ApkExporter.Progress(){
       public void on(String phase,int pct,String msg){try{JSONObject o=new JSONObject();o.put("jobId",id);o.put("type","progress");o.put("phase",phase);o.put("percent",pct);o.put("message",msg);emitBuild(o);}catch(Exception ignore){}}
       public boolean cancelled(){return cancel.get();}});
      JSONObject o=new JSONObject();o.put("jobId",id);o.put("type","done");o.put("outputUri",r.uri);o.put("name",r.name);o.put("sha256",r.sha256);o.put("packageId",r.packageId);o.put("versionCode",r.versionCode);o.put("installable",r.installable);o.put("fingerprint",r.fingerprint);if(r.warning!=null)o.put("warning",r.warning);emitBuild(o);
     }catch(Throwable t){try{JSONObject o=new JSONObject();o.put("jobId",id);o.put("type","error");o.put("message",t.getMessage()==null?t.toString():t.getMessage());emitBuild(o);}catch(Exception ignore){}}
     finally{buildJobs.remove(id);}
    });
    JSONObject ok=new JSONObject();ok.put("ok",true);ok.put("jobId",id);return ok.toString();
   }catch(Exception e){return err("Pedido de build inválido: "+e.getMessage());}
  }
  @JavascriptInterface public void cancelBuild(String jobId){AtomicBoolean c=jobId==null?null:buildJobs.get(jobId);if(c!=null)c.set(true);}
  @JavascriptInterface public String installApk(final String uriStr){
   try{
    if(currentUrl==null||!currentUrl.startsWith(ORIGIN))return err("Origem não autorizada.");
    final Uri uri=Uri.parse(uriStr);if(!"content".equals(uri.getScheme()))return err("Instalação direta indisponível neste Android; abra o arquivo pela pasta Downloads/Kix.");
    if(Build.VERSION.SDK_INT>=26&&!getPackageManager().canRequestPackageInstalls()){
     runOnUiThread(()->{try{startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName())));}catch(Exception e){Toast.makeText(MainActivity.this,"Permita instalar apps desconhecidos para o Kix nas configurações.",Toast.LENGTH_LONG).show();}});
     JSONObject o=new JSONObject();o.put("ok",false);o.put("needsPermission",true);o.put("error","Permita \"Instalar apps desconhecidos\" para o Kix e toque em Instalar de novo.");return o.toString();
    }
    runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(uri,"application/vnd.android.package-archive");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}catch(Exception e){Toast.makeText(MainActivity.this,"Não foi possível abrir o instalador. Abra o APK em Downloads/Kix.",Toast.LENGTH_LONG).show();}});
    return "{\"ok\":true}";
   }catch(Exception e){return err(e.getMessage());}
  }
  private String err(String m){try{JSONObject o=new JSONObject();o.put("ok",false);o.put("error",m);return o.toString();}catch(Exception e){return "{\"ok\":false}";}}
 }
private void registerSensors(){if(sensorManager==null)return;Sensor a=sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),g=sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE),m=sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);if(a!=null)sensorManager.registerListener(sensorListener,a,SensorManager.SENSOR_DELAY_GAME);if(g!=null)sensorManager.registerListener(sensorListener,g,SensorManager.SENSOR_DELAY_GAME);if(m!=null)sensorManager.registerListener(sensorListener,m,SensorManager.SENSOR_DELAY_GAME);}
private void unregisterSensors(){if(sensorManager!=null)sensorManager.unregisterListener(sensorListener);}
private final SensorEventListener sensorListener=new SensorEventListener(){public void onSensorChanged(SensorEvent e){if(e.sensor.getType()==Sensor.TYPE_ACCELEROMETER)System.arraycopy(e.values,0,accel,0,Math.min(3,e.values.length));else if(e.sensor.getType()==Sensor.TYPE_GYROSCOPE)System.arraycopy(e.values,0,gyro,0,Math.min(3,e.values.length));else if(e.sensor.getType()==Sensor.TYPE_MAGNETIC_FIELD)System.arraycopy(e.values,0,mag,0,Math.min(3,e.values.length));}public void onAccuracyChanged(Sensor s,int a){}};
private double compass(){float[] R=new float[9],I=new float[9];if(!SensorManager.getRotationMatrix(R,I,accel,mag))return 0;float[] o=new float[3];SensorManager.getOrientation(R,o);double deg=Math.toDegrees(o[0]);return deg<0?deg+360:deg;}
private double tiltX(){return Math.toDegrees(Math.atan2(accel[1],Math.sqrt(accel[0]*accel[0]+accel[2]*accel[2])));}
private double tiltY(){return Math.toDegrees(Math.atan2(-accel[0],Math.sqrt(accel[1]*accel[1]+accel[2]*accel[2])));}
private double locationValue(String name){try{if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)return 0;Location best=null;for(String provider:new String[]{LocationManager.GPS_PROVIDER,LocationManager.NETWORK_PROVIDER}){if(locationManager!=null&&locationManager.isProviderEnabled(provider)){Location l=locationManager.getLastKnownLocation(provider);if(l!=null&&(best==null||l.getTime()>best.getTime()))best=l;}}if(best==null)return 0;if("gps_latitude".equals(name))return best.getLatitude();if("gps_longitude".equals(name))return best.getLongitude();return best.getAccuracy();}catch(Exception e){return 0;}}
}
