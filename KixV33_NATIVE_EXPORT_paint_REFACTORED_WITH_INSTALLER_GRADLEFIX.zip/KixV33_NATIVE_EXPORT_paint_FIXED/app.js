// ============================================================
// Kix — Visual Programming Studio (v2)
// ============================================================
const KIX_APP_VERSION = '1.7.5';

// Names of block parameters that use the visual project-image picker.
var IMAGE_PARAM_PICKER_BLOCKS = new Set([
  'Definir sprite da base',
  'Definir sprite do manípulo',
  'Definir sprite dos botões',
  'Spritesheet',
  'Definir GIF como aparência',
  'Tocar GIF',
  'Definir sprites do D-Pad',
  'Definir sprite da seta do D-Pad'
]);

// Visual labels are separate from engine block names. This keeps the runtime/save format
// backwards-compatible while making the blocks read like natural Portuguese.
const BLOCK_VISUAL_LABELS = {
  'Se ... então': 'Se {condição} for verdadeira então',
  'Se ... então ... senão': 'Se {condição} for verdadeira então',
  'Se [Fórmula] for verdadeira então...': 'Se {condição} for verdadeira então',
  'Tentar ... se erro': 'Tentar e, se ocorrer um erro, mostrar {mensagem}',
  'Se estiver na borda, volte': 'Se estiver na borda volte',
  // Eventos e controle
  'Quando cronômetro >': 'Quando o cronômetro passar de {segundos} segundos',
  'Quando entrar na região': 'Quando entrar na região em X {x} e Y {y} com tamanho {largura} por {altura}',
  'Quando sair da região': 'Quando sair da região em X {x} e Y {y} com tamanho {largura} por {altura}',
  'Esperar X segundos': 'Esperar {segundos} segundos',
  'Se tocado X vezes seguidamente': 'Se for tocado {vezes} vezes seguidas',
  'Debounce por X ms': 'Aguardar {ms} ms entre toques',
  'Throttle a cada X ms': 'Limitar a 1 execução a cada {ms} ms',
  'Executar após frames': 'Executar após {quadros} frames',
  'Com chance % faça': 'Se houver {porcentagem}% de chance fazer',
  'Repetir para sempre com delay': 'Repetir para sempre com intervalo de {segundos} segundos',
  'Sempre': 'Sempre',
  'Repita X vezes': 'Repetir {vezes} vezes',
  'Repita até': 'Repetir até {condição}',
  'Repita enquanto': 'Repetir enquanto {condição}',
  'Se variável = faça': 'Se {variável} = {valor} executar',
  'Transição fade para cena': 'Ir para a cena {cena} com fade em {segundos} segundos',
  'Transição fade para [cena] em [segundos]': 'Ir para a cena {cena} com fade em {segundos} segundos',
  'Mudar para cena': 'Mudar para a cena {cena}',

  'câmera no jogador': 'Câmera no jogador {ator}',
  'reset completo da câmera': 'Reset completo da câmera',
  'zoom de impacto': 'Zoom de impacto {valor} em {segundos} segundos',
  'seguir com suavidade': 'Seguir {ator} com suavidade {suavidade}',
  'bounds do palco': 'Limites do palco',

  // Movimento
  'Mover X passos': 'Mover {passos} passos',
  'Girar direita X graus': 'Girar {graus} para a direita',
  'Girar esquerda X graus': 'Girar {graus} para a esquerda',
  'Ir para X e Y': 'Ir para X {x} e Y {y}',
  'Deslizar em X segundos até X: Y:': 'Deslizar até X {x} e Y {y} em {segundos} s',
  'Apontar para direção X': 'Apontar para {direção} graus',
  'Mover na direção': 'Mover {passos} passos na direção {graus} graus',
  'Seguir objeto': 'Seguir {objeto} por {passos} passos',
  'Afastar de objeto': 'Afastar de {objeto} por {passos} passos',
  'Definir velocidade X': 'Definir velocidade X para {valor}',
  'Definir velocidade Y': 'Definir velocidade Y para {valor}',
  'Mover em círculo': 'Mover em círculo com raio {raio} e ângulo {graus} graus',
  'Empurrar com força': 'Empurrar com força {força} na direção {direção} graus',
  'Seguir joystick': 'Seguir joystick {id} apontar {apontar} velocidade {velocidade}',
  'Definir gravidade personalizada': 'Definir gravidade em X {x} e Y {y}',
  'Raycast': 'Lançar raio de X {x} e Y {y} com ângulo {ângulo} graus',
  'Aplicar Impulso': 'Aplicar impulso X {x} Y {y}',
  'Definir tamanho da colisão': 'Definir colisão com largura {largura} e altura {altura}',
  'Definir deslocamento da colisão': 'Deslocar colisão em X {x} e Y {y}',
  'Verificar colisão com': 'Verificar colisão com {objeto} e salvar em {variável}',
  'Empurrar ao colidir': 'Ao colidir empurrar com força {força}',
  'Mover até colidir': 'Mover até colidir com {objeto} no máximo {passos} passos',
  'Definir camada de colisão': 'Definir camada de colisão para {camada}',
  'Definir máscara de colisão': 'Definir máscara de colisão para {máscara}',

  // Joystick / controles virtuais
  'Criar joystick virtual': 'Criar Joystick com Id {id}\nEm posição X {x} Y {y}\nCom tamanho {tamanho}',
  'Definir posição do joystick': 'Definir posição do joystick {id} em X {x} e Y {y}',
  'Definir tamanho do joystick': 'Definir tamanho do joystick {id} para {tamanho}',
  'Ler direção do joystick': 'Ler direção do joystick {id} e salvar em {variável}',
  'Ler eixo X do joystick': 'Ler eixo X do joystick {id} e salvar em {variável}',
  'Ler eixo Y do joystick': 'Ler eixo Y do joystick {id} e salvar em {variável}',
  'Ler força do joystick (analógico)': 'Ler força do joystick {id} e salvar em {variável}',
  'Criar botão de ação': 'Criar botão {id} com texto {texto}',
  'Criar D-pad': 'Criar D-pad {id}',
  'Criar D-Pad': 'Criar D-Pad Id {id}\nCima = {cima}\nEsquerda = {esquerda}\nDireita = {direita}\nBaixo = {baixo}',
  'Trocar skin do D-pad': 'Trocar skin do D-Pad {id} para {estilo}',
  'Definir sprites do D-Pad': 'Definir sprites do D-Pad {id}\nFundo {fundo}\nCima {cima} Baixo {baixo}\nEsquerda {esquerda} Direita {direita}',
  'Definir sprite da seta do D-pad': 'Definir sprite da seta {direção} do D-Pad {id} para {imagem}',
  'Definir opacidade do D-pad': 'Definir opacidade do D-Pad {id} para {opacidade}',
  'Definir cor do D-pad': 'Definir cor do D-Pad {id} para {cor}',
  'Restaurar sprite padrão do D-pad': 'Restaurar sprite padrão do D-Pad {id}',
  'Remover controles virtuais': 'Remover controles virtuais {id}',
  'Definir sprite da base': 'Definir sprite da base do joystick {id} para {imagem}',
  'Definir sprite do manípulo': 'Definir sprite do manípulo do joystick {id} para {imagem}',
  'Definir sprite dos botões': 'Definir sprite dos botões do joystick {id} para {imagem}',
  'Trocar skin do joystick': 'Trocar skin do joystick {id} para {preset}',
  'Definir opacidade do joystick': 'Definir opacidade do joystick {id} para {opacidade}',
  'Definir cor de tint do joystick': 'Definir cor do joystick {id} para {cor}',
  'Restaurar sprite padrão': 'Restaurar sprite padrão do joystick {id}',

  // Aparência
  'Mudar para fantasia/costume': 'Mudar para {costume}',
  'Definir GIF como aparência': 'Definir {imagem} como aparência',
  'Tocar GIF': 'Tocar GIF {imagem}',
  'Mudar tamanho em': 'Mudar tamanho em {valor}%',
  'Definir tamanho para': 'Definir tamanho para {valor}%',
  'Mudar efeito gráfico em': 'Mudar efeito {efeito} em {valor}',
  'Definir efeito para': 'Definir efeito {efeito} para {valor}',
  'Ir para camada': 'Ir para a camada {camada}',
  'Mudar camada em': 'Mudar camada em {valor}',
  'Mudar transparência em': 'Mudar transparência em {valor}%',
  'Definir transparência para': 'Definir transparência para {valor}%',
  'Definir aparência para número': 'Definir aparência para o número {número}',
  'Definir aparência para nome': 'Definir aparência {nome}',
  'Trocar cor': 'Trocar a cor {de} por {para}',
  'Dizer': 'Mostrar “{texto}” por {segundos} segundos',
  'Piscar X vezes': 'Piscar {vezes} vezes',
  'Outline': 'Adicionar contorno {cor} com espessura {espessura}',
  'Definir taxa de emissão': 'Definir taxa de emissão para {valor}',
  'Definir cor da partícula': 'Definir cor da partícula para {cor}',
  'Tocar pasta em loop na velocidade': 'Tocar {pasta} em loop a {fps} FPS',
  'Tocar pasta uma vez na velocidade': 'Tocar {pasta} uma vez a {fps} FPS',
  'Definir quadro da animação para': 'Definir quadro da animação para {número}',
  'Definir velocidade da animação para': 'Definir velocidade da animação para {valor}',
  'Definir cor': 'Definir a cor {de} para {para} com tolerância {tolerância}',
  'Definir opacidade': 'Definir opacidade para {valor}%',
  'Mudar opacidade em': 'Mudar opacidade em {valor}%',
  'Aparecer gradualmente': 'Aparecer gradualmente em {segundos} segundos',
  'Desaparecer gradualmente': 'Desaparecer gradualmente em {segundos} segundos',
  'Definir efeito': 'Definir efeito {efeito} para {valor}',
  'Mudar efeito em': 'Mudar efeito {efeito} em {valor}',
  'Piscar': 'Piscar {vezes} vezes por {segundos} segundos',
  'Tocar pasta': 'Tocar {pasta} no modo {modo} a {fps} FPS ao terminar {ao terminar}',
  'Definir quadro': 'Definir quadro para {número}',
  'Inverter ordem da pasta': 'Inverter ordem da pasta {pasta}',
  'Tintar sprite': 'Tintar sprite com {cor} ({intensidade}%)',
  'Flash de hit': 'Flash de hit com {cor} por {frames} frames',
  'Sombra': 'Sombra com cor {cor} em X {offsetX} e Y {offsetY} com desfoque {blur}',
  'Rastro de movimento': 'Rastro de movimento {ligado} com opacidade {opacidade}%',

  // Controle / desenho / texto: complete parameter coverage so no field is appended as a loose orphan.
  'Debounce por X ms':'Aguardar {ms} ms entre ativações',
  'Throttle a cada X ms':'Limitar a uma ativação a cada {ms} ms',
  'Transição fade para cena':'Ir para a cena {cena} em {segundos} segundos com cor {cor} e estilo {estilo}',
  'Transição fade para [cena] em [segundos]':'Ir para a cena {cena} em {segundos} segundos com cor {cor} e estilo {estilo}',
  'Seguir joystick':'Seguir joystick {id} a {velocidade} com apontar {apontar}',
  'Emissor de partículas':'Emissor de partículas {ligado} com taxa {taxa} e cor {cor}',
  'Tocar pasta':'Tocar {pasta} no modo {modo} a {fps} FPS e, ao terminar, {ao terminar}',
  'Escrever texto em tempo real':'Escrever {variável} em X: {x} Y: {y}, tamanho {tamanho}, cor {cor}, fonte {fonte} e ângulo {graus}',
  'Criar texto facilitado':'Criar texto {id} com {texto}, tamanho {tamanho}, cor {cor}, sombra {sombra}, X: {x}, Y: {y} e fonte {fonte}',
  'Efeito de digitação':'Mostrar texto {texto} com efeito de digitação a {velocidade}',
  'Gradiente animado do texto':'Animar gradiente do texto de {cor inicio} para {cor fim} na direção {direcao} com velocidade {velocidade}',
  'Iniciar animacao de texto':'Iniciar animação de texto {tipo} com intensidade {intensidade} e velocidade {velocidade}',
  'Animacao de texto em loop':'Repetir animação de texto {tipo} em loop, intensidade {intensidade} e velocidade {velocidade}',
  'Definir texto com aspas coloridas':'Definir texto {texto} com cor base {cor base} e cor das aspas {cor aspas}',
  'Texto estilizado rapido':'Criar texto estilizado {texto} com fonte {fonte}, tamanho {tamanho}, cor {cor}, contorno {contorno} e sombra {sombra}',
  'Texto HUD rapido':'Mostrar {variavel} no HUD com rótulo {rotulo} na posição {posicao}',
  'Texto de dano flutuante':'Mostrar dano flutuante {texto} na cor {cor} em X: {x} Y: {y}',
  'Caixa de dialogo com digitacao pronta':'Mostrar caixa de diálogo {texto} com velocidade {velocidade}',
  // Dados / listas
  'Definir variável para': 'Definir {variável} para {valor}',
  'Mudar variável em': 'Mudar {variável} em {valor}',
  'Definir variável local para': 'Definir variável local {variável} para {valor}',
  'Mudar variável local em': 'Mudar variável local {variável} em {valor}',
  'Definir variável global para': 'Definir variável global {variável} para {valor}',
  'Mudar variável global em': 'Mudar variável global {variável} em {valor}',
  'Mostrar variável': 'Mostrar variável {variável}',
  'Esconder variável': 'Esconder variável {variável}',
  'Criar lista': 'Criar lista {lista}',
  'Adicionar à lista': 'Adicionar {item} à lista {lista}',
  'Apagar de lista': 'Apagar item {índice} da lista {lista}',
  'Apagar tudo da lista': 'Apagar todos os itens da lista {lista}',
  'Inserir em lista': 'Inserir {item} na posição {índice} da lista {lista}',
  'Substituir item da lista': 'Substituir item {índice} da lista {lista} por {item}',
  'Item da lista': 'Obter item {índice} da lista {lista}',
  'Tamanho da lista': 'Obter tamanho da lista {lista}',
  'Lista contém': 'Verificar se a lista {lista} contém {item}',
  'Mostrar lista': 'Mostrar lista {lista}',
  'Esconder lista': 'Esconder lista {lista}',

  // Texto
  'Mostrar texto': 'Mostrar texto {texto}',
  'Criar texto facilitado': 'Criar texto {id} com {texto} tamanho {tamanho} cor {cor} sombra {sombra}',
  'Definir texto multilinha': 'Definir texto multilinha para {texto}',
  'Definir fonte': 'Definir fonte {fonte}',
  'Definir tamanho da fonte': 'Definir tamanho da fonte para {tamanho}',
  'Definir cor do texto': 'Definir cor do texto para {cor}',
  'Definir negrito e itálico': 'Texto em negrito {negrito} e itálico {italico}',
  'Definir alinhamento': 'Definir alinhamento para {alinhamento}',
  'Definir espaçamento entre linhas': 'Definir espaçamento entre linhas para {espacamento}',
  'Definir contorno (stroke)': 'Definir contorno {cor} com espessura {espessura}',
  'Definir sombra do texto': 'Definir sombra com cor {cor} em X {deslocamento x} e Y {deslocamento y} com desfoque {desfoque}',
  'Definir glow do texto': 'Definir glow {cor} com intensidade {intensidade}',
  'Definir gradiente do texto': 'Gradiente de {cor inicio} para {cor fim} com ângulo {angulo} graus',
  'Efeito de digitação': 'Mostrar texto com efeito de digitação {texto} na velocidade {velocidade}',
  'Quebra de linha automática': 'Quebrar linhas automaticamente em {largura maxima}px',
  'Rotacionar texto': 'Rotacionar texto {graus} graus',
  'Definir opacidade do texto': 'Definir opacidade do texto para {opacidade}%',
  'Interpolar texto (fade in/out)': 'Animar texto de {de} para {para} em {duracao} segundos',
  'Definir texto rico (tags)': 'Definir texto rico para {texto}',
  'Mostrar dado como texto': 'Mostrar {variavel} como texto com prefixo {prefixo}',
  'Pulsar texto': 'Pulsar texto de {escala minima}× a {escala maxima}× na velocidade {velocidade}',
  'Definir posicao X do texto': 'Definir posição X do texto para {x}',
  'Definir posicao Y do texto': 'Definir posição Y do texto para {y}',
  'Mudar X do texto em': 'Mudar X do texto em {valor}',
  'Mudar Y do texto em': 'Mudar Y do texto em {valor}',

  // Som
  'Tocar som': 'Tocar som {som}',
  'Tocar som e esperar terminar': 'Tocar som {som} e esperar terminar',
  'Mudar volume em': 'Mudar volume em {valor}%',
  'Definir volume para': 'Definir volume para {valor}%',
  'Mudar tom (pitch) em': 'Mudar tom em {valor}',
  'Definir tom para': 'Definir tom para {valor}',
  'Definir loop do som': 'Repetir som: {sim}',
  'Falar (texto para voz)': 'Falar {texto}',
  'Falar e esperar': 'Falar {texto} e esperar terminar',
  'Definir idioma da fala': 'Definir idioma da fala para {idioma}',
  'Crossfade': 'Fazer crossfade de {som} em {segundos} segundos',
  'Definir canal': 'Definir canal de áudio para {canal}',
  'Tocar som com volume': 'Tocar som {som} com volume {volume}',
  'Fade out em': 'Fade out em {segundos} segundos',
  'Fade in em': 'Fade in em {segundos} segundos',

  // Câmera
  'Seguir ator com câmera': 'Fazer a câmera seguir {ator}',
  'Zoom da câmera': 'Definir zoom da câmera para {valor}',
  'Shake de câmera': 'Balançar a câmera com intensidade {intensidade}',
  'Definir posição da câmera': 'Definir posição da câmera em X {x} e Y {y}',
  'Mudar posição da câmera em': 'Mudar câmera em X {x} e Y {y}',
  'Deslizar câmera até': 'Deslizar câmera até X {x} Y {y} em {segundos} segundos',
  'Zoom suave até': 'Fazer zoom até {valor} em {segundos} segundos',
  'Centralizar no ator': 'Centralizar câmera em {ator}',
  'Definir offset da câmera': 'Definir offset da câmera em X {x} e Y {y}',
  'Rotacionar câmera': 'Rotacionar câmera {graus} graus',
  'Definir suavidade do follow': 'Definir suavidade do acompanhamento para {valor}',
  'Definir deadzone do follow': 'Definir área morta com largura {largura} e altura {altura}',
  'Travar eixo da câmera': 'Travar eixo da câmera {eixo}',
  'Empurrar câmera': 'Mover câmera em X {x} e Y {y}',
  'Zoom no toque': 'Aplicar zoom de {valor} no toque',
  'Look-ahead da câmera': 'Antecipação da câmera {distância}',

  // UI / tilemap
  'Definir posição da UI': 'Definir posição da interface em X: {x} e Y: {y}',
  'Mostrar elemento UI': 'Mostrar elemento da interface {id}',
  'Esconder elemento UI': 'Esconder elemento da interface {id}',
  'Quando botão pressionado': 'Quando o botão {id} for pressionado',
  'Definir posição do HUD': 'Definir posição do HUD em X {x} e Y {y}',
  'Atualizar ponto no minimapa': 'Atualizar ponto {id} no minimapa em X {x} e Y {y}',
  'Marcar no radar': 'Marcar {id} no radar em X {x} e Y {y}',
  'Criar killfeed': 'Criar feed de eliminações',
  'Adicionar entrada ao killfeed': 'Adicionar entrada ao feed de eliminações: {texto}',
  'Criar crosshair': 'Criar mira',
  'Definir tamanho da UI': 'Definir tamanho da interface {id} para {largura} por {altura}',
  'Animar UI': 'Animar elemento da interface {id}',
  'Definir tile': 'Definir tile em X {x} Y {y} para {id}',
  'Ler tile em': 'Ler tile em X {x} Y {y}',
};

const BLOCK_HELP = {
  'Quando a cena começar': 'Executa os blocos abaixo assim que a cena inicia.',
  'Quando tocado': 'Executa quando o usuário toca neste objeto.',
  'Mover X passos': 'Move o objeto na direção atual.',
  'Girar direita X graus': 'Gira no sentido horário.',
  'Esperar X segundos': 'Pausa o script pelo tempo informado.',
  'Sempre': 'Repete os blocos internos continuamente, uma vez por quadro. Use Esperar um frame se quiser um ciclo controlado.',
  'Ler direção do joystick': 'Lê a direção atual do joystick. Quando usada com Definir X/Y para dentro de Sempre, ela acompanha o eixo correspondente do joystick.',
  'Ler eixo X do joystick': 'Lê o eixo horizontal do joystick de -1 (esquerda) a 1 (direita).',
  'Ler eixo Y do joystick': 'Lê o eixo vertical do joystick de -1 (baixo) a 1 (cima).',
  'Repita X vezes': 'Repete os blocos internos X vezes.',
  'Criar D-Pad': 'Cria um D-pad e atualiza as quatro variáveis escolhidas entre 0 e 1 conforme cada direção é pressionada.',
  'Criar D-pad': 'Cria o controle D-pad básico e dispara o evento Quando botão pressionado ao tocar uma direção.',
  'Trocar skin do D-pad': 'Troca a aparência do D-Pad para escuro claro ou vidro.',
  'Definir sprites do D-Pad': 'Define o fundo e as quatro imagens do D-Pad. Campos vazios mantêm a aparência atual.',
  'Definir sprite da seta do D-pad': 'Troca somente a imagem de uma seta do D-Pad.',
  'Definir opacidade do D-pad': 'Define a opacidade do D-Pad entre 0 e 1.',
  'Definir cor do D-pad': 'Define a cor das setas do D-Pad.',
  'Restaurar sprite padrão do D-pad': 'Volta o D-Pad ao visual padrão.',
  'Fim de loop': 'Marca claramente o fim deste bloco de repetição. Tudo abaixo dele fica fora do loop e pode continuar normalmente.',
  'Se ... então': 'Executa se a condição for verdadeira.',
  'Tocar som': 'Toca o som selecionado.',
  'Mostrar': 'Torna o objeto visível.',
  'Esconder': 'Torna o objeto invisível.',
  'Definir variável para': 'Define o valor de uma variável.',
  'Mudar variável em': 'Altera o valor da variável pelo valor informado.',
  'Criar clone de': 'Cria uma cópia deste objeto.',
  'Ir para X: Y:': 'Teleporta o objeto para a posição.',
  'Abaixar caneta': 'Começa a desenhar ao se mover.',
  'Aplicar Blur': 'Aplica desfoque no objeto ou tela.',
  'Shader Custom (GLSL)': 'Aplica um shader escrito em código.',
};

function buildCompleteBlockHelp() {
  const describe = (name, params) => {
    const n = String(name || 'bloco');
    const low = n.toLowerCase();
    let action = n;
    if (low.startsWith('quando ')) action = n + ' quando o evento indicado acontecer';
    else if (low.startsWith('definir ')) action = n + ' para configurar exatamente o valor informado';
    else if (low.startsWith('mudar ')) action = n + ' para alterar o valor atual pelo valor informado';
    else if (low.startsWith('criar ')) action = n + ' para criar o recurso indicado';
    else if (low.startsWith('aplicar ')) action = n + ' para aplicar o efeito imediatamente';
    else if (low.startsWith('remover ') || low.startsWith('limpar ')) action = n + ' para remover o efeito ou recurso indicado';
    else action = n + ' para executar a ação indicada';
    const ps = Array.isArray(params) && params.length ? ' Preencha os campos mostrados no bloco; eles controlam diretamente como a ação será executada.' : '';
    return action + '.' + ps;
  };
  Object.values(CATEGORIES).forEach(cat => (cat.blocks || []).forEach(b => {
    if (!BLOCK_HELP[b.n]) BLOCK_HELP[b.n] = describe(b.n, b.p);
  }));
}

// Cores exatas do documento original
const CATEGORIES = {
  evento: { name: "Evento", color: "#CF5717", body: "#E8895A", blocks: [
    { n: "Quando a cena começar" },
    { n: "Quando tocado" },
    { n: "Quando a tela for pressionada" },
    { n: "Quando o sprite for solto" },
    { n: "Quando o dedo mover sobre o sprite" },
    { n: "Quando o dedo mover na tela" },
    { n: "Quando receber mensagem", p: ["mensagem"] },
    { n: "Enviar mensagem", p: ["mensagem"] },
    { n: "Enviar mensagem e esperar", p: ["mensagem"] },
    { n: "Quando inclinar dispositivo", p: ["direção"] },
    { n: "Quando bater no dispositivo" },
    { n: "Quando colidir com", p: ["objeto"] },
    { n: "Quando variável mudar", p: ["variável"] },
    { n: "Quando cronômetro >", p: ["segundos"] },
    { n: "Quando entrar na região", p: ["x", "y", "largura", "altura"] },
    { n: "Quando sair da região", p: ["x", "y", "largura", "altura"] },
    { n: "Quando FPS <", p: ["fps"] }
  ] },
  controle: { name: "Controle", color: "#F99761", body: "#F7C79A", blocks: [
    { n: "Esperar X segundos", p: ["segundos"] },
    { n: "Sempre" },
    { n: "Repita X vezes", p: ["vezes"] },
    { n: "Repita até", p: ["condição"] },
    { n: "Repita enquanto", p: ["condição"] },
    { n: "Se ... então", p: ["condição"] },
    { n: "Se ... então ... senão", p: ["condição"] },
    { n: "Se [Fórmula] for verdadeira então...", p: ["condição"] },
    { n: "Esperar até", p: ["condição"] },
    { n: "Parar este script" },
    { n: "Parar todos os scripts" },
    { n: "Parar outros scripts deste objeto" },
    { n: "Sair do loop" },
    { n: "Continuar próxima iteração" },
    { n: "Se tocado X vezes seguidamente", p: ["vezes"] },
    { n: "Iniciar thread", p: ["nome"] },
    { n: "Aguardar thread", p: ["nome"] },
    { n: "Parar thread", p: ["nome"] },
    { n: "Criar clone" },
    { n: "Quando começar como clone" },
    { n: "Apagar este clone" },
    { n: "Nota", p: ["texto"] },
    { n: "Debounce por X ms", p: ["ms"] },
    { n: "Throttle a cada X ms", p: ["ms"] },
    { n: "Tentar ... se erro", p: ["mensagem"] },
    { n: "Executar após frames", p: ["quadros"] },
    { n: "Com chance % faça", p: ["porcentagem"] },
    { n: "Esperar um frame" },
    { n: "Repetir para sempre com delay", p: ["segundos"] },
    { n: "Se variável = faça", p: ["variável", "valor"] },
    { n: "Sair de todos os loops" },
    { n: "Executar uma vez" },
    { n: "Se está tocando", p: ["objeto"] },
    { n: "Mudar para cena", p: ["cena"] },
    { n: "Próxima cena" },
    { n: "Cena anterior" },
    { n: "Reiniciar cena atual" },
    { n: "Transição fade para cena", p: ["cena", "segundos", "cor", "estilo"] },
    { n: "Transição fade para [cena] em [segundos]", p: ["cena", "segundos", "cor", "estilo"] }
  ] },
  movimento: { name: "Movimento", color: "#408AC5", body: "#7FB3E8", blocks: [
    { n: "Mover X passos", p: ["passos"] },
    { n: "Girar direita X graus", p: ["graus"] },
    { n: "Girar esquerda X graus", p: ["graus"] },
    { n: "Ir para X e Y", p: ["x", "y"] },
    { n: "Ir para posição aleatória" },
    { n: "Ir para outro objeto", p: ["objeto"] },
    { n: "Deslizar em X segundos até X: Y:", p: ["segundos", "x", "y"] },
    { n: "Apontar em direção a", p: ["objeto"] },
    { n: "Apontar para direção X", p: ["direção"] },
    { n: "Mudar X em", p: ["valor"] },
    { n: "Definir X para", p: ["valor"] },
    { n: "Mudar Y em", p: ["valor"] },
    { n: "Definir Y para", p: ["valor"] },
    { n: "Se estiver na borda, volte" },
    { n: "Definir estilo de rotação", p: ["estilo"] },
    { n: "Mover em direção ao toque" },
    { n: "Mudar direção em", p: ["graus"] },
    { n: "Definir direção para", p: ["graus"] },
    { n: "Mover na direção", p: ["graus", "passos"] },
    { n: "Seguir objeto", p: ["objeto", "passos"] },
    { n: "Afastar de objeto", p: ["objeto", "passos"] },
    { n: "Ir para o toque" },
    { n: "Limitar à tela" },
    { n: "Definir velocidade X", p: ["valor"] },
    { n: "Definir velocidade Y", p: ["valor"] },
    { n: "Parar movimento" },
    { n: "Mover em círculo", p: ["raio", "graus"] },
    { n: "Empurrar com força", p: ["força", "direção"] },
    { n: "Seguir joystick", p: [{name:"id",type:"text",default:"'joystick1'"}, {name:"apontar",type:"bool",default:"'sim'"}, {name:"velocidade",type:"number",default:"6"}] },
{ n: "Definir gravidade personalizada", p: ["x", "y"] },
    { n: "Ativar Colisão Trigger" },
    { n: "Camadas de Colisão", p: ["camada"] },
    { n: "Raycast", p: ["x", "y", "ângulo"] },
    { n: "Criar Joint/Mola" },
    { n: "Configurar física de veículo" },
    { n: "Aplicar Impulso", p: ["x", "y"] },
    { n: "Definir Massa/Atrito", p: ["massa", "atrito"] },
    { n: "Sensor de Colisão Contínua" },
    { n: "Verificar colisão com", p: ["objeto","variável"] },
    { n: "Parar ao colidir com", p: ["objeto"] },
    { n: "Desfazer movimento se colidir" },
    { n: "Empurrar ao colidir", p: ["força"] },
    { n: "Mover até colidir", p: ["objeto","passos"] },
    { n: "Definir resposta de colisão", p: ["modo"] },
    { n: "Definir camada de colisão", p: ["camada"] },
    { n: "Definir máscara de colisão", p: ["máscara"] },
    { n: "Definir tamanho da colisão", p: ["largura","altura"] },
    { n: "Definir deslocamento da colisão", p: ["x","y"] },
    { n: "Pausar Física do Objeto" },
    { n: "Simular explosão", p: ["força"] },
    { n: "Detectar Contato" },
    { n: "Definir restituição", p: ["valor"] },
    { n: "Otimizar Mundo Físico" },
    { n: "Path de Física" }
] },
  aparencias: { name: "Aparências", color: "#6B9C49", body: "#93C67A", blocks: [
    { n: "Mudar para fantasia/costume", p: ["costume"] },
    { n: "Definir GIF como aparência", p: ["imagem"] },
    { n: "Tocar GIF", p: ["imagem"] },
    { n: "Parar GIF" },
    { n: "Reiniciar GIF" },
    { n: "Próxima fantasia" },
    { n: "Mudar tamanho em", p: ["valor"] },
    { n: "Definir tamanho para", p: ["valor"] },
    { n: "Mostrar" },
    { n: "Esconder" },
    { n: "Mudar efeito gráfico em", p: ["efeito", "valor"] },
    { n: "Definir efeito para", p: ["efeito", "valor"] },
    { n: "Limpar efeitos gráficos" },
    { n: "Ir para camada", p: ["camada"] },
    { n: "Mudar camada em", p: ["valor"] },
    { n: "Mudar transparência em", p: ["valor"] },
    { n: "Definir transparência para", p: ["valor"] },
    { n: "Definir aparência para número", p: ["número"] },
    { n: "Definir aparência para nome", p: ["nome"] },
    { n: "Espelhar horizontal" },
    { n: "Espelhar vertical" },
    { n: "Trocar cor", p: [{name:"de",type:"color",default:"'#FFFFFF'"},{name:"para",type:"color",default:"'#000000'"}] },
    { n: "Definir tolerância de cor", p: ["valor"] },
    { n: "Dizer", p: ["texto", "segundos"] },
    { n: "Fade in", p: ["segundos"] },
    { n: "Fade out", p: ["segundos"] },
    { n: "Piscar X vezes", p: ["vezes"] },
    { n: "Definir brilho", p: ["valor"] },
    { n: "Outline", p: [{name:"cor",type:"color",default:"'#FFFFFF'"},"espessura"] },
    { n: "Criar emissor de partículas" },
    { n: "Definir taxa de emissão", p: ["valor"] },
    { n: "Quando partícula nascer" },
    { n: "Definir cor da partícula", p: [{name:"cor",type:"color",default:"'#FFFFFF'"}] },
    { n: "Emitir partículas", p: ["quantidade"] },
    { n: "Parar partículas" },
    { n: "Definir quantidade de partículas", p: ["quantidade"] },
    { n: "Definir velocidade das partículas", p: ["velocidade"] },
    { n: "Definir tamanho das partículas", p: ["tamanho"] },
    { n: "Definir duração das partículas", p: ["segundos"] },
    { n: "Mostrar partículas" },
    { n: "Esconder partículas" },
    { n: "Reproduzir animação da pasta", p: [{"name": "pasta", "type": "folder"}] },
    { n: "Repetir animação da pasta", p: [{"name": "pasta", "type": "folder"}] },
    { n: "Repetir animação da pasta em loop", p: [{"name": "pasta", "type": "folder"}] },
    { n: "Parar animação da pasta", p: [{"name": "pasta", "type": "folder"}] },
    { n: "Aplicar animação em loop na pasta", p: [{"name": "pasta", "type": "folder"}] },
    { n: "Tocar pasta uma vez e parar na última aparência", p: [{"name": "pasta", "type": "folder"}] },
    { n: "Tocar pasta uma vez e voltar pra aparência original", p: [{"name": "pasta", "type": "folder"}] },
    { n: "Definir pasta como aparência atual", p: [{"name": "pasta", "type": "folder"}] },
    { n: "Inverter ordem da pasta ao tocar", p: [{"name": "pasta", "type": "folder"}] },
    { n: "Tocar pasta em loop na velocidade", p: [{"name": "pasta", "type": "folder"}, {"name": "fps", "type": "number", "default": "12"}] },
    { n: "Tocar pasta uma vez na velocidade", p: [{"name": "pasta", "type": "folder"}, {"name": "fps", "type": "number", "default": "12"}] },
    { n: "Parar animação" },
    { n: "Próximo quadro da animação" },
    { n: "Definir quadro da animação para", p: ["número"] },
    { n: "Esperar animação terminar" },
    { n: "Definir velocidade da animação para", p: ["valor"] },
    { n: "Mudar aparência para", p: ["nome"] },
    { n: "Definir cor", p: [{name:"de",type:"color",default:"'#FFFFFF'"},{name:"para",type:"color",default:"'#000000'"},{name:"tolerância",type:"number",default:"0"}] },
    { n: "Restaurar cor original" },
    { n: "Mudar aparência", p: ["valor"] },
    { n: "Próxima aparência" },
    { n: "Aparência anterior" },
    { n: "Trazer para frente" },
    { n: "Enviar para trás" },
    { n: "Definir opacidade", p: ["valor"] },
    { n: "Mudar opacidade em", p: ["valor"] },
    { n: "Aparecer gradualmente", p: ["segundos"] },
    { n: "Desaparecer gradualmente", p: ["segundos"] },
    { n: "Definir efeito", p: ["efeito", "valor"] },
    { n: "Mudar efeito em", p: ["efeito", "valor"] },
    { n: "Limpar efeitos" },
    { n: "Espelhar", p: ["eixo"] },
    { n: "Piscar", p: ["vezes", "segundos"] },
    { n: "Emissor de partículas", p: [{name:"ligado",type:"bool",default:"'sim'"}, "taxa", {name:"cor",type:"color",default:"'#FFFFFF'"}] },
    { n: "Tocar pasta", p: [{name:"pasta",type:"folder"},{name:"modo",type:"choice",options:["uma vez","loop"],default:"'loop'"},{name:"fps",type:"number",default:"12"},{name:"ao terminar",type:"choice",options:["parar","voltar ao original"],default:"'parar'"}] },
    { n: "Próximo quadro" },
    { n: "Definir quadro", p: ["número"] },
    { n: "Definir velocidade da animação", p: ["valor"] },
    { n: "Inverter ordem da pasta", p: [{name:"pasta",type:"folder"}] },
    { n: "Tintar sprite", p: [{name:"cor",type:"color",default:"'#FFFFFF'"},"intensidade"] },
    { n: "Flash de hit", p: [{name:"cor",type:"color",default:"'#FFFFFF'"},"frames"] },
    { n: "Sombra", p: [{name:"cor",type:"color",default:"'#000000'"},"offsetX","offsetY","blur"] },
    { n: "Rastro de movimento", p: [{name:"ligado",type:"bool",default:"'sim'"}, "opacidade"] },
    { n: "Modo de mistura", p: ["modo"] }
  ] },
  dados: { name: "Dados", color: "#E15B5B", body: "#F5A3A3", blocks: [
    { n: "Definir variável para", p: [{"name": "variável", "type": "text", "default": "'pontos'"}, "valor"] },
    { n: "Mudar variável em", p: [{"name": "variável", "type": "text", "default": "'pontos'"}, "valor"] },
    { n: "Definir variável local para", p: [{"name": "variável", "type": "text", "default": "'local'"}, "valor"] },
    { n: "Mudar variável local em", p: [{"name": "variável", "type": "text", "default": "'local'"}, "valor"] },
    { n: "Definir variável global para", p: [{"name": "variável", "type": "text", "default": "'global'"}, "valor"] },
    { n: "Mudar variável global em", p: [{"name": "variável", "type": "text", "default": "'global'"}, "valor"] },
    { n: "Mostrar variável", p: [{"name": "variável", "type": "text", "default": "'pontos'"}] },
    { n: "Esconder variável", p: [{"name": "variável", "type": "text", "default": "'pontos'"}] },
    { n: "Criar lista", p: [{"name": "lista", "type": "text", "default": "'lista'"}] },
    { n: "Adicionar à lista", p: [{"name": "item", "type": "text", "default": "'item'"}, {"name": "lista", "type": "text", "default": "'lista'"}] },
    { n: "Apagar de lista", p: ["índice", {"name": "lista", "type": "text", "default": "'lista'"}] },
    { n: "Apagar tudo da lista", p: [{"name": "lista", "type": "text", "default": "'lista'"}] },
    { n: "Inserir em lista", p: ["índice", {"name": "item", "type": "text", "default": "'item'"}, {"name": "lista", "type": "text", "default": "'lista'"}] },
    { n: "Substituir item da lista", p: ["índice", {"name": "item", "type": "text", "default": "'item'"}, {"name": "lista", "type": "text", "default": "'lista'"}] },
    { n: "Item da lista", p: ["índice", {"name": "lista", "type": "text", "default": "'lista'"}] },
    { n: "Tamanho da lista", p: [{"name": "lista", "type": "text", "default": "'lista'"}] },
    { n: "Lista contém", p: [{"name": "item", "type": "text", "default": "'item'"}, {"name": "lista", "type": "text", "default": "'lista'"}] },
    { n: "Mostrar lista", p: [{"name": "lista", "type": "text", "default": "'lista'"}] },
    { n: "Esconder lista", p: [{"name": "lista", "type": "text", "default": "'lista'"}] }
  ] },
  telefone: { name: "Telefone", color: "#0F766E", body: "#5EEAD4", blocks: [
    { n: "Forçar orientação da tela", p: ["orientação"] },
    { n: "Vibrar curto" },
    { n: "Vibrar longo" },
    { n: "Vibrar", p: ["ms"] },
    { n: "Padrão de vibração customizado", p: ["padrão"] },
    { n: "Parar vibração" },
    { n: "Feedback tátil por evento" },
    { n: "Quando vibração terminar" },
    { n: "Compartilhar print da tela" },
    { n: "Compartilhar pontuação", p: ["valor"] },
    { n: "Compartilhar vídeo curto" },
    { n: "Convidar amigo com link/código" },
    { n: "Quando compartilhar ok" },
    { n: "Definir idioma do jogo", p: ["idioma"] },
    { n: "Texto traduzido por chave", p: ["chave"] },
    { n: "Detectar idioma do dispositivo" },
    { n: "Trocar idioma em tempo real" },
    { n: "Quando idioma mudar" },
    { n: "Detectar pinça (pinch)" },
    { n: "Arrastar com dois dedos" },
    { n: "Swipe (direção)" },
    { n: "Toque duplo" },
    { n: "Pressionar e segurar" },
    { n: "Rotação por gesto" },
    { n: "Quando swipe" },
    { n: "Quando pinça" },
    { n: "Detectar toque duplo" }
  ,
{ n: "Vibrar por X segundos", p: ["segundos"] },
    { n: "Definir brilho da tela", p: ["valor"] },
    { n: "Tirar foto" },
    { n: "Ler valor do acelerômetro" },
    { n: "Ler valor do giroscópio" },
    { n: "Ler valor da bússola" },
    { n: "Ler GPS" },
    { n: "Ler sensor de luz" },
    { n: "Ler sensor de proximidade" },
    { n: "Enviar notificação", p: ["texto"] },
    { n: "Abrir outro aplicativo", p: ["app"] },
    { n: "Ler QR code" },
    { n: "Ler nível de bateria" },
    { n: "Manter tela ligada" },
    { n: "Mostrar toast", p: ["texto"] },
    { n: "Copiar texto", p: ["texto"] },
    { n: "Pedir permissão de sensores" },
    { n: "Detectar se está online" },
    { n: "Obter data/hora", p: ["formato"] },
    { n: "Gerar número aleatório", p: ["min", "max", "variável"] },
    { n: "Pedir texto ao usuário", p: ["pergunta", "variável"] },] },
  desenhos: { name: "Desenhos", color: "#991B1B", body: "#FCA5A5", blocks: [
    { n: "Desenhar linha", p: ["x1", "y1", "x2", "y2"] },
    { n: "Desenhar círculo", p: ["x", "y", "raio"] },
    { n: "Desenhar retângulo", p: ["x", "y", "largura", "altura"] },
    { n: "Desenhar polígono", p: ["pontos"] },
    { n: "Preencher forma com cor", p: ["cor"] },
    { n: "Definir espessura do traço", p: ["valor"] },
    { n: "Limpar desenho" },
    { n: "Desenhar texto vetorial", p: ["texto"] },
    { n: "Abaixar caneta" },
    { n: "Levantar caneta" },
    { n: "Definir cor da caneta", p: [{name:"cor",type:"color",default:"'#FFFFFF'"}] },
    { n: "Definir tamanho da caneta", p: ["tamanho"] },
    { n: "Carimbar (stamp)" },
    { n: "Limpar tudo" },
    { n: "Definir opacidade da caneta", p: ["valor"] }
  ] },
  ia: { name: "IA", color: "#4338CA", body: "#A5B4FC", blocks: [
    { n: "Perguntar à IA", p: ["prompt"] },
    { n: "Quando IA responder" },
    { n: "Definir modelo de IA", p: ["modelo"] },
    { n: "Definir chave de API", p: ["chave"] },
    { n: "Cancelar pedido de IA" },
    { n: "Criar NPC", p: ["id"] },
    { n: "Definir comportamento do NPC", p: ["id", "comportamento"] },
    { n: "Definir estado do NPC", p: ["id", "estado"] },
    { n: "Definir objetivo do NPC", p: ["id", "objetivo"] },
    { n: "Definir alvo do NPC", p: ["id", "alvo"] },
    { n: "NPC perseguir alvo", p: ["id", "alvo", "velocidade"] },
    { n: "NPC fugir do alvo", p: ["id", "alvo", "velocidade"] },
    { n: "NPC patrulhar rota", p: ["id", "rota", "velocidade"] },
    { n: "NPC seguir caminho", p: ["id", "destino", "velocidade"] },
    { n: "Definir visão do NPC", p: ["id", "distância", "ângulo"] },
    { n: "Definir alcance de ataque do NPC", p: ["id", "distância"] },
    { n: "Definir alcance de detecção do NPC", p: ["id", "distância"] },
    { n: "Definir memória do NPC", p: ["id", "tempo"] },
    { n: "NPC lembrar alvo", p: ["id", "alvo"] },
    { n: "NPC esquecer alvo", p: ["id", "alvo"] },
    { n: "Definir personalidade do NPC", p: ["id", "personalidade"] },
    { n: "Definir agressividade do NPC", p: ["id", "valor"] },
    { n: "Definir inteligência do NPC", p: ["id", "valor"] },
    { n: "Definir dificuldade do NPC", p: ["id", "nível"] },
    { n: "Definir reação do NPC", p: ["id", "evento", "ação"] },
    { n: "Quando NPC detectar objeto", p: ["id"] },
    { n: "Quando NPC perder o alvo", p: ["id"] },
    { n: "Quando NPC chegar ao destino", p: ["id"] },
    { n: "Quando NPC sofrer dano", p: ["id"] },
    { n: "Quando NPC atacar", p: ["id"] },
    { n: "NPC tomar decisão", p: ["id"] },
    { n: "NPC escolher alvo mais próximo", p: ["id"] },
    { n: "NPC escolher caminho", p: ["id", "destino"] },
    { n: "NPC parar", p: ["id"] },
    { n: "NPC atacar alvo", p: ["id", "alvo"] },
    { n: "NPC defender", p: ["id"] },
    { n: "NPC esquivar", p: ["id"] },
    { n: "NPC chamar aliados", p: ["id", "distância"] },
    { n: "NPC evitar obstáculo", p: ["id", "distância"] },
    { n: "NPC conversar", p: ["id", "texto"] },
    { n: "NPC emitir som", p: ["id", "som"] },
    { n: "NPC usar habilidade", p: ["id", "habilidade"] },
    { n: "NPC usar item", p: ["id", "item"] },
    { n: "NPC trocar estado automaticamente", p: ["id"] },
    { n: "NPC copiar configuração", p: ["id", "origem"] },
    { n: "NPC definir variável", p: ["id", "nome", "valor"] }
  ] },
  shaders: { name: "Shaders", color: "#0891B2", body: "#67E8F9", blocks: [
    { n: "Aplicar shader ao ator" },
    { n: "Remover shader" },
    { n: "Shader personalizado (GLSL)", p: ["código"] },
    { n: "Definir uniform do shader", p: ["nome", "valor"] },
    { n: "Definir tempo do shader", p: ["valor"] },
    { n: "Aplicar blur", p: ["raio"] },
    { n: "Aplicar contorno", p: [{name:"cor",type:"color",default:"'#FFFFFF'"}] },
    { n: "Aplicar distorção de onda", p: ["amplitude"] },
    { n: "Aplicar pixelização", p: ["tamanho"] },
    { n: "Aplicar escala de cinza" },
    { n: "Aplicar sépia" },
    { n: "Definir intensidade do efeito", p: ["valor"] },
    { n: "Combinar shaders" },
    { n: "Aplicar shader na cena inteira" },
    { n: "Pré-visualizar shader" },
    { n: "Quando shader aplicar" },
    { n: "Definir uniform texto", p: ["nome", "valor"] },
    { n: "Carregar shader de arquivo", p: ["caminho"] },
    { n: "Misturar dois shaders", p: ["a", "b"] },
    { n: "Definir resolução do shader", p: ["largura", "altura"] },
    { n: "Pausar shader" },
    { n: "Retomar shader" },
    { n: "Exportar preview do shader", p: ["nome"] }
  ] },
  fastui: { name: "UI", color: "#BE185D", body: "#F9A8D4", blocks: [
    { n: "Criar botão", p: ["texto"] },
    { n: "Criar slider" },
    { n: "Criar texto na UI", p: ["texto"] },
    { n: "Definir posição da UI", p: ["x", "y"] },
    { n: "Mostrar elemento UI", p: ["id"] },
    { n: "Esconder elemento UI", p: ["id"] },
    { n: "Quando botão pressionado", p: ["id"] },
    { n: "Renderizar sprite otimizado" },
    { n: "Ativar modo de desenho em lote" },
    { n: "Definir qualidade de renderização", p: ["qualidade"] },
    { n: "Pré-carregar textura" },
    { n: "Liberar textura da memória" },
    { n: "Definir taxa de quadros alvo (FPS)", p: ["fps"] },
    { n: "Criar barra de vida flutuante", p: ["id", "max"] },
    { n: "Atualizar barra de vida", p: ["id", "valor"] },
    { n: "Criar killfeed" },
    { n: "Adicionar entrada ao killfeed", p: ["texto"] },
    { n: "Criar timer de partida", p: ["segundos"] },
    { n: "Criar placar por time", p: ["timeA", "timeB"] },
    { n: "Atualizar placar", p: ["time", "pontos"] },
    { n: "Indicador de dano recebido", p: ["valor"] },
    { n: "Mostrar HUD" },
    { n: "Esconder HUD" },
    { n: "Definir posição do HUD", p: ["x", "y"] },
    { n: "Criar barra de progresso", p: ["id", "max"] },
    { n: "Atualizar barra de progresso", p: ["id", "valor"] },
    { n: "Criar minimapa" },
    { n: "Atualizar ponto no minimapa", p: ["id", "x", "y"] },
    { n: "Criar diálogo", p: ["id", "texto"] },
    { n: "Fechar diálogo", p: ["id"] },
    { n: "Criar menu de pausa" },
    { n: "Mostrar menu de pausa" },
    { n: "Esconder menu de pausa" },
    { n: "Criar contador", p: ["id", "valor"] },
    { n: "Atualizar contador", p: ["id", "valor"] },
    { n: "Criar ícone de status", p: ["id", "ícone"] },
    { n: "Criar cooldown radial", p: ["id", "segundos"] },
    { n: "Criar crosshair" },
    { n: "Mostrar tooltip", p: ["texto"] },
    { n: "Criar notificação toast UI", p: ["texto"] },
    { n: "Definir estilo do HUD", p: ["tema"] },
    { n: "Quando slider mudar", p: ["id"] },
    { n: "Obter valor do slider", p: ["id", "variável"] },
    { n: "Definir tamanho da UI", p: ["id", "largura", "altura"] },
    { n: "Animar UI", p: ["id", "tipo"] },
    { n: "Criar lista de inventário", p: ["slots"] },
    { n: "Definir item do inventário", p: ["slot", "nome"] },
    { n: "Criar barra de XP", p: ["id", "max"] },
    { n: "Atualizar barra de XP", p: ["id", "valor"] },
    { n: "Criar radar", p: ["alcance"] },
    { n: "Marcar no radar", p: ["id", "x", "y"] },
    { n: "HUD de combate completo" },
    { n: "placar 2 times", p: ["nomeA", "nomeB"] },
    { n: "timer countdown", p: ["segundos"] },
    { n: "barra de vida no jogador", p: ["max"] },
    { n: "limpar toda a UI" }
  
  ] },
  texto: { name: "Texto", color: "#0369A1", body: "#7DD3FC", blocks: [
    { n: "Escrever texto em tempo real", p: [
      {name:"variável",type:"text",default:"'texto_digitado'"},
      {name:"x",type:"number",default:"0"},
      {name:"y",type:"number",default:"0"},
      {name:"tamanho",type:"number",default:"32"},
      {name:"cor",type:"color",default:"'#FFFFFF'"},
      {name:"fonte",type:"file"},
      {name:"graus",type:"number",default:"0"}
    ] },
    { n: "Perguntar ao usuário", p: [
      {name:"pergunta",type:"text",default:"'Digite sua resposta'"},
      {name:"variável",type:"text",default:"'resposta'"}
    ] },
{ n: "Esconder texto" },

    { n: "Mostrar texto", p: [{"name": "texto", "type": "text", "default": "'Ola!'"}] },
    { n: "Criar texto facilitado", p: [{"name": "id", "type": "text", "default": "'texto1'"}, {"name": "texto", "type": "text", "default": "'Ola!'"}, {"name": "tamanho", "type": "number", "default": "50"}, {"name": "cor", "type": "color", "default": "'#FFFFFF'"}, {"name": "sombra", "type": "bool", "default": "'sim'"}, {"name": "x", "type": "number", "default": "0"}, {"name": "y", "type": "number", "default": "0"}, {"name": "fonte", "type": "file"}] },
    { n: "Definir texto multilinha", p: [{"name": "texto", "type": "text", "default": "'Linha 1'"}] },
    { n: "Definir fonte", p: [{"name": "fonte", "type": "file"}] },
    { n: "Definir tamanho da fonte", p: [{"name":"tamanho","type":"number","default":"50"}] },
    { n: "Definir cor do texto", p: [{"name": "cor", "type": "color", "default": "'#FFFFFF'"}] },
    { n: "Definir negrito e itálico", p: [{"name": "negrito", "type": "bool", "default": "'nao'"}, {"name": "italico", "type": "bool", "default": "'nao'"}] },
    { n: "Definir alinhamento", p: [{"name": "alinhamento", "type": "text", "default": "'centro'"}] },
    { n: "Definir espaçamento entre linhas", p: ["espacamento"] },
    { n: "Definir contorno (stroke)", p: [{"name": "cor", "type": "color", "default": "'#000000'"}, "espessura"] },
    { n: "Definir sombra do texto", p: [{"name": "cor", "type": "color", "default": "'#000000'"}, {"name": "deslocamento x", "type": "number", "default": "2"}, {"name": "deslocamento y", "type": "number", "default": "2"}, {"name": "desfoque", "type": "number", "default": "4"}] },
    { n: "Definir glow do texto", p: [{"name": "cor", "type": "color", "default": "'#FFFFFF'"}, "intensidade"] },
    { n: "Definir gradiente do texto", p: [{"name": "cor inicio", "type": "text", "default": "'#FF0000'"}, {"name": "cor fim", "type": "text", "default": "'#0000FF'"}, "angulo"] },
    { n: "Efeito de digitação", p: [{"name": "texto", "type": "text", "default": "'Ola!'"}, "velocidade"] },
    { n: "Quebra de linha automática", p: ["largura maxima"] },
    { n: "Rotacionar texto", p: ["graus"] },
    { n: "Definir opacidade do texto", p: ["opacidade"] },
    { n: "Interpolar texto (fade in/out)", p: ["de", "para", "duracao"] },
    { n: "Definir texto rico (tags)", p: [{"name": "texto", "type": "text", "default": "'texto'"}] },
    { n: "Medir largura do texto" },
    { n: "Mostrar dado como texto", p: [{"name": "variavel", "type": "text", "default": "'pontos'"}, {"name": "prefixo", "type": "text", "default": "'Pontos: '"}] },
    { n: "Pulsar texto", p: [{"name": "escala minima", "type": "number", "default": "0.9"}, {"name": "escala maxima", "type": "number", "default": "1.1"}, "velocidade"] },
    { n: "Definir posicao X do texto", p: ["x"] },
    { n: "Definir posicao Y do texto", p: ["y"] },
    { n: "Mudar X do texto em", p: ["valor"] },
    { n: "Mudar Y do texto em", p: ["valor"] },
    { n: "Gradiente animado do texto", p: [{"name": "cor inicio", "type": "text", "default": "'#FF0000'"}, {"name": "cor fim", "type": "text", "default": "'#0000FF'"}, {"name": "direcao", "type": "text", "default": "'direita'"}, {"name": "velocidade", "type": "number", "default": "1"}] },
    { n: "Parar gradiente animado" },
    { n: "Iniciar animacao de texto", p: [{"name": "tipo", "type": "text", "default": "'shake'"}, {"name": "intensidade", "type": "number", "default": "8"}, {"name": "velocidade", "type": "number", "default": "1"}] },
    { n: "Finalizar animacao de texto" },
    { n: "Animacao de texto em loop", p: [{"name": "tipo", "type": "text", "default": "'pulse'"}, {"name": "intensidade", "type": "number", "default": "8"}, {"name": "velocidade", "type": "number", "default": "1"}] },
    { n: "Definir texto com aspas coloridas", p: [{"name": "texto", "type": "text", "default": "'eu estou com muita \"raiva\"'"}, {"name": "cor base", "type": "text", "default": "'#FFFFFF'"}, {"name": "cor aspas", "type": "text", "default": "'#FF4444'"}] },
    { n: "Texto estilizado rapido", p: [{"name": "texto", "type": "text", "default": "'Kix'"}, {"name": "fonte", "type": "file"}, {"name":"tamanho","type":"number","default":"50"}, {"name": "cor", "type": "color", "default": "'#FFFFFF'"}, {"name": "contorno", "type": "color", "default": "'#000000'"}, {"name": "sombra", "type": "bool", "default": "'sim'"}] },
    { n: "Texto HUD rapido", p: [{"name": "variavel", "type": "text", "default": "'pontos'"}, {"name": "rotulo", "type": "text", "default": "'Vida'"}, {"name": "posicao", "type": "text", "default": "'canto superior esquerdo'"}] },
    { n: "Titulo de nivel pronto", p: [{"name": "texto", "type": "text", "default": "'Fase 1'"}] },
    { n: "Texto de dano flutuante", p: [{"name": "texto", "type": "text", "default": "'-10'"}, {"name": "cor", "type": "color", "default": "'#FF4444'"}, "x", "y"] },
    { n: "Caixa de dialogo com digitacao pronta", p: [{"name": "texto", "type": "text", "default": "'Ola, aventureiro!'"}, "velocidade"] }
  ] },
  presets: { name: "Presets", color: "#F97316", body: "#FB923C", blocks: [
    { family: "Joystick / Controles virtuais", n: "Criar joystick virtual", p: [{name:"id",type:"text",default:"'joystick1'"}, {name:"x",type:"number",default:"0"}, {name:"y",type:"number",default:"0"}, {name:"tamanho",type:"number",default:"110"}] },
    { family: "Joystick / Controles virtuais", n: "Definir posição do joystick", p: ["id", "x", "y"] },
    { family: "Joystick / Controles virtuais", n: "Definir tamanho do joystick", p: ["id", "tamanho"] },
    { family: "Joystick / Controles virtuais", n: "Ler direção do joystick", p: ["id", "variável"] },
    { family: "Joystick / Controles virtuais", n: "Ler eixo X do joystick", p: ["id", "variável"] },
    { family: "Joystick / Controles virtuais", n: "Ler eixo Y do joystick", p: ["id", "variável"] },
    { family: "Joystick / Controles virtuais", n: "Ler força do joystick (analógico)", p: ["id", "variável"] },
    { family: "Joystick / Controles virtuais", n: "Criar botão de ação", p: ["id", "texto"] },
    { family: "Joystick / Controles virtuais", n: "Criar D-pad", p: [{name:"id",type:"text",default:"'dpad1'"}] },
    { family: "Joystick / Controles virtuais", n: "Criar D-Pad", p: [{name:"id",type:"text",default:"'dpad1'"},{name:"cima",type:"text",default:"'dpad_cima'"},{name:"esquerda",type:"text",default:"'dpad_esquerda'"},{name:"direita",type:"text",default:"'dpad_direita'"},{name:"baixo",type:"text",default:"'dpad_baixo'"}] },
    { family: "Joystick / Controles virtuais", n: "Remover controles virtuais", p: ["id"] },
    { family: "Aparência do joystick", n: "Definir sprite da base", p: ["id", "imagem"] },
    { family: "Aparência do joystick", n: "Definir sprite do manípulo", p: ["id", "imagem"] },
    { family: "Aparência do joystick", n: "Definir sprite dos botões", p: ["id", "imagem"] },
    { family: "Aparência do joystick", n: "Trocar skin do joystick", p: ["id", "preset"] },
    { family: "Aparência do joystick", n: "Definir opacidade do joystick", p: ["id", "opacidade"] },
    { family: "Aparência do joystick", n: "Definir cor de tint do joystick", p: ["id", {name:"cor",type:"color",default:"'#FFFFFF'"}] },
    { family: "Aparência do joystick", n: "Restaurar sprite padrão", p: ["id"] },
    { family: "Aparência do D-pad", n: "Trocar skin do D-pad", p: [{name:"id",type:"text",default:"'dpad1'"},{name:"estilo",type:"choice",options:["escuro","claro","vidro"],default:"'escuro'"}] },
    { family: "Aparência do D-pad", n: "Definir sprites do D-Pad", p: ["id", {name:"fundo",type:"image"}, {name:"cima",type:"image"}, {name:"baixo",type:"image"}, {name:"esquerda",type:"image"}, {name:"direita",type:"image"}] },
    { family: "Aparência do D-pad", n: "Definir sprite da seta do D-pad", p: [{name:"direção",type:"choice",options:["cima","baixo","esquerda","direita"],default:"'cima'"}, "id", {name:"imagem",type:"image"}] },
    { family: "Aparência do D-pad", n: "Definir opacidade do D-pad", p: ["id", {name:"opacidade",type:"number",default:"1"}] },
    { family: "Aparência do D-pad", n: "Definir cor do D-pad", p: ["id", {name:"cor",type:"color",default:"'#FFFFFF'"}] },
    { family: "Aparência do D-pad", n: "Restaurar sprite padrão do D-pad", p: ["id"] },
    { family: "Câmera", n: "Criar câmera de seguimento", p: ["id", {name:"ator", type:"object"}] },
    { family: "Câmera", n: "Definir alvo da câmera", p: ["id", {name:"ator", type:"object"}] },
    { family: "Câmera", n: "Definir zoom da câmera", p: ["valor"] },
    { family: "Câmera", n: "Câmera com suavização", p: ["valor"] },
    { family: "Câmera", n: "Câmera com paralaxe", p: ["fator"] },
    { family: "Câmera", n: "câmera no jogador", p: [{name:"ator", type:"object"}] },
    { family: "Câmera", n: "reset completo da câmera" },
    { family: "Câmera", n: "zoom de impacto", p: ["valor", "segundos"] },
    { family: "Câmera", n: "seguir com suavidade", p: [{name:"ator", type:"object"}, "suavidade"] },
    { family: "Câmera", n: "bounds do palco" },
    { family: "Cenas prontas", n: "Preset de checkpoint", p: ["id"] },
    { family: "Cenas prontas", n: "Preset de objetivo da fase", p: ["texto"] },
    { family: "Transições", n: "Transição fade in/out", p: ["modo", "segundos"] },
    { family: "Transições", n: "Transição cortinas (wipe)", p: ["direção", "segundos"] },
    { family: "Transições", n: "Transição deslizar (slide)", p: ["direção", "segundos"] },
    { family: "Transições", n: "Transição zoom", p: ["modo", "segundos"] },
    { family: "Transições", n: "Transição de cena aleatória", p: ["segundos"] },
    { family: "Transições", n: "Definir duração da transição", p: ["segundos"] },
    { family: "Telas prontas", n: "Preset de tela de carregamento", p: ["texto"] },
    { family: "Telas prontas", n: "Preset de menu pausado", p: ["título"] },
    { family: "Telas prontas", n: "Preset de tela de game over", p: ["título"] },
    { family: "Colisão fácil", n: "Objeto sólido", p: ["largura","altura"] },
    { family: "Colisão fácil", n: "Parede", p: ["direção","força"] },
    { family: "Colisão fácil", n: "Plataforma", p: ["altura","atrito"] },
    { family: "Colisão fácil", n: "Coletável", p: ["valor","variável"] },
    { family: "Colisão fácil", n: "Dano por contato", p: ["dano","intervalo"] },
    { family: "Colisão fácil", n: "Empurrão", p: ["força","direção"] },
    { family: "Colisão fácil", n: "Sensor", p: ["variável"] },
    { family: "Colisão fácil", n: "Projétil", p: ["dano","velocidade"] },
    { family: "Colisão fácil", n: "Plataforma móvel", p: ["distância","velocidade"] },
    { family: "Colisão fácil", n: "Zona de teleporte", p: ["cena","x","y"] },
    { family: "Multiplayer", n: "Preset de tela de lobby", p: ["título"] },
    { family: "Multiplayer", n: "Preset de busca de partida", p: ["texto"] },
    { family: "Multiplayer", n: "Preset de lista de jogadores na sala", p: ["id"] },
    { family: "Multiplayer", n: "Indicador de conexão (ping/status)", p: ["id"] },
    { family: "Multiplayer", n: "Preset de botão pronto", p: ["id", "texto"] },
    { family: "Multiplayer", n: "Preset de contagem regressiva de início", p: ["segundos"] },
    { family: "Multiplayer", n: "Preset de tela de resultado da partida", p: ["título"] },
    { family: "Multiplayer", n: "Preset de convite de amigo", p: ["id", "texto"] },
    { family: "Multiplayer", n: "Preset de chat rápido", p: ["id"] },
    { family: "Multiplayer", n: "Preset de indicador de host", p: ["id", "nome"] }
  ] },
  somplus: { name: "Som+", color: "#9B5FD1", body: "#D8B4FE", blocks: [
    { n: "Tocar som", p: [{"name": "som", "type": "sound", "default": "''"}] },
    { n: "Tocar som e esperar terminar", p: [{"name": "som", "type": "sound", "default": "''"}] },
    { n: "Parar todos os sons" },
    { n: "Parar este som" },
    { n: "Pausar som" },
    { n: "Retomar som" },
    { n: "Mudar volume em", p: ["valor"] },
    { n: "Definir volume para", p: ["valor"] },
    { n: "Mudar tom (pitch) em", p: ["valor"] },
    { n: "Definir tom para", p: ["valor"] },
    { n: "Definir loop do som", p: [{"name": "sim", "type": "bool", "default": "'sim'"}] },
    { n: "Falar (texto para voz)", p: [{"name": "texto", "type": "text", "default": "'olá'"}] },
    { n: "Falar e esperar", p: [{"name": "texto", "type": "text", "default": "'olá'"}] },
    { n: "Definir idioma da fala", p: [{"name": "idioma", "type": "text", "default": "'pt-BR'"}] },
    { n: "Crossfade", p: [{"name": "som", "type": "sound", "default": "''"}, "segundos"] },
    { n: "Definir canal", p: [{"name": "canal", "type": "text", "default": "'master'"}] },
    { n: "Quando som terminar" },
    { n: "Pausar todos os sons" },
    { n: "Retomar todos os sons" },
    { n: "Tocar som com volume", p: [{name:"som",type:"sound",default:"''"}, "volume"] },
    { n: "Fade out em", p: ["segundos"] },
    { n: "Fade in em", p: ["segundos"] }
  ] },
  multiplayer: { name: "Multiplayer", color: "#2563EB", body: "#5F8FC7", blocks: [
    // Firebase: 5 blocos de conexão/configuração
    { n: "Configurar Firebase", p: [{name:"configuração",type:"text",default:"{\"apiKey\":\"\",\"projectId\":\"\",\"databaseURL\":\"\"}"}] },
    { n: "Conectar Firebase" },
    { n: "Desconectar Firebase" },
    { n: "Status Firebase" },
    { n: "Definir caminho Firebase", p: [{name:"caminho",type:"text",default:"'salas'"}] },
    // 25 blocos funcionais de rede/multiplayer
    { n: "Entrar anonimamente no Firebase" },
    { n: "Entrar no Firebase com email", p: ["email","senha"] },
    { n: "Sair do Firebase" },
    { n: "Ler UID do jogador" },
    { n: "Ler erro do Firebase" },
    { n: "Salvar dados no Firebase", p: ["dados"] },
    { n: "Ler dados do Firebase", p: ["caminho"] },
    { n: "Atualizar dados no Firebase", p: ["caminho","dados"] },
    { n: "Excluir dados do Firebase", p: ["caminho"] },
    { n: "Adicionar jogador à sala", p: ["sala","nome"] },
    { n: "Remover jogador da sala", p: ["sala"] },
    { n: "Definir dado do jogador", p: ["nome","valor"] },
    { n: "Ler dado do jogador", p: ["jogador","nome"] },
    { n: "Listar jogadores da sala", p: ["sala"] },
    { n: "Criar sala multiplayer", p: ["sala"] },
    { n: "Entrar em sala multiplayer", p: ["sala"] },
    { n: "Sair da sala multiplayer", p: ["sala"] },
    { n: "Definir estado da sala", p: ["estado"] },
    { n: "Ler estado da sala", p: ["sala"] },
    { n: "Enviar evento multiplayer", p: ["evento","dados"] },
    { n: "Ler último evento multiplayer" },
    { n: "Escutar mudanças da sala", p: ["sala"] },
    { n: "Parar de escutar a sala", p: ["sala"] },
    { n: "Enviar WebSocket", p: [{name:"mensagem",type:"text",default:"'hello'"}] },
    { n: "Ler última mensagem WebSocket" },
    { n: "Status WebSocket" },
    { n: "Conectar WebSocket", p: [{name:"url",type:"text",default:"'wss://exemplo.com'"}] },
    { n: "Desconectar WebSocket" },
    { n: "Requisição HTTP GET", p: ["url"] },
    { n: "Requisição HTTP POST", p: ["url","corpo"] },
    { n: "Codificar JSON", p: ["valor"] },
    { n: "Decodificar JSON", p: ["texto"] },
    { n: "Definir timeout de rede", p: ["milissegundos"] },
    { n: "Ping servidor", p: ["url"] },
    { n: "Transmitir evento de rede", p: ["evento","dados"] }
  ] },
  database: { name: "Persistência", color: "#2563EB", body: "#93C5FD", blocks: [
    { n: "Salvar variável no dispositivo", p: ["variável"] },
    { n: "Ler variável do dispositivo", p: ["variável"] },
    { n: "Quando dados forem salvos" },
    { n: "Apagar dados salvos", p: ["chave"] }
  ] },
  animavancada: { name: "Animação", color: "#7C3AED", body: "#C4B5FD", blocks: [
    { n: "Animar propriedade", p: ["prop", "de", "para", "duração"] },
    { n: "Quando animação terminar" },
    { n: "Definir curva de animação", p: ["tipo"] }
  ] },
  seguranca: { name: "Segurança", color: "#BE123C", body: "#FDA4AF", blocks: [
    { n: "Criptografar texto", p: ["texto"] },
    { n: "Quando autenticação ok" },
    { n: "Descriptografar texto", p: ["texto"] },
    { n: "Gerar hash", p: ["texto"] }
  ] },
  debug: { name: "Debug", color: "#9333EA", body: "#D8B4FE", blocks: [
    { n: "Executar JavaScript", p: [{name:"código",type:"code",default:"// Escreva seu código aqui\n"}] },
    { n: "Log de texto", p: ["texto"] },
    { n: "Quando erro ocorrer" },
    { n: "Mostrar FPS" },
    { n: "Assertar condição", p: ["condição"] },
    { n: "Reiniciar cronômetro" },
    { n: "Ler cronômetro" },
    { n: "Quando timer acabar" },
    { n: "Iniciar timer", p: ["segundos"] }
] },
  economia: { name: "Loja", color: "#D97706", body: "#FCD34D", blocks: [
    { n: "Adicionar moedas", p: ["valor"] },
    { n: "Quando compra concluída" },
    { n: "Gastar moedas", p: ["valor"] },
    { n: "Definir preço", p: ["item", "valor"] }
  ] },
  levels: { name: "Levels", color: "#7C2D12", body: "#FDBA74", blocks: [
    { n: "Carregar nível", p: ["nível"] },
    { n: "Quando nível completo" },
    { n: "Próximo nível" },
    { n: "Reiniciar nível" }
  ] },
  cameraplus: { name: "Camera+", color: "#1E3A8A", body: "#3B82F6", blocks: [
    { n: "Seguir ator com câmera", p: [{name:"ator", type:"object"}] },
    { n: "Zoom da câmera", p: ["valor"] },
    { n: "Shake de câmera", p: ["intensidade"] },
    { n: "Quando câmera mover" },
    { n: "Definir limites da câmera" },
    { n: "Câmera livre" },
    { n: "Ativar câmera AR" },
    { n: "Detectar plano AR" },
    { n: "Colocar objeto no AR" },
    { n: "Definir posição da câmera", p: ["x", "y"] },
    { n: "Mudar posição da câmera em", p: ["x", "y"] },
    { n: "Deslizar câmera até", p: ["x", "y", "segundos"] },
    { n: "Zoom suave até", p: ["valor", "segundos"] },
    { n: "Resetar câmera" },
    { n: "Centralizar no ator", p: [{name:"ator", type:"object"}] },
    { n: "Definir offset da câmera", p: ["x", "y"] },
    { n: "Rotacionar câmera", p: ["graus"] },
    { n: "Definir suavidade do follow", p: ["valor"] },
    { n: "Definir deadzone do follow", p: ["largura", "altura"] },
    { n: "Travar eixo da câmera", p: ["eixo"] },
    { n: "Parar shake da câmera" },
    { n: "Empurrar câmera", p: ["x", "y"] },
    { n: "Zoom no toque", p: ["valor"] },
    { n: "Look-ahead da câmera", p: ["distância"] },
    { n: "Quando zoom mudar" },
    { n: "Obter posição X da câmera" },
    { n: "Obter posição Y da câmera" },
    { n: "Obter zoom da câmera" }
  ] },
  layers: { name: "Layers", color: "#64748B", body: "#CBD5E1", blocks: [
    { n: "Mostrar camada", p: ["nome"] },
    { n: "Esconder camada", p: ["nome"] },
    { n: "Quando camada mudar" },
    { n: "Mover para camada", p: ["nome"] }
  ] },
  tilemap: { name: "Tilemap", color: "#047857", body: "#6EE7B7", blocks: [
    { n: "Spritesheet", p: ["imagem", "colunas", "linhas", "fps", "modo"] },
    { n: "Animar spritesheet" },
    { n: "Parar spritesheet" },
    { n: "Definir quadro do spritesheet", p: ["número"] },
    { n: "Spritesheet da pasta", p: [{name:"pasta",type:"folder"}, "fps"] },
    { n: "Spritesheet da pasta em grade", p: [{name:"pasta",type:"folder"}, "colunas", "linhas", "fps"] },

    { n: "Carregar tilemap", p: ["nome"] },
    { n: "Quando colidir com tile" },
    { n: "Definir tile", p: ["x", "y", "id"] },
    { n: "Ler tile em", p: ["x", "y"] }
  ] },
}

/* Kix/Catrobat conceptual compatibility catalog. This layer annotates existing
 * blocks and adds only semantically-missing entries. Legacy names/opcodes remain.
 */
const KIX_CATROBAT_COMPAT_VERSION = '1.0.0';

// These Catrobat bricks remain runtime/import-compatible, but are intentionally
// hidden from the Kix creation palette to avoid the requested redundant/legacy
// entries. Existing imported projects are not rewritten or stripped.
const KIX_CATROBAT_PALETTE_HIDDEN_IDS = new Set([
  'looks.focus_point',
  'looks.change_brightness',
  'looks.change_color',
  'looks.copy_look',
  'looks.delete_look',
  'looks.edit_look',
  'looks.fade_particle',
  'looks.get_image_current',
  'looks.paint_new_look',
  'looks.say_wait',
  'looks.set_background_wait',
  'looks.think_wait',
  'looks.think',
  'looks.turn_flashlight',
  'looks.particle_additivity',
  'looks.use_camera',
  'looks.set_background_number_wait'
]);

const KIX_CATROBAT_CATEGORIES = {
  event: { key:'evento', names:['Event','Evento'], blocks:[
    {id:'event.when_background_changes', name:'When background changes to', aliases:['Quando o fundo mudar para','Quando background mudar para'], p:[{name:'background',type:'text',default:"''"}], type:'hat'},
    {id:'event.when_scene_starts', name:'When scene starts', aliases:['Quando a cena começar'], p:[], type:'hat'},
    {id:'event.when_stage_tapped', name:'When stage is tapped', aliases:['Quando a tela for pressionada'], p:[], type:'hat'},
    {id:'event.when_tapped', name:'When tapped', aliases:['Quando tocado'], p:[], type:'hat'},
    {id:'event.when_receive', name:'When you receive', aliases:['Quando receber mensagem'], p:[{name:'message',type:'text',default:"''"}], type:'hat'},
    {id:'event.when_clone_starts', name:'When you start as a clone', aliases:['Quando começar como clone'], p:[], type:'hat'},
    {id:'event.when_condition_true', name:'When(…) becomes true', aliases:['Quando condição se tornar verdadeira','Quando (…) se tornar verdadeira'], p:['condition'], type:'hat'}
  ]},
  control: { key:'controle', names:['Control','Controle'], blocks:[
    {id:'control.broadcast', name:'Broadcast', aliases:['Enviar mensagem'], p:['message'], type:'action'},
    {id:'control.broadcast_wait', name:'Broadcast and wait', aliases:['Enviar mensagem e esperar'], p:['message'], type:'action'},
    {id:'control.continue_scene', name:'Continue scene', aliases:[], p:[], type:'action'},
    {id:'control.create_clone', name:'Create clone of', aliases:[], p:['object'], type:'action'},
    {id:'control.delete_clone', name:'Delete this clone', aliases:['Apagar este clone'], p:[], type:'action'},
    {id:'control.finish_stage', name:'Finish stage', aliases:[], p:[], type:'action'},
    {id:'control.for_each', name:'For each value from .. in ..', aliases:[], p:['value','source'], type:'loop'},
    {id:'control.for_range', name:'For values from 1 to 10 in', aliases:[], p:['from','to','value'], type:'loop'},
    {id:'control.forever', name:'Forever', aliases:['Sempre'], p:[], type:'loop'},
    {id:'control.if_else', name:'If … Then … Else …', aliases:['Se ... então ... senão'], p:['condition'], type:'if'},
    {id:'control.if', name:'If(…) is true then', aliases:['Se [Fórmula] for verdadeira então...'], p:['condition'], type:'if'},
    {id:'control.note', name:'Note', aliases:['Nota'], p:['text'], type:'note'},
    {id:'control.repeat', name:'Repeat … times', aliases:['Repita X vezes'], p:['times'], type:'loop'},
    {id:'control.repeat_until', name:'Repeat until …', aliases:['Repita até'], p:['condition'], type:'loop'},
    {id:'control.start_scene', name:'Start scene', aliases:[], p:['scene'], type:'action'},
    {id:'control.stop', name:'Stop', aliases:['Parar este script'], p:[], type:'action'},
    {id:'control.wait', name:'Wait', aliases:['Esperar X segundos'], p:['seconds'], type:'action'},
    {id:'control.wait_until', name:'Wait until … is true', aliases:['Esperar até'], p:['condition'], type:'action'},
    {id:'control.wait_until_scripts_stopped', name:'Wait until all other scripts have stopped', aliases:[], p:[], type:'action'}
  ]},
  motion: { key:'movimento', names:['Motion','Movimento'], blocks:[
    {id:'motion.change_x', name:'Change X by', aliases:['Mudar X em'], p:['value']},
    {id:'motion.change_y', name:'Change Y by', aliases:['Mudar Y em'], p:['value']},
    {id:'motion.glide', name:'Glide … second to', aliases:['Deslizar em X segundos até X: Y:'], p:['seconds','x','y']},
    {id:'motion.go_back_layer', name:'Go back … layer', aliases:[], p:['layers']},
    {id:'motion.go_to', name:'Go to', aliases:['Ir para outro objeto'], p:['target']},
    {id:'motion.go_to_front', name:'Go to front', aliases:['Trazer para frente'], p:[]},
    {id:'motion.if_edge_bounce', name:'If on edge, bounce', aliases:['Se estiver na borda, volte'], p:[]},
    {id:'motion.move_steps', name:'Move … steps', aliases:['Mover X passos'], p:['steps']},
    {id:'motion.place_at', name:'Place at', aliases:['Ir para X e Y'], p:['x','y']},
    {id:'motion.point_direction', name:'Point in direction … degrees', aliases:['Definir direção para'], p:['degrees']},
    {id:'motion.point_towards', name:'Point towards', aliases:['Apontar em direção a'], p:['target']},
    {id:'motion.set_rotation_style', name:'Set rotation style', aliases:['Definir estilo de rotação'], p:['style']},
    {id:'motion.set_velocity', name:'Set velocity to', aliases:[], p:['x','y']},
    {id:'motion.set_x', name:'Set X to', aliases:['Definir X para'], p:['x']},
    {id:'motion.set_y', name:'Set Y to', aliases:['Definir Y para'], p:['y']},
    {id:'motion.set_motion_type', name:'Set your motion type to …', aliases:[], p:['type']},
    {id:'motion.spin_left', name:'Spin left … degrees/second', aliases:[], p:['degreesPerSecond']},
    {id:'motion.spin_right', name:'Spin right … degrees/second', aliases:[], p:['degreesPerSecond']},
    {id:'motion.turn_left', name:'Turn left … degrees', aliases:['Girar esquerda X graus'], p:['degrees']},
    {id:'motion.turn_right', name:'Turn right … degrees', aliases:['Girar direita X graus'], p:['degrees']},
    {id:'motion.vibrate', name:'Vibrate for … second', aliases:['Vibrar por X segundos'], p:['seconds']},
    {id:'motion.when_bounce', name:'When you bounce off …', aliases:[], p:['object'], type:'hat'},
    {id:'motion.set_bounce_factor', name:'Set bounce factor to …%', aliases:['Definir restituição'], p:['percent']},
    {id:'motion.set_friction', name:'Set friction to …%', aliases:[], p:['percent']},
    {id:'motion.set_gravity', name:'Set gravity for all actors and objects to …', aliases:[], p:['gravity']},
    {id:'motion.set_mass', name:'Set mass to … kilogram', aliases:[], p:['kilogram']}
  ]},
  sound: { key:'somplus', names:['Sound','Som'], blocks:[
    {id:'sound.change_volume', name:'Change volume by …', aliases:['Mudar volume em'], p:['percent']},
    {id:'sound.play_drum', name:'Play drum … for … beats', aliases:[], p:['drum','beats']},
    {id:'sound.play_note', name:'Play note … for … beats', aliases:[], p:['note','beats']},
    {id:'sound.set_instrument', name:'Set instrument to', aliases:[], p:['instrument']},
    {id:'sound.set_volume', name:'Set volume to …%', aliases:['Definir volume para'], p:['percent']},
    {id:'sound.start', name:'Start sound', aliases:['Tocar som'], p:['sound']},
    {id:'sound.start_wait', name:'Start sound and wait', aliases:['Tocar som e esperar terminar'], p:['sound']},
    {id:'sound.stop_all', name:'Stop all sounds', aliases:['Parar todos os sons'], p:[]},
    {id:'sound.stop', name:'Stop sound', aliases:['Parar este som'], p:['sound']},
    {id:'sound.change_tempo', name:'Change tempo by …', aliases:[], p:['bpm']},
    {id:'sound.pause_beats', name:'Pause for … beats', aliases:[], p:['beats']},
    {id:'sound.set_tempo', name:'Set tempo to …', aliases:[], p:['bpm']}
  ]},
  looks: { key:'aparencias', names:['Looks','Aparências'], blocks:[
    {id:'looks.ask_store', name:'Ask … and store written answer in …', aliases:['Pedir texto ao usuário'], p:['question','variable']},
    {id:'looks.focus_point', name:'Become focus point with …% horizontal and …% vertical flexibility', aliases:[], p:['horizontal','vertical']},
    {id:'looks.change_brightness', name:'Change brightness by …', aliases:[], p:['percent']},
    {id:'looks.change_color', name:'Change colour by …', aliases:[], p:['value']},
    {id:'looks.change_size', name:'Change size by …', aliases:['Mudar tamanho em'], p:['percent']},
    {id:'looks.change_transparency', name:'Change transparency by …', aliases:['Mudar transparência em'], p:['percent']},
    {id:'looks.clear_effects', name:'Clear graphic effects', aliases:['Limpar efeitos gráficos'], p:[]},
    {id:'looks.copy_look', name:'Copy look and name it …', aliases:[], p:['name']},
    {id:'looks.delete_look', name:'Delete look', aliases:[], p:['look']},
    {id:'looks.edit_look', name:'Edit look', aliases:[], p:['look']},
    {id:'looks.fade_particle', name:'Fade particle effect', aliases:[], p:['seconds']},
    {id:'looks.get_image_current', name:'Get image from … and use as current look', aliases:[], p:['source']},
    {id:'looks.hide', name:'Hide', aliases:['Esconder'], p:[]},
    {id:'looks.next_look', name:'Next look', aliases:['Próxima aparência'], p:[]},
    {id:'looks.paint_new_look', name:'Paint new look …', aliases:[], p:['name']},
    {id:'looks.previous_look', name:'Previous look', aliases:['Aparência anterior'], p:[]},
    {id:'looks.say', name:'Say …', aliases:['Dizer'], p:['text']},
    {id:'looks.say_wait', name:'Say … for … second', aliases:[], p:['text','seconds']},
    {id:'looks.set_background', name:'Set background', aliases:['Mudar aparência para'], p:['background']},
    {id:'looks.set_background_wait', name:'Set background and wait', aliases:[], p:['background']},
    {id:'looks.set_background_number', name:'Set background to number …', aliases:['Definir aparência para número'], p:['number']},
    {id:'looks.set_brightness', name:'Set brightness to …%', aliases:['Definir brilho'], p:['percent']},
    {id:'looks.set_color', name:'Set colour to …', aliases:['Definir cor'], p:['color']},
    {id:'looks.set_particle_color', name:'Set particle color to …', aliases:['Definir cor da partícula'], p:['color']},
    {id:'looks.set_size', name:'Set size to …%', aliases:['Definir tamanho para'], p:['percent']},
    {id:'looks.set_transparency', name:'Set transparency to …', aliases:['Definir transparência para'], p:['percent']},
    {id:'looks.show', name:'Show', aliases:['Mostrar'], p:[]},
    {id:'looks.switch_look', name:'Switch to look', aliases:['Mudar para fantasia/costume'], p:['look']},
    {id:'looks.switch_look_number', name:'Switch to look with number …', aliases:['Definir aparência para número'], p:['number']},
    {id:'looks.think_wait', name:'Think … for … second', aliases:[], p:['text','seconds']},
    {id:'looks.think', name:'Think …', aliases:[], p:['text']},
    {id:'looks.turn_camera', name:'Turn camera', aliases:['Rotacionar câmera'], p:['degrees']},
    {id:'looks.turn_flashlight', name:'Turn flashlight', aliases:[], p:['state']},
    {id:'looks.particle_additivity', name:'Turn particle effect additivity', aliases:[], p:['state']},
    {id:'looks.use_camera', name:'Use camera', aliases:[], p:['camera']},
    {id:'looks.set_background_number_wait', name:'Set background to number … and wait', aliases:[], p:['number']}
  ]},
  pen: { key:'desenhos', names:['Pen','Caneta'], blocks:[
    {id:'pen.clear', name:'Clear', aliases:['Limpar desenho'], p:[]},
    {id:'pen.down', name:'Pen down', aliases:['Abaixar caneta'], p:[]},
    {id:'pen.up', name:'Pen up', aliases:['Levantar caneta'], p:[]},
    {id:'pen.set_size', name:'Set pen size to …', aliases:['Definir tamanho da caneta'], p:['size']},
    {id:'pen.stamp', name:'Stamp', aliases:['Carimbar (stamp)'], p:[]},
    {id:'pen.set_color', name:'Set pen colour to red … green … blue', aliases:[], p:['red','green','blue']}
  ]},
  data: { key:'dados', names:['Data','Dados'], blocks:[
    {id:'data.write_variable_file', name:'Write variable … to file …', aliases:[], p:['variable','file']},
    {id:'data.read_variable_file', name:'Read variable … from file … AND …', aliases:[], p:['variable','file','and']},
    {id:'data.add_to_list', name:'Add … to list …', aliases:['Adicionar à lista'], p:['item','list']},
    {id:'data.delete_item_list', name:'Delete item from list … at position …', aliases:['Apagar de lista'], p:['list','position']},
    {id:'data.delete_all_list', name:'Delete all items from list …', aliases:['Apagar tudo da lista'], p:['list']},
    {id:'data.insert_list', name:'Insert … into list … at position …', aliases:['Inserir em lista'], p:['item','list','position']},
    {id:'data.read_list_device', name:'Read list from device …', aliases:[], p:['list']},
    {id:'data.read_variable_device', name:'Read variable from device …', aliases:['Ler variável do dispositivo'], p:['variable']},
    {id:'data.replace_item_list', name:'Replace item in list … at position … with …', aliases:['Substituir item da lista'], p:['list','position','item']},
    {id:'data.web_request_store', name:'Send web request to … and store answer in …', aliases:[], p:['url','variable']},
    {id:'data.set_variable', name:'Set variable … to …', aliases:['Definir variável para'], p:['variable','value']},
    {id:'data.show_variable_xy', name:'Show variable … at X: … Y: …', aliases:[], p:['variable','x','y']},
    {id:'data.show_variable_style', name:'Show variable … at X: … Y: … size: … colour: … aligned …', aliases:[], p:['variable','x','y','size','color','aligned']},
    {id:'data.store_csv_column', name:'Store column … of the comma-separated values …', aliases:[], p:['column','csv']},
    {id:'data.change_variable', name:'Change variable … by …', aliases:['Mudar variável em'], p:['variable','value']},
    {id:'data.hide_variable', name:'Hide variable …', aliases:['Esconder variável'], p:['variable']},
    {id:'data.write_list_device', name:'Write list on device …', aliases:[], p:['list']},
    {id:'data.write_variable_device', name:'Write variable on device …', aliases:['Salvar variável no dispositivo'], p:['variable']}
  ]},
};

function kixNormalizeBrickText(v) {
  return String(v == null ? '' : v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[.……]/g,'').replace(/[^a-z0-9]+/g,' ').trim();
}
function kixCatrobatBlockMeta(kind) {
  const isHat = kind === 'hat';
  const isLoop = kind === 'loop';
  const isIf = kind === 'if';
  if (isHat) return { canContainChildren:false, canBeChild:false, allowedParent:[], allowedChildren:[] };
  if (isLoop || isIf) return { canContainChildren:true, canBeChild:true, allowedParent:['script','control'], allowedChildren:['command','control'] };
  if (kind === 'note') return { canContainChildren:false, canBeChild:true, allowedParent:['script','control'], allowedChildren:[] };
  return { canContainChildren:false, canBeChild:true, allowedParent:['script','control'], allowedChildren:[] };
}

function kixCatrobatInstallCatalog() {
  const result = {categories:[], blocks:[], duplicates:[]};
  const byName = new Map();
  try {
    Object.entries(CATEGORIES || {}).forEach(([key, cat]) => (cat.blocks || []).forEach(b => {
      if (!b || !b.n) return;
      const n = kixNormalizeBrickText(b.n);
      if (!byName.has(n)) byName.set(n, []);
      byName.get(n).push({key, cat, block:b});
    }));
  } catch (_) {}

  Object.entries(KIX_CATROBAT_CATEGORIES).forEach(([compatCategory, specCat]) => {
    // Explicitly removed categories must never be recreated by the compatibility installer.
    if (compatCategory === 'device' || compatCategory === 'embroidery' || compatCategory === 'yourbricks' || compatCategory === 'plot') return;
    let cat = CATEGORIES[specCat.key];
    if (!cat) {
      const base = compatCategory === 'embroidery' ? (CATEGORIES.desenhos || {}) : (CATEGORIES.layers || CATEGORIES.controle || {});
      cat = {
        name: compatCategory === 'yourbricks' ? 'YourBricks' : (compatCategory === 'embroidery' ? 'Embroidery' : 'Plot'),
        color: base.color || '#64748B', body: base.body || '#CBD5E1', blocks: []
      };
      CATEGORIES[specCat.key] = cat;
      result.categories.push({id:compatCategory,status:'implemented',key:specCat.key,name:cat.name});
    } else {
      result.categories.push({id:compatCategory,status:'existing',key:specCat.key,name:cat.name});
    }

    const catatSet = new Set();
    (cat.blocks || []).forEach(b => { if (b.compatId) catatSet.add(b.compatId); });
    specCat.blocks.forEach(spec => {
      if (KIX_CATROBAT_PALETTE_HIDDEN_IDS.has(spec.id)) {
        result.blocks.push({id:spec.id,status:'hidden-from-palette',category:compatCategory,catrobatName:spec.name});
        return;
      }
      const aliasNames = [spec.name].concat(spec.aliases || []);
      let match = null;
      for (const alias of aliasNames) {
        const hits = byName.get(kixNormalizeBrickText(alias)) || [];
        const preferred = hits.find(h => h.key === specCat.key) || hits[0];
        if (preferred) { match = preferred; break; }
      }
      if (!match) {
        // Semantic fallback: exact compat id already installed (e.g. re-evaluation during hot reload).
        const existingCompat = (cat.blocks || []).find(b => b && b.compatId === spec.id);
        if (existingCompat) match = {key:specCat.key,cat,block:existingCompat};
      }
      const kind = spec.type || 'action';
      const meta = kixCatrobatBlockMeta(kind);
      if (match && match.block) {
        const b = match.block;
        b.compatId = spec.id;
        b.catrobatName = spec.name;
        b.catrobatCategory = compatCategory;
        b.compatNative = true;
        // Existing Kix catalog entries historically had only visual category data.
        // Structural Catrobat metadata must also reach the editor/runtime model.
        if (spec.type && ['hat','loop','if','note'].includes(kind)) {
          b.type = kind;
          b.brickType = kind;
        } else if (!b.brickType && spec.type) {
          b.brickType = kind;
        }
        b.canContainChildren = b.canContainChildren === true || meta.canContainChildren;
        if (b.canBeChild === undefined) b.canBeChild = meta.canBeChild;
        if (!b.allowedParent) b.allowedParent = meta.allowedParent.slice();
        if (!b.allowedChildren) b.allowedChildren = meta.allowedChildren.slice();
        if (b.catrobatParams === undefined) b.catrobatParams = spec.p || [];
        result.blocks.push({id:spec.id,status:'existing',category:compatCategory,projectName:b.n,catrobatName:spec.name});
        const key = kixNormalizeBrickText(b.n);
        if ((byName.get(key) || []).length > 1) result.duplicates.push({id:spec.id,name:b.n,candidates:(byName.get(key)||[]).map(x=>x.block.n)});
      } else {
        const b = {
          n: spec.name, p: spec.p || [],
          compatId: spec.id, catrobatName: spec.name, catrobatCategory: compatCategory,
          compatNative:false, canContainChildren:meta.canContainChildren, canBeChild:meta.canBeChild,
          allowedParent:meta.allowedParent.slice(), allowedChildren:meta.allowedChildren.slice(),
          brickType:kind
        };
        cat.blocks.push(b);
        byName.set(kixNormalizeBrickText(b.n), [{key:specCat.key,cat,block:b}]);
        result.blocks.push({id:spec.id,status:'implemented',category:compatCategory,projectName:b.n,catrobatName:spec.name});
      }
    });
  });

  const compatRegistry = Object.create(null), compatAliases = Object.create(null);
  Object.values(CATEGORIES || {}).forEach(cat => (cat.blocks || []).forEach(b => {
    if (!b || !b.compatId) return;
    b.compatVersion = KIX_CATROBAT_COMPAT_VERSION;
    if (!b.brickType) b.brickType = b.type || 'action';
    const entry = {id:b.compatId, catrobatName:b.catrobatName, category:b.catrobatCategory, projectName:b.n, opcode:b.opcode || null, params:b.catrobatParams || b.p || [], type:b.brickType, compatNative:b.compatNative !== false, canContainChildren:b.canContainChildren===true, canBeChild:b.canBeChild!==false, allowedParent:b.allowedParent||[], allowedChildren:b.allowedChildren||[]};
    compatRegistry[b.compatId] = entry;
    [b.n,b.catrobatName].forEach(n => { if(n) compatAliases[kixNormalizeBrickText(n)] = b.compatId; });
  }));
  window.KixCatrobatBrickRegistry = compatRegistry;
  window.KixCatrobatBrickAliases = compatAliases;
  window.KixCatrobatCompatCatalog = KIX_CATROBAT_CATEGORIES;
  window.KixCatrobatCompatAudit = result;
  window.KixCatrobatPaletteHiddenIds = Array.from(KIX_CATROBAT_PALETTE_HIDDEN_IDS);
  return result;
}

const KIX_CATROBAT_INSTALL_RESULT = kixCatrobatInstallCatalog();


// ============================================================
// Kix i18n + clear Brick language
// Primary locale: pt-BR. Secondary locales: ru, es, en.
// The persisted block name/opcode never changes; only presentation changes.
// ============================================================
const KIX_SUPPORTED_LOCALES = Object.freeze({
  'pt-BR': { label:'Português (Brasil)', short:'PT-BR' },
  'ru':    { label:'Русский', short:'RU' },
  'es':    { label:'Español', short:'ES' },
  'en':    { label:'English', short:'EN' }
});

const KIX_UI_I18N = {
  'pt-BR': {
    settings:'Configurações', language:'Idioma', languageDesc:'Idioma da interface e dos blocos traduzidos',
    primaryLanguage:'Principal', secondaryLanguages:'Secundários', extensions:'Extensões', interface:'Interface', privacy:'Privacidade', appearance:'Aparência', additions:'Adições', appOptions:'Opções do app',
    categoryStyle:'Estilo das categorias', classic:'Clássico', centered:'Centralizado', searchBlocks:'Buscar blocos...',
    autoSave:'Salvar automaticamente', autoSaveDesc:'Mantém alterações persistidas enquanto você edita', compact:'Interface compacta', compactDesc:'Reduz espaços e deixa mais conteúdo visível',
    visualFeedback:'Toques com resposta visual', visualFeedbackDesc:'Dá feedback rápido ao tocar em controles', toasts:'Avisos rápidos (toasts)', toastsDesc:'Mostra mensagens temporárias de confirmação e erro', grid:'Grade do palco por padrão', gridDesc:'Mostra uma referência visual ao testar cenas',
    plugins:'Plugins', pluginsDesc:'Gerenciar plugins instalados', experimental:'Recursos experimentais', linter:'Análise de código em tempo real', telemetry:'Relatórios anônimos de erros'
  },
  'en': {
    settings:'Settings', language:'Language', languageDesc:'Interface and translated block language',
    primaryLanguage:'Primary', secondaryLanguages:'Secondary', extensions:'Extensions', interface:'Interface', privacy:'Privacy', appearance:'Appearance', additions:'Add-ons', appOptions:'App options',
    categoryStyle:'Category style', classic:'Classic', centered:'Centered', searchBlocks:'Search blocks...',
    autoSave:'Auto-save', autoSaveDesc:'Keeps edits persisted while you work', compact:'Compact interface', compactDesc:'Reduces spacing to show more content',
    visualFeedback:'Touch feedback', visualFeedbackDesc:'Quick visual response on controls', toasts:'Toast messages', toastsDesc:'Shows temporary confirmation and error messages', grid:'Stage grid by default', gridDesc:'Shows a visual guide while testing scenes',
    plugins:'Plugins', pluginsDesc:'Manage installed plugins', experimental:'Experimental features', linter:'Real-time code analysis', telemetry:'Anonymous error reports'
  },
  'es': {
    settings:'Configuración', language:'Idioma', languageDesc:'Idioma de la interfaz y de los bloques traducidos',
    primaryLanguage:'Principal', secondaryLanguages:'Secundarios', extensions:'Extensiones', interface:'Interfaz', privacy:'Privacidad', appearance:'Apariencia', additions:'Añadidos', appOptions:'Opciones de la app',
    categoryStyle:'Estilo de categorías', classic:'Clásico', centered:'Centrado', searchBlocks:'Buscar bloques...',
    autoSave:'Guardado automático', autoSaveDesc:'Mantiene los cambios guardados mientras editas', compact:'Interfaz compacta', compactDesc:'Reduce espacios para mostrar más contenido',
    visualFeedback:'Respuesta visual al tocar', visualFeedbackDesc:'Respuesta rápida al tocar controles', toasts:'Avisos rápidos', toastsDesc:'Muestra mensajes temporales de confirmación y error', grid:'Cuadrícula del escenario', gridDesc:'Muestra una guía visual al probar escenas',
    plugins:'Plugins', pluginsDesc:'Gestionar plugins instalados', experimental:'Funciones experimentales', linter:'Análisis de código en tiempo real', telemetry:'Informes anónimos de errores'
  },
  'ru': {
    settings:'Настройки', language:'Язык', languageDesc:'Язык интерфейса и переведённых блоков',
    primaryLanguage:'Основной', secondaryLanguages:'Дополнительные', extensions:'Расширения', interface:'Интерфейс', privacy:'Конфиденциальность', appearance:'Внешний вид', additions:'Дополнения', appOptions:'Настройки приложения',
    categoryStyle:'Стиль категорий', classic:'Классический', centered:'По центру', searchBlocks:'Поиск блоков...',
    autoSave:'Автосохранение', autoSaveDesc:'Сохраняет изменения во время редактирования', compact:'Компактный интерфейс', compactDesc:'Уменьшает отступы и показывает больше содержимого',
    visualFeedback:'Отклик на касание', visualFeedbackDesc:'Быстрый визуальный отклик элементов', toasts:'Всплывающие уведомления', toastsDesc:'Показывает временные сообщения подтверждения и ошибки', grid:'Сетка сцены', gridDesc:'Показывает визуальную сетку при тестировании сцен',
    plugins:'Плагины', pluginsDesc:'Управление установленными плагинами', experimental:'Экспериментальные функции', linter:'Анализ кода в реальном времени', telemetry:'Анонимные отчёты об ошибках'
  }
};

const KIX_APP_TEXT_I18N = {
  'projects-empty': {'pt-BR':'Nenhum projeto ainda. Toque em + para criar.','en':'No projects yet. Tap + to create one.','es':'Aún no hay proyectos. Toca + para crear uno.','ru':'Пока нет проектов. Нажмите +, чтобы создать.'},
  'tutorial-title': {'pt-BR':'Mini tutorial','en':'Quick tutorial','es':'Mini tutorial','ru':'Мини-урок'},
  'create-portrait': {'pt-BR':'Retrato','en':'Portrait','es':'Retrato','ru':'Портрет'},
  'create-landscape': {'pt-BR':'Paisagem','en':'Landscape','es':'Paisaje','ru':'Альбомная'},
  'create-confirm': {'pt-BR':'Criar','en':'Create','es':'Crear','ru':'Создать'},
  'create-cancel': {'pt-BR':'Sair','en':'Exit','es':'Salir','ru':'Выйти'},
  'screen-dialog-title': {'pt-BR':'Ação','en':'Action','es':'Acción','ru':'Действие'},
  'screen-catrobat-report-title': {'pt-BR':'Análise Catrobat','en':'Catrobat analysis','es':'Análisis de Catrobat','ru':'Анализ Catrobat'},
  'project-options-import-files': {'pt-BR':'Importar arquivos','en':'Import files','es':'Importar archivos','ru':'Импортировать файлы'},
  'project-options-clear-vars': {'pt-BR':'Limpar variáveis salvas','en':'Clear saved variables','es':'Borrar variables guardadas','ru':'Очистить сохранённые переменные'},
  'project-options-export': {'pt-BR':'Exportar .kix','en':'Export .kix','es':'Exportar .kix','ru':'Экспорт .kix'},
  'project-options-delete': {'pt-BR':'Excluir projeto','en':'Delete project','es':'Eliminar proyecto','ru':'Удалить проект'},
  'actors-label': {'pt-BR':'Atores e objetos','en':'Actors & objects','es':'Actores y objetos','ru':'Объекты'},
  'actors-empty': {'pt-BR':'Toque em + para adicionar um objeto','en':'Tap + to add an object','es':'Toca + para añadir un objeto','ru':'Нажмите +, чтобы добавить объект'},
  'scripts-empty': {'pt-BR':'Nenhum script.\nToque em + para adicionar blocos.','en':'No scripts.\nTap + to add blocks.','es':'No hay scripts.\nToca + para añadir bloques.','ru':'Нет скриптов.\nНажмите +, чтобы добавить блоки.'},
  'looks-empty': {'pt-BR':'Nenhuma aparência.\nImporte imagens.','en':'No looks.\nImport images.','es':'No hay apariencias.\nImporta imágenes.','ru':'Нет образов.\nИмпортируйте изображения.'},
  'sounds-empty': {'pt-BR':'Nenhum som.\nImporte arquivos de áudio.','en':'No sounds.\nImport audio files.','es':'No hay sonidos.\nImporta archivos de audio.','ru':'Нет звуков.\nИмпортируйте аудиофайлы.'},
  'btn-import-look': {'pt-BR':'+ Importar imagem','en':'+ Import image','es':'+ Importar imagen','ru':'+ Импортировать изображение'},
  'btn-import-sound': {'pt-BR':'+ Importar som','en':'+ Import sound','es':'+ Importar sonido','ru':'+ Импортировать звук'},
  'categories-title': {'pt-BR':'Categorias','en':'Categories','es':'Categorías','ru':'Категории'},
  'image-picker-title': {'pt-BR':'Escolher imagem','en':'Choose image','es':'Elegir imagen','ru':'Выбрать изображение'},
  'btn-image-picker-formula': {'pt-BR':'Fórmula','en':'Formula','es':'Fórmula','ru':'Формула'},
  'btn-image-picker-add': {'pt-BR':'+ Imagem','en':'+ Image','es':'+ Image','ru':'+ Изображение'},
  'image-picker-grid-title': {'pt-BR':'Imagens do projeto','en':'Project images','es':'Imágenes del proyecto','ru':'Изображения проекта'},
  'image-picker-empty': {'pt-BR':'Nenhuma imagem adicionada.','en':'No images added.','es':'No hay imágenes.','ru':'Изображений нет.'},
  'formula-title': {'pt-BR':'Editor de fórmula','en':'Formula editor','es':'Editor de fórmulas','ru':'Редактор формул'},
  'formula-result': {'pt-BR':'Resultado:','en':'Result:','es':'Resultado:','ru':'Результат:'},
  'formula-text-mode': {'pt-BR':'Inserir texto','en':'Insert text','es':'Insertar texto','ru':'Вставить текст'},
  'formula-text-ok': {'pt-BR':'Inserir texto','en':'Insert text','es':'Insertar texto','ru':'Вставить текст'},
  'stop-play': {'pt-BR':'Voltar','en':'Back','es':'Volver','ru':'Назад'},
  'restart-play': {'pt-BR':'Reiniciar','en':'Restart','es':'Reiniciar','ru':'Перезапустить'},
  'pause-play': {'pt-BR':'Pausar','en':'Pause','es':'Pausar','ru':'Пауза'},
  'play-more': {'pt-BR':'Mais','en':'More','es':'Más','ru':'Ещё'},
  'play-more-rotate': {'pt-BR':'Girar tela','en':'Rotate screen','es':'Girar pantalla','ru':'Повернуть экран'},
  'play-more-camera': {'pt-BR':'Câmera livre','en':'Free camera','es':'Cámara libre','ru':'Свободная камера'},
  'play-more-reset-camera': {'pt-BR':'Centralizar câmera','en':'Center camera','es':'Centrar cámara','ru':'Центрировать камеру'},
  'play-more-fit': {'pt-BR':'Ajustar ao palco','en':'Fit to stage','es':'Ajustar al escenario','ru':'По размеру сцены'},
  'play-more-grid': {'pt-BR':'Grade de referência','en':'Reference grid','es':'Cuadrícula','ru':'Сетка'},
  'play-more-axes': {'pt-BR':'Eixos','en':'Axes','es':'Ejes','ru':'Оси'},
  'play-more-collision': {'pt-BR':'Mostrar colisões','en':'Show collisions','es':'Mostrar colisiones','ru':'Показать столкновения'},
  'play-more-fps': {'pt-BR':'FPS e depuração','en':'FPS & debug','es':'FPS y depuración','ru':'FPS и отладка'},
  'play-more-reload': {'pt-BR':'Recarregar cena','en':'Reload scene','es':'Recargar escena','ru':'Перезагрузить сцену'},
  'play-more-clearlog': {'pt-BR':'Limpar diagnóstico','en':'Clear diagnostics','es':'Limpiar diagnóstico','ru':'Очистить диагностику'},
  'play-more-selftest': {'pt-BR':'Verificar engine','en':'Check engine','es':'Comprobar motor','ru':'Проверить движок'},
  'play-more-clean': {'pt-BR':'Tirar menu','en':'Hide menu','es':'Ocultar menú','ru':'Скрыть меню'},
  'kix-quality-toggle': {'pt-BR':'Kix Quality','en':'Kix Quality','es':'Kix Quality','ru':'Kix Quality'},
  'files-empty': {'pt-BR':'Nenhum arquivo. Toque em + para importar.','en':'No files. Tap + to import.','es':'No hay archivos. Toca + para importar.','ru':'Нет файлов. Нажмите + для импорта.'},
  'ctx-formula-btn': {'pt-BR':'Editar fórmula','en':'Edit formula','es':'Editar fórmula','ru':'Изменить формулу'},
  'ctx-visual-position-btn': {'pt-BR':'Colocar visualmente','en':'Place visually','es':'Colocar visualmente','ru':'Разместить визуально'},
  'visual-position-cancel': {'pt-BR':'Cancelar','en':'Cancel','es':'Cancelar','ru':'Отмена'},
  'visual-position-confirm': {'pt-BR':'Concluir','en':'Done','es':'Listo','ru':'Готово'},
  'confirm-cancel': {'pt-BR':'Cancelar','en':'Cancel','es':'Cancelar','ru':'Отмена'},
  'confirm-delete': {'pt-BR':'Excluir','en':'Delete','es':'Eliminar','ru':'Удалить'},
  'menu-import-catrobat': {'pt-BR':'Importar Catroid','en':'Import Catroid','es':'Importar Catroid','ru':'Импорт Catroid'},
  'menu-create-folder': {'pt-BR':'Criar pasta','en':'Create folder','es':'Crear carpeta','ru':'Создать папку'},
  'menu-import-gif': {'pt-BR':'Importar GIF','en':'Import GIF','es':'Importar GIF','ru':'Импорт GIF'},
  'actor-opt-title': {'pt-BR':'Objeto','en':'Object','es':'Objeto','ru':'Объект'},
  'look-opt-title': {'pt-BR':'Aparência','en':'Look','es':'Apariencia','ru':'Образ'}
};

const KIX_CATEGORY_I18N = {
  evento:    {'pt-BR':'Evento',        en:'Event',       es:'Eventos',        ru:'События'},
  controle:  {'pt-BR':'Controle',      en:'Control',     es:'Control',        ru:'Управление'},
  movimento: {'pt-BR':'Movimento',     en:'Motion',      es:'Movimiento',     ru:'Движение'},
  aparencias:{'pt-BR':'Aparências',    en:'Looks',       es:'Apariencia',     ru:'Внешность'},
  dados:     {'pt-BR':'Dados',         en:'Data',        es:'Datos',          ru:'Данные'},
  telefone:  {'pt-BR':'Telefone',      en:'Device',      es:'Dispositivo',    ru:'Устройство'},
  desenhos:  {'pt-BR':'Desenhos',      en:'Drawing',     es:'Dibujo',         ru:'Рисование'},
  ia:        {'pt-BR':'IA',            en:'AI',          es:'IA',             ru:'ИИ'},
  shaders:   {'pt-BR':'Shaders',       en:'Shaders',     es:'Shaders',        ru:'Шейдеры'},
  fastui:    {'pt-BR':'UI',            en:'UI',          es:'UI',             ru:'UI'},
  texto:     {'pt-BR':'Texto',         en:'Text',        es:'Texto',          ru:'Текст'},
  presets:   {'pt-BR':'Presets',       en:'Presets',     es:'Presets',        ru:'Пресеты'},
  somplus:   {'pt-BR':'Som+',          en:'Sound+',      es:'Sonido+',        ru:'Звук+'},
  multiplayer:{'pt-BR':'Multiplayer',  en:'Multiplayer', es:'Multijugador',   ru:'Мультиплеер'},
  animavancada:{'pt-BR':'Animação',    en:'Animation',   es:'Animación',      ru:'Анимация'},
  economia:  {'pt-BR':'Loja',          en:'Store',       es:'Tienda',         ru:'Магазин'},
  database:  {'pt-BR':'Persistência',  en:'Persistence', es:'Persistencia',   ru:'Хранилище'},
  seguranca: {'pt-BR':'Segurança',     en:'Security',    es:'Seguridad',      ru:'Безопасность'},
  levels:    {'pt-BR':'Levels',        en:'Levels',       es:'Niveles',        ru:'Уровни'},
  cameraplus:{'pt-BR':'Camera+',       en:'Camera+',     es:'Cámara+',        ru:'Камера+'},
  layers:    {'pt-BR':'Layers',        en:'Layers',      es:'Capas',          ru:'Слои'},
  debug:     {'pt-BR':'Debug',         en:'Debug',       es:'Depuración',     ru:'Отладка'},
  tilemap:   {'pt-BR':'Tilemap',       en:'Tilemap',     es:'Tilemap',        ru:'Тайлмап'}
};

// Clearer PT-BR presentation without changing persistent block names.
// Inspired by Pocket Code/Catroid's short action-first Brick phrasing.
const KIX_COMPACT_PT_TEMPLATES = {
  'Quando cronômetro >':'Quando cronômetro > {segundos}s',
  'Quando entrar na região':'Ao entrar: X {x} Y {y} W {largura} H {altura}',
  'Quando sair da região':'Ao sair: X {x} Y {y} W {largura} H {altura}',
  'Esperar X segundos':'Esperar {segundos}s',
  'Se tocado X vezes seguidamente':'Se tocado {vezes}× seguidas',
  'Debounce por X ms':'Aguardar {ms} ms entre ativações',
  'Throttle a cada X ms':'Limitar a uma ativação a cada {ms} ms',
  'Executar após frames':'Executar após {quadros} frames',
  'Com chance % faça':'{porcentagem}% de chance: executar',
  'Repetir para sempre com delay':'Repetir sempre: intervalo {segundos}s',
  'Se variável = faça':'Se {variável} = {valor}',
  'Transição fade para cena':'Ir para {cena}: fade {segundos}s • {cor} • {estilo}',
  'Transição fade para [cena] em [segundos]':'Ir para {cena}: fade {segundos}s • {cor} • {estilo}',
  'Mudar para cena':'Ir para {cena}',
  'Mover X passos':'Mover {passos} passos',
  'Girar direita X graus':'Girar {graus}° →',
  'Girar esquerda X graus':'Girar {graus}° ←',
  'Ir para X e Y':'Ir para X {x} Y {y}',
  'Deslizar em X segundos até X: Y:':'Deslizar até X {x} Y {y} ({segundos}s)',
  'Apontar para direção X':'Apontar {direção}°',
  'Mover na direção':'Mover {passos} → {graus}°',
  'Seguir objeto':'Seguir {objeto}: {passos} passos',
  'Afastar de objeto':'Afastar de {objeto}: {passos} passos',
  'Definir velocidade X':'Velocidade X = {valor}',
  'Definir velocidade Y':'Velocidade Y = {valor}',
  'Definir gravidade personalizada':'Gravidade X {x} Y {y}',
  'Aplicar Impulso':'Impulso X {x} Y {y}',
  'Definir tamanho da colisão':'Colisão W {largura} H {altura}',
  'Definir deslocamento da colisão':'Offset X {x} Y {y}',
  'Verificar colisão com':'Colisão {objeto} → {variável}',
  'Mudar para fantasia/costume':'Mudar para {costume}',
  'Definir GIF como aparência':'Usar {imagem} como aparência',
  'Mudar tamanho em':'Tamanho {valor}%',
  'Definir tamanho para':'Tamanho = {valor}%',
  'Definir efeito para':'Efeito {efeito} = {valor}',
  'Ir para camada':'Camada = {camada}',
  'Mudar camada em':'Camada + {valor}',
  'Definir transparência para':'Transparência = {valor}%',
  'Definir aparência para número':'Aparência {número}',
  'Definir aparência para nome':'Aparência {nome}',
  'Definir opacidade':'Opacidade = {valor}%',
  'Mudar opacidade em':'Opacidade + {valor}%',
  'Aparecer gradualmente':'Aparecer em {segundos}s',
  'Desaparecer gradualmente':'Sumir em {segundos}s',
  'Definir variável para':'Definir variável {variável} para {valor}',
  'Mudar variável em':'Alterar variável {variável} por {valor}',
  'Mostrar variável':'Mostrar variável {variável}',
  'Esconder variável':'Esconder variável {variável}',
  'Criar lista':'Criar lista {lista}',
  'Adicionar à lista':'Adicionar {item} à lista {lista}',
  'Apagar de lista':'Apagar item {índice} da lista {lista}',
  'Apagar tudo da lista':'Apagar todos os itens da lista {lista}',
  'Inserir em lista':'Inserir {item} na posição {índice} da lista {lista}',
  'Substituir item da lista':'Substituir item {índice} da lista {lista} por {item}',
  'Item da lista':'Obter item {índice} da lista {lista}',
  'Tamanho da lista':'Obter tamanho da lista {lista}',
  'Lista contém':'Verificar se a lista {lista} contém {item}',
  'Mostrar lista':'Mostrar {lista}',
  'Esconder lista':'Esconder {lista}',
  'Mostrar texto':'Mostrar {texto}',
  'Definir fonte':'Fonte = {fonte}',
  'Definir tamanho da fonte':'Fonte = {tamanho}',
  'Definir cor do texto':'Cor do texto = {cor}',
  'Definir alinhamento':'Alinhar {alinhamento}',
  'Escrever texto em tempo real':'Escrever {variável} X {x} Y {y} Tamanho {tamanho} Cor {cor} Fonte {fonte} Ângulo {graus}',
  'Perguntar ao usuário':'Perguntar {pergunta} Salvar em {variável}',
  'Rotacionar texto':'Texto {graus}°',
  'Definir opacidade do texto':'Texto: opacidade {opacidade}%',
  'Tocar som':'Tocar {som}',
  'Tocar som e esperar terminar':'Tocar {som} e esperar',
  'Mudar volume em':'Volume + {valor}%',
  'Definir volume para':'Volume = {valor}%',
  'Falar (texto para voz)':'Falar {texto}',
  'Falar e esperar':'Falar {texto} e esperar'
};

// Final PT-BR Brick presentation grammar.
// This is intentionally visual-only: `block.n` remains the stable runtime key.
// Phrasing follows the compact, action-first style visible in NewCatroid/Catroid
// references (for example: "Definir tamanho para 195 %", "Alterar tamanho em 5",
// "Aguardar 0,01 segundos", "Colocar em X ... Y ...", "Iniciar som ...").
const KIX_CATROID_PT_TEMPLATES = {
  // Evento
  'Quando a cena começar':'Quando a cena começar',
  'Quando tocado':'Quando tocado',
  'Quando a tela for pressionada':'Quando a tela for pressionada',
  'Quando o sprite for solto':'Quando o sprite for solto',
  'Quando o dedo mover sobre o sprite':'Quando o dedo mover sobre o sprite',
  'Quando o dedo mover na tela':'Quando o dedo mover na tela',
  'Quando receber mensagem':'Quando receber {mensagem}',
  'Enviar mensagem':'Enviar {mensagem}',
  'Enviar mensagem e esperar':'Enviar {mensagem} e esperar',
  'Quando inclinar dispositivo':'Quando inclinar o dispositivo para {direção}',
  'Quando bater no dispositivo':'Quando bater no dispositivo',
  'Quando colidir com':'Quando colidir com {objeto}',
  'Quando variável mudar':'Quando {variável} mudar',
  'Quando cronômetro >':'Quando o cronômetro passar de {segundos} segundos',
  'Quando entrar na região':'Quando entrar na região X {x} Y {y} largura {largura} altura {altura}',
  'Quando sair da região':'Quando sair da região X {x} Y {y} largura {largura} altura {altura}',
  'Quando FPS <':'Quando FPS for menor que {fps}',

  // Controle
  'Esperar X segundos':'Aguardar {segundos} segundos',
  'Sempre':'Sempre',
  'Repita X vezes':'Repetir {vezes} vezes',
  'Repita até':'Repetir até {condição}',
  'Repita enquanto':'Repetir enquanto {condição}',
  'Se ... então':'Se {condição} for verdadeira então',
  'Se ... então ... senão':'Se {condição} for verdadeira então',
  'Se [Fórmula] for verdadeira então...':'Se {condição} for verdadeira então',
  'Esperar até':'Aguardar até {condição}',
  'Parar este script':'Parar este script',
  'Parar todos os scripts':'Parar todos os scripts',
  'Parar outros scripts deste objeto':'Parar outros scripts deste objeto',
  'Sair do loop':'Sair do loop',
  'Continuar próxima iteração':'Continuar próxima repetição',
  'Se tocado X vezes seguidamente':'Se tocado {vezes} vezes seguidas',
  'Iniciar thread':'Iniciar thread {nome}',
  'Aguardar thread':'Aguardar thread {nome}',
  'Parar thread':'Parar thread {nome}',
  'Criar clone':'Criar clone',
  'Quando começar como clone':'Quando começar como clone',
  'Apagar este clone':'Apagar este clone',
  'Nota':'Nota {texto}',
  'Executar após frames':'Executar após {quadros} frames',
  'Com chance % faça':'Com chance de {porcentagem}% fazer',
  'Esperar um frame':'Aguardar um quadro',
  'Repetir para sempre com delay':'Repetir para sempre com intervalo de {segundos} segundos',
  'Se variável = faça':'Se {variável} = {valor} então',
  'Sair de todos os loops':'Sair de todos os loops',
  'Executar uma vez':'Executar uma vez',
  'Se está tocando':'Se estiver tocando {objeto}',
  'Mudar para cena':'Ir para a cena {cena}',
  'Próxima cena':'Próxima cena',
  'Cena anterior':'Cena anterior',
  'Reiniciar cena atual':'Reiniciar cena atual',
  'Transição fade para cena':'Ir para a cena {cena} em {segundos} segundos com cor {cor} e estilo {estilo}',
  'Transição fade para [cena] em [segundos]':'Ir para a cena {cena} em {segundos} segundos com cor {cor} e estilo {estilo}',

  // Movimento
  'Mover X passos':'Mover {passos} passos',
  'Girar direita X graus':'Girar {graus} graus para a direita',
  'Girar esquerda X graus':'Girar {graus} graus para a esquerda',
  'Ir para X e Y':'Colocar em X: {x} Y: {y}',
  'Ir para posição aleatória':'Ir para uma posição aleatória',
  'Ir para outro objeto':'Ir para {objeto}',
  'Deslizar em X segundos até X: Y:':'Deslizar em {segundos} segundos até X: {x} Y: {y}',
  'Apontar em direção a':'Apontar em direção a {objeto}',
  'Apontar para direção X':'Apontar em direção a {direção} graus',
  'Mudar X em':'Alterar X em {valor}',
  'Definir X para':'Definir X para {valor}',
  'Mudar Y em':'Alterar Y em {valor}',
  'Definir Y para':'Definir Y para {valor}',
  'Se estiver na borda, volte':'Se estiver na borda, voltar',
  'Definir estilo de rotação':'Definir estilo de rotação para {estilo}',
  'Mover em direção ao toque':'Mover em direção ao toque',
  'Mudar direção em':'Alterar direção em {graus} graus',
  'Definir direção para':'Definir direção para {graus} graus',
  'Mover na direção':'Mover {passos} passos na direção {graus} graus',
  'Seguir objeto':'Seguir {objeto} por {passos} passos',
  'Afastar de objeto':'Afastar de {objeto} por {passos} passos',
  'Ir para o toque':'Ir para o toque',
  'Limitar à tela':'Limitar à tela',
  'Definir velocidade X':'Definir velocidade X para {valor}',
  'Definir velocidade Y':'Definir velocidade Y para {valor}',
  'Parar movimento':'Parar movimento',
  'Mover em círculo':'Mover em círculo com raio {raio} e ângulo {graus} graus',
  'Empurrar com força':'Empurrar com força {força} na direção {direção} graus',
  'Seguir joystick':'Seguir joystick {id} a {velocidade} com apontar {apontar}',
  'Definir gravidade personalizada':'Definir gravidade em X: {x} Y: {y}',
  'Ativar Colisão Trigger':'Ativar colisão',
  'Camadas de Colisão':'Camada de colisão {camada}',
  'Raycast':'Lançar raio de X: {x} Y: {y} em {ângulo} graus',
  'Criar Joint/Mola':'Criar junta ou mola',
  'Configurar física de veículo':'Configurar física do veículo',
  'Aplicar Impulso':'Aplicar impulso X: {x} Y: {y}',
  'Definir Massa/Atrito':'Definir massa {massa} e atrito {atrito}',
  'Sensor de Colisão Contínua':'Ativar detecção contínua de colisão',
  'Verificar colisão com':'Verificar colisão com {objeto} e salvar em {variável}',
  'Parar ao colidir com':'Parar ao colidir com {objeto}',
  'Desfazer movimento se colidir':'Desfazer movimento ao colidir',
  'Empurrar ao colidir':'Ao colidir, empurrar com força {força}',
  'Mover até colidir':'Mover até colidir com {objeto} por {passos} passos',
  'Definir resposta de colisão':'Definir resposta de colisão para {modo}',
  'Definir camada de colisão':'Definir camada de colisão para {camada}',
  'Definir máscara de colisão':'Definir máscara de colisão para {máscara}',
  'Definir tamanho da colisão':'Definir tamanho da colisão para {largura} por {altura}',
  'Definir deslocamento da colisão':'Definir deslocamento da colisão X: {x} Y: {y}',
  'Pausar Física do Objeto':'Pausar física do objeto',
  'Simular explosão':'Simular explosão com força {força}',
  'Detectar Contato':'Detectar contato',
  'Definir restituição':'Definir restituição para {valor}',
  'Otimizar Mundo Físico':'Otimizar mundo físico',
  'Path de Física':'Caminho de física',

  // Aparências
  'Mudar para fantasia/costume':'Alterar para aparência {costume}',
  'Definir GIF como aparência':'Definir {imagem} como aparência',
  'Tocar GIF':'Iniciar GIF {imagem}',
  'Parar GIF':'Parar GIF',
  'Reiniciar GIF':'Reiniciar GIF',
  'Próxima fantasia':'Próxima aparência',
  'Mudar tamanho em':'Alterar tamanho em {valor} %',
  'Definir tamanho para':'Definir tamanho para {valor} %',
  'Mostrar':'Mostrar',
  'Esconder':'Esconder',
  'Mudar efeito gráfico em':'Alterar efeito {efeito} em {valor}',
  'Definir efeito para':'Definir efeito {efeito} para {valor}',
  'Limpar efeitos gráficos':'Limpar efeitos gráficos',
  'Ir para camada':'Ir para a camada {camada}',
  'Mudar camada em':'Alterar camada em {valor}',
  'Mudar transparência em':'Alterar transparência em {valor} %',
  'Definir transparência para':'Definir transparência para {valor} %',
  'Definir aparência para número':'Definir aparência de número {número}',
  'Definir aparência para nome':'Definir aparência {nome}',
  'Espelhar horizontal':'Espelhar horizontalmente',
  'Espelhar vertical':'Espelhar verticalmente',
  'Trocar cor':'Trocar a cor {de} por {para}',
  'Definir tolerância de cor':'Definir tolerância de cor para {valor}',
  'Dizer':'Dizer {texto} por {segundos} segundos',
  'Fade in':'Aparecer gradualmente em {segundos} segundos',
  'Fade out':'Desaparecer gradualmente em {segundos} segundos',
  'Piscar X vezes':'Piscar {vezes} vezes',
  'Definir brilho':'Definir brilho para {valor}',
  'Outline':'Adicionar contorno {cor} com espessura {espessura}',
  'Criar emissor de partículas':'Criar emissor de partículas',
  'Definir taxa de emissão':'Definir taxa de emissão para {valor}',
  'Quando partícula nascer':'Quando uma partícula nascer',
  'Definir cor da partícula':'Definir cor da partícula para {cor}',
  'Reproduzir animação da pasta':'Iniciar animação da pasta {pasta}',
  'Repetir animação da pasta':'Repetir animação da pasta {pasta}',
  'Repetir animação da pasta em loop':'Repetir animação da pasta {pasta} em loop',
  'Parar animação da pasta':'Parar animação da pasta {pasta}',
  'Aplicar animação em loop na pasta':'Aplicar animação da pasta {pasta} em loop',
  'Tocar pasta uma vez e parar na última aparência':'Tocar {pasta} uma vez e parar na última aparência',
  'Tocar pasta uma vez e voltar pra aparência original':'Tocar {pasta} uma vez e voltar à aparência original',
  'Definir pasta como aparência atual':'Definir {pasta} como aparência atual',
  'Inverter ordem da pasta ao tocar':'Inverter a ordem de {pasta} ao tocar',
  'Tocar pasta em loop na velocidade':'Tocar {pasta} em loop a {fps} FPS',
  'Tocar pasta uma vez na velocidade':'Tocar {pasta} uma vez a {fps} FPS',
  'Parar animação':'Parar animação',
  'Próximo quadro da animação':'Próximo quadro da animação',
  'Definir quadro da animação para':'Definir quadro da animação para {número}',
  'Esperar animação terminar':'Aguardar animação terminar',
  'Definir velocidade da animação para':'Definir velocidade da animação para {valor}',
  'Mudar aparência para':'Alterar para aparência {nome}',
  'Definir cor':'Definir a cor {de} para {para} com tolerância {tolerância}',
  'Restaurar cor original':'Restaurar cor original',
  'Mudar aparência':'Alterar aparência por {valor}',
  'Próxima aparência':'Próxima aparência',
  'Aparência anterior':'Aparência anterior',
  'Trazer para frente':'Trazer para frente',
  'Enviar para trás':'Enviar para trás',
  'Definir opacidade':'Definir opacidade para {valor} %',
  'Mudar opacidade em':'Alterar opacidade em {valor} %',
  'Aparecer gradualmente':'Aparecer gradualmente em {segundos} segundos',
  'Desaparecer gradualmente':'Desaparecer gradualmente em {segundos} segundos',
  'Definir efeito':'Definir efeito {efeito} para {valor}',
  'Mudar efeito em':'Alterar efeito {efeito} em {valor}',
  'Limpar efeitos':'Limpar efeitos',
  'Espelhar':'Espelhar {eixo}',
  'Piscar':'Piscar {vezes} vezes por {segundos} segundos',
  'Emissor de partículas':'Emissor de partículas {ligado} com taxa {taxa} e cor {cor}',
  'Tocar pasta':'Tocar {pasta} no modo {modo} a {fps} FPS e, ao terminar, {ao terminar}',
  'Próximo quadro':'Próximo quadro',
  'Definir quadro':'Definir quadro para {número}',
  'Definir velocidade da animação':'Definir velocidade da animação para {valor}',
  'Inverter ordem da pasta':'Inverter ordem da pasta {pasta}',
  'Tintar sprite':'Tintar sprite com {cor} em {intensidade} %',
  'Flash de hit':'Flash de impacto com {cor} por {frames} frames',
  'Sombra':'Sombra com cor {cor} X: {offsetX} Y: {offsetY} desfoque {blur}',
  'Rastro de movimento':'Rastro de movimento {ligado} com opacidade {opacidade} %',
  'Modo de mistura':'Definir modo de mistura para {modo}',

  // Dados / listas
  'Definir variável para':'Definir variável {variável} para {valor}',
  'Mudar variável em':'Alterar variável {variável} por {valor}',
  'Definir variável local para':'Definir variável local {variável} para {valor}',
  'Mudar variável local em':'Alterar variável local {variável} por {valor}',
  'Definir variável global para':'Definir variável global {variável} para {valor}',
  'Mudar variável global em':'Alterar variável global {variável} por {valor}',
  'Mostrar variável':'Mostrar variável {variável}',
  'Esconder variável':'Esconder variável {variável}',
  'Criar lista':'Criar lista {lista}',
  'Adicionar à lista':'Adicionar {item} à lista {lista}',
  'Apagar de lista':'Apagar item {índice} da lista {lista}',
  'Apagar tudo da lista':'Apagar todos os itens da lista {lista}',
  'Inserir em lista':'Inserir {item} na posição {índice} da lista {lista}',
  'Substituir item da lista':'Substituir item {índice} da lista {lista} por {item}',
  'Item da lista':'Item {índice} da lista {lista}',
  'Tamanho da lista':'Tamanho da lista {lista}',
  'Lista contém':'A lista {lista} contém {item}',
  'Mostrar lista':'Mostrar lista {lista}',
  'Esconder lista':'Esconder lista {lista}',

  // Som
  'Tocar som':'Iniciar som {som}',
  'Tocar som e esperar terminar':'Iniciar som {som} e esperar terminar',
  'Parar todos os sons':'Parar todos os sons',
  'Parar este som':'Parar este som',
  'Pausar som':'Pausar som',
  'Retomar som':'Retomar som',
  'Mudar volume em':'Alterar volume em {valor} %',
  'Definir volume para':'Definir volume para {valor} %',
  'Mudar tom (pitch) em':'Alterar tom em {valor}',
  'Definir tom para':'Definir tom para {valor}',
  'Definir loop do som':'Repetir som: {sim}',
  'Falar (texto para voz)':'Falar {texto}',
  'Falar e esperar':'Falar {texto} e esperar terminar',
  'Definir idioma da fala':'Definir idioma da fala para {idioma}',
  'Crossfade':'Fazer crossfade em {som} durante {segundos} segundos',
  'Definir canal':'Definir canal de áudio para {canal}',
  'Quando som terminar':'Quando o som terminar',
  'Pausar todos os sons':'Pausar todos os sons',
  'Retomar todos os sons':'Retomar todos os sons',
  'Tocar som com volume':'Iniciar som {som} com volume {volume}',
  'Fade out em':'Desaparecer gradualmente em {segundos} segundos',
  'Fade in em':'Aparecer gradualmente em {segundos} segundos',

  // Texto
  'Escrever texto em tempo real':'Escrever {variável} em X: {x} Y: {y}, tamanho {tamanho}, cor {cor}, fonte {fonte} e ângulo {graus}',
  'Perguntar ao usuário':'Perguntar {pergunta} e salvar em {variável}',
  'Esconder texto':'Esconder texto',
  'Mostrar texto':'Mostrar {texto}',
  'Criar texto facilitado':'Criar texto {id} com {texto}, tamanho {tamanho}, cor {cor}, sombra {sombra}, X: {x}, Y: {y} e fonte {fonte}',
  'Definir texto multilinha':'Definir texto para {texto}',
  'Definir fonte':'Definir fonte para {fonte}',
  'Definir tamanho da fonte':'Definir tamanho da fonte para {tamanho}',
  'Definir cor do texto':'Definir cor do texto para {cor}',
  'Definir negrito e itálico':'Definir negrito {negrito} e itálico {italico}',
  'Definir alinhamento':'Definir alinhamento para {alinhamento}',
  'Definir espaçamento entre linhas':'Definir espaçamento entre linhas para {espacamento}',
  'Definir contorno (stroke)':'Definir contorno {cor} com espessura {espessura}',
  'Definir sombra do texto':'Definir sombra com cor {cor} X: {deslocamento x} Y: {deslocamento y} desfoque {desfoque}',
  'Definir glow do texto':'Definir brilho {cor} com intensidade {intensidade}',
  'Definir gradiente do texto':'Definir gradiente de {cor inicio} para {cor fim} com ângulo {angulo}',
  'Efeito de digitação':'Mostrar texto {texto} com efeito de digitação a {velocidade}',
  'Quebra de linha automática':'Quebrar linhas automaticamente em {largura maxima}',
  'Rotacionar texto':'Rotacionar texto {graus} graus',
  'Definir opacidade do texto':'Definir opacidade do texto para {opacidade} %',
  'Interpolar texto (fade in/out)':'Animar texto de {de} para {para} em {duracao} segundos',
  'Definir texto rico (tags)':'Definir texto rico para {texto}',
  'Medir largura do texto':'Medir largura do texto',
  'Mostrar dado como texto':'Mostrar {variavel} como texto com prefixo {prefixo}',
  'Pulsar texto':'Pulsar texto de {escala minima} a {escala maxima} na velocidade {velocidade}',
  'Definir posicao X do texto':'Definir posição X do texto para {x}',
  'Definir posicao Y do texto':'Definir posição Y do texto para {y}',
  'Mudar X do texto em':'Alterar X do texto em {valor}',
  'Mudar Y do texto em':'Alterar Y do texto em {valor}',
  'Gradiente animado do texto':'Animar gradiente do texto de {cor inicio} para {cor fim} na direção {direcao} com velocidade {velocidade}',
  'Parar gradiente animado':'Parar gradiente animado',
  'Iniciar animacao de texto':'Iniciar animação de texto {tipo} com intensidade {intensidade} e velocidade {velocidade}',
  'Finalizar animacao de texto':'Parar animação de texto',
  'Animacao de texto em loop':'Repetir animação de texto {tipo} em loop, intensidade {intensidade} e velocidade {velocidade}',
  'Definir texto com aspas coloridas':'Definir texto {texto} com cor base {cor base} e cor das aspas {cor aspas}',
  'Texto estilizado rapido':'Criar texto estilizado {texto} com fonte {fonte}, tamanho {tamanho}, cor {cor}, contorno {contorno} e sombra {sombra}',
  'Texto HUD rapido':'Mostrar {variavel} no HUD com rótulo {rotulo} na posição {posicao}',
  'Titulo de nivel pronto':'Mostrar título do nível {texto}',
  'Texto de dano flutuante':'Mostrar dano flutuante {texto} na cor {cor} em X: {x} Y: {y}',
  'Caixa de dialogo com digitacao pronta':'Mostrar caixa de diálogo {texto} com velocidade {velocidade}',

  // Dispositivo
  'Forçar orientação da tela':'Definir orientação da tela para {orientação}',
  'Vibrar curto':'Vibrar brevemente',
  'Vibrar longo':'Vibrar por mais tempo',
  'Vibrar':'Vibrar por {ms} ms',
  'Vibrar por X segundos':'Vibrar por {segundos} segundos',
  'Padrão de vibração customizado':'Definir padrão de vibração para {padrão}',
  'Parar vibração':'Parar vibração',
  'Feedback tátil por evento':'Feedback tátil por evento',
  'Quando vibração terminar':'Quando a vibração terminar',
  'Compartilhar print da tela':'Compartilhar captura de tela',
  'Compartilhar pontuação':'Compartilhar pontuação {valor}',
  'Compartilhar vídeo curto':'Compartilhar vídeo curto',
  'Convidar amigo com link/código':'Convidar amigo com link ou código',
  'Quando compartilhar ok':'Quando o compartilhamento terminar',
  'Definir idioma do jogo':'Definir idioma do jogo para {idioma}',
  'Texto traduzido por chave':'Mostrar texto traduzido {chave}',
  'Detectar idioma do dispositivo':'Detectar idioma do dispositivo',
  'Trocar idioma em tempo real':'Trocar idioma do jogo em tempo real',
  'Quando idioma mudar':'Quando o idioma mudar',
  'Detectar pinça (pinch)':'Detectar gesto de pinça',
  'Arrastar com dois dedos':'Arrastar com dois dedos',
  'Swipe (direção)':'Detectar deslize',
  'Toque duplo':'Detectar toque duplo',
  'Pressionar e segurar':'Detectar toque prolongado',
  'Rotação por gesto':'Detectar rotação por gesto',
  'Quando swipe':'Quando ocorrer um deslize',
  'Quando pinça':'Quando ocorrer uma pinça',
  'Detectar toque duplo':'Detectar toque duplo',
  'Definir brilho da tela':'Definir brilho da tela para {valor}',
  'Tirar foto':'Tirar foto',
  'Ler valor do acelerômetro':'Ler acelerômetro',
  'Ler valor do giroscópio':'Ler giroscópio',
  'Ler valor da bússola':'Ler bússola',
  'Ler GPS':'Ler GPS',
  'Ler sensor de luz':'Ler sensor de luz',
  'Ler sensor de proximidade':'Ler sensor de proximidade',
  'Enviar notificação':'Enviar notificação {texto}',
  'Abrir outro aplicativo':'Abrir o aplicativo {app}',
  'Ler QR code':'Ler código QR',
  'Ler nível de bateria':'Ler nível da bateria',
  'Manter tela ligada':'Manter a tela ligada',
  'Mostrar toast':'Mostrar aviso {texto}',
  'Copiar texto':'Copiar texto {texto}',
  'Pedir permissão de sensores':'Pedir permissão para sensores',
  'Detectar se está online':'Detectar conexão com a internet',
  'Obter data/hora':'Obter data e hora em {formato}',
  'Gerar número aleatório':'Gerar número aleatório entre {min} e {max} e salvar em {variável}',
  'Pedir texto ao usuário':'Pedir {pergunta} e salvar em {variável}',
};

function kixCatroidLikeFallbackTemplate(name, params) {
  const n = String(name || '').trim();
  const ps = (Array.isArray(params) ? params : []).map(p => typeof p === 'string' ? p : String(p?.name || '')).filter(Boolean);
  // Exact rewrites for Kix-only/custom bricks where the original name was
  // implementation-oriented. They affect presentation only; runtime keys and
  // persisted names remain unchanged.
  const exact = {
    'Debounce por X ms':'Aguardar {ms} ms entre ativações',
    'Throttle a cada X ms':'Limitar a uma ativação a cada {ms} ms',
    'Tentar ... se erro':'Tentar e, se ocorrer um erro, mostrar {mensagem}',
    'Carimbar (stamp)':'Carimbar',
    'Shader personalizado (GLSL)':'Usar shader personalizado {código}',
    'Definir uniform do shader':'Definir parâmetro {nome} do shader para {valor}',
    'Definir uniform texto':'Definir parâmetro de texto {nome} para {valor}',
    'Misturar dois shaders':'Combinar os shaders {a} e {b}',
    'Exportar preview do shader':'Exportar pré-visualização do shader {nome}',
    'Obter valor do slider':'Ler valor do slider {id} e guardar em {variável}',
    'Indicador de dano recebido':'Mostrar indicador de dano {valor}',
    'placar 2 times':'Criar placar para os times {nomeA} e {nomeB}',
    'timer countdown':'Criar contagem regressiva de {segundos} segundos',
    'barra de vida no jogador':'Criar barra de vida do jogador com máximo {max}',
    'limpar toda a UI':'Limpar toda a interface',
    'câmera no jogador':'Seguir o jogador com a câmera {ator}',
    'reset completo da câmera':'Redefinir a câmera',
    'zoom de impacto':'Aplicar zoom de impacto de {valor} durante {segundos} segundos',
    'seguir com suavidade':'Seguir {ator} com suavidade {suavidade}',
    'bounds do palco':'Definir os limites do palco',
    'Transição fade in/out':'Fazer transição {modo} em {segundos} segundos',
    'Transição cortinas (wipe)':'Fazer transição de cortinas para {direção} em {segundos} segundos',
    'Transição deslizar (slide)':'Fazer transição deslizante para {direção} em {segundos} segundos',
    'Transição zoom':'Fazer transição de zoom {modo} em {segundos} segundos',
    'Preset de checkpoint':'Usar predefinição de checkpoint {id}',
    'Preset de objetivo da fase':'Usar predefinição de objetivo: {texto}',
    'Preset de tela de carregamento':'Usar predefinição de tela de carregamento: {texto}',
    'Preset de menu pausado':'Usar predefinição de menu de pausa: {título}',
    'Preset de tela de game over':'Usar predefinição de tela de fim de jogo: {título}',
    'Preset de tela de lobby':'Usar predefinição de tela de lobby: {título}',
    'Preset de busca de partida':'Usar predefinição de busca de partida: {texto}',
    'Preset de lista de jogadores na sala':'Usar predefinição de lista de jogadores: {id}',
    'Preset de botão pronto':'Usar predefinição de botão pronto {id}: {texto}',
    'Preset de contagem regressiva de início':'Usar predefinição de contagem regressiva de início: {segundos} segundos',
    'Preset de tela de resultado da partida':'Usar predefinição de resultado da partida: {título}',
    'Preset de convite de amigo':'Usar predefinição de convite de amigo {id}: {texto}',
    'Preset de chat rápido':'Usar predefinição de chat rápido {id}',
    'Preset de indicador de host':'Usar predefinição de indicador de host {id}: {nome}',
    'Objeto sólido':'Criar objeto sólido com largura {largura} e altura {altura}',
    'Parede':'Criar parede na direção {direção} com força {força}',
    'Plataforma':'Criar plataforma com altura {altura} e atrito {atrito}',
    'Coletável':'Criar coletável com valor {valor} e guardar em {variável}',
    'Dano por contato':'Aplicar {dano} de dano por contato a cada {intervalo}',
    'Empurrão':'Aplicar empurrão com força {força} na direção {direção}',
    'Sensor':'Criar sensor e guardar em {variável}',
    'Projétil':'Criar projétil com dano {dano} e velocidade {velocidade}',
    'Plataforma móvel':'Criar plataforma móvel por {distância} com velocidade {velocidade}',
    'Zona de teleporte':'Criar zona de teleporte para {cena} em X: {x} Y: {y}',
    'Status Firebase':'Obter status do Firebase',
    'Salvar dados no Firebase':'Salvar {dados} no Firebase',
    'Ler dados do Firebase':'Ler dados do Firebase em {caminho}',
    'Atualizar dados do Firebase':'Atualizar {caminho} no Firebase com {dados}',
    'Excluir dados do Firebase':'Excluir dados do Firebase em {caminho}',
    'Ler último evento multiplayer':'Ler o último evento do multiplayer',
    'Status WebSocket':'Obter status do WebSocket',
    'Ler última mensagem WebSocket':'Ler a última mensagem do WebSocket',
    'Animar propriedade':'Animar {prop} de {de} para {para} em {duração} segundos',
    'Log de texto':'Registrar {texto}',
    'Assertar condição':'Verificar se {condição} é verdadeira',
    'Reiniciar cronômetro':'Reiniciar cronômetro',
    'Ler cronômetro':'Ler cronômetro',
    'Iniciar timer':'Iniciar cronômetro de {segundos} segundos',
    'Adicionar moedas':'Adicionar {valor} moedas',
    'Gastar moedas':'Gastar {valor} moedas',
    'Definir preço':'Definir preço de {item} para {valor}',
    'Carregar nível':'Carregar nível {nível}',
    'Shake de câmera':'Balançar a câmera com intensidade {intensidade}',
    'Câmera livre':'Liberar a câmera',
    'Detectar plano AR':'Detectar plano com AR',
    'Colocar objeto no AR':'Colocar objeto no ambiente AR',
    'Spritesheet':'Usar spritesheet {imagem} com {colunas} colunas, {linhas} linhas e {fps} FPS no modo {modo}',
    'Animar spritesheet':'Animar spritesheet',
    'Definir quadro do spritesheet':'Definir quadro do spritesheet para {número}',
    'Spritesheet da pasta':'Animar spritesheet da pasta {pasta} a {fps} FPS',
    'Spritesheet da pasta em grade':'Animar spritesheet da pasta {pasta} com {colunas} colunas, {linhas} linhas e {fps} FPS',
    'Carregar tilemap':'Carregar tilemap {nome}',
    'Quando colidir com tile':'Quando colidir com um tile',
    'Definir tile':'Definir tile em X: {x} Y: {y} para {id}',
    'Ler tile em':'Ler tile em X: {x} Y: {y}'
  };
  let out = exact[n] || n;
  // NPC-specific phrases keep the subject and parameters in a natural order.
  const npc = {
    'NPC perseguir alvo':'Fazer o NPC {id} perseguir {alvo} com velocidade {velocidade}',
    'NPC fugir do alvo':'Fazer o NPC {id} fugir de {alvo} com velocidade {velocidade}',
    'NPC patrulhar rota':'Fazer o NPC {id} patrulhar {rota} com velocidade {velocidade}',
    'NPC seguir caminho':'Fazer o NPC {id} seguir {destino} com velocidade {velocidade}',
    'NPC lembrar alvo':'Fazer o NPC {id} lembrar {alvo}',
    'NPC esquecer alvo':'Fazer o NPC {id} esquecer {alvo}',
    'NPC tomar decisão':'Fazer o NPC {id} tomar uma decisão',
    'NPC escolher alvo mais próximo':'Fazer o NPC {id} escolher o alvo mais próximo',
    'NPC escolher caminho':'Fazer o NPC {id} escolher um caminho até {destino}',
    'NPC parar':'Fazer o NPC {id} parar',
    'NPC atacar alvo':'Fazer o NPC {id} atacar {alvo}',
    'NPC defender':'Fazer o NPC {id} defender',
    'NPC esquivar':'Fazer o NPC {id} esquivar',
    'NPC chamar aliados':'Fazer o NPC {id} chamar aliados a até {distância}',
    'NPC evitar obstáculo':'Fazer o NPC {id} evitar obstáculos a até {distância}',
    'NPC conversar':'Fazer o NPC {id} dizer {texto}',
    'NPC emitir som':'Fazer o NPC {id} reproduzir {som}',
    'NPC usar habilidade':'Fazer o NPC {id} usar {habilidade}',
    'NPC usar item':'Fazer o NPC {id} usar {item}',
    'NPC trocar estado automaticamente':'Fazer o NPC {id} trocar de estado automaticamente',
    'NPC copiar configuração':'Copiar a configuração de {origem} para o NPC {id}',
    'NPC definir variável':'Definir a variável {nome} do NPC {id} para {valor}',
    'Desenhar linha':'Desenhar uma linha de {x1}, {y1} até {x2}, {y2}',
    'Desenhar círculo':'Desenhar um círculo com raio {raio}',
    'Desenhar retângulo':'Desenhar um retângulo de largura {largura} e altura {altura}',
    'Desenhar polígono':'Desenhar um polígono com pontos {pontos}',
    'Preencher forma com cor':'Preencher a forma com {cor}',
    'Definir espessura do traço':'Definir espessura do traço para {valor}',
    'Limpar desenho':'Limpar o desenho',
    'Desenhar texto vetorial':'Desenhar o texto {texto}',
    'Abaixar caneta':'Abaixar a caneta',
    'Levantar caneta':'Levantar a caneta',
    'Definir cor da caneta':'Definir a cor da caneta para {cor}',
    'Definir tamanho da caneta':'Definir o tamanho da caneta para {tamanho}',
    'Limpar tudo':'Limpar tudo',
    'Definir opacidade da caneta':'Definir a opacidade da caneta para {valor}',
    'Perguntar à IA':'Perguntar à IA {prompt}',
    'Quando IA responder':'Quando a IA responder',
    'Definir modelo de IA':'Definir o modelo de IA para {modelo}',
    'Definir chave de API':'Definir a chave da API para {chave}',
    'Cancelar pedido de IA':'Cancelar o pedido à IA',
    'Definir posição da UI':'Definir posição da interface em X: {x} e Y: {y}',
    'Criar texto na UI':'Criar texto da interface {texto}',
    'Criar botão':'Criar botão com texto {texto}',
    'Criar slider':'Criar controle deslizante',
    'Renderizar sprite otimizado':'Renderizar sprite otimizado',
    'Ativar modo de desenho em lote':'Ativar desenho em lote',
    'Definir qualidade de renderização':'Definir qualidade de renderização para {qualidade}',
    'Pré-carregar textura':'Pré-carregar textura',
    'Liberar textura da memória':'Liberar textura da memória',
    'Definir taxa de quadros alvo (FPS)':'Definir taxa de quadros para {fps} FPS',
    'Criar killfeed':'Criar feed de eliminações {id}',
    'Adicionar entrada ao killfeed':'Adicionar {texto} ao feed de eliminações',
    'Criar timer de partida':'Criar cronômetro da partida por {segundos} segundos',
    'Criar placar por time':'Criar placar para os times {timeA} e {timeB}',
    'Atualizar placar':'Atualizar placar do time {time} para {pontos}',
    'Definir posição do HUD':'Definir posição do HUD em X: {x} e Y: {y}',
    'Criar minimapa':'Criar minimapa',
    'Atualizar ponto no minimapa':'Atualizar o ponto {id} no minimapa em X: {x} e Y: {y}',
    'Criar diálogo':'Criar diálogo {id}: {texto}',
    'Fechar diálogo':'Fechar diálogo {id}',
    'Criar menu de pausa':'Criar menu de pausa',
    'Mostrar menu de pausa':'Mostrar menu de pausa',
    'Esconder menu de pausa':'Esconder menu de pausa',
    'Criar contador':'Criar contador {id} com valor {valor}',
    'Atualizar contador':'Atualizar contador {id} para {valor}',
    'Criar ícone de status':'Criar ícone de status {id}: {ícone}',
    'Criar cooldown radial':'Criar contagem radial {id} de {segundos} segundos',
    'Criar crosshair':'Criar mira {id}',
    'Mostrar tooltip':'Mostrar dica {texto}',
    'Criar notificação toast UI':'Mostrar aviso {texto}',
    'Definir estilo do HUD':'Definir estilo do HUD para {tema}',
    'Quando slider mudar':'Quando o controle deslizante {id} mudar',
    'Definir tamanho da UI':'Definir tamanho da interface {id} para {largura} × {altura}',
    'Animar UI':'Animar elemento da interface {id} com {tipo}',
    'Criar lista de inventário':'Criar inventário com {slots} espaços',
    'Definir item do inventário':'Definir o item {nome} no espaço {slot} do inventário',
    'Criar barra de XP':'Criar barra de experiência {id} com máximo {max}',
    'Atualizar barra de XP':'Atualizar barra de experiência {id} para {valor}',
    'Criar radar':'Criar radar com alcance {alcance}',
    'Marcar no radar':'Marcar {id} no radar em X: {x} e Y: {y}',
    'HUD de combate completo':'Mostrar HUD de combate completo',
    'placar 2 times':'Criar placar para os times {nomeA} e {nomeB}',
    'timer countdown':'Criar contagem regressiva de {segundos} segundos',
    'barra de vida no jogador':'Criar barra de vida do jogador com máximo {max}',
    'limpar toda a UI':'Limpar toda a interface',
    'Definir alvo da câmera':'Definir alvo da câmera {id} para {ator}',
    'Definir zoom da câmera':'Definir zoom da câmera para {valor}',
    'Câmera com suavização':'Definir suavidade da câmera para {valor}',
    'Câmera com paralaxe':'Definir paralaxe da câmera para {fator}',
    'Definir posição da câmera':'Definir posição da câmera em X: {x} e Y: {y}',
    'Mudar posição da câmera em':'Alterar posição da câmera em X: {x} e Y: {y}',
    'Deslizar câmera até':'Deslizar a câmera até X: {x} Y: {y} em {segundos} segundos',
    'Zoom suave até':'Fazer zoom suavemente até {valor} em {segundos} segundos',
    'Centralizar no ator':'Centralizar a câmera em {ator}',
    'Definir offset da câmera':'Definir deslocamento da câmera X: {x} Y: {y}',
    'Rotacionar câmera':'Rotacionar a câmera para {graus} graus',
    'Definir suavidade do follow':'Definir suavidade do acompanhamento para {valor}',
    'Definir deadzone do follow':'Definir zona morta do acompanhamento para {valor}',
    'Travar eixo da câmera':'Travar o eixo {eixo} da câmera',
    'Parar shake da câmera':'Parar a vibração da câmera',
    'Empurrar câmera':'Deslocar a câmera {distância} na direção {direção}',
    'Zoom no toque':'Fazer zoom no toque até {valor}',
    'Look-ahead da câmera':'Antecipar o movimento da câmera em {valor}',
    'Obter posição X da câmera':'Obter posição X da câmera',
    'Obter posição Y da câmera':'Obter posição Y da câmera',
    'Obter zoom da câmera':'Obter zoom da câmera',
    'Mostrar camada':'Mostrar camada {nome}',
    'Esconder camada':'Esconder camada {nome}',
    'Quando camada mudar':'Quando a camada mudar',
    'Mover para camada':'Mover para a camada {nome}',
    'Spritesheet':'Usar spritesheet {imagem}: {colunas} colunas × {linhas} linhas, {fps} FPS, modo {modo}',
    'Animar spritesheet':'Animar spritesheet',
    'Parar spritesheet':'Parar spritesheet',
    'Definir quadro do spritesheet':'Definir quadro do spritesheet para {número}',
    'Spritesheet da pasta':'Animar spritesheet da pasta {pasta} a {fps} FPS',
    'Spritesheet da pasta em grade':'Animar spritesheet da pasta {pasta}: {colunas} colunas × {linhas} linhas, {fps} FPS',
    'Carregar tilemap':'Carregar tilemap {nome}',
    'Quando colidir com tile':'Quando colidir com um tile',
    'Definir tile':'Definir tile em X: {x} Y: {y} para {id}',
    'Ler tile em':'Ler tile em X: {x} Y: {y}'
  };
  if (npc[n]) out = npc[n];
  // Remove implementation-only notation while keeping meaningful parentheses.
  out = out.replace(/\s*\((?:pitch|stamp|stroke|tags|GLSL|pinch|analógico|ping\/status|wipe|slide)\)\s*/ig, ' ')
           .replace(/\s*\[Fórmula\]\s*/ig, ' ')
           .replace(/_+/g, ' ')
           .replace(/\s+/g, ' ')
           .trim();
  out = out.replace(/^Mudar\b/i, 'Alterar')
           .replace(/^Ativar Colisão Trigger\b/i, 'Ativar colisão')
           .replace(/^Camadas de Colisão\b/i, 'Camada de colisão')
           .replace(/^Sensor de Colisão Contínua\b/i, 'Detecção contínua de colisão')
           .replace(/^Path de Física\b/i, 'Caminho de física')
           .replace(/^limpar toda a UI\b/i, 'Limpar toda a interface');
  // X/Y are written with the Catroid-style colon only when those parameters exist.
  if (ps.includes('x') && !/\{x\}/i.test(out)) out = out.replace(/\bX\b/g, 'X: {x}');
  if (ps.includes('y') && !/\{y\}/i.test(out)) out = out.replace(/\bY\b/g, 'Y: {y}');
  out = out.charAt(0).toUpperCase() + out.slice(1);
  return kixEnsureBlockTemplateParams(out, ps);
}

const KIX_BLOCK_I18N = {
  'pt-BR': {
    'Quando a cena começar':'Quando a cena começar','Quando tocado':'Quando tocado','Quando a tela for pressionada':'Quando a tela for pressionada','Quando receber mensagem':'Quando receber {mensagem}',
    'Enviar mensagem':'Enviar {mensagem}','Enviar mensagem e esperar':'Enviar {mensagem} e esperar','Esperar X segundos':'Esperar {segundos}s','Sempre':'Sempre','Repita X vezes':'Repetir {vezes}×',
    'Repita até':'Repetir até {condição}','Repita enquanto':'Repetir enquanto {condição}','Se ... então':'Se {condição}','Se ... então ... senão':'Se {condição}; senão',
    'Mostrar':'Mostrar','Esconder':'Esconder','Parar este script':'Parar script','Parar todos os scripts':'Parar tudo','Sair do loop':'Sair do loop',
    'Continuar próxima iteração':'Próxima iteração','Próxima cena':'Próxima cena','Cena anterior':'Cena anterior','Reiniciar cena atual':'Reiniciar cena',
    'Mover X passos':'Mover {passos} passos','Girar direita X graus':'Girar {graus}° →','Girar esquerda X graus':'Girar {graus}° ←','Ir para X e Y':'Ir para X {x} Y {y}',
    'Mudar X em':'X + {valor}','Definir X para':'X = {valor}','Mudar Y em':'Y + {valor}','Definir Y para':'Y = {valor}',
    'Se estiver na borda, volte':'Se na borda, voltar','Definir direção para':'Direção = {graus}°','Mudar direção em':'Direção + {graus}°',
    'Mudar para fantasia/costume':'Mudar para {costume}','Mudar tamanho em':'Tamanho + {valor}%','Definir tamanho para':'Tamanho = {valor}%',
    'Definir transparência para':'Transparência = {valor}%','Definir aparência para número':'Aparência {número}','Definir aparência para nome':'Aparência {nome}',
    'Dizer':'Mostrar “{texto}” por {segundos}s','Definir variável para':'{variável} = {valor}','Mudar variável em':'{variável} += {valor}',
    'Mostrar variável':'Mostrar {variável}','Esconder variável':'Esconder {variável}','Criar lista':'Criar lista {lista}','Adicionar à lista':'Adicionar {item} → {lista}',
    'Tocar som':'Tocar {som}','Tocar som e esperar terminar':'Tocar {som} e esperar','Mudar volume em':'Volume + {valor}%','Definir volume para':'Volume = {valor}%',
    'Mostrar texto':'Mostrar {texto}','Definir fonte':'Fonte = {fonte}','Definir tamanho da fonte':'Fonte = {tamanho}','Definir cor do texto':'Cor = {cor}',
    'Definir alinhamento':'Alinhar {alinhamento}','Rotacionar texto':'Texto {graus}°','Definir opacidade':'Opacidade = {valor}%','Mudar opacidade em':'Opacidade + {valor}%'
  },
  'en': {
    'Quando a cena começar':'When scene starts','Quando tocado':'When tapped','Quando a tela for pressionada':'When stage tapped','Quando receber mensagem':'When receive {mensagem}',
    'Enviar mensagem':'Broadcast {mensagem}','Enviar mensagem e esperar':'Broadcast {mensagem} and wait','Esperar X segundos':'Wait {segundos}s','Sempre':'Forever','Repita X vezes':'Repeat {vezes}×',
    'Repita até':'Repeat until {condição}','Repita enquanto':'Repeat while {condição}','Se ... então':'If {condição}','Se ... então ... senão':'If {condição}; else',
    'Mostrar':'Show','Esconder':'Hide','Parar este script':'Stop script','Parar todos os scripts':'Stop all','Sair do loop':'Exit loop','Continuar próxima iteração':'Next iteration',
    'Próxima cena':'Next scene','Cena anterior':'Previous scene','Reiniciar cena atual':'Restart scene','Mover X passos':'Move {passos} steps','Girar direita X graus':'Turn {graus}° →','Girar esquerda X graus':'Turn {graus}° ←',
    'Ir para X e Y':'Go to X {x} Y {y}','Mudar X em':'X + {valor}','Definir X para':'X = {valor}','Mudar Y em':'Y + {valor}','Definir Y para':'Y = {valor}',
    'Se estiver na borda, volte':'If on edge, bounce','Definir direção para':'Direction = {graus}°','Mudar direção em':'Direction + {graus}°',
    'Mudar para fantasia/costume':'Switch to {costume}','Mudar tamanho em':'Size + {valor}%','Definir tamanho para':'Size = {valor}%',
    'Definir transparência para':'Transparency = {valor}%','Definir aparência para número':'Look {número}','Definir aparência para nome':'Look {nome}',
    'Dizer':'Say “{texto}” for {segundos}s','Definir variável para':'{variável} = {valor}','Mudar variável em':'{variável} += {valor}',
    'Mostrar variável':'Show {variável}','Esconder variável':'Hide {variável}','Criar lista':'Create list {lista}','Adicionar à lista':'Add {item} → {lista}',
    'Tocar som':'Play {som}','Tocar som e esperar terminar':'Play {som} and wait','Mudar volume em':'Volume + {valor}%','Definir volume para':'Volume = {valor}%',
    'Mostrar texto':'Show {texto}','Definir fonte':'Font = {fonte}','Definir tamanho da fonte':'Font = {tamanho}','Definir cor do texto':'Text color = {cor}',
    'Definir alinhamento':'Align {alinhamento}','Rotacionar texto':'Text {graus}°','Definir opacidade':'Opacity = {valor}%','Mudar opacidade em':'Opacity + {valor}%'
  },
  'es': {
    'Quando a cena começar':'Al comenzar la escena','Quando tocado':'Al tocar','Quando a tela for pressionada':'Al tocar el escenario','Quando receber mensagem':'Al recibir {mensagem}',
    'Enviar mensagem':'Enviar {mensagem}','Enviar mensagem e esperar':'Enviar {mensagem} y esperar','Esperar X segundos':'Esperar {segundos}s','Sempre':'Por siempre','Repita X vezes':'Repetir {vezes}×',
    'Repita até':'Repetir hasta {condição}','Repita enquanto':'Repetir mientras {condição}','Se ... então':'Si {condição}','Se ... então ... senão':'Si {condição}; si no',
    'Mostrar':'Mostrar','Esconder':'Ocultar','Parar este script':'Detener script','Parar todos os scripts':'Detener todo','Sair do loop':'Salir del bucle','Continuar próxima iteração':'Siguiente iteración',
    'Próxima cena':'Siguiente escena','Cena anterior':'Escena anterior','Reiniciar cena atual':'Reiniciar escena','Mover X passos':'Mover {passos} pasos','Girar direita X graus':'Girar {graus}° →','Girar esquerda X graus':'Girar {graus}° ←',
    'Ir para X e Y':'Ir a X {x} Y {y}','Mudar X em':'X + {valor}','Definir X para':'X = {valor}','Mudar Y em':'Y + {valor}','Definir Y para':'Y = {valor}',
    'Se estiver na borda, volte':'Si toca el borde, rebotar','Definir direção para':'Dirección = {graus}°','Mudar direção em':'Dirección + {graus}°',
    'Mudar para fantasia/costume':'Cambiar a {costume}','Mudar tamanho em':'Tamaño + {valor}%','Definir tamanho para':'Tamaño = {valor}%',
    'Definir transparência para':'Transparencia = {valor}%','Definir aparência para número':'Apariencia {número}','Definir aparência para nome':'Apariencia {nome}',
    'Dizer':'Mostrar “{texto}” {segundos}s','Definir variável para':'{variável} = {valor}','Mudar variável em':'{variável} += {valor}',
    'Mostrar variável':'Mostrar {variável}','Esconder variável':'Ocultar {variável}','Criar lista':'Crear lista {lista}','Adicionar à lista':'Añadir {item} → {lista}',
    'Tocar som':'Reproducir {som}','Tocar som e esperar terminar':'Reproducir {som} y esperar','Mudar volume em':'Volumen + {valor}%','Definir volume para':'Volumen = {valor}%',
    'Mostrar texto':'Mostrar {texto}','Definir fonte':'Fuente = {fonte}','Definir tamanho da fonte':'Fuente = {tamanho}','Definir cor do texto':'Color = {cor}',
    'Definir alinhamento':'Alinear {alinhamento}','Rotacionar texto':'Texto {graus}°','Definir opacidade':'Opacidad = {valor}%','Mudar opacidade em':'Opacidad + {valor}%'
  },
  'ru': {
    'Quando a cena começar':'Когда начинается сцена','Quando tocado':'При касании','Quando a tela for pressionada':'При нажатии на сцену','Quando receber mensagem':'Когда получено {mensagem}',
    'Enviar mensagem':'Отправить {mensagem}','Enviar mensagem e esperar':'Отправить {mensagem} и ждать','Esperar X segundos':'Ждать {segundos} с','Sempre':'Всегда','Repita X vezes':'Повторить {vezes}×',
    'Repita até':'Повторять до {condição}','Repita enquanto':'Повторять пока {condição}','Se ... então':'Если {condição}','Se ... então ... senão':'Если {condição}; иначе',
    'Mostrar':'Показать','Esconder':'Скрыть','Parar este script':'Остановить скрипт','Parar todos os scripts':'Остановить всё','Sair do loop':'Выйти из цикла','Continuar próxima iteração':'Следующая итерация',
    'Próxima cena':'Следующая сцена','Cena anterior':'Предыдущая сцена','Reiniciar cena atual':'Перезапустить сцену','Mover X passos':'Двигаться {passos} шагов','Girar direita X graus':'Поворот {graus}° →','Girar esquerda X graus':'Поворот {graus}° ←',
    'Ir para X e Y':'Перейти X {x} Y {y}','Mudar X em':'X + {valor}','Definir X para':'X = {valor}','Mudar Y em':'Y + {valor}','Definir Y para':'Y = {valor}',
    'Se estiver na borda, volte':'У края — отскок','Definir direção para':'Направление = {graus}°','Mudar direção em':'Направление + {graus}°',
    'Mudar para fantasia/costume':'Сменить на {costume}','Mudar tamanho em':'Размер + {valor}%','Definir tamanho para':'Размер = {valor}%',
    'Definir transparência para':'Прозрачность = {valor}%','Definir aparência para número':'Образ {número}','Definir aparência para nome':'Образ {nome}',
    'Dizer':'Показать «{texto}» {segundos} с','Definir variável para':'{variável} = {valor}','Mudar variável em':'{variável} += {valor}',
    'Mostrar variável':'Показать {variável}','Esconder variável':'Скрыть {variável}','Criar lista':'Создать список {lista}','Adicionar à lista':'Добавить {item} → {lista}',
    'Tocar som':'Воспроизвести {som}','Tocar som e esperar terminar':'Воспроизвести {som} и ждать','Mudar volume em':'Громкость + {valor}%','Definir volume para':'Громкость = {valor}%',
    'Mostrar texto':'Показать {texto}','Definir fonte':'Шрифт = {fonte}','Definir tamanho da fonte':'Размер шрифта = {tamanho}','Definir cor do texto':'Цвет текста = {cor}',
    'Definir alinhamento':'Выравнивание: {alinhamento}','Rotacionar texto':'Текст {graus}°','Definir opacidade':'Непрозрачность = {valor}%','Mudar opacidade em':'Непрозрачность + {valor}%'
  }
};

const KIX_BLOCK_EXTRA_I18N = {
  'pt-BR': {
    'Continue scene':'Continuar cena','Finish stage':'Finalizar palco','Wait until all other scripts have stopped':'Esperar até que todos os outros scripts terminem','Otimizar Mundo Físico':'Otimizar mundo físico','Vibrar longo':'Vibrar por mais tempo','Tirar foto':'Tirar foto','Ler GPS':'Ler GPS','Ler QR code':'Ler código QR','Combinar shaders':'Combinar shaders','Pré-visualizar shader':'Pré-visualizar shader','Renderizar sprite otimizado':'Renderizar sprite otimizado','Ler cronômetro':'Ler cronômetro','Animar spritesheet':'Animar spritesheet','Path de Física':'Caminho de física','Feedback tátil por evento':'Feedback tátil por evento','Cancelar pedido de IA':'Cancelar pedido de IA','HUD de combate completo':'HUD de combate completo','Ler último evento multiplayer':'Ler último evento multiplayer','When background changes to':'Quando o fundo mudar para {background}','When(…) becomes true':'Quando {condition} ficar verdadeiro','Create clone of':'Criar clone de {object}','Start scene':'Iniciar cena {scene}','For each value from .. in ..':'Para cada {value} de {source}','For values from 1 to 10 in':'Para valores de {from} a {to} em {value}','Go back … layer':'Voltar {layers} camada(s)','Set velocity to':'Definir velocidade X {x} Y {y}','Set your motion type to …':'Definir tipo de movimento {type}','Spin left … degrees/second':'Girar à esquerda {degreesPerSecond} graus/segundo','Spin right … degrees/second':'Girar à direita {degreesPerSecond} graus/segundo','When you bounce off …':'Quando quicar em {object}','Set friction to …%':'Definir atrito em {percent}%','Set gravity for all actors and objects to …':'Definir gravidade para todos em {gravity}','Set mass to … kilogram':'Definir massa {kilogram} kg','Write variable … to file …':'Gravar {variable} no arquivo {file}','Read variable … from file … AND …':'Ler {variable} do arquivo {file} e {and}','Read list from device …':'Ler lista do dispositivo {list}','Send web request to … and store answer in …':'Enviar requisição web para {url} e guardar em {variable}','Show variable … at X: … Y: …':'Mostrar {variable} em X {x} Y {y}','Show variable … at X: … Y: … size: … colour: … aligned …':'Mostrar {variable} em X {x} Y {y}, tamanho {size}, cor {color}, alinhamento {aligned}','Store column … of the comma-separated values …':'Armazenar coluna {column} dos valores CSV {csv}','Write list on device …':'Gravar lista no dispositivo {list}','Set pen colour to red … green … blue':'Definir cor da caneta R {red} G {green} B {blue}','Play drum … for … beats':'Tocar bateria {drum} por {beats} tempos','Play note … for … beats':'Tocar nota {note} por {beats} tempos','Set instrument to':'Definir instrumento {instrument}','Change tempo by …':'Mudar andamento em {bpm}','Pause for … beats':'Pausar por {beats} tempos','Set tempo to …':'Definir andamento para {bpm}'
  },
  'en': {
    'Continue scene':'Continue scene','Finish stage':'Finish stage','Wait until all other scripts have stopped':'Wait until all other scripts have stopped','Otimizar Mundo Físico':'Optimize physics world','Vibrar longo':'Vibrate long','Tirar foto':'Take photo','Ler GPS':'Read GPS','Ler QR code':'Read QR code','Combinar shaders':'Combine shaders','Pré-visualizar shader':'Preview shader','Renderizar sprite otimizado':'Render optimized sprite','Ler cronômetro':'Read timer','Animar spritesheet':'Animate spritesheet','Path de Física':'Physics path','Feedback tátil por evento':'Haptic feedback by event','Cancelar pedido de IA':'Cancel AI request','HUD de combate completo':'Full combat HUD','Ler último evento multiplayer':'Read last multiplayer event'
  },
  'es': {
    'Continue scene':'Continuar escena','Finish stage':'Finalizar escenario','Wait until all other scripts have stopped':'Esperar hasta que todos los demás scripts se detengan','Otimizar Mundo Físico':'Optimizar mundo físico','Vibrar longo':'Vibrar largo','Tirar foto':'Tomar foto','Ler GPS':'Leer GPS','Ler QR code':'Leer código QR','Combinar shaders':'Combinar shaders','Pré-visualizar shader':'Previsualizar shader','Renderizar sprite otimizado':'Renderizar sprite optimizado','Ler cronômetro':'Leer cronómetro','Animar spritesheet':'Animar spritesheet','Path de Física':'Ruta de física','Mostrar':'Mostrar','Feedback tátil por evento':'Vibración háptica por evento','Cancelar pedido de IA':'Cancelar solicitud de IA','HUD de combate completo':'HUD de combate completo','Ler último evento multiplayer':'Leer último evento multijugador','When background changes to':'Al cambiar el fondo a {background}','When(…) becomes true':'Cuando {condition} sea verdadera','Create clone of':'Crear clon de {object}','Start scene':'Iniciar escena {scene}','For each value from .. in ..':'Para cada {value} de {source}','For values from 1 to 10 in':'Para valores de {from} a {to} en {value}','Go back … layer':'Retroceder {layers} capa(s)','Set velocity to':'Establecer velocidad X {x} Y {y}','Set your motion type to …':'Establecer tipo de movimiento {type}','Spin left … degrees/second':'Girar a la izquierda {degreesPerSecond} grados/segundo','Spin right … degrees/second':'Girar a la derecha {degreesPerSecond} grados/segundo','When you bounce off …':'Al rebotar contra {object}','Set friction to …%':'Establecer fricción en {percent}%','Set gravity for all actors and objects to …':'Establecer gravedad para todos en {gravity}','Set mass to … kilogram':'Establecer masa {kilogram} kg','Write variable … to file …':'Escribir {variable} en el archivo {file}','Read variable … from file … AND …':'Leer {variable} del archivo {file} y {and}','Read list from device …':'Leer lista del dispositivo {list}','Send web request to … and store answer in …':'Enviar solicitud web a {url} y guardar en {variable}','Show variable … at X: … Y: …':'Mostrar {variable} en X {x} Y {y}','Show variable … at X: … Y: … size: … colour: … aligned …':'Mostrar {variable} en X {x} Y {y}, tamaño {size}, color {color}, alineado {aligned}','Store column … of the comma-separated values …':'Guardar columna {column} de los valores CSV {csv}','Write list on device …':'Escribir lista en el dispositivo {list}','Set pen colour to red … green … blue':'Establecer color de lápiz R {red} G {green} B {blue}','Play drum … for … beats':'Reproducir tambor {drum} durante {beats} tiempos','Play note … for … beats':'Reproducir nota {note} durante {beats} tiempos','Set instrument to':'Establecer instrumento {instrument}','Change tempo by …':'Cambiar tempo en {bpm}','Pause for … beats':'Pausar durante {beats} tiempos','Set tempo to …':'Establecer tempo a {bpm}'
  },
  'ru': {
    'Continue scene':'Продолжить сцену','Finish stage':'Завершить сцену','Wait until all other scripts have stopped':'Ждать, пока все остальные скрипты не остановятся','Otimizar Mundo Físico':'Оптимизировать физический мир','Vibrar longo':'Длинная вибрация','Tirar foto':'Сделать фото','Ler GPS':'Читать GPS','Ler QR code':'Читать QR-код','Combinar shaders':'Объединить шейдеры','Pré-visualizar shader':'Предпросмотр шейдера','Renderizar sprite otimizado':'Оптимизированный рендер спрайта','Ler cronômetro':'Читать таймер','Animar spritesheet':'Анимировать спрайт-лист','Path de Física':'Физический путь','Feedback tátil por evento':'Тактильная обратная связь по событию','Cancelar pedido de IA':'Отменить запрос ИИ','Ler último evento multiplayer':'Читать последнее событие мультиплеера','When background changes to':'При изменении фона на {background}','When(…) becomes true':'Когда {condition} становится истинным','Create clone of':'Создать клон {object}','Start scene':'Запустить сцену {scene}','For each value from .. in ..':'Для каждого {value} из {source}','For values from 1 to 10 in':'Для значений от {from} до {to} в {value}','Go back … layer':'Назад на {layers} слой(ев)','Set velocity to':'Скорость X {x} Y {y}','Set your motion type to …':'Тип движения: {type}','Spin left … degrees/second':'Поворот влево {degreesPerSecond} град./с','Spin right … degrees/second':'Поворот вправо {degreesPerSecond} град./с','When you bounce off …':'При отскоке от {object}','Set friction to …%':'Трение {percent}%','Set gravity for all actors and objects to …':'Гравитация для всех: {gravity}','Set mass to … kilogram':'Масса {kilogram} кг','Write variable … to file …':'Записать {variable} в файл {file}','Read variable … from file … AND …':'Прочитать {variable} из файла {file} и {and}','Read list from device …':'Прочитать список с устройства {list}','Send web request to … and store answer in …':'Отправить запрос на {url} и сохранить в {variable}','Show variable … at X: … Y: …':'Показать {variable} в X {x} Y {y}','Show variable … at X: … Y: … size: … colour: … aligned …':'Показать {variable}: X {x} Y {y}, размер {size}, цвет {color}, выравнивание {aligned}','Store column … of the comma-separated values …':'Сохранить столбец {column} из CSV {csv}','Write list on device …':'Записать список на устройстве {list}','Set pen colour to red … green … blue':'Цвет пера R {red} G {green} B {blue}','Play drum … for … beats':'Барабан {drum}, {beats} тактов','Play note … for … beats':'Нота {note}, {beats} тактов','Set instrument to':'Инструмент {instrument}','Change tempo by …':'Изменить темп на {bpm}','Pause for … beats':'Пауза {beats} тактов','Set tempo to …':'Установить темп {bpm}'
  }
};

const KIX_BLOCK_MANUAL_I18N = {
  "Quando cronômetro >": {
    "en": "when the timer passes",
    "es": "cuando el temporizador supere",
    "ru": "когда таймер превысит"
  },
  "Throttle a cada X ms": {
    "en": "limit to 1 execution every",
    "es": "limitar a 1 ejecución cada",
    "ru": "ограничить до 1 запуска каждые"
  },
  "Executar após frames": {
    "en": "run after",
    "es": "ejecutar después de",
    "ru": "выполнить после"
  },
  "Se está tocando": {
    "en": "if playing",
    "es": "si se está reproduciendo",
    "ru": "если воспроизводится"
  },
  "Mover em círculo": {
    "en": "move in a circle with",
    "es": "mover en círculo con",
    "ru": "двигаться по кругу с"
  },
  "Raycast": {
    "en": "raycast from X and Y at",
    "es": "raycast desde X e Y con",
    "ru": "лучевой тест из X и Y под углом"
  },
  "Configurar física de veículo": {
    "en": "configure vehicle physics",
    "es": "configurar física de vehículo",
    "ru": "настроить физику транспорта"
  },
  "Sensor de Colisão Contínua": {
    "en": "continuous collision sensor",
    "es": "sensor de colisión continua",
    "ru": "датчик непрерывных столкновений"
  },
  "Mover até colidir": {
    "en": "move until colliding with",
    "es": "mover hasta colisionar con",
    "ru": "двигаться до столкновения с"
  },
  "Definir máscara de colisão": {
    "en": "set collision mask to",
    "es": "establecer máscara de colisión en",
    "ru": "установить маску столкновений"
  },
  "Pausar Física do Objeto": {
    "en": "pause object physics",
    "es": "pausar física del objeto",
    "ru": "приостановить физику объекта"
  },
  "Simular explosão": {
    "en": "simulate explosion with",
    "es": "simular explosión con",
    "ru": "смоделировать взрыв с силой"
  },
  "Definir tolerância de cor": {
    "en": "set color tolerance to",
    "es": "establecer tolerancia de color en",
    "ru": "установить допуск цвета"
  },
  "Definir taxa de emissão": {
    "en": "set emission rate to",
    "es": "establecer tasa de emisión en",
    "ru": "установить частоту эмиссии"
  },
  "Tocar pasta uma vez e parar na última aparência": {
    "en": "play folder once and stop on the last look",
    "es": "reproducir carpeta una vez y detenerse en la última apariencia",
    "ru": "проиграть папку один раз и остановиться на последнем образе"
  },
  "Enviar para trás": {
    "en": "send backward",
    "es": "enviar hacia atrás",
    "ru": "переместить назад"
  },
  "Lista contém": {
    "en": "list contains",
    "es": "la lista contiene",
    "ru": "список содержит"
  },
  "Forçar orientação da tela": {
    "en": "force screen orientation to",
    "es": "forzar orientación de pantalla a",
    "ru": "принудительно задать ориентацию экрана"
  },
  "Compartilhar pontuação": {
    "en": "share score",
    "es": "compartir puntuación",
    "ru": "поделиться счётом"
  },
  "Compartilhar vídeo curto": {
    "en": "share short video",
    "es": "compartir vídeo corto",
    "ru": "поделиться коротким видео"
  },
  "Convidar amigo com link/código": {
    "en": "invite a friend with a link/code",
    "es": "invitar a un amigo con un enlace/código",
    "ru": "пригласить друга по ссылке/коду"
  },
  "Ler valor do acelerômetro": {
    "en": "read accelerometer value",
    "es": "leer valor del acelerómetro",
    "ru": "читать значение акселерометра"
  },
  "Ler valor do giroscópio": {
    "en": "read gyroscope value",
    "es": "leer valor del giroscopio",
    "ru": "читать значение гироскопа"
  },
  "Ler valor da bússola": {
    "en": "read compass value",
    "es": "leer valor de la brújula",
    "ru": "читать значение компаса"
  },
  "Ler nível de bateria": {
    "en": "read battery level",
    "es": "leer nivel de batería",
    "ru": "читать уровень заряда батареи"
  },
  "Pedir permissão de sensores": {
    "en": "request sensor permissions",
    "es": "solicitar permisos de sensores",
    "ru": "запросить разрешения датчиков"
  },
  "Detectar se está online": {
    "en": "detect whether online",
    "es": "detectar si está en línea",
    "ru": "определить наличие подключения"
  },
  "Desenhar retângulo": {
    "en": "draw rectangle",
    "es": "dibujar rectángulo",
    "ru": "нарисовать прямоугольник"
  },
  "Desenhar polígono": {
    "en": "draw polygon",
    "es": "dibujar polígono",
    "ru": "нарисовать многоугольник"
  },
  "Definir espessura do traço": {
    "en": "set stroke width to",
    "es": "establecer grosor del trazo en",
    "ru": "установить толщину линии"
  },
  "Definir visão do NPC": {
    "en": "set NPC vision to",
    "es": "establecer visión del NPC en",
    "ru": "задать обзор NPC"
  },
  "Definir alcance de detecção do NPC": {
    "en": "set NPC detection range to",
    "es": "establecer alcance de detección del NPC en",
    "ru": "задать радиус обнаружения NPC"
  },
  "Definir inteligência do NPC": {
    "en": "set NPC intelligence to",
    "es": "establecer inteligencia del NPC en",
    "ru": "задать интеллект NPC"
  },
  "Definir reação do NPC": {
    "en": "set NPC reaction to",
    "es": "establecer reacción del NPC en",
    "ru": "задать реакцию NPC"
  },
  "NPC tomar decisão": {
    "en": "NPC makes a decision",
    "es": "el NPC toma una decisión",
    "ru": "NPC принимает решение"
  },
  "NPC evitar obstáculo": {
    "en": "NPC avoids obstacle by",
    "es": "el NPC evita obstáculos a",
    "ru": "NPC избегает препятствия на"
  },
  "NPC copiar configuração": {
    "en": "NPC copies configuration from",
    "es": "el NPC copia la configuración de",
    "ru": "NPC копирует настройки из"
  },
  "Aplicar distorção de onda": {
    "en": "apply wave distortion",
    "es": "aplicar distorsión de onda",
    "ru": "применить волновое искажение"
  },
  "Aplicar pixelização": {
    "en": "apply pixelation",
    "es": "aplicar pixelación",
    "ru": "применить пикселизацию"
  },
  "Aplicar sépia": {
    "en": "apply sepia",
    "es": "aplicar sepia",
    "ru": "применить сепию"
  },
  "Definir resolução do shader": {
    "en": "set shader resolution to",
    "es": "establecer resolución del shader en",
    "ru": "задать разрешение шейдера"
  },
  "Definir qualidade de renderização": {
    "en": "set render quality to",
    "es": "establecer calidad de renderizado en",
    "ru": "задать качество рендеринга"
  },
  "Pré-carregar textura": {
    "en": "preload texture",
    "es": "precargar textura",
    "ru": "предзагрузить текстуру"
  },
  "Criar diálogo": {
    "en": "create dialog",
    "es": "crear diálogo",
    "ru": "создать диалог"
  },
  "Fechar diálogo": {
    "en": "close dialog",
    "es": "cerrar diálogo",
    "ru": "закрыть диалог"
  },
  "Criar ícone de status": {
    "en": "create status icon",
    "es": "crear icono de estado",
    "ru": "создать значок состояния"
  },
  "Criar lista de inventário": {
    "en": "create inventory list with",
    "es": "crear lista de inventario con",
    "ru": "создать список инвентаря на"
  },
  "Definir item do inventário": {
    "en": "set inventory item",
    "es": "establecer objeto del inventario",
    "ru": "задать предмет инвентаря"
  },
  "Definir negrito e itálico": {
    "en": "set bold to and italic to",
    "es": "establecer negrita en y cursiva en",
    "ru": "задать жирный шрифт и курсив"
  },
  "Definir espaçamento entre linhas": {
    "en": "set line spacing to",
    "es": "establecer interlineado en",
    "ru": "задать межстрочный интервал"
  },
  "Definir gradiente do texto": {
    "en": "set text gradient from to with angle",
    "es": "establecer degradado de texto de a con ángulo",
    "ru": "задать градиент текста от до под углом"
  },
  "Efeito de digitação": {
    "en": "typing effect with text at speed",
    "es": "efecto de escritura con texto a velocidad",
    "ru": "эффект печати текста со скоростью"
  },
  "Definir sprite do manípulo": {
    "en": "set joystick handle sprite to",
    "es": "establecer sprite de la palanca del joystick en",
    "ru": "задать спрайт рукоятки джойстика"
  },
  "Definir sprite dos botões": {
    "en": "set joystick button sprites to",
    "es": "establecer sprites de los botones del joystick en",
    "ru": "задать спрайты кнопок джойстика"
  },
  "Câmera com suavização": {
    "en": "camera with smoothing",
    "es": "cámara con suavizado",
    "ru": "камера со сглаживанием"
  },
  "Definir duração da transição": {
    "en": "set transition duration to",
    "es": "establecer duración de transición en",
    "ru": "задать длительность перехода"
  },
  "Objeto sólido": {
    "en": "solid object",
    "es": "objeto sólido",
    "ru": "твёрдый объект"
  },
  "Coletável": {
    "en": "collectible",
    "es": "coleccionable",
    "ru": "предмет для сбора"
  },
  "Empurrão": {
    "en": "push with force",
    "es": "empujar con fuerza",
    "ru": "толчок с силой"
  },
  "Projétil": {
    "en": "projectile with damage and speed",
    "es": "proyectil con daño y velocidad",
    "ru": "снаряд с уроном и скоростью"
  },
  "Plataforma móvel": {
    "en": "moving platform with distance and speed",
    "es": "plataforma móvil con distancia y velocidad",
    "ru": "движущаяся платформа с расстоянием и скоростью"
  },
  "Indicador de conexão (ping/status)": {
    "en": "connection indicator (ping/status)",
    "es": "indicador de conexión (ping/estado)",
    "ru": "индикатор соединения (ping/состояние)"
  },
  "Preset de contagem regressiva de início": {
    "en": "start countdown preset",
    "es": "ajuste predefinido de cuenta atrás inicial",
    "ru": "преднастройка стартового обратного отсчёта"
  },
  "Definir canal": {
    "en": "set audio channel to",
    "es": "establecer canal de audio en",
    "ru": "задать аудиоканал"
  },
  "Escutar mudanças da sala": {
    "en": "listen for room changes",
    "es": "escuchar cambios de la sala",
    "ru": "слушать изменения комнаты"
  },
  "Ler última mensagem WebSocket": {
    "en": "read last WebSocket message",
    "es": "leer último mensaje de WebSocket",
    "ru": "читать последнее сообщение WebSocket"
  },
  "Requisição HTTP GET": {
    "en": "HTTP GET request",
    "es": "solicitud HTTP GET",
    "ru": "HTTP GET-запрос"
  },
  "Requisição HTTP POST": {
    "en": "HTTP POST request",
    "es": "solicitud HTTP POST",
    "ru": "HTTP POST-запрос"
  },
  "Quando autenticação ok": {
    "en": "when authentication succeeds",
    "es": "cuando la autenticación sea correcta",
    "ru": "когда аутентификация успешна"
  },
  "Assertar condição": {
    "en": "assert condition",
    "es": "verificar condición",
    "ru": "проверить условие"
  },
  "Reiniciar cronômetro": {
    "en": "reset timer",
    "es": "reiniciar temporizador",
    "ru": "сбросить таймер"
  },
  "Quando compra concluída": {
    "en": "when purchase completes",
    "es": "cuando se complete la compra",
    "ru": "когда покупка завершена"
  },
  "Definir preço": {
    "en": "set price",
    "es": "establecer precio",
    "ru": "задать цену"
  },
  "Carregar nível": {
    "en": "load level",
    "es": "cargar nivel",
    "ru": "загрузить уровень"
  },
  "Quando nível completo": {
    "en": "when level completes",
    "es": "cuando se complete el nivel",
    "ru": "когда уровень завершён"
  },
  "Próximo nível": {
    "en": "next level",
    "es": "siguiente nivel",
    "ru": "следующий уровень"
  },
  "Reiniciar nível": {
    "en": "reset level",
    "es": "reiniciar nivel",
    "ru": "сбросить уровень"
  },
  "Definir deadzone do follow": {
    "en": "set follow deadzone",
    "es": "establecer zona muerta de seguimiento",
    "ru": "задать мёртвую зону слежения"
  },
  "Look-ahead da câmera": {
    "en": "camera look-ahead",
    "es": "anticipación de cámara",
    "ru": "упреждение камеры"
  },
  "Quando entrar na região": {
    "en": "when entering the region",
    "es": "al entrar en la región",
    "ru": "при входе в область"
  },
  "Quando sair da região": {
    "en": "when leaving the region",
    "es": "al salir de la región",
    "ru": "при выходе из области"
  },
  "Continuar próxima iteração": {
    "en": "continue next iteration",
    "es": "continuar con la siguiente iteración",
    "ru": "продолжить следующую итерацию"
  },
  "Wait until all other scripts have stopped": {
    "en": "wait until all other scripts have stopped",
    "es": "esperar hasta que todos los demás scripts se detengan",
    "ru": "ждать остановки всех остальных скриптов"
  },
  "Ir para posição aleatória": {
    "en": "go to random position",
    "es": "ir a una posición aleatoria",
    "ru": "перейти в случайную позицию"
  },
  "Apontar em direção a": {
    "en": "point towards",
    "es": "apuntar hacia",
    "ru": "направиться к"
  },
  "Definir estilo de rotação": {
    "en": "set rotation style to",
    "es": "establecer estilo de rotación en",
    "ru": "задать стиль вращения"
  },
  "Mover em direção ao toque": {
    "en": "move towards touch",
    "es": "mover hacia el toque",
    "ru": "двигаться к касанию"
  },
  "Mudar direção em": {
    "en": "change direction by",
    "es": "cambiar dirección en",
    "ru": "изменить направление на"
  },
  "Definir direção para": {
    "en": "set direction to",
    "es": "establecer dirección en",
    "ru": "задать направление"
  },
  "Mover na direção": {
    "en": "move in direction for steps",
    "es": "mover en dirección durante pasos",
    "ru": "двигаться в направлении на шагов"
  },
  "Empurrar com força": {
    "en": "push with force in direction",
    "es": "empujar con fuerza en dirección",
    "ru": "толкнуть с силой в направлении"
  },
  "Ativar Colisão Trigger": {
    "en": "enable collision trigger",
    "es": "activar disparador de colisión",
    "ru": "включить триггер столкновений"
  },
  "Camadas de Colisão": {
    "en": "collision layers",
    "es": "capas de colisión",
    "ru": "слои столкновений"
  },
  "Verificar colisão com": {
    "en": "check collision with and store in",
    "es": "comprobar colisión con y guardar en",
    "ru": "проверить столкновение с и сохранить в"
  },
  "Definir resposta de colisão": {
    "en": "set collision response to",
    "es": "establecer respuesta de colisión en",
    "ru": "задать реакцию на столкновение"
  },
  "Definir camada de colisão": {
    "en": "set collision layer to",
    "es": "establecer capa de colisión en",
    "ru": "задать слой столкновений"
  },
  "Definir tamanho da colisão": {
    "en": "set collision size to",
    "es": "establecer tamaño de colisión en",
    "ru": "задать размер области столкновения"
  },
  "Definir deslocamento da colisão": {
    "en": "set collision offset to",
    "es": "establecer desplazamiento de colisión en",
    "ru": "задать смещение области столкновения"
  },
  "Definir restituição": {
    "en": "set restitution to",
    "es": "establecer restitución en",
    "ru": "задать упругость"
  },
  "Otimizar Mundo Físico": {
    "en": "optimize physics world",
    "es": "optimizar el mundo físico",
    "ru": "оптимизировать физический мир"
  },
  "Path de Física": {
    "en": "physics path",
    "es": "ruta física",
    "ru": "физический путь"
  },
  "Set friction to …%": {
    "en": "set friction to",
    "es": "establecer fricción en",
    "ru": "задать трение на"
  },
  "Limpar efeitos gráficos": {
    "en": "clear graphic effects",
    "es": "limpiar efectos gráficos",
    "ru": "очистить графические эффекты"
  },
  "Criar emissor de partículas": {
    "en": "create particle emitter",
    "es": "crear emisor de partículas",
    "ru": "создать эмиттер частиц"
  },
  "Quando partícula nascer": {
    "en": "when a particle is created",
    "es": "cuando nazca una partícula",
    "ru": "при создании частицы"
  },
  "Definir cor da partícula": {
    "en": "set particle color to",
    "es": "establecer color de partícula en",
    "ru": "задать цвет частицы"
  },
  "Reproduzir animação da pasta": {
    "en": "play folder animation",
    "es": "reproducir animación de carpeta",
    "ru": "воспроизвести анимацию папки"
  },
  "Repetir animação da pasta": {
    "en": "repeat folder animation",
    "es": "repetir animación de carpeta",
    "ru": "повторять анимацию папки"
  },
  "Repetir animação da pasta em loop": {
    "en": "loop folder animation",
    "es": "repetir la animación de carpeta en bucle",
    "ru": "зациклить анимацию папки"
  },
  "Parar animação da pasta": {
    "en": "stop folder animation",
    "es": "detener animación de carpeta",
    "ru": "остановить анимацию папки"
  },
  "Aplicar animação em loop na pasta": {
    "en": "loop animation in folder",
    "es": "aplicar animación en bucle en la carpeta",
    "ru": "зациклить анимацию в папке"
  },
  "Parar animação": {
    "en": "stop animation",
    "es": "detener animación",
    "ru": "остановить анимацию"
  },
  "Próximo quadro da animação": {
    "en": "next animation frame",
    "es": "siguiente fotograma de animación",
    "ru": "следующий кадр анимации"
  },
  "Definir quadro da animação para": {
    "en": "set animation frame to",
    "es": "establecer fotograma de animación en",
    "ru": "задать кадр анимации"
  },
  "Esperar animação terminar": {
    "en": "wait for animation to finish",
    "es": "esperar a que termine la animación",
    "ru": "ждать окончания анимации"
  },
  "Definir velocidade da animação para": {
    "en": "set animation speed to",
    "es": "establecer velocidad de animación en",
    "ru": "задать скорость анимации"
  },
  "Definir cor": {
    "en": "set color from to with tolerance",
    "es": "establecer color de a con tolerancia",
    "ru": "задать цвет от до с допуском"
  },
  "Emissor de partículas": {
    "en": "particle emitter",
    "es": "emisor de partículas",
    "ru": "эмиттер частиц"
  },
  "Definir velocidade da animação": {
    "en": "set animation speed",
    "es": "establecer velocidad de animación",
    "ru": "задать скорость анимации"
  },
  "Inserir em lista": {
    "en": "insert into list at position",
    "es": "insertar en la lista en la posición",
    "ru": "вставить в список на позицию"
  },
  "Padrão de vibração customizado": {
    "en": "custom vibration pattern",
    "es": "patrón de vibración personalizado",
    "ru": "пользовательский шаблон вибрации"
  },
  "Parar vibração": {
    "en": "stop vibration",
    "es": "detener vibración",
    "ru": "остановить вибрацию"
  },
  "Feedback tátil por evento": {
    "en": "haptic feedback by event",
    "es": "respuesta háptica por evento",
    "ru": "тактильная обратная связь по событию"
  },
  "Quando vibração terminar": {
    "en": "when vibration ends",
    "es": "cuando termine la vibración",
    "ru": "когда вибрация завершится"
  },
  "Swipe (direção)": {
    "en": "swipe (direction)",
    "es": "deslizamiento (dirección)",
    "ru": "свайп (направление)"
  },
  "Rotação por gesto": {
    "en": "gesture rotation",
    "es": "rotación por gesto",
    "ru": "вращение жестом"
  },
  "Enviar notificação": {
    "en": "send notification",
    "es": "enviar notificación",
    "ru": "отправить уведомление"
  },
  "Ler QR code": {
    "en": "read QR code",
    "es": "leer código QR",
    "ru": "читать QR-код"
  },
  "Gerar número aleatório": {
    "en": "generate random number",
    "es": "generar número aleatorio",
    "ru": "сгенерировать случайное число"
  },
  "Pedir texto ao usuário": {
    "en": "ask user for text",
    "es": "pedir texto al usuario",
    "ru": "запросить текст у пользователя"
  },
  "Desenhar linha": {
    "en": "draw line",
    "es": "dibujar línea",
    "ru": "нарисовать линию"
  },
  "Desenhar círculo": {
    "en": "draw circle",
    "es": "dibujar círculo",
    "ru": "нарисовать круг"
  },
  "Set pen colour to red … green … blue": {
    "en": "set pen color to red green blue",
    "es": "establecer color de lápiz rojo verde azul",
    "ru": "задать цвет пера красный зелёный синий"
  },
  "Criar botão": {
    "en": "create button",
    "es": "crear botón",
    "ru": "создать кнопку"
  },
  "Definir posição da UI": {
    "en": "set UI position",
    "es": "establecer posición de la UI",
    "ru": "задать положение UI"
  },
  "Quando botão pressionado": {
    "en": "when button is pressed",
    "es": "cuando se presione el botón",
    "ru": "при нажатии кнопки"
  },
  "Definir posição do HUD": {
    "en": "set HUD position",
    "es": "establecer posición del HUD",
    "ru": "задать положение HUD"
  },
  "Criar notificação toast UI": {
    "en": "create toast UI notification",
    "es": "crear notificación toast de UI",
    "ru": "создать toast-уведомление UI"
  },
  "Definir posicao X do texto": {
    "en": "set text X position",
    "es": "establecer posición X del texto",
    "ru": "задать позицию X текста"
  },
  "Definir posicao Y do texto": {
    "en": "set text Y position",
    "es": "establecer posición Y del texto",
    "ru": "задать позицию Y текста"
  },
  "Iniciar animacao de texto": {
    "en": "start text animation",
    "es": "iniciar animación de texto",
    "ru": "запустить анимацию текста"
  },
  "Finalizar animacao de texto": {
    "en": "finish text animation",
    "es": "finalizar animación de texto",
    "ru": "завершить анимацию текста"
  },
  "Animacao de texto em loop": {
    "en": "loop text animation",
    "es": "animación de texto en bucle",
    "ru": "зациклить анимацию текста"
  },
  "Texto estilizado rapido": {
    "en": "quick styled text",
    "es": "texto estilizado rápido",
    "ru": "быстрое стилизованное текстовое оформление"
  },
  "Texto HUD rapido": {
    "en": "quick HUD text",
    "es": "texto HUD rápido",
    "ru": "быстрый текст HUD"
  },
  "Criar joystick virtual": {
    "en": "create virtual joystick",
    "es": "crear joystick virtual",
    "ru": "создать виртуальный джойстик"
  },
  "Definir posição do joystick": {
    "en": "set joystick position",
    "es": "establecer posición del joystick",
    "ru": "задать положение джойстика"
  },
  "Ler direção do joystick": {
    "en": "read joystick direction and store in",
    "es": "leer dirección del joystick y guardar en",
    "ru": "читать направление джойстика и сохранить в"
  },
  "Criar botão de ação": {
    "en": "create action button",
    "es": "crear botón de acción",
    "ru": "создать кнопку действия"
  },
  "Criar câmera de seguimento": {
    "en": "create follow camera",
    "es": "crear cámara de seguimiento",
    "ru": "создать камеру слежения"
  },
  "Definir alvo da câmera": {
    "en": "set camera target",
    "es": "establecer objetivo de la cámara",
    "ru": "задать цель камеры"
  },
  "Definir zoom da câmera": {
    "en": "set camera zoom to",
    "es": "establecer zoom de la cámara en",
    "ru": "задать масштаб камеры"
  },
  "Câmera com paralaxe": {
    "en": "camera with parallax",
    "es": "cámara con paralaje",
    "ru": "камера с параллаксом"
  },
  "câmera no jogador": {
    "en": "camera on player",
    "es": "cámara en el jugador",
    "ru": "камера на игроке"
  },
  "reset completo da câmera": {
    "en": "full camera reset",
    "es": "restablecer toda la cámara",
    "ru": "полный сброс камеры"
  },
  "Transição fade in/out": {
    "en": "fade in/out transition",
    "es": "transición de fundido de entrada/salida",
    "ru": "переход с появлением/исчезновением"
  },
  "Transição cortinas (wipe)": {
    "en": "curtain wipe transition",
    "es": "transición de cortina (wipe)",
    "ru": "переход с вытеснением (шторка)"
  },
  "Transição deslizar (slide)": {
    "en": "slide transition",
    "es": "transición de deslizamiento (slide)",
    "ru": "переход сдвигом (slide)"
  },
  "Transição zoom": {
    "en": "zoom transition",
    "es": "transición de zoom",
    "ru": "переход масштабированием"
  },
  "Transição de cena aleatória": {
    "en": "random scene transition",
    "es": "transición de escena aleatoria",
    "ru": "случайный переход сцены"
  },
  "Preset de botão pronto": {
    "en": "ready button preset",
    "es": "ajuste predefinido de botón listo",
    "ru": "преднастройка готовой кнопки"
  },
  "Preset de chat rápido": {
    "en": "quick chat preset",
    "es": "ajuste predefinido de chat rápido",
    "ru": "преднастройка быстрого чата"
  },
  "Ler último evento multiplayer": {
    "en": "read last multiplayer event",
    "es": "leer último evento multijugador",
    "ru": "читать последнее сетевое событие"
  },
  "Quando animação terminar": {
    "en": "when animation ends",
    "es": "cuando termine la animación",
    "ru": "когда анимация завершится"
  },
  "Definir curva de animação": {
    "en": "set animation curve to",
    "es": "establecer curva de animación en",
    "ru": "задать кривую анимации"
  },
  "Ler cronômetro": {
    "en": "read timer",
    "es": "leer temporizador",
    "ru": "читать таймер"
  },
  "Seguir ator com câmera": {
    "en": "follow actor with camera",
    "es": "seguir actor con la cámara",
    "ru": "следить за актёром камерой"
  },
  "Zoom da câmera": {
    "en": "camera zoom to",
    "es": "zoom de la cámara a",
    "ru": "масштаб камеры"
  },
  "Shake de câmera": {
    "en": "camera shake with intensity",
    "es": "sacudida de cámara con intensidad",
    "ru": "тряска камеры с интенсивностью"
  },
  "Quando câmera mover": {
    "en": "when camera moves",
    "es": "cuando se mueva la cámara",
    "ru": "когда камера перемещается"
  },
  "Definir limites da câmera": {
    "en": "set camera limits",
    "es": "establecer límites de la cámara",
    "ru": "задать границы камеры"
  },
  "Câmera livre": {
    "en": "free camera",
    "es": "cámara libre",
    "ru": "свободная камера"
  },
  "Ativar câmera AR": {
    "en": "enable AR camera",
    "es": "activar cámara AR",
    "ru": "включить AR-камеру"
  },
  "Definir posição da câmera": {
    "en": "set camera position",
    "es": "establecer posición de la cámara",
    "ru": "задать положение камеры"
  },
  "Mudar posição da câmera em": {
    "en": "change camera position by",
    "es": "cambiar la posición de la cámara en",
    "ru": "изменить положение камеры на"
  },
  "Deslizar câmera até": {
    "en": "glide camera to",
    "es": "deslizar la cámara hasta",
    "ru": "плавно переместить камеру в"
  },
  "Resetar câmera": {
    "en": "reset camera",
    "es": "restablecer cámara",
    "ru": "сбросить камеру"
  },
  "Centralizar no ator": {
    "en": "center camera on actor",
    "es": "centrar la cámara en el actor",
    "ru": "центрировать камеру на актёре"
  },
  "Definir offset da câmera": {
    "en": "set camera offset to",
    "es": "establecer desplazamiento de la cámara en",
    "ru": "задать смещение камеры"
  },
  "Rotacionar câmera": {
    "en": "rotate camera by",
    "es": "rotar la cámara en",
    "ru": "повернуть камеру на"
  },
  "Travaár eixo da câmera": {
    "en": "lock camera axis to",
    "es": "bloquear eje de la cámara en",
    "ru": "заблокировать ось камеры"
  },
  "Travar eixo da câmera": {
    "en": "lock camera axis to",
    "es": "bloquear eje de la cámara en",
    "ru": "заблокировать ось камеры"
  },
  "Parar shake da câmera": {
    "en": "stop camera shake",
    "es": "detener sacudida de cámara",
    "ru": "остановить тряску камеры"
  },
  "Empurrar câmera": {
    "en": "push camera by",
    "es": "mover la cámara en",
    "ru": "сдвинуть камеру на"
  },
  "Obter posição X da câmera": {
    "en": "get camera X position",
    "es": "obtener posición X de la cámara",
    "ru": "получить позицию X камеры"
  },
  "Obter posição Y da câmera": {
    "en": "get camera Y position",
    "es": "obtener posición Y de la cámara",
    "ru": "получить позицию Y камеры"
  },
  "Obter zoom da câmera": {
    "en": "get camera zoom",
    "es": "obtener zoom de la cámara",
    "ru": "получить масштаб камеры"
  }
};

Object.assign(KIX_BLOCK_MANUAL_I18N, {
  "Ler sensor de luz": {"en":"read light sensor","es":"leer sensor de luz","ru":"читать датчик освещённости"},
  "Ler sensor de proximidade": {"en":"read proximity sensor","es":"leer sensor de proximidad","ru":"читать датчик приближения"},
  "NPC usar habilidade": {"en":"NPC uses skill","es":"NPC usa habilidad","ru":"НПС использует навык"},
  "NPC usar item": {"en":"NPC uses item","es":"NPC usa elemento","ru":"НПС использует предмет"},
  "NPC escolher alvo mais próximo": {"en":"NPC chooses the nearest target","es":"NPC elige el objetivo más cercano","ru":"НПС выбирает ближайшую цель"},
  "NPC trocar estado automaticamente": {"en":"NPC changes state automatically","es":"NPC cambia de estado automáticamente","ru":"НПС автоматически меняет состояние"},
  "Parar todos os sons": {"en":"stop all sounds","es":"detener todos los sonidos","ru":"остановить все звуки"},
  "Pausar todos os sons": {"en":"pause all sounds","es":"pausar todos los sonidos","ru":"приостановить все звуки"},
  "Retomar todos os sons": {"en":"resume all sounds","es":"reanudar todos los sonidos","ru":"возобновить все звуки"},
  "Excluir dados do Firebase": {"en":"delete Firebase data","es":"eliminar datos de Firebase","ru":"удалить данные Firebase"},
  "Parar outros scripts deste objeto": {"en":"stop other scripts of this object","es":"detener otros scripts de este objeto","ru":"остановить другие скрипты этого объекта"},
  "Tocar pasta uma vez e voltar pra aparência original": {"en":"play folder once and return to the original look","es":"reproducir la carpeta una vez y volver a la apariencia original","ru":"воспроизвести папку один раз и вернуться к исходному образу"},
  "Modo de mistura": {"en":"blend mode","es":"modo de mezcla","ru":"режим смешивания"},
  "Definir idioma do jogo": {"en":"set game language","es":"establecer idioma del juego","ru":"установить язык игры"},
  "Texto traduzido por chave": {"en":"translated text by key","es":"texto traducido por clave","ru":"переведённый текст по ключу"},
  "Trocar idioma em tempo real": {"en":"change language in real time","es":"cambiar el idioma en tiempo real","ru":"менять язык в реальном времени"},
  "Definir idioma da fala": {"en":"set speech language","es":"establecer idioma del habla","ru":"установить язык речи"},
  "Aplicar shader na cena inteira": {"en":"apply shader to the whole scene","es":"aplicar sombreado a toda la escena","ru":"применить шейдер ко всей сцене"},
  "Definir taxa de quadros alvo (FPS)": {"en":"set target frame rate (FPS)","es":"establecer la tasa de fotogramas objetivo (FPS)","ru":"задать целевую частоту кадров (FPS)"}
});


Object.assign(KIX_BLOCK_MANUAL_I18N, {
  "Definir tamanho da UI": {"en":"set UI size to {id}, width {largura}, height {altura}","es":"establecer tamaño de la UI: {id}, ancho {largura}, alto {altura}","ru":"задать размер UI: {id}, ширина {largura}, высота {altura}"},
  "Medir largura do texto": {"en":"measure text width","es":"medir el ancho del texto","ru":"измерить ширину текста"},
  "Criar D-Pad": {"en":"create D-pad: ID {id}, up {cima}, left {esquerda}, right {direita}, down {baixo}","es":"crear D-pad: ID {id}, arriba {cima}, izquierda {esquerda}, derecha {direita}, abajo {baixo}","ru":"создать D-панель: ID {id}, вверх {cima}, влево {esquerda}, вправо {direita}, вниз {baixo}"},
  "Repetir para sempre com delay": {"en":"repeat forever with a delay of {segundos} seconds","es":"repetir para siempre con un intervalo de {segundos} segundos","ru":"повторять бесконечно с интервалом {segundos} секунд"},
  "Transição fade para cena": {"en":"transition to scene {cena} with fade in {segundos} seconds {cor} {estilo}","es":"transición a la escena {cena} con fundido de entrada de {segundos} segundos {cor} {estilo}","ru":"переход к сцене {cena} с появлением за {segundos} секунд {cor} {estilo}"},
  "Transição fade para [cena] em [segundos]": {"en":"transition to scene {cena} with fade in {segundos} seconds {cor} {estilo}","es":"transición a la escena {cena} con fundido de entrada de {segundos} segundos {cor} {estilo}","ru":"переход к сцене {cena} с появлением за {segundos} секунд {cor} {estilo}"},
  "Trazer para frente": {"en":"bring to front","es":"llevar al frente","ru":"переместить на передний план"},
  "Interpolar texto (fade in/out)": {"en":"interpolate text from {inicio} to {fim} in {segundos} seconds","es":"interpolar texto de {inicio} a {fim} en {segundos} segundos","ru":"интерполировать текст от {inicio} до {fim} за {segundos} секунд"},
  "Crossfade": {"en":"crossfade {som} over {segundos} seconds","es":"fundido cruzado de {som} durante {segundos} segundos","ru":"перекрёстное затухание {som} за {segundos} секунд"},
  "Zoom suave até": {"en":"smooth zoom to {valor} in {segundos} seconds","es":"hacer zoom suavemente hasta {valor} en {segundos} segundos","ru":"плавно изменить масштаб до {valor} за {segundos} секунд"}
});


Object.assign(KIX_BLOCK_MANUAL_I18N, {
  "Com chance % faça": {"en":"with a {porcentagem}% chance, run","es":"con un {porcentagem}% de probabilidad, ejecutar","ru":"выполнить с вероятностью {porcentagem}%"},
  "Sombra": {"en":"shadow: color {cor}, X {offsetX}, Y {offsetY}, blur {blur}","es":"sombra: color {cor}, X {offsetX}, Y {offsetY}, desenfoque {blur}","ru":"тень: цвет {cor}, X {offsetX}, Y {offsetY}, размытие {blur}"},
  "Definir sombra do texto": {"en":"set text shadow: color {cor}, X {deslocamento x}, Y {deslocamento y}, blur {desfoque}","es":"establecer sombra del texto: color {cor}, X {deslocamento x}, Y {deslocamento y}, desenfoque {desfoque}","ru":"задать тень текста: цвет {cor}, X {deslocamento x}, Y {deslocamento y}, размытие {desfoque}"},
  "Interpolar texto (fade in/out)": {"en":"interpolate text from {de} to {para} in {duracao} seconds","es":"interpolar texto de {de} a {para} en {duracao} segundos","ru":"интерполировать текст от {de} до {para} за {duracao} секунд"},
  "Mostrar dado como texto": {"en":"show {variavel} as text with prefix {prefixo}","es":"mostrar {variavel} como texto con prefijo {prefixo}","ru":"показать {variavel} как текст с префиксом {prefixo}"},
  "Rotacionar texto": {"en":"rotate text by {graus} degrees","es":"rotar el texto {graus} grados","ru":"повернуть текст на {graus} градусов"},
  "Desenhar texto vetorial": {"en":"draw vector text {texto}","es":"dibujar texto vectorial {texto}","ru":"нарисовать векторный текст {texto}"},
  "Criptografar texto": {"en":"encrypt text {texto}","es":"cifrar texto {texto}","ru":"зашифровать текст {texto}"},
  "Descriptografar texto": {"en":"decrypt text {texto}","es":"descifrar texto {texto}","ru":"расшифровать текст {texto}"},
  "Log de texto": {"en":"log text {texto}","es":"registrar texto {texto}","ru":"записать текст в журнал {texto}"},
  "Iniciar timer": {"en":"start timer {segundos}","es":"iniciar temporizador {segundos}","ru":"запустить таймер {segundos}"},
  "Texto traduzido por chave": {"en":"translated text by key {chave}","es":"texto traducido por clave {chave}","ru":"переведённый текст по ключу {chave}"},
  "Definir uniform texto": {"en":"set text uniform {nome} {valor}","es":"establecer uniform de texto {nome} {valor}","ru":"задать текстовый uniform {nome} {valor}"},
  "Definir gradiente do texto": {"en":"set text gradient from {cor inicio} to {cor fim} with angle {angulo}","es":"establecer degradado de texto de {cor inicio} a {cor fim} con ángulo {angulo}","ru":"задать градиент текста от {cor inicio} до {cor fim} под углом {angulo}"},
  "Efeito de digitação": {"en":"typing effect: {texto} at speed {velocidade}","es":"efecto de escritura: {texto} a velocidad {velocidade}","ru":"эффект печати: {texto}, скорость {velocidade}"},
  "Quebra de linha automática": {"en":"automatic line break at {largura maxima}px","es":"salto de línea automático en {largura maxima}px","ru":"автоматический перенос строки при {largura maxima}px"}
});

const KIX_PARAM_I18N = {
  'pt-BR': {},
  'en': { segundos:'seconds', vezes:'times', condição:'condition', variável:'variable', valor:'value', objeto:'object', ator:'actor', cena:'scene', som:'sound', texto:'text', cor:'color', tamanho:'size', direção:'direction', passos:'steps', graus:'degrees', porcentagem:'chance', largura:'width', altura:'height', nome:'name', índice:'index', lista:'list', item:'item', imagem:'image', efeitos:'effect' },
  'es': { segundos:'segundos', vezes:'veces', condição:'condición', variável:'variable', valor:'valor', objeto:'objeto', ator:'actor', cena:'escena', som:'sonido', texto:'texto', cor:'color', tamanho:'tamaño', direção:'dirección', passos:'pasos', graus:'grados', porcentagem:'probabilidad', largura:'ancho', altura:'alto', nome:'nombre', índice:'índice', lista:'lista', item:'elemento', imagem:'imagen', efeitos:'efecto' },
  'ru': { segundos:'секунд', vezes:'раз', condição:'условие', variável:'переменная', valor:'значение', objeto:'объект', ator:'актёр', cena:'сцена', som:'звук', texto:'текст', cor:'цвет', tamanho:'размер', direção:'направление', passos:'шагов', graus:'град.', porcentagem:'шанс', largura:'ширина', altura:'высота', nome:'имя', índice:'индекс', lista:'список', item:'элемент', imagem:'изображение', efeitos:'эффект' }
};


// Fallback translator for the full Kix catalog and dynamically-created UI text.
// The explicit dictionaries above remain authoritative for polished/common phrases;
// this layer prevents untranslated Portuguese from being left behind when a block is
// outside the small explicit phrase map.
const KIX_UI_PHRASE_I18N = {
  en: {
    'Projetos':'Projects','Configurações':'Settings','Mini tutorial':'Quick tutorial','Sobre o Kix':'About Kix','Criar projeto':'Create project','NOVO PROJETO':'NEW PROJECT','ADICIONAR OBJETO':'ADD OBJECT','ADICIONAR APARÊNCIA':'ADD LOOK','ADICIONAR SOM':'ADD SOUND','OPÇÕES':'OPTIONS','Projeto vazio':'Empty project','Jogo de teste Kix':'Kix test game','Projeto com nome':'Named project','Objeto vazio':'Empty object','Importar da galeria':'Import from gallery','Tirar foto':'Take photo','Importar .kix':'Import .kix','Mochila':'Backpack','Selecionar imagem':'Choose image','Aparência vazia':'Empty look','Selecionar arquivo de áudio':'Choose audio file','Gravar áudio':'Record audio','OBJECT':'OBJECT','LOOK':'LOOK','Renomear objeto':'Rename object','Renomear':'Rename','Duplicar':'Duplicate','Definir posição (0,0)':'Set position (0,0)','Mostrar':'Show','Esconder':'Hide','Tamanho 100%':'Size 100%','Editar colisão':'Edit collision','Excluir objeto':'Delete object','Usar como ativa':'Use as active','Definir como Pixel Art':'Set as Pixel Art','Nova pasta':'New folder','Adicionar GIF':'Add GIF','Mover para pasta':'Move to folder','Tirar da pasta':'Remove from folder','Apagar aparência':'Delete look','Voltar':'Back','Cancelar':'Cancel','Salvar':'Save','Excluir':'Delete','Detalhes':'Details','Selecionar':'Select','Escolha um item do projeto':'Choose a project item','Tipo de tela':'Screen type','Nome':'Name','Versão':'Version','Paisagem':'Landscape','Retrato':'Portrait','Criar':'Create','Sair':'Exit','Biblioteca':'Library','Scripts':'Scripts','Aparências':'Looks','Sons':'Sounds','Categorias':'Categories','Atores e objetos':'Actors & objects','Adicionar objeto':'Add object','Adicionar aparência':'Add look','Adicionar som':'Add sound','Executar':'Run','Parar':'Stop','Pausar':'Pause','Reiniciar':'Restart','Mais':'More','Câmera livre':'Free camera','Centralizar câmera':'Center camera','Ajustar ao palco':'Fit to stage','Novo projeto':'New project','Opções':'Options','Bem-vindo':'Welcome','Nenhum projeto ainda.\nToque em + para criar.':'No projects yet.\nTap + to create one.','Agora':'Now','Como começar':'Getting started','Categorias principais':'Main categories','Blocos menos óbvios':'Less obvious blocks','NPCs com IA':'AI NPCs'
  },
  es: {
    'Projetos':'Proyectos','Configurações':'Configuración','Mini tutorial':'Mini tutorial','Sobre o Kix':'Acerca de Kix','Criar projeto':'Crear proyecto','NOVO PROJETO':'NUEVO PROYECTO','ADICIONAR OBJETO':'AÑADIR OBJETO','ADICIONAR APARÊNCIA':'AÑADIR APARIENCIA','ADICIONAR SOM':'AÑADIR SONIDO','OPÇÕES':'OPCIONES','Projeto vazio':'Proyecto vacío','Jogo de teste Kix':'Juego de prueba de Kix','Projeto com nome':'Proyecto con nombre','Objeto vazio':'Objeto vacío','Importar da galeria':'Importar de la galería','Tirar foto':'Tomar foto','Importar .kix':'Importar .kix','Mochila':'Mochila','Selecionar imagem':'Seleccionar imagen','Aparência vazia':'Apariencia vacía','Selecionar arquivo de áudio':'Seleccionar archivo de audio','Gravar áudio':'Grabar audio','OBJECT':'OBJETO','LOOK':'APARIENCIA','Renomear objeto':'Renombrar objeto','Renomear':'Renombrar','Duplicar':'Duplicar','Definir posição (0,0)':'Definir posición (0,0)','Mostrar':'Mostrar','Esconder':'Ocultar','Tamanho 100%':'Tamaño 100%','Editar colisão':'Editar colisión','Excluir objeto':'Eliminar objeto','Usar como ativa':'Usar como activa','Definir como Pixel Art':'Establecer como Pixel Art','Nova pasta':'Nueva carpeta','Adicionar GIF':'Añadir GIF','Mover para pasta':'Mover a carpeta','Tirar da pasta':'Sacar de la carpeta','Apagar aparência':'Eliminar apariencia','Voltar':'Volver','Cancelar':'Cancelar','Salvar':'Guardar','Excluir':'Eliminar','Detalhes':'Detalles','Selecionar':'Seleccionar','Escolha um item do projeto':'Elige un elemento del proyecto','Tipo de tela':'Tipo de pantalla','Nome':'Nombre','Versão':'Versión','Paisagem':'Paisaje','Retrato':'Retrato','Criar':'Crear','Sair':'Salir','Biblioteca':'Biblioteca','Atores e objetos':'Actores y objetos','Adicionar objeto':'Añadir objeto','Adicionar aparência':'Añadir apariencia','Adicionar som':'Añadir sonido','Executar':'Ejecutar','Parar':'Detener','Pausar':'Pausar','Reiniciar':'Reiniciar','Mais':'Más','Câmera livre':'Cámara libre','Centralizar câmera':'Centrar cámara','Ajustar ao palco':'Ajustar al escenario','Novo projeto':'Nuevo proyecto','Opções':'Opciones','Bem-vindo':'Bienvenido','Nenhum projeto ainda.\nToque em + para criar.':'Aún no hay proyectos.\nToca + para crear uno.','Agora':'Ahora','Como começar':'Cómo empezar','Categorias principais':'Categorías principales','Blocos menos óbvios':'Bloques menos obvios','NPCs com IA':'NPC con IA'
  },
  ru: {
    'Projetos':'Проекты','Configurações':'Настройки','Mini tutorial':'Мини-урок','Sobre o Kix':'О Kix','Criar projeto':'Создать проект','NOVO PROJETO':'НОВЫЙ ПРОЕКТ','ADICIONAR OBJETO':'ДОБАВИТЬ ОБЪЕКТ','ADICIONAR APARÊNCIA':'ДОБАВИТЬ ОБРАЗ','ADICIONAR SOM':'ДОБАВИТЬ ЗВУК','OPÇÕES':'ОПЦИИ','Projeto vazio':'Пустой проект','Jogo de teste Kix':'Тестовая игра Kix','Projeto com nome':'Проект с именем','Objeto vazio':'Пустой объект','Importar da galeria':'Импорт из галереи','Tirar foto':'Сделать фото','Importar .kix':'Импорт .kix','Mochila':'Рюкзак','Selecionar imagem':'Выбрать изображение','Aparência vazia':'Пустой образ','Selecionar arquivo de áudio':'Выбрать аудиофайл','Gravar áudio':'Записать аудио','OBJECT':'ОБЪЕКТ','LOOK':'ОБРАЗ','Renomear objeto':'Переименовать объект','Renomear':'Переименовать','Duplicar':'Дублировать','Definir posição (0,0)':'Задать позицию (0,0)','Mostrar':'Показать','Esconder':'Скрыть','Tamanho 100%':'Размер 100%','Editar colisão':'Изменить столкновение','Excluir objeto':'Удалить объект','Usar como ativa':'Использовать как активный','Definir como Pixel Art':'Сделать Pixel Art','Nova pasta':'Новая папка','Adicionar GIF':'Добавить GIF','Mover para pasta':'Переместить в папку','Tirar da pasta':'Убрать из папки','Apagar aparência':'Удалить образ','Voltar':'Назад','Cancelar':'Отмена','Salvar':'Сохранить','Excluir':'Удалить','Detalhes':'Подробности','Selecionar':'Выбрать','Escolha um item do projeto':'Выберите элемент проекта','Tipo de tela':'Ориентация экрана','Nome':'Имя','Versão':'Версия','Paisagem':'Альбомная','Retrato':'Портрет','Criar':'Создать','Sair':'Выйти','Biblioteca':'Библиотека','Atores e objetos':'Объекты','Adicionar objeto':'Добавить объект','Adicionar aparência':'Добавить образ','Adicionar som':'Добавить звук','Executar':'Запустить','Parar':'Остановить','Pausar':'Пауза','Reiniciar':'Перезапустить','Mais':'Ещё','Câmera livre':'Свободная камера','Centralizar câmera':'Центрировать камеру','Ajustar ao palco':'По размеру сцены','Novo projeto':'Новый проект','Opções':'Параметры','Bem-vindo':'Добро пожаловать','Nenhum projeto ainda.\nToque em + para criar.':'Пока нет проектов.\nНажмите +, чтобы создать.','Agora':'Сейчас','Como começar':'Начало работы','Categorias principais':'Основные категории','Blocos menos óbvios':'Менее очевидные блоки','NPCs com IA':'ИИ и NPC'
  }
};

const KIX_AUTO_I18N = {
  en: {
    'quando':'when','começar':'start','começa':'starts','iniciar':'start','cena':'scene','tela':'stage','tocado':'tapped','pressionada':'pressed','receber':'receive','recebido':'received','mensagem':'message','enviar':'broadcast','esperar':'wait','sempre':'forever','repita':'repeat','repetir':'repeat','até':'until','enquanto':'while','se':'if','então':'then','senão':'else','mostrar':'show','esconder':'hide','parar':'stop','sair':'exit','continuar':'continue','próxima':'next','próximo':'next','anterior':'previous','reiniciar':'restart','mover':'move','passos':'steps','girar':'turn','direita':'right','esquerda':'left','ir':'go','para':'to','posição':'position','posicao':'position','aleatória':'random','aleatório':'random','outro':'other','deslizar':'glide','apontar':'point','direção':'direction','direcao':'direction','mudar':'change','definir':'set','aumentar':'increase','diminuir':'decrease','tamanho':'size','transparência':'transparency','transparencia':'transparency','aparência':'look','aparencia':'look','fantasia':'look','número':'number','numero':'number','nome':'name','variável':'variable','variavel':'variable','valor':'value','objeto':'object','ator':'actor','som':'sound','texto':'text','cor':'color','lista':'list','item':'item','efeito':'effect','efeitos':'effects','brilho':'brightness','opacidade':'opacity','volume':'volume','fonte':'font','alinhamento':'alignment','graus':'degrees','segundo':'second','segundos':'seconds','vez':'time','vezes':'times','quadro':'frame','pasta':'folder','animação':'animation','animacao':'animation','tocar':'play','reproduzir':'play','aplicar':'apply','criar':'create','adicionar':'add','apagar':'delete','remover':'remove','copiar':'copy','editar':'edit','restaurar':'restore','limpar':'clear','salvar':'save','carregar':'load','atualizar':'update','executar':'run','aguardar':'wait','pausar':'pause','retomar':'resume','ativar':'enable','desativar':'disable','detectar':'detect','verificar':'check','seguir':'follow','afastar':'move away','colidir':'collide','colisão':'collision','colisao':'collision','dano':'damage','vida':'life','jogador':'player','jogadores':'players','alvo':'target','força':'force','forca':'force','velocidade':'speed','gravidade':'gravity','câmera':'camera','camera':'camera','camada':'layer','controle':'control','evento':'event','dados':'data','som':'sound','caneta':'pen','desenho':'drawing','dispositivo':'device','idioma':'language','sala':'room','partida':'match','objetivo':'goal','estado':'state','modo':'mode','padrão':'default','padrao':'default','arquivo':'file','caminho':'path','chave':'key','resultado':'result','erro':'error','status':'status','progresso':'progress','botão':'button','botao':'button','sensor':'sensor','região':'region','regiao':'region','camadas':'layers','minimapa':'minimap','placar':'scoreboard','moedas':'coins','thread':'thread','scripts':'scripts','shader':'shader','shaders':'shaders','spritesheet':'spritesheet','sprite':'sprite','gif':'gif','joystick':'joystick','pad':'pad','tile':'tile','firebase':'firebase','websocket':'websocket','http':'HTTP','api':'API','npc':'NPC','ia':'AI','zoom':'zoom','fade':'fade','painel':'panel','barra':'bar','indicador':'indicator','notificação':'notification','notificacao':'notification','memória':'memory','memoria':'memory','vibração':'vibration','vibracao':'vibration','aleatório':'random','rápido':'fast','rapido':'fast','completo':'complete','original':'original','local':'local','global':'global','do':'of','da':'of','dos':'of','das':'of','de':'of','em':'in','no':'in the','na':'in the','nos':'in the','nas':'in the','com':'with','por':'for','a':'the','o':'the','os':'the','as':'the','e':'and','ao':'to the','à':'to the','às':'to the','um':'a','uma':'a','sem':'without','sobre':'over','entre':'between','fora':'outside','dentro':'inside','direto':'direct','gradualmente':'gradually','parcialmente':'partially','escolher':'choose','pedir':'ask','falar':'say','pensar':'think','piscar':'blink','tintar':'tint','espelhar':'mirror','rotacionar':'rotate','rotação':'rotation','transição':'transition','transicao':'transition','conectar':'connect','desconectar':'disconnect','compartilhar':'share','entrar':'enter','sair':'exit','pronto':'ready','dois':'two','duplo':'double','curto':'short','círculo':'circle','circulo':'circle','linha':'line','emissor':'emitter','partícula':'particle','particulas':'particles','partículas':'particles','radar':'radar','rede':'network','alcance':'range','inverter':'reverse','gerar':'generate','configurar':'configure','contato':'contact','contorno':'outline','gradiente':'gradient','plataforma':'platform','pinça':'pinch','pinca':'pinch','pressão':'pressure','pressao':'pressure'
  },
  es: {
    'quando':'al','começar':'comenzar','começa':'comienza','iniciar':'iniciar','cena':'escena','tela':'pantalla','tocado':'tocado','pressionada':'pulsada','receber':'recibir','recebido':'recibido','mensagem':'mensaje','enviar':'enviar','esperar':'esperar','sempre':'siempre','repita':'repetir','repetir':'repetir','até':'hasta','enquanto':'mientras','se':'si','então':'entonces','senão':'si no','mostrar':'mostrar','esconder':'ocultar','parar':'detener','sair':'salir','continuar':'continuar','próxima':'siguiente','próximo':'siguiente','anterior':'anterior','reiniciar':'reiniciar','mover':'mover','passos':'pasos','girar':'girar','direita':'derecha','esquerda':'izquierda','ir':'ir','para':'a','posição':'posición','posicao':'posición','aleatória':'aleatoria','aleatório':'aleatorio','outro':'otro','deslizar':'deslizar','apontar':'apuntar','direção':'dirección','direcao':'dirección','mudar':'cambiar','definir':'establecer','aumentar':'aumentar','diminuir':'reducir','tamanho':'tamaño','transparência':'transparencia','transparencia':'transparencia','aparência':'apariencia','aparencia':'apariencia','fantasia':'apariencia','número':'número','numero':'número','nome':'nombre','variável':'variable','variavel':'variable','valor':'valor','objeto':'objeto','ator':'actor','som':'sonido','texto':'texto','cor':'color','lista':'lista','item':'elemento','efeito':'efecto','efeitos':'efectos','brilho':'brillo','opacidade':'opacidad','volume':'volumen','fonte':'fuente','alinhamento':'alineación','graus':'grados','segundo':'segundo','segundos':'segundos','vez':'vez','vezes':'veces','quadro':'cuadro','pasta':'carpeta','animação':'animación','animacao':'animación','tocar':'reproducir','reproduzir':'reproducir','aplicar':'aplicar','criar':'crear','adicionar':'añadir','apagar':'borrar','remover':'eliminar','copiar':'copiar','editar':'editar','restaurar':'restaurar','limpar':'limpiar','salvar':'guardar','carregar':'cargar','atualizar':'actualizar','executar':'ejecutar','aguardar':'esperar','pausar':'pausar','retomar':'reanudar','ativar':'activar','desativar':'desactivar','detectar':'detectar','verificar':'comprobar','seguir':'seguir','afastar':'alejar','colidir':'colisionar','colisão':'colisión','colisao':'colisión','dano':'daño','vida':'vida','jogador':'jugador','jogadores':'jugadores','alvo':'objetivo','força':'fuerza','forca':'fuerza','velocidade':'velocidad','gravidade':'gravedad','câmera':'cámara','camera':'cámara','camada':'capa','controle':'control','evento':'evento','dados':'datos','caneta':'pluma','desenho':'dibujo','dispositivo':'dispositivo','idioma':'idioma','sala':'sala','partida':'partida','objetivo':'objetivo','estado':'estado','modo':'modo','padrão':'predeterminado','padrao':'predeterminado','arquivo':'archivo','caminho':'ruta','chave':'clave','resultado':'resultado','erro':'error','status':'estado','progresso':'progreso','botão':'botón','botao':'botón','sensor':'sensor','região':'región','regiao':'región','camadas':'capas','minimapa':'minimapa','placar':'marcador','moedas':'monedas','thread':'hilo','scripts':'scripts','shader':'sombreado','shaders':'sombreados','sprite':'sprite','spritesheet':'spritesheet','gif':'gif','joystick':'joystick','pad':'pad','tile':'tile','firebase':'firebase','websocket':'websocket','http':'HTTP','api':'API','npc':'NPC','ia':'IA','zoom':'zoom','fade':'fundido','painel':'panel','barra':'barra','indicador':'indicador','notificação':'notificación','notificacao':'notificación','memória':'memoria','memoria':'memoria','vibração':'vibración','vibracao':'vibración','rápido':'rápido','rapido':'rápido','completo':'completo','original':'original','local':'local','global':'global','do':'del','da':'de la','dos':'de los','das':'de las','de':'de','em':'en','no':'en el','na':'en la','nos':'en los','nas':'en las','com':'con','por':'por','a':'a','o':'el','os':'los','as':'las','e':'y','ao':'al','à':'a la','às':'a las','um':'un','uma':'una','sem':'sin','sobre':'sobre','entre':'entre','fora':'fuera','dentro':'dentro','direto':'directo','gradualmente':'gradualmente','escolher':'elegir','pedir':'pedir','falar':'decir','pensar':'pensar','piscar':'parpadear','tintar':'teñir','espelhar':'reflejar','rotacionar':'rotar','rotação':'rotación','transição':'transición','transicao':'transición','conectar':'conectar','desconectar':'desconectar','compartilhar':'compartir','entrar':'entrar','pronto':'listo','dois':'dos','duplo':'doble','curto':'corto','círculo':'círculo','circulo':'círculo','linha':'línea','emissor':'emisor','partícula':'partícula','particulas':'partículas','partículas':'partículas','radar':'radar','rede':'red','alcance':'alcance','inverter':'invertir','gerar':'generar','configurar':'configurar','contato':'contacto','contorno':'contorno','gradiente':'degradado','plataforma':'plataforma','pinça':'pinza','pinca':'pinza','pressão':'presión','pressao':'presión'
  },
  ru: {
    'quando':'когда','começar':'начинать','começa':'начинается','iniciar':'запустить','cena':'сцену','tela':'экран','tocado':'касании','pressionada':'нажата','receber':'получить','recebido':'получено','mensagem':'сообщение','enviar':'отправить','esperar':'ждать','sempre':'всегда','repita':'повторить','repetir':'повторять','até':'до','enquanto':'пока','se':'если','então':'тогда','senão':'иначе','mostrar':'показать','esconder':'скрыть','parar':'остановить','sair':'выйти','continuar':'продолжить','próxima':'следующая','próximo':'следующий','anterior':'предыдущий','reiniciar':'перезапустить','mover':'двигаться','passos':'шагов','girar':'повернуть','direita':'вправо','esquerda':'влево','ir':'перейти','para':'в','posição':'позиция','posicao':'позиция','aleatória':'случайная','aleatório':'случайный','outro':'другой','deslizar':'скользить','apontar':'направить','direção':'направление','direcao':'направление','mudar':'изменить','definir':'установить','aumentar':'увеличить','diminuir':'уменьшить','tamanho':'размер','transparência':'прозрачность','transparencia':'прозрачность','aparência':'образ','aparencia':'образ','fantasia':'образ','número':'номер','numero':'номер','nome':'имя','variável':'переменная','variavel':'переменная','valor':'значение','objeto':'объект','ator':'актёр','som':'звук','texto':'текст','cor':'цвет','lista':'список','item':'элемент','efeito':'эффект','efeitos':'эффекты','brilho':'яркость','opacidade':'непрозрачность','volume':'громкость','fonte':'шрифт','alinhamento':'выравнивание','graus':'градусов','segundo':'секунду','segundos':'секунд','vez':'раз','vezes':'раз','quadro':'кадр','pasta':'папка','animação':'анимация','animacao':'анимация','tocar':'воспроизвести','reproduzir':'воспроизвести','aplicar':'применить','criar':'создать','adicionar':'добавить','apagar':'удалить','remover':'удалить','copiar':'копировать','editar':'редактировать','restaurar':'восстановить','limpar':'очистить','salvar':'сохранить','carregar':'загрузить','atualizar':'обновить','executar':'выполнить','aguardar':'ждать','pausar':'пауза','retomar':'продолжить','ativar':'включить','desativar':'выключить','detectar':'обнаружить','verificar':'проверить','seguir':'следовать','afastar':'отдалить','colidir':'столкнуться','colisão':'столкновение','colisao':'столкновение','dano':'урон','vida':'жизнь','jogador':'игрок','jogadores':'игроки','alvo':'цель','força':'сила','forca':'сила','velocidade':'скорость','gravidade':'гравитация','câmera':'камера','camera':'камера','camada':'слой','controle':'управление','evento':'событие','dados':'данные','caneta':'перо','desenho':'рисование','dispositivo':'устройство','idioma':'язык','sala':'комната','partida':'матч','objetivo':'цель','estado':'состояние','modo':'режим','padrão':'по умолчанию','padrao':'по умолчанию','arquivo':'файл','caminho':'путь','chave':'ключ','resultado':'результат','erro':'ошибка','status':'статус','progresso':'прогресс','botão':'кнопка','botao':'кнопка','sensor':'датчик','região':'область','regiao':'область','camadas':'слои','minimapa':'мини-карта','placar':'табло','moedas':'монеты','thread':'поток','scripts':'скрипты','shader':'шейдер','shaders':'шейдеры','sprite':'спрайт','spritesheet':'таблица спрайтов','gif':'GIF','joystick':'джойстик','pad':'панель','tile':'тайл','firebase':'Firebase','websocket':'WebSocket','http':'HTTP','api':'API','npc':'НПС','ia':'ИИ','zoom':'масштаб','fade':'затухание','painel':'панель','barra':'полоса','indicador':'индикатор','notificação':'уведомление','notificacao':'уведомление','memória':'память','memoria':'память','vibração':'вибрация','vibracao':'вибрация','rápido':'быстро','rapido':'быстро','completo':'полный','original':'исходный','local':'локальный','global':'глобальный','do':'из','da':'из','dos':'из','das':'из','de':'из','em':'в','no':'в','na':'в','nos':'в','nas':'в','com':'с','por':'для','a':'','o':'','os':'','as':'','e':'и','ao':'к','à':'к','às':'к','um':'один','uma':'одна','sem':'без','sobre':'о','entre':'между','fora':'вне','dentro':'внутри','direto':'прямой','gradualmente':'постепенно','escolher':'выбрать','pedir':'спросить','falar':'сказать','pensar':'думать','piscar':'мигать','tintar':'тонировать','espelhar':'отразить','rotacionar':'повернуть','rotação':'вращение','transição':'переход','transicao':'переход','conectar':'подключить','desconectar':'отключить','compartilhar':'поделиться','entrar':'войти','pronto':'готово','dois':'два','duplo':'двойной','curto':'короткий','círculo':'круг','circulo':'круг','linha':'линия','emissor':'эмиттер','partícula':'частица','particulas':'частицы','partículas':'частицы','radar':'радар','rede':'сеть','alcance':'диапазон','inverter':'обратный','gerar':'создать','configurar':'настроить','contato':'контакт','contorno':'контур','gradiente':'градиент','plataforma':'платформа','pinça':'жест щипком','pinca':'жест щипком','pressão':'давление','pressao':'давление'
  }
};


Object.assign(KIX_AUTO_I18N.en, {
  "houver":"there is", "fazer":"do", "trazer":"bring", "medir":"measure", "desenhar":"draw", "criptografar":"encrypt", "descriptografar":"decrypt", "sombra":"shadow", "desfoque":"blur", "largura":"width", "altura":"height", "cima":"top", "baixo":"bottom", "fim":"end", "inicio":"start"
});
Object.assign(KIX_AUTO_I18N.es, {
  "houver":"haya", "fazer":"hacer", "trazer":"llevar", "medir":"medir", "desenhar":"dibujar", "criptografar":"cifrar", "descriptografar":"descifrar", "sombra":"sombra", "desfoque":"desenfoque", "largura":"ancho", "altura":"alto", "cima":"arriba", "baixo":"abajo", "fim":"fin", "inicio":"inicio"
});
Object.assign(KIX_AUTO_I18N.ru, {
  "houver":"есть", "fazer":"сделать", "trazer":"переместить", "medir":"измерить", "desenhar":"рисовать", "criptografar":"зашифровать", "descriptografar":"расшифровать", "sombra":"тень", "desfoque":"размытие", "largura":"ширина", "altura":"высота", "cima":"сверху", "baixo":"снизу", "fim":"конец", "inicio":"начало"
});


Object.assign(KIX_UI_PHRASE_I18N.en, {
    "Bem-vindo ao Kix": "Welcome to Kix",
    "Nenhum projeto ainda. Toque em + para criar.": "No projects yet. Tap + to create one.",
    "Nenhum projeto ainda.": "No projects yet.",
    "Toque em + para criar.": "Tap + to create one.",
    "Criar pasta": "Create folder",
    "Renomear": "Rename",
    "Duplicar": "Duplicate",
    "Editar colisão": "Edit collision",
    "Excluir": "Delete",
    "Projects": "Projects",
    "Choose a project item": "Choose a project item",
    "NEW PROJECT": "NEW PROJECT",
    "Empty project": "Empty project",
    "Kix test game": "Kix test game",
    "Named project": "Named project",
    "ADD OBJECT": "ADD OBJECT",
    "Empty object": "Empty object",
    "Import from gallery": "Import from gallery",
    "Take photo": "Take photo",
    "Import .kix": "Import .kix",
    "Backpack": "Backpack",
    "Settings": "Settings",
    "Quick tutorial": "Quick tutorial",
    "About Kix": "About Kix",
    "ADD LOOK": "ADD LOOK",
    "Choose image": "Choose image",
    "Empty look": "Empty look",
    "ADD SOUND": "ADD SOUND",
    "Choose audio file": "Choose audio file",
    "Record audio": "Record audio",
    "OPTIONS": "OPTIONS",
    "Details": "Details",
    "OBJECT": "OBJECT",
    "LOOK": "LOOK",
    "Show": "Show",
    "Hide": "Hide",
    "Size 100%": "Size 100%",
    "Delete object": "Delete object",
    "Use as active": "Use as active",
    "Set as Pixel Art": "Set as Pixel Art",
    "New folder": "New folder",
    "Add GIF": "Add GIF",
    "Move to folder": "Move to folder",
    "Remove from folder": "Remove from folder",
    "Delete look": "Delete look"
  });

Object.assign(KIX_UI_PHRASE_I18N.es, {
    "Bem-vindo ao Kix": "Bienvenido a Kix",
    "Nenhum projeto ainda. Toque em + para criar.": "Aún no hay proyectos. Toca + para crear uno.",
    "Nenhum projeto ainda.": "Aún no hay proyectos.",
    "Toque em + para criar.": "Toca + para crear uno.",
    "Criar pasta": "Crear carpeta",
    "Renomear": "Renombrar",
    "Duplicar": "Duplicar",
    "Editar colisão": "Editar colisión",
    "Excluir": "Eliminar",
    "Projects": "Proyectos",
    "Choose a project item": "Elige un elemento del proyecto",
    "NEW PROJECT": "NUEVO PROYECTO",
    "Empty project": "Proyecto vacío",
    "Kix test game": "Juego de prueba de Kix",
    "Named project": "Proyecto con nombre",
    "ADD OBJECT": "AÑADIR OBJETO",
    "Empty object": "Objeto vacío",
    "Import from gallery": "Importar desde la galería",
    "Take photo": "Tomar foto",
    "Import .kix": "Importar .kix",
    "Backpack": "Mochila",
    "Settings": "Configuración",
    "Quick tutorial": "Mini tutorial",
    "About Kix": "Acerca de Kix",
    "ADD LOOK": "AÑADIR APARIENCIA",
    "Choose image": "Elegir imagen",
    "Empty look": "Apariencia vacía",
    "ADD SOUND": "AÑADIR SONIDO",
    "Choose audio file": "Elegir archivo de audio",
    "Record audio": "Grabar audio",
    "OPTIONS": "OPCIONES",
    "Details": "Detalles",
    "OBJECT": "OBJETO",
    "LOOK": "APARIENCIA",
    "Show": "Mostrar",
    "Hide": "Ocultar",
    "Size 100%": "Tamaño 100%",
    "Delete object": "Eliminar objeto",
    "Use as active": "Usar como activa",
    "Set as Pixel Art": "Establecer como Pixel Art",
    "New folder": "Nueva carpeta",
    "Add GIF": "Añadir GIF",
    "Move to folder": "Mover a carpeta",
    "Remove from folder": "Quitar de la carpeta",
    "Delete look": "Eliminar apariencia"
  });

Object.assign(KIX_UI_PHRASE_I18N.ru, {
    "Bem-vindo ao Kix": "Добро пожаловать в Kix",
    "Nenhum projeto ainda. Toque em + para criar.": "Пока нет проектов. Нажмите +, чтобы создать.",
    "Nenhum projeto ainda.": "Пока нет проектов.",
    "Toque em + para criar.": "Нажмите +, чтобы создать.",
    "Criar pasta": "Создать папку",
    "Renomear": "Переименовать",
    "Duplicar": "Дублировать",
    "Editar colisão": "Изменить столкновение",
    "Excluir": "Удалить",
    "Projects": "Проекты",
    "Choose a project item": "Выберите элемент проекта",
    "NEW PROJECT": "НОВЫЙ ПРОЕКТ",
    "Empty project": "Пустой проект",
    "Kix test game": "Тестовая игра Kix",
    "Named project": "Именованный проект",
    "ADD OBJECT": "ДОБАВИТЬ ОБЪЕКTO",
    "Empty object": "Пустой объект",
    "Import from gallery": "Импортировать из галереи",
    "Take photo": "Сделать фото",
    "Import .kix": "Импорт .kix",
    "Backpack": "Рюкзак",
    "Settings": "Настройки",
    "Quick tutorial": "Мини-урок",
    "About Kix": "О Kix",
    "ADD LOOK": "ДОБАВИТЬ ОБРАЗ",
    "Choose image": "Выбрать изображение",
    "Empty look": "Пустой образ",
    "ADD SOUND": "ДОБАВИТЬ ЗВУК",
    "Choose audio file": "Выбрать аудиофайл",
    "Record audio": "Записать аудио",
    "OPTIONS": "НАСТРОЙКИ",
    "Details": "Подробности",
    "OBJECT": "ОБЪЕКТ",
    "LOOK": "ОБРАЗ",
    "Show": "Показать",
    "Hide": "Скрыть",
    "Size 100%": "Размер 100%",
    "Delete object": "Удалить объект",
    "Use as active": "Использовать как активный",
    "Set as Pixel Art": "Установить Pixel Art",
    "New folder": "Новая папка",
    "Add GIF": "Добавить GIF",
    "Move to folder": "Переместить в папку",
    "Remove from folder": "Удалить из папки",
    "Delete look": "Удалить образ"
  });
Object.assign(KIX_UI_PHRASE_I18N.en, {
  "Projetos": "Projects",
  "Bem-vindo ao Kix": "Welcome to Kix",
  "Nenhum projeto ainda. Toque em + para criar.": "No projects yet. Tap + to create one.",
  "Nenhum projeto ainda.": "No projects yet.",
  "Toque em + para criar.": "Tap + to create one.",
  "Selecionar": "Select",
  "Escolha um item do projeto": "Choose a project item",
  "NOVO PROJETO": "NEW PROJECT",
  "Projeto vazio": "Empty project",
  "Jogo de teste Kix": "Kix test game",
  "Projeto com nome": "Named project",
  "ADICIONAR OBJETO": "ADD OBJECT",
  "Objeto vazio": "Empty object",
  "Importar da galeria": "Import from gallery",
  "Tirar foto": "Take photo",
  "Importar .kix": "Import .kix",
  "Mochila": "Backpack",
  "Configurações": "Settings",
  "Mini tutorial": "Quick tutorial",
  "Sobre o Kix": "About Kix",
  "ADICIONAR APARÊNCIA": "ADD LOOK",
  "Selecionar imagem": "Choose image",
  "Aparência vazia": "Empty look",
  "ADICIONAR SOM": "ADD SOUND",
  "Selecionar arquivo de áudio": "Choose audio file",
  "Gravar áudio": "Record audio",
  "OPÇÕES": "OPTIONS",
  "Criar pasta": "Create folder",
  "Renomear objeto": "Rename object",
  "Detalhes": "Details",
  "OBJETO": "OBJECT",
  "Renomear": "Rename",
  "Duplicar": "Duplicate",
  "Definir posição (0,0)": "Set position (0,0)",
  "Mostrar": "Show",
  "Esconder": "Hide",
  "Tamanho 100%": "Size 100%",
  "Editar colisão": "Edit collision",
  "Excluir objeto": "Delete object",
  "APARÊNCIA": "LOOK",
  "Usar como ativa": "Use as active",
  "Definir como Pixel Art": "Set as Pixel Art",
  "Nova pasta": "New folder",
  "Adicionar GIF": "Add GIF",
  "Mover para pasta": "Move to folder",
  "Tirar da pasta": "Remove from folder",
  "Apagar aparência": "Delete look",
  "Projects": "Projects",
  "Select": "Select",
  "Choose a project item": "Choose a project item",
  "NEW PROJECT": "NEW PROJECT",
  "Empty project": "Empty project",
  "Named project": "Named project",
  "ADD OBJECT": "ADD OBJECT",
  "Empty object": "Empty object",
  "Import from gallery": "Import from gallery",
  "Take photo": "Take photo",
  "Import .kix": "Import .kix",
  "Backpack": "Backpack",
  "Settings": "Settings",
  "Quick tutorial": "Quick tutorial",
  "About Kix": "About Kix",
  "ADD LOOK": "ADD LOOK",
  "Choose image": "Choose image",
  "Empty look": "Empty look",
  "ADD SOUND": "ADD SOUND",
  "Choose audio file": "Choose audio file",
  "Record audio": "Record audio",
  "OPTIONS": "OPTIONS",
  "Create folder": "Create folder",
  "Rename object": "Rename object",
  "Details": "Details",
  "OBJECT": "OBJECT",
  "Rename": "Rename",
  "Duplicate": "Duplicate",
  "Set position (0,0)": "Set position (0,0)",
  "Show": "Show",
  "Hide": "Hide",
  "Size 100%": "Size 100%",
  "Edit collision": "Edit collision",
  "Delete object": "Delete object",
  "LOOK": "LOOK",
  "Use as active": "Use as active",
  "Set as Pixel Art": "Set as Pixel Art",
  "New folder": "New folder",
  "Add GIF": "Add GIF",
  "Move to folder": "Move to folder",
  "Remove from folder": "Remove from folder",
  "Delete look": "Delete look"
});
Object.assign(KIX_UI_PHRASE_I18N.es, {
  "Projetos": "Proyectos",
  "Bem-vindo ao Kix": "Bienvenido a Kix",
  "Nenhum projeto ainda. Toque em + para criar.": "Aún no hay proyectos. Toca + para crear uno.",
  "Nenhum projeto ainda.": "Aún no hay proyectos.",
  "Toque em + para criar.": "Toca + para crear uno.",
  "Selecionar": "Seleccionar",
  "Escolha um item do projeto": "Elige un elemento del proyecto",
  "NOVO PROJETO": "NUEVO PROYECTO",
  "Projeto vazio": "Proyecto vacío",
  "Jogo de teste Kix": "Juego de prueba de Kix",
  "Projeto com nome": "Proyecto con nombre",
  "ADICIONAR OBJETO": "AÑADIR OBJETO",
  "Objeto vazio": "Objeto vacío",
  "Importar da galeria": "Importar desde la galería",
  "Tirar foto": "Tomar foto",
  "Importar .kix": "Importar .kix",
  "Mochila": "Mochila",
  "Configurações": "Configuración",
  "Mini tutorial": "Mini tutorial",
  "Sobre o Kix": "Acerca de Kix",
  "ADICIONAR APARÊNCIA": "AÑADIR APARIENCIA",
  "Selecionar imagem": "Elegir imagen",
  "Aparência vazia": "Apariencia vacía",
  "ADICIONAR SOM": "AÑADIR SONIDO",
  "Selecionar arquivo de áudio": "Elegir archivo de audio",
  "Gravar áudio": "Grabar audio",
  "OPÇÕES": "OPCIONES",
  "Criar pasta": "Crear carpeta",
  "Renomear objeto": "Renombrar objeto",
  "Detalhes": "Detalles",
  "OBJETO": "OBJETO",
  "Renomear": "Renombrar",
  "Duplicar": "Duplicar",
  "Definir posição (0,0)": "Establecer posición (0,0)",
  "Mostrar": "Mostrar",
  "Esconder": "Ocultar",
  "Tamanho 100%": "Tamaño 100%",
  "Editar colisão": "Editar colisión",
  "Excluir objeto": "Eliminar objeto",
  "APARÊNCIA": "APARIENCIA",
  "Usar como ativa": "Usar como activa",
  "Definir como Pixel Art": "Establecer como Pixel Art",
  "Nova pasta": "Nueva carpeta",
  "Adicionar GIF": "Añadir GIF",
  "Mover para pasta": "Mover a carpeta",
  "Tirar da pasta": "Quitar de la carpeta",
  "Apagar aparência": "Eliminar apariencia",
  "Projects": "Proyectos",
  "Select": "Seleccionar",
  "Choose a project item": "Elige un elemento del proyecto",
  "NEW PROJECT": "NUEVO PROYECTO",
  "Empty project": "Proyecto vacío",
  "Named project": "Proyecto con nombre",
  "ADD OBJECT": "AÑADIR OBJETO",
  "Empty object": "Objeto vacío",
  "Import from gallery": "Importar desde la galería",
  "Take photo": "Tomar foto",
  "Import .kix": "Importar .kix",
  "Backpack": "Mochila",
  "Settings": "Configuración",
  "Quick tutorial": "Mini tutorial",
  "About Kix": "Acerca de Kix",
  "ADD LOOK": "AÑADIR APARIENCIA",
  "Choose image": "Elegir imagen",
  "Empty look": "Apariencia vacía",
  "ADD SOUND": "AÑADIR SONIDO",
  "Choose audio file": "Elegir archivo de audio",
  "Record audio": "Grabar audio",
  "OPTIONS": "OPCIONES",
  "Create folder": "Crear carpeta",
  "Rename object": "Renombrar objeto",
  "Details": "Detalles",
  "OBJECT": "OBJETO",
  "Rename": "Renombrar",
  "Duplicate": "Duplicar",
  "Set position (0,0)": "Establecer posición (0,0)",
  "Show": "Mostrar",
  "Hide": "Ocultar",
  "Size 100%": "Tamaño 100%",
  "Edit collision": "Editar colisión",
  "Delete object": "Eliminar objeto",
  "LOOK": "APARIENCIA",
  "Use as active": "Usar como activa",
  "Set as Pixel Art": "Establecer como Pixel Art",
  "New folder": "Nueva carpeta",
  "Add GIF": "Añadir GIF",
  "Move to folder": "Mover a carpeta",
  "Remove from folder": "Quitar de la carpeta",
  "Delete look": "Eliminar apariencia"
});
Object.assign(KIX_UI_PHRASE_I18N.ru, {
  "Projetos": "Проекты",
  "Bem-vindo ao Kix": "Добро пожаловать в Kix",
  "Nenhum projeto ainda. Toque em + para criar.": "Пока нет проектов. Нажмите +, чтобы создать.",
  "Nenhum projeto ainda.": "Пока нет проектов.",
  "Toque em + para criar.": "Нажмите +, чтобы создать.",
  "Selecionar": "Выбрать",
  "Escolha um item do projeto": "Выберите элемент проекта",
  "NOVO PROJETO": "НОВЫЙ ПРОЕКТ",
  "Projeto vazio": "Пустой проект",
  "Jogo de teste Kix": "Тестовая игра Kix",
  "Projeto com nome": "Именованный проект",
  "ADICIONAR OBJETO": "ДОБАВИТЬ ОБЪЕКТ",
  "Objeto vazio": "Пустой объект",
  "Importar da galeria": "Импортировать из галереи",
  "Tirar foto": "Сделать фото",
  "Importar .kix": "Импорт .kix",
  "Mochila": "Рюкзак",
  "Configurações": "Настройки",
  "Mini tutorial": "Мини-урок",
  "Sobre o Kix": "О Kix",
  "ADICIONAR APARÊNCIA": "ДОБАВИТЬ ОБРАЗ",
  "Selecionar imagem": "Выбрать изображение",
  "Aparência vazia": "Пустой образ",
  "ADICIONAR SOM": "ДОБАВИТЬ ЗВУК",
  "Selecionar arquivo de áudio": "Выбрать аудиофайл",
  "Gravar áudio": "Записать аудио",
  "OPÇÕES": "НАСТРОЙКИ",
  "Criar pasta": "Создать папку",
  "Renomear objeto": "Переименовать объект",
  "Detalhes": "Подробности",
  "OBJETO": "ОБЪЕКТ",
  "Renomear": "Переименовать",
  "Duplicar": "Дублировать",
  "Definir posição (0,0)": "Задать позицию (0,0)",
  "Mostrar": "Показать",
  "Esconder": "Скрыть",
  "Tamanho 100%": "Размер 100%",
  "Editar colisão": "Изменить столкновение",
  "Excluir objeto": "Удалить объект",
  "APARÊNCIA": "ОБРАЗ",
  "Usar como ativa": "Использовать как активный",
  "Definir como Pixel Art": "Установить Pixel Art",
  "Nova pasta": "Новая папка",
  "Adicionar GIF": "Добавить GIF",
  "Mover para pasta": "Переместить в папку",
  "Tirar da pasta": "Удалить из папки",
  "Apagar aparência": "Удалить образ",
  "Projects": "Проекты",
  "Select": "Выбрать",
  "Choose a project item": "Выберите элемент проекта",
  "NEW PROJECT": "НОВЫЙ ПРОЕКТ",
  "Empty project": "Пустой проект",
  "Named project": "Именованный проект",
  "ADD OBJECT": "ДОБАВИТЬ ОБЪЕКТ",
  "Empty object": "Пустой объект",
  "Import from gallery": "Импортировать из галереи",
  "Take photo": "Сделать фото",
  "Import .kix": "Импорт .kix",
  "Backpack": "Рюкзак",
  "Settings": "Настройки",
  "Quick tutorial": "Мини-урок",
  "About Kix": "О Kix",
  "ADD LOOK": "ДОБАВИТЬ ОБРАЗ",
  "Choose image": "Выбрать изображение",
  "Empty look": "Пустой образ",
  "ADD SOUND": "ДОБАВИТЬ ЗВУК",
  "Choose audio file": "Выбрать аудиофайл",
  "Record audio": "Записать аудио",
  "OPTIONS": "НАСТРОЙКИ",
  "Create folder": "Создать папку",
  "Rename object": "Переименовать объект",
  "Details": "Подробности",
  "OBJECT": "ОБЪЕКТ",
  "Rename": "Переименовать",
  "Duplicate": "Дублировать",
  "Set position (0,0)": "Задать позицию (0,0)",
  "Show": "Показать",
  "Hide": "Скрыть",
  "Size 100%": "Размер 100%",
  "Edit collision": "Изменить столкновение",
  "Delete object": "Удалить объект",
  "LOOK": "ОБРАЗ",
  "Use as active": "Использовать как активный",
  "Set as Pixel Art": "Установить Pixel Art",
  "New folder": "Новая папка",
  "Add GIF": "Добавить GIF",
  "Move to folder": "Переместить в папку",
  "Remove from folder": "Удалить из папки",
  "Delete look": "Удалить образ"
});

Object.assign(KIX_UI_PHRASE_I18N.en, {
  "Kix 1.7.5 — categorias unificadas · multi-toque · tolerância de cor":"Kix 1.7.5 — unified categories · multi-touch · color tolerance",
  "Sons":"Sounds", "Aparência":"Looks", "Aparências":"Looks", "Categorias":"Categories", "Atores e objetos":"Actors & objects", "Adicionar objeto":"Add object", "Adicionar aparência":"Add look", "Adicionar som":"Add sound", "Executar":"Run", "Parar":"Stop", "Pausar":"Pause", "Reiniciar":"Restart", "Voltar":"Back", "Cancelar":"Cancel", "Salvar":"Save", "Excluir":"Delete", "Mostrar":"Show", "Esconder":"Hide",
  "Opções do projeto":"Project options", "Ícone":"Icon", "Projeto":"Project", "Nome":"Name",
  "Versão do projeto":"Project version", "Descrição do projeto":"Project description",
  "Importar arquivos":"Import files", "Limpar variáveis salvas":"Clear saved variables", "Exportar .kix":"Export .kix",
  "Excluir projeto":"Delete project", "As alterações de nome e descrição são salvas automaticamente.":"Name and description changes are saved automatically.",
  "Opções do app":"App options", "Estilo das categorias":"Category style", "Análise de código em tempo real":"Real-time code analysis",
  "Salvamento automático":"Auto-save", "Salvamento automático ativo":"Auto-save enabled", "Salvamento automático pausado":"Auto-save paused",
  "Toques com resposta visual":"Touch feedback", "Grade do palco por padrão":"Stage grid by default",
  "Mostrar colisões":"Show collisions", "mostrar colisões":"Show collisions", "Excluir bloco":"Delete block",
  "Ativar bloco":"Enable block", "Desativar bloco":"Disable block", "Linter de scripts":"Script linter", "Estilo de categorias":"Category style"
});
Object.assign(KIX_UI_PHRASE_I18N.es, {
  "Kix 1.7.5 — categorias unificadas · multi-toque · tolerância de cor":"Kix 1.7.5 — categorías unificadas · multitáctil · tolerancia de color",
  "Sons":"Sonidos", "Aparência":"Apariencia", "Aparências":"Apariencias", "Categorias":"Categorías", "Atores e objetos":"Actores y objetos", "Adicionar objeto":"Añadir objeto", "Adicionar aparência":"Añadir apariencia", "Adicionar som":"Añadir sonido", "Executar":"Ejecutar", "Parar":"Detener", "Pausar":"Pausar", "Reiniciar":"Reiniciar", "Voltar":"Volver", "Cancelar":"Cancelar", "Salvar":"Guardar", "Excluir":"Eliminar", "Mostrar":"Mostrar", "Esconder":"Ocultar",
  "Opções do projeto":"Opciones del proyecto", "Ícone":"Icono", "Projeto":"Proyecto", "Nome":"Nombre",
  "Versão do projeto":"Versión del proyecto", "Descrição do projeto":"Descripción del proyecto",
  "Importar arquivos":"Importar archivos", "Limpar variáveis salvas":"Borrar variables guardadas", "Exportar .kix":"Exportar .kix",
  "Excluir projeto":"Eliminar proyecto", "As alterações de nome e descrição são salvas automaticamente.":"Los cambios de nombre y descripción se guardan automáticamente.",
  "Opções do app":"Opciones de la app", "Estilo das categorias":"Estilo de categorías", "Análise de código em tempo real":"Análisis de código en tiempo real",
  "Salvamento automático":"Guardado automático", "Salvamento automático ativo":"Guardado automático activado", "Salvamento automático pausado":"Guardado automático pausado",
  "Toques com resposta visual":"Respuesta visual al tocar", "Grade do palco por padrão":"Cuadrícula del escenario por defecto",
  "Mostrar colisões":"Mostrar colisiones", "mostrar colisões":"Mostrar colisiones", "Excluir bloco":"Eliminar bloque",
  "Ativar bloco":"Activar bloque", "Desativar bloco":"Desactivar bloque", "Linter de scripts":"Analizador de scripts", "Estilo de categorias":"Estilo de categorías"
});
Object.assign(KIX_UI_PHRASE_I18N.ru, {
  "Kix 1.7.5 — categorias unificadas · multi-toque · tolerância de cor":"Kix 1.7.5 — единые категории · мультитач · допуск цвета",
  "Sons":"Звуки", "Aparência":"Внешность", "Aparências":"Образы", "Categorias":"Категории", "Atores e objetos":"Объекты", "Adicionar objeto":"Добавить объект", "Adicionar aparência":"Добавить образ", "Adicionar som":"Добавить звук", "Executar":"Запустить", "Parar":"Остановить", "Pausar":"Пауза", "Reiniciar":"Перезапустить", "Voltar":"Назад", "Cancelar":"Отмена", "Salvar":"Сохранить", "Excluir":"Удалить", "Mostrar":"Показать", "Esconder":"Скрыть",
  "Opções do projeto":"Параметры проекта", "Ícone":"Значок", "Projeto":"Проект", "Nome":"Имя",
  "Versão do projeto":"Версия проекта", "Descrição do projeto":"Описание проекта",
  "Importar arquivos":"Импортировать файлы", "Limpar variáveis salvas":"Очистить сохранённые переменные", "Exportar .kix":"Экспорт .kix",
  "Excluir projeto":"Удалить проект", "As alterações de nome e descrição são salvas automaticamente.":"Изменения имени и описания сохраняются автоматически.",
  "Opções do app":"Настройки приложения", "Estilo das categorias":"Стиль категорий", "Análise de código em tempo real":"Анализ кода в реальном времени",
  "Salvamento automático":"Автосохранение", "Salvamento automático ativo":"Автосохранение включено", "Salvamento automático pausado":"Автосохранение приостановлено",
  "Toques com resposta visual":"Отклик на касание", "Grade do palco por padrão":"Сетка сцены по умолчанию",
  "Mostrar colisões":"Показать столкновения", "mostrar colisões":"Показать столкновения", "Excluir bloco":"Удалить блок",
  "Ativar bloco":"Включить блок", "Desativar bloco":"Отключить блок", "Linter de scripts":"Анализ скриптов", "Estilo de categorias":"Стиль категорий"
});

function kixAutoTranslatePhrase(text, locale) {
  const loc = String(locale || kixCurrentLocale?.() || 'pt-BR');
  if (loc === 'pt-BR' || !KIX_AUTO_I18N[loc]) return String(text == null ? '' : text);
  let out = String(text == null ? '' : text);
  const protectedTokens = [];
  out = out.replace(/\{[^}]+\}/g, m => { const id = protectedTokens.length; protectedTokens.push(m); return `\uE000${id}\uE001`; });
  const dict = KIX_AUTO_I18N[loc];
  const entries = Object.entries(dict).sort((a,b)=>b[0].length-a[0].length);
  for (const [from,to] of entries) {
    const re = new RegExp(`(^|[^A-Za-zÀ-ÿ0-9_])${from.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}(?=$|[^A-Za-zÀ-ÿ0-9_])`, 'gi');
    out = out.replace(re, (_,pre) => `${pre}${to}`);
  }
  out = out.replace(/\uE000(\d+)\uE001/g, (_,i) => protectedTokens[Number(i)] || '');
  return out.replace(/\s+/g,' ').replace(/\s+([,.;:!?])/g,'$1').trim();
}

function kixAutoTranslateUiText(text, locale) {
  const v=String(text == null ? '' : text);
  if (!v.trim() || locale === 'pt-BR') return v;
  const exact = KIX_UI_PHRASE_I18N[locale]?.[v.trim()];
  if (exact) return exact;
  return kixAutoTranslatePhrase(v, locale);
}

const KIX_UI_TRANSLATE_SKIP = [
  'script','style','input','textarea','select','option','[contenteditable="true"]',
  '[data-kix-i18n]',
  '.pc-block','.param','.project-card','.actor-item','.look-item','.look-folder','.scene-item','.sound-item',
  '.scene-name','#project-title','#script-title','#script-blocks','#kix-user-content'
].join(',');
function kixTranslateUiTree(root=document.body) {
  const loc=kixCurrentLocale();
  if(!root) return;
  try {
    const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
    const nodes=[];
    while(walker.nextNode()) {
      const node=walker.currentNode; const el=node.parentElement;
      if(!el || el.closest(KIX_UI_TRANSLATE_SKIP)) continue;
      const raw=String(node.nodeValue||''); const core=raw.trim();
      if(!core || /^[-+]?\d+(?:[.,]\d+)?%?$/.test(core)) continue;
      const source=String(node.__kixI18nSource || el.dataset.kixI18nSource || core).trim();
      node.__kixI18nSource=source;
      nodes.push({node,raw,source});
    }
    if(loc==='pt-BR') return;
    nodes.forEach(({node,raw,source})=>{
      const owner=node.parentElement;
      const byId=owner?.id && KIX_APP_TEXT_I18N[owner.id]?.[loc];
      const next=byId || kixAutoTranslateUiText(source,loc);
      const core=raw.trim();
      if(next && next!==core) {
        const leading=raw.match(/^\s*/)?.[0]||''; const trailing=raw.match(/\s*$/)?.[0]||'';
        node.nodeValue=leading+next+trailing;
      }
    });
  } catch(e) { console.warn('kixTranslateUiTree',e); }
}
function kixInstallUiTranslationObserver() {
  if(window.__kixI18nObserver || typeof MutationObserver==='undefined') return;
  const root=document.body; if(!root) return;
  let scheduled=false;
  const run=()=>{scheduled=false; try{kixTranslateUiTree(root);}catch(_){}};
  window.__kixI18nObserver=new MutationObserver(()=>{if(scheduled)return; scheduled=true; (window.requestAnimationFrame||setTimeout)(run,0);});
  window.__kixI18nObserver.observe(root,{subtree:true,childList:true,characterData:true});
  run();
}

function kixCurrentLocale() {
  const raw = String(appOptions?.language || 'pt-BR');
  return KIX_SUPPORTED_LOCALES[raw] ? raw : 'pt-BR';
}
function kixT(key, fallback) {
  const loc = kixCurrentLocale();
  return KIX_UI_I18N[loc]?.[key] ?? KIX_UI_I18N['pt-BR']?.[key] ?? fallback ?? key;
}
function kixCategoryName(key, fallback) {
  const loc = kixCurrentLocale();
  return KIX_CATEGORY_I18N[key]?.[loc] || KIX_CATEGORY_I18N[key]?.['pt-BR'] || fallback || key;
}
const KIX_PARAM_EXTRA_I18N = {
  "en": {
    "raio": "radius",
    "ângulo": "angle",
    "massa": "mass",
    "atrito": "friction",
    "máscara": "mask",
    "camada": "layer",
    "força": "force",
    "orientação": "orientation",
    "ligado": "enabled",
    "taxa": "rate",
    "quadros": "frames",
    "padrão": "pattern",
    "espessura": "thickness",
    "tolerância": "tolerance",
    "id": "id",
    "partida": "match",
    "sala": "room",
    "ação": "action",
    "habilidade": "skill",
    "distância": "distance",
    "tempo": "time",
    "configuração": "configuration",
    "carpo": "body",
    "duração": "duration",
    "espacamento": "spacing",
    "angulo": "angle",
    "italico": "italic",
    "negrito": "bold",
    "sombra": "shadow",
    "contorno": "outline",
    "rotulo": "label",
    "posicao": "position",
    "fator": "factor",
    "suavidade": "smoothness",
    "escala minima": "minimum scale",
    "escala maxima": "maximum scale",
    "largura maxima": "maximum width",
    "desfoque": "blur",
    "deslocamento x": "offset X",
    "deslocamento y": "offset Y",
    "cor inicio": "start color",
    "cor fim": "end color",
    "direcao": "direction",
    "cor base": "base color",
    "cor aspas": "quote color",
    "cima": "top",
    "baixo": "bottom",
    "fundo": "background",
    "b": "B",
    "a": "A",
    "sim": "yes",
    "intervalo": "interval",
    "canal": "channel",
    "drum": "drum",
    "beats": "beats",
    "note": "note",
    "instrument": "instrument"
  },
  "es": {
    "raio": "radio",
    "ângulo": "ángulo",
    "massa": "masa",
    "atrito": "fricción",
    "máscara": "máscara",
    "camada": "capa",
    "força": "fuerza",
    "orientação": "orientación",
    "ligado": "activado",
    "taxa": "tasa",
    "quadros": "fotogramas",
    "padrão": "patrón",
    "espessura": "grosor",
    "tolerância": "tolerancia",
    "angulo": "ángulo",
    "italico": "cursiva",
    "negrito": "negrita",
    "sombra": "sombra",
    "contorno": "contorno",
    "rotulo": "etiqueta",
    "posicao": "posición",
    "fator": "factor",
    "suavidade": "suavizado",
    "escala minima": "escala mínima",
    "escala maxima": "escala máxima",
    "largura maxima": "ancho máximo",
    "desfoque": "desenfoque",
    "deslocamento x": "desplazamiento X",
    "deslocamento y": "desplazamiento Y",
    "cor inicio": "color inicial",
    "cor fim": "color final",
    "direcao": "dirección",
    "cor base": "color base",
    "cor aspas": "color de comillas",
    "cima": "arriba",
    "baixo": "abajo",
    "intervalo": "intervalo",
    "canal": "canal",
    "configuração": "configuración",
    "duração": "duración",
    "espacamento": "espaciado",
    "título": "título",
    "sala": "sala",
    "acao": "acción",
    "habilidade": "habilidad",
    "distância": "distancia"
  },
  "ru": {
    "raio": "радиус",
    "ângulo": "угол",
    "massa": "масса",
    "atrito": "трение",
    "máscara": "маска",
    "camada": "слой",
    "força": "сила",
    "orientação": "ориентация",
    "ligado": "включено",
    "taxa": "частота",
    "quadros": "кадры",
    "padrão": "шаблон",
    "espessura": "толщина",
    "tolerância": "допуск",
    "angulo": "угол",
    "italico": "курсив",
    "negrito": "жирный",
    "sombra": "тень",
    "contorno": "контур",
    "rotulo": "метка",
    "posicao": "позиция",
    "fator": "коэффициент",
    "suavidade": "сглаживание",
    "escala minima": "минимальный масштаб",
    "escala maxima": "максимальный масштаб",
    "largura maxima": "максимальная ширина",
    "desfoque": "размытие",
    "deslocamento x": "смещение X",
    "deslocamento y": "смещение Y",
    "cor inicio": "начальный цвет",
    "cor fim": "конечный цвет",
    "direcao": "направление",
    "cor base": "базовый цвет",
    "cor aspas": "цвет кавычек",
    "cima": "сверху",
    "baixo": "снизу",
    "intervalo": "интервал",
    "canal": "канал",
    "configuração": "настройки",
    "duração": "длительность",
    "espacamento": "интервал",
    "sala": "комната",
    "acao": "действие",
    "habilidade": "навык",
    "distância": "расстояние",
    "tempo": "время",
    "partida": "матч"
  }
};
const KIX_PARAM_EN_I18N = {
  'pt-BR': {background:'fundo',condition:'condição',object:'objeto',value:'valor',source:'origem',from:'início',to:'fim',scene:'cena',layers:'camada(s)',type:'tipo',degreesPerSecond:'graus/seg.',percent:'porcentagem',gravity:'gravidade',kilogram:'quilogramas',variable:'variável',file:'arquivo',and:'e',url:'URL',x:'X',y:'Y',size:'tamanho',color:'cor',aligned:'alinhamento',column:'coluna',csv:'CSV',red:'vermelho',green:'verde',blue:'azul',drum:'bateria',beats:'tempos',note:'nota',instrument:'instrumento',bpm:'BPM'},
  'en': {},
  'es': {background:'fondo',condition:'condición',object:'objeto',value:'valor',source:'origen',from:'inicio',to:'fin',scene:'escena',layers:'capa(s)',type:'tipo',degreesPerSecond:'grados/s',percent:'porcentaje',gravity:'gravedad',kilogram:'kilogramos',variable:'variable',file:'archivo',and:'y',url:'URL',x:'X',y:'Y',size:'tamaño',color:'color',aligned:'alineación',column:'columna',csv:'CSV',red:'rojo',green:'verde',blue:'azul',drum:'tambor',beats:'tiempos',note:'nota',instrument:'instrumento',bpm:'BPM'},
  'ru': {background:'фон',condition:'условие',object:'объект',value:'значение',source:'источник',from:'от',to:'до',scene:'сцена',layers:'слой(ев)',type:'тип',degreesPerSecond:'град./с',percent:'процент',gravity:'гравитация',kilogram:'кг',variable:'переменная',file:'файл',and:'и',url:'URL',x:'X',y:'Y',size:'размер',color:'цвет',aligned:'выравнивание',column:'столбец',csv:'CSV',red:'красный',green:'зелёный',blue:'синий',drum:'барабан',beats:'тактов',note:'нота',instrument:'инструмент',bpm:'BPM'}
};

function kixParamLabel(name) {
  const loc = kixCurrentLocale();
  const raw = String(name);
  return KIX_PARAM_I18N[loc]?.[raw] || KIX_PARAM_EN_I18N[loc]?.[raw] || KIX_PARAM_EXTRA_I18N[loc]?.[raw] || kixAutoTranslatePhrase(raw, loc) || raw;
}
function kixEnsureBlockTemplateParams(template, params) {
  let out=String(template==null?'':template).trim();
  const ps=(Array.isArray(params)?params:[]).map(p=>typeof p==='string'?p:(p&&p.name?String(p.name):'')).filter(Boolean);
  const present=new Set();
  String(out).replace(/\{([^}]+)\}/g,(_,k)=>{present.add(String(k));return _;});
  for(const pname of ps) if(!present.has(pname)) { out += (out?' ':'') + `{${pname}}`; present.add(pname); }
  return out;
}
function kixCatrobatTemplate(name, params) {
  const ps=(Array.isArray(params)?params:[]).map(p=>typeof p==='string'?p:(p&&p.name?String(p.name):'')).filter(Boolean);
  const block=Object.values(CATEGORIES||{}).flatMap(c=>c.blocks||[]).find(b=>b&&b.n===name);
  if(!block?.catrobatName) return '';
  let i=0;
  let out=String(block.catrobatName).replace(/…+/g,()=> ps[i++] ? `{${ps[i-1]}}` : '');
  return kixEnsureBlockTemplateParams(out,ps);
}
function kixPolishCatroidPTTemplate(template) {
  let out = String(template == null ? '' : template);
  // Small presentation rules shared by every PT-BR Brick template.
  out = out.replace(/\bX\s+\{x\}/g, 'X: {x}')
           .replace(/\bY\s+\{y\}/g, 'Y: {y}')
           .replace(/\{segundos\}s\b/g, '{segundos} segundos')
           .replace(/\{valor\}%\b/g, '{valor} %')
           .replace(/\{porcentagem\}%\b/g, '{porcentagem} %')
           .replace(/\s+([,.;:!?])/g, '$1')
           .replace(/\s{2,}/g, ' ')
           .trim();
  return out;
}

function kixBlockTemplate(name, params) {
  const n = String(name || '');
  const loc = kixCurrentLocale();
  const ps = Array.isArray(params) ? params : [];
  if (loc === 'pt-BR' && KIX_CATROID_PT_TEMPLATES[n]) return kixEnsureBlockTemplateParams(kixPolishCatroidPTTemplate(KIX_CATROID_PT_TEMPLATES[n]), ps);
  if (loc === 'pt-BR' && KIX_COMPACT_PT_TEMPLATES[n]) return kixEnsureBlockTemplateParams(kixPolishCatroidPTTemplate(KIX_COMPACT_PT_TEMPLATES[n]), ps);
  const manual = KIX_BLOCK_MANUAL_I18N[n]?.[loc];
  if (manual) return kixEnsureBlockTemplateParams(loc === 'pt-BR' ? kixPolishCatroidPTTemplate(manual) : manual, ps);
  const translated = KIX_BLOCK_I18N[loc]?.[n];
  if (translated) return kixEnsureBlockTemplateParams(loc === 'pt-BR' ? kixPolishCatroidPTTemplate(translated) : translated, ps);
  const extra = KIX_BLOCK_EXTRA_I18N[loc]?.[n];
  if (extra) return kixEnsureBlockTemplateParams(loc === 'pt-BR' ? kixPolishCatroidPTTemplate(extra) : extra, ps);
  if (loc === 'en') {
    const catrobat = kixCatrobatTemplate(n, ps);
    if (catrobat) return catrobat;
  }
  if (loc === 'pt-BR') return kixEnsureBlockTemplateParams(kixPolishCatroidPTTemplate(kixCatroidLikeFallbackTemplate(BLOCK_VISUAL_LABELS[n] || n, ps)), ps) || null;
  const base = BLOCK_VISUAL_LABELS[n] || n;
  return kixEnsureBlockTemplateParams(kixAutoTranslatePhrase(String(base), loc), ps) || null;
}
function kixSetLanguage(locale) {
  const next = KIX_SUPPORTED_LOCALES[locale] ? locale : 'pt-BR';
  appOptions.language = next;
  try { localStorage.setItem('kix_app_options', JSON.stringify(appOptions)); } catch (_) {}
  applyKixLanguage();
  try { buildCategories(); } catch (_) {}
  try {
    const activeCategory = document.body.dataset.kixCategory || window._kixActiveCategoryKey;
    if (!$('screen-blocks')?.classList.contains('hidden') && activeCategory) openCategory(activeCategory);
  } catch (_) {}
  try { if (!$('screen-scripts')?.classList.contains('hidden')) renderScripts(); } catch (_) {}
  const sel = $('app-language'); if (sel) sel.value = next;
  try { toast(KIX_SUPPORTED_LOCALES[next].label); } catch (_) {}
}
function applyKixLanguage() {
  try {
    document.documentElement.lang = kixCurrentLocale();
    document.querySelectorAll('[data-kix-i18n]').forEach(el => {
      const key = el.getAttribute('data-kix-i18n');
      const sourceText = KIX_UI_I18N['pt-BR']?.[key];
      if (sourceText) el.dataset.kixI18nSource = sourceText;
      const val = kixT(key, el.textContent);
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') el.placeholder = val;
      else el.textContent = val;
    });
    const loc = kixCurrentLocale();
    Object.entries(KIX_APP_TEXT_I18N).forEach(([id, dict]) => {
      const el = $(id); if (!el) return;
      const val = dict[loc] || dict['pt-BR'];
      const sourceText = dict['pt-BR'];
      if (sourceText) el.dataset.kixI18nSource = sourceText;
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') el.placeholder = val;
      else if (id === 'scripts-empty' || id === 'looks-empty' || id === 'sounds-empty') el.innerHTML = String(val).replace(/\n/g,'<br>');
      else el.textContent = val;
    });
    document.querySelectorAll('#script-tabs .tab-btn').forEach(btn => {
      const tab = btn.dataset.tab;
      const labels = {scripts:{'pt-BR':'Scripts',en:'Scripts',es:'Scripts',ru:'Скрипты'},looks:{'pt-BR':'Aparência',en:'Looks',es:'Apariencia',ru:'Внешность'},sounds:{'pt-BR':'Sons',en:'Sounds',es:'Sonidos',ru:'Звуки'}};
      if (labels[tab]) { btn.dataset.kixI18nSource = labels[tab]['pt-BR']; btn.textContent = labels[tab][loc] || labels[tab]['pt-BR']; }
    });
    const selected = $('app-language');
    if (selected) selected.value = kixCurrentLocale();
    kixTranslateUiTree(document.body);
    kixInstallUiTranslationObserver();
  } catch (e) { console.warn('applyKixLanguage', e); }
}

// ===== Stable block registry (production IDs) =====
// Names remain human-readable for the editor, but execution is keyed by a stable opcode.
// Existing projects are migrated by name once; newly saved blocks carry the opcode.
const KIX_BLOCK_ALIASES = {
  'Ir para X: Y:': 'Ir para X e Y',
  'Definir Gravidade Custom': 'Definir gravidade personalizada',
  'Física de Veículo': 'Configurar física de veículo',
  'Simular Explosão': 'Simular explosão',
  'Definir Restituição': 'Definir restituição',
  'Reproduzir animação': 'Reproduzir animação da pasta',
  'Repetir animação': 'Repetir animação da pasta',
  'Definir pasta como animação em loop': 'Repetir animação da pasta',
  'Parar animação em loop da pasta': 'Parar animação da pasta',
  'Definir negrito/italico': 'Definir negrito e itálico',
  'Definir espacamento entre linhas': 'Definir espaçamento entre linhas',
  'Efeito de digitacao (typewriter)': 'Efeito de digitação',
  'Quebra de linha automatica': 'Quebra de linha automática'
};
function kixStableOpcode(name) {
  const canonical = KIX_BLOCK_ALIASES[name] || name;
  let h = 2166136261;
  const s = String(canonical).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  for (let i=0;i<s.length;i++) { h ^= s.charCodeAt(i); h = Math.imul(h,16777619); }
  return 'kix.' + (h >>> 0).toString(16).padStart(8,'0');
}
const KIX_BLOCK_REGISTRY = Object.create(null);
Object.values(CATEGORIES).forEach(cat => (cat.blocks || []).forEach(b => {
  b.opcode = kixStableOpcode(b.n);
  KIX_BLOCK_REGISTRY[b.opcode] = b.n;
}));
window.KixBlockRegistry = KIX_BLOCK_REGISTRY;
window.KixBlockAliases = KIX_BLOCK_ALIASES;
try {
  Object.values(CATEGORIES||{}).forEach(cat => (cat.blocks||[]).forEach(b => {
    if (!b || !b.compatId) return;
    if (b.opcode && window.KixCatrobatBrickRegistry?.[b.compatId]) window.KixCatrobatBrickRegistry[b.compatId].opcode = b.opcode;
    if (window.KixCatrobatBrickRegistry?.[b.compatId]) {
      window.KixCatrobatBrickRegistry[b.compatId].projectName = b.n;
      window.KixCatrobatBrickRegistry[b.compatId].params = b.catrobatParams || b.p || [];
      window.KixCatrobatBrickRegistry[b.compatId].compatNative = b.compatNative !== false;
    }
  }));
} catch (_) {}
;;



// ===== YourBricks compatibility =====
function kixNormalizeCustomBrickDefinition(def, idx) {
  if (!def || typeof def !== 'object') return null;
  const name = String(def.name || '').trim();
  if (!name) return null;
  const id = String(def.id || ('custom.' + kixNormalizeBrickText(name).replace(/\s+/g,'_') + '_' + String(idx || 0)));
  const params = Array.isArray(def.params) ? def.params.map((p, pi) => {
    if (p && typeof p === 'object') return Object.assign({}, p, { name: String(p.name || ('param' + (pi + 1))) });
    return String(p || ('param' + (pi + 1)));
  }) : [];
  const sequence = Array.isArray(def.sequence) ? def.sequence.map((b, bi) => {
    if (!b) return null;
    if (typeof b === 'string') return { id:'seq_'+bi, name: b, params: [], values: {} };
    const name2 = String(b.name || '').trim();
    if (!name2) return null;
    const out = {
      id: String(b.id || ('seq_'+bi)),
      name: name2,
      params: Array.isArray(b.params) ? b.params.slice() : [],
      values: (b.values && typeof b.values === 'object') ? Object.assign({}, b.values) : {},
      disabled: b.disabled === true
    };
    ['type','loopEndId','ifEndId','ifElseId','customBrickId','brickType'].forEach(key => {
      if (b[key] != null && b[key] !== '') out[key] = (key === 'type' || key === 'brickType' || key === 'customBrickId') ? String(b[key]) : String(b[key]);
    });
    ['loopBoundaryExplicit','ifBoundaryExplicit','ifElseExplicit'].forEach(key => { if (b[key] === true) out[key] = true; });
    if (b.catrobat && typeof b.catrobat === 'object') {
      out.catrobat = {};
      ['sourceType','adapted','adaptedFrom','sourcePreserved','userDefinedBrickId'].forEach(key => {
        if (b.catrobat[key] != null) out.catrobat[key] = b.catrobat[key];
      });
    }
    return out;
  }).filter(Boolean) : [];
  const out = { id, name, params, sequence, color: def.color || null, createdAt: def.createdAt || Date.now() };
  if (def.catrobat && typeof def.catrobat === 'object') {
    out.catrobat = JSON.parse(JSON.stringify(def.catrobat));
  }
  return out;
}
function kixGetCustomBricks(project) {
  if (!project || typeof project !== 'object') return [];
  if (!Array.isArray(project.customBricks)) project.customBricks = [];
  const seen = new Set();
  const out = [];
  project.customBricks.forEach((raw, i) => {
    const def = kixNormalizeCustomBrickDefinition(raw, i);
    if (!def || seen.has(def.id)) return;
    seen.add(def.id);
    // Do not serialize internal editor-only state.
    delete def._runtime;
    out.push(def);
  });
  project.customBricks = out;
  return out;
}
function kixSyncYourBricksCategory(project) {
  // YourBricks category was intentionally removed. Keep custom-brick data/API
  // compatible for existing projects, but never recreate a visible category.
  const cat = { name:'YourBricks', blocks:[] };
  const defs = kixGetCustomBricks(project);
  const fixed = (cat.blocks || []).filter(b => !b.customBrickId && b.n !== 'Criar YourBrick');
  if (!fixed.some(b => b.n === 'Criar YourBrick')) fixed.unshift({ n:'Criar YourBrick', p:['nome'], brickType:'manager', type:'action', canContainChildren:false, canBeChild:true, allowedParent:['script'], allowedChildren:[] });
  const dynamic = defs.map(def => ({
    n: def.name, p: def.params, customBrickId: def.id, brickType:'custom', type:'custom',
    canContainChildren:false, canBeChild:true, allowedParent:['script','control'], allowedChildren:[],
    compatId:'yourbricks.define.' + def.id
  }));
  // Avoid duplicate custom entries even when a project was loaded twice.
  const seen = new Set();
  cat.blocks = fixed.concat(dynamic.filter(b => { if (seen.has(b.customBrickId)) return false; seen.add(b.customBrickId); return true; }));
  return defs;
}
function kixCreateCustomBrick(name, params, sequence, project) {
  const target = project || currentProject;
  if (!target) throw new Error('Nenhum projeto aberto');
  const defs = kixGetCustomBricks(target);
  const normalized = kixNormalizeCustomBrickDefinition({name, params, sequence}, defs.length);
  if (!normalized) throw new Error('Nome de YourBrick inválido');
  const same = defs.find(d => kixNormalizeBrickText(d.name) === kixNormalizeBrickText(normalized.name));
  if (same) return same;
  defs.push(normalized);
  target.customBricks = defs;
  kixSyncYourBricksCategory(target);
  return normalized;
}
function kixAddCustomBrickToCurrentActor(def) {
  const actors = getSceneActors();
  const actor = restoreCurrentActorContext() || currentActor || actors[currentActorIdx];
  if (!actor) throw new Error('Abra um objeto primeiro');
  if (!Array.isArray(actor.scripts)) actor.scripts = [];
  const block = {
    id: window.KixEngine?.newId ? KixEngine.newId() : ('b'+Date.now()),
    opcode: kixStableOpcode(def.name), name:def.name, params:def.params||[], values:{},
    color:def.color || CATEGORIES.yourbricks?.color || '#64748B', type:'custom', disabled:false, customBrickId:def.id,
    canContainChildren:false, canBeChild:true, allowedParent:['script','control'], allowedChildren:[]
  };
  (def.params || []).forEach(p => {
    const pn = typeof p === 'object' ? String(p.name || '') : String(p || '');
    if (pn) block.values[pn] = (typeof p === 'object' && p.default != null) ? p.default : '';
  });
  actor.scripts.push(block);
  ensureActorIdentity(actor);
  currentActor=actor; currentActorIdx=actors.indexOf(actor);
  syncActorToProject(); save(); renderScripts();
  return block;
}
window.KixYourBricks = {
  list: () => kixGetCustomBricks(currentProject).slice(),
  create: (name, params, sequence) => { const d=kixCreateCustomBrick(name,params,sequence,currentProject); syncActorToProject(); save(); buildCategories(); return d; },
  addToScript: (id) => { const d=kixGetCustomBricks(currentProject).find(x=>String(x.id)===String(id)); if(!d) throw new Error('YourBrick não encontrado'); return kixAddCustomBrickToCurrentActor(d); },
  expand: (defId, values) => {
    const d=kixGetCustomBricks(currentProject).find(x=>String(x.id)===String(defId));
    if(!d) return [];
    return JSON.parse(JSON.stringify(d.sequence || [])).map(b => ({
      name:b.name, params:b.params||[], values:Object.fromEntries(Object.entries(b.values||{}).map(([k,v]) => [k, String(v).replace(/\{([^}]+)\}/g, (_,key) => values?.[key] ?? '{'+key+'}')]))
    }));
  }
};

// ===== Extensions =====
const EXT_CATEGORIES = {
  desenhos: ['desenhos'],
  cat3d: ['cat3d']
};
let extensions = { desenhos: true, experimental: false };
try {
  extensions = JSON.parse(localStorage.getItem('kix_extensions') || '{"desenhos":true,"experimental":false}') || { desenhos: true, experimental: false };
  if (extensions.experimental === undefined && extensions.devmode !== undefined) extensions.experimental = !!extensions.devmode;
  if (extensions.experimental === undefined) extensions.experimental = false;
} catch (e) { extensions = { desenhos: true, experimental: false }; }

function isCategoryEnabled(key) {
  try {
    if (!key) return true;
    // All catalog categories visible by default
    return true;
  } catch (e) {
    return true;
  }
}

// ===== State =====
function safeParseLocal(key, fallback) { try { const v = JSON.parse(localStorage.getItem(key) || ''); return v == null ? fallback : v; } catch (_) { return fallback; } }
let projects = safeParseLocal('kix_projects', []);
let backpack = safeParseLocal('kix_backpack', []);
let globals = safeParseLocal('kix_globals', {});
let currentProject = null, currentActor = null, currentScene = 0, currentActorIdx = -1;
let activeFormulaCategory = '';
let formulaCategorySearchOpen = false;
let formulaCategoryReturn = 'formula';
let dataReturnScreen = 'formula';
let activeDataEditId = null;
let filesReturnScreen = 'project';
let formulaVal = '1', formulaTarget = null, formulaMode = 'number', formulaFresh = true;
let formulaCursorIndex = 1;
let formulaTargetRef = null;
// Snapshot of runtime variable values captured exactly when Play is closed.
// Formula evaluation after Play must use this snapshot instead of later edits.
let playClosedVariableSnapshot = null;
let formulaInternalClipboard = ''; // App-local formula clipboard with system-clipboard fallback.
let formulaResultLiveTimer = null;
let formulaHistory = [];
let formulaHistoryIndex = -1;

function updateFormulaHistoryButtons(){
  const undo = $('formula-undo');
  const redo = $('formula-redo');
  if (undo) {
    const enabled = formulaHistoryIndex > 0;
    undo.disabled = !enabled;
    undo.setAttribute('aria-disabled', String(!enabled));
  }
  if (redo) {
    const enabled = formulaHistoryIndex >= 0 && formulaHistoryIndex < formulaHistory.length - 1;
    redo.disabled = !enabled;
    redo.setAttribute('aria-disabled', String(!enabled));
  }
}

function resetFormulaHistory(){
  formulaHistory = [String(formulaVal == null ? '' : formulaVal)];
  formulaHistoryIndex = 0;
  updateFormulaHistoryButtons();
}

function setFormulaValue(next, {fresh=false, record=true, sync=true} = {}){
  const value = String(next == null ? '' : next);
  const current = String(formulaVal == null ? '' : formulaVal);
  if (value === current) {
    formulaFresh = !!fresh;
    if (sync) syncFormulaEditorUi();
    return false;
  }
  if (record) {
    if (!Array.isArray(formulaHistory) || formulaHistoryIndex < 0) resetFormulaHistory();
    formulaHistory = formulaHistory.slice(0, formulaHistoryIndex + 1);
    formulaHistory.push(value);
    formulaHistoryIndex = formulaHistory.length - 1;
  }
  formulaVal = value;
  formulaCursorIndex = Math.max(0, Math.min(formulaCursorIndex, value.length));
  formulaFresh = !!fresh;
  if (sync) syncFormulaEditorUi();
  updateFormulaHistoryButtons();
  return true;
}

function resolveFormulaTarget(){
  if (formulaTarget && document.documentElement.contains(formulaTarget)) return formulaTarget;
  const ref = formulaTargetRef;
  if (!ref) return formulaTarget = null;
  const blocks = Array.from(document.querySelectorAll('#script-blocks .pc-block:not(.loop-end):not(.if-marker)'));
  let block = null;
  if (ref.scriptIdx != null) {
    block = blocks.find(b => String(b.dataset.scriptIdx ?? '') === String(ref.scriptIdx));
  }
  if (!block && ref.blockId) {
    block = blocks.find(b => String(b.dataset.blockId || '') === String(ref.blockId));
  }
  if (!block) return formulaTarget = null;
  const params = Array.from(block.querySelectorAll('.param'));
  formulaTarget = params.find(p => String(p.dataset.param || '') === String(ref.paramKey || '')) || null;
  return formulaTarget;
}

function syncFormulaEditorUi(){
  // This function lives in the global formula state layer. The result-screen
  // controller is local to the editor initializer, so it must never be called
  // here: doing so throws a ReferenceError before the editor can open.
  $('formula-result')?.classList.add('hidden');
  renderFormulaExpr();
  const raw = String(formulaVal == null ? '' : formulaVal);
  const display = formulaDisplayValue(formulaVal);
  const param = $('formula-param');
  if (param) {
    param.textContent = display;
    param.dataset.value = raw;
    param.title = raw;
  }
  // Keep both previews live: the formula editor expression and the Brick that
  // opened the editor must reflect the same formulaVal on every mutation.
  try {
    const target = resolveFormulaTarget();
    if (target) {
      const displayValue = raw === '' ? '···' : raw;
      target.textContent = displayValue;
      target.dataset.value = raw;
      target.title = raw;
    }
  } catch (_) {
    // Preview synchronization must never prevent the formula editor from opening.
  }
}

function undoFormula(){
  if (formulaHistoryIndex <= 0) return;
  formulaHistoryIndex -= 1;
  formulaVal = formulaHistory[formulaHistoryIndex];
  formulaFresh = false;
  syncFormulaEditorUi();
  updateFormulaHistoryButtons();
}

function redoFormula(){
  if (formulaHistoryIndex < 0 || formulaHistoryIndex >= formulaHistory.length - 1) return;
  formulaHistoryIndex += 1;
  formulaVal = formulaHistory[formulaHistoryIndex];
  formulaFresh = false;
  syncFormulaEditorUi();
  updateFormulaHistoryButtons();
}
let isPlaying = false, showAxes = false, freeCam = false;
let stageGrid = false;
let appOptions = safeParseLocal('kix_app_options', {autosave:true, compact:false, feedback:true, toasts:true, grid:false, language:'pt-BR', kixQualityEnabled:false});
if (appOptions.kixQualityEnabled !== true) appOptions.kixQualityEnabled = false;
if (!Object.prototype.hasOwnProperty.call(appOptions, 'toasts')) appOptions.toasts = true;
let globalsPanelTimer = null;
let lookSelection = new Set();

let activeScriptTab = 'scripts';
let catStyle = (() => { try { return localStorage.getItem('kix_cat_style') || 'classic'; } catch (_) { return 'classic'; } })();
let camX = 0, camY = 0, camZoom = 1;
let camDragging = false, camLastX = 0, camLastY = 0;
let camPinchDist = 0;
let playChromeHidden = false;
let playCleanHistoryActive = false;
const visualPositionState = { active:false, blockIdx:null, mode:'', actorId:'', actorIdx:-1, original:{x:null,y:null}, placed:{x:0,y:0}, listenersBound:false, dragging:false };

function $(id) { return document.getElementById(id); }

// UI icon primitives: SVG only.
function kixSvgIcon(name, size=18) {
  const paths = {
    more: '<circle cx="12" cy="5" r="1.35"/><circle cx="12" cy="12" r="1.35"/><circle cx="12" cy="19" r="1.35"/>',
    chevron: '<path d="M6 9l6 6 6-6"/>',
    target: '<circle cx="12" cy="12" r="7"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4"/>',
    calculator: '<rect x="4" y="3" width="16" height="18" rx="2.5"/><path d="M8 7h8"/><path d="M8 11h2M14 11h2M8 15h2M14 15h2"/>',
    check: '<path d="m5 12 4 4 10-10"/>',
    close: '<path d="M6 6l12 12M18 6 6 18"/>'
  };
  return `<svg class="kix-svg-icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.more}</svg>`;
}

window.onerror = function (msg, src, line, col, err) {
  console.error('Kix error:', msg, src, line, col, err);
  return false;
};
window.addEventListener('unhandledrejection', function (e) {
  console.error('Kix unhandled:', e.reason);
});

let _kixSaveTimer = null;
let _kixIdleId = null;
let _kixSaveBusy = false;
let _kixDirty = false;

function save() {
  // Keep editor actions synchronous only in memory. Heavy persistence runs in idle time.
  try {
    syncActorToProject();
    _kixDirty = true;
    if (typeof projects !== 'undefined' && appOptions.autosave !== false) scheduleKixPersistence();
  } catch (e) { console.warn('save', e); }
}

// Public app bridge: keeps quality/diagnostic modules out of the giant UI file
// while exposing only authoritative state operations. No module may mutate
// currentProject directly without going through this bridge.
window.KixProjectAPI = Object.freeze({
  getCurrentProject: () => currentProject,
  getCurrentActor: () => currentActor,
  getCurrentSceneIndex: () => currentScene,
  getProjects: () => Array.isArray(projects) ? projects : [],
  getAppOptions: () => appOptions,
  save: () => save(),
  normalize: (project) => normalizeKixProject(project),
  show: (name, opts) => show(name, opts),
  back: () => navBack(),
  openProject: (idx, opts) => openProject(idx, opts),
  toast: (message, ms) => toast(message, ms)
});

function scheduleKixPersistence() {
  clearTimeout(_kixSaveTimer);
  if (_kixIdleId != null && 'cancelIdleCallback' in window) { try { cancelIdleCallback(_kixIdleId); } catch (_) {} _kixIdleId = null; }
  _kixSaveTimer = setTimeout(() => {
    const run = () => { _kixIdleId = null; persistKixState(); };
    if ('requestIdleCallback' in window) {
      try { _kixIdleId = requestIdleCallback(run, { timeout: 1600 }); return; } catch (_) {}
    }
    setTimeout(run, 0);
  }, 650);
}

function buildLightProjectMirror() {
  // No image payloads in the local mirror; the complete project is kept in IndexedDB.
  return (projects || []).map(p => ({
    id: p?.id, name: p?.name || 'Projeto', description: p?.description || '', version: p?.version || KIX_APP_VERSION,
    updatedAt: p?.updatedAt || Date.now(), orientation: p?.orientation || 'portrait',
    scenes: (p?.scenes || []).map(s => ({
      name: s?.name || 'Cena',
      actors: (s?.actors || []).map(a => ({
        id: a?.id, name: a?.name || 'Objeto', x: a?.x || 0, y: a?.y || 0,
        visible: a?.visible !== false, size: a?.size ?? 100, image: a?.image ? '[asset]' : null,
        looks: Array.isArray(a?.looks) ? a.looks.map(() => '[asset]') : [],
        folders: Array.isArray(a?.folders) ? a.folders.map(f => ({
          name: f?.name || 'Pasta', looks: Array.isArray(f?.looks) ? f.looks.map(() => '[asset]') : []
        })) : []
      }))
    }))
  }));
}

async function persistKixState() {
  if (_kixSaveBusy || !_kixDirty) return;
  _kixSaveBusy = true;
  _kixDirty = false;
  try {
    let storedInIDB = false;
    if (window.indexedDB) {
      try { await putKixIDB('projects', projects || []); storedInIDB = true; }
      catch (e) { console.warn('IDB project persistence', e); }
    }
    // Only use the synchronous full-project path as a compatibility fallback for
    // WebViews/browsers with no working IndexedDB. It still runs outside the tap path.
    if (!storedInIDB) {
      try { localStorage.setItem('kix_projects', JSON.stringify(projects || [])); }
      catch (e) { console.warn('localStorage project persistence', e); _kixDirty = true; }
    } else {
      try { localStorage.removeItem('kix_projects'); } catch (_) {}
    }
    try { localStorage.setItem('kix_projects_meta', JSON.stringify(buildLightProjectMirror())); } catch (_) {}
    try { localStorage.setItem('kix_globals', JSON.stringify(globals || {})); } catch (_) {}
    try { localStorage.setItem('kix_extensions', JSON.stringify(extensions || {})); } catch (_) {}
  } finally { _kixSaveBusy = false; }
}

function putKixIDB(key, value) {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) return reject(new Error('IndexedDB indisponível'));
    const req = indexedDB.open('KixSafeStore', 1);
    req.onupgradeneeded = () => { if (!req.result.objectStoreNames.contains('state')) req.result.createObjectStore('state'); };
    req.onerror = () => reject(req.error);
    req.onsuccess = () => {
      const db=req.result;
      let tx;
      try { tx=db.transaction('state','readwrite'); tx.objectStore('state').put(value,key); } catch (e) { try { db.close(); } catch (_) {} reject(e); return; }
      tx.oncomplete=()=>{try{db.close()}catch(_){};resolve(true)};
      tx.onerror=()=>{try{db.close()}catch(_){};reject(tx.error)};
    };
  });
}
function getKixIDB(key) {
  return new Promise((resolve,reject)=>{
    if(!window.indexedDB) return resolve(null);
    const req=indexedDB.open('KixSafeStore',1);
    req.onupgradeneeded=()=>{ if (!req.result.objectStoreNames.contains('state')) req.result.createObjectStore('state'); };
    req.onerror=()=>reject(req.error);
    req.onsuccess=()=>{
      const db=req.result,tx=db.transaction('state','readonly'),r=tx.objectStore('state').get(key);
      r.onsuccess=()=>{try{db.close()}catch(_){};resolve(r.result||null)};
      r.onerror=()=>{try{db.close()}catch(_){};reject(r.error)};
    };
  });
}
async function restoreKixState() {
  try {
    const saved = await getKixIDB('projects');
    if (Array.isArray(saved) && saved.length) {
      projects = saved;
      try { localStorage.removeItem('kix_projects'); } catch (_) {}
    }
  } catch(e){ console.warn('restoreKixState',e); }
  // The Home surface is rendered once after persistence restoration. This avoids
  // a startup frame where the recent-project pencil exists and is then replaced
  // by a second project-state render.
  try { renderProjects?.(); } catch (e) { console.warn('renderProjects after restore', e); }
}

/** Write currentActor back into projects[i].scenes[s].actors[a] */
function syncActorToProject() {
  try {
    if (!currentProject || !currentActor) return;
    // Ensure currentProject is the same object inside projects[]
    let pIdx = projects.indexOf(currentProject);
    if (pIdx < 0) {
      // try match by name + updated
      pIdx = projects.findIndex(p => p && p.name === currentProject.name);
      if (pIdx >= 0) {
        projects[pIdx] = currentProject;
      } else {
        projects.unshift(currentProject);
        pIdx = 0;
      }
    }
    const scene = currentProject.scenes && currentProject.scenes[currentScene];
    if (!scene) return;
    if (!Array.isArray(scene.actors)) scene.actors = [];
    // Resolve actor index
    let aIdx = currentActorIdx;
    if (aIdx < 0 || aIdx >= scene.actors.length || scene.actors[aIdx] !== currentActor) {
      aIdx = scene.actors.indexOf(currentActor);
    }
    if (aIdx < 0) {
      // match by name
      aIdx = scene.actors.findIndex(a => a && a.name === currentActor.name);
    }
    if (aIdx >= 0) {
      // Ensure scripts is a plain array
      if (currentActor.scripts && currentActor.scripts.blocks && window.KixEngine) {
        currentActor.scripts = KixEngine.scriptsToFlat(currentActor.scripts);
      }
      if (!Array.isArray(currentActor.scripts)) currentActor.scripts = [];
      scene.actors[aIdx] = currentActor;
      currentActorIdx = aIdx;
    }
  } catch (e) { console.warn('syncActorToProject', e); }
}

function kixStableId(prefix='kix') {
  try {
    if (window.KixEngine && typeof KixEngine.newId === 'function') return String(KixEngine.newId());
  } catch (_) {}
  return prefix + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
}
function ensureProjectIdentity(project) {
  if (!project) return '';
  if (!project.kixId) project.kixId = kixStableId('project');
  return String(project.kixId);
}
function ensureActorIdentity(actor) {
  if (!actor) return '';
  if (!actor.kixId) actor.kixId = kixStableId('actor');
  return String(actor.kixId);
}
function resolveActorHint(ctx, actors) {
  const list = Array.isArray(actors) ? actors : getSceneActors();
  if (!ctx || !list.length) return null;
  if (ctx.actorId) {
    const byId = list.find(a => a && String(a.kixId || '') === String(ctx.actorId));
    if (byId) return byId;
  }
  if (Number.isInteger(Number(ctx.actorIdx)) && Number(ctx.actorIdx) >= 0) {
    const at = list[Number(ctx.actorIdx)];
    if (at && (!ctx.actorName || String(at.name || '') === String(ctx.actorName))) return at;
  }
  if (ctx.actorName) {
    const byName = list.find(a => a && String(a.name || '') === String(ctx.actorName));
    if (byName) return byName;
  }
  return null;
}
function getSceneActors() {
  try {
    if (!currentProject) return [];
    if (!Array.isArray(currentProject.files)) currentProject.files = [];
    if (!Array.isArray(currentProject.scenes)) currentProject.scenes = [{ name: 'Cena 1', actors: [] }];
    if (currentScene < 0 || currentScene >= currentProject.scenes.length) currentScene = 0;
    const scene = currentProject.scenes[currentScene];
    if (!scene) return [];
    if (!Array.isArray(scene.actors)) scene.actors = [];
    scene.actors.forEach(a => ensureActorIdentity(a));
    return scene.actors;
  } catch (e) { return []; }
}

let navStack = [];
let lastScreen = 'home';
// Where the current project editor was entered from. This prevents the editor
// from accidentally falling back into the scene screen when it was opened from Home.
let projectEntryOrigin = 'home';

// Play is a transient execution surface, not an editor destination. It must never
// become a persistent navigation-history entry; otherwise a later Back from the
// scene editor can resurrect the Play surface. Keep this rule centralized so
// every navigation path follows the same invariant.
const KIX_TRANSIENT_NAV_SCREENS = new Set(['play']);
function purgeTransientNavEntries() {
  try {
    navStack = navStack.filter(entry => !KIX_TRANSIENT_NAV_SCREENS.has(String(entry?.screen || '')));
  } catch (_) {}
}
function pushNav(screen, ctx) {
  try {
    purgeTransientNavEntries();
    if (lastScreen && lastScreen !== screen && !KIX_TRANSIENT_NAV_SCREENS.has(String(lastScreen))) {
      const top = navStack[navStack.length - 1];
      // avoid consecutive duplicates
      if (!top || top.screen !== lastScreen) {
        navStack.push({ screen: lastScreen, ctx: ctx || captureNavCtx() });
      }
      if (navStack.length > 40) navStack.shift();
    }
    lastScreen = screen;
  } catch (_) {}
}
function captureNavCtx() {
  const actorId = currentActor ? ensureActorIdentity(currentActor) : '';
  return {
    projectIdx: currentProject ? projects.indexOf(currentProject) : -1,
    projectId: currentProject ? ensureProjectIdentity(currentProject) : '',
    scene: currentScene,
    actorIdx: currentActorIdx,
    actorId,
    actorName: currentActor ? String(currentActor.name || '') : '',
    tab: (typeof currentTab !== 'undefined' ? currentTab : 'scripts')
  };
}
function clearNavStack() { navStack = []; tabNavStack = []; previousTab = 'scripts'; lastScreen = 'home'; }
// Some "close/leave this editor" shortcuts jump straight to an ancestor screen
// (e.g. the Object editor's own back arrow returning to Scene) instead of
// walking back through navBack(). Because show(screen, {noPush:true}) never
// touches navStack, a stale entry for that same screen stays sitting on top of
// the stack (it was pushed earlier, when the editor was first opened, and is
// never consumed by this shortcut). The next real Back press then pops that
// stale duplicate instead of the true previous screen, so the first press
// silently redraws the same screen and only a second press actually goes
// anywhere — this is what made Back feel like it "remembered" the wrong
// screen or skipped a level. Call this before the noPush show() to discard
// any stale entries for the screen being jumped to, keeping the stack in
// sync with where the user actually is.
function navJumpTo(screen, opts) {
  try {
    while (navStack.length && navStack[navStack.length - 1].screen === screen) {
      navStack.pop();
    }
  } catch (_) {}
  show(screen, Object.assign({ noPush: true }, opts || {}));
}
function navBack() {
  try {
    // Execution surfaces are transient. Purge any stale Play entry before
    // consuming editor history, including projects created by an older build
    // where Play could accidentally have been retained in the stack.
    purgeTransientNavEntries();
    // Every full Kix screen is real navigation history. Do not discard
    // categories/blocks/formula/data/files as if they were modals: the Android
    // Back action must return to the immediately previous screen.
    const prev = navStack.pop();
    if (!prev) {
      // Fallback ladder: scripts→scene→project→home
      if (lastScreen === 'data') { show(dataReturnScreen || 'formula', { noPush: true }); return; }
      if (lastScreen === 'scripts' || lastScreen === 'categories' || lastScreen === 'blocks' || lastScreen === 'formula' || lastScreen === 'image-picker') {
        currentActor = null;
        currentActorIdx = -1;
        show('scene', { noPush: true });
        try { renderActors(); } catch (_) {}
        return;
      }
      if (lastScreen === 'scene') {
        show('project', { noPush: true });
        try { renderScenes(); } catch (_) {}
        return;
      }
      if (currentProject) {
        show('project', { noPush: true });
        return;
      }
      show('home', { noPush: true });
      return;
    }
    lastScreen = prev.screen;
    if (prev.ctx) {
      if (prev.ctx.projectId && currentProject && String(ensureProjectIdentity(currentProject)) !== String(prev.ctx.projectId)) {
        const projectById = projects.find(p => p && String(p.kixId || '') === String(prev.ctx.projectId));
        if (projectById) currentProject = projectById;
      }
      if (prev.ctx.scene != null) currentScene = prev.ctx.scene;
      if (currentProject && (prev.ctx.actorId || Number(prev.ctx.actorIdx) >= 0 || prev.ctx.actorName)) {
        const acts = getSceneActors();
        const found = resolveActorHint(prev.ctx, acts);
        currentActor = found || null;
        currentActorIdx = found ? acts.indexOf(found) : -1;
      } else if (prev.screen === 'scene' || prev.screen === 'project') {
        currentActor = null;
        currentActorIdx = -1;
      }
      if (prev.ctx.tab && currentActor && prev.screen === 'scripts') {
        try { switchTab(prev.ctx.tab, {record:false}); previousTab = 'scripts'; } catch (_) {}
      }
    }
    show(prev.screen, { noPush: true });
    if (prev.screen === 'scripts' && currentActor) {
      try { renderScripts(); renderLooks(); renderSounds(); } catch (_) {}
    }
    if (prev.screen === 'scene') try { renderActors(); } catch (_) {}
    if (prev.screen === 'project') try { renderScenes(); } catch (_) {}
  } catch (e) {
    console.warn('navBack', e);
    show('scene', { noPush: true });
  }
}
let _kixShowToken = 0;
let _kixViewTransitionRunning = false;
function kixElementVisible(el){
  if(!el) return false;
  try { return !el.classList.contains('hidden') && getComputedStyle(el).display !== 'none' && el.getAttribute('aria-hidden') !== 'true'; } catch(_){ return false; }
}
function handleKixSystemBack(){
  try { if(window.KixPluginRuntime?.handleBack?.()) return true; } catch(_){}
  const confirm=$('confirm-popover');
  if(kixElementVisible(confirm)){ confirm.classList.add('hidden'); return true; }
  if($('sheet-backdrop')?.classList.contains('open')){ closeSheets(); return true; }
  if($('formula-category-menu')){ closeFormulaCategoryMenu(); return true; }
  if($('kix-data-mini-menu')){ closeDataMiniMenu(); return true; }
  if(document.querySelector('.kix-inline-dropdown')){ try{closeInlineResourceDropdown();}catch(_){} return true; }
  if(kixElementVisible($('block-ctx-overlay'))){ try{closeBlockContext();}catch(_){} return true; }
  if(kixElementVisible($('kix-block-search-overlay'))){ try{closeKixBlockSearch();}catch(_){} return true; }
  if(kixElementVisible($('screen-image-picker'))){ try{closeImagePicker();}catch(_){} return true; }
  if(kixElementVisible($('screen-dialog'))){ try{closeActionScreen(true);}catch(_){} return true; }
  if(window.hasRuntimeInputOverlays?.()){ try{window.closeAllRuntimeInputOverlays?.(true);}catch(_){} return true; }
  if(visualPositionState.active){ cancelVisualPositionPlacement(); return true; }
  if(lastScreen === 'play' && playChromeHidden){ setPlayCleanMode(false); return true; }
  if(kixElementVisible($('data-create-modal'))){ try{closeDataEditor();}catch(_){} return true; }
  if(kixElementVisible($('formula-text-screen'))){ try{closeFormulaTextScreen();}catch(_){} return true; }
  if(kixElementVisible($('formula-category-screen'))){ try{closeFormulaCategoryScreen();}catch(_){} return true; }
  if(lastScreen === 'play'){ try{ stopPlay(); }catch(_){ navBack(); } return true; }
  if(lastScreen === 'data'){ try{ closeDataScreen(); }catch(_){ navBack(); } return true; }
  if(lastScreen === 'formula'){ try{ closeFormula(); }catch(_){ navBack(); } return true; }
  if(lastScreen === 'scripts' && tabNavStack.length){
    const targetTab = tabNavStack.pop() || 'scripts';
    try {
      switchTab(targetTab, {record:false});
      previousTab = tabNavStack.length ? tabNavStack[tabNavStack.length - 1] : 'scripts';
    } catch(_) { try { switchTab(targetTab || 'scripts', {record:false}); } catch(__){} }
    return true;
  }
  if(lastScreen === 'scripts' && currentTab !== 'scripts'){
    try { switchTab(previousTab || 'scripts', {record:false}); previousTab = 'scripts'; } catch(_) { try { switchTab('scripts', {record:false}); } catch(__){} }
    return true;
  }
  navBack();
  return true;
}
window.KixHandleBack = handleKixSystemBack;

// Browser/WebView Back fallback for clean Play mode. Native Android shells that
// call window.KixHandleBack keep their existing path; this covers environments
// where Back is delivered as a history pop instead.
window.addEventListener('popstate', () => {
  if (!playCleanHistoryActive) return;
  playCleanHistoryActive = false;
  if (lastScreen === 'play' && playChromeHidden) {
    setPlayCleanMode(false, {fromHistory:true});
  }
});

function show(name, opts) {
  const options = opts || {};
  try { closeKixBlockSearch(); } catch (_) {}
  try { closeInlineResourceDropdown(); } catch (_) {}
  try { window.KixPluginRuntime?.closeEditorDropdowns?.(); } catch (_) {}
  const previous = lastScreen;
  if (!options.noPush) pushNav(name);
  else lastScreen = name;
  const token = ++_kixShowToken;
  try { document.documentElement.dataset.kixNav = options.noPush ? 'back' : 'forward'; } catch (_) {}
  const screens = ['home','project','project-options','project-health','publish','catrobat-loading','catrobat-report','scene','scripts','categories','blocks','formula','data','image-picker','play','settings','kix-plugins','kix-plugin-editor','app-options','files','collision','create-project','dialog','tutorial','kix-paint'];
  // EDITOR ORIENTATION INVARIANT: navigation and brick editing never request or
  // lock the Android Activity orientation. Project orientation belongs only to the
  // Play-stage presentation. The phone may rotate naturally while editing.
  const render = () => {
    // Screen navigation owns the viewport. Transient fixed overlays must never
    // survive a transition and cover the newly selected editor surface.
    try { closeSheets(); } catch (_) {}
    try { $('sheet-backdrop')?.classList.remove('open'); } catch (_) {}
    try { closeInlineResourceDropdown(); } catch (_) {}
    try { closeBlockContext(); } catch (_) {}
    try { $('confirm-popover')?.classList.add('hidden'); } catch (_) {}
    screens.forEach(n => {
      const el = $('screen-' + n);
      if (!el) return;
      const active = n === name;
      el.classList.toggle('hidden', !active);
      // The active screen is the only screen allowed to participate in layout,
      // focus, pointer events and accessibility. The hidden attribute is used in
      // addition to the legacy CSS class so stacked absolute screens can never
      // visually sit over Home.
      el.hidden = !active;
      el.setAttribute('aria-hidden', active ? 'false' : 'true');
      el.style.pointerEvents = active ? 'auto' : 'none';
      if (n === 'home') {
        const editorFab = $('btn-kix-plugin-editor-fab');
        if (editorFab) {
          let editorModeEnabled = false;
          try { editorModeEnabled = localStorage.getItem('kix_editor_mode') === '1'; } catch (_) {}
          editorFab.classList.toggle('hidden', !(active && editorModeEnabled));
        }
      }
      if (active && previous !== name) {
        el.classList.remove('kix-screen-enter');
        el.classList.add('kix-screen-enter');
        clearTimeout(el._kixScreenTimer);
        el._kixScreenTimer = setTimeout(() => {
          if (token === _kixShowToken) el.classList.remove('kix-screen-enter');
        }, 420);
      }
    });
    try { window.KixPluginRuntime?.applyUiRules?.(); } catch (_) {}
  };
  // Single synchronous render: View Transitions snapshot the whole WebView and
  // used to overlay the previous screen while the next one was already active.
  render();
}
window.toast = toast;
function toast(msg, ms = 2000) {
  if (appOptions && appOptions.toasts === false) return;
  const t = $('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), ms);
}
let dialogState = null;
let _kixRuntimeInputSeq = 0;
const _kixRuntimeInputs = new Map();
function _kixRuntimeInputLayer() {
  return $('kix-runtime-input-layer') || document.getElementById('kix-runtime-input-layer');
}
function openRuntimeInputOverlay(opts) {
  opts = opts || {};
  const layer = _kixRuntimeInputLayer();
  if (!layer) return null;
  const id = 'kix-runtime-input-' + (++_kixRuntimeInputSeq);
  const title = String(opts.title || 'Entrada de texto');
  const value = String(opts.value == null ? '' : opts.value);
  const multiline = opts.multiline === true;
  const card = document.createElement('div');
  card.className = 'kix-runtime-input-card';
  card.dataset.inputId = id;
  const main = document.createElement('div'); main.className = 'kix-runtime-input-main';
  const label = document.createElement('div'); label.className = 'kix-runtime-input-title'; label.textContent = title;
  // Runtime question/text input uses the phone's native Android IME.
  // Kix creates only the HTML input field here; it does not create a keyboard.
  const field = document.createElement(multiline ? 'textarea' : 'input');
  field.className = 'kix-runtime-input-field';
  field.value = value;
  field.autocomplete = 'off'; field.spellcheck = false;
  field.autocapitalize = 'sentences';
  field.setAttribute('inputmode', 'text');
  if (!multiline) { field.type = 'text'; field.inputMode = 'text'; }
  else { field.rows = 2; field.wrap = 'soft'; field.inputMode = 'text'; }
  field.setAttribute('aria-label', title);
  main.appendChild(label); main.appendChild(field);
  const actions = document.createElement('div'); actions.className = 'kix-runtime-input-actions';
  const cancel = document.createElement('button'); cancel.type='button'; cancel.className='kix-runtime-input-btn'; cancel.textContent='×'; cancel.setAttribute('aria-label','Fechar');
  const done = document.createElement('button'); done.type='button'; done.className='kix-runtime-input-btn kix-runtime-input-btn-primary'; done.innerHTML=kixSvgIcon('check',16); done.setAttribute('aria-label',String(opts.confirmText||'Concluir'));
  actions.appendChild(cancel); actions.appendChild(done);
  card.appendChild(main); card.appendChild(actions); layer.appendChild(card);
  const state = { id, card, field, closed:false, onInput:opts.onInput, onConfirm:opts.onConfirm, onCancel:opts.onCancel };
  _kixRuntimeInputs.set(id,state);
  const finish = (cancelled) => {
    const st = _kixRuntimeInputs.get(id); if (!st || st.closed) return;
    st.closed = true; _kixRuntimeInputs.delete(id);
    const v = String(st.field?.value ?? '');
    try { if (cancelled) st.onCancel?.(v); else st.onConfirm?.(v); } catch (e) { console.warn('runtime input callback', e); }
    try { st.card?.remove(); } catch (_) {}
    try { if (!_kixRuntimeInputs.size && window.Android?.hideKeyboard) window.Android.hideKeyboard(); } catch (_) {}
  };
  field.oninput = () => { try { state.onInput?.(field.value); } catch(e) { console.warn('runtime input onInput',e); } };
  cancel.onclick = () => finish(true);
  done.onclick = () => finish(false);
  field.addEventListener('keydown', (e) => {
    if (!multiline && e.key === 'Enter') { e.preventDefault(); finish(false); }
    if (e.key === 'Escape') { e.preventDefault(); finish(true); }
  });
  setTimeout(() => {
    try { field.focus({preventScroll:true}); } catch (_) { try { field.focus(); } catch(__) {} }
    try { field.setSelectionRange(field.value.length, field.value.length); } catch (_) {}
    try { kixRequestKeyboard(field); } catch (_) {}
  }, Number(opts.focusDelayMs) >= 0 ? Number(opts.focusDelayMs) : 20);
  return { id, close: () => finish(true), confirm: () => finish(false), input: field, card };
}
window.openRuntimeInputOverlay = openRuntimeInputOverlay;
function closeAllRuntimeInputOverlays(cancelled=true) {
  Array.from(_kixRuntimeInputs.values()).forEach(st => { try { st.closed=false; } catch(_){} });
  Array.from(_kixRuntimeInputs.keys()).forEach(id => {
    const st=_kixRuntimeInputs.get(id); if (!st) return;
    try { if (cancelled) st.onCancel?.(String(st.field?.value ?? '')); else st.onConfirm?.(String(st.field?.value ?? '')); } catch(_){}
    try { st.card?.remove(); } catch(_){}
    _kixRuntimeInputs.delete(id);
  });
  try { if (window.Android?.hideKeyboard) window.Android.hideKeyboard(); } catch(_){}
}
window.closeAllRuntimeInputOverlays = closeAllRuntimeInputOverlays;
window.hasRuntimeInputOverlays = () => _kixRuntimeInputs.size > 0;
function openActionScreen(opts) {
  opts = opts || {};
  const previous = lastScreen || (currentProject ? 'project' : 'home');
  dialogState = { previous, onCancel: opts.onCancel || null };
  const title = $('dialog-title'), message = $('dialog-message'), inputWrap = $('dialog-input-wrap'), input = $('dialog-input'), options = $('dialog-options'), actions = $('dialog-actions');
  if (title) title.textContent = opts.title || 'Ação';
  if (message) message.textContent = opts.message || '';
  if (options) options.innerHTML = '';
  if (actions) actions.innerHTML = '';
  if (inputWrap) inputWrap.classList.toggle('hidden', !opts.input);
  if (input) {
    input.value = opts.value ?? '';
    input.placeholder = opts.placeholder || '';
    input.rows = Math.max(2, Number(opts.rows) || 4);
    input.setAttribute('aria-label', opts.inputLabel || opts.title || 'Texto');
    input.oninput = () => { try { opts.onInput?.(input.value); } catch (e) { console.warn('dialog onInput', e); } };
  }
  if (opts.options && options) {
    opts.options.forEach(o => {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'w-full text-left px-4 py-3 rounded-lg bg-[#202024] border border-[#303038] text-[14px] text-[#E6E6E8]';
      b.textContent = o.label;
      b.onclick = () => { closeActionScreen(); if (o.action) o.action(); };
      options.appendChild(b);
    });
  }
  if (opts.input && actions) {
    const ok = document.createElement('button'); ok.type='button'; ok.className='w-full h-10 rounded-xl bg-[#059669] text-white text-[14px]'; ok.textContent=opts.confirmText||'Continuar';
    ok.onclick=()=>{ const v=input?.value ?? ''; closeActionScreen(false); if (opts.onConfirm) opts.onConfirm(v); };
    actions.appendChild(ok);
  }
  const cancel = document.createElement('button'); cancel.type='button'; cancel.className='w-full h-10 rounded-xl bg-[#242428] border border-[#33333A] text-[#DCDCE1] text-[14px]'; cancel.textContent='Cancelar';
  cancel.onclick=()=>closeActionScreen(true);
  actions?.appendChild(cancel);
  if ($('dialog-back')) $('dialog-back').onclick = () => closeActionScreen(true);
  show('dialog', {noPush:true});
  const shouldFocus = opts.input && opts.autoFocus !== false;
  const shouldKeyboard = opts.input && opts.openKeyboard !== false;
  setTimeout(()=>{ if(input && shouldFocus){ input.focus({preventScroll:true}); if(shouldKeyboard) kixRequestKeyboard(input); } }, 80);
}
function closeActionScreen(cancelled=false) {
  const st = dialogState; dialogState = null;
  if (cancelled && st?.onCancel) st.onCancel();
  show(st?.previous || (currentProject ? 'project' : 'home'), {noPush:true});
}
function askText(title, message, value, onConfirm) { openActionScreen({title,message,value,input:true,onConfirm}); }
function kixRequestKeyboard(el){
  try {
    if(!el) return;
    el.setAttribute('inputmode', el.inputMode || 'text');
    el.focus({preventScroll:true});
    // This calls Android's system IME only. The editable HTML element remains
    // the input connection, so Gboard/Samsung Keyboard/etc. is shown normally.
    if(window.Android?.showKeyboard) window.Android.showKeyboard();
  } catch(_){}
}
function askChoice(title, message, options, onCancel) { openActionScreen({title,message,options,onCancel}); }
function askConfirm(title, message, onConfirm) {
  const pop = $('confirm-popover');
  if (!pop) { openActionScreen({title,message,options:[{label:'Continuar',action:()=>onConfirm()}]}); return; }
  $('confirm-popover-title').textContent = title || 'Confirmar';
  $('confirm-popover-message').textContent = message || '';
  pop.classList.remove('hidden');
  $('confirm-popover-ok').onclick = () => { pop.classList.add('hidden'); onConfirm?.(); };
  $('confirm-popover-cancel').onclick = () => pop.classList.add('hidden');
}
window.openActionScreen = openActionScreen;
window.askText = askText;
window.askConfirm = askConfirm;

function openSheet(id) {
  $('sheet-backdrop')?.classList.add('open');
  $(id)?.classList.add('open');
}
function closeSheets() {
  $('sheet-backdrop')?.classList.remove('open');
  document.querySelectorAll('.sheet').forEach(s => s.classList.remove('open'));
}

// ===== FORMULA EDITOR (universal) =====
const FORMULA_CATEGORIES = {
  'Funções': ['seno','cosseno','tangente','raiz','potência','log','log10','log base','exponencial','arredondar','piso','teto','absoluto','aleatório','mod','mínimo','máximo','limitar','entre','distância','interpolar','misturar'],
  'Texto': ['comprimento','juntar','letra','para número','para texto','maiúscula','minúscula','substituir','dividir texto','começa com','termina com','contém texto'],
  'Lista': ['tamanho da lista','item da lista','lista contém','índice de','primeiro item','último item','lista vazia','contar item'],
  'Cor': ['RGB para hex','hex para vermelho','hex para verde','hex para azul','misturar cores'],
  'Tempo': ['hora','minuto','segundo','milissegundo','timestamp','data atual','hora atual','ano','mês','dia','dia da semana'],
  'Sensores': ['toque x','toque y','tela está tocada','toque x(1)','toque y(1)','acelerômetro','giroscópio','bússola','GPS','luz','proximidade','bateria'],
  'Lógica': ['E','OU','NÃO','=','≠','>','<','≥','≤'],
  'Dado': ['valor','existe variável','se'],
  'Objetos': ['selecionar objeto']
};
const FORMULA_FUNCS = FORMULA_CATEGORIES['Funções'];
const FORMULA_PROPS_AP = ['tamanho','largura','altura','camada','transparência','aparência atual','nome da aparência'];
const FORMULA_PROPS_MV = ['posição x','posição y','direção','está tocando objeto','tocando na borda','distância até'];
const FORMULA_SENSORS = FORMULA_CATEGORIES['Sensores'];
const FORMULA_LOGIC = FORMULA_CATEGORIES['Lógica'];


// ===== Project image bank / visual image parameter picker =====


function isImageParamPickerTarget(targetEl) {
  try {
    const el = targetEl && targetEl.closest ? targetEl.closest('.param') : targetEl;
    if (!el) return false;
    const paramName = String(el.dataset.param || '').trim().toLowerCase();
    const block = el.closest('.pc-block');
    if (!block) return false;
    const blockName = String(block.dataset.name || '').trim();
    if (blockName === 'Definir sprites do D-Pad') return ['fundo','cima','baixo','esquerda','direita'].includes(paramName);
    if (paramName !== 'imagem') return false;
    return IMAGE_PARAM_PICKER_BLOCKS.has(blockName);
  } catch (_) {
    return false;
  }
}

function collectLiveProjectImageSources(project) {
  const live = new Set();
  const add = (src) => { if (src != null && String(src) !== '') live.add(String(src)); };
  if (!project) return live;

  (project.scenes || []).forEach(scene => {
    (scene?.actors || []).forEach(actor => {
      if (!actor) return;
      add(actor.image);
      add(actor.thumbnailImage);
      add(actor.backgroundFirstImage);
      (actor.looks || []).forEach(look => {
        const src = typeof look === 'string' ? look : (look && (look.src || look.dataUrl || look.image));
        add(src);
      });
      (actor.folders || []).forEach(folder => (folder?.looks || []).forEach(look => {
        const src = typeof look === 'string' ? look : (look && (look.src || look.dataUrl || look.image));
        add(src);
      }));
      const liveScripts = Array.isArray(actor.scripts) ? actor.scripts : (actor.scripts && window.KixEngine?.scriptsToFlat ? (() => { try { return window.KixEngine.scriptsToFlat(actor.scripts); } catch (_) { return []; } })() : []);
      liveScripts.forEach(block => {
        if (!block || !block.values) return;
        const blockName = String(block.name || '').trim();
        if (IMAGE_PARAM_PICKER_BLOCKS.has(blockName)) {
          const keys = blockName === 'Definir sprites do D-Pad' ? ['fundo','cima','baixo','esquerda','direita'] : ['imagem'];
          keys.forEach(k => {
            const v = block.values[k];
            if (v != null && String(v).trim() !== '') {
              const raw = String(v).trim().replace(/^["']|["']$/g, '');
              if (raw) add(raw);
            }
          });
        }
      });
    });
  });
  return live;
}

function pruneProjectImageHistory() {
  if (!currentProject) return false;
  let _changed = false;
  const live = collectLiveProjectImageSources(currentProject);
  const central = new Map();
  if (!Array.isArray(currentProject.imageHistory)) currentProject.imageHistory = [];

  // Migrate legacy actor histories into one project-level bank before deleting the
  // per-actor copies. This prevents the same base64 image from being stored twice.
  (currentProject.scenes || []).forEach(scene => {
    (scene?.actors || []).forEach(actor => {
      if (!actor || !Array.isArray(actor.imageHistory)) return;
      actor.imageHistory.forEach(x => {
        if (!x?.src || !live.has(String(x.src))) return;
        const key = String(x.src);
        if (!central.has(key)) central.set(key, {src:key, name:String(x.name || 'Imagem'), addedAt:Number(x.addedAt || 0) || 0});
      });
    });
  });
  currentProject.imageHistory.forEach(x => {
    if (!x?.src || !live.has(String(x.src))) return;
    const key = String(x.src);
    if (!central.has(key)) central.set(key, {src:key, name:String(x.name || 'Imagem'), addedAt:Number(x.addedAt || 0) || 0});
  });
  const _prevLen = currentProject.imageHistory.length;
  currentProject.imageHistory = Array.from(central.values()).sort((a,b) => Number(a.addedAt||0) - Number(b.addedAt||0));
  if (currentProject.imageHistory.length !== _prevLen) _changed = true;

  // The project bank is now authoritative. Empty legacy actor histories so deleted
  // sprites and duplicate base64 payloads do not keep occupying project storage.
  (currentProject.scenes || []).forEach(scene => {
    (scene?.actors || []).forEach(actor => {
      if (actor && Array.isArray(actor.imageHistory)) { if (actor.imageHistory.length) _changed = true; actor.imageHistory = []; }
    });
  });
  return _changed;
}

function getProjectImageBank() {
  const bank = [];
  const seen = new Set();
  const add = (src, name, addedAt) => {
    if (src == null || src === '') return;
    const value = String(src);
    if (!value || seen.has(value)) return;
    seen.add(value);
    bank.push({
      src: value,
      name: String(name || 'Imagem'),
      addedAt: Number(addedAt || 0) || 0
    });
  };

  if (!currentProject) return bank;

  // Remove orphaned/deleted image history entries before presenting the bank.
  pruneProjectImageHistory();

  // Prefer the existing imageHistory data model when available.
  if (Array.isArray(currentProject.imageHistory)) {
    currentProject.imageHistory.forEach((x, i) => {
      if (x && x.src) add(x.src, x.name || ('Imagem ' + (i + 1)), x.addedAt);
    });
  }

  (currentProject.scenes || []).forEach((scene, si) => {
    (scene && scene.actors || []).forEach((actor, ai) => {
      if (!actor) return;
      const owner = actor.name || ('Objeto ' + (ai + 1));
      if (Array.isArray(actor.imageHistory)) {
        actor.imageHistory.forEach((x, i) => {
          if (x && x.src) add(x.src, x.name || (owner + ' • imagem ' + (i + 1)), x.addedAt);
        });
      }

      // Backward compatibility: old projects can have looks without imageHistory.
      if (Array.isArray(actor.looks)) {
        actor.looks.forEach((look, i) => {
          const src = typeof look === 'string'
            ? look
            : (look && (look.dataUrl || look.src || look.image));
          if (src) add(src, owner + ' • aparência ' + (i + 1), 0);
        });
      }

      // Also cover legacy/background image fields.
      add(actor.image, owner + ' • imagem principal', 0);
      add(actor.thumbnailImage, owner + ' • miniatura', 0);
      add(actor.backgroundFirstImage, owner + ' • fundo', 0);
    });
  });

  bank.sort((a, b) => {
    if (b.addedAt !== a.addedAt) return b.addedAt - a.addedAt;
    return a.name.localeCompare(b.name, 'pt-BR');
  });
  return bank;
}

function getImagePickerTargetBlock() {
  const target = window._imagePickerTarget;
  if (!target || !target.blockId || !target.paramName) return null;
  const actor = target.actor || currentActor;
  if (!actor) return null;
  let scripts = Array.isArray(actor.scripts) ? actor.scripts : [];
  if (!scripts.length && actor.scripts && window.KixEngine?.scriptsToFlat) { try { scripts = KixEngine.scriptsToFlat(actor.scripts); actor.scripts = scripts; } catch (_) {} }
  if (!Array.isArray(scripts)) return null;
  const block = scripts.find(b => b && b.id === target.blockId);
  return block ? { actor, scripts, block } : null;
}

function setImagePickerValue(src) {
  const target = window._imagePickerTarget;
  const found = getImagePickerTargetBlock();
  if (!target || !found) {
    toast('Não foi possível localizar o bloco');
    return;
  }

  if (!found.block.values) found.block.values = {};
  found.block.values[target.paramName] = String(src || '');

  // Keep the editor state synchronized with the stored block.
  syncActorToProject();
  save();

  window._imagePickerTarget = null;
  const picker = $('screen-image-picker');
  if (picker) picker.classList.add('hidden');
  try { renderScripts(); } catch (_) {}
}

function renderImagePicker() {
  const grid = $('image-picker-grid');
  const empty = $('image-picker-empty');
  const title = $('image-picker-title');
  if (!grid) return;

  const target = window._imagePickerTarget;
  if (title) title.textContent = target && target.blockName
    ? 'Escolher imagem · ' + target.blockName
    : 'Escolher imagem';

  const bank = getProjectImageBank();
  grid.innerHTML = '';

  if (empty) empty.classList.toggle('hidden', bank.length > 0);

  bank.forEach((img) => {
    const item = document.createElement('button');
    item.type = 'button';
    item.className = 'image-picker-item text-left rounded-lg overflow-hidden border border-[#35353C] bg-[#242429] active:scale-[.985] transition-transform';
    item.dataset.src = img.src;
    const targetBlock = getImagePickerTargetBlock()?.block;
    const selected = targetBlock?.values?.[window._imagePickerTarget?.paramName] === img.src;
    if (selected) item.classList.add('ring-2', 'ring-[#34D399]');
    item.innerHTML = `
      <div class="aspect-square bg-[#17171B] overflow-hidden flex items-center justify-center">
        <img src="" alt="" class="w-full h-full object-contain">
      </div>
      <div class="px-2 py-2">
        <div class="text-[11px] text-[#E5E5E7] truncate image-picker-name"></div>
      </div>`;
    const image = item.querySelector('img');
    image.src = img.src;
    item.querySelector('.image-picker-name').textContent = img.name;
    item.onclick = () => setImagePickerValue(img.src);
    grid.appendChild(item);
  });
}

function openImagePicker(targetEl) {
  restoreCurrentActorContext();
  const blockEl = targetEl && targetEl.closest ? targetEl.closest('.pc-block') : null;
  const paramName = targetEl && targetEl.dataset ? targetEl.dataset.param : 'imagem';
  if (!blockEl || !currentActor) {
    openFormula(targetEl);
    return;
  }

  // Store a stable block id instead of the DOM node so a re-render cannot
  // accidentally write the image into another block.
  const idx = blockEl.dataset.scriptIdx != null ? Number(blockEl.dataset.scriptIdx) : -1;
  const scripts = Array.isArray(currentActor.scripts) ? currentActor.scripts : [];
  const block = idx >= 0 ? scripts[idx] : null;
  if (!block) {
    openFormula(targetEl);
    return;
  }

  window._imagePickerTarget = {
    actor: currentActor,
    actorIdx: currentActorIdx,
    blockId: block.id,
    blockName: block.name,
    paramName: paramName || 'imagem',
    el: targetEl
  };

  renderImagePicker();
  const picker = $('screen-image-picker');
  if (picker) picker.classList.remove('hidden');
}

function closeImagePicker() {
  window._imagePickerTarget = null;
  const picker = $('screen-image-picker');
  if (picker) picker.classList.add('hidden');
  try { renderScripts(); } catch (_) {}
}

function openFormula(targetEl, mode) {
  // Formula is a full editor surface, not a child of any transient sheet/menu.
  // A stale fixed sheet backdrop (z-index:40) can otherwise sit above the
  // formula screen and make the entire editor look grey/unresponsive.
  try { closeSheets(); } catch (_) {}
  try { $('sheet-backdrop')?.classList.remove('open'); } catch (_) {}
  try { $('block-ctx-overlay')?.classList.remove('open'); $('block-ctx-overlay').style.display='none'; } catch (_) {}
  try { $('confirm-popover')?.classList.add('hidden'); } catch (_) {}
  try { closeFormulaCategoryMenu(); } catch (_) {}
  try {
    $('formula-category-screen')?.classList.add('hidden');
    $('formula-text-screen')?.classList.add('hidden');
    $('formula-main-content')?.classList.remove('hidden');
    activeFormulaCategory = '';
    formulaCategorySearchOpen = false;
  } catch (_) {}
  formulaTarget = targetEl;
  const blockForFormulaRef = targetEl?.closest?.('.pc-block');
  formulaTargetRef = targetEl ? {
    scriptIdx: blockForFormulaRef?.dataset?.scriptIdx ?? null,
    blockId: blockForFormulaRef?.dataset?.blockId || '',
    paramKey: targetEl?.dataset?.param || ''
  } : null;
  formulaMode = mode || (targetEl && targetEl.dataset && targetEl.dataset.type) || 'number';
  let raw = '';
  if (targetEl) {
    if (targetEl.dataset && targetEl.dataset.value !== undefined && targetEl.dataset.value !== '') {
      raw = targetEl.dataset.value;
    } else {
      raw = (targetEl.textContent || '').trim();
    }
  }
  if (raw === '···' || raw === '…') raw = '';
  formulaVal = raw;
  formulaCursorIndex = formulaVal.length;
  formulaFresh = (formulaVal === '' || formulaVal === '0' || formulaVal === '1');
  resetFormulaHistory();
  if (formulaMode !== 'code') renderFormulaExpr();
  syncFormulaEditorUi();
  try {
    const blockEl = targetEl && targetEl.closest && targetEl.closest('.pc-block');
    const preview = $('formula-block-preview');
    const label = $('formula-block-label');
    if (preview) {
      let sourceColor = '';
      if (blockEl) {
        sourceColor = String(blockEl.style.backgroundColor || blockEl.style.background || '').trim();
        if (!sourceColor) {
          try { sourceColor = getComputedStyle(blockEl).backgroundColor || ''; } catch (_) {}
        }
      }
      // Do not invent the old red preview color when a source block has no color.
      preview.style.setProperty('--kix-formula-preview-color', sourceColor || 'transparent');
      preview.style.setProperty('box-shadow', 'none', '');
      if (label) label.textContent = (blockEl?.dataset?.name || 'Bloco').slice(0, 40);
    }
  } catch (_) {}
  $('formula-result') && $('formula-result').classList.add('hidden');
  $('formula-picker') && $('formula-picker').classList.add('hidden');
  $('formula-text-mode') && $('formula-text-mode').classList.add('hidden');
  $('formula-cats-row') && $('formula-cats-row').classList.remove('hidden');
  const grid = document.querySelector('#screen-formula .grid');
  if (grid) grid.classList.remove('hidden');
  
  // Pure code editor: code stays multiline and is edited as code, not as a number keypad.
  if (formulaMode === 'code') {
    const picker = $('formula-picker');
    const list = $('formula-picker-list');
    const keys = document.querySelector('#screen-formula .grid');
    const textMode = $('formula-text-mode');
    textMode?.classList.add('hidden');
    keys?.classList.add('hidden');
    picker?.classList.remove('hidden');
    if (picker && list) {
      list.innerHTML = '';
      const wrap = document.createElement('div');
      wrap.className = 'p-3';
      const label = document.createElement('div');
      label.className = 'text-[12px] text-[#9B9BA3] mb-2';
      label.textContent = 'JavaScript';
      const editor = document.createElement('textarea');
      editor.className = 'w-full min-h-[240px] resize-y rounded-xl bg-[#111113] border border-[#3A3A42] p-3 text-[13px] leading-5 text-[#F1F1F3] font-mono outline-none focus:border-[#059669]';
      editor.value = String(formulaVal || '').replace(/^['"]|['"]$/g,'');
      editor.spellcheck = false;
      const actions = document.createElement('div');
      actions.className = 'flex gap-2 mt-3';
      const saveBtn = document.createElement('button');
      saveBtn.type = 'button'; saveBtn.className = 'flex-1 h-10 rounded-xl bg-[#059669] text-white text-[13px]'; saveBtn.textContent = 'Salvar código';
      saveBtn.onclick = () => { setFormulaValue(editor.value, {fresh:false}); picker.classList.add('hidden'); keys?.classList.remove('hidden'); };
      const cancelBtn = document.createElement('button');
      cancelBtn.type = 'button'; cancelBtn.className = 'px-4 h-10 rounded-xl bg-[#242428] border border-[#33333A] text-[#DCDCE1] text-[13px]'; cancelBtn.textContent = 'Cancelar';
      cancelBtn.onclick = () => { picker.classList.add('hidden'); keys?.classList.remove('hidden'); };
      actions.append(saveBtn, cancelBtn);
      wrap.append(label, editor, actions);
      list.appendChild(wrap);
      setTimeout(()=>editor.focus({preventScroll:true}),80);
    }
  }
  // Folder picker for type=folder params
  if (formulaMode === 'file') {
    const files = ensureProjectFiles();
    const picker = $('formula-picker');
    const list = $('formula-picker-list');
    const keys = document.querySelector('#screen-formula .grid');
    const textMode = $('formula-text-mode');
    textMode?.classList.add('hidden');
    keys?.classList.add('hidden');
    if (picker && list) {
      picker.classList.remove('hidden');
      list.innerHTML = '';
      if (!files.length) {
        list.innerHTML = '<p class="text-[#666] text-sm px-2 py-4">Nenhum arquivo. Menu de opções → Adicionar arquivos</p>';
      } else {
        files.forEach(f => {
          const el = document.createElement('div');
          el.className = 'formula-pick-item';
          el.textContent = f.name;
          el.onclick = () => {
            setFormulaValue("'" + String(f.name).replace(/'/g, "\\'") + "'", {fresh:false});
            picker.classList.add('hidden');
            keys?.classList.remove('hidden');
          };
          list.appendChild(el);
        });
      }
    }
  }
  const formulaSetQuoted = (value) => {
    const clean = String(value == null ? '' : value).replace(/^["']|["']$/g, '').trim();
    setFormulaValue("'" + clean.replace(/'/g, "\\'") + "'", {fresh:false});
  };
  if (formulaMode === 'bool') {
    const picker=$('formula-picker'), list=$('formula-picker-list'), keys=document.querySelector('#screen-formula .grid');
    const textMode=$('formula-text-mode'); textMode?.classList.add('hidden'); keys?.classList.add('hidden');
    if(picker&&list){
      picker.classList.remove('hidden'); list.innerHTML='';
      [['sim','Sim'],['não','Não']].forEach(([value,label])=>{
        const el=document.createElement('button'); el.type='button'; el.className='formula-pick-item w-full text-left'; el.textContent=label;
        el.onclick=()=>{formulaSetQuoted(value);picker.classList.add('hidden');keys?.classList.remove('hidden');}; list.appendChild(el);
      });
    }
  }
  if (formulaMode === 'color') {
    const picker=$('formula-picker'), list=$('formula-picker-list'), keys=document.querySelector('#screen-formula .grid');
    const textMode=$('formula-text-mode'); textMode?.classList.add('hidden'); keys?.classList.add('hidden');
    if(picker&&list){
      picker.classList.remove('hidden'); list.innerHTML='';
      const current=String(formulaVal||"'#FFFFFF'").replace(/^["']|["']$/g,'').trim();
      const normalized=/^#[0-9a-f]{6}$/i.test(current)?current:'#FFFFFF';
      const wrap=document.createElement('div'); wrap.className='formula-color-picker p-3 bg-[#2C2C2C] rounded-lg border border-[#3A3A3A]';
      wrap.innerHTML='<div class="text-[12px] text-[#C8C8CE] mb-2">Escolha uma cor</div><div class="flex items-center gap-3"><input type="color" aria-label="Escolher cor" class="w-16 h-12 rounded-lg bg-transparent border-0 p-0"><span class="text-[13px] font-mono text-white"></span></div><div class="flex gap-2 mt-3"><button type="button" data-color-ok class="flex-1 py-2 rounded-lg bg-[#059669] text-white text-[12px] font-medium">Usar cor</button><button type="button" data-color-formula class="py-2 px-3 rounded-lg border border-[#444] text-[#aaa] text-[12px]">Fórmula</button></div>';
      const input=wrap.querySelector('input'), valueLabel=wrap.querySelector('span'); input.value=normalized; valueLabel.textContent=normalized.toUpperCase();
      input.oninput=()=>{valueLabel.textContent=input.value.toUpperCase();};
      wrap.querySelector('[data-color-ok]').onclick=()=>{formulaSetQuoted(input.value.toUpperCase());picker.classList.add('hidden');keys?.classList.remove('hidden');};
      wrap.querySelector('[data-color-formula]').onclick=()=>{picker.classList.add('hidden');keys?.classList.remove('hidden');toast('Modo fórmula');};
      list.appendChild(wrap);
    }
  }
  if (formulaMode === 'choice') {
    const optionsRaw=String(targetEl?.dataset?.options||'').split('\u001f').map(v=>v.trim()).filter(Boolean);
    const picker=$('formula-picker'), list=$('formula-picker-list'), keys=document.querySelector('#screen-formula .grid');
    const textMode=$('formula-text-mode'); textMode?.classList.add('hidden'); keys?.classList.add('hidden');
    if(picker&&list){
      picker.classList.remove('hidden'); list.innerHTML='';
      const current=String(formulaVal||'').replace(/^["']|["']$/g,'').trim().toLowerCase();
      optionsRaw.forEach(option=>{
        const el=document.createElement('button'); el.type='button'; el.className='formula-pick-item w-full text-left'; el.textContent=option;
        if(option.toLowerCase()===current) el.classList.add('is-selected');
        el.onclick=()=>{formulaSetQuoted(option);picker.classList.add('hidden');keys?.classList.remove('hidden');}; list.appendChild(el);
      });
    }
  }

  if (formulaMode === 'object' || formulaMode === 'actor') {
    const actors = getSceneActors().filter(a => a && a !== getSceneActors()[0] && !a.isBackground && a.name);
    const picker = $('formula-picker');
    const list = $('formula-picker-list');
    const keys = document.querySelector('#screen-formula .grid');
    const textMode = $('formula-text-mode');
    textMode?.classList.add('hidden');
    keys?.classList.add('hidden');
    if (picker && list) {
      picker.classList.remove('hidden');
      list.innerHTML = '';
      if (!actors.length) {
        list.innerHTML = '<p class="text-[#666] text-sm px-2 py-4">Nenhum objeto disponível nesta cena.</p>';
      } else {
        actors.forEach(actor => {
          const el = document.createElement('button');
          el.type = 'button';
          el.className = 'formula-pick-item w-full text-left';
          el.textContent = String(actor.name);
          const current = String(formulaVal || '').replace(/^['"]|['"]$/g, '').trim();
          if (String(actor.name).toLowerCase() === current.toLowerCase()) el.classList.add('is-selected');
          el.onclick = () => {
            formulaSetQuoted(actor.name);
            picker.classList.add('hidden');
            keys?.classList.remove('hidden');
          };
          list.appendChild(el);
        });
      }
    }
  }

  if (formulaMode === 'folder') {
    const folders = ((currentActor && currentActor.folders) || []).map(f => f && f.name).filter(Boolean);
    const picker = $('formula-picker');
    const list = $('formula-picker-list');
    const keys = document.querySelector('#screen-formula .grid');
    const textMode = $('formula-text-mode');
    textMode?.classList.add('hidden');
    keys?.classList.add('hidden');
    if (picker && list) {
      picker.classList.remove('hidden');
      list.innerHTML = '';
      if (!folders.length) {
        list.innerHTML = '<p class="text-[#666] text-sm px-2 py-4">Nenhuma pasta. Crie pastas em Aparência.</p>';
      } else {
        folders.forEach(name => {
          const el = document.createElement('div');
          el.className = 'formula-pick-item';
          el.textContent = name;
          el.onclick = () => {
            setFormulaValue("'" + name.replace(/'/g, "\\'") + "'", {fresh:false});
            picker.classList.add('hidden');
            keys?.classList.remove('hidden');
          };
          list.appendChild(el);
        });
      }
    }
  }

  show('formula');
}
function applyFormulaInput(text) {
  const token = String(text == null ? '' : text);
  if (!token) return false;
  const current = String(formulaVal == null ? '' : formulaVal);
  const replaceCurrent = formulaFresh || !current || current === '···' || current === '…';
  if (replaceCurrent) {
    formulaCursorIndex = token.length;
    return setFormulaValue(token, {fresh:false});
  }
  const at = Math.max(0, Math.min(formulaCursorIndex, current.length));
  const next = current.slice(0, at) + token + current.slice(at);
  formulaCursorIndex = at + token.length;
  return setFormulaValue(next, {fresh:false});
}
function insertFormula(text) {
  return applyFormulaInput(text);
}
function formulaDisplayValue(value) {
  const raw = String(value == null ? '' : value).trim();
  if (!raw || raw === '···' || raw === '…') return '···';
  // Formula strings may be stored with quotes. They are syntax, not part of
  // the user-facing preview, so truncate the displayed content only.
  const unquoted = raw.replace(/^(?:['"])([\s\S]*)(?:['"])$/, '$1');
  return truncateKixDisplayText(unquoted, 10);
}

function syncFormulaExprViewport() {
  const el = $('formula-expr');
  const wrap = $('formula-expression-wrap');
  if (!el || !wrap) return;

  // Measure the real wrapped content first. The expression itself is not a
  // flex filler: it grows only as much as its content needs, then becomes the
  // vertical scroll viewport when that content reaches the fixed workspace.
  el.style.flex = '0 0 auto';
  el.style.height = '1px';
  el.style.maxHeight = 'none';
  el.style.overflowY = 'hidden';
  el.style.overflowX = 'hidden';
  void el.offsetHeight;

  const label = $('formula-expression-label');
  const result = $('formula-result');
  const labelH = label ? label.offsetHeight + 4 : 0;
  const resultH = result && !result.classList.contains('hidden') ? result.offsetHeight + 8 : 0;
  const available = Math.max(52, wrap.clientHeight - labelH - resultH);
  const natural = Math.max(52, el.scrollHeight);
  const height = Math.min(natural, available);

  el.style.height = height + 'px';
  el.style.maxHeight = available + 'px';
  el.style.overflowY = natural > available + 1 ? 'auto' : 'hidden';
  el.classList.toggle('formula-scroll-y', natural > available + 1);
  el.style.overflowX = 'hidden';
}

function tokenizeFormulaDisplay(rawValue) {
  const raw = String(rawValue == null ? '' : rawValue);
  const out = [];
  let i = 0;
  while (i < raw.length) {
    const ch = raw[i];
    if (/\s/.test(ch)) {
      let j = i + 1;
      while (j < raw.length && /\s/.test(raw[j])) j++;
      out.push({type:'space', value:raw.slice(i,j)});
      i = j;
      continue;
    }
    // Quoted text is ONE text token. Spaces, punctuation, operators and
    // nested-looking characters inside the quotes must never become formula
    // tokens in the preview.
    if (ch === '"' || ch === "'") {
      const quote = ch;
      let j = i + 1;
      let escaped = false;
      while (j < raw.length) {
        const c = raw[j];
        if (escaped) { escaped = false; j++; continue; }
        if (c === '\\') { escaped = true; j++; continue; }
        if (c === quote) { j++; break; }
        j++;
      }
      out.push({type:'text', value:raw.slice(i,j)});
      i = j;
      continue;
    }
    if (/[()\+\−\×\÷]/.test(ch)) {
      out.push({type:'op', value:ch});
      i++;
      continue;
    }
    let j = i + 1;
    while (j < raw.length && !/[\s()\+\−\×\÷"']/.test(raw[j])) j++;
    const token = raw.slice(i,j);
    out.push({type:/^[0-9.]+$/.test(token) ? 'num' : 'fn', value:token});
    i = j;
  }
  return out;
}
function renderFormulaExpr() {
  const el = $('formula-expr');
  if (!el) return;
  const raw = String(formulaVal == null ? '' : formulaVal);
  const cursor = Math.max(0, Math.min(formulaCursorIndex, raw.length));
  const parts = tokenizeFormulaDisplay(raw);
  el.innerHTML = '';

  // Preserve the original token boxes and spacing. The editable character
  // spans live inside each token, so choosing a cursor position does not
  // change the visual geometry of the formula editor.
  let rawOffset = 0;
  let cursorPlaced = false;
  const appendCursor = parent => {
    const caret = document.createElement('span');
    caret.className = 'formula-cursor';
    caret.setAttribute('aria-hidden', 'true');
    (parent || el).appendChild(caret);
  };

  parts.forEach(part => {
    const partStart = rawOffset;
    const partValue = String(part.value ?? '');
    const partEnd = partStart + partValue.length;
    const token = document.createElement('span');
    token.className = 'formula-token ' + part.type;
    if (part.type === 'space') token.style.padding = '0 3px';
    else if (part.type === 'op') token.style.padding = '0 4px';

    if (cursor >= partStart && cursor <= partEnd) {
      for (let j = 0; j < partValue.length; j++) {
        const absoluteIndex = partStart + j;
        if (absoluteIndex === cursor) {
          appendCursor(token);
          cursorPlaced = true;
        }
        const charEl = document.createElement('span');
        charEl.className = 'formula-char';
        charEl.dataset.formulaIndex = String(absoluteIndex);
        charEl.textContent = partValue[j] === ' ' ? '\u00a0' : partValue[j];
        token.appendChild(charEl);
      }
      if (cursor === partEnd) {
        appendCursor(token);
        cursorPlaced = true;
      }
    } else {
      token.textContent = partValue;
    }

    el.appendChild(token);
    rawOffset = partEnd;
  });

  if (!cursorPlaced) appendCursor();
  requestAnimationFrame(syncFormulaExprViewport);
}
function closeFormula() {
  try { closeFormulaCategoryScreen(); closeFormulaTextScreen(); } catch (_) {}
  try {
    if (formulaTarget) {
      const display = (formulaVal === '' || formulaVal == null) ? '···' : String(formulaVal);
      formulaTarget.textContent = display;
      formulaTarget.dataset.value = formulaVal == null ? '' : String(formulaVal);
      const paramKey = formulaTarget.dataset.param;
      if (paramKey && currentActor) {
        // Ensure flat scripts array
        if (currentActor.scripts && currentActor.scripts.blocks && window.KixEngine) {
          currentActor.scripts = KixEngine.scriptsToFlat(currentActor.scripts);
        }
        if (!Array.isArray(currentActor.scripts)) currentActor.scripts = [];
        const blockEl = formulaTarget.closest('.pc-block');
        let idx = blockEl && blockEl.dataset.scriptIdx != null ? parseInt(blockEl.dataset.scriptIdx, 10) : -1;
        if (isNaN(idx) || idx < 0) {
          const blocks = document.querySelectorAll('#script-blocks .pc-block:not(.loop-end)');
          blocks.forEach((b, i) => { if (b === blockEl) idx = i; });
        }
        if (idx >= 0 && currentActor.scripts[idx]) {
          if (!currentActor.scripts[idx].values) currentActor.scripts[idx].values = {};
          currentActor.scripts[idx].values[paramKey] = formulaVal == null ? '' : String(formulaVal);
          // also mirror into params-named keys
          syncActorToProject();
          save();
        }
      }
    }
  } catch (e) { console.warn('closeFormula', e); }
  formulaTarget = null;
  formulaTargetRef = null;
  try { navBack(); } catch (_) { show('scripts', { noPush: true }); }
  try { renderScripts(); } catch (_) {}
}


// ===== FORMULA CATEGORY SCREENS + DATA MANAGER =====
function ensureProjectDataDefinitions(project) {
  if (!project) return [];
  if (!Array.isArray(project.dataDefinitions)) project.dataDefinitions = [];
  // Backfill the new model from the legacy project.vars store without duplicating existing definitions.
  if (project.dataDefinitions.length === 0 && project.vars && typeof project.vars === 'object') {
    const existingNames = new Set(project.dataDefinitions.map(d => String(d?.name || '').toLowerCase()));
    Object.entries(project.vars).forEach(([name, value], i) => {
      const clean = String(name || '').trim();
      if (!clean || existingNames.has(clean.toLowerCase())) return;
      project.dataDefinitions.push({
        id: 'data_legacy_' + i + '_' + Math.random().toString(36).slice(2,8),
        name: clean, value: value ?? 0, scope: 'project', valuesByActor: {}, createdAt: Date.now(), updatedAt: Date.now()
      });
      existingNames.add(clean.toLowerCase());
    });
  }
  project.dataDefinitions = project.dataDefinitions.map((d, i) => {
    const out = d && typeof d === 'object' ? d : {};
    out.id = String(out.id || ('data_' + i + '_' + Math.random().toString(36).slice(2,8)));
    out.name = String(out.name || ('Dado ' + (i + 1)));
    out.value = out.value ?? 0;
    out.scope = ['object','project','network'].includes(String(out.scope||'')) ? String(out.scope) : 'project';
    if (!out.valuesByActor || typeof out.valuesByActor !== 'object') out.valuesByActor = {};
    out.createdAt = Number(out.createdAt || Date.now()) || Date.now();
    out.updatedAt = Number(out.updatedAt || Date.now()) || Date.now();
    return out;
  });
  return project.dataDefinitions;
}
function dataScopeLabel(scope) {
  return scope === 'object' ? 'Este objeto + clones' : scope === 'network' ? 'Todos + multiplayer entre projetos' : 'Todos os objetos e cenas';
}
function currentFormulaActorKey() {
  try { return currentActor ? String(ensureActorIdentity(currentActor)) : ''; } catch (_) { return ''; }
}
function getDataDefinitionById(id) {
  const defs = ensureProjectDataDefinitions(currentProject);
  return defs.find(d => String(d.id) === String(id)) || null;
}
function getDataDefinitionByName(name) {
  const q = String(name||'').trim();
  const defs = ensureProjectDataDefinitions(currentProject);
  return defs.find(d => d.name === q) || defs.find(d => d.name.toLowerCase() === q.toLowerCase()) || null;
}
function dataDefinitionValue(def, actor = currentActor) {
  if (!def) return '';
  if (def.scope === 'object') {
    const key = (() => { try { return actor ? String(ensureActorIdentity(actor)) : ''; } catch (_) { return ''; } })();
    if (key && Object.prototype.hasOwnProperty.call(def.valuesByActor || {}, key)) return def.valuesByActor[key];
    return def.value;
  }
  return def.value;
}
function writeDataDefinitionValue(def, value, actor = currentActor) {
  if (!def) return;
  def.updatedAt = Date.now();
  if (def.scope === 'object') {
    const key = (() => { try { return actor ? String(ensureActorIdentity(actor)) : ''; } catch (_) { return ''; } })();
    if (key) def.valuesByActor[key] = value;
    if (actor) {
      actor._vars = actor._vars || {};
      actor._vars[def.name] = value;
      actor.vars = actor.vars || {};
      actor.vars[def.name] = value;
    }
  } else {
    def.value = value;
    if (currentProject) {
      currentProject.vars = currentProject.vars || {};
      currentProject.vars[def.name] = value;
    }
    if (def.scope === 'network') {
      try { globals[def.name] = value; } catch (_) {}
    }
  }
}
function createDataDefinition(name, initial, scope) {
  const clean = String(name||'').trim();
  if (!clean) return null;
  ensureProjectDataDefinitions(currentProject);
  if (getDataDefinitionByName(clean)) throw new Error('Já existe um dado com este nome');
  const legacyNames = Object.keys(currentProject?.vars || {});
  if (legacyNames.some(n => String(n).toLowerCase() === clean.toLowerCase())) {
    throw new Error('Já existe uma variável com este nome');
  }
  const def = {
    id: 'data_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,8),
    name: clean,
    value: 0,
    scope: ['object','project','network'].includes(scope) ? scope : 'project',
    valuesByActor: {},
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  currentProject.dataDefinitions.push(def);
  if (def.scope === 'object' && currentActor) writeDataDefinitionValue(def, def.value, currentActor);
  else writeDataDefinitionValue(def, def.value, currentActor);
  save();
  return def;
}
function renameDataDefinition(def, name) {
  if (!def) return false;
  const clean = String(name||'').trim();
  if (!clean || clean === def.name) return false;
  const conflict = ensureProjectDataDefinitions(currentProject).find(d => d !== def && d.name.toLowerCase() === clean.toLowerCase());
  if (conflict) throw new Error('Já existe um dado com este nome');
  const oldName = def.name;
  def.name = clean;
  if (currentProject?.vars && Object.prototype.hasOwnProperty.call(currentProject.vars, oldName)) {
    currentProject.vars[clean] = currentProject.vars[oldName];
    delete currentProject.vars[oldName];
  }
  if (globals && Object.prototype.hasOwnProperty.call(globals, oldName)) {
    globals[clean] = globals[oldName];
    delete globals[oldName];
  }
  if (currentActor?._vars && Object.prototype.hasOwnProperty.call(currentActor._vars, oldName)) {
    currentActor._vars[clean] = currentActor._vars[oldName];
    delete currentActor._vars[oldName];
  }
  def.updatedAt = Date.now();
  save();
  return true;
}
function deleteDataDefinition(def) {
  if (!def || !currentProject) return false;
  currentProject.dataDefinitions = ensureProjectDataDefinitions(currentProject).filter(d => d !== def);
  if (currentProject.vars && Object.prototype.hasOwnProperty.call(currentProject.vars, def.name)) delete currentProject.vars[def.name];
  if (globals && Object.prototype.hasOwnProperty.call(globals, def.name)) delete globals[def.name];
  if (currentActor?._vars && Object.prototype.hasOwnProperty.call(currentActor._vars, def.name)) delete currentActor._vars[def.name];
  save();
  return true;
}
function renderDataList(filter='') {
  const list = $('data-list');
  if (!list) return;
  ensureProjectDataDefinitions(currentProject);
  list.innerHTML = '';
  const q = String(filter||'').trim().toLowerCase();
  const defs = ensureProjectDataDefinitions(currentProject).filter(d => !q || d.name.toLowerCase().includes(q) || dataScopeLabel(d.scope).toLowerCase().includes(q));
  const dataFns = (FORMULA_CATEGORIES && Array.isArray(FORMULA_CATEGORIES['Dado'])) ? FORMULA_CATEGORIES['Dado'] : ['valor','existe variável','se'];
  const matchingFns = dataFns.filter(fn => !q || String(fn).toLowerCase().includes(q));
  if (matchingFns.length) {
    const heading = document.createElement('div');
    heading.className = 'kix-data-section-title';
    heading.textContent = 'Funções do dado';
    list.appendChild(heading);
    matchingFns.forEach(fn => {
      const row = document.createElement('button');
      row.type = 'button';
      row.className = 'kix-data-function-row';
      row.textContent = String(fn);
      row.onclick = e => {
        e.preventDefault();
        insertFormula(String(fn));
        closeDataScreen();
        toast(String(fn));
      };
      list.appendChild(row);
    });
  }
  if (!defs.length && !matchingFns.length) {
    const empty = document.createElement('div');
    empty.className = 'kix-data-empty';
    empty.textContent = q ? 'Nenhum dado encontrado' : 'Nenhum dado criado';
    list.appendChild(empty);
    return;
  }
  if (defs.length) {
    const heading = document.createElement('div');
    heading.className = 'kix-data-section-title';
    heading.textContent = 'Dados';
    list.appendChild(heading);
  }
  defs.forEach(def => {
    const row = document.createElement('div');
    row.className = 'kix-data-row';
    row.dataset.id = def.id;
    const preview = document.createElement('div'); preview.className='kix-data-preview';
    const value = document.createElement('div'); value.className='kix-data-value'; value.textContent=String(dataDefinitionValue(def));
    const name = document.createElement('div'); name.className='kix-data-name'; name.textContent=def.name;
    preview.append(name, value);
    const scope = document.createElement('div'); scope.className='kix-data-scope'; scope.textContent=dataScopeLabel(def.scope);
    const menu = document.createElement('button'); menu.type='button'; menu.className='kix-data-menu'; menu.setAttribute('aria-label','Opções de '+def.name); menu.innerHTML=kixSvgIcon('more',18);
    menu.onclick = e => { e.preventDefault(); e.stopPropagation(); openDataMiniMenu(def, menu); };
    row.append(preview, scope, menu);
    row.onclick = e => {
      if (e.target.closest('.kix-data-menu')) return;
      if (dataReturnScreen === 'formula') {
        // The Dado screen is opened from the formula-category overlay, not from
        // a separate navigation destination. Return to the actual formula
        // editor surface and close the category overlay in the same transition.
        insertFormula(def.name);
        closeDataMiniMenu();
        closeDataEditor();
        try { navBack(); } catch (_) { show('formula', {noPush:true}); }
        closeFormulaCategoryScreen();
        requestAnimationFrame(() => {
          // Returning from the Dado screen may have recreated the Brick DOM.
          // Resolve the target again, then synchronize both previews from the
          // single formula state instead of writing to a stale DOM node.
          resolveFormulaTarget();
          syncFormulaEditorUi();
          syncFormulaExprViewport();
        });
        toast('Dado inserido');
      } else {
        openDataEditor(def);
      }
    };
    list.appendChild(row);
  });
}
function openDataMiniMenu(def, anchor) {
  closeDataMiniMenu();
  const menu = document.createElement('div'); menu.id='kix-data-mini-menu'; menu.className='kix-data-mini-menu'; menu.setAttribute('role','menu');
  const action = (label, fn, danger=false) => { const b=document.createElement('button'); b.type='button'; b.className='kix-data-mini-action'+(danger?' danger':''); b.textContent=label; b.onclick=e=>{e.preventDefault();e.stopPropagation();closeDataMiniMenu();fn();}; menu.appendChild(b); };
  action('Trocar nome',()=>openDataEditor(def,{renameOnly:true}));
  action('Editar',()=>openDataEditor(def));
  action('Excluir',()=>{ askConfirm('Excluir dado','Excluir este dado?',()=>{ deleteDataDefinition(def); renderDataList($('data-search-input')?.value||''); }); },true);
  document.body.appendChild(menu);
  const r=anchor.getBoundingClientRect(), w=Math.min(220,window.innerWidth-20);
  menu.style.width=w+'px';
  let left=Math.max(10,Math.min(window.innerWidth-w-10,r.right-w));
  let top=r.bottom+6; const h=menu.offsetHeight; if(top+h>window.innerHeight-10) top=Math.max(10,r.top-h-6);
  menu.style.left=Math.round(left)+'px'; menu.style.top=Math.round(top)+'px';
  const outside=e=>{if(!menu.contains(e.target)&&!anchor.contains(e.target))closeDataMiniMenu();};
  const esc=e=>{if(e.key==='Escape')closeDataMiniMenu();};
  document.addEventListener('pointerdown',outside,true); document.addEventListener('keydown',esc,true);
  menu._cleanup=()=>{document.removeEventListener('pointerdown',outside,true);document.removeEventListener('keydown',esc,true);};
}
function closeDataMiniMenu(){ const m=$('kix-data-mini-menu'); if(m){try{m._cleanup?.();}catch(_){} m.remove();} }
function openDataEditor(def, opts={}) {
  activeDataEditId = def ? String(def.id) : null;
  const modal=$('data-create-modal'), title=$('data-modal-title'), name=$('data-modal-name'), value=$('data-modal-value'), scope=$('data-modal-scope');
  if(!modal||!name||!value||!scope) return;
  title.textContent = def ? (opts.renameOnly ? 'Renomear dado' : 'Editar dado') : 'Criar dado';
  name.value = def ? def.name : '';
  // Creation always starts at zero. The hidden value field preserves an
  // existing value during edits without exposing a "Valor inicial" control.
  if (value) value.value = def ? String(dataDefinitionValue(def)) : '0';
  const selectedScope = def ? def.scope : 'object';
  scope.value = selectedScope;
  document.querySelectorAll('input[name="dataScope"]').forEach(r => { r.checked = r.value === selectedScope; });
  const scopeWrap = $('data-modal-scope-wrap'); if(scopeWrap) scopeWrap.classList.toggle('hidden', !!opts.renameOnly || !!def);
  const valueWrap = $('data-modal-value-wrap'); if(valueWrap) valueWrap.classList.add('hidden');
  const saveButton = $('data-modal-save');
  if (saveButton) saveButton.textContent = def ? 'Salvar' : 'Criar';
  modal.classList.remove('hidden');
  modal.dataset.renameOnly = opts.renameOnly ? '1' : '0';
  setTimeout(()=>kixRequestKeyboard(name),80);
}
function closeDataEditor(){ const m=$('data-create-modal'); if(m) m.classList.add('hidden'); activeDataEditId=null; window._kixPendingVariableSelector=null; }
function commitDataEditor(){
  const name=String($('data-modal-name')?.value||'').trim();
  const rawValue=String($('data-modal-value')?.value??'0');
  const scope=String(document.querySelector('input[name="dataScope"]:checked')?.value || $('data-modal-scope')?.value || 'object');
  const scopeSelect=$('data-modal-scope'); if(scopeSelect) scopeSelect.value=scope;
  if(!name){ toast('Digite um nome'); kixRequestKeyboard($('data-modal-name')); return; }
  try {
    if(activeDataEditId){
      const def=getDataDefinitionById(activeDataEditId); if(!def) throw new Error('Dado não encontrado');
      const renameOnly=$('data-create-modal')?.dataset.renameOnly==='1';
      renameDataDefinition(def,name);
      if(!renameOnly){ const parsed=Number(rawValue); const value=(rawValue.trim()!=='' && Number.isFinite(parsed)) ? parsed : rawValue; writeDataDefinitionValue(def,value,currentActor); save(); }
      closeDataEditor(); renderDataList($('data-search-input')?.value||''); toast('Dado atualizado');
    } else {
      const created = createDataDefinition(name,0,scope);
      const pendingVariableTarget = window._kixPendingVariableSelector;
      window._kixPendingVariableSelector = null;
      if (created && pendingVariableTarget) applyKixVariableSelectorValue(pendingVariableTarget, created.name);
      closeDataEditor(); renderDataList($('data-search-input')?.value||''); toast('Dado criado');
    }
  } catch(e){ toast(e?.message || 'Não foi possível salvar'); }
}
function openDataScreen(returnScreen='formula') {
  if(!currentProject){ toast('Abra um projeto'); return; }
  dataReturnScreen=returnScreen||'formula'; ensureProjectDataDefinitions(currentProject); renderDataList('');
  const search=$('data-search-input'); if(search) search.value='';
  $('data-search-wrap')?.classList.add('hidden');
  closeDataMiniMenu(); closeDataEditor();
  show('data');
}
function closeDataScreen(){ closeDataMiniMenu(); closeDataEditor(); try { navBack(); } catch (_) { show(dataReturnScreen||'formula',{noPush:true}); } }
function openFormulaCategoryScreen(category) {
  const cat=String(category||'').trim();
  if(!cat) return;
  if(cat==='Dado') { openDataScreen('formula'); return; }
  activeFormulaCategory=cat; formulaCategorySearchOpen=false;
  const screen=$('formula-category-screen'), title=$('formula-category-title'), list=$('formula-category-list'), searchWrap=$('formula-category-search-wrap'), search=$('formula-category-search');
  if(!screen||!title||!list) return;
  title.textContent=cat;
  screen.dataset.formulaCategory = cat;
  if(search) search.value=''; searchWrap?.classList.add('hidden');
  screen.classList.remove('hidden');
  $('formula-main-content')?.classList.add('hidden');
  closeFormulaCategoryMenu(); renderFormulaCategoryList('');
}
function closeFormulaCategoryScreen(){ closeFormulaCategoryMenu(); $('formula-category-screen')?.classList.add('hidden'); $('formula-text-screen')?.classList.add('hidden'); $('formula-main-content')?.classList.remove('hidden'); activeFormulaCategory=''; }
function renderFormulaCategoryList(filter=''){
  const list=$('formula-category-list'); if(!list) return;
  let items = [];
  if (Array.isArray(FORMULA_CATEGORIES[activeFormulaCategory])) items = [...FORMULA_CATEGORIES[activeFormulaCategory]];
  if (activeFormulaCategory === 'Propriedades') items = [...new Set([...(FORMULA_PROPS_AP||[]), ...(FORMULA_PROPS_MV||[])])];
  if (activeFormulaCategory === 'Objetos') items = currentProject ? getSceneActors().map(a => String(a.name||a.kixId||a.id||'')).filter(Boolean) : [];
  const q=String(filter||'').trim().toLowerCase(); list.innerHTML='';
  const matched=items.filter(x=>!q||String(x).toLowerCase().includes(q));
  if(!matched.length){ const empty=document.createElement('div'); empty.className='kix-formula-empty'; empty.textContent=q?'Nenhuma função encontrada':'Nenhuma função disponível'; list.appendChild(empty); return; }
  matched.forEach(item=>{
    const b=document.createElement('button');
    b.type='button';
    b.className='kix-formula-category-item';
    b.disabled = false;
    b.style.pointerEvents = 'auto';
    b.style.opacity = '1';
    b.dataset.formulaItem = String(item);
    b.dataset.formulaCategory = activeFormulaCategory;
    const label=document.createElement('span');
    label.textContent=String(item);
    b.append(label);
    b.onclick=()=>{ insertFormula(String(item)); closeFormulaCategoryScreen(); toast(String(item)); };
    list.appendChild(b);
  });
}
function toggleFormulaCategorySearch(){ formulaCategorySearchOpen=!formulaCategorySearchOpen; const wrap=$('formula-category-search-wrap'), inp=$('formula-category-search'); wrap?.classList.toggle('hidden',!formulaCategorySearchOpen); if(formulaCategorySearchOpen){ setTimeout(()=>{inp?.focus({preventScroll:true}); kixRequestKeyboard(inp);},40); } else if(inp){ inp.value=''; renderFormulaCategoryList(''); } }
function openFormulaCategoryMenu(anchor){ closeFormulaCategoryMenu(); const menu=document.createElement('div'); menu.id='formula-category-menu'; menu.className='kix-formula-category-menu';
  const add=(label,fn)=>{const b=document.createElement('button');b.type='button';b.className='kix-formula-category-action';b.textContent=label;b.onclick=e=>{e.stopPropagation();closeFormulaCategoryMenu();fn();};menu.appendChild(b);};
  add('Limpar pesquisa',()=>{const i=$('formula-category-search');if(i)i.value='';renderFormulaCategoryList('');});
  add('Voltar ao editor',closeFormulaCategoryScreen);
  document.body.appendChild(menu); const r=anchor.getBoundingClientRect(),w=Math.min(210,window.innerWidth-20);menu.style.width=w+'px';menu.style.left=Math.max(10,Math.min(window.innerWidth-w-10,r.right-w))+'px';menu.style.top=Math.min(window.innerHeight-menu.offsetHeight-10,r.bottom+6)+'px';
  const outside=e=>{if(!menu.contains(e.target)&&e.target!==anchor)closeFormulaCategoryMenu();}; const esc=e=>{if(e.key==='Escape')closeFormulaCategoryMenu();}; document.addEventListener('pointerdown',outside,true);document.addEventListener('keydown',esc,true);menu._cleanup=()=>{document.removeEventListener('pointerdown',outside,true);document.removeEventListener('keydown',esc,true);};
}
function closeFormulaCategoryMenu(){const m=$('formula-category-menu');if(m){try{m._cleanup?.();}catch(_){}m.remove();}}
function openFormulaTextScreen(){
  const screen=$('formula-text-screen'), input=$('formula-text-editor');
  if(!screen||!input)return;
  screen.classList.remove('hidden');
  screen.setAttribute('aria-hidden','false');
  $('formula-category-screen')?.classList.add('hidden');
  closeFormulaCategoryMenu();

  // ABC operates only on a text literal. Existing numeric/formula tokens are
  // not wrapped in quotes and are not rewritten when the editor opens.
  const current=String(formulaVal||'').trim();
  const isStandaloneText=/^(["'])([\s\S]*)\1$/.test(current);
  const rawText=isStandaloneText ? current.slice(1,-1).replace(/\\([\\"])/g,'$1') : '';
  input.value=rawText;
  input.setAttribute('data-formula-text-mode','append');
  setTimeout(()=>{
    kixRequestKeyboard(input);
    input.focus({preventScroll:true});
    input.selectionStart=input.selectionEnd=input.value.length;
  },60);
}
function closeFormulaTextScreen(){
  const screen=$('formula-text-screen'), input=$('formula-text-editor');
  if(input && document.activeElement===input) input.blur();
  if(screen){ screen.classList.add('hidden'); screen.setAttribute('aria-hidden','true'); }
}
function commitFormulaText(){
  const input=$('formula-text-editor');
  const t=String(input?.value||'');
  if(t.length){
    const quoted='"'+t.replace(/\\/g,'\\\\').replace(/"/g,'\\"')+'"';
    const current=String(formulaVal||'').trim();
    // Preserve existing numbers/formulas verbatim; ABC adds one text token.
    if (!current || current==='···' || current==='…' || /^("|')([\s\S]*)\1$/.test(current)) {
      formulaCursorIndex = quoted.length;
      setFormulaValue(quoted, {fresh:false});
    } else {
      const at = Math.max(0, Math.min(formulaCursorIndex, current.length));
      formulaCursorIndex = at + quoted.length;
      setFormulaValue(current.slice(0, at) + quoted + current.slice(at), {fresh:false});
    }
  }
  closeFormulaTextScreen();
}

// ===== PROJECTS =====
const KIX_PLUGIN_MINI_DOC = "# Kix 1.7.5 — Documentação oficial de desenvolvimento de plugins\n\n> **Público-alvo:** desenvolvedores humanos e agentes de IA.\n>\n> **Fonte de verdade:** `app/src/main/assets/kix-plugins.js`. Quando este documento ou o schema divergirem do runtime, o runtime vence.\n\n## 1. Visão geral\n\nUm plugin Kix é um manifesto JSON com categorias, blocos e, opcionalmente, UI declarativa e código de runtime.\n\nFluxo conceitual:\n\n```text\n.kixplugin / JSON\n    ↓\nnormalização do manifesto\n    ↓\ncategorias + blocos\n    ↓\nregistro no catálogo\n    ↓\neditor / palco / script\n    ↓\nhandler do bloco\n    ↓\nKix Plugin API\n    ↓\nprojeto / cena / ator / runtime\n```\n\nA instalação do plugin é persistente. A edição feita pelo editor interno também persiste automaticamente.\n\n## 2. Arquivo mínimo\n\n```json\n{\n  \"schema\": \"kix-plugin-v1\",\n  \"id\": \"exemplo-basico\",\n  \"name\": \"Exemplo Básico\",\n  \"version\": \"1.0.0\",\n  \"language\": \"javascript\",\n  \"categories\": [\n    {\n      \"id\": \"geral\",\n      \"name\": \"Geral\",\n      \"color\": \"#0F766E\",\n      \"body\": \"#CCFBF1\"\n    }\n  ],\n  \"blocks\": [\n    {\n      \"id\": \"notificar\",\n      \"name\": \"Notificar {mensagem}\",\n      \"categoryId\": \"geral\",\n      \"type\": \"action\",\n      \"params\": [\n        {\"name\": \"mensagem\", \"type\": \"text\", \"default\": \"Olá\"}\n      ],\n      \"handlerLanguage\": \"javascript\",\n      \"handler\": \"api.notify(api.params.get('mensagem', 'Olá'))\"\n    }\n  ]\n}\n```\n\n`name` é obrigatório. `id` pode ser omitido, mas manter um ID estável é altamente recomendado para que referências não mudem depois de uma edição.\n\n## 3. Campos do manifesto\n\nCampos reconhecidos pelo normalizador do Kix:\n\n`schema`, `id`, `name`, `version`, `icon`, `iconImage`, `author`, `description`, `language`, `enabled`, `categories`, `blocks`, `categoryOverrides`, `ui`, `runtime`, `capabilities`.\n\n### `schema`\n\nUse `kix-plugin-v1`.\n\n### `id`\n\nIdentificador persistente do plugin. O runtime higieniza o ID quando necessário.\n\n### `language`\n\nLinguagem padrão dos handlers. Nesta build, JavaScript é a linguagem integrada.\n\n### `enabled`\n\n`false` desativa o plugin sem removê-lo do armazenamento.\n\n### `capabilities`\n\nLista declarativa de capacidades solicitadas/descritas pelo plugin. **Não é uma sandbox de segurança.** O runtime do plugin continua sujeito às APIs realmente expostas nesta build.\n\n## 4. Categorias\n\nExemplo:\n\n```json\n{\n  \"id\": \"util\",\n  \"name\": \"Utilidades\",\n  \"color\": \"#0F766E\",\n  \"body\": \"#CCFBF1\",\n  \"family\": \"util\",\n  \"badge\": \"PLUGIN\",\n  \"order\": 0\n}\n```\n\nCampos:\n\n| Campo | Tipo | Comportamento |\n|---|---|---|\n| `id` | string | ID persistente da categoria |\n| `name` | string | texto exibido |\n| `color` | `#RRGGBB` | cor principal |\n| `body` | `#RRGGBB` | cor auxiliar/fundo |\n| `family` | string | agrupamento opcional |\n| `badge` | string | rótulo opcional |\n| `order` | number | ordem da categoria |\n\nO editor interno renumera `order` quando a ordem é modificada.\n\n## 5. Blocos\n\nTipos estruturais reconhecidos pelo normalizador:\n\n- `action` — ação normal.\n- `hat` — bloco de início/gatilho.\n- `loop` — estrutura de repetição; pode conter filhos.\n- `if` — estrutura condicional; pode conter filhos.\n- `note` — bloco anotação/nota.\n\nExemplo completo:\n\n```json\n{\n  \"id\": \"andar\",\n  \"name\": \"Seguir {objeto} por {valor} segundos\",\n  \"categoryId\": \"movimento\",\n  \"family\": \"motion\",\n  \"badge\": \"PLUGIN\",\n  \"color\": \"#2563EB\",\n  \"useCategoryColor\": false,\n  \"heightY\": 56,\n  \"multiline\": false,\n  \"template\": \"Seguir {objeto} por {valor} segundos\",\n  \"example\": \"Seguir jogador por 2 segundos\",\n  \"type\": \"action\",\n  \"params\": [\n    {\"name\":\"objeto\",\"type\":\"object\",\"default\":\"\"},\n    {\"name\":\"valor\",\"type\":\"number\",\"default\":2,\"placeholder\":\"2\"}\n  ],\n  \"presets\": [\"1\", \"2\", \"5\", \"10\"],\n  \"handlerLanguage\": \"javascript\",\n  \"handler\": \"const segundos = Number(api.params.get('valor', 2)); api.actor.move(segundos * 10, 0);\"\n}\n```\n\n### Campos estruturais\n\n| Campo | Função |\n|---|---|\n| `id` | identificador estável do bloco |\n| `name` | texto principal do Brick/editor |\n| `categoryId` | categoria dona do bloco |\n| `family` | agrupamento semântico |\n| `badge` | pequena marca visual |\n| `color` | cor própria quando `useCategoryColor` é falso |\n| `useCategoryColor` | usa a cor da categoria quando verdadeiro |\n| `heightY` / `height` | altura visual mínima; o runtime aplica mínimo de 32 |\n| `multiline` | permite apresentação em várias linhas |\n| `template` | texto/template usado como referência de apresentação |\n| `example` | exemplo humano para o editor/documentação |\n| `params` | parâmetros editáveis pelo usuário |\n| `type` | estrutura do Brick |\n| `canContainChildren` | permite filhos; `loop` e `if` já habilitam por padrão |\n| `ifElse` | marca condicional com alternativa |\n| `canBeChild` | permite inserção como filho |\n| `allowedParent` | pais permitidos |\n| `allowedChildren` | tipos permitidos como filhos |\n| `handlerLanguage` | linguagem do handler |\n| `handler` | código executado pelo bloco |\n| `code` | mapa alternativo por linguagem; o runtime seleciona o handler |\n| `overrideOf` | referência a um bloco que o plugin pretende substituir |\n| `presets` | presets rápidos; máximo de 64 entradas após normalização |\n| `enabled` | desativa o bloco sem removê-lo |\n\n## 6. Template vs. handler\n\nSão coisas diferentes.\n\n**Template:** descreve o que o usuário vê e quais placeholders existem.\n\n**Handler:** descreve o que acontece quando o Brick é executado.\n\nExemplo:\n\n```text\nTemplate:\nSeguir {objeto} por {valor} segundos\n```\n\nO runtime não executa o texto do template. O runtime executa o `handler`.\n\nOs nomes dos placeholders devem corresponder aos nomes dos parâmetros.\n\n## 7. Parâmetros\n\nTipos aceitos pela normalização:\n\n```text\ntext\nstring\nnumber\nbool\ncolor\nchoice\nsound\nimage\nlook\nappearance\nfolder\nscene\nobject\nactor\nfile\nurl\ncode\ndata\n```\n\nFormato geral:\n\n```json\n{\n  \"name\": \"valor\",\n  \"type\": \"number\",\n  \"default\": 1,\n  \"placeholder\": \"1\",\n  \"multiline\": false,\n  \"options\": []\n}\n```\n\n`options` é usado principalmente por `choice`.\n\nExemplo de escolha:\n\n```json\n{\n  \"name\": \"direção\",\n  \"type\": \"choice\",\n  \"default\": \"direita\",\n  \"options\": [\"esquerda\", \"direita\", \"cima\", \"baixo\"]\n}\n```\n\nTexto longo:\n\n```json\n{\"name\":\"mensagem\",\"type\":\"text\",\"multiline\":true}\n```\n\n## 8. API do handler\n\nOs handlers JavaScript recebem a API `api`. O código não deve presumir métodos que não aparecem nesta seção.\n\n### Identidade do plugin e bloco\n\n```js\napi.plugin.id\napi.plugin.name\napi.plugin.version\n\napi.block.id\napi.block.name\napi.block.params\n```\n\n`api.block.params` contém uma cópia dos parâmetros coletados para aquela execução.\n\n### Parâmetros\n\n```js\napi.params.get('valor', 1)\napi.params.all()\n```\n\n### Ator atual\n\n```js\napi.actor.data\napi.actor.getName()\napi.actor.setName('Jogador')\napi.actor.setVisible(true)\napi.actor.setPosition(100, 50)\napi.actor.getPosition()\napi.actor.move(10, 0)\napi.actor.getSize()\napi.actor.setSize(120)\napi.actor.getDirection()\napi.actor.setDirection(90)\napi.actor.getVelocity()\napi.actor.setVelocity(3, 0)\napi.actor.isMoving()\napi.actor.isVisible()\napi.actor.setVariable('vida', 100)\napi.actor.getVariable('vida', 0)\n```\n\nUse `api.actor` para a lógica do objeto que está executando o Brick.\n\n### Objetos da cena\n\n```js\napi.actors.list()\napi.actors.count()\napi.actors.get(0)\napi.actors.find('Inimigo')\napi.actors.findById('actor-id')\n```\n\n`list()` devolve informações de ID, nome, visibilidade, posição, tamanho e direção.\n\n`count()` devolve a quantidade de objetos da cena atual.\n\n`find(name)` procura por nome sem diferenciar maiúsculas e minúsculas.\n\n`findById(id)` procura por ID estável.\n\n### Física e colisão\n\n```js\napi.physics.getGravity()\napi.physics.setGravity(9.8)\napi.physics.getMass()\napi.physics.setMass(1)\napi.physics.getFriction()\napi.physics.setFriction(0.2)\napi.physics.pauseActor(true)\napi.physics.setCollisionMode('damage')\napi.physics.getCollisionMode()\napi.physics.overlaps('Inimigo')\n```\n\nEsses métodos operam sobre o ator atual e usam a implementação de colisão/física já existente no runtime.\n\n### Projeto\n\n```js\napi.project.getName()\napi.project.setName('Meu projeto')\napi.project.getDescription()\napi.project.setDescription('Descrição')\napi.project.getScenes()\napi.project.getFiles()\napi.project.save()\n```\n\n`getScenes()` e `getFiles()` devolvem cópias do estado persistido atual.\n\n### Cena\n\n```js\napi.scene.getIndex()\napi.scene.getName()\napi.scene.setName('Fase 2')\napi.scene.switchTo('Fase 2', {fade:0.25, color:'#000000', style:'fade'})\napi.scene.restart({fade:0.1})\n```\n\n`switchTo` e `restart` encaminham para a mudança de cena real do Kix quando essa ponte está disponível.\n\n### Variáveis globais de runtime\n\n```js\napi.globals.get('pontuacao', 0)\napi.globals.set('pontuacao', 42)\n```\n\nIsto acessa os globais do runtime atual.\n\n### Armazenamento privado do plugin\n\n```js\napi.storage.get('config', {})\napi.storage.set('config', {modo:'hard'})\napi.storage.remove('config')\napi.storage.clear()\napi.storage.has('config')\napi.storage.keys()\napi.storage.key('config')\n```\n\nAs chaves são prefixadas internamente pelo ID do plugin, reduzindo colisões entre plugins.\n\n### Interface\n\n```js\napi.ui.toast('Olá')\napi.ui.setText('#meu-elemento', 'Novo texto')\napi.ui.setVisible('#meu-elemento', true)\napi.ui.setStyle('#meu-elemento', 'opacity:0.8;')\napi.ui.addText('#host', 'beforeend', 'Olá', 'minha-classe')\n```\n\nUse seletores conhecidos e evite criar milhares de nós.\n\n### Áudio\n\n```js\nawait api.audio.play('arquivo-ou-url')\napi.audio.stopAll()\n```\n\nO método retorna o objeto de áudio quando o ambiente permite a criação, mas a reprodução depende das regras do ambiente/WebView. `stopAll()` interrompe os sons gerenciados pelo runtime e a síntese de voz ativa.\n\n### Rede\n\n```js\nconst resposta = await api.fetch('https://example.com/api')\n```\n\nO wrapper `api.fetch` encaminha os mesmos argumentos ao `fetch` real do WebView sem impor uma whitelist própria de esquema ou transformar o primeiro argumento em texto. As regras do WebView/Android e do servidor continuam valendo.\n\n### Acesso avançado sem sandbox\n\nJavaScript de plugin é código confiável local nesta build. Não há uma sandbox de linguagem separada. O handler recebe `api.raw` (o `window/globalThis` do WebView), `api.host` (atalhos para `document`, `navigator`, `location`, storages, `fetch`, `Android`, `KixEngine` e `KixPluginRuntime`), `api.app` (a ponte de aplicação anexada pelo Kix) e `api.engine` (o `KixEngine` global quando existir).\n\nIsso permite ao criador ir além das APIs de alto nível sem o runtime impor uma falsa limitação. APIs nativas do Android continuam limitadas ao que a ponte `Android` realmente expõe nesta build.\n\n### Tempo e serialização\n\n```js\nconst agora = api.now()\nawait api.wait(250)\nconst texto = api.json({ok:true})\nconst valor = api.parse(texto, null)\n```\n\n### Runtime\n\n```js\napi.runtime.get('fps', 0)\napi.runtime.getMany(['fps', 'elapsedSeconds'])\napi.runtime.isRunning()\napi.runtime.isPaused()\napi.runtime.has('fps')\napi.runtime.set('flag', true)\napi.runtime.setMany({a:1,b:2})\n```\n\nA API devolve apenas o valor se ele existir e tenta clonar valores complexos.\n\n### Entrada e dispositivo\n\n```js\napi.input.getPointer()\napi.input.isDown()\napi.device.getViewport()\napi.device.getLanguage()\napi.device.isOnline()\napi.device.canVibrate()\napi.device.vibrate(30)\napi.device.hasTouch()\napi.device.getPlatform()\napi.device.getScreenSize()\n```\n\nEssas funções consultam o estado real do WebView/runtime atual.\n\n### Palco\n\n```js\napi.stage.getSize()\napi.stage.getBounds()\napi.stage.getPointer()\napi.stage.screenToWorld(clientX, clientY)\napi.stage.isRunning()\napi.stage.getMode()\n```\n\n`screenToWorld()` reutiliza a conversão real do engine para o palco em execução.\n\n### Câmera\n\n```js\napi.camera.getPosition()\napi.camera.setPosition(100, 50)\napi.camera.getZoom()\napi.camera.setZoom(1.5)\napi.camera.getRotation()\napi.camera.setRotation(15)\napi.camera.reset()\napi.camera.follow('Jogador')\napi.camera.stopFollow()\napi.camera.getSmoothing()\napi.camera.setSmoothing(0.15)\napi.camera.getDeadZone()\napi.camera.setDeadZone(40, 40)\napi.camera.getLookAhead()\napi.camera.setLookAhead(30)\napi.camera.getAxisLock()\napi.camera.setAxisLock('x')\napi.camera.getOffset()\napi.camera.setOffset(10, 0)\n```\n\nAs coordenadas públicas da câmera usam o mesmo espaço de mundo exposto pelo engine.\n\n### Área de transferência\n\n```js\nconst texto = await api.clipboard.readText()\nawait api.clipboard.writeText('Olá')\n```\n\nA API retorna `null`/`false` quando a permissão ou a implementação do WebView não estiver disponível.\n\n### Tilemap\n\n```js\napi.tilemap.list()\napi.tilemap.get('tilemap-id')\napi.tilemap.getCell('tilemap-id', 0, 0)\n```\n\nOs métodos são somente leitura e devolvem cópias dos dados persistidos.\n\n### Partículas\n\n```js\napi.particles.list()\napi.particles.get('emitter-id')\napi.particles.isRunning('emitter-id')\n```\n\n`isRunning()` consulta os emissores ativos do runtime atual.\n\n### Matemática\n\n```js\napi.math.clamp(v, min, max)\napi.math.lerp(a, b, t)\napi.math.random(min, max)\napi.math.round(v)\napi.math.floor(v)\napi.math.ceil(v)\napi.math.abs(v)\napi.math.min(a, b, c)\napi.math.max(a, b, c)\napi.math.distance(x1, y1, x2, y2)\napi.math.angle(x1, y1, x2, y2)\napi.math.degToRad(graus)\napi.math.radToDeg(radianos)\napi.math.map(valor, deMin, deMax, paraMin, paraMax)\napi.math.randomInt(min, max)\napi.math.sign(v)\napi.math.sin(v)\napi.math.cos(v)\napi.math.tan(v)\napi.math.atan2(y, x)\napi.math.pow(a, b)\napi.math.sqrt(v)\napi.math.mod(a, b)\napi.math.normalize(x, y)\n```\n\nAs funções trigonométricas recebem e retornam radianos, exceto `angle()`, que retorna graus.\n\n### Canvas\n\n```js\nconst canvas = api.canvas.make(320, 180)\n```\n\nO método cria um elemento Canvas local. Ele não publica automaticamente esse canvas no palco.\n\n### Crypto\n\n```js\napi.crypto\n```\n\nQuando disponível, aponta para `globalThis.crypto` do WebView.\n\n### Notificação\n\n```js\napi.notify('Concluído')\n```\n\nÉ o atalho de notificação/toast do runtime.\n\n## 9. Async e ciclo de vida\n\nHandlers podem usar `await`.\n\n```js\napi.notify('Começou')\nawait api.wait(500)\napi.notify('Terminou')\n```\n\nEvite loops síncronos infinitos:\n\n```js\n// NÃO FAÇA\nwhile (true) {}\n```\n\nPrefira espera assíncrona ou blocos estruturais do Kix.\n\n## 10. UI declarativa do manifesto\n\nA seção `ui` suporta regras e inserções.\n\nExemplo:\n\n```json\n{\n  \"ui\": {\n    \"rules\": [\n      {\n        \"id\": \"titulo\",\n        \"selector\": \"#meu-titulo\",\n        \"text\": \"Olá\",\n        \"visible\": true,\n        \"title\": \"Título atualizado\"\n      }\n    ],\n    \"inserts\": [\n      {\n        \"id\": \"botao\",\n        \"selector\": \"#host\",\n        \"position\": \"beforeend\",\n        \"tag\": \"button\",\n        \"text\": \"Executar\",\n        \"className\": \"meu-botao\",\n        \"clickCode\": \"api.notify('clicado')\"\n      }\n    ]\n  }\n}\n```\n\n### `ui.rules`\n\nPropriedades suportadas pelo normalizador:\n\n`selector`, `text`, `cssText`, `visible`, `title`, `className`.\n\n### `ui.inserts`\n\nPosições aceitas:\n\n`beforebegin`, `afterbegin`, `beforeend`, `afterend`.\n\nTags permitidas pelo normalizador:\n\n`div`, `span`, `p`, `button`, `label`.\n\n## 11. Runtime global\n\nO manifesto pode declarar código de inicialização:\n\n```json\n{\n  \"runtime\": {\n    \"javascript\": \"api.notify('Plugin carregado')\"\n  }\n}\n```\n\nTambém podem existir `runtime.python`, `runtime.lua` e `runtime.java` no manifesto, porém isso não significa que esses runtimes estejam ativos. Eles dependem de um executor registrado.\n\nA extensão de linguagem é:\n\n```js\nKixPluginRuntime.registerLanguageRuntime(language, executor)\n```\n\nSem um executor real registrado, não trate Python/Lua/Java como linguagens integradas.\n\n## 12. Editor de plugin integrado ao Kix\n\nA versão 1.7.5 possui um editor de objetos de plugin que se comporta como as outras áreas de criação do app.\n\n### Categorias\n\nO fluxo é:\n\n```text\nPlugins → Categoria → [+] → editor exclusivo\n```\n\nCada categoria possui pré-visualização 1:1 e edição ao vivo.\n\n### Blocos\n\nO fluxo é:\n\n```text\nPlugins → Blocos → [+] → editor exclusivo\n```\n\nA prévia mostra o Brick enquanto o usuário altera nome, parâmetros, cor, template, tipo e demais propriedades.\n\n### Autosave\n\nAs mudanças do editor são sincronizadas automaticamente. Sair da tela confirma a versão atual do rascunho.\n\n### Menu `⋮`\n\nOs objetos possuem menu contextual para editar, reordenar e excluir.\n\n### Importação e exportação\n\nO gerenciador aceita um ou vários manifestos `.kixplugin`/JSON. Também aceita o pacote `.kixplugins.json` produzido por `exportAll`, no formato `{ \"schema\": \"kix-plugin-bundle-v1\", \"plugins\": [ ... ] }`.\n\nO editor exporta o plugin atual e o gerenciador de Plugins pode exportar todos os plugins instalados em um único arquivo. No Android, o Kix usa o seletor nativo de documentos quando a ponte `Android` está disponível.\n\n## 13. Presets\n\nOs presets podem ser enviados como array:\n\n```json\n{\"presets\":[\"1\",\"2\",\"5\",\"10\"]}\n```\n\nOu como texto separado por linhas/vírgulas:\n\n```json\n{\"presets\":\"1\\n2\\n5\\n10\"}\n```\n\nO runtime normaliza isso para uma lista de strings com no máximo 64 entradas.\n\n## 14. Substituição de nativos\n\nO campo `overrideOf` e `categoryOverrides` existem para cenários de integração/substituição.\n\nUse IDs estáveis e não altere IDs nativos sem conhecer o catálogo alvo.\n\nOverrides de categoria podem usar IDs iniciados por `native:`.\n\nNão suponha que qualquer nome textual substitui um bloco nativo. A associação confiável é por ID/registro.\n\n## 15. Persistência e compatibilidade\n\nO Kix armazena os manifestos instalados localmente e preserva as informações necessárias para reconstruir os blocos do projeto.\n\nVariáveis do projeto e armazenamento do plugin são conceitos diferentes:\n\n```text\nprojeto/runtime\n  └── variáveis/globais\n\nplugin\n  └── api.storage\n```\n\nNão presuma sincronização automática entre aparelhos.\n\n## 16. Segurança prática\n\nJavaScript de plugin roda localmente no WebView da aplicação. O Kix não transforma `capabilities` em uma sandbox.\n\nBoas práticas:\n\n- instale somente plugins confiáveis;\n- revise handlers antes de importar;\n- trate acesso de rede como parte do código confiável do plugin;\n- lembre que as políticas do WebView/Android/servidor continuam valendo;\n- não baixe e execute código arbitrário sem uma política de confiança;\n- não faça manipulação pesada do DOM a cada frame.\n\n## 17. Guia para agentes de IA\n\n### Processo recomendado\n\n1. Leia este documento.\n2. Leia `docs/KIX_PLUGIN_SCHEMA.json`.\n3. Consulte `app/src/main/assets/kix-plugins.js` quando houver dúvida.\n4. Identifique se a tarefa é de categoria, Brick, handler, UI ou runtime.\n5. Gere o menor manifesto que resolve a tarefa.\n6. Use somente APIs documentadas.\n7. Preserve IDs existentes ao editar um plugin.\n8. Faça `categoryId` apontar para uma categoria real.\n9. Faça cada placeholder do template corresponder a um parâmetro.\n10. Valide JSON antes de entregar.\n\n### Regra de não-invenção\n\nUm agente **não deve** inventar:\n\n- nomes de APIs;\n- tipos de parâmetros;\n- propriedades do manifesto;\n- tipos estruturais;\n- executores de linguagem;\n- permissões de rede;\n- sincronização multiplayer;\n- comportamento de APIs externas.\n\nQuando um requisito depender de algo não documentado/implementado, marque:\n\n```text\n[NÃO VERIFICADO]\n```\n\n### Heurística para escolher API\n\n```text\nPrecisa do valor inserido pelo usuário?\n→ api.params\n\nPrecisa mexer no ator atual?\n→ api.actor\n\nPrecisa procurar outros objetos?\n→ api.actors\n\nPrecisa mexer no projeto?\n→ api.project\n\nPrecisa mexer na cena?\n→ api.scene\n\nPrecisa de dado global de execução?\n→ api.globals\n\nPrecisa armazenar configuração própria?\n→ api.storage\n\nPrecisa alterar uma interface conhecida?\n→ api.ui\n\nPrecisa esperar?\n→ api.wait\n\nPrecisa de cálculo?\n→ api.math\n```\n\n## 18. Exemplo de plugin para IA gerar\n\n```json\n{\n  \"schema\":\"kix-plugin-v1\",\n  \"id\":\"movimento-extra\",\n  \"name\":\"Movimento Extra\",\n  \"version\":\"1.0.0\",\n  \"language\":\"javascript\",\n  \"categories\":[\n    {\n      \"id\":\"movimento-extra\",\n      \"name\":\"Movimento Extra\",\n      \"color\":\"#2563EB\",\n      \"body\":\"#DBEAFE\"\n    }\n  ],\n  \"blocks\":[\n    {\n      \"id\":\"mover-direita\",\n      \"name\":\"Mover {valor} passos para direita\",\n      \"categoryId\":\"movimento-extra\",\n      \"type\":\"action\",\n      \"template\":\"Mover {valor} passos para direita\",\n      \"params\":[\n        {\"name\":\"valor\",\"type\":\"number\",\"default\":10,\"placeholder\":\"10\"}\n      ],\n      \"handlerLanguage\":\"javascript\",\n      \"handler\":\"const valor = Number(api.params.get('valor', 10)) || 0; api.actor.move(valor, 0);\"\n    }\n  ]\n}\n```\n\n## 19. Checklist automático antes de entregar um plugin\n\n```text\n[ ] JSON válido\n[ ] schema = kix-plugin-v1\n[ ] name preenchido\n[ ] id estável\n[ ] IDs de categoria únicos\n[ ] IDs de bloco únicos\n[ ] categoryId de cada bloco existe\n[ ] type é action/hat/loop/if/note\n[ ] placeholders possuem parâmetros equivalentes\n[ ] tipos de parâmetro pertencem à lista oficial\n[ ] choice possui options quando necessário\n[ ] presets são strings após normalização\n[ ] handlerLanguage é intencional\n[ ] nenhuma API inventada\n[ ] acesso de rede segue as políticas do ambiente\n[ ] não há loop síncrono infinito\n[ ] não há milhares de nós criados por execução\n[ ] plugin pode ser reinstalado sem duplicar IDs\n```\n\n## Kix Game API\n\nA partir do Kix 1.7.5, handlers de plugins recebem uma fachada de jogo com a seguinte estrutura:\n\n```text\nKix Game API\n├── actor\n├── actors\n├── physics\n├── collision\n├── animation\n├── appearance\n├── audio\n├── particles\n├── camera\n├── tilemap\n├── input\n├── controls\n├── hud\n├── ui\n├── scene\n├── project\n├── save\n├── timers\n├── events\n├── networking\n├── multiplayer\n├── assets\n├── math\n└── debug\n```\n\nA fachada reutiliza as implementações existentes do Kix quando elas já estão disponíveis; ela não cria uma segunda engine, um segundo sistema de drag ou um segundo sistema de áudio. Consulte `docs/KIX_GAME_API.md` para o contrato resumido.\n\n`[NÃO VERIFICADO]`: interoperabilidade com um servidor multiplayer específico de terceiros.\n\n`[NÃO VERIFICADO]`: transporte TCP/UDP nativo quando a bridge Android `global.kixNetwork` não estiver presente.\n\n## 20. Fontes internas da implementação\n\nPara desenvolver ferramentas em cima do Kix, use estas referências do projeto:\n\n```text\napp/src/main/assets/kix-plugins.js\napp/src/main/assets/app.js\napp/src/main/assets/engine.js\ndocs/KIX_PLUGIN_SCHEMA.json\nexamples/KixPlugin.AI_TEMPLATE.kixplugin\n```\n\nQuando este guia, o schema e uma implementação concreta divergirem, inspecione primeiro `kix-plugins.js`, porque ele normaliza o manifesto e cria a API do handler.\n\n## 21. Limites conhecidos\n\nJavaScript é o runtime de plugin integrado desta build.\n\nPython, Lua e Java podem ser declarados, mas só funcionam quando um executor real for registrado por `registerLanguageRuntime`.\n\nRecursos externos, multiplayer, sincronização entre projetos, permissões do sistema operacional e APIs nativas do Android não devem ser assumidos a partir deste manifesto.\n\nQualquer uma dessas extensões precisa de uma integração real correspondente.\n\n---\n\n**Versão do documento:** Kix 1.7.5\n**Revisão de API:** conforme o runtime presente nesta build.\n\n\n## Entrada de texto em runtime (não bloqueante)\n\n`Perguntar ao usuário`, `Pedir texto ao usuário` e `Escrever texto em tempo real` usam um overlay de entrada sobre o palco. Eles não pausam `runtime`, não chamam `togglePause()` e não bloqueiam a coroutine atual. Durante a digitação, `onInput` recebe o valor atual e deve persistir o valor na variável desejada. Plugins podem usar `window.openRuntimeInputOverlay({title, value, multiline, confirmText, onInput, onConfirm, onCancel})`.\n\nO Back do Android é consumido primeiro pelo overlay: a entrada é fechada e o Kix permanece no Play em vez de sair do aplicativo. Ao abandonar o Play, qualquer entrada ativa é encerrada automaticamente.\n\n\n---\n\n# 22. Referência profissional para humanos e IAs\n\nEsta seção é a referência operacional para criar plugins Kix 1.7.5. O manifesto continua sendo `kix-plugin-v1` e `app/src/main/assets/kix-plugins.js` continua sendo a autoridade do runtime.\n\n## 22.1 Anatomia mínima de um plugin\n\n```json\n{\n  \"schema\": \"kix-plugin-v1\",\n  \"id\": \"meu-plugin\",\n  \"name\": \"Meu Plugin\",\n  \"version\": \"1.0.0\",\n  \"description\": \"Descrição clara para o usuário\",\n  \"language\": \"javascript\",\n  \"enabled\": true,\n  \"categories\": [],\n  \"blocks\": [],\n  \"capabilities\": []\n}\n```\n\nIDs devem ser estáveis. Não troque o `id` de um plugin já instalado apenas para mudar o nome mostrado ao usuário.\n\n## 22.2 Criando uma categoria\n\nUma categoria é declarada em `categories`:\n\n```json\n{\n  \"id\": \"combate\",\n  \"name\": \"Combate\",\n  \"color\": \"#DC2626\",\n  \"body\": \"#FEE2E2\",\n  \"badge\": \"GAME\",\n  \"order\": 20\n}\n```\n\nRegras:\n\n- `id`: identificador interno único dentro do plugin;\n- `name`: nome mostrado na UI;\n- `color`: cor principal dos Bricks da categoria quando `useCategoryColor` estiver ativo;\n- `body`: cor de corpo/área da categoria;\n- `badge`: identificação opcional;\n- `order`: posição relativa quando usada pelo editor.\n\nUm Brick usa a categoria declarando `categoryId`:\n\n```json\n{\n  \"id\": \"causar-dano\",\n  \"name\": \"Causar {dano} de dano\",\n  \"categoryId\": \"combate\"\n}\n```\n\n`categoryId` deve apontar para uma categoria realmente existente. Um Brick apontando para uma categoria inexistente está incompleto.\n\n## 22.3 Criando um Brick\n\nExemplo completo:\n\n```json\n{\n  \"id\": \"causar-dano\",\n  \"name\": \"Causar {dano} de dano\",\n  \"categoryId\": \"combate\",\n  \"type\": \"action\",\n  \"useCategoryColor\": true,\n  \"heightY\": 56,\n  \"template\": \"Causar {dano} de dano\",\n  \"example\": \"Causar 10 de dano\",\n  \"params\": [\n    {\n      \"name\": \"dano\",\n      \"type\": \"number\",\n      \"default\": 10,\n      \"placeholder\": \"10\"\n    }\n  ],\n  \"handlerLanguage\": \"javascript\",\n  \"handler\": \"const dano = Number(api.params.get('dano', 10)) || 0;\"\n}\n```\n\nO texto do `template` define a aparência do Brick. O `handler` define o comportamento real.\n\nNão escreva um placeholder `{dano}` sem criar um parâmetro `dano` correspondente.\n\n## 22.4 Tipos de parâmetros\n\nOs tipos reconhecidos pela normalização atual são:\n\n```text\ntext\nstring\nnumber\nbool\ncolor\nchoice\nsound\nimage\nlook\nappearance\nfolder\nscene\nobject\nactor\nfile\nurl\ncode\ndata\n```\n\nExemplo de `choice`:\n\n```json\n{\n  \"name\": \"direção\",\n  \"type\": \"choice\",\n  \"default\": \"direita\",\n  \"options\": [\"esquerda\", \"direita\", \"cima\", \"baixo\"]\n}\n```\n\n## 22.5 API de arquivos\n\nUse `api.files` para dados que devem fazer parte do projeto.\n\n```js\napi.files.create('data/config.json', '{\"modo\":\"hard\"}', 'application/json;charset=utf-8')\napi.files.writeText('data/config.json', 'texto')\nconst texto = api.files.readText('data/config.json')\napi.files.writeJSON('data/state.json', {vida:100, fase:2})\nconst state = api.files.readJSON('data/state.json', {})\napi.files.saveVariables('save/profile.json', {vida:100, moedas:4})\nconst profile = api.files.loadVariables('save/profile.json', {})\napi.files.saveList('save/inventory.json', ['espada', 'poção'])\nconst inventory = api.files.loadList('save/inventory.json', [])\napi.files.redirect('save/profile.json', 'save/backup/profile.json')\napi.files.export('save/backup/profile.json', 'profile.json')\n```\n\nNão trate o `path` como caminho absoluto do Android. O `path` é virtual dentro do modelo `project.files`.\n\n## 22.6 API de listas\n\nA API pública usa `runtime.lists` já existente:\n\n```js\napi.lists.create('inventario', ['espada'])\napi.lists.add('inventario', 'poção')\nconst itens = api.lists.get('inventario', [])\napi.files.saveList('save/inventario.json', itens)\n```\n\nPara persistir várias listas, crie um objeto:\n\n```js\napi.files.writeJSON('save/all-lists.json', {\n  inventario: api.lists.get('inventario', []),\n  armas: api.lists.get('armas', []),\n  magias: api.lists.get('magias', [])\n})\n```\n\n## 22.7 API WebView\n\nUse `api.webview` para operações simples e previsíveis relacionadas ao WebView host:\n\n```js\nconst url = api.webview.getUrl()\nconst ready = api.webview.getReadyState()\napi.webview.setTitle('Meu sistema')\napi.webview.scrollTo(0, 0)\napi.webview.openExternal('https://example.com')\n```\n\nNão use `openExternal()` com esquemas como `intent:`, `file:`, `javascript:` ou URIs arbitrárias. A fachada aceita somente `http` e `https`.\n\nO handler ainda pode usar `api.host.document` e `api.host.window`, mas isso permanece acesso avançado no mesmo realm e não constitui sandbox.\n\n## 22.8 Escolhendo a API correta\n\n```text\nParâmetro do Brick\n→ api.params\n\nAtor atual\n→ api.actor\n\nOutros atores\n→ api.actors\n\nFísica/colisão\n→ api.physics / api.collision\n\nProjeto\n→ api.project\n\nCena\n→ api.scene\n\nVariável global do runtime\n→ api.globals\n\nLista de runtime\n→ api.lists\n\nArquivo do projeto\n→ api.files\n\nSave slot de jogo\n→ api.save\n\nUI conhecida\n→ api.ui / api.hud\n\nWebView host\n→ api.webview\n\nTempo\n→ api.timers / api.wait\n\nEventos\n→ api.events\n\nCálculo\n→ api.math\n\nDiagnóstico\n→ api.debug\n```\n\n## 22.9 Exemplo completo de plugin de dados\n\n```json\n{\n  \"schema\": \"kix-plugin-v1\",\n  \"id\": \"dados-save\",\n  \"name\": \"Dados e Saves\",\n  \"version\": \"1.0.0\",\n  \"language\": \"javascript\",\n  \"categories\": [\n    {\n      \"id\": \"dados\",\n      \"name\": \"Dados\",\n      \"color\": \"#2563EB\",\n      \"body\": \"#DBEAFE\",\n      \"order\": 10\n    }\n  ],\n  \"blocks\": [\n    {\n      \"id\": \"salvar-perfil\",\n      \"name\": \"Salvar perfil em {arquivo}\",\n      \"categoryId\": \"dados\",\n      \"type\": \"action\",\n      \"template\": \"Salvar perfil em {arquivo}\",\n      \"params\": [\n        {\n          \"name\": \"arquivo\",\n          \"type\": \"text\",\n          \"default\": \"save/profile.json\"\n        }\n      ],\n      \"handlerLanguage\": \"javascript\",\n      \"handler\": \"api.files.saveVariables(api.params.get('arquivo','save/profile.json'), {vida:api.actor.getVariable('vida',0), nome:api.actor.getName()})\"\n    }\n  ]\n}\n```\n\n## 22.10 Regras obrigatórias para IAs\n\nUma IA que gera plugins deve:\n\n1. ler `docs/KIX_PLUGIN_SCHEMA.json`;\n2. ler `docs/KIX_GAME_API.md`;\n3. consultar `app/src/main/assets/kix-plugins.js` em caso de dúvida;\n4. nunca inventar um método que não esteja implementado/documentado;\n5. validar que cada `categoryId` existe;\n6. validar que cada placeholder possui parâmetro correspondente;\n7. preservar IDs estáveis ao editar plugins;\n8. não transformar uma API não verificada em requisito garantido;\n9. preferir a menor API real que resolve o problema;\n10. marcar qualquer dependência não confirmada como `[NÃO VERIFICADO]`.\n\n## 22.11 Anti-padrões\n\nNão faça:\n\n```text\n[ERRO] Criar uma segunda lista fora de runtime.lists sem necessidade\n[ERRO] Gravar dados de projeto diretamente em caminhos absolutos do Android\n[ERRO] Fingir que redirect() é movimentação física no armazenamento\n[ERRO] Usar API inventada de WebView\n[ERRO] Criar um novo sistema de arquivo paralelo ao project.files\n[ERRO] Declarar sandbox onde não existe\n[ERRO] Criar categoria sem id estável\n[ERRO] Apontar Brick para categoryId inexistente\n[ERRO] Criar placeholder sem parâmetro\n```\n\n## 22.12 Checklist de integração\n\n```text\n[ ] schema válido\n[ ] id estável\n[ ] categorias válidas\n[ ] categoryId dos Bricks válidos\n[ ] placeholders correspondentes aos params\n[ ] handlers usam APIs reais\n[ ] arquivo/lista usa project.files/runtime.lists\n[ ] exportação usa a bridge existente quando disponível\n[ ] URL externa é http/https\n[ ] não há sandbox falsa\n[ ] JSON válido\n[ ] JS válido\n[ ] testes de regressão executados\n```\n";
const KIX_PLUGIN_SCHEMA_DOC = "{\n  \"$schema\": \"https://json-schema.org/draft/2020-12/schema\",\n  \"title\": \"Kix Plugin Manifest v1\",\n  \"description\": \"Reference schema for Kix 1.7.5; kix-plugins.js remains the runtime authority.\",\n  \"type\": \"object\",\n  \"required\": [\n    \"name\"\n  ],\n  \"properties\": {\n    \"schema\": {\n      \"const\": \"kix-plugin-v1\"\n    },\n    \"id\": {\n      \"type\": \"string\"\n    },\n    \"name\": {\n      \"type\": \"string\",\n      \"minLength\": 1\n    },\n    \"version\": {\n      \"type\": \"string\"\n    },\n    \"icon\": {\n      \"type\": \"string\"\n    },\n    \"iconImage\": {\n      \"type\": \"string\"\n    },\n    \"author\": {\n      \"type\": \"string\"\n    },\n    \"description\": {\n      \"type\": \"string\"\n    },\n    \"language\": {\n      \"type\": \"string\"\n    },\n    \"enabled\": {\n      \"type\": \"boolean\"\n    },\n    \"categories\": {\n      \"type\": \"array\"\n    },\n    \"blocks\": {\n      \"type\": \"array\"\n    },\n    \"categoryOverrides\": {\n      \"type\": \"array\"\n    },\n    \"ui\": {\n      \"type\": \"object\"\n    },\n    \"runtime\": {\n      \"type\": \"object\"\n    },\n    \"capabilities\": {\n      \"type\": \"array\",\n      \"items\": {\n        \"type\": \"string\"\n      }\n    }\n  },\n  \"$defs\": {\n    \"parameterType\": {\n      \"enum\": [\n        \"text\",\n        \"string\",\n        \"number\",\n        \"bool\",\n        \"color\",\n        \"choice\",\n        \"sound\",\n        \"image\",\n        \"look\",\n        \"appearance\",\n        \"folder\",\n        \"scene\",\n        \"object\",\n        \"actor\",\n        \"file\",\n        \"url\",\n        \"code\",\n        \"data\"\n      ]\n    },\n    \"blockType\": {\n      \"enum\": [\n        \"action\",\n        \"hat\",\n        \"loop\",\n        \"if\",\n        \"note\"\n      ]\n    }\n  }\n}\n";

function downloadKixPluginMiniDoc(){
  try {
    const blob = new Blob([KIX_PLUGIN_MINI_DOC], {type:'text/markdown;charset=utf-8'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'Kix_Plugins_Mini_Documentacao.md';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(url), 1000);
    toast('Documentação baixada');
  } catch(e) { console.error('Kix plugin mini doc', e); toast('Não foi possível baixar a documentação'); }
}

function downloadKixPluginSchemaDoc(){
  try { const blob=new Blob([KIX_PLUGIN_SCHEMA_DOC],{type:'application/json;charset=utf-8'}); const url=URL.createObjectURL(blob); const link=document.createElement('a'); link.href=url; link.download='Kix_Plugin_Schema.json'; document.body.appendChild(link); link.click(); link.remove(); setTimeout(()=>URL.revokeObjectURL(url),1000); toast('Schema baixado'); }
  catch(e){ console.error('Kix plugin schema doc',e); toast('Não foi possível baixar o schema'); }
}

function openTutorialScreen() {
  closeSheets();
  const el = $('screen-tutorial');
  if (!el) return;
  const body = $('tutorial-body');
  if (body) body.innerHTML = `
    <div class="space-y-4 text-[13px] leading-5 text-[#D2D2D7]">
      <section><h3 class="text-[14px] font-medium text-white mb-1">Como começar</h3><p>Abra um projeto, escolha uma cena, crie um objeto e entre em Scripts. Arraste blocos para montar o comportamento.</p></section>
      <section><h3 class="text-[14px] font-medium text-white mb-1">Categorias principais</h3><ul class="space-y-1 text-[#B7B7BF]"><li><b>Evento:</b> começa scripts quando algo acontece.</li><li><b>Controle:</b> repetições, condições e fluxo.</li><li><b>Dados:</b> variáveis, listas e valores.</li><li><b>Movimento:</b> posição, direção, velocidade e colisões.</li><li><b>Som:</b> sons e volume.</li><li><b>Câmera:</b> visão e acompanhamento da cena.</li><li><b>Presets:</b> recursos prontos e configuráveis sem montar tudo do zero.</li><li><b>Multiplayer:</b> conexão, salas e dados online.</li><li><b>Aparências:</b> imagens, animações e efeitos visuais.</li><li><b>IA:</b> chamadas de IA e NPCs/Bots com ID próprio.</li><li><b>Shaders:</b> efeitos visuais configuráveis para objetos e cena.</li></ul></section>
      <section><h3 class="text-[14px] font-medium text-white mb-1">Blocos menos óbvios</h3><p><b>Quando...</b> é um gatilho. <b>Definir...</b> substitui um valor. <b>Mudar...</b> altera o valor atual. <b>Se...</b> decide se um trecho deve rodar. <b>Esperar...</b> pausa somente aquele script.</p></section>
      <section><h3 class="text-[14px] font-medium text-white mb-1">NPCs com IA</h3><p>Cada NPC recebe um <b>ID</b>. Use o mesmo ID nos blocos para configurar comportamento, alvo, visão, memória, personalidade e decisões desse NPC.</p></section>
      <section><h3 class="text-[14px] font-medium text-white mb-1">Shaders</h3><p>Comece com efeitos prontos como blur, contorno, onda, pixelização e cor. Depois ajuste intensidade, tempo, resolução e uniforms.</p></section>
      <section class="pt-1"><h3 class="text-[14px] font-medium text-white mb-1">Criar plugins</h3><p>Crie categorias e Bricks no Editor de Kix Plugins. A pré-visualização mostra o resultado antes de salvar.</p><div class="mt-2 grid grid-cols-1 gap-2"><button type="button" id="btn-download-plugin-doc" class="w-full rounded-lg bg-[#059669] px-4 py-3 text-white">Baixar guia completo de plugins (.md)</button><button type="button" id="btn-download-plugin-schema" class="w-full rounded-lg bg-[#2A2B2E] px-4 py-3 text-[#EDEDF0]">Baixar schema para IAs (.json)</button></div></section>
    </div>`;
    $('btn-download-plugin-doc')?.addEventListener('click', downloadKixPluginMiniDoc); $('btn-download-plugin-schema')?.addEventListener('click', downloadKixPluginSchemaDoc);
  show('tutorial');
}


function renderProjects() {
  const list = $('projects-list');
  const recentCard = $('btn-home-play');
  if (recentCard) {
    const recent = Array.isArray(projects) && projects.length ? projects[0] : null;
    const iconHtml = recent && recent.icon
      ? `<div class="absolute inset-0 flex items-center justify-center"><img src="${String(recent.icon).replace(/"/g,'&quot;')}" class="w-48 h-48 rounded-3xl object-cover opacity-85 shadow-xl" alt=""></div>`
      : `<div class="absolute inset-0 flex items-center justify-center"><div class="w-48 h-48 rounded-3xl bg-[#3A3A3A] border border-white/5 flex items-center justify-center opacity-55">
          <svg width="28" height="28" fill="none" stroke="#888" stroke-width="1.5"><rect x="5" y="5" width="18" height="18" rx="3"/><path d="M9 18l4-4 3 3 2-2 3 3"/></svg>
        </div></div>`;
      recentCard.innerHTML = `
      <div class="absolute inset-0 overflow-hidden">
        ${iconHtml}
        <div class="absolute inset-0 bg-gradient-to-b from-transparent via-black/5 to-[#111]/28"></div>
      </div>
      ${recent ? `<button type="button" id="home-play-btn" class="recent-play-action absolute left-1/2 top-1/2 z-20 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#059669] text-white flex items-center justify-center" aria-label="Editar projeto recente">
        <span class="recent-play-icon flex items-center justify-center">
          <svg width="34" height="34" fill="none" stroke="currentColor" stroke-width="1.9" viewBox="0 0 24 24"><path d="M4 20h4l10.5-10.5a2.12 2.12 0 0 0-3-3L5 17v3Z"/><path d="m14.5 7.5 2 2"/></svg>
        </span>
      </button>` : ''}`;
  }
  if (!list) return;
  list.querySelectorAll('.project-card').forEach(e => e.remove());
  const empty = $('projects-empty');
  if (!projects.length) { if (empty) empty.style.display = ''; return; }
  if (empty) empty.style.display = 'none';
  projects.forEach((p, i) => {
    const el = document.createElement('div');
    el.className = 'project-card flex items-center gap-3 py-2.5 px-1';
    el.innerHTML = `<div class="w-10 h-10 rounded bg-[#3A3A3A] overflow-hidden flex items-center justify-center project-thumb">
      ${p.icon ? `<img src="${p.icon}" class="w-full h-full object-cover">` : `<svg width="16" height="16" fill="none" stroke="#888" stroke-width="1.5"><rect x="3" y="3" width="14" height="14" rx="1"/></svg>`}
    </div>
    <div class="flex-1 min-w-0"><div class="text-[14px] font-medium truncate">${p.name}</div>
    <div class="text-[11px] text-[#888]">${p.updated || 'Agora'}</div></div>
    <button type="button" class="project-menu w-9 h-9 flex items-center justify-center text-[#888]" aria-label="Opções do projeto">
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="5" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="12" cy="19" r="1.2"/></svg>
    </button>`;
    el.onclick = () => openProject(i);
    el.querySelector('.project-menu').onclick = (e) => {
      e.stopPropagation();
      // Home project ⋮ must open Project Settings directly. Opening the project
      // editor first would expose the Scene Selection screen as an unintended
      // intermediate destination. Initialization remains centralized in
      // openProject(); only the final destination is changed here.
      openProject(i, { origin: 'home', targetScreen: 'project-options' });
    };
    list.appendChild(el);
  });
}
function createKixTestGame() {
  const svg = (fill, label) => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96"><rect x="2" y="2" width="92" height="92" rx="18" fill="${fill}"/><text x="48" y="57" text-anchor="middle" font-family="Arial" font-size="18" fill="white">${label}</text></svg>`);
  const player = svg('#059669','KIX');
  const target = svg('#6B9C49','GO');
  const scripts = [
    {id:'t1',name:'Quando a cena começar',values:{}},
    {id:'t2',name:'Definir tamanho para',params:['valor'],values:{valor:70}},
    {id:'t3',name:'Mostrar',values:{}},
    {id:'t4',name:'Definir variável para',params:['variável','valor'],values:{'variável':'pontos',valor:0}},
    {id:'t5',name:'Tocar animação',params:['pasta','modo','fps'],values:{pasta:'Run',modo:'loop',fps:8}},
    {id:'t5b',name:'Mudar tamanho em',params:['valor'],values:{valor:1}},
    {id:'t5c',name:'Definir pasta como aparência atual',params:['pasta'],values:{pasta:'Run'}},
    {id:'t5d',name:'Tocar pasta uma vez na velocidade',params:['pasta','fps'],values:{pasta:'Run',fps:10}},
    {id:'t5e',name:'Esperar animação terminar',values:{}},
    {id:'t5f',name:'Definir variável para',params:['variável','valor'],values:{'variável':'animacao_ok',valor:1}},
    {id:'t6',name:'Sempre',values:{}},
    {id:'t7',name:'Mover X passos',params:['passos'],values:{passos:1}},
    {id:'t8',name:'Se estiver na borda, volte',values:{}},
    {id:'t9',name:'Mostrar',values:{}},
    {id:'t10',name:'Definir opacidade para',params:['valor'],values:{valor:90}},
    {id:'t11',name:'Definir direção para',params:['graus'],values:{graus:90}},
    {id:'t12',name:'Tocar pasta uma vez na velocidade',params:['pasta','fps'],values:{pasta:'Run',fps:10}}
  ];
  const tapScripts = [
    {id:'p1',name:'Quando tocado',values:{}},
    {id:'p2',name:'Mudar variável em',params:['variável','valor'],values:{'variável':'pontos',valor:1}},
    {id:'p3',name:'Mudar tamanho em',params:['valor'],values:{valor:10}},
    {id:'p4',name:'Piscar X vezes',params:['vezes'],values:{vezes:2}}
  ];
  const project={name:'Kix Test Lab',updated:'Agora',description:'Projeto oficial para testar blocos, aparências, animações, dados, câmera e segurança.',credits:'Kix',scenes:[{name:'Teste completo',actors:[
    {name:'Player',image:player,looks:[player,target],folders:[{name:'Run',looks:[player,target,player]}],sounds:[],x:-120,y:0,direction:90,size:70,visible:true,scripts:scripts,collisionShape:{type:'rect',width:64,height:64,offsetX:0,offsetY:0,enabled:true,debug:true}},
    {name:'Alvo',image:target,looks:[target],folders:[],sounds:[],x:120,y:0,direction:90,size:70,visible:true,scripts:tapScripts,collisionShape:{type:'circle',radius:32,enabled:true,debug:true}}
  ]}],files:[],icon:null,orientation:'portrait',vars:{pontos:0}};
  projects.unshift(project); save(); renderProjects(); openProject(0); setTimeout(() => { try { const acts=getSceneActors(); const pi=acts.findIndex(a=>a && a.name==='Player'); if(pi>=0) openActor(pi); } catch(e){ console.warn('test lab open player',e); } }, 0); toast('Kix Test Lab criado');
}

var _createOrientation = 'portrait';
function openCreateProjectScreen(testMode=false) {
  const name = $('create-name'), version = $('create-version');
  if (name) name.value = testMode ? 'Kix Test Lab' : '';
  if (version) version.value = KIX_APP_VERSION;
  _createOrientation = 'portrait';
  document.querySelectorAll('.create-orientation').forEach(b => b.classList.toggle('text-[#10B981]', b.dataset.orientation === _createOrientation));
  document.querySelectorAll('.create-orientation').forEach(b => b.classList.toggle('text-[#D8D8DD]', b.dataset.orientation !== _createOrientation));
  show('create-project');
  setTimeout(() => name?.focus(), 50);
}
function createFromForm() {
  const name = String($('create-name')?.value || '').trim() || ('Projeto ' + (projects.length + 1));
  const version = String($('create-version')?.value || KIX_APP_VERSION).trim() || KIX_APP_VERSION;
  createProject(name, {version, orientation:_createOrientation, quickShare:!!$('create-share')?.checked});
}

function createProject(name, meta) {
  const newProject = {
    kixId: kixStableId('project'),
    name: name || ('Projeto ' + (projects.length + 1)),
    updated: 'Agora', description: '', credits: '',
    scenes: [{ name: 'Cena 1', actors: [], tilemaps: [], particleEmitters: [] }],
    files: [],
    icon: null, orientation: (meta && meta.orientation) || 'portrait',
    stage: {width: ((meta && meta.orientation) === 'landscape') ? 800 : 480, height: ((meta && meta.orientation) === 'landscape') ? 480 : 800, mode:'FIT'},
    version: (meta && meta.version) || KIX_APP_VERSION, quickShare: !!(meta && meta.quickShare), vars: {}, dataDefinitions: []
  };
  projects.unshift(newProject);
  save(); renderProjects(); openProject(0);
  toast('Projeto criado');
}
function openProject(idx, opts = {}) {
  try {
    if (!Array.isArray(projects) || idx < 0 || idx >= projects.length) {
      toast('Projeto inválido');
      return;
    }
    currentProject = projects[idx];
    ensureProjectIdentity(currentProject);
    ensureProjectDataDefinitions(currentProject);
    try { if (ensureKixCatroidProjectCompatibility(currentProject)) save(); } catch (_) {}
    // IMPORTANT: project orientation belongs to the stage presentation, not the
    // editor Activity. Opening/editing a project must never rotate the Android UI.
    document.documentElement.dataset.kixProjectOrientation = String(currentProject.orientation || currentProject.catrobatStage?.orientation || 'portrait').toLowerCase();
    projectEntryOrigin = opts && opts.origin ? String(opts.origin) : (lastScreen === 'home' ? 'home' : 'project');
    currentScene = 0;
    currentActor = null;
    currentActorIdx = -1;
    if (!currentProject.scenes || !currentProject.scenes.length) {
      currentProject.scenes = [{ name: 'Cena 1', actors: [] }];
    }
    currentProject.scenes.forEach(sc => {
      if (!sc) return;
      if (!Array.isArray(sc.actors)) sc.actors = [];
      sc.actors.forEach(a => {
        if (!a) return;
        ensureActorIdentity(a);
        try {
          if (a.scripts && a.scripts.blocks && window.KixEngine) {
            a.scripts = KixEngine.scriptsToFlat(a.scripts);
          }
          if (!Array.isArray(a.scripts)) a.scripts = [];
          a.scripts.forEach(s => {
            if (!s.values) s.values = {};
          });
          if (!Array.isArray(a.looks)) a.looks = [];
          if (!Array.isArray(a.sounds)) a.sounds = [];
          if (!Array.isArray(a.folders)) a.folders = [];
          if (a.x === undefined) a.x = 0;
          if (a.y === undefined) a.y = 0;
          if (a.direction === undefined) a.direction = 90;
          if (a.size === undefined) a.size = 100;
        } catch (e) { console.warn('normalize actor', e); }
      });
    });
    if ($('project-title')) $('project-title').textContent = currentProject.name || 'Projeto';
    try { ensureBackgroundActor(); } catch (_) {}
    // Clean orphaned image history from old projects as soon as they are opened.
    try { if (pruneProjectImageHistory()) save(); } catch (_) {}
    renderScenes();
    renderActors();
    clearNavStack();
    const targetScreen = opts && opts.targetScreen === 'project-options' ? 'project-options' : 'project';
    if (targetScreen === 'project-options') {
      // Home → ⋮ is a settings intent, not a scene-selection intent. Keep the
      // current project initialized, populate its settings, then land directly
      // on the project options screen. Back is handled by projectEntryOrigin.
      renderProjectOptionsScreen();
      show('project-options');
    } else {
      lastScreen = 'project';
      show('project');
    }
  } catch (e) {
    console.error('openProject', e);
    toast('Erro ao abrir projeto');
  }
}
function renderScenes() {
  try {
    const list = $('scenes-list');
    if (!list) return;
    list.innerHTML = '';
    if (!currentProject || !Array.isArray(currentProject.scenes)) return;
    const empty = $('scenes-empty');
    if (!currentProject.scenes.length) {
      if (empty) empty.style.display = '';
      return;
    }
    if (empty) empty.style.display = 'none';
    currentProject.scenes.forEach((sc, i) => {
      try {
        const el = document.createElement('div');
        el.className = 'scene-item flex items-center gap-3 p-2 rounded bg-[#2C2C2C] mb-2';
        // thumbnail from Fundo or first actor with image
        let thumbSrc = null;
        const acts = (sc && sc.actors) || [];
        const bg = acts.find(a => a && (a.isBackground || a.name === 'Fundo'));
        if (!thumbSrc && bg) thumbSrc = bg.thumbnailImage || bg.backgroundFirstImage || bg.image || (bg.looks && bg.looks[0]) || null;
        if (!thumbSrc) {
          for (let ai = 0; ai < acts.length; ai++) {
            const a = acts[ai];
            if (!a || a === bg) continue;
            if (a.image) { thumbSrc = a.image; break; }
            if (a.looks && a.looks.length && a.looks[0]) { thumbSrc = a.looks[0]; break; }
          }
        }
        const thumbInner = thumbSrc
          ? `<img src="${String(thumbSrc).replace(/"/g, '')}" style="width:100%;height:100%;object-fit:cover;" alt="">`
          : `<svg width="22" height="22" fill="none" stroke="#888" stroke-width="1.5" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="14" rx="2"/><path d="M3 14l4-4 3 3 4-5 5 6"/></svg>`;
        el.innerHTML = `
          <div class="scene-thumb" style="width:48px;height:48px;border-radius:10px;background:#333;flex-shrink:0;overflow:hidden;display:flex;align-items:center;justify-content:center;">${thumbInner}</div>
          <div class="flex-1 min-w-0">
            <div class="text-[14px] font-medium truncate scene-name"></div>
            <div class="text-[11px] text-[#666]">${acts.length} objeto(s)</div>
          </div>
          <button type="button" class="scene-menu text-[#888] px-2 text-lg">${kixSvgIcon('more',18)}</button>`;
        el.querySelector('.scene-name').textContent = (sc && sc.name) || ('Cena ' + (i + 1));
        el.onclick = (e) => {
          if (e.target.closest('.scene-menu')) return;
          try { openScene(i); } catch (err) { console.error(err); toast('Erro na cena'); }
        };
        const menuBtn = el.querySelector('.scene-menu');
        if (menuBtn) menuBtn.onclick = (e) => {
          e.stopPropagation();
          try { openSceneMenu(i); } catch (err) { console.error(err); }
        };
        list.appendChild(el);
      } catch (err) { console.warn('scene row', err); }
    });
  } catch (e) {
    console.error('renderScenes', e);
  }
}
function addScene() {
  try {
    if (addScene._lock) return;
    addScene._lock = true;
    setTimeout(() => { addScene._lock = false; }, 500);
    if (!currentProject) { toast('Nenhum projeto'); return; }
    if (!Array.isArray(currentProject.files)) currentProject.files = [];
    if (!Array.isArray(currentProject.scenes)) currentProject.scenes = [];
    currentProject.scenes.push({
      name: 'Cena ' + (currentProject.scenes.length + 1),
      actors: []
    });
    currentScene = currentProject.scenes.length - 1;
    save();
    renderScenes();
    toast('Cena criada');
  } catch (e) {
    console.error('addScene', e);
    addScene._lock = false;
  }
}
function openScene(idx) {
  try {
    if (!currentProject) { toast('Nenhum projeto'); return; }
    if (!Array.isArray(currentProject.files)) currentProject.files = [];
    if (!Array.isArray(currentProject.scenes)) currentProject.scenes = [{ name: 'Cena 1', actors: [] }];
    idx = Number(idx);
    if (isNaN(idx) || idx < 0 || idx >= currentProject.scenes.length) {
      toast('Cena não encontrada');
      return;
    }
    currentScene = idx;
    currentActor = null;
    currentActorIdx = -1;
    const sc = currentProject.scenes[idx];
    if (!sc.actors) sc.actors = [];
    if ($('scene-title')) $('scene-title').textContent = sc.name || ('Cena ' + (idx + 1));
    try { ensureBackgroundActor(); } catch (e) { console.warn(e); }
    // Show scene screen FIRST so actors-list exists in visible tree
    show('scene');
    renderActors();
  } catch (e) {
    console.error('openScene', e);
    toast('Erro na cena: ' + (e.message || e));
    try { show('scene'); } catch (_) {}
  }
}

function leaveProjectEditor() {
  try { save(); syncActorToProject(); } catch (_) {}
  // This button belongs to the OBJECT editor. Its parent is always the current
  // scene, even when the project itself was originally opened from Home.
  // Returning to Home is reserved for the project's own back control.
  const returnScene = Number.isFinite(Number(currentScene)) ? Number(currentScene) : 0;
  currentActor = null; currentActorIdx = -1;
  if (currentProject) {
    currentScene = Math.max(0, returnScene);
    try {
      const scene = currentProject.scenes && currentProject.scenes[currentScene];
      if (scene && $('scene-title')) $('scene-title').textContent = scene.name || ('Cena ' + (currentScene + 1));
    } catch (_) {}
    navJumpTo('scene');
    try { renderActors(); } catch (_) {}
    return;
  }
  renderProjects();
  clearNavStack();
  show('home', { noPush: true });
}
function renderProjectOptionsScreen() {
  if (!currentProject) return;
  const name = $('project-options-name');
  const desc = $('project-options-description');
  const version = $('project-options-version');
  const label = $('project-options-name-label');
  const icon = $('project-options-icon');
  if (name) name.value = currentProject.name || 'Projeto';
  if (desc) desc.value = currentProject.description || '';
  if (version) version.value = currentProject.version || KIX_APP_VERSION;
  if (label) label.textContent = currentProject.name || 'Projeto';
  if (icon) icon.innerHTML = currentProject.icon
    ? `<img src="${String(currentProject.icon).replace(/"/g,'')}" class="w-full h-full object-cover" alt="">`
    : '<span class="text-[#888] text-xs">Ícone</span>';
}
function openProjectOptionsScreen() {
  if (!currentProject) { toast('Nenhum projeto aberto'); return; }
  closeSheets();
  renderProjectOptionsScreen();
  show('project-options');
}
function deleteCurrentProject() {
  if (!currentProject) return;
  askConfirm('Excluir projeto', 'Excluir este projeto? Esta ação não pode ser desfeita.', () => {
    projects = projects.filter(p => p !== currentProject);
    currentProject = null; currentActor = null; currentActorIdx = -1; currentScene = 0;
    save(); renderProjects(); show('home'); toast('Projeto excluído');
  });
}

function openSceneMenu(idx) {
  const s = currentProject.scenes[idx];
  askChoice('Cena: ' + s.name, 'Escolha uma ação para esta cena.', [
    {label:'Renomear', action:()=>askText('Renomear cena','Novo nome da cena:',s.name,n=>{ if(n){s.name=n;save();renderScenes();} })},
    {label:'Duplicar', action:()=>{ currentProject.scenes.splice(idx+1,0,JSON.parse(JSON.stringify(s))); currentProject.scenes[idx+1].name+=' (cópia)'; save(); renderScenes(); toast('Cena duplicada'); }},
    {label:'Excluir', action:()=>{ if(currentProject.scenes.length<=1){toast('A cena principal não pode ser excluída');return;} currentProject.scenes.splice(idx,1); if(currentScene>=currentProject.scenes.length) currentScene=currentProject.scenes.length-1; save();renderScenes();renderActors();toast('Cena excluída'); }}
  ]);
}

// ===== Lightweight thumbnails =====
// Lists used to embed the full-size base64 image in every row. On a phone that
// forces a full decode per row on each render. Rows now receive a small cached
// bitmap generated off the tap path.
const _kixThumbCache = new Map();
const _kixThumbQueue = [];
let _kixThumbBusy = false;
const KIX_BLANK_PX = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';
function kixThumbKey(src, size) { return size + ':' + src.length + ':' + src.slice(24, 72) + ':' + src.slice(-40); }
function kixApplyThumb(img, src, size) {
  if (!img) return;
  size = size || 96;
  src = String(src == null ? '' : src);
  if (!src) return;
  if (src.length < 24000 || !/^data:image\/(png|jpe?g|webp|gif)/i.test(src)) { img.src = src; return; }
  const key = kixThumbKey(src, size);
  const hit = _kixThumbCache.get(key);
  if (hit) { img.src = hit; return; }
  img.src = KIX_BLANK_PX;
  img.dataset.kixThumbKey = key;
  img.decoding = 'async';
  if (!_kixThumbQueue.some(q => q.key === key)) _kixThumbQueue.push({ key, src, size });
  kixPumpThumbs();
}
function kixPumpThumbs() {
  if (_kixThumbBusy || !_kixThumbQueue.length) return;
  _kixThumbBusy = true;
  const job = _kixThumbQueue.shift();
  const done = (out) => {
    if (out) {
      _kixThumbCache.set(job.key, out);
      if (_kixThumbCache.size > 400) _kixThumbCache.delete(_kixThumbCache.keys().next().value);
      document.querySelectorAll('img[data-kix-thumb-key]').forEach(im => { if (im.dataset.kixThumbKey === job.key) im.src = out; });
    } else {
      document.querySelectorAll('img[data-kix-thumb-key]').forEach(im => { if (im.dataset.kixThumbKey === job.key) im.src = job.src; });
    }
    _kixThumbBusy = false;
    setTimeout(kixPumpThumbs, 0);
  };
  const im = new Image();
  im.decoding = 'async';
  im.onload = () => {
    try {
      const k = Math.min(1, job.size / Math.max(im.naturalWidth || 1, im.naturalHeight || 1));
      if (k >= 1) { done(job.src); return; }
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(im.naturalWidth * k));
      c.height = Math.max(1, Math.round(im.naturalHeight * k));
      const g = c.getContext('2d');
      g.imageSmoothingEnabled = true; g.imageSmoothingQuality = 'medium';
      g.drawImage(im, 0, 0, c.width, c.height);
      done(c.toDataURL('image/png'));
    } catch (_) { done(null); }
  };
  im.onerror = () => done(null);
  im.src = job.src;
}

function renderActors() {
  try {
    const fundo = getSceneActors().find(a => a && (a.isBackground || a.name === 'Fundo'));
    const fundoHost = $('actor-fundo');
    if (fundoHost) {
      const thumb = fundoHost.querySelector('.actor-thumb');
      const src = fundo && (fundo.thumbnailImage || fundo.backgroundFirstImage || (fundo.looks && fundo.looks[0]) || fundo.image);
      if (thumb) {
        thumb.innerHTML = src ? '<img class="w-full h-full object-cover" alt="" draggable="false">' : '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#888" stroke-width="1.5"><rect x="3" y="3" width="14" height="14" rx="1"/></svg>';
        if (src) kixApplyThumb(thumb.querySelector('img'), typeof src === 'string' ? src : (src.src || src.dataUrl || ''), 96);
      }
    }
    const listEl = $('actors-list');
    if (!listEl) return;
    listEl.innerHTML = '';
    const actors = getSceneActors();
    const empty = $('actors-empty');
    if (!actors.length) {
      if (empty) empty.style.display = '';
      return;
    }
    if (empty) empty.style.display = 'none';
    try { if (listEl._actorSortable && typeof listEl._actorSortable.destroy === 'function') listEl._actorSortable.destroy(); } catch (_) {}
    listEl._actorSortable = null;
    actors.forEach((a, i) => {
      try {
        if (!a) return;
        if (a.isBackground || a.name === 'Fundo') return;
        if (!a.kixId) a.kixId = 'actor_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,8) + '_' + i;
        const el = document.createElement('div');
        el.className = 'actor-item flex items-center gap-3 p-1.5';
        el.dataset.actorId = String(a.kixId);
        const thumb = a.image
          ? `<img class="w-full h-full object-cover" alt="" draggable="false">`
          : `<svg width="14" height="14" fill="none" stroke="#888" stroke-width="1.5"><rect x="3" y="3" width="14" height="14" rx="1"/></svg>`;
        el.innerHTML = `<div class="w-11 h-11 rounded bg-[#3A3A3A] overflow-hidden flex items-center justify-center actor-thumb">${thumb}</div>
          <span class="text-[15px] flex-1"></span>
          <button type="button" class="actor-menu w-8 h-8 flex items-center justify-center text-[#888]">${kixSvgIcon('more',18)}</button>`;
        el.querySelector('span').textContent = a.name || 'Objeto';
        if (a.image) kixApplyThumb(el.querySelector('.actor-thumb img'), a.image, 96);
        el.querySelector('.actor-menu').onclick = (e) => {
          e.stopPropagation();
          try {
            const live = getSceneActors().findIndex(x => x && String(x.kixId||'') === String(el.dataset.actorId||''));
            if (live >= 0) openActorMenu(live);
          } catch (err) { console.warn(err); }
        };
        el.onclick = (e) => {
          if (e.target.closest('.actor-menu')) return;
          try {
            const live = getSceneActors().findIndex(x => x && String(x.kixId||'') === String(el.dataset.actorId||''));
            if (live >= 0) openActor(live);
          } catch (err) {
            console.error(err);
            toast('Erro ao abrir objeto');
          }
        };
        listEl.appendChild(el);
      } catch (err) { console.warn('actor row', err); }
    });
    try {
      if (window.Sortable && listEl.children.length) {
        listEl._actorSortable = Sortable.create(listEl, {
          draggable: '.actor-item',
          filter: '.actor-menu,button,input,select,textarea,[contenteditable="true"]',
          // Actors are reordered with the same BrickDragController. A shorter
          // touch activation window makes long-press drag practical on Android
          // without introducing a second gesture engine.
          delay: 320,
          delayOnTouchOnly: true,
          forceFallback: true,
          fallbackTolerance: 8,
          touchStartThreshold: 8,
          // Finger moves before the hold window => the list scrolls (it used to
          // be impossible to scroll when touching an object row).
          manualScrollBeforeHold: true,
          animation: 120,
          onEnd: function(evt) {
            try {
              const scene = currentProject && currentProject.scenes ? currentProject.scenes[currentScene] : null;
              if (!scene || !Array.isArray(scene.actors)) return;
              const beforeCurrentId = currentActor && currentActor.kixId ? String(currentActor.kixId) : '';
              const rows = Array.from(listEl.querySelectorAll('.actor-item'));
              const orderedIds = rows.map(r => String(r.dataset.actorId||'')).filter(Boolean);
              const fundo = scene.actors.find(a => a && (a.isBackground || a.name === 'Fundo')) || null;
              const byId = new Map(scene.actors.filter(Boolean).map(a => [String(a.kixId||''), a]));
              const ordered = orderedIds.map(id => byId.get(id)).filter(Boolean);
              const remainder = scene.actors.filter(a => a && !(a.isBackground || a.name === 'Fundo') && !ordered.includes(a));
              scene.actors = (fundo ? [fundo] : []).concat(ordered, remainder);
              scene.actors.forEach((a,i)=>ensureActorIdentity(a));
              currentActorIdx = beforeCurrentId ? scene.actors.findIndex(a => String(a && a.kixId||'') === beforeCurrentId) : currentActorIdx;
              if (currentActorIdx >= 0) currentActor = scene.actors[currentActorIdx];
              syncActorToProject(); save(); renderActors();
              toast('Ordem dos objetos atualizada');
            } catch (err) { console.error('actor reorder',err); toast('Não foi possível reorganizar os objetos'); renderActors(); }
          }
        });
      }
    } catch (err) { console.warn('actor sortable', err); }
  } catch (e) {
    console.error('renderActors', e);
  }
}
function openActorMenu(idx) {
  window._actorMenuIdx = idx;
  const actors = getSceneActors();
  const a = actors[idx];
  if (!a) return;
  const t = $('actor-opt-title');
  if (t) t.textContent = a.name || 'Objeto';
  openSheet('sheet-actor-options');
}
function addActor(name, image, opts) {
  try {
    if (!currentProject) { toast('Abra um projeto'); return; }
    const scene = currentProject.scenes[currentScene];
    if (!scene) return;
    if (!scene.actors) scene.actors = [];
    opts = opts || {};
    const actor = {
      name: name || ('Objeto ' + (scene.actors.length + 1)),
      image: image || null,
      scripts: [],
      looks: image ? [image] : [],
      sounds: [],
      folders: [],
      x: 0, y: 0, direction: 90, size: 100, pixelArt: false, visible: opts.visible !== undefined ? opts.visible : true, costume: 0,
      isLayer: !!opts.isLayer,
      isCamera: !!opts.isCamera,
      children: opts.children || [],
      collisionShape: opts.collisionShape || { type: 'rect' }
    };
    scene.actors.push(actor);
    const createdIdx = scene.actors.length - 1;
    save();
    renderActors();
    // If an object was created from a resource parameter's "novo..." action,
    // immediately write the new object's stable name into the original block.
    const pendingObject = window._kixPendingSelector;
    if (pendingObject?.kind === 'object' && pendingObject?.actor && pendingObject?.project === currentProject) {
      const pendingScripts = Array.isArray(pendingObject.actor.scripts) ? pendingObject.actor.scripts : [];
      const pendingBlock = pendingScripts.find(b => b && String(b.id || '') === String(pendingObject.block?.id || '')) || pendingObject.block;
      if (pendingBlock) {
        if (!pendingBlock.values) pendingBlock.values = {};
        const oldValue = String(pendingBlock.values[pendingObject.paramName] == null ? '' : pendingBlock.values[pendingObject.paramName]).trim();
        const cleanName = String(actor.name || '').trim();
        pendingBlock.values[pendingObject.paramName] = /^['"][\s\S]*['"]$/.test(oldValue) ? "'" + cleanName.replace(/'/g, "\\'") + "'" : cleanName;
        try { syncActorToProject(); save(); } catch (_) {}
      }
      window._kixPendingSelector = null;
    }
    toast('Objeto adicionado');
    // Open it immediately so user can script
    openActor(createdIdx);
  } catch (e) {
    console.error('addActor', e);
    toast('Erro ao criar objeto');
  }
}
function ensureBackgroundActor() {
  try {
    if (!currentProject) return;
    if (!currentProject.scenes || !currentProject.scenes.length) {
      currentProject.scenes = [{ name: 'Cena 1', actors: [] }];
    }
    if (currentScene < 0 || currentScene >= currentProject.scenes.length) currentScene = 0;
    const scene = currentProject.scenes[currentScene];
    if (!Array.isArray(scene.actors)) scene.actors = [];
    // Collect all background-like actors
    const fundos = [];
    const others = [];
    scene.actors.forEach(a => {
      if (!a) return;
      if (a.isBackground || a.name === 'Fundo') {
        a.isBackground = true;
        a.name = 'Fundo';
        fundos.push(a);
      } else {
        others.push(a);
      }
    });
    let fundo = fundos[0];
    if (!fundo) {
      fundo = {
        name: 'Fundo', image: null, thumbnailImage: null, backgroundFirstImage: null, scripts: [], looks: [], sounds: [], folders: [],
        x: 0, y: 0, direction: 90, size: 100, pixelArt: false, visible: true, costume: 0, isBackground: true
      };
    }
    // Exactly one Fundo at index 0
    const firstLook = Array.isArray(fundo.looks) && fundo.looks.length ? (typeof fundo.looks[0] === 'string' ? fundo.looks[0] : (fundo.looks[0]?.src || fundo.looks[0]?.dataUrl || fundo.looks[0]?.image)) : null;
    fundo.thumbnailImage = fundo.thumbnailImage || fundo.backgroundFirstImage || firstLook || fundo.image || null;
    fundo.backgroundFirstImage = fundo.thumbnailImage || null;
    scene.actors = [fundo].concat(others);
  } catch (e) { console.warn('ensureBackgroundActor', e); }
}

function openActor(idx) {
  try {
    const actors = getSceneActors();
    if (idx < 0 || idx >= actors.length) { toast('Objeto inválido'); return; }
    currentActorIdx = idx;
    currentActor = actors[idx];
    ensureActorIdentity(currentActor);
    ensureProjectIdentity(currentProject);
    if (currentActor.scripts && currentActor.scripts.blocks && window.KixEngine) {
      currentActor.scripts = KixEngine.scriptsToFlat(currentActor.scripts);
    }
    if (!Array.isArray(currentActor.scripts)) currentActor.scripts = [];
    // normalize each block values
    currentActor.scripts.forEach(s => {
      if (!s.values) s.values = {};
      (s.params || []).forEach(p => {
        const pn = typeof p === 'object' ? p.name : p;
        const def = normalizeParam(p, s.name);
        if (s.values[pn] === undefined || s.values[pn] === null || s.values[pn] === '') {
          s.values[pn] = def.default;
        } else if (def.type === 'bool' && /^(?:1|true|sim|nao|não)$/i.test(String(s.values[pn]).replace(/['"]/g, ''))) {
          const clean = String(s.values[pn]).replace(/['"]/g, '').toLowerCase();
          if (clean === '1' || clean === 'true') s.values[pn] = def.default;
        } else if (def.type === 'color' && !/^['"]?#(?:[0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})['"]?$/i.test(String(s.values[pn]).trim())) {
          // A legacy untyped color could have inherited the numeric default "1".
          if (String(s.values[pn]).trim() === '1') s.values[pn] = def.default;
        }
      });
    });
    if (!currentActor.looks) currentActor.looks = [];
    if (!currentActor.sounds) currentActor.sounds = [];
    if (!currentActor.folders) currentActor.folders = [];
    if (currentActor.x === undefined) currentActor.x = 0;
    if (currentActor.y === undefined) currentActor.y = 0;
    if (currentActor.pixelArt === undefined) currentActor.pixelArt = false;
    if (currentActor.direction === undefined) currentActor.direction = 90;
    if (currentActor.size === undefined) currentActor.size = 100;
    if ($('script-title')) $('script-title').textContent = currentActor.name || 'Objeto';
    renderScripts(); renderLooks(); renderSounds();
    switchTab('scripts', {record:false});
    previousTab = 'scripts';
    tabNavStack = [];
    show('scripts');
    // nav already pushed by show
  } catch (e) {
    console.error('openActor', e);
    toast('Erro ao abrir objeto');
  }
}

// ===== SCRIPTS =====

/** Infer resource selector types for Catrobat/Pocket Code-like parameters. */
function inferKixParamType(blockName, paramName, explicitType) {
  const b = String(blockName || '').trim().toLowerCase();
  const n = String(paramName || '').trim().toLowerCase();
  const resourceTypes = new Set(['sound','object','actor','image','look','appearance','folder','scene']);
  if (resourceTypes.has(String(explicitType || '').toLowerCase())) return explicitType;
  if (/^(som|áudio|audio)$/.test(n) && /(som|áudio|audio|tocar|volume|parar)/i.test(b)) return 'sound';
  if (/^(objeto|ator|alvo)$/.test(n) && /(colid|apontar|distância|distancia|objeto|ator)/i.test(b)) return 'object';
  if (/^(aparência|aparencia|look|fantasia)$/.test(n) && /(aparên|aparenc|look|fantasia)/i.test(b)) return 'image';
  if (/^pasta$/.test(n) && /(pasta|anima|aparên|aparenc|look|fantasia)/i.test(b)) return 'folder';
  if (/^(cena|scene)$/.test(n) && /(cena|scene)/i.test(b)) return 'scene';
  return explicitType || 'number';
}

/** Normalize param def to { name, type, default, options }. blockName is optional for legacy string params. */
function normalizeParam(p, blockName) {
  if (p == null) return { name: 'valor', type: 'number', default: '1' };
  if (typeof p === 'object') {
    const name = p.name || p.n || 'valor';
    const type = inferKixParamType(blockName, name, p.type || 'number');
    const isPosition = /^(x|y|posição x|posição y)$/i.test(String(name).trim());
    let def = p.default != null ? p.default : null;
    if (def == null) {
      if (isPosition) def = '0';
      else if (type === 'text' || type === 'file' || type === 'folder' || type === 'image' || type === 'object' || type === 'actor' || type === 'sound' || type === 'scene') def = "''";
      else if (type === 'bool') def = "'não'";
      else if (type === 'color') def = "'#FFFFFF'";
      else if (type === 'choice' && Array.isArray(p.options) && p.options.length) def = "'" + String(p.options[0]).replace(/'/g, "\\'") + "'";
      else def = '1';
    }
    return { name, type, default: def, options: Array.isArray(p.options) ? p.options.slice() : null };
  }
  const name = String(p);
  const type = inferKixParamType(blockName, name, 'number');
  const isPosition = /^(x|y|posição x|posição y)$/i.test(name.trim());
  const defaultValue = ['sound','object','actor','image','folder','scene'].includes(type) ? "''" : (isPosition ? '0' : '1');
  return { name, type, default: defaultValue, options: null };
}

/**
 * Build HTML label for a block with param chips.
 * catalogMode: show param NAMES as placeholders (not [object Object])
 * values: optional map of current values (script editor)
 */
function truncateKixDisplayText(value, maxChars = 10) {
  const clean = String(value == null ? '' : value)
    .replace(/\\n/g, ' ')
    .replace(/\r?\n/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (clean.length <= maxChars) return clean;
  return clean.slice(0, maxChars) + '...';
}

function displayBlockParamValue(paramDef, value) {
  const raw = String(value == null ? '' : value);
  const type = paramDef?.type;
  if (type === 'bool') {
    const clean = raw.replace(/['"]/g, '').trim().toLowerCase();
    if (clean === 'sim' || clean === 'true' || clean === '1') return 'Sim';
    if (clean === 'nao' || clean === 'não' || clean === 'false' || clean === '0') return 'Não';
    return raw;
  }
  if (type === 'color' || type === 'choice' || type === 'image' || type === 'object' || type === 'actor') return raw.replace(/^['"]|['"]$/g, '').trim();
  if (type !== 'text' && type !== 'string' && type !== 'code' && type !== 'url') return raw.replace(/[\r\n]+/g, ' ').trim();
  const clean = raw.replace(/\\n/g, ' ').replace(/\r?\n/g, ' ').replace(/\s+/g, ' ').trim();
  if (!clean) return '';
  // Text-like parameters keep their full value internally, but the block only
  // shows the first 10 characters so long IDs/messages cannot stretch the Brick.
  return truncateKixDisplayText(clean, 10);
}

function isKixVariableSelectorBlock(blockName) {
  return /^(?:Definir variável|Definir variável local|Definir variável global) para$/i.test(String(blockName || '').trim());
}

function getKixAvailableVariableNames() {
  const names = [];
  const seen = new Set();
  const add = (value) => {
    const clean = String(value == null ? '' : value).trim();
    if (!clean) return;
    const key = clean.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    names.push(clean);
  };
  try {
    const defs = ensureProjectDataDefinitions(currentProject);
    defs.forEach(def => add(def?.name));
  } catch (_) {}
  try { Object.keys(currentProject?.vars || {}).forEach(add); } catch (_) {}
  try { Object.keys(currentActor?._vars || {}).forEach(add); } catch (_) {}
  try { Object.keys(currentActor?.vars || {}).forEach(add); } catch (_) {}
  return names;
}

function resolveKixVariableSelectorTarget(targetEl) {
  try {
    const blockEl = targetEl?.closest?.('.pc-block');
    if (!blockEl || !currentProject) return null;
    const actors = getSceneActors();
    const actorIdHint = String(blockEl.dataset?.actorId || '');
    const actorFromDom = actorIdHint
      ? actors.find(a => { try { return String(ensureActorIdentity(a)) === actorIdHint; } catch (_) { return false; } })
      : null;
    const actor = actorFromDom || (currentActor && actors.includes(currentActor) ? currentActor : null);
    if (!actor) return null;
    if (currentActor !== actor) {
      currentActor = actor;
      currentActorIdx = actors.indexOf(actor);
    }
    if (!Array.isArray(actor.scripts)) actor.scripts = [];
    const scriptIdx = Number(blockEl.dataset.scriptIdx);
    const blockId = String(blockEl.dataset.blockId || '');
    let block = blockId ? actor.scripts.find(b => String(b?.id || '') === blockId) || null : null;
    if (!block && Number.isFinite(scriptIdx) && scriptIdx >= 0) block = actor.scripts[scriptIdx] || null;
    if (!block) return null;
    return {
      el: targetEl,
      blockEl,
      block,
      blockId: String(block.id || blockId || ''),
      scriptIdx: Number.isFinite(scriptIdx) ? scriptIdx : -1,
      paramName: String(targetEl.dataset?.param || 'variável'),
      actor,
      actorId: String(ensureActorIdentity(actor)),
      project: currentProject,
      projectId: String(ensureProjectIdentity(currentProject))
    };
  } catch (_) { return null; }
}

function resolveKixVariableSelectorElement(target) {
  try {
    if (!target) return null;
    if (target.el && document.documentElement.contains(target.el)) return target.el;
    const blockEl = [...document.querySelectorAll('#script-blocks .pc-block')].find(el => {
      const actorId = String(el.dataset?.actorId || '');
      const blockId = String(el.dataset?.blockId || '');
      const scriptIdx = Number(el.dataset?.scriptIdx);
      return actorId === String(target.actorId || '') && (
        (target.blockId && blockId === String(target.blockId)) ||
        (!target.blockId && Number.isFinite(scriptIdx) && scriptIdx === Number(target.scriptIdx))
      );
    });
    return blockEl?.querySelector(`.kix-variable-selector[data-param="${String(target.paramName || 'variável').replace(/([\"\\])/g,'\\$1')}"]`) || null;
  } catch (_) { return null; }
}

function applyKixVariableSelectorValue(target, value) {
  const clean = String(value == null ? '' : value).trim();
  if (!target || !clean) return false;
  try {
    const actor = target.actor && Array.isArray(target.actor.scripts) ? target.actor : currentActor;
    if (!actor) return false;
    const scripts = Array.isArray(actor.scripts) ? actor.scripts : [];
    let block = target.blockId ? scripts.find(b => String(b?.id || '') === String(target.blockId)) : null;
    if (!block && target.scriptIdx >= 0) block = scripts[target.scriptIdx];
    if (!block) return false;
    block.values = block.values || {};
    const oldValue = block.values[target.paramName] == null ? '' : String(block.values[target.paramName]);
    if (oldValue === clean) return false;
    block.values[target.paramName] = clean;
    currentActor = actor;
    currentActorIdx = getSceneActors().indexOf(actor);
    syncActorToProject();
    save();
    renderScripts();
    return true;
  } catch (e) {
    console.warn('applyKixVariableSelectorValue', e);
    return false;
  }
}

function openKixVariableDropdown(targetEl) {
  const target = resolveKixVariableSelectorTarget(targetEl);
  if (!target) return false;
  try { window.KixInlineDropdownClose?.(); } catch (_) {}
  window._kixVariableSelectorTarget = target;
  window._kixSelectorTarget = target;

  const menu = document.createElement('div');
  menu.className = 'kix-inline-dropdown kix-variable-inline-dropdown';

  menu.setAttribute('role', 'listbox');
  menu.setAttribute('aria-label', 'Selecionar variável');
  const blockEl = target.blockEl;
  if (!blockEl) return false;

  const names = getKixAvailableVariableNames();
  const makeRow = (label, className, onClick) => {
    const row = document.createElement('button');
    row.type = 'button';
    row.className = 'kix-inline-row' + (className ? ' ' + className : '');
    row.textContent = label;
    row.addEventListener('click', e => {
      e.preventDefault(); e.stopPropagation();
      onClick?.();
    });
    return row;
  };

  menu.appendChild(makeRow('novo', 'kix-inline-new', () => {
    window._kixPendingVariableSelector = target;
    try { window.KixInlineDropdownClose?.(); } catch (_) {}
    openDataEditor(null);
  }));
  menu.appendChild(makeRow('editar fórmula...', 'kix-inline-formula', () => {
    const el = resolveKixVariableSelectorElement(target);
    try { window.KixInlineDropdownClose?.(); } catch (_) {}
    if (el) requestAnimationFrame(() => openFormula(el));
  }));

  names.forEach(name => {
    const selected = String(target.block?.values?.[target.paramName] || '').trim().toLowerCase() === name.toLowerCase();
    menu.appendChild(makeRow(name, selected ? 'is-selected' : '', () => {
      applyKixVariableSelectorValue(target, name);
      try { window.KixInlineDropdownClose?.(); } catch (_) {}
    }));
  });

  if (!names.length) {
    const empty = document.createElement('div');
    empty.className = 'kix-inline-row kix-inline-heading';
    empty.textContent = 'Nenhuma variável criada';
    menu.appendChild(empty);
  }

  // The dropdown is interactive content inside the Brick. Stop every stage of
  // the pointer/click sequence at the dropdown boundary so the Brick's own
  // click handler cannot open its context menu or otherwise dismiss the list.
  const stopDropdownEvent = e => { e.stopPropagation(); };
  menu.addEventListener('pointerdown', stopDropdownEvent);
  menu.addEventListener('pointerup', stopDropdownEvent);
  menu.addEventListener('mousedown', stopDropdownEvent);
  menu.addEventListener('mouseup', stopDropdownEvent);
  menu.addEventListener('click', stopDropdownEvent);
  menu.addEventListener('touchstart', stopDropdownEvent, {passive:true});
  menu.addEventListener('touchend', stopDropdownEvent, {passive:true});
  const blockRect = blockEl.getBoundingClientRect();
  const targetRect = targetEl.getBoundingClientRect();
  // The dropdown is mounted inside the Brick, so align its top-left corner
  // with the exact top-left corner of the tapped variable parameter.
  menu.style.left = Math.round(targetRect.left - blockRect.left) + 'px';
  menu.style.top = Math.round(targetRect.top - blockRect.top) + 'px';
  blockEl.appendChild(menu);
  blockEl.classList.add('kix-variable-selector-open');
  targetEl.classList.add('kix-dropdown-active');
  targetEl.setAttribute('aria-expanded', 'true');
  window._kixSelectorTarget = { el: targetEl, kind: 'variable', variableTarget: target };
  requestAnimationFrame(() => menu.classList.add('is-open'));
  return true;
}

function escapeBlockHtml(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function normalizeBlockLabelText(text) {
  return String(text == null ? '' : text)
    .split(/\r?\n/)
    .map(line => line
      .replace(/[ \t]+/g, ' ')
      .replace(/\s+([,.;:!?])/g, '$1')
      .trim())
    .join('\n');
}

// Block language avoids comma period and degree symbols in the visible sentence.
// Parameter chips keep their real values unchanged including decimal numbers.
function normalizeKixVisualStaticText(text) {
  return String(text == null ? '' : text)
    .replace(/°/g, '')
    .replace(/\.{2,}/g, '')
    .replace(/_+/g, ' ')
    .replace(/\s*;\s*/g, ' ')
    .replace(/\s+([,.;:!?])/g, '$1')
    .replace(/(^|[\s(])#(?=[A-Za-zÀ-ÿ0-9])/g, '$1')
    .replace(/\s+/g, ' ')
    .trim();
}


function buildBlockLabelHtml(blockName, params, values, catalogMode, meta) {
  const name = String(blockName || '');
  const pluginMeta = meta && typeof meta === 'object' ? meta : null;
  const list = (params || []).map(p => normalizeParam(p, name));
  if (!list.length) {
    const translated = pluginMeta?.template || kixBlockTemplate(name, []);
    const visible = normalizeBlockLabelText(normalizeKixVisualStaticText(translated || name));
    return `<span class="blk-label">${escapeBlockHtml(visible)}</span>`;
  }

  const makeChip = (p) => {
    let display;
    if (catalogMode) {
      display = (pluginMeta?.example && list.length === 1 && (p.type === 'text' || p.type === 'string'))
        ? String(pluginMeta.example)
        : kixParamLabel(p.name);
    } else {
      let val = (values && values[p.name] !== undefined && values[p.name] !== '') ? values[p.name] : p.default;
      if (val === '' || val == null) val = '···';
      display = displayBlockParamValue(p, val);
    }
    const rawForEditor = !catalogMode
      ? ((values && values[p.name] !== undefined && values[p.name] !== '') ? values[p.name] : p.default)
      : display;
    const optionAttr = p.options && p.options.length ? ` data-options="${escapeBlockHtml(p.options.join('\u001f'))}"` : '';
    const dropdown = ['sound','object','actor','image','look','appearance','folder','scene'].includes(String(p.type || '').toLowerCase());
    const variableSelector = isKixVariableSelectorBlock(name) && String(p.name || '') === 'variável';
    const suppressDropdown = pluginMeta?.suppressDropdown === true;
    // Editor previews are visual prototypes, not live script parameters. They
    // must not expose the dropdown chevron/selector affordance. Real script
    // blocks keep the existing interactive selector path unchanged.
    // Variable selectors have their own interaction path. They must never
    // inherit the generic formula-open trigger, otherwise a tap can bypass the
    // selector dropdown and open the formula editor directly.
    const cls = 'param' + ((suppressDropdown || variableSelector) ? '' : ' formula-open') + ((dropdown || variableSelector) && !suppressDropdown ? ' dropdown' : '') + (variableSelector ? ' kix-variable-selector' : '');
    const kindAttr = (dropdown && !suppressDropdown) ? ` data-dropdown-type="${escapeBlockHtml(p.type)}"` : '';
    const variableAttr = variableSelector ? ' data-variable-selector="1"' : '';
    return `<span class="${cls}" data-param="${escapeBlockHtml(p.name)}" data-type="${escapeBlockHtml(p.type)}"${kindAttr}${variableAttr}${optionAttr} data-value="${escapeBlockHtml(rawForEditor)}">${escapeBlockHtml(display)}</span>`;
  };

  const chipsByName = Object.create(null);
  list.forEach(p => { chipsByName[p.name] = makeChip(p); });

  // Explicit visual templates are preferred. They eliminate ambiguous substring
  // matching (for example, "x" inside "joystick") and let us write multi-line
  // blocks exactly as the user reads them.
  if (String(name || '').trim() === 'Definir variável para') {
    const variableParam = list.find(p => String(p.name) === 'variável');
    const valueParam = list.find(p => String(p.name) === 'valor');
    const variableChip = variableParam ? chipsByName[variableParam.name] : '';
    const valueChip = valueParam ? chipsByName[valueParam.name] : '';
    return `<span class="blk-label kix-set-variable-label"><span class="kix-set-variable-title">Definir variável</span><span class="kix-set-variable-variable-line">${variableChip}</span><span class="kix-set-variable-value-line"><span class="kix-set-variable-keyword">Para</span>${valueChip}</span></span>`;
  }

  const template = pluginMeta?.template || kixBlockTemplate(name, list);
  if (template) {
    const allowTemplateBreaks = pluginMeta?.multiline === true || /^(?:Joystick|D-pad|Dpad|Controle virtual|Botão virtual|Escrever texto em tempo real|Perguntar ao usuário|Executar JavaScript)$/i.test(name);
    const html = String(template).split(/(\{[^}]+\})/g).map(part => {
      const m = part.match(/^\{(.+)\}$/);
      if (m && chipsByName[m[1]] !== undefined) return chipsByName[m[1]];
      const normalized = normalizeBlockLabelText(normalizeKixVisualStaticText(part));
      return escapeBlockHtml(allowTemplateBreaks ? normalized : normalized.replace(/[\r\n]+/g, ' ')).replace(/\n/g, allowTemplateBreaks ? '<br>' : ' ');
    }).join('').replace(/<br>\s+/g, '<br>');
    return `<span class="blk-label${allowTemplateBreaks ? ' blk-label-multiline' : ''}">${html}</span>`;
  }

  // Safe generic fallback: only replace a whole parameter word. Never search
  // for short parameter names such as x/y/id as arbitrary substrings.
  let label = escapeBlockHtml(normalizeKixVisualStaticText(name));
  list.forEach(p => {
    const token = `§${list.indexOf(p)}§`;
    const safeName = escapeBlockHtml(p.name);
    const re = new RegExp(`(^|[^A-Za-zÀ-ÿ0-9_])${safeName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(?=$|[^A-Za-zÀ-ÿ0-9_])`, 'i');
    if (re.test(label)) label = label.replace(re, `$1${token}`);
    else label += ` ${token}`;
  });
  list.forEach((p, pi) => { label = label.replace(`§${pi}§`, chipsByName[p.name]); });
  return `<span class="blk-label">${normalizeBlockLabelText(label)}</span>`;
}



// Loops get a visual end marker. The marker is editor-only and is never saved as a script block.
// It follows the same structural rule used by the current flat-script migration: a loop owns
// the action blocks until the next hat/loop/if block. Keeping this marker virtual preserves
// compatibility with existing projects while making the visual end explicit to beginners.
const KIX_LOOP_NAMES_VISUAL = new Set([
  'Sempre',
  'Repita X vezes',
  'Repita até',
  'Repita enquanto',
  'Repetir para sempre com delay',
  'Repetir assincronamente X vezes'
]);

function isKixVisualLoop(name) {
  const n = String(name || '');
  if (KIX_LOOP_NAMES_VISUAL.has(n)) return true;
  try { return !!(window.KixEngine && window.KixEngine.blockType && window.KixEngine.blockType(n) === 'loop'); } catch (_) { return false; }
}

function loopVisualEndIndices(scripts) {
  const ends = new Map();
  const list = Array.isArray(scripts) ? scripts : [];
  for (let i = 0; i < list.length; i++) {
    const block = list[i];
    const name = String(block?.name || '');
    if (!isKixVisualLoop(name)) continue;

    // New projects store the exact last block belonging to each loop.
    // This is what makes the visual terminator a real boundary instead of a
    // marker that is guessed from the next loop/hat.
    const boundaryExplicit = block && block.loopBoundaryExplicit === true;
    const storedEndId = boundaryExplicit && block.loopEndId != null ? String(block.loopEndId) : '';
    // An explicit null boundary means an intentionally empty loop. The
    // terminator must still be visible immediately after the loop block.
    let end = boundaryExplicit && !storedEndId ? i : -1;
    if (storedEndId) {
      for (let j = i + 1; j < list.length; j++) {
        if (String(list[j]?.id || '') === storedEndId) { end = j; break; }
      }
      // Explicit boundaries are never guessed. If a stored end id became
      // invalid, keep the loop empty rather than swallowing following blocks.
      if (end < i && boundaryExplicit) end = i;
    }

    // Backward compatibility for old flat projects: preserve the old meaning
    // (everything after the loop until the next hat/loop) exactly once.
    if (end < i && !boundaryExplicit) {
      end = i;
      for (let j = i + 1; j < list.length; j++) {
        const next = String(list[j]?.name || '');
        const isHat = /^Quando\s/i.test(next);
        const isLoop = isKixVisualLoop(next);
        if (isHat || isLoop) break;
        end = j;
      }
      if (end === i) end = i; // empty loop
    }
    ends.set(end, {
      color: block?.color || '#666',
      loopId: String(block?.id || ''),
      empty: end === i
    });
  }
  return ends;
}

// Keep explicit loop boundaries valid when blocks are deleted.
// If the removed range contains the block referenced by a surviving loop's
// loopEndId, move that boundary to the nearest surviving block still inside
// the same loop. This prevents deleting the last body block from turning all
// remaining siblings into outside blocks on the next render.
function repairLoopBoundariesAfterRemoval(scripts, removeStart, removeEnd) {
  if (!Array.isArray(scripts)) return;
  const removed = new Set();
  for (let i = Math.max(0, removeStart); i <= Math.min(removeEnd, scripts.length - 1); i++) {
    if (scripts[i]) removed.add(scripts[i]);
  }

  scripts.forEach((loop, loopIndex) => {
    if (!loop || !isKixVisualLoop(loop.name) || removed.has(loop)) return;
    if (loop.loopBoundaryExplicit !== true) return;

    const endId = loop.loopEndId != null && loop.loopEndId !== '' ? String(loop.loopEndId) : '';
    if (!endId) return;

    const endIndex = scripts.findIndex((block, i) => i > loopIndex && block && String(block.id || '') === endId);
    if (endIndex < 0 || !removed.has(scripts[endIndex])) return;

    let replacement = null;
    for (let i = endIndex - 1; i > loopIndex; i--) {
      const candidate = scripts[i];
      if (!candidate || removed.has(candidate)) continue;
      replacement = candidate;
      break;
    }

    loop.loopEndId = replacement ? String(replacement.id || '') || null : null;
    loop.loopBoundaryExplicit = true;
  });
}

function renderLoopEndMarker(container, color, loopId) {
  // The visual loop terminator itself is the insertion boundary. Older builds
  // created 2px drop-anchor elements here; even at near-zero opacity they could
  // look like a preview line during drag. The custom pointer sortable does not
  // need those anchors, so keep the DOM visually clean and use the terminator.
  const end = document.createElement('div');
  end.className = 'pc-block loop-end';
  end.dataset.loopEnd = '1';
  end.dataset.loopId = String(loopId || '');
  end.setAttribute('aria-hidden', 'true');
  end.style.background = color || '#666';
  end.style.color = '#fff';
  end.style.flex = '0 0 auto';
  // Structural end markers use the same full-width geometry as normal Bricks.
  end.style.width = 'auto';
  end.style.margin = '8px 0 10px 0';
  end.style.minHeight = '38px';
  end.style.borderRadius = '10px';
  end.style.opacity = '0.92';
  end.innerHTML = '<span class="blk-label">Fim de loop</span>';
  container.appendChild(end);
}

function isKixVisualIf(name) {
  const n = String(name || '');
  return n === 'Se ... então' || n === 'Se ... então ... senão' || n === 'Se [Fórmula] for verdadeira então...' || /\bSe .* então(?:.*senão)?/i.test(n) && /condição|verdadeira/i.test(n);
}

function isKixVisualControl(name) { return isKixVisualLoop(name) || isKixVisualIf(name); }

function isKixIfStructuralBlock(block) {
  if (!block) return false;
  const name = String(block.name || '');
  const sourceType = String(block.catrobat?.sourceType || '');
  return sourceType === 'KixIfElse' || sourceType === 'KixIfEnd' || sourceType === 'CatrobatIfElse' || sourceType === 'CatrobatIfEnd' || /^(Senão|Fim de condição|Fim se)$/i.test(name);
}

function ifVisualHasElse(block) {
  if (!block) return false;
  if (block.ifElseExplicit === true) return true;
  const name = String(block.name || '');
  if (name === 'Se [Fórmula] for verdadeira então...') return true;
  return name.includes('senão');
}

function ifVisualEndIndex(scripts, start, block) {
  const list = Array.isArray(scripts) ? scripts : [];
  if (!block) return -1;
  const endId = block.ifBoundaryExplicit === true && block.ifEndId != null ? String(block.ifEndId) : '';
  if (endId) {
    const found = list.findIndex((x, i) => i > start && x && String(x.id || '') === endId);
    if (found > start) return found;
  }
  // Legacy fallback: the first top-level control/hat terminates the visual range.
  let end = -1;
  for (let j = start + 1; j < list.length; j++) {
    const n = String(list[j]?.name || '');
    if (/^Quando\s/i.test(n) || isKixVisualLoop(n) || isKixVisualIf(n)) break;
    if (list[j]?.catrobat?.sourceType === 'CatrobatIfEnd' || /^Fim (?:de condição|se)$/i.test(n)) { end = j; break; }
    end = j;
  }
  return end >= start ? end : start;
}

function ifVisualMarkerIndices(scripts) {
  const out = new Map();
  const list = Array.isArray(scripts) ? scripts : [];
  for (let i = 0; i < list.length; i++) {
    const b = list[i];
    if (!isKixVisualIf(b?.name)) continue;
    const end = ifVisualEndIndex(list, i, b);
    if (end < i) continue;
    const id = String(b.id || '');
    let elseIndex = -1;
    const elseId = b.ifElseExplicit && b.ifElseId != null ? String(b.ifElseId) : '';
    if (elseId) elseIndex = list.findIndex((x,j)=>j>i && j<end && x && String(x.id||'')===elseId);
    if (elseIndex < 0 && ifVisualHasElse(b)) {
      for (let j=i+1;j<end;j++) {
        const n=String(list[j]?.name||'');
        if (list[j]?.catrobat?.sourceType === 'CatrobatIfElse' || /^Senão$/i.test(n)) { elseIndex=j; break; }
      }
    }
    if (elseIndex >= 0) out.set(elseIndex,{kind:'else',color:b.color||'#F99761',ifId:id});
    if (end >= 0) out.set(end,{kind:'end',color:b.color||'#F99761',ifId:id});
  }
  return out;
}

function renderIfMarker(container, kind, color, ifId) {
  const el = document.createElement('div');
  el.className = 'pc-block if-marker ' + (kind === 'else' ? 'if-else-marker' : 'if-end-marker');
  el.dataset.ifMarker = kind;
  el.dataset.ifId = String(ifId || '');
  el.setAttribute('aria-hidden','true');
  el.style.background = color || '#F99761';
  el.style.color = '#fff';
  el.style.flex = '0 0 auto';
  // Do not override the normal .pc-block geometry here. Structural IF markers
  // must occupy exactly the same visual row geometry as ordinary Bricks.
  el.style.opacity = '1';
  el.innerHTML = '<span class="blk-label">' + (kind === 'else' ? 'Senão' : 'Fim se') + '</span>';
  container.appendChild(el);
}

function ensureFlatIfBoundaries(scripts) {
  if (!Array.isArray(scripts)) return false;
  let changed = false;
  // Work backward so insertions do not invalidate yet-to-be-processed indices.
  for (let i = scripts.length - 1; i >= 0; i--) {
    const b = scripts[i];
    if (!isKixVisualIf(b?.name)) continue;
    const hasElse = ifVisualHasElse(b);
    let endIndex = ifVisualEndIndex(scripts, i, b);
    let endId = b.ifEndId != null ? String(b.ifEndId) : '';
    if (endIndex <= i || !scripts[endIndex] || !/^Fim (?:de condição|se)$/i.test(String(scripts[endIndex].name||''))) {
      const end = { id: (window.KixEngine?.newId?.() || ('bifend_'+Date.now()+Math.random())), opcode: window.KixEngine?.opcodeFor?.('Fim de condição') || '', color: b.color || '#F99761', name:'Fim de condição', params:[], values:{}, type:'if', disabled:true, ifEndId:null, ifBoundaryExplicit:true, catrobat:{sourceType:'KixIfEnd',disabled:true} };
      endId = String(end.id);
      end.ifEndId = endId;
      scripts.splice(Math.max(i+1, endIndex > i ? endIndex : i+1), 0, end);
      endIndex = scripts.indexOf(end);
      changed = true;
    } else if (!endId || String(scripts[endIndex].id||'') !== endId) {
      endId = String(scripts[endIndex].id||'');
      b.ifEndId = endId;
      b.ifBoundaryExplicit = true;
      changed = true;
    }
    b.ifBoundaryExplicit = true;
    b.ifEndId = endId || null;

    if (hasElse) {
      let elseIndex = -1;
      const elseId = b.ifElseId != null ? String(b.ifElseId) : '';
      if (elseId) elseIndex = scripts.findIndex((x,j)=>j>i && j<endIndex && x && String(x.id||'')===elseId);
      if (elseIndex < 0) {
        for (let j=i+1;j<endIndex;j++) {
          const x=scripts[j]; const n=String(x?.name||'');
          if (x?.catrobat?.sourceType === 'CatrobatIfElse' || /^Senão$/i.test(n)) { elseIndex=j; break; }
        }
      }
      if (elseIndex < 0) {
        const em = { id:(window.KixEngine?.newId?.() || ('bifelse_'+Date.now()+Math.random())), opcode:window.KixEngine?.opcodeFor?.('Senão') || '', color:b.color||'#F99761', name:'Senão', params:[], values:{}, type:'action', disabled:true, catrobat:{sourceType:'KixIfElse',disabled:true}, ifElseId:null, ifBoundaryExplicit:true };
        scripts.splice(endIndex,0,em);
        elseIndex=endIndex;
        endIndex++;
        changed=true;
      }
      b.ifElseId=String(scripts[elseIndex].id||'');
      b.ifElseExplicit=true;
      scripts[elseIndex].disabled=true;
      scripts[elseIndex].catrobat=Object.assign({},scripts[elseIndex].catrobat||{}, {sourceType:'KixIfElse',disabled:true});
    }
    scripts[endIndex].disabled=true;
    scripts[endIndex].ifEndId=b.ifEndId;
    scripts[endIndex].ifBoundaryExplicit=true;
    scripts[endIndex].catrobat=Object.assign({},scripts[endIndex].catrobat||{}, {sourceType:'KixIfEnd',disabled:true});
  }
  return changed;
}

function restoreCurrentActorContext() {
  try {
    const actors = getSceneActors();
    if (currentActor && actors.includes(currentActor)) {
      currentActorIdx = actors.indexOf(currentActor);
      ensureActorIdentity(currentActor);
      return currentActor;
    }
    const ctx = window._scriptActorContext || window._blockPickerContext;
    if (!ctx || Number(ctx.scene) !== Number(currentScene) || !currentProject) return null;
    const projectOk = !ctx.projectId || String(ctx.projectId) === String(ensureProjectIdentity(currentProject));
    if (!projectOk) return null;
    const found = resolveActorHint(ctx, actors);
    if (!found) return null;
    currentActor = found;
    currentActorIdx = actors.indexOf(found);
    ensureActorIdentity(found);
    return found;
  } catch (_) { return null; }
}

function kixIsStructuralTerminator(b) {
  if (!b) return false;
  if (b.boundaryKind) return true;
  if (b.disabled && /^(?:Fim de loop|Fim de condição|Fim se|Senão)$/i.test(String(b.name||''))) return true;
  return false;
}
function kixStructuralParentAt(list, targetIndex) {
  try {
    if (window.KixBrickDragModel?.structuralParentAt) return window.KixBrickDragModel.structuralParentAt(list, targetIndex);
  } catch (_) {}
  return null;
}
function kixValidateScriptStructure(list) {
  try {
    if (window.KixBrickDragModel?.validateStructure) return window.KixBrickDragModel.validateStructure(list);
  } catch (_) {}
  return [];
}
function kixRejectInvalidDrag(currentList, proposedList, draggedGroup) {
  let errors = [];
  try { errors = kixValidateScriptStructure(proposedList); } catch (_) { errors = []; }
  if (!errors.length) return false;
  const ids = new Set((draggedGroup || []).filter(Boolean).map(b => String(b.id || '')));
  const relevant = errors.find(e =>
    ids.has(String(e.block?.id || '')) ||
    ids.has(String(e.parent?.id || e.parent?.block?.id || ''))
  );
  if (!relevant) return false;
  try { toast('Esse Brick não pode ser inserido dentro desse controle'); } catch (_) {}
  return true;
}

function kixBuildDragProposal(list, draggedIndex, beforeIndex) {
  try {
    if (window.KixBrickDragModel?.isValidDrop) {
      return window.KixBrickDragModel.isValidDrop(list, draggedIndex, beforeIndex);
    }
  } catch (err) {
    return { valid:false, reason:err?.message || 'drag-model-error', scripts:Array.isArray(list) ? list.slice() : [] };
  }
  return { valid:false, reason:'drag-model-unavailable', scripts:Array.isArray(list) ? list.slice() : [] };
}

function kixDropTargetLoopId(node) {
  try {
    if (node && node.classList && node.classList.contains('loop-end')) return String(node.dataset.loopId || '');
  } catch (_) {}
  return '';
}

function kixApplyLoopBoundaryAfterInsert(scripts, loopId, insertedId) {
  if (!Array.isArray(scripts) || !loopId || !insertedId) return false;
  const loop = scripts.find(b => b && String(b.id || '') === String(loopId));
  if (!loop || !isKixVisualLoop(loop.name)) return false;
  loop.loopBoundaryExplicit = true;
  loop.loopEndId = String(insertedId);
  return true;
}

function kixRepairLoopBoundariesAfterMove(oldScripts, newScripts, movedGroup) {
  if (!Array.isArray(oldScripts) || !Array.isArray(newScripts)) return false;
  const movedIds = new Set((movedGroup || []).filter(Boolean).map(b => String(b.id || '')));
  if (!movedIds.size) return false;
  let changed = false;
  for (let i = 0; i < oldScripts.length; i++) {
    const loop = oldScripts[i];
    if (!loop || !isKixVisualLoop(loop.name) || loop.loopBoundaryExplicit !== true) continue;
    const loopId = String(loop.id || '');
    if (movedIds.has(loopId)) continue;
    const endId = loop.loopEndId == null ? '' : String(loop.loopEndId);
    if (!endId || !movedIds.has(endId)) continue;
    const endIndex = oldScripts.findIndex((b, j) => j > i && b && String(b.id || '') === endId);
    if (endIndex <= i) continue;
    const newIds = new Set(newScripts.map(b => String(b?.id || '')));
    let replacement = null;
    for (let j = endIndex - 1; j > i; j--) {
      const candidate = oldScripts[j];
      if (!candidate) continue;
      const id = String(candidate.id || '');
      if (!id || movedIds.has(id) || !newIds.has(id)) continue;
      replacement = id;
      break;
    }
    const newLoop = newScripts.find(b => b && String(b.id || '') === loopId);
    if (!newLoop) continue;
    newLoop.loopBoundaryExplicit = true;
    newLoop.loopEndId = replacement;
    changed = true;
  }
  return changed;
}

function kixApplyLoopDropToProposal(oldScripts, proposal, dropBeforeNode) {
  if (!proposal || !proposal.valid || !Array.isArray(proposal.scripts)) return proposal;
  const movedGroup = Array.isArray(proposal.group) ? proposal.group : [];
  const movedIds = new Set(movedGroup.filter(Boolean).map(b => String(b.id || '')));
  const targetLoopId = kixDropTargetLoopId(dropBeforeNode);
  let repairsNeeded = false;
  if (Array.isArray(oldScripts) && movedIds.size) {
    repairsNeeded = oldScripts.some(loop =>
      loop && isKixVisualLoop(loop.name) && loop.loopBoundaryExplicit === true &&
      loop.loopEndId != null && loop.loopEndId !== '' && movedIds.has(String(loop.loopEndId))
    );
  }
  // Drag preview must remain model-pure. The base proposal may share object
  // references with the persisted flat script, so boundary edits happen only
  // on a cloned proposal; the actual actor model changes later in onEnd().
  if (targetLoopId || repairsNeeded) {
    proposal.scripts = kixCloneScriptsForHistory(proposal.scripts);
  }
  kixRepairLoopBoundariesAfterMove(oldScripts, proposal.scripts, movedGroup);
  if (targetLoopId && movedGroup.length) {
    const groupEnd = movedGroup[movedGroup.length - 1];
    kixApplyLoopBoundaryAfterInsert(proposal.scripts, targetLoopId, groupEnd?.id);
  }
  return proposal;
}

function kixDropTargetBeforeIndex(node, scripts) {
  if (!node) return null;

  const idx = node.dataset?.scriptIdx != null ? Number(node.dataset.scriptIdx) : NaN;
  if (Number.isInteger(idx) && idx >= 0 && idx < (scripts?.length || 0)) return idx;

  const list = Array.isArray(scripts) ? scripts : [];

  // A rendered loop terminator is a logical boundary. Dropping before it means
  // inserting as the last child of that loop, including an empty loop.
  if (node.classList?.contains('loop-end')) {
    const loopId = String(node.dataset.loopId || '');
    const ownerIndex = list.findIndex(b => b && String(b.id || '') === loopId);
    if (ownerIndex >= 0) {
      const range = window.KixBrickDragModel?.groupRange
        ? window.KixBrickDragModel.groupRange(list, ownerIndex)
        : {start:ownerIndex,end:ownerIndex};
      // The loop-end marker is virtual and rendered *after* the last child.
      // Therefore dropping before it means inserting at end+1, not before the
      // last child. For an empty loop, that is immediately after the header.
      return Math.min(list.length, Number(range.end) + 1);
    }
  }

  // IF markers represent either the else boundary or the final end boundary.
  if (node.classList?.contains('if-marker')) {
    const ifId = String(node.dataset.ifId || '');
    const ownerIndex = list.findIndex(b => b && String(b.id || '') === ifId);
    if (ownerIndex >= 0) {
      const owner = list[ownerIndex];
      const kind = String(node.dataset.ifMarker || 'end');

      if (kind === 'else' && owner.ifElseExplicit && owner.ifElseId != null) {
        const elseId = String(owner.ifElseId);
        const elseIndex = list.findIndex((b,i) => i > ownerIndex && String(b?.id || '') === elseId);
        if (elseIndex >= 0) return elseIndex;
      }

      if (owner.ifBoundaryExplicit && owner.ifEndId != null) {
        const endId = String(owner.ifEndId);
        const endIndex = list.findIndex((b,i) => i > ownerIndex && String(b?.id || '') === endId);
        if (endIndex >= 0) return endIndex;
      }

      return window.KixBrickDragModel?.groupRange
        ? window.KixBrickDragModel.groupRange(list, ownerIndex).end
        : ownerIndex;
    }
  }

  return null;
}
function kixCloneScriptsForHistory(scripts) {
  try {
    if (window.KixBrickDragModel?.cloneScripts) return window.KixBrickDragModel.cloneScripts(scripts);
  } catch (_) {}
  try { return JSON.parse(JSON.stringify(Array.isArray(scripts) ? scripts : [])); } catch (_) { return Array.isArray(scripts) ? scripts.slice() : []; }
}
function kixSameScriptOrder(a, b) {
  try {
    if (window.KixBrickDragModel?.sameOrder) return window.KixBrickDragModel.sameOrder(a, b);
  } catch (_) {}
  if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
  for (let i=0;i<a.length;i++) {
    if (String(a[i]?.id || '') !== String(b[i]?.id || '') && a[i] !== b[i]) return false;
  }
  return true;
}

// Drag history is intentionally editor-local: one completed drag = one undo step.
// Intermediate pointer moves and previews never enter history.
const KIX_DRAG_HISTORY_LIMIT = 100;
const kixDragHistory = { undo: [], redo: [] };

function kixRecordBrickDrag(operation) {
  if (!operation || !operation.brickId || !operation.oldScripts || !operation.newScripts) return;
  kixDragHistory.undo.push({
    kind:'DragOperation',
    brickId:String(operation.brickId),
    projectId:String(operation.projectId || ''),
    actorId:String(operation.actorId || ''),
    oldParent:operation.oldParent == null ? null : String(operation.oldParent),
    oldIndex:Number(operation.oldIndex),
    newParent:operation.newParent == null ? null : String(operation.newParent),
    newIndex:Number(operation.newIndex),
    oldScripts:kixCloneScriptsForHistory(operation.oldScripts),
    newScripts:kixCloneScriptsForHistory(operation.newScripts),
    createdAt:Date.now()
  });
  if (kixDragHistory.undo.length > KIX_DRAG_HISTORY_LIMIT) kixDragHistory.undo.shift();
  kixDragHistory.redo.length = 0;
}

function kixFindActorForHistory(op) {
  if (!currentProject || !op) return null;
  const pid = ensureProjectIdentity(currentProject);
  if (op.projectId && String(op.projectId) !== String(pid)) return null;
  const actors = getSceneActors();
  if (op.actorId) {
    const found = actors.find(a => String(ensureActorIdentity(a)) === String(op.actorId));
    if (found) return found;
  }
  return currentActor && actors.includes(currentActor) ? currentActor : null;
}

function kixApplyHistoryOperation(op, direction) {
  const actor = kixFindActorForHistory(op);
  if (!actor) return false;
  const scripts = direction === 'undo' ? op.oldScripts : op.newScripts;
  actor.scripts = kixCloneScriptsForHistory(scripts);
  currentActor = actor;
  currentActorIdx = getSceneActors().indexOf(actor);
  syncActorToProject();
  save();
  renderScripts();
  return true;
}

function kixUndoBrickDrag() {
  const op = kixDragHistory.undo[kixDragHistory.undo.length - 1];
  if (!op || !kixApplyHistoryOperation(op, 'undo')) return false;
  kixDragHistory.undo.pop();
  kixDragHistory.redo.push(op);
  return true;
}

function kixRedoBrickDrag() {
  const op = kixDragHistory.redo[kixDragHistory.redo.length - 1];
  if (!op || !kixApplyHistoryOperation(op, 'redo')) return false;
  kixDragHistory.redo.pop();
  kixDragHistory.undo.push(op);
  return true;
}

window.KixBrickHistory = {
  undo: kixUndoBrickDrag,
  redo: kixRedoBrickDrag,
  clear: () => { kixDragHistory.undo.length = 0; kixDragHistory.redo.length = 0; },
  counts: () => ({ undo:kixDragHistory.undo.length, redo:kixDragHistory.redo.length })
};

window.KixVariableSelector = {
  isBlock: isKixVariableSelectorBlock,
  names: getKixAvailableVariableNames,
  open: openKixVariableDropdown,
  apply: applyKixVariableSelectorValue
};

function renderScripts() {
  const container = $('script-blocks'); if (!container) return;
  restoreCurrentActorContext();
  if (currentActor) {
    window._scriptActorContext = { project: currentProject, projectId: ensureProjectIdentity(currentProject), scene: currentScene, actorId: ensureActorIdentity(currentActor), actorIdx: currentActorIdx, actorName: String(currentActor.name || '') };
  }
  // Keep script blocks in a normal vertical flow. This avoids a mobile/WebView
  // compositing edge case where the preset joystick block could visually cover
  // following siblings.
  container.style.display = 'flex';
  container.style.flexDirection = 'column';
  container.style.alignItems = 'stretch';
  container.style.width = '100%';
  container.style.position = 'relative';
  container.style.isolation = 'isolate';
  container.style.gap = '0px';
  container.innerHTML = '';
  const empty = $('scripts-empty');
  if (!currentActor) return;
  // Flatten tree form for editor display
  if (currentActor.scripts && currentActor.scripts.blocks && window.KixEngine) {
    currentActor.scripts = KixEngine.scriptsToFlat(currentActor.scripts);
  }
  if (!Array.isArray(currentActor.scripts)) currentActor.scripts = [];

  // Convert legacy flat loop ranges to explicit boundaries once. From this
  // point onward the marker position is stored on the loop itself, so blocks
  // can be freely dropped below Fim de loop without being swallowed back into
  // the loop on the next render.
  if (window.KixEngine && typeof KixEngine.ensureFlatLoopBoundaries === 'function') {
    const changed = KixEngine.ensureFlatLoopBoundaries(currentActor.scripts);
    if (changed) save();
  }
  if (typeof ensureFlatIfBoundaries === 'function') {
    const changedIf = ensureFlatIfBoundaries(currentActor.scripts);
    if (changedIf) save();
  }
  if (!currentActor.scripts.length) { if (empty) empty.style.display = ''; return; }
  if (empty) empty.style.display = 'none';
  const loopEnds = loopVisualEndIndices(currentActor.scripts);
  const ifMarkers = ifVisualMarkerIndices(currentActor.scripts);
  currentActor.scripts.forEach((s, si) => {
    // Imported Catrobat loop terminators are structural model records. The editor
    // renders exactly one virtual Fim de loop marker from loopVisualEndIndices().
    if (s && s.catrobat && s.catrobat.sourceType === 'CatrobatLoopEnd') return;
    if (s && s.sourceType === 'CatrobatLoopEnd') return;
    // Persisted IF markers are runtime data; the editor renders one virtual,
    // non-draggable marker so Senão/Fim se cannot be duplicated or split.
    if (isKixIfStructuralBlock(s)) {
      if (ifMarkers.has(si)) {
        const marker = ifMarkers.get(si);
        renderIfMarker(container, marker.kind, marker.color || '#F99761', marker.ifId);
      }
      return;
    }
    const b = document.createElement('div');
    const entering = window._kixAnimateBlockId && String(window._kixAnimateBlockId) === String(s.id);
    b.className = 'pc-block' + (s.disabled ? ' disabled' : '') + (entering ? ' kix-block-enter' : '');
    const pluginPresentation = window.KixPluginRuntime?.getPresentation?.(s.name, {
      pluginId: s.pluginId || '', pluginBlockId: s.pluginBlockId || '', color: s.color || '',
      heightY: s.heightY || 56, multiline: !!s.multiline, template: '', example: '', badge: '', family: ''
    }, s) || null;
    b.style.background = s.disabled ? '#3A3A3A' : (pluginPresentation?.color || s.color || '#666');
    b.style.flex = '0 0 auto';
    // Width is owned by the CSS box model. The connector extends outside the
    // left edge, so subtracting 26px here created a visible right-side gap.
    b.style.width = 'auto';
    b.style.minHeight = (Math.max(32, Number(pluginPresentation?.heightY || s.heightY || 0) || 56) * 1.05).toFixed(2) + 'px';
    b.style.height = 'auto';
    b.style.zIndex = String(si + 1);
    b.dataset.name = s.name;
    b.dataset.scriptIdx = String(si);
    b.dataset.blockId = String(s.id || '');
    b.dataset.actorId = String(ensureActorIdentity(currentActor));
    if (s.pluginId) b.dataset.pluginId = String(s.pluginId);
    if (s.pluginBlockId) b.dataset.pluginBlockId = String(s.pluginBlockId);
    if (pluginPresentation?.multiline || s.multiline) b.classList.add('kix-plugin-multiline');
    b.innerHTML = buildBlockLabelHtml(s.name, s.params, s.values, false, pluginPresentation);
    // Gesto único do editor: toque curto abre o painel; toque prolongado
    // transforma o mesmo gesto em Drag. Rolagem vertical antes da ativação
    // cancela o gesto sem disparar o painel de opções.
    // O Drag é controlado exclusivamente pelo BrickDragController abaixo; não
    // existe um segundo motor local de long-press.
    const openCtx = () => {
      if (!b.isConnected) return;
      window._kixSelectedBlock = { actorId:String(ensureActorIdentity(currentActor)), blockId:String(s.id || ''), scriptIdx:si };
      if (container._sortable?.isDragging?.()) return;
      container._sortable?.cancelPending?.();
      openBlockContext(s.name, s.color, si, !!(s.params && s.params.length));
    };
    b.addEventListener('click', e => {
      if (e.defaultPrevented) return;
      const target = e.target;
      if (target && target.closest && target.closest('input,button,select,textarea,[contenteditable="true"],.param,.kix-inline-dropdown')) return;
      openCtx();
    });
    // Clique secundário continua sendo um caminho auxiliar no desktop; o fluxo
    // principal agora é clique curto para opções e segurar + mover para arrastar.
    b.addEventListener('contextmenu', e => {
      e.preventDefault();
      e.stopPropagation();
      openCtx();
    });
    container.appendChild(b);
    if (loopEnds.has(si)) {
      const marker = loopEnds.get(si);
      renderLoopEndMarker(container, marker.color || '#666', marker.loopId);
    }
  });

  // Only the block just created gets an entrance animation; rerenders no longer animate the entire script.
  window._kixAnimateBlockId = null;

  // Drag-and-drop reorder (flat list). Soltar reordena o array.
  if (window.Sortable && container) {
    if (container._sortable) { try { container._sortable.destroy(); } catch(e) {} }
    container._sortable = Sortable.create(container, {
      draggable: '.pc-block:not(.loop-end):not(.if-marker)',
      filter: '.loop-end, .if-marker, input, button, select, textarea, [contenteditable="true"], .param, .kix-inline-dropdown',

      // Pocket Code/Catroid style: toque curto = opções; segurar = Drag.
      // Após a janela de ativação o mesmo gesto entra em DRAGGING mesmo sem
      // movimento inicial; o movimento subsequente apenas posiciona o Brick.
      delay: 360,
      delayOnTouchOnly: true,
      delayStartsDragOnMovementOnly: false,
      forceFallback: true,
      fallbackTolerance: 8,
      touchStartThreshold: 8,
      manualScrollBeforeHold: true,
      autoScrollEdge: 44,
      autoScrollDelay: 260,
      autoScrollMax: 7,

      // The controller asks the model whether the current preview target is legal.
      // No model mutation happens during pointer movement.
      isValidDropTarget: function(target) {
        try {
          if (!currentActor || !Array.isArray(currentActor.scripts)) return false;
          const state = container._dragModelState;
          if (!state || !Number.isInteger(state.originalIndex)) return false;
          const beforeIndex = kixDropTargetBeforeIndex(target?.beforeNode, state.originalScripts || currentActor.scripts);
          const old = state.originalScripts || currentActor.scripts.slice();
          const validation = kixBuildDragProposal(old, state.originalIndex, beforeIndex);
          kixApplyLoopDropToProposal(old, validation, target?.beforeNode);
          if (!validation.valid) return false;
          if (typeof window.KixBrickDragModel?.validateStructure === 'function') {
            const errors = window.KixBrickDragModel.validateStructure(validation.scripts);
            const movedIds = new Set((validation.group || []).map(b => String(b?.id || '')));
            const relevant = errors.find(err => movedIds.has(String(err.block?.id || '')) || movedIds.has(String(err.parent?.id || err.parent?.block?.id || '')));
            if (relevant) return false;
          }
          return true;
        } catch (err) {
          console.warn('isValidDropTarget', err);
          return false;
        }
      },

      onTargetChange: function(info) {
        // Preview only. The DOM slot/ghost represent the target; the model is untouched.
        try {
          container.dataset.kixDropValid = info.valid ? '1' : '0';
          if (info.item) {
            info.item.setAttribute('aria-grabbed', 'true');
            info.item.setAttribute('aria-invalid', info.valid ? 'false' : 'true');
          }
        } catch (_) {}
      },

      // When a loop/IF header is dragged, temporarily hide its body and virtual
      // terminators. The entire structural unit then moves together.
      onStart: function(evt) {
        if (!currentActor || !Array.isArray(currentActor.scripts)) return;

        const idx = Number(evt && evt.item && evt.item.dataset && evt.item.dataset.scriptIdx);
        if (!Number.isInteger(idx) || idx < 0 || idx >= currentActor.scripts.length) return;

        const source = currentActor.scripts[idx];
        if (!source) return;

        const originalScripts = currentActor.scripts.slice();
        const originalParent = kixStructuralParentAt(originalScripts, idx);

        container._dragModelState = {
          originalScripts,
          originalIndex: idx,
          originalParentId: originalParent?.id != null ? String(originalParent.id) : null,
          brickId: String(source.id || ''),
          hidden: []
        };

        if (!isKixVisualControl(source.name)) return;

        const isLoop = isKixVisualLoop(source.name);
        const isIf = isKixVisualIf(source.name);
        let end = idx;

        const explicit = isLoop
          ? source.loopBoundaryExplicit === true
          : source.ifBoundaryExplicit === true;
        const endId = explicit
          ? String(isLoop ? (source.loopEndId ?? '') : (source.ifEndId ?? ''))
          : '';

        if (endId) {
          const found = originalScripts.findIndex((b, i) =>
            i > idx && b && String(b.id || '') === endId
          );
          if (found > idx) end = found;
        } else if (!explicit) {
          const range = window.KixBrickDragModel?.groupRange
            ? window.KixBrickDragModel.groupRange(originalScripts, idx)
            : {start:idx,end:idx};
          end = range.end;
        }

        const hidden = [];
        for (let i = idx + 1; i <= end; i++) {
          const node = container.querySelector(`.pc-block[data-script-idx="${i}"]`);
          if (node) {
            hidden.push({
              node,
              display: node.style.display,
              visibility: node.style.visibility,
              kixDragHidden: node.dataset.kixDragHidden
            });
            node.style.visibility = 'hidden';
            node.dataset.kixDragHidden = '1';
          }
        }

        // Hide virtual structural markers that belong to the dragged unit.
        const groupIds = new Set();
        for (let i = idx; i <= end; i++) {
          const b = originalScripts[i];
          if (b && isKixVisualControl(b.name)) groupIds.add(String(b.id || ''));
        }

        Array.from(container.children).forEach(node => {
          if (!node.classList) return;
          if (!(node.classList.contains('loop-end') ||
                node.classList.contains('loop-drop-anchor') ||
                node.classList.contains('if-marker'))) return;

          const markerOwner = node.classList.contains('if-marker')
            ? String(node.dataset.ifId || '')
            : String(node.dataset.loopId || '');

          if (!groupIds.has(markerOwner)) return;

          hidden.push({
            node,
            display: node.style.display,
            visibility: node.style.visibility,
            kixDragHidden: node.dataset.kixDragHidden
          });
          node.style.visibility = 'hidden';
          node.dataset.kixDragHidden = '1';
        });

        container._dragModelState.hidden = hidden;
        container._dragLoopState = {
          id: String(source.id || ''),
          start: idx,
          end,
          hidden
        };

        evt.item.dataset.dragLoopHeader = '1';
      },

      onEnd: function(evt) {
        const modelState = container._dragModelState || null;
        const loopState = container._dragLoopState || null;

        const restoreHidden = () => {
          const hidden = modelState?.hidden || loopState?.hidden || [];
          hidden.forEach(x => {
            try {
              x.node.style.display = x.display;
              x.node.style.visibility = x.visibility || '';
              if (x.kixDragHidden == null) delete x.node.dataset.kixDragHidden;
              else x.node.dataset.kixDragHidden = x.kixDragHidden;
            } catch (_) {}
          });
        };

        try {
          if (!currentActor || !modelState || !Array.isArray(modelState.originalScripts)) {
            return;
          }

          if (evt?.cancelled) {
            return;
          }

          const old = modelState.originalScripts;
          const draggedIndex = modelState.originalIndex;
          const beforeIndex = kixDropTargetBeforeIndex(evt?.dropBeforeNode, old);

          const proposal = kixBuildDragProposal(old, draggedIndex, beforeIndex);
          kixApplyLoopDropToProposal(old, proposal, evt?.dropBeforeNode);
          if (!proposal.valid || !Array.isArray(proposal.scripts)) {
            toast('Esse Brick não pode ser inserido nessa posição');
            return;
          }

          // Same logical order = a no-op. Do not create an undo entry or persist.
          if (kixSameScriptOrder(old, proposal.scripts)) return;

          const dragged = old[draggedIndex];
          if (!dragged) return;

          const oldParent = kixStructuralParentAt(old, draggedIndex);
          const newParent = kixStructuralParentAt(proposal.scripts, proposal.insertAt);

          // The only mutation of the logical program happens here, once.
          currentActor.scripts = proposal.scripts;

          kixRecordBrickDrag({
            brickId: String(dragged.id || modelState.brickId || ''),
            projectId: ensureProjectIdentity(currentProject),
            actorId: ensureActorIdentity(currentActor),
            oldParent: oldParent?.id ?? modelState.originalParentId ?? null,
            oldIndex: draggedIndex,
            newParent: newParent?.id ?? null,
            newIndex: proposal.insertAt,
            oldScripts: old,
            newScripts: proposal.scripts
          });

          try {
            window._kixAnimateBlockId = dragged.id ? String(dragged.id) : null;
          } catch (_) {
            window._kixAnimateBlockId = null;
          }

          syncActorToProject();
          save();
        } catch (err) {
          console.error('Brick drag commit', err);
          try {
            currentActor.scripts = modelState.originalScripts;
            toast('Não foi possível mover o Brick');
          } catch (_) {}
        } finally {
          restoreHidden();
          container._dragModelState = null;
          container._dragLoopState = null;
          try { delete container.dataset.kixDropValid; } catch (_) {}
          if (evt?.item) {
            delete evt.item.dataset.dragLoopHeader;
            evt.item.setAttribute('aria-grabbed', 'false');
            evt.item.setAttribute('aria-invalid', 'false');
          }
          renderScripts();
        }
      },

      onCancel: function(evt) {
        const modelState = container._dragModelState || null;
        const loopState = container._dragLoopState || null;

        const restoreHidden = () => {
          const hidden = modelState?.hidden || loopState?.hidden || [];
          hidden.forEach(x => {
            try {
              x.node.style.display = x.display;
              x.node.style.visibility = x.visibility || '';
              if (x.kixDragHidden == null) delete x.node.dataset.kixDragHidden;
              else x.node.dataset.kixDragHidden = x.kixDragHidden;
            } catch (_) {}
          });
        };

        // The model was never mutated during drag; cancel simply restores the UI.
        restoreHidden();
        container._dragModelState = null;
        container._dragLoopState = null;
        try { delete container.dataset.kixDropValid; } catch (_) {}

        if (evt?.invalid) {
          try { toast('Destino inválido'); } catch (_) {}
        }

        if (evt?.item) {
          delete evt.item.dataset.dragLoopHeader;
          evt.item.setAttribute('aria-grabbed', 'false');
          evt.item.setAttribute('aria-invalid', 'false');
        }
        renderScripts();
      }
    });

  }
}

function showBlockTip(name, x, y) {
  const tip = $('block-tip'); if (!tip) return;
  const displayName = kixBlockTemplate(name) || name;
  tip.textContent = BLOCK_HELP[name] || (kixCurrentLocale() === 'en' ? 'Block: ' + displayName : kixCurrentLocale() === 'es' ? 'Bloque: ' + displayName : kixCurrentLocale() === 'ru' ? 'Блок: ' + displayName : 'Bloco: ' + displayName);
  tip.style.display = 'block';
  tip.style.left = Math.min(x, innerWidth - 250) + 'px';
  tip.style.top = Math.max(8, y - 55) + 'px';
}
function hideBlockTip() { setTimeout(() => { if ($('block-tip')) $('block-tip').style.display = 'none'; }, 1600); }

function addBlockToScript(color, name, params, actorHint, insertBeforeIndex, dropBeforeNode, pluginDefinition) {
  try {
    if (name === 'Criar YourBrick') {
      openActionScreen({
        title:'YourBrick', message:'Nome + parâmetros + sequência de Bricks. Use ; entre parâmetros e ; entre Bricks.',
        value:'', input:true, confirmText:'Criar',
        onConfirm:(raw) => {
          try {
            const parts=String(raw||'').split('=>');
            const head=String(parts[0]||'').trim();
            const seqText=String(parts[1]||'').trim();
            const m=head.match(/^(.+?)(?:\((.*?)\))?$/);
            const defName=String(m?.[1]||head).trim();
            const pnames=String(m?.[2]||'').split(',').map(x=>x.trim()).filter(Boolean);
            const seq=seqText.split(';').map(x=>x.trim()).filter(Boolean).map(txt=>({name:txt,params:[],values:{}}));
            if(!defName){ toast('Nome inválido'); return; }
            const def=kixCreateCustomBrick(defName,pnames,seq,currentProject);
            syncActorToProject(); save(); buildCategories(); renderScripts(); toast('YourBrick criado: '+def.name);
          } catch(e){ console.error('Create YourBrick',e); toast('Não foi possível criar YourBrick'); }
        }
      });
      return true;
    }
    const actors = getSceneActors();
    const ctx = actorHint || window._blockPickerContext || null;
    let actor = null;

    // Resolve against a stable project + actor identity first. DOM navigation and
    // rerenders may replace object references; IDs keep the editor attached to the
    // same object instead of silently falling back to "no object".
    if (ctx && currentProject && Number(ctx.scene) === Number(currentScene)) {
      const projectMatches = (ctx.project === currentProject) || (ctx.projectId && String(ctx.projectId) === String(ensureProjectIdentity(currentProject)));
      if (projectMatches) actor = resolveActorHint(ctx, actors);
    }
    const currentActorId = currentActor ? ensureActorIdentity(currentActor) : '';
    if (!actor && currentActor && actors.includes(currentActor)) actor = currentActor;
    if (!actor && currentActorId) actor = actors.find(a => String(a.kixId || '') === String(currentActorId)) || null;
    if (!actor && currentActorIdx >= 0 && actors[currentActorIdx]) actor = actors[currentActorIdx];
    if (!actor) { toast('Abra um objeto primeiro'); return false; }

    currentActor = actor;
    currentActorIdx = actors.indexOf(actor);
    if (actor.scripts && actor.scripts.blocks && window.KixEngine) actor.scripts = KixEngine.scriptsToFlat(actor.scripts);
    if (!Array.isArray(actor.scripts)) actor.scripts = [];
    const isDragInsert = insertBeforeIndex !== undefined;
    const resolvedInsertAt = isDragInsert && insertBeforeIndex != null && Number.isInteger(Number(insertBeforeIndex))
      ? Math.max(0, Math.min(actor.scripts.length, Number(insertBeforeIndex)))
      : actor.scripts.length;
    const dragInsertOldScripts = isDragInsert ? kixCloneScriptsForHistory(actor.scripts) : null;
    const values = {};
    (params || []).forEach(p => {
      if (typeof p === 'object' && p.name) {
        const np = normalizeParam(p);
        if (p.type === 'folder') {
          const folders = actor.folders || [];
          values[p.name] = p.default != null ? p.default : (folders[0] ? ("'" + folders[0].name + "'") : np.default);
        } else if (p.type === 'file') {
          const files = currentProject?.files || [];
          values[p.name] = p.default != null ? p.default : (files[0] ? ("'" + files[0].name + "'") : np.default);
        } else {
          values[p.name] = np.default;
        }
      } else {
        const pn = String(p);
        const textish = /mensagem|texto|nome|url|caminho|chave|api|id|sprite|som|cena|variável|variavel|arquivo|código|codigo|pasta|fonte/i.test(pn);
        values[pn] = textish ? ("'" + pn + "'") : '1';
      }
    });
    const resolvedPluginDef = pluginDefinition || window.KixPluginRuntime?.findBlockByName?.(name) || null;
    const visualName = resolvedPluginDef?.overrideOf || name || 'Bloco';
    const pluginCategory = resolvedPluginDef && window.KixPluginRuntime?.categoryPresentation
      ? window.KixPluginRuntime.categoryPresentation(resolvedPluginDef.pluginId, resolvedPluginDef.categoryId)
      : null;
    const pluginColor = resolvedPluginDef
      ? (resolvedPluginDef.useCategoryColor ? (pluginCategory?.color || resolvedPluginDef.color || color || '#666') : (resolvedPluginDef.color || color || '#666'))
      : (color || '#666');
    const pluginParams = resolvedPluginDef?.params?.length ? resolvedPluginDef.params : (params || []);
    const pluginType = resolvedPluginDef?.type || (window.KixEngine ? KixEngine.blockType(visualName) : 'action');
    const block = {
      id: window.KixEngine ? KixEngine.newId() : ('b' + Date.now() + Math.random().toString(36).slice(2)),
      opcode: resolvedPluginDef ? ('kix.plugin.' + resolvedPluginDef.pluginId + '.' + resolvedPluginDef.id) : (window.KixEngine?.opcodeFor ? KixEngine.opcodeFor(visualName) : kixStableOpcode(visualName)),
      color: pluginColor, name: visualName, params: pluginParams, values,
      type: pluginType, disabled: false
    };
    if (resolvedPluginDef) {
      block.pluginId = String(resolvedPluginDef.pluginId || '');
      block.pluginBlockId = String(resolvedPluginDef.id || '');
      block.pluginLanguage = String(resolvedPluginDef.handlerLanguage || 'javascript');
      block.heightY = Number(resolvedPluginDef.heightY || 56);
      block.multiline = !!resolvedPluginDef.multiline;
      block.template = String(resolvedPluginDef.template || '');
      block.example = String(resolvedPluginDef.example || '');
      block.useCategoryColor = resolvedPluginDef.useCategoryColor !== false;
      block.canContainChildren = resolvedPluginDef.canContainChildren === true;
      block.canBeChild = resolvedPluginDef.canBeChild !== false;
      block.allowedParent = Array.isArray(resolvedPluginDef.allowedParent) ? resolvedPluginDef.allowedParent.slice() : ['script','control'];
      block.allowedChildren = Array.isArray(resolvedPluginDef.allowedChildren) ? resolvedPluginDef.allowedChildren.slice() : [];
      if (pluginType === 'loop') { block.loopEndId = null; block.loopBoundaryExplicit = true; }
      if (pluginType === 'if') { block.ifEndId = null; block.ifBoundaryExplicit = true; }
    }
    (resolvedPluginDef?.params || []).forEach(p => { if (!(p.name in values)) values[p.name] = p.default == null ? '' : p.default; });
    const customDef = currentProject ? kixGetCustomBricks(currentProject).find(d => kixNormalizeBrickText(d.name) === kixNormalizeBrickText(name)) : null;
    if (customDef) { block.customBrickId=customDef.id; block.type='custom'; block.canContainChildren=false; block.canBeChild=true; block.allowedParent=['script','control']; block.allowedChildren=[]; }
    if ((resolvedPluginDef?.type === 'if' && resolvedPluginDef.ifElse === true) || name === 'Se ... então ... senão' || name === 'Se [Fórmula] for verdadeira então...') {
      const endId = window.KixEngine?.newId?.() || ('bifend_'+Date.now()+Math.random());
      const elseId = window.KixEngine?.newId?.() || ('bifelse_'+Date.now()+Math.random());
      block.ifEndId = String(endId);
      block.ifBoundaryExplicit = true;
      block.ifElseId = String(elseId);
      block.ifElseExplicit = true;
      const elseMarker = {
        id:String(elseId), opcode:window.KixEngine?.opcodeFor?.('Senão')||'', color:block.color||'#F99761', name:'Senão', params:[], values:{}, type:'action', disabled:true,
        catrobat:{sourceType:'KixIfElse',disabled:true,ifOwnerId:String(block.id)}
      };
      const endMarker = {
        id:String(endId), opcode:window.KixEngine?.opcodeFor?.('Fim de condição')||'', color:block.color||'#F99761', name:'Fim de condição', params:[], values:{}, type:'if', disabled:true,
        ifEndId:String(endId), ifBoundaryExplicit:true, catrobat:{sourceType:'KixIfEnd',disabled:true,ifOwnerId:String(block.id)}
      };
      const insertAt = resolvedInsertAt;
      actor.scripts.splice(insertAt, 0, block, elseMarker, endMarker);
    } else if (resolvedPluginDef?.type === 'if' || name === 'Se ... então') {
      const endId = window.KixEngine?.newId?.() || ('bifend_'+Date.now()+Math.random());
      block.ifEndId = String(endId); block.ifBoundaryExplicit = true;
      const endMarker = {
        id:String(endId), opcode:window.KixEngine?.opcodeFor?.('Fim de condição')||'', color:block.color||'#F99761', name:'Fim de condição', params:[], values:{}, type:'if', disabled:true,
        ifEndId:String(endId), ifBoundaryExplicit:true, catrobat:{sourceType:'KixIfEnd',disabled:true,ifOwnerId:String(block.id)}
      };
      const insertAt = resolvedInsertAt;
      actor.scripts.splice(insertAt, 0, block, endMarker);
    } else if (resolvedPluginDef?.type === 'loop') {
      const insertAt = resolvedInsertAt;
      actor.scripts.splice(insertAt, 0, block);
    } else {
      const insertAt = resolvedInsertAt;
      actor.scripts.splice(insertAt, 0, block);
    }
    // A palette drop on a virtual Fim de loop marker is a structural insertion,
    // not merely an array position. Extend the exact target loop to the new block.
    const targetLoopId = kixDropTargetLoopId(dropBeforeNode);
    if (targetLoopId) {
      kixApplyLoopBoundaryAfterInsert(actor.scripts, targetLoopId, block.id);
    }
    ensureActorIdentity(actor);
    if (currentActorIdx >= 0 && actors[currentActorIdx]) actors[currentActorIdx] = actor;
    currentActor = actor;
    currentActorIdx = actors.indexOf(actor);
    window._kixAnimateBlockId = String(block.id);
    if (dragInsertOldScripts) {
      kixRecordBrickDrag({
        brickId: String(block.id || ''),
        projectId: ensureProjectIdentity(currentProject),
        actorId: ensureActorIdentity(actor),
        oldParent: null,
        oldIndex: -1,
        newParent: null,
        newIndex: Math.max(0, Math.min(actor.scripts.length - 1, resolvedInsertAt)),
        oldScripts: dragInsertOldScripts,
        newScripts: actor.scripts
      });
    }
    syncActorToProject();
    save();
    renderScripts();
    show('scripts', { noPush: true });
    // Confirm model + DOM state before reporting success. Never claim a block was placed unless it exists.
    const placed = Array.isArray(currentActor.scripts) && currentActor.scripts.some(b => b && b.id === block.id);
    if (!placed) throw new Error('O bloco não foi persistido');
    toast('Bloco adicionado');
    return true;
  } catch (e) {
    console.error('addBlockToScript', e);
    toast('Não foi possível colocar o bloco');
    return false;
  }
}

function appearanceKey(src) {
  const text = String(src || '');
  let hash = 2166136261;
  for (let i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619);
  return String(hash >>> 0);
}

function actorAppearanceEntries(actor) {
  const out = [];
  if (!actor) return out;
  const root = Array.isArray(actor.looks) ? actor.looks : [];
  root.forEach((src, i) => { if (src) out.push({ where:'root', folderIdx:null, idx:i, src:String(src) }); });
  (Array.isArray(actor.folders) ? actor.folders : []).forEach((folder, fi) => {
    (Array.isArray(folder?.looks) ? folder.looks : []).forEach((src, i) => { if (src) out.push({ where:'folder', folderIdx:fi, idx:i, src:String(src) }); });
  });
  return out;
}

function appearancePixelArtEnabled(actor, src) {
  if (!actor || !src) return !!actor?.pixelArt;
  const key=appearanceKey(src);
  const explicit=actor.pixelArtLooks && typeof actor.pixelArtLooks === 'object' ? actor.pixelArtLooks : {};
  if (Object.prototype.hasOwnProperty.call(explicit,key)) return explicit[key] === true;
  const auto=actor.pixelArtAutoLooks && typeof actor.pixelArtAutoLooks === 'object' ? actor.pixelArtAutoLooks : {};
  return auto[key] === true;
}

function setActorAppearanceActive(actor, src, where, folderIdx, idx) {
  if (!actor) return false;
  const clean = String(src || '');
  if (!clean) return false;
  actor.image = clean;
  actor.activeAppearance = {
    where: where === 'folder' ? 'folder' : 'root',
    folderIdx: where === 'folder' ? Number(folderIdx) : null,
    idx: Number(idx) || 0,
    key: appearanceKey(clean)
  };
  if (where !== 'folder') actor.costume = Number(idx) || 0;
  actor.pixelArt = appearancePixelArtEnabled(actor, clean);
  return true;
}

function normalizeActorAppearanceState(actor, preferredSrc) {
  if (!actor) return null;
  if (!Array.isArray(actor.looks)) actor.looks = [];
  if (!Array.isArray(actor.folders)) actor.folders = [];
  const entries = actorAppearanceEntries(actor);
  let chosen = null;
  const wanted = String(preferredSrc || actor.image || '');
  if (wanted) chosen = entries.find(e => e.src === wanted) || null;
  const active = actor.activeAppearance;
  if (!chosen && active) {
    chosen = entries.find(e => e.where === active.where && Number(e.folderIdx ?? -1) === Number(active.folderIdx ?? -1) && Number(e.idx) === Number(active.idx)) || null;
    if (!chosen && active.key) chosen = entries.find(e => appearanceKey(e.src) === String(active.key)) || null;
  }
  if (!chosen) {
    const rootIndex = Math.max(0, Math.min(actor.looks.length - 1, Number(actor.costume) || 0));
    if (actor.looks[rootIndex]) chosen = { where:'root', folderIdx:null, idx:rootIndex, src:String(actor.looks[rootIndex]) };
  }
  if (!chosen) chosen = entries[0] || null;
  if (!actor.pixelArtLooks || typeof actor.pixelArtLooks !== 'object') actor.pixelArtLooks = {};
  if (!actor.pixelArtAutoLooks || typeof actor.pixelArtAutoLooks !== 'object') actor.pixelArtAutoLooks = {};
  const validKeys = new Set(entries.map(e => appearanceKey(e.src)));
  Object.keys(actor.pixelArtLooks).forEach(k => { if (!validKeys.has(k)) delete actor.pixelArtLooks[k]; });
  Object.keys(actor.pixelArtAutoLooks).forEach(k => { if (!validKeys.has(k)) delete actor.pixelArtAutoLooks[k]; });
  if (chosen) setActorAppearanceActive(actor, chosen.src, chosen.where, chosen.folderIdx, chosen.idx);
  else {
    actor.image = null;
    actor.activeAppearance = null;
    actor.costume = 0;
    actor.pixelArt = false;
  }
  return chosen ? chosen.src : null;
}

function prepareLookImport(mode, folderIdx) {
  const inp = $('input-actor-image');
  if (!inp || !currentActor) { toast('Abra um objeto primeiro'); return; }
  if (mode === 'gif') inp.accept = 'image/gif,.gif';
  else inp.accept = 'image/*,.gif,image/gif';
  window._importMode = mode === 'gif' ? 'gif-look-selected' : 'look-selected';
  window._lookImportFolderIdx = Number.isFinite(Number(folderIdx)) ? Number(folderIdx) : null;
  inp.click();
}

function renderLooks() {
  const list = $('looks-list'); if (!list) return;
  list.innerHTML = '';
  if (!currentActor) return;

  // Multi-select toolbar
  lookSelection = lookSelection || new Set();
  const barId = 'looks-multibar';
  let bar = $(barId);
  if (!bar) {
    bar = document.createElement('div');
    bar.id = barId;
    bar.className = 'flex items-center gap-2 px-1 mb-3';
    bar.innerHTML = `
      <button type="button" id="looks-select-toggle" class="text-[12px] text-[#34D399] px-2 py-1 rounded border border-[#3A3A3A]">Selecionar</button>
      <button type="button" id="looks-delete-selected" class="hidden text-[12px] text-[#f87171] px-2 py-1 rounded border border-[#5a2020]">Apagar selecionadas</button>
    `;
    list.parentElement.insertBefore(bar, list);
    bar.querySelector('#looks-select-toggle').onclick = () => {
      window._lookSelectMode = !window._lookSelectMode;
      if (!window._lookSelectMode) lookSelection.clear();
      renderLooks();
    };
    bar.querySelector('#looks-delete-selected').onclick = () => {
      if (!lookSelection.size) { toast('Nenhuma selecionada'); return; }
      askConfirm('Apagar aparências', 'Apagar ' + lookSelection.size + ' aparência(s)?', () => {
      const idxs = Array.from(lookSelection).map(Number).sort((a,b)=>b-a);
      idxs.forEach(i => {
        if (currentActor.looks && currentActor.looks[i] != null) currentActor.looks.splice(i, 1);
      });
      lookSelection.clear();
      window._lookSelectMode = false;
      normalizeActorAppearanceState(currentActor);
      syncActorToProject(); pruneProjectImageHistory(); save(); renderLooks(); renderActors();
      renderImagePicker();
      toast('Aparências apagadas');
      });
    };
  }
  const delBtn = bar.querySelector('#looks-delete-selected');
  if (delBtn) delBtn.classList.toggle('hidden', !window._lookSelectMode);
  bar.querySelector('#looks-select-toggle').textContent = window._lookSelectMode ? 'Cancelar' : 'Selecionar';

  if (!currentActor.folders) currentActor.folders = [];
  if (!Array.isArray(currentActor.looks)) currentActor.looks = [];
  const empty = $('looks-empty');
  const hasContent = currentActor.looks.length || currentActor.folders.length;
  const importBtn = $('btn-import-look');
  if (importBtn) importBtn.classList.toggle('hidden', !!hasContent);
  if (!hasContent) { if (empty) empty.style.display = ''; return; }
  if (empty) empty.style.display = 'none';

  currentActor.folders.forEach((folder, fi) => {
    const wrap = document.createElement('div');
    wrap.className = 'look-folder';
    const open = folder.open !== false;
    wrap.innerHTML = `
      <div class="look-folder-header">
        <span style="display:inline-flex">${open
          ? '<svg width="16" height="16" fill="none" stroke="#ccc" stroke-width="1.8"><path d="M3 8v8a1 1 0 001 1h12a1 1 0 001-1V9a1 1 0 00-1-1h-6l-2-2H4a1 1 0 00-1 1v1z"/></svg>'
          : '<svg width="16" height="16" fill="none" stroke="#ccc" stroke-width="1.8"><path d="M3 7v10a1 1 0 001 1h12a1 1 0 001-1V9a1 1 0 00-1-1h-6l-2-2H4a1 1 0 00-1 1z"/></svg>'}</span>
        <span class="folder-name">${folder.name || 'Pasta'}</span>
        <button type="button" class="folder-rename text-[#888] text-xs px-1">Renomear</button>
        <button type="button" class="folder-del text-[#888] text-xs px-1">×</button>
      </div>
      <div class="look-folder-grid" style="display:${open ? 'grid' : 'none'}"></div>`;
    const header = wrap.querySelector('.look-folder-header');
    const grid = wrap.querySelector('.look-folder-grid');
    header.onclick = (e) => {
      if (e.target.closest('.folder-rename') || e.target.closest('.folder-del')) return;
      folder.open = !open;
      save(); renderLooks();
    };
    wrap.querySelector('.folder-rename').onclick = (e) => {
      e.stopPropagation();
      askText('Renomear pasta', 'Novo nome da pasta:', folder.name, n => { if (n) { folder.name = n; save(); renderLooks(); } });
    };
    wrap.querySelector('.folder-del').onclick = (e) => {
      e.stopPropagation();
      askConfirm('Excluir pasta', 'Excluir pasta? As imagens voltam para fora.', () => {
      const moved = Array.isArray(folder.looks) ? folder.looks.slice() : [];
      moved.forEach(s => currentActor.looks.push(s));
      currentActor.folders.splice(fi, 1);
      normalizeActorAppearanceState(currentActor, currentActor.image);
      syncActorToProject();
      pruneProjectImageHistory();
      save(); renderLooks(); renderActors(); renderImagePicker();
      });
    };
    (folder.looks || []).forEach((src, li) => {
      grid.appendChild(makeLookItem(src, 'folder', fi, li));
    });
    const addIn = document.createElement('div');
    addIn.className = 'look-item flex items-center justify-center text-[#555] text-[11px] border border-dashed border-[#444]';
    addIn.textContent = '+ aqui';
    addIn.onclick = () => {
      const inp = $('input-actor-image');
      if (!inp || !currentActor) return;
      inp.accept = 'image/*,.gif,image/gif';
      window._importMode = 'look-folder';
      window._folderIdx = fi;
      inp.click();
    };
    grid.appendChild(addIn);
    list.appendChild(wrap);
  });

  currentActor.looks.forEach((src, i) => {
    list.appendChild(makeLookItem(src, 'root', null, i));
  });
  // Multi-select mode UI
  try {
    if (window._lookSelectMode) {
      list.querySelectorAll('[data-look-idx]').forEach(row => {
        const li = Number(row.dataset.lookIdx);
        let cb = row.querySelector('.look-check');
        if (!cb) {
          cb = document.createElement('input');
          cb.type = 'checkbox';
          cb.className = 'look-check';
          cb.style.cssText = 'position:absolute;top:4px;left:4px;z-index:5;width:18px;height:18px;';
          row.style.position = 'relative';
          row.insertBefore(cb, row.firstChild);
        }
        cb.checked = lookSelection.has(li);
        cb.onclick = (e) => e.stopPropagation();
        cb.onchange = () => {
          if (cb.checked) lookSelection.add(li);
          else lookSelection.delete(li);
          const db = document.getElementById('looks-delete-selected');
          if (db) db.classList.toggle('hidden', lookSelection.size === 0);
        };
        row.addEventListener('click', (e) => {
          if (e.target.classList.contains('look-menu')) return;
          cb.checked = !cb.checked;
          cb.onchange();
        });
      });
    }
  } catch (_) {}
}

function makeLookItem(src, where, folderIdx, idx) {
  const d = document.createElement('div');
  d.className = 'look-item';
  if (where === 'root') d.dataset.lookIdx = String(idx);

  if (src) {
    d.innerHTML = `<img alt="" draggable="false"><span class="look-edit-badge" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg></span><button type="button" class="look-menu">${kixSvgIcon('more',18)}</button>`;
    kixApplyThumb(d.querySelector('img'), src, 220);
  } else {
    d.innerHTML = `<div class="w-full h-full flex items-center justify-center text-[#555] text-xs">vazio</div><button type="button" class="look-menu">${kixSvgIcon('more',18)}</button>`;
  }
  d.querySelector('.look-menu').onclick = (e) => {
    e.stopPropagation();
    openLookItemMenu(where, folderIdx, idx);
  };
  // Tocar numa aparência abre o Kix Paint com ela carregada (modo desenho).
  // "Usar como ativa", renomear, apagar etc. continuam no menu ⋮.
  d.onclick = (e) => {
    if (e.target.closest('.look-menu')) return;
    if (window._lookSelectMode) return; // modo seleção múltipla: o toque só marca/desmarca
    if (currentActor) kixEditLookInPaint(src, where, folderIdx, idx);
  };
  return d;
}

function kixEditLookInPaint(src, where, folderIdx, idx) {
  const actor = currentActor;
  if (!actor || !window.KixPaint) { toast('Editor de desenho indisponível'); return; }
  const getList = () => where === 'folder' ? actor.folders?.[folderIdx]?.looks : actor.looks;
  window.KixPaint.open({
    mode: 'look-edit',
    baseImage: src || undefined,
    onSave: (dataUrl, frames) => {
      const list = getList();
      if (!list || idx >= list.length) { toast('Aparência não encontrada'); return; }
      const wasActive = !!src && actor.image === src;
      const oldKey = src ? appearanceKey(src) : null;
      list[idx] = dataUrl;
      // Quadros extras criados no Paint viram aparências logo depois desta (animação).
      if (frames && frames.length > 1) {
        frames.slice(1).forEach((f, k) => list.splice(idx + 1 + k, 0, f.src));
        actor.frameDurations = actor.frameDurations || {};
        frames.forEach((f, i) => { actor.frameDurations[list[idx + i]] = f.ms; });
      }
      // Mantém a marca de Pixel Art da imagem antiga.
      if (oldKey && actor.pixelArtLooks && Object.prototype.hasOwnProperty.call(actor.pixelArtLooks, oldKey)) {
        actor.pixelArtLooks[appearanceKey(dataUrl)] = actor.pixelArtLooks[oldKey];
      }
      normalizeActorAppearanceState(actor, wasActive ? dataUrl : actor.image);
      syncActorToProject(); save(); renderLooks(); renderActors();
      toast(frames && frames.length > 1 ? 'Animação salva' : 'Aparência salva');
    }
  });
}

function openLookItemMenu(where, folderIdx, idx) {
  if (!currentActor) return;
  window._lookMenu = { where, folderIdx, idx };
  const title = $('look-opt-title');
  if (title) title.textContent = 'Aparência ' + (idx + 1);
  const src = where === 'root' ? currentActor.looks?.[idx] : currentActor.folders?.[folderIdx]?.looks?.[idx];
  const pixelBtn = document.querySelector('#sheet-look-options .sheet-item[data-action="look-pixel-art"]');
  if (pixelBtn) pixelBtn.querySelector('span').textContent = appearancePixelArtEnabled(currentActor, src) ? 'Desativar Pixel Art' : 'Definir como Pixel Art';
  const toRoot = document.querySelector('#sheet-look-options .sheet-item[data-action="look-to-root"]');
  if (toRoot) toRoot.style.display = where === 'folder' ? '' : 'none';
  const moveFolder = document.querySelector('#sheet-look-options .sheet-item[data-action="look-move-folder"]');
  if (moveFolder) moveFolder.style.display = (where === 'root' && (currentActor.folders || []).length) ? '' : 'none';
  openSheet('sheet-look-options');
}

function applyLookOption(act) {
  if (!currentActor || !window._lookMenu) return;
  const { where, folderIdx, idx } = window._lookMenu;
  const getSrc = () => {
    if (where === 'root') return currentActor.looks[idx];
    return currentActor.folders[folderIdx]?.looks?.[idx];
  };
  if (act === 'look-set-active') {
    const src = getSrc();
    if (src) {
      setActorAppearanceActive(currentActor, src, where, folderIdx, idx);
      syncActorToProject(); save(); renderLooks(); renderActors(); toast('Ativa');
    }
  } else if (act === 'look-pixel-art') {
    const src = getSrc();
    if (src) {
      if (!currentActor.pixelArtLooks || typeof currentActor.pixelArtLooks !== 'object') currentActor.pixelArtLooks = {};
      const key = appearanceKey(src);
      currentActor.pixelArtLooks[key] = !appearancePixelArtEnabled(currentActor, src);
      currentActor.pixelArt = !!currentActor.pixelArtLooks[key];
      if (currentActor.image === src) currentActor.pixelArt = !!currentActor.pixelArtLooks[key];
      setActorAppearanceActive(currentActor, src, where, folderIdx, idx);
      syncActorToProject(); save(); renderLooks(); renderActors();
      toast(currentActor.pixelArtLooks[key] ? 'Pixel Art ativado' : 'Pixel Art desativado');
    }
  } else if (act === 'look-new-folder') {
    closeSheets();
    createLookFolder();
    return;
  } else if (act === 'look-import-gif') {
    closeSheets();
    prepareLookImport('gif', where === 'folder' ? folderIdx : null);
    return;
  } else if (act === 'look-rename') {
    // rename stored as sidecar if object looks are plain strings - use parallel names array
    if (!currentActor.lookNames) currentActor.lookNames = {};
    const key = where + ':' + (folderIdx ?? 'r') + ':' + idx;
    askText('Renomear aparência', 'Novo nome da aparência:', currentActor.lookNames[key] || ('Aparência ' + (idx + 1)), n => { if (n) { currentActor.lookNames[key] = n; save(); toast('Renomeado'); } });
  } else if (act === 'look-delete') {
    askConfirm('Apagar aparência', 'Apagar esta aparência?', () => {
    if (where === 'root') {
      currentActor.looks.splice(idx, 1);
    } else if (currentActor.folders[folderIdx]) {
      currentActor.folders[folderIdx].looks.splice(idx, 1);
    }
    normalizeActorAppearanceState(currentActor);
    syncActorToProject(); pruneProjectImageHistory(); save(); renderLooks(); renderActors(); renderImagePicker(); toast('Apagada');
    });
  } else if (act === 'look-move-folder') {
    if (!currentActor.folders.length) { toast('Crie uma pasta primeiro'); return; }
    const names = currentActor.folders.map((f, i) => (i + 1) + '. ' + f.name).join('\n');
    askChoice('Mover aparência', 'Escolha a pasta de destino.\n' + names, currentActor.folders.map((f,i)=>({label:f.name, action:()=>{
      let src;
      if (where === 'root') src = currentActor.looks.splice(idx, 1)[0];
      else src = currentActor.folders[folderIdx].looks.splice(idx, 1)[0];
      if (!currentActor.folders[i].looks) currentActor.folders[i].looks = [];
      const newIdx = currentActor.folders[i].looks.push(src) - 1;
      if (currentActor.image === src) setActorAppearanceActive(currentActor, src, 'folder', i, newIdx);
      normalizeActorAppearanceState(currentActor, currentActor.image);
      syncActorToProject(); save(); renderLooks(); renderActors(); toast('Movida');
    }})));
    return;
  } else if (act === 'look-to-root' && where === 'folder') {
    const src = currentActor.folders[folderIdx].looks.splice(idx, 1)[0];
    const rootIdx = currentActor.looks.push(src) - 1;
    if (currentActor.image === src) setActorAppearanceActive(currentActor, src, 'root', null, rootIdx);
    normalizeActorAppearanceState(currentActor, currentActor.image);
    syncActorToProject(); save(); renderLooks(); renderActors(); toast('Para fora da pasta');
  }
  closeSheets();
}


function openCollisionEditor() {
  try {
    if (!currentActor) { toast('Abra um objeto'); return; }
    if (currentActor.isCamera) { toast('Câmera não usa colisão'); return; }

    const old = currentActor.collisionShape || {};
    const cs = Object.assign({
      type: 'rect', width: 48, height: 48, offsetX: 0, offsetY: 0,
      radius: 24, enabled: true, debug: true
    }, old);

    currentActor.collisionShape = cs;
    window._colShape = ['rect','circle','pixel'].includes(cs.type) ? cs.type : 'rect';

    // The screen is created lazily so old projects remain compatible.
    ensureCollisionScreen();

    const setShapeUI = (type) => {
      window._colShape = type;
      document.querySelectorAll('.col-shape').forEach(b => {
        const on = b.dataset.shape === type;
        b.classList.toggle('border-[#059669]', on);
        b.classList.toggle('text-[#34D399]', on);
        b.classList.toggle('bg-[#059669]/15', on);
      });
      const rf = $('collision-rect-fields');
      const cf = $('collision-circle-fields');
      const pf = $('collision-pixel-hint');
      if (rf) rf.classList.toggle('hidden', type !== 'rect');
      if (cf) cf.classList.toggle('hidden', type !== 'circle');
      if (pf) pf.classList.toggle('hidden', type !== 'pixel');
      updateCollisionPreview();
    };

    if ($('col-w')) $('col-w').value = cs.width;
    if ($('col-h')) $('col-h').value = cs.height;
    if ($('col-ox')) $('col-ox').value = cs.offsetX;
    if ($('col-oy')) $('col-oy').value = cs.offsetY;
    if ($('col-r')) $('col-r').value = cs.radius;
    if ($('col-cox')) $('col-cox').value = cs.offsetX || 0;
    if ($('col-coy')) $('col-coy').value = cs.offsetY || 0;
    if ($('col-enabled')) $('col-enabled').checked = cs.enabled !== false;
    if ($('col-debug')) $('col-debug').checked = cs.debug !== false;

    document.querySelectorAll('.col-shape').forEach(b => {
      b.onclick = () => setShapeUI(b.dataset.shape);
    });
    ['col-w','col-h','col-ox','col-oy','col-r','col-cox','col-coy'].forEach(id => {
      const el = $(id);
      if (el) el.oninput = updateCollisionPreview;
    });

    setShapeUI(window._colShape);
    show('collision', { noPush: false });
    requestAnimationFrame(() => { updateCollisionPreview(); });
  } catch (e) {
    console.error('openCollisionEditor', e);
    toast('Erro ao abrir colisão');
  }
}

function ensureCollisionScreen() {
  if ($('screen-collision')) return;
  const el = document.createElement('div');
  el.id = 'screen-collision';
  el.className = 'fixed inset-0 z-[100] hidden bg-[#1F1F1F] text-white';
  el.innerHTML = `
    <div class="h-full flex flex-col bg-[#1F1F1F]">
      <div class="h-14 shrink-0 flex items-center border-b border-[#3A3A3A] px-4">
        <button id="collision-back" class="text-[#aaa] text-sm mr-4">Voltar</button>
        <span class="text-[15px]">Colisão</span>
        <button id="collision-save" class="ml-auto text-[#34D399] text-sm">Salvar</button>
      </div>
      <div class="flex-1 overflow-y-auto p-4">
        <div id="collision-preview" class="relative mx-auto mb-5 w-[180px] h-[180px] bg-[#252525] border border-[#3A3A3A] rounded-xl flex items-center justify-center overflow-hidden"></div>
        <div class="grid grid-cols-3 gap-2 mb-4">
          <button type="button" class="col-shape border border-[#3A3A3A] rounded-lg py-2 text-xs" data-shape="rect">Retângulo</button>
          <button type="button" class="col-shape border border-[#3A3A3A] rounded-lg py-2 text-xs" data-shape="circle">Círculo</button>
          <button type="button" class="col-shape border border-[#3A3A3A] rounded-lg py-2 text-xs" data-shape="pixel">Sprite</button>
        </div>
        <div id="collision-rect-fields" class="grid grid-cols-2 gap-3">
          <label class="text-xs text-[#888]">Largura<input id="col-w" type="number" min="1" class="w-full mt-1 p-2 bg-[#292929] border border-[#3A3A3A] rounded text-white"></label>
          <label class="text-xs text-[#888]">Altura<input id="col-h" type="number" min="1" class="w-full mt-1 p-2 bg-[#292929] border border-[#3A3A3A] rounded text-white"></label>
          <label class="text-xs text-[#888]">Offset X<input id="col-ox" type="number" class="w-full mt-1 p-2 bg-[#292929] border border-[#3A3A3A] rounded text-white"></label>
          <label class="text-xs text-[#888]">Offset Y<input id="col-oy" type="number" class="w-full mt-1 p-2 bg-[#292929] border border-[#3A3A3A] rounded text-white"></label>
        </div>
        <div id="collision-circle-fields" class="hidden grid grid-cols-2 gap-3">
          <label class="text-xs text-[#888]">Raio<input id="col-r" type="number" min="1" class="w-full mt-1 p-2 bg-[#292929] border border-[#3A3A3A] rounded text-white"></label>
          <label class="text-xs text-[#888]">Offset X<input id="col-cox" type="number" class="w-full mt-1 p-2 bg-[#292929] border border-[#3A3A3A] rounded text-white"></label>
          <label class="text-xs text-[#888]">Offset Y<input id="col-coy" type="number" class="w-full mt-1 p-2 bg-[#292929] border border-[#3A3A3A] rounded text-white"></label>
        </div>
        <div id="collision-pixel-hint" class="hidden text-xs text-[#888] p-3 bg-[#252525] rounded-lg mt-3">Usa os limites do sprite. O formato continua compatível com projetos antigos.</div>
        <label class="flex items-center gap-2 mt-5 text-sm"><input id="col-enabled" type="checkbox"> Colisão ativa</label>
        <label class="flex items-center gap-2 mt-3 text-sm"><input id="col-debug" type="checkbox"> Mostrar depuração durante o teste</label>
        <p class="text-xs text-[#666] mt-4">A colisão é aplicada no espaço do projeto e acompanha tamanho, posição e câmera automaticamente.</p>
      </div>
    </div>`;
  document.body.appendChild(el);
  $('collision-back').onclick = () => navBack();
  $('collision-save').onclick = saveCollisionEditor;
}

function updateCollisionPreview() {
  try {
    const prev = $('collision-preview');
    if (!prev) return;
    const type = window._colShape || 'rect';
    const ox = Number(($('col-ox') && $('col-ox').value) || 0);
    const oy = Number(($('col-oy') && $('col-oy').value) || 0);
    const esc = v => String(v == null ? '' : v).replace(/"/g, '&quot;');
    const imgSrc = currentActor && currentActor.image ? esc(currentActor.image) : '';
    const thumb = imgSrc
      ? `<img src="${imgSrc}" style="max-width:75%;max-height:75%;opacity:.38;position:absolute;inset:0;margin:auto;object-fit:contain;">`
      : '';
    let shape = '';
    if (type === 'circle') {
      const r = Math.max(2, Math.min(75, Number(($('col-r') && $('col-r').value) || 24)));
      shape = `<div style="width:${r*2}px;height:${r*2}px;border:2px solid #34D399;border-radius:50%;transform:translate(${ox}px,${oy}px);position:relative;z-index:1"></div>`;
    } else if (type === 'pixel') {
      shape = `<div style="width:70%;height:70%;border:2px dashed #34D399;position:relative;z-index:1;transform:translate(${ox}px,${oy}px)"></div>`;
    } else {
      const w = Math.max(2, Math.min(150, Number(($('col-w') && $('col-w').value) || 48)));
      const h = Math.max(2, Math.min(150, Number(($('col-h') && $('col-h').value) || 48)));
      shape = `<div style="width:${w}px;height:${h}px;border:2px solid #34D399;position:relative;z-index:1;transform:translate(${ox}px,${oy}px)"></div>`;
    }
    prev.innerHTML = thumb + shape;
  } catch (e) { console.warn('collision preview', e); }
}

function saveCollisionEditor() {
  try {
    if (!currentActor) return;
    const type = window._colShape || 'rect';
    const cs = { type: type, enabled: $('col-enabled') ? $('col-enabled').checked : true, debug: $('col-debug') ? $('col-debug').checked : true };
    if (type === 'rect') {
      cs.width = Number(($('col-w') && $('col-w').value) || 48);
      cs.height = Number(($('col-h') && $('col-h').value) || 48);
      cs.offsetX = Number(($('col-ox') && $('col-ox').value) || 0);
      cs.offsetY = Number(($('col-oy') && $('col-oy').value) || 0);
    } else if (type === 'circle') {
      cs.radius = Number(($('col-r') && $('col-r').value) || 24);
      cs.offsetX = Number(($('col-cox') && $('col-cox').value) || 0);
      cs.offsetY = Number(($('col-coy') && $('col-coy').value) || 0);
    }
    currentActor.collisionShape = cs;
    currentActor._collisionVersion = (Number(currentActor._collisionVersion) || 0) + 1;
    try { syncActorToProject(); } catch (_) {}
    try { save(); } catch (_) {}
    try { renderActors(); } catch (_) {}
    toast('Colisão salva');
    navBack();
  } catch (e) {
    console.error(e);
    toast('Erro ao salvar');
  }
}

function createLookFolder() {
  if (!currentActor) return;
  if (!currentActor.folders) currentActor.folders = [];
  let nameResult = null;
  askText('Criar pasta', 'Nome da nova pasta:', 'Pasta ' + (currentActor.folders.length + 1), name => { if (!name) return; currentActor.folders.push({ name, looks: [], open: true }); save(); switchTab('looks'); renderLooks(); toast('Pasta criada'); });
  return;
}
function renderSounds() {
  const list = $('sounds-list'); if (!list) return;
  list.innerHTML = '';
  const empty = $('sounds-empty');
  const sounds = Array.isArray(currentActor?.sounds) ? currentActor.sounds : [];
  if (!sounds.length) { if (empty) empty.style.display = ''; return; }
  if (empty) empty.style.display = 'none';

  // 1.45x the previous row/icon/text geometry (≈45% larger).
  const soundRowScale = 1.45;
  const rowMinHeight = Number((32 * soundRowScale).toFixed(2));
  const iconSize = Number((16 * soundRowScale).toFixed(2));
  const textSize = Number((13 * soundRowScale).toFixed(2));
  const clearPreviewRows = () => list.querySelectorAll('.sound-item').forEach(row => {
    row.dataset.previewing = 'false';
    row.setAttribute('aria-pressed', 'false');
    row.classList.remove('ring-1','ring-[#9B5FD1]/60','bg-[#9B5FD1]/10');
  });

  sounds.forEach((s, i) => {
    const name = String(s?.name || 'Som ' + (i + 1));
    const d = document.createElement('button');
    d.type = 'button';
    d.className = 'sound-item flex items-center gap-3 w-full text-left rounded-lg px-3';
    d.style.minHeight = rowMinHeight + 'px';
    d.style.paddingTop = '8px'; d.style.paddingBottom = '8px'; d.style.cursor = 'pointer';
    d.dataset.soundIndex = String(i); d.dataset.previewing = 'false';
    d.setAttribute('aria-label','Pré-visualizar ' + name); d.setAttribute('aria-pressed','false');
    d.setAttribute('title','Tocar pré-visualização');

    const svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
    svg.setAttribute('width',String(iconSize)); svg.setAttribute('height',String(iconSize)); svg.setAttribute('viewBox','0 0 24 24');
    svg.setAttribute('fill','none'); svg.setAttribute('stroke','currentColor'); svg.setAttribute('stroke-width','1.7');
    svg.setAttribute('stroke-linecap','round'); svg.setAttribute('stroke-linejoin','round'); svg.setAttribute('aria-hidden','true');
    svg.innerHTML = '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>';

    const label = document.createElement('span');
    label.className = 'flex-1 truncate'; label.style.fontSize = textSize + 'px'; label.style.lineHeight = '1.2'; label.textContent = name;
    d.appendChild(svg); d.appendChild(label); list.appendChild(d);

    const setPreviewState = on => {
      d.dataset.previewing = on ? 'true' : 'false'; d.setAttribute('aria-pressed',on?'true':'false');
      d.classList.toggle('ring-1',on); d.classList.toggle('ring-[#9B5FD1]/60',on); d.classList.toggle('bg-[#9B5FD1]/10',on);
      d.setAttribute('aria-label',(on?'Parar pré-visualização de ':'Pré-visualizar ') + name);
    };
    d.addEventListener('click', () => {
      const engine = window.KixEngine;
      if (!engine || typeof engine.previewSound !== 'function') { toast('Pré-visualização de áudio indisponível'); return; }
      clearPreviewRows(); setPreviewState(false);
      try {
        const result = engine.previewSound(s);
        Promise.resolve(result).then(audio => {
          if (!audio) { toast('Não foi possível reproduzir este áudio'); return; }
          setPreviewState(true);
          audio.addEventListener('ended',()=>setPreviewState(false),{once:true});
          audio.addEventListener('error',()=>setPreviewState(false),{once:true});
        }).catch(()=>{ setPreviewState(false); toast('Não foi possível reproduzir este áudio'); });
      } catch (_) { setPreviewState(false); toast('Não foi possível reproduzir este áudio'); }
    });
  });
}
let currentTab = 'scripts';
let previousTab = 'scripts';
// Real sibling-tab history for Android/system Back.
let tabNavStack = [];

function renderTextAnimPanel() { /* moved to Texto blocks */ }

function switchTab(tab, opts = {}) {
  const nextTab = String(tab || 'scripts');
  const record = opts.record !== false;
  if (record && currentTab && currentTab !== nextTab) {
    previousTab = currentTab;
    tabNavStack.push(currentTab);
    if (tabNavStack.length > 20) tabNavStack.shift();
  }
  currentTab = nextTab;
  
  activeScriptTab = tab || 'scripts';
  document.querySelectorAll('.tab-btn').forEach(b => {
    const on = b.dataset.tab === tab;
    b.classList.toggle('kix-tab-active', on);
    b.classList.toggle('text-[#34D399]', on);
    b.classList.toggle('border-[#059669]', on);
    b.classList.toggle('text-[#888]', !on);
    b.classList.toggle('border-transparent', !on);
  });
  ['scripts','looks','sounds'].forEach(t => {
    const el = $(t + '-area');
    if (el) el.classList.toggle('hidden', t !== tab);
  });
}

// ===== CATEGORIES =====
let kixCategoryPage = 0;
let kixCategoryPagerBound = false;
let kixCategorySwipe = null;


function kixCategoryPluginOrder(pluginKeys, cats) {
  const order = new Map();
  pluginKeys.forEach((key, index) => {
    const cat = cats[key] || {};
    const id = String(cat.pluginId || key.split(':')[1] || key);
    const current = order.get(id);
    const numeric = Number(cat.order);
    const firstOrder = Number.isFinite(numeric) ? numeric : index;
    if (!current || firstOrder < current.order) order.set(id, {order:firstOrder, firstSeen:index, name:String(cat.pluginName || id)});
  });
  return Array.from(order.entries()).sort((a,b) =>
    a[1].order - b[1].order || a[1].firstSeen - b[1].firstSeen || a[1].name.localeCompare(b[1].name)
  ).map(([id]) => id);
}

function kixRenderCategoryGrid(container, keys, cats, style, pluginSection) {
  const grid = document.createElement('div');
  grid.className = 'cat-list cat-' + (style === 'classic' ? 'classic' : 'centralizado');
  keys.forEach(key => {
    const cat = cats[key];
    if (!cat || !cat.name) return;
    const card = document.createElement('div');
    card.className = 'cat-card' + (pluginSection ? ' kix-plugin-category-card' : '');
    card.style.background = cat.color || '#666';
    card.dataset.categoryKey = key;
    // Plugin categories use the same clean category card as native categories:
    // only the category name is shown. The plugin identity is communicated once
    // by the centered plugin title above the group.
    card.textContent = kixCategoryName(key, cat.name);
    card.onclick = () => openCategory(key);
    grid.appendChild(card);
  });
  container.appendChild(grid);
}

function kixRenderPluginGroup(container, pluginId, pluginKeys, cats, style) {
  const first = cats[pluginKeys[0]] || {};
  const title = document.createElement('div');
  title.className = 'kix-category-plugin-title';
  const p = window.KixPluginRuntime?.get?.(pluginId) || null;
  const name = document.createElement('div');
  name.className = 'kix-category-plugin-name';
  name.textContent = String(first.pluginName || p?.name || pluginId);
  title.appendChild(name);
  container.appendChild(title);
  kixRenderCategoryGrid(container, pluginKeys, cats, style, true);
}

function kixApplyCategoryPage(page, animate = true) {
  kixCategoryPage = Math.max(0, Math.min(1, Number(page) || 0));
  const list = $('categories-list');
  const track = list?.querySelector('.kix-category-pages');
  if (!track) return;
  track.style.transition = animate ? 'transform .22s cubic-bezier(.22,.8,.28,1)' : 'none';
  track.style.transform = 'translate3d(' + (kixCategoryPage ? '-50%' : '0%') + ',0,0)';
  list.setAttribute('aria-label', kixCategoryPage === 0 ? 'Categorias nativas do Kix' : 'Categorias dos plugins');
}

function kixChangeCategoryPage(delta) {
  const next = Math.max(0, Math.min(1, kixCategoryPage + Number(delta || 0)));
  if (next === kixCategoryPage) return false;
  kixApplyCategoryPage(next, true);
  return true;
}

function bindKixCategoryPager() {
  if (kixCategoryPagerBound) return;
  const viewport = $('categories-list');
  if (!viewport) return;
  kixCategoryPagerBound = true;
  kixCategorySwipe = null;

  viewport.addEventListener('touchstart', e => {
    if (!e.touches?.length) return;
    const t = e.touches[0];
    kixCategorySwipe = {x:t.clientX, y:t.clientY, active:false};
  }, {passive:true});

  viewport.addEventListener('touchmove', e => {
    const s = kixCategorySwipe;
    if (!s || s.active || !e.touches?.length) return;
    const t = e.touches[0];
    const dx = t.clientX - s.x;
    const dy = t.clientY - s.y;
    if (Math.abs(dx) < 18) return;
    if (Math.abs(dx) <= Math.abs(dy) * 1.2) { kixCategorySwipe = null; return; }
    s.active = true;
    if (e.cancelable) e.preventDefault();
  }, {passive:false});

  viewport.addEventListener('touchend', e => {
    const s = kixCategorySwipe;
    kixCategorySwipe = null;
    if (!s || !s.active || !e.changedTouches?.length) return;
    const t = e.changedTouches[0];
    const dx = t.clientX - s.x;
    if (Math.abs(dx) < 48) return;
    // Kix category pager: drag left = next page, drag right = previous page.
    if (dx < 0) kixChangeCategoryPage(1);
    else kixChangeCategoryPage(-1);
  }, {passive:true});

  viewport.addEventListener('touchcancel', () => { kixCategorySwipe = null; }, {passive:true});
}

function buildCategories(options) {
  try {
    const list = $('categories-list');
    if (!list) { console.warn('categories-list missing'); return; }
    const opts = options || {};
    if (!opts.preservePage) kixCategoryPage = 0;
    list.innerHTML = '';
    const style = (typeof catStyle !== 'undefined' && catStyle) ? catStyle : 'classic';
    const cats = CATEGORIES || {};
    const preferredOrder = [
      'evento','controle','movimento','aparencias','dados','somplus',
      'telefone','desenhos','ia','shaders','fastui','texto','presets',
      'cameraplus','multiplayer','animavancada','economia',
      'database','seguranca','levels','layers','debug','tilemap'
    ];
    const keys = Object.keys(cats);
    const preferred = preferredOrder.filter(k => cats[k]);
    const restNative = keys.filter(k => !k.startsWith('plugin:') && !preferredOrder.includes(k));
    const nativeKeys = preferred.concat(restNative);
    const pluginKeys = keys.filter(k => k.startsWith('plugin:'));
    const pluginGroups = new Map();
    pluginKeys.forEach(key => {
      const cat = cats[key];
      if (!cat) return;
      const pluginId = String(cat.pluginId || key.split(':')[1] || key);
      if (!pluginGroups.has(pluginId)) pluginGroups.set(pluginId, []);
      pluginGroups.get(pluginId).push(key);
    });
    pluginGroups.forEach(keysForPlugin => keysForPlugin.sort((a,b) => {
      const ao = Number(cats[a]?.order ?? 0), bo = Number(cats[b]?.order ?? 0);
      return ao - bo || String(cats[a]?.name || a).localeCompare(String(cats[b]?.name || b));
    }));
    const orderedPluginIds = kixCategoryPluginOrder(pluginKeys, cats);

    const track = document.createElement('div');
    track.className = 'kix-category-pages';
    const nativePage = document.createElement('div');
    nativePage.className = 'kix-category-page';
    nativePage.dataset.categoryPage = 'native';
    kixRenderCategoryGrid(nativePage, nativeKeys, cats, style, false);
    if (!nativeKeys.length) {
      const empty = document.createElement('div'); empty.className = 'kix-category-empty';
      empty.textContent = 'Nenhuma categoria nativa disponível.'; nativePage.appendChild(empty);
    }

    const pluginPage = document.createElement('div');
    pluginPage.className = 'kix-category-page';
    pluginPage.dataset.categoryPage = 'plugins';
    const pluginPageLabel = document.createElement('div');
    pluginPageLabel.className = 'kix-category-plugin-page-label';
    pluginPageLabel.textContent = 'Kix Plugins';
    pluginPage.appendChild(pluginPageLabel);
    if (orderedPluginIds.length) {
      orderedPluginIds.forEach(pluginId => {
        const groupKeys = pluginGroups.get(pluginId) || [];
        if (groupKeys.length) kixRenderPluginGroup(pluginPage, pluginId, groupKeys, cats, style);
      });
    } else {
      const empty = document.createElement('div'); empty.className = 'kix-category-empty';
      empty.textContent = 'Nenhum plugin ativo adicionando categorias. Importe ou ative um Kix Plugin nas Configurações.';
      pluginPage.appendChild(empty);
    }

    track.append(nativePage, pluginPage);
    list.appendChild(track);
    bindKixCategoryPager();
    kixApplyCategoryPage(opts.preservePage ? kixCategoryPage : 0, false);
    if (!nativeKeys.length && !orderedPluginIds.length) toast('Nenhuma categoria');
  } catch (e) {
    console.error('buildCategories', e);
    toast('Erro categorias: ' + e.message);
  }
}

function setCatStyle(style) {
  try {
    catStyle = style || 'classic';
    localStorage.setItem('kix_cat_style', catStyle);
    updateCatStyleButtons();
    if ($('screen-categories') && !$('screen-categories').classList.contains('hidden')) buildCategories();
    toast(catStyle === 'classic' ? 'Estilo clássico' : 'Estilo centralizado');
  } catch (e) { console.error('setCatStyle', e); }
}
function updateCatStyleButtons() {
  try {
    const c = $('style-classic');
    const z = $('style-centralizado');
    if (!c || !z) return;
    const isClassic = (typeof catStyle !== 'undefined' ? catStyle : 'classic') === 'classic';
    c.className = isClassic
      ? 'flex-1 py-2 rounded text-[12px] font-normal border border-[#059669] text-[#34D399] bg-[#059669]/15'
      : 'flex-1 py-2 rounded text-[12px] font-normal border border-[#3A3A3A] text-[#aaa]';
    z.className = !isClassic
      ? 'flex-1 py-2 rounded text-[12px] font-normal border border-[#059669] text-[#34D399] bg-[#059669]/15'
      : 'flex-1 py-2 rounded text-[12px] font-normal border border-[#3A3A3A] text-[#aaa]';
  } catch (e) { console.warn('updateCatStyleButtons', e); }
}
const HIDDEN_CATALOG_BLOCKS = new Set([
  'Transição fade para [cena] em [segundos]', 'Camadas de Colisão', 'Mudar efeito gráfico em', 'Definir efeito', 'Definir quadro', 'Próximo quadro', 'Definir velocidade da animação',
  'Mudar transparência em', 'Definir transparência para', 'Limpar efeitos gráficos', 'Fade in', 'Fade out',
  'Trocar cor', 'Espelhar horizontal', 'Espelhar vertical', 'Piscar X vezes',
  'Reproduzir animação da pasta', 'Repetir animação da pasta', 'Repetir animação da pasta em loop',
  'Aplicar animação em loop na pasta', 'Parar animação da pasta', 'Tocar pasta uma vez e parar na última aparência',
  'Tocar pasta uma vez e voltar pra aparência original', 'Tocar pasta em loop na velocidade', 'Tocar pasta uma vez na velocidade',
  'Inverter ordem da pasta', 'Inverter ordem da pasta ao tocar',
  'câmera no jogador', 'reset completo da câmera', 'zoom de impacto', 'seguir com suavidade', 'bounds do palco'
]);

function returnFromCategoryPicker() {
  try {
    const ctx = window._blockPickerContext || window._scriptActorContext;
    if (ctx && currentProject && (!ctx.projectId || String(ctx.projectId) === String(ensureProjectIdentity(currentProject))) && Number(ctx.scene) === Number(currentScene)) {
      const actors = getSceneActors();
      const found = resolveActorHint(ctx, actors);
      if (found) {
        currentActor = found;
        currentActorIdx = actors.indexOf(found);
      }
    }
    restoreCurrentActorContext();
    try { switchTab(activeScriptTab || 'scripts'); } catch (_) {}
    if (!currentActor) {
      toast('Objeto anterior não está mais disponível');
      navBack();
      return;
    }
    navJumpTo('scripts');
    try { renderScripts(); renderLooks(); renderSounds(); } catch (_) {}
  } catch (e) {
    console.warn('returnFromCategoryPicker', e);
    navJumpTo('scripts');
  }
}

function kixCollectSearchBlocks() {
  const out = [];
  const seen = new Set();
  for (const [key, cat] of Object.entries(CATEGORIES || {})) {
    if (!cat || !Array.isArray(cat.blocks)) continue;
    for (const blk of cat.blocks) {
      const pluginDef = (blk && typeof blk === 'object' && blk.pluginId) ? blk : null;
      const name = typeof blk === 'string' ? blk : String(pluginDef ? pluginDef.name : (blk?.n || ''));
      if (!name || HIDDEN_CATALOG_BLOCKS.has(name)) continue;
      if (blk && typeof blk === 'object' && KIX_CATROBAT_PALETTE_HIDDEN_IDS.has(blk.compatId)) continue;
      const dedupe = String(pluginDef?.pluginId || '') + '|' + String(pluginDef?.id || '') + '|' + name + '|' + String(key);
      if (seen.has(dedupe)) continue;
      seen.add(dedupe);
      const params = typeof blk === 'string' ? [] : (pluginDef ? (pluginDef.params || []) : (blk.p || []));
      const color = pluginDef?.useCategoryColor === false ? (pluginDef.color || cat.color) : cat.color;
      out.push({ key, category: kixCategoryName(key, cat.name), cat, blk, name, params, pluginDef, color });
    }
  }
  return out;
}

function closeKixBlockSearch() {
  const overlay = $('kix-block-search-overlay');
  if (!overlay) return;
  overlay.classList.add('hidden');
  overlay.setAttribute('aria-hidden', 'true');
  const input = $('kix-block-search-input');
  if (input) input.value = '';
}

function openKixBlockSearch() {
  const overlay = $('kix-block-search-overlay');
  const input = $('kix-block-search-input');
  const list = $('kix-block-search-list');
  if (!overlay || !input || !list) return;
  const all = kixCollectSearchBlocks();
  const render = () => {
    const q = String(input.value || '').trim().toLocaleLowerCase('pt-BR');
    const matches = q ? all.filter(item => (item.name + ' ' + item.category).toLocaleLowerCase('pt-BR').includes(q)) : all;
    list.innerHTML = '';
    if (!matches.length) {
      const empty = document.createElement('div');
      empty.className = 'kix-block-search-empty';
      empty.textContent = 'Nenhum bloco encontrado.';
      list.appendChild(empty);
      return;
    }
    let lastCategory = '';
    const frag = document.createDocumentFragment();
    matches.forEach(item => {
      if (!q && item.category !== lastCategory) {
        const section = document.createElement('div');
        section.className = 'kix-block-search-section';
        section.textContent = item.category;
        frag.appendChild(section);
        lastCategory = item.category;
      }
      const row = document.createElement('div');
      row.className = 'pc-block kix-search-block-result kix-block-search-row';
      row.style.background = item.color || '#666';
      row.dataset.name = item.name;
      row.setAttribute('role', 'button');
      row.tabIndex = 0;
      row.innerHTML = buildBlockLabelHtml(item.name, item.params, null, true, item.pluginDef);
      const choose = () => {
        const added = addBlockToScript(item.color || '#666', item.name, item.params, window._blockPickerContext, undefined, undefined, item.pluginDef);
        if (added !== false) toast('Bloco adicionado');
      };
      row.addEventListener('click', choose);
      row.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); choose(); }
      });
      frag.appendChild(row);
    });
    list.appendChild(frag);
  };
  overlay.classList.remove('hidden');
  overlay.setAttribute('aria-hidden', 'false');
  input.oninput = render;
  render();
  setTimeout(() => { try { input.focus({preventScroll:true}); } catch (_) { input.focus(); } }, 60);
}

function openCategory(key) {

  // Keep the exact object being edited while the user browses categories.
  // On mobile, long stays/navigation can temporarily clear currentActor; the
  // category picker must still know where the new block belongs.
  const actorsNow = getSceneActors();
  const categoryCtx = window._blockPickerContext;
  const actorNow = currentActor && actorsNow.includes(currentActor) ? currentActor : null;
  const currentActorId = actorNow ? ensureActorIdentity(actorNow) : '';
  const currentProjectId = currentProject ? ensureProjectIdentity(currentProject) : '';
  const ctxActor = categoryCtx ? resolveActorHint(categoryCtx, actorsNow) : null;
  const ctxStillValid = categoryCtx && categoryCtx.projectId === currentProjectId
    && Number(categoryCtx.scene) === Number(currentScene)
    && !!ctxActor;
  if (!ctxStillValid) {
    window._blockPickerContext = {
      project: currentProject,
      projectId: currentProjectId,
      scene: currentScene,
      actor: actorNow || null,
      actorId: currentActorId,
      actorIdx: actorNow ? actorsNow.indexOf(actorNow) : currentActorIdx,
      actorName: actorNow ? String(actorNow.name || '') : '',
      openedAt: Date.now()
    };
  } else {
    categoryCtx.actor = ctxActor;
    categoryCtx.actorId = ensureActorIdentity(ctxActor);
    categoryCtx.actorIdx = actorsNow.indexOf(ctxActor);
  }

  const resolvedKey = key === 'camera' || key === 'câmera' ? 'cameraplus' : key;
  const cat = CATEGORIES[resolvedKey] || CATEGORIES.camera || CATEGORIES.câmera;
  if (!cat || !Array.isArray(cat.blocks)) { toast('Categoria indisponível'); return; }
  window._kixActiveCategoryKey = resolvedKey;
  document.body.dataset.kixCategory = resolvedKey;
  if ($('blocks-title')) $('blocks-title').textContent = kixCategoryName(resolvedKey, cat.name);
  const list = $('blocks-list'); if (!list) return;
  list.innerHTML = '';
  // Presets keep every existing block/function, but are grouped by family for beginners.
  let lastFamily = null;
  cat.blocks.forEach(blk => {
    const family = (blk && typeof blk === 'object' && blk.family) ? blk.family : null;
    const name = typeof blk === 'string' ? blk : (blk?.pluginId ? blk.name : blk?.n);
    if (HIDDEN_CATALOG_BLOCKS.has(name) || (blk && typeof blk === 'object' && KIX_CATROBAT_PALETTE_HIDDEN_IDS.has(blk.compatId))) return;
    if ((cat.name === 'Presets' || cat.isPlugin) && family && family !== lastFamily) {
      const h = document.createElement('div');
      h.className = 'px-4 pt-4 pb-1 text-[11px] uppercase tracking-wider text-[#858585]';
      h.textContent = family;
      list.appendChild(h);
      lastFamily = family;
    }
    const params = typeof blk === 'string' ? [] : (blk?.pluginId ? (blk.params || []) : (blk.p || []));
    const b = document.createElement('div');
    const isHat = name.startsWith('Quando ') || name.startsWith('Quando') || blk?.type === 'hat';
    const isNote = name.includes('Comentário') || name.includes('Nota') || blk?.type === 'note';
    b.className = 'pc-block' + (isHat ? ' hat' : '') + (isNote ? ' note' : '');
    // Color by action type: note=gray, else category color
    b.style.background = isNote ? '#2B2B2B' : cat.color;
    b.dataset.name = name;
    b.style.setProperty('--kix-delay', Math.min(cat.blocks.indexOf(blk), 12) * 18 + 'ms');
    const pluginDef = (blk && typeof blk === 'object' && blk.pluginId) ? blk : null;
    b.style.background = isNote ? '#2B2B2B' : (pluginDef?.useCategoryColor === false ? (pluginDef.color || cat.color) : cat.color);
    b.innerHTML = buildBlockLabelHtml(name, params, null, true, pluginDef);
    if (pluginDef) { b.dataset.pluginId=String(pluginDef.pluginId); b.dataset.pluginBlockId=String(pluginDef.id); }
    b.onclick = () => {
      addBlockToScript(pluginDef?.useCategoryColor === false ? (pluginDef.color || cat.color) : cat.color, name, params, window._blockPickerContext, undefined, undefined, pluginDef);
    };
    let tipT;
    b.addEventListener('touchstart', e => {
      tipT = setTimeout(() => showBlockTip(name, e.touches[0].clientX, e.touches[0].clientY), 450);
    }, { passive: true });
    b.addEventListener('touchend', () => { clearTimeout(tipT); hideBlockTip(); });
    list.appendChild(b);
  });

  // Palette -> Script uses the SAME BrickDragController as existing-brick reorder.
  // The palette item is only a prototype: the model instance is created on drop.
  if (list._paletteDrag) { try { list._paletteDrag.destroy(); } catch (_) {} }
  if (window.Sortable && list) {
    list._paletteDrag = Sortable.create(list, {
      draggable: '.pc-block',
      filter: 'input',
      delay: 360,
      delayOnTouchOnly: true,
      touchStartThreshold: 8,
      autoScrollEdge: 44,
      autoScrollDelay: 260,
      autoScrollMax: 7,
      scrollRoot: () => $('scripts-area'),
      dropRoot: () => $('script-blocks'),
      onStart: function(evt) {
        evt.palette = true;
        // Keep the existing navigation model; reveal the already-rendered script
        // editor only after the drag actually starts. No model mutation occurs.
        show('scripts', { noPush: true });
      },
      isValidDropTarget: function(target) {
        try {
          const actor = restoreCurrentActorContext();
          const scripts = Array.isArray(actor?.scripts) ? actor.scripts : [];
          const before = kixDropTargetBeforeIndex(target?.beforeNode, scripts);
          const name = String(target?.item?.dataset?.name || target?.item?.querySelector?.('.blk-label')?.textContent || '');
          if (!actor || !name) return false;
          const parent = before == null ? null : kixStructuralParentAt(scripts, before);
          const isEvent = /^Quando\s/i.test(name);
          if (isEvent && parent) return false;
          return true;
        } catch (_) { return false; }
      },
      onEnd: function(evt) {
        const item = evt?.item;
        try {
          const actor = restoreCurrentActorContext();
          if (!actor || !item || evt?.cancelled || evt?.invalid) return;
          const scripts = Array.isArray(actor.scripts) ? actor.scripts : [];
          const beforeIndex = kixDropTargetBeforeIndex(evt?.dropBeforeNode, scripts);
          const name = String(item.dataset?.name || '');
          const catColor = item.style.background || '';
          const params = [];
          // Palette items already carry their semantic parameters in the closure
          // used by their click handler; recover them from the category definition
          // instead of cloning DOM state into the model.
          const catKey = key === 'camera' || key === 'câmera' ? 'cameraplus' : key;
          const catDef = CATEGORIES[catKey] || CATEGORIES.camera || CATEGORIES.câmera;
          const spec = catDef?.blocks?.find(x => (typeof x === 'string' ? x : (x?.n || x?.name)) === name);
          const sourceParams = typeof spec === 'string' ? [] : ((spec?.pluginId ? spec?.params : spec?.p) || []);
          const sourceDef = (spec && typeof spec === 'object' && spec.pluginId) ? spec : null;
          const sourceColor = sourceDef?.useCategoryColor === false ? (sourceDef.color || catDef?.color || catColor) : (catDef?.color || catColor);
          addBlockToScript(sourceColor, name, sourceParams, window._blockPickerContext, beforeIndex, evt?.dropBeforeNode || null, sourceDef);
        } catch (err) {
          console.error('Palette drag commit', err);
          toast('Não foi possível inserir o Brick');
        }
      },
      onCancel: function() {
        // Returning to the palette on cancel keeps the operation reversible and
        // does not alter the project. A successful drop intentionally remains in Scripts.
        show('blocks', { noPush: true });
      }
    });
  }
  show('blocks');
}


// ===== BLOCK CONTEXT MENU (see global handleCtxAction) =====

// ===== PLAY / DEBUG =====

// ===== PROJECT FILES =====
function ensureProjectFiles() {
  if (!currentProject) return [];
  if (!Array.isArray(currentProject.files)) currentProject.files = [];
  return currentProject.files;
}

function openFilesScreen(returnTo) {
  try {
    closeSheets();
    ensureProjectFiles();
    filesReturnScreen = returnTo || 'project';
    renderProjectFiles();
    show('files');
  } catch (e) {
    console.error('openFilesScreen', e);
    toast('Erro ao abrir arquivos');
  }
}

function fileTypeIcon(name) {
  const n = (name || '').toLowerCase();
  if (/\.(ttf|otf|woff2?)$/.test(n)) return 'T';
  if (/\.(gif)$/.test(n)) return 'GIF';
  if (/\.(png|jpe?g|webp|svg)$/.test(n)) return 'Imagem';
  if (/\.(mp3|wav|ogg|m4a)$/.test(n)) return 'Áudio';
  if (/\.(kix)$/.test(n)) return 'KIX';
  if (/\.(json)$/.test(n)) return '{ }';
  if (/\.(glsl|frag|vert)$/.test(n)) return 'Shader';
  return 'Arquivo';
}

function renderProjectFiles() {
  const list = $('files-list');
  const empty = $('files-empty');
  if (!list) return;
  list.innerHTML = '';
  const files = ensureProjectFiles();
  if (!files.length) {
    if (empty) empty.style.display = '';
    return;
  }
  if (empty) empty.style.display = 'none';
  files.forEach((f, i) => {
    const el = document.createElement('div');
    el.className = 'flex items-center gap-3 p-2 rounded bg-[#2C2C2C] mb-2';
    const sizeKb = f.dataUrl ? Math.round((f.dataUrl.length * 0.75) / 1024) : 0;
    el.innerHTML = `
      <div class="w-11 h-11 rounded bg-[#3A3A3A] flex items-center justify-center text-lg flex-shrink-0">${fileTypeIcon(f.name)}</div>
      <div class="flex-1 min-w-0">
        <div class="text-[14px] truncate">${(f.name || 'arquivo').replace(/</g,'')}</div>
        <div class="text-[11px] text-[#666]">${sizeKb} KB · ${f.type || 'file'}</div>
      </div>
      <button type="button" class="file-menu text-[#888] px-2 text-lg">${kixSvgIcon('more',18)}</button>`;
    el.querySelector('.file-menu').onclick = (e) => {
      e.stopPropagation();
      askChoice(f.name || 'Arquivo', 'Escolha uma ação para este arquivo.', [
        {label:'Renomear', action:()=>askText('Renomear arquivo','Novo nome:',f.name,n=>{if(n){f.name=n;save();renderProjectFiles();}})},
        {label:'Copiar nome', action:()=>{try{navigator.clipboard.writeText(f.name);}catch(_){} toast('Nome copiado: '+f.name);}},
        {label:'Excluir', action:()=>askConfirm('Excluir arquivo','Excluir '+f.name+'?',()=>{files.splice(i,1);save();renderProjectFiles();toast('Excluído');})}
      ]);
    };
    list.appendChild(el);
  });
}

function addProjectFileFromInput(fileList) {
  const files = ensureProjectFiles();
  const arr = Array.from(fileList || []);
  if (!arr.length) return;
  let done = 0;
  arr.forEach(file => {
    const reader = new FileReader();
    reader.onload = () => {
      files.push({
        name: file.name,
        type: file.type || 'application/octet-stream',
        dataUrl: reader.result
      });
      // load font if applicable
      if (/\.(ttf|otf|woff2?)$/i.test(file.name)) {
        try {
          const fam = file.name.replace(/\.[^.]+$/, '');
          const face = new FontFace(fam, 'url(' + reader.result + ')');
          face.load().then(ff => { document.fonts.add(ff); }).catch(() => {});
        } catch (_) {}
      }
      done++;
      if (done === arr.length) {
        save();
        renderProjectFiles();
        toast(arr.length + ' arquivo(s) adicionado(s)');
      }
    };
    reader.readAsDataURL(file);
  });
}


function kixChangeScene(target, opts) {
  try {
    if (!currentProject || !currentProject.scenes) return;
    opts = opts || {};
    let idx = currentScene;
    if (typeof target === 'number') idx = target;
    else if (target === 'next') idx = Math.min(currentProject.scenes.length - 1, currentScene + 1);
    else if (target === 'prev') idx = Math.max(0, currentScene - 1);
    else if (target === 'restart') idx = currentScene;
    else {
      const name = String(target || '').replace(/['"]/g, '').toLowerCase();
      const found = currentProject.scenes.findIndex(s => String(s.name || '').toLowerCase() === name);
      if (found >= 0) idx = found;
      else {
        const n = parseInt(target, 10);
        if (!isNaN(n)) idx = n;
      }
    }
    idx = Math.max(0, Math.min(currentProject.scenes.length - 1, idx));

    const duration = Math.max(0.05, Number(opts.fade != null ? opts.fade : opts.seconds) || 0.5);
    const color = opts.color || opts.cor || '#000000';
    let style = String(opts.style || opts.estilo || 'fade').toLowerCase().replace(/['"]/g, '');
    // aliases
    if (style.includes('esquerda') || style === 'left') style = 'slide-left';
    else if (style.includes('direita') || style === 'right') style = 'slide-right';
    else if (style.includes('cima') || style === 'up') style = 'slide-up';
    else if (style.includes('baixo') || style === 'down') style = 'slide-down';
    else if (style.includes('zoom')) style = 'zoom';
    else if (style.includes('circular') || style.includes('iris')) style = 'iris';
    else style = 'fade';

    const doSwitch = () => {
      try {
        if (window.KixEngine && KixEngine.stopEngine) KixEngine.stopEngine();
      } catch (_) {}
      currentScene = idx;
      let g = {};
      try {
        if (window.KixEngine && KixEngine.runtime && KixEngine.runtime.globals) {
          g = Object.assign({}, KixEngine.runtime.globals);
        }
      } catch (_) {}
      try {
        if (typeof showScreen === 'function') showScreen('play');
        else if (typeof openScreen === 'function') openScreen('play');
      } catch (_) {}
      try {
        KixEngine.startEngine(currentProject, currentScene, Object.assign({}, g, currentProject.vars || {}));
        try { toast('Cena: ' + (currentProject.scenes[idx].name || idx)); } catch (_) {}
      } catch (e) {
        console.error('kixChangeScene switch', e);
      }
    };

    // Instant
    if (!opts.fade && !opts.seconds && duration <= 0.05 && !opts.forceFade) {
      doSwitch();
      return;
    }

    // Overlay element
    let ov = document.getElementById('kix-scene-fade');
    if (!ov) {
      ov = document.createElement('div');
      ov.id = 'kix-scene-fade';
      document.body.appendChild(ov);
    }
    const half = duration / 2;
    const base = 'position:fixed;inset:0;z-index:99999;pointer-events:auto;';

    const applyOut = () => {
      if (style === 'fade') {
        ov.style.cssText = base + 'background:' + color + ';opacity:0;transition:opacity ' + half + 's ease;';
        // force reflow
        void ov.offsetWidth;
        ov.style.opacity = '1';
      } else if (style === 'slide-left') {
        ov.style.cssText = base + 'background:' + color + ';transform:translateX(100%);transition:transform ' + half + 's ease;';
        void ov.offsetWidth;
        ov.style.transform = 'translateX(0)';
      } else if (style === 'slide-right') {
        ov.style.cssText = base + 'background:' + color + ';transform:translateX(-100%);transition:transform ' + half + 's ease;';
        void ov.offsetWidth;
        ov.style.transform = 'translateX(0)';
      } else if (style === 'slide-up') {
        ov.style.cssText = base + 'background:' + color + ';transform:translateY(100%);transition:transform ' + half + 's ease;';
        void ov.offsetWidth;
        ov.style.transform = 'translateY(0)';
      } else if (style === 'slide-down') {
        ov.style.cssText = base + 'background:' + color + ';transform:translateY(-100%);transition:transform ' + half + 's ease;';
        void ov.offsetWidth;
        ov.style.transform = 'translateY(0)';
      } else if (style === 'zoom') {
        ov.style.cssText = base + 'background:' + color + ';opacity:0;transform:scale(0.3);transition:opacity ' + half + 's ease, transform ' + half + 's ease;';
        void ov.offsetWidth;
        ov.style.opacity = '1';
        ov.style.transform = 'scale(1)';
      } else if (style === 'iris') {
        ov.style.cssText = base + 'background:' + color + ';clip-path:circle(100% at 50% 50%);transition:clip-path ' + half + 's ease;';
        void ov.offsetWidth;
        ov.style.clipPath = 'circle(0% at 50% 50%)';
        // iris closes then switch - use reverse: start open end closed covering
        ov.style.clipPath = 'circle(0% at 50% 50%)';
        // better: expand overlay as circle from center
        ov.style.cssText = base + 'background:' + color + ';clip-path:circle(0% at 50% 50%);transition:clip-path ' + half + 's ease;';
        void ov.offsetWidth;
        ov.style.clipPath = 'circle(150% at 50% 50%)';
      } else {
        ov.style.cssText = base + 'background:' + color + ';opacity:0;transition:opacity ' + half + 's ease;';
        void ov.offsetWidth;
        ov.style.opacity = '1';
      }
    };

    const applyIn = () => {
      if (style === 'fade' || style === 'zoom') {
        ov.style.transition = 'opacity ' + half + 's ease' + (style === 'zoom' ? ', transform ' + half + 's ease' : '');
        ov.style.opacity = '0';
        if (style === 'zoom') ov.style.transform = 'scale(1.2)';
      } else if (style.startsWith('slide-')) {
        ov.style.transition = 'transform ' + half + 's ease';
        if (style === 'slide-left') ov.style.transform = 'translateX(-100%)';
        else if (style === 'slide-right') ov.style.transform = 'translateX(100%)';
        else if (style === 'slide-up') ov.style.transform = 'translateY(-100%)';
        else if (style === 'slide-down') ov.style.transform = 'translateY(100%)';
      } else if (style === 'iris') {
        ov.style.transition = 'clip-path ' + half + 's ease';
        ov.style.clipPath = 'circle(0% at 50% 50%)';
      } else {
        ov.style.transition = 'opacity ' + half + 's ease';
        ov.style.opacity = '0';
      }
    };

    applyOut();
    setTimeout(function () {
      doSwitch();
      // next frame start fade-in
      requestAnimationFrame(function () {
        applyIn();
        setTimeout(function () {
          try {
            if (ov && ov.parentNode) ov.parentNode.removeChild(ov);
          } catch (_) {}
        }, half * 1000 + 40);
      });
    }, half * 1000);
  } catch (e) {
    console.error('kixChangeScene', e);
  }
}
window.KixChangeScene = kixChangeScene;

function setPlayCleanMode(enabled, options) {
  const opts = options || {};
  const next = !!enabled;

  // Clean mode gets one browser/WebView history marker. This lets the normal
  // Back gesture restore the Play UI before it can leave the Play surface.
  if (next && !playChromeHidden && !playCleanHistoryActive) {
    try {
      const currentState = (history.state && typeof history.state === 'object') ? history.state : {};
      history.pushState(Object.assign({}, currentState, { kixPlayClean: true }), document.title, location.href);
      playCleanHistoryActive = true;
    } catch (_) {
      // The floating restore button and the exported KixHandleBack remain usable
      // even when this WebView does not permit pushState.
      playCleanHistoryActive = false;
    }
  }

  let consumeCleanHistory = false;
  if (!next) {
    consumeCleanHistory = playCleanHistoryActive && !opts.fromHistory;
    playCleanHistoryActive = false;
  }

  playChromeHidden = next;
  const screen = $('screen-play');
  const controls = $('play-controls');
  const more = $('play-more-menu');
  const debug = $('debug-panel');
  const fps = $('play-fps-display');
  const hint = $('free-cam-hint');
  const axes = $('axes-overlay');
  const restore = $('btn-play-restore-ui');
  if (screen) screen.classList.toggle('kix-play-clean-mode', playChromeHidden);
  [controls, more, debug, fps, hint, axes].forEach(el => {
    if (!el) return;
    if (playChromeHidden) el.style.display = 'none';
    else el.style.removeProperty('display');
  });
  if (more && playChromeHidden) more.classList.add('hidden');
  if (restore) restore.classList.toggle('hidden', !playChromeHidden);
  syncPlayViewportToControls();

  // A click on the floating restore button or the app-level Back handler exits
  // clean mode. If the clean marker is still in browser history, consume only
  // that marker; the editor's own navigation history remains untouched.
  if (consumeCleanHistory) {
    try { history.back(); } catch (_) {}
  }
}

function visualPositionBlockMode(block) {
  if (!block) return '';
  const rawName = String(block.name || '').trim();
  let name = rawName;
  try { name = String(window.KixEngine?.canonicalBlockName?.(rawName) || rawName); } catch (_) {}
  if (name === 'Ir para X e Y' || name === 'Deslizar em X segundos até X: Y:') return 'xy';
  if (name === 'Definir X para') return 'x';
  if (name === 'Definir Y para') return 'y';
  const params = Array.isArray(block.params) ? block.params.map(p => String(typeof p === 'string' ? p : (p?.name || ''))).map(p => p.toLowerCase()) : [];
  const hasX = params.includes('x');
  const hasY = params.includes('y');
  if (hasX && hasY && /^(ir para|deslizar|colocar)/i.test(name)) return 'xy';
  if (hasX && !hasY && /^(definir|set).*\bx\b/i.test(name)) return 'x';
  if (hasY && !hasX && /^(definir|set).*\by\b/i.test(name)) return 'y';
  return '';
}

function isVisualPositionBlock(block) { return !!visualPositionBlockMode(block); }

function visualPositionBlockValues(block) {
  const values = block?.values && typeof block.values === 'object' ? block.values : {};
  const mode = visualPositionBlockMode(block);
  const num = (key) => {
    const n = Number(values[key]);
    return Number.isFinite(n) ? n : null;
  };
  if (mode === 'x') return { x:num('x') ?? num('valor'), y:null };
  if (mode === 'y') return { x:null, y:num('y') ?? num('valor') };
  return { x:num('x'), y:num('y') };
}

function visualPositionRuntimeActor() {
  const actors = window.KixEngine?.runtime?.actors || [];
  const byId = visualPositionState.actorId ? actors.find(ra => String(ra?.data?.kixId || ra?.data?.id || ra?.id || '') === String(visualPositionState.actorId)) : null;
  if (byId) return byId;
  if (visualPositionState.actorIdx >= 0 && actors[visualPositionState.actorIdx]) return actors[visualPositionState.actorIdx];
  return actors.find(ra => ra?.data === currentActor || String(ra?.data?.name || '') === String(currentActor?.name || '')) || null;
}

function updateVisualPositionReadout(x, y) {
  visualPositionState.placed = { x:Number(x)||0, y:Number(y)||0 };
  const el = $('visual-position-coord');
  if (el) el.textContent = 'X: ' + Math.round(Number(x)||0) + ' · Y: ' + Math.round(Number(y)||0);
}

function clearVisualPositionActorHighlight() {
  try { document.querySelectorAll('.kix-visual-placement-target').forEach(el => el.classList.remove('kix-visual-placement-target')); } catch (_) {}
}

function bindVisualPositionPointer() {
  if (visualPositionState.listenersBound) return;
  const stage = $('play-stage');
  if (!stage) return;
  visualPositionState.listenersBound = true;
  const pointFromEvent = (e) => {
    const t = e?.touches?.[0] || e?.changedTouches?.[0] || e;
    if (!t) return null;
    try { return window.KixEngine?.stagePointToWorld?.(t.clientX, t.clientY) || null; } catch (_) { return null; }
  };
  const constrainedPoint = (p) => {
    const mode = visualPositionState.mode || 'xy';
    const anchor = visualPositionState.placed || {x:0,y:0};
    return {
      x: mode === 'y' ? Number(anchor.x)||0 : Number(p.x)||0,
      y: mode === 'x' ? Number(anchor.y)||0 : Number(p.y)||0
    };
  };
  const update = (e) => {
    if (!visualPositionState.active || !visualPositionState.dragging) return;
    const p = pointFromEvent(e);
    const ra = visualPositionRuntimeActor();
    if (!p || !ra) return;
    const next = constrainedPoint(p);
    try { window.KixEngine?.actorPositionSet?.(ra, next.x, next.y, true); } catch (_) { return; }
    updateVisualPositionReadout(next.x, next.y);
    if (e?.cancelable) e.preventDefault();
    e?.stopImmediatePropagation?.();
  };
  const down = (e) => {
    if (!visualPositionState.active) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    const p = pointFromEvent(e);
    const ra = visualPositionRuntimeActor();
    if (!p || !ra) return;
    visualPositionState.dragging = true;
    try { if (e.pointerId != null) stage.setPointerCapture?.(e.pointerId); } catch (_) {}
    const next = constrainedPoint(p);
    try { window.KixEngine?.actorPositionSet?.(ra, next.x, next.y, true); } catch (_) {}
    updateVisualPositionReadout(next.x, next.y);
    if (e.cancelable) e.preventDefault();
    e.stopImmediatePropagation?.();
  };
  const up = (e) => {
    if (!visualPositionState.active) return;
    visualPositionState.dragging = false;
    try { if (e?.pointerId != null) stage.releasePointerCapture?.(e.pointerId); } catch (_) {}
    if (e?.cancelable) e.preventDefault();
    e?.stopImmediatePropagation?.();
  };
  if (typeof window.PointerEvent === 'function') {
    stage.addEventListener('pointerdown', down, {capture:true, passive:false});
    stage.addEventListener('pointermove', update, {capture:true, passive:false});
    stage.addEventListener('pointerup', up, {capture:true, passive:false});
    stage.addEventListener('pointercancel', up, {capture:true, passive:false});
  } else {
    stage.addEventListener('touchstart', down, {capture:true, passive:false});
    stage.addEventListener('touchmove', update, {capture:true, passive:false});
    stage.addEventListener('touchend', up, {capture:true, passive:false});
    stage.addEventListener('touchcancel', up, {capture:true, passive:false});
    stage.addEventListener('mousedown', down, {capture:true, passive:false});
    stage.addEventListener('mousemove', update, {capture:true, passive:false});
    window.addEventListener('mouseup', up, {capture:true, passive:false});
  }
}

function openVisualPositionPlacement() {
  try {
    restoreCurrentActorContext();
    const idx = Number(ctxBlockIdx);
    if (!currentActor || !Array.isArray(currentActor.scripts) || !Number.isInteger(idx) || !currentActor.scripts[idx]) { toast('Bloco não encontrado'); return false; }
    const block = currentActor.scripts[idx];
    const mode = visualPositionBlockMode(block);
    if (!mode) { toast('Este bloco não usa posição X/Y'); return false; }
    const actors = getSceneActors();
    const actorIdx = actors.indexOf(currentActor);
    if (actorIdx < 0) { toast('Objeto não encontrado'); return false; }
    const vals = visualPositionBlockValues(block);
    const startX = vals.x == null ? Number(currentActor.x) || 0 : vals.x;
    const startY = vals.y == null ? Number(currentActor.y) || 0 : vals.y;
    visualPositionState.mode = mode;
    visualPositionState.active = true;
    visualPositionState.blockIdx = idx;
    visualPositionState.actorId = ensureActorIdentity(currentActor);
    visualPositionState.actorIdx = actorIdx;
    visualPositionState.original = { x:Number(currentActor.x)||0, y:Number(currentActor.y)||0 };
    visualPositionState.placed = { x:startX, y:startY };
    visualPositionState.dragging = false;
    const originScreen = lastScreen === 'scripts' ? 'scripts' : 'scene';
    playReturn = { screen:originScreen, actorIdx:originScreen === 'scripts' ? actorIdx : -1, tab:originScreen === 'scripts' ? currentTab : 'scripts', scene:currentScene };
    closeBlockContext();
    isPlaying = true;
    playChromeHidden = false;
    freeCam = false; camX = 0; camY = 0; camZoom = 1;
    stageGrid = false;
    const g = Object.assign({}, globals || {}, currentProject?.vars || {});
    KixEngine.startEngine(currentProject, currentScene, g, { mode:'visual-position', skipSceneStart:true });
    show('play', { noPush:true, noAnimation:true });
    lastScreen = 'play';
    const screen = $('screen-play');
    screen?.classList.add('kix-play-placement-mode');
    setPlayCleanMode(false);
    $('visual-position-toolbar')?.classList.remove('hidden');
    if ($('visual-position-cancel')) $('visual-position-cancel').textContent = 'Cancelar';
    const ra = visualPositionRuntimeActor();
    if (ra) {
      window.KixEngine.actorPositionSet(ra, startX, startY, true);
      ra.el?.classList.add('kix-visual-placement-target');
    }
    updateVisualPositionReadout(startX, startY);
    bindVisualPositionPointer();
    try { KixEngine?.syncStageLayout?.(); } catch (_) {}
    requestAnimationFrame(() => { try { KixEngine?.syncStageLayout?.(); } catch (_) {} });
    return true;
  } catch (e) {
    console.error('openVisualPositionPlacement', e);
    visualPositionState.active = false;
    try { KixEngine?.stopEngine?.(); } catch (_) {}
    toast('Não foi possível abrir a posição visual');
    return false;
  }
}

function finishVisualPositionPlacement(saveChanges) {
  if (!visualPositionState.active) return;
  const idx = visualPositionState.blockIdx;
  const x = Number(visualPositionState.placed?.x) || 0;
  const y = Number(visualPositionState.placed?.y) || 0;
  const mode = visualPositionState.mode || 'xy';
  const doSave = saveChanges === true;
  const wasScripts = playReturn?.screen === 'scripts';
  const tab = playReturn?.tab || 'scripts';
  const actorIdx = playReturn?.actorIdx ?? -1;
  const scene = playReturn?.scene ?? currentScene;
  visualPositionState.active = false;
  visualPositionState.dragging = false;
  clearVisualPositionActorHighlight();
  $('visual-position-toolbar')?.classList.add('hidden');
  $('screen-play')?.classList.remove('kix-play-placement-mode');
  setPlayCleanMode(false);
  try { KixEngine?.stopEngine?.(); } catch (_) {}
  if (doSave) {
    try {
      if (currentActor && Array.isArray(currentActor.scripts) && currentActor.scripts[idx]) {
        const block = currentActor.scripts[idx];
        block.values = block.values && typeof block.values === 'object' ? block.values : {};
        if (mode === 'x') block.values.valor = String(Number.isFinite(x) ? x : 0);
        else if (mode === 'y') block.values.valor = String(Number.isFinite(y) ? y : 0);
        else {
          block.values.x = String(Number.isFinite(x) ? x : 0);
          block.values.y = String(Number.isFinite(y) ? y : 0);
        }
      }
    } catch (e) { console.error('finishVisualPositionPlacement save', e); }
    try { save(); } catch (_) {}
  }
  isPlaying = false;
  currentScene = scene;
  if (wasScripts && actorIdx >= 0) {
    try { openActor(actorIdx); } catch (_) { navJumpTo('scripts'); }
    try { switchTab(tab,{record:false}); } catch (_) {}
    try { renderScripts(); } catch (_) {}
    lastScreen='scripts';
  } else {
    navJumpTo('scene');
    try { renderActors(); } catch (_) {}
    lastScreen='scene';
  }
  try { $('visual-position-toolbar')?.classList.add('hidden'); } catch (_) {}
  visualPositionState.blockIdx=null; visualPositionState.actorId=''; visualPositionState.actorIdx=-1;
  visualPositionState.mode='';
  visualPositionState.original={x:null,y:null};
  if (doSave) toast('Posição atualizada'); else toast('Alteração cancelada');
}

function cancelVisualPositionPlacement() { finishVisualPositionPlacement(false); }

function updatePlayStateUI(paused) {
  const btn = $('btn-pause-play');
  if (btn) { const span = btn.querySelector('span:last-child'); if (span) span.textContent = paused ? 'Retomar' : 'Pausar'; }
}

function startPlay() {
  try {
    visualPositionState.active = false;
    $('visual-position-toolbar')?.classList.add('hidden');
    $('screen-play')?.classList.remove('kix-play-placement-mode');
    setPlayCleanMode(false);
    // Project orientation is applied to the Android Activity and remains the source
    // of truth while Play runs; the logical stage coordinates are kept fixed.
    // Remember where Play was pressed
    const originScreen = (lastScreen === 'scripts' || lastScreen === 'scene') ? lastScreen : 'scene';
    playReturn = {
      screen: originScreen,
      actorIdx: originScreen === 'scripts' && currentActorIdx >= 0 ? currentActorIdx : -1,
      tab: originScreen === 'scripts' ? currentTab : 'scripts',
      scene: currentScene
    };

    try {
      const scene = currentProject && currentProject.scenes && currentProject.scenes[currentScene];
      (scene && scene.actors || []).forEach(a => {
        if (a.scripts && a.scripts.blocks && window.KixEngine) {
          a.scripts = KixEngine.scriptsToFlat(a.scripts);
        }
        if (!Array.isArray(a.scripts)) a.scripts = [];
        if (!Array.isArray(a.folders)) a.folders = [];
        if (!Array.isArray(a.looks)) a.looks = [];
      });
    } catch (_) {}
    try { syncActorToProject(); } catch (_) {}
    try { save(); } catch (_) {}
    // Play is transient: remove any stale Play history before opening the
    // runtime so exiting back through the scene/project editors cannot loop.
    purgeTransientNavEntries();
    isPlaying = true;
    // A new Play session invalidates the previous close snapshot. A fresh
    // snapshot is created only when this session is actually closed.
    playClosedVariableSnapshot = null;
    if (globalsPanelTimer) { if (window.KixLifecycle?.clear) window.KixLifecycle.clear(globalsPanelTimer, 'play'); else clearInterval(globalsPanelTimer); }
    globalsPanelTimer = (window.KixLifecycle?.setInterval ? window.KixLifecycle.setInterval : setInterval)(() => {
      try {
        const panel = $('debug-panel') || $('globals-panel');
        if (!panel) return;
        const hidden = panel.classList && panel.classList.contains('hidden');
        const parentHidden = panel.closest && panel.closest('.hidden');
        if (!hidden && !parentHidden && typeof updateGlobalsPanel === 'function') updateGlobalsPanel();
      } catch (_) {}
    }, 200, 'play', {name:'globals-panel'});
    freeCam = false;
    try { if (window.KixEngine && KixEngine.runtime) KixEngine.runtime.freeCam = false; } catch (_) {}
    camX = 0; camY = 0; camZoom = 1;
    stageGrid = !!appOptions.grid;
    if (typeof applyCamTransform === 'function') applyCamTransform();
    if (typeof applyStageGrid === 'function') applyStageGrid();
    $('free-cam-hint')?.classList.add('hidden');
    $('btn-free-cam')?.classList.remove('text-[#34D399]');
    $('btn-free-cam')?.classList.add('text-[#aaa]');
    if (typeof updateGlobalsPanel === 'function') updateGlobalsPanel();
    if (!window.KixEngine) {
      toast('Motor não carregado');
      isPlaying = false;
      return;
    }
    if (!currentProject) {
      toast('Nenhum projeto aberto');
      isPlaying = false;
      return;
    }
    // Screen orientation belongs to the Play session. Free camera is only a world-space transform.
    try {
      const requested = String(currentProject.orientation || currentProject?.catrobatStage?.orientation || '').toLowerCase();
      if ((requested === 'landscape' || requested === 'portrait') && window.Android?.setProjectOrientation) {
        window.Android.setProjectOrientation(requested);
      }
    } catch (_) {}
    const g = Object.assign({}, globals || {}, currentProject.vars || {});
    syncPlayViewportToControls();
    try { window.KixLifecycle?.enter?.('play'); } catch (_) {}
    KixEngine.startEngine(currentProject, currentScene, g);
    try { window.KixLifecycle?.leave?.(); } catch (_) {}
    $('play-fps-display')?.classList.add('hidden');
    updatePlayStateUI(false);
    try { const st = $('play-status'); if (st) st.style.display = 'none'; } catch(_){}
    toast('Executando');
  } catch (e) {
    console.error('startPlay', e);
    toast('Erro ao executar');
    isPlaying = false;
  } finally {
    if (isPlaying) {
      try {
        show('play', { noPush: true });
        lastScreen = 'play';
        syncPlayViewportToControls();
        // The Play screen was hidden while the engine was created. Sync again now
        // so the real visible canvas defines the center of world 0,0.
        if (window.KixEngine?.syncStageLayout) KixEngine.syncStageLayout();
        requestAnimationFrame(() => { try { KixEngine?.syncStageLayout?.(); } catch (_) {} });
      } catch (_) {}
    }
  }
}
function stopPlay() {
  try {
    if (visualPositionState.active) { cancelVisualPositionPlacement(); return; }
    // Defensive cleanup for sessions opened by older code paths/plugins.
    // Play must never survive in the editor's navigation history.
    purgeTransientNavEntries();
    setPlayCleanMode(false);
    isPlaying = false;
    $('play-fps-display')?.classList.add('hidden');
    if (globalsPanelTimer) { if (window.KixLifecycle?.clear) window.KixLifecycle.clear(globalsPanelTimer, 'play'); else clearInterval(globalsPanelTimer); globalsPanelTimer = null; }
    showAxes = false;
    freeCam = false;
    // Capture BEFORE stopEngine(), because stopEngine() tears down the runtime.
    // This is the exact value boundary requested by the formula editor: the
    // variable value at the instant the user closes Play.
    // A função vive dentro do módulo do editor de fórmulas; sem este desvio o ReferenceError
    // pulava o stopEngine() e o Play continuava rodando em segundo plano.
    try { (window.__kixCapturePlayVariableSnapshot || (() => null))(); } catch (_) {}
    if (window.KixEngine && typeof KixEngine.stopEngine === 'function') {
      KixEngine.stopEngine();
    }
    try { window.KixLifecycle?.clearScope?.('play'); } catch (_) {}
    try { if (window.Android?.restoreProjectOrientation) window.Android.restoreProjectOrientation(); } catch (_) {}
  } catch (e) {
    console.error('stopPlay', e);
  } finally {
    try {
      // Return to the exact editor surface that launched Play.
      const returnScreen = playReturn?.screen === 'scripts' ? 'scripts' : 'scene';
      const aIdx = (returnScreen === 'scripts' && playReturn && playReturn.actorIdx >= 0) ? playReturn.actorIdx : -1;
      const sc = (playReturn && playReturn.scene != null) ? playReturn.scene : currentScene;
      currentScene = sc;
      if (returnScreen === 'scripts' && aIdx >= 0) {
        try { openActor(aIdx); } catch (_) { navJumpTo('scripts'); }
        try { switchTab(playReturn?.tab || 'scripts', {record:false}); } catch (_) { try { switchTab('scripts', {record:false}); } catch(__){} }
      } else {
        navJumpTo('scene');
        try { renderActors(); } catch (_) {}
      }
      lastScreen = returnScreen;
    } catch (e2) {
      console.error(e2);
      try { navJumpTo('scripts'); } catch (_) {}
    }
  }
}

function persistAppOptions() {
  try { localStorage.setItem('kix_app_options', JSON.stringify(appOptions)); } catch (_) {}
}
function applyStageGrid() {
  const canvas = $('play-canvas');
  if (canvas) canvas.classList.toggle('kix-stage-grid', !!stageGrid);
}
function syncPlayViewportToControls() {
  try {
    const canvas = $('play-canvas');
    const controls = $('play-controls');
    if (!canvas || !controls) return;
    const h = Math.max(0, Math.ceil(controls.getBoundingClientRect().height || controls.offsetHeight || 0));
    canvas.style.marginBottom = h ? (h + 'px') : '';
    canvas.style.boxSizing = 'border-box';
  } catch (_) {}
}
function setStageZoom(next) {
  camZoom = Math.min(4, Math.max(0.25, Number(next) || 1));
  applyCamTransform();
  try { if (KixEngine?.runtime) KixEngine.runtime.camZoom = camZoom; } catch (_) {}
}
function fitStage() {
  camX = 0; camY = 0;
  setStageZoom(1);
  toast('Palco ajustado');
}
function syncCameraStateToRuntime() {
  try {
    const r = window.KixEngine?.runtime;
    if (!r) return;
    r.camX = camX;
    r.camY = camY;
    r.camZoom = camZoom;
    // Public camera coordinates are world coordinates. The internal camX is the
    // render translation, so X is inverted while Y keeps the world-axis direction.
    r.cameraWorldX = -camX;
    r.cameraWorldY = camY;
  } catch (_) {}
}
function applyCamTransform() {
  const stage = $('play-stage');
  if (stage) {
    stage.style.transform = `translate(${camX}px, ${camY}px) scale(${camZoom})`;
  }
  syncCameraStateToRuntime();
}
function toggleFreeCam() {
  freeCam = !freeCam;
  try { if (window.KixEngine && KixEngine.runtime) KixEngine.runtime.freeCam = freeCam; } catch (_) {}
  syncCameraStateToRuntime();
  const btn = $('btn-free-cam');
  const hint = $('free-cam-hint');
  if (freeCam) {
    btn?.classList.remove('text-[#aaa]');
    btn?.classList.add('text-[#34D399]');
    hint?.classList.remove('hidden');
    toast('Câmera livre ativa');
  } else {
    btn?.classList.remove('text-[#34D399]');
    btn?.classList.add('text-[#aaa]');
    hint?.classList.add('hidden');
    // reset optional - keep position
    toast('Câmera livre desligada');
  }
}
function setupFreeCamGestures() {
  const canvas = $('play-canvas');
  if (!canvas || canvas._camBound) return;
  canvas._camBound = true;

  canvas.addEventListener('touchstart', (e) => {
    if (!(freeCam || (window.KixEngine && KixEngine.runtime && KixEngine.runtime.freeCam)) || !isPlaying) return;
    if (e.touches.length === 1) {
      camDragging = true;
      camLastX = e.touches[0].clientX;
      camLastY = e.touches[0].clientY;
    } else if (e.touches.length === 2) {
      camDragging = false;
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      camPinchDist = Math.hypot(dx, dy);
    }
  }, { passive: true });

  canvas.addEventListener('touchmove', (e) => {
    if (!(freeCam || (window.KixEngine && KixEngine.runtime && KixEngine.runtime.freeCam)) || !isPlaying) return;
    if (e.touches.length === 1 && camDragging) {
      const dx = e.touches[0].clientX - camLastX;
      const dy = e.touches[0].clientY - camLastY;
      camX += dx;
      camY += dy;
      camLastX = e.touches[0].clientX;
      camLastY = e.touches[0].clientY;
      applyCamTransform();
      try { if (window.KixEngine?.runtime) { KixEngine.runtime.camX = camX; KixEngine.runtime.camY = camY; } } catch (_) {}
    } else if (e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.hypot(dx, dy);
      if (camPinchDist > 0) {
        const scale = dist / camPinchDist;
        camZoom = Math.min(4, Math.max(0.25, camZoom * scale));
        camPinchDist = dist;
        applyCamTransform();
        try { if (window.KixEngine?.runtime) KixEngine.runtime.camX = camX; if (window.KixEngine?.runtime) KixEngine.runtime.camZoom = camZoom; } catch (_) {}
      }
    }
  }, { passive: true });

  canvas.addEventListener('touchend', () => {
    camDragging = false;
    camPinchDist = 0;
  });

  // Desktop mouse support
  canvas.addEventListener('mousedown', (e) => {
    if (!(freeCam || (window.KixEngine && KixEngine.runtime && KixEngine.runtime.freeCam)) || !isPlaying) return;
    camDragging = true;
    camLastX = e.clientX;
    camLastY = e.clientY;
  });
  window.addEventListener('mousemove', (e) => {
    if (!camDragging || !(freeCam || (window.KixEngine && KixEngine.runtime && KixEngine.runtime.freeCam))) return;
    camX += e.clientX - camLastX;
    camY += e.clientY - camLastY;
    camLastX = e.clientX;
    camLastY = e.clientY;
    applyCamTransform();
    try { if (window.KixEngine?.runtime) { KixEngine.runtime.camX = camX; KixEngine.runtime.camY = camY; } } catch (_) {}
  });
  window.addEventListener('mouseup', () => { camDragging = false; });
  canvas.addEventListener('wheel', (e) => {
    if (!(freeCam || (window.KixEngine && KixEngine.runtime && KixEngine.runtime.freeCam)) || !isPlaying) return;
    e.preventDefault();
    camZoom = Math.min(4, Math.max(0.25, camZoom * (e.deltaY > 0 ? 0.9 : 1.1)));
    applyCamTransform();
    try { if (window.KixEngine?.runtime) KixEngine.runtime.camZoom = camZoom; } catch (_) {}
  }, { passive: false });
}
function runKixSelfTest() {
  const results = [];
  const check = (name, ok, detail='') => results.push({name, ok:!!ok, detail});
  try {
    const cats = window.KixEngine?.categories || (typeof CATEGORIES !== 'undefined' ? CATEGORIES : {});
    check('1. Engine carregada', !!window.KixEngine, 'KixEngine global');
    check('2. Categorias disponíveis', Object.keys(cats || {}).length > 0, Object.keys(cats || {}).length + ' categorias');
    check('3. Aparências catalogada', !!(cats?.aparencias || cats?.looks), 'categoria visual');
    check('4. Camera+ catalogada', !!(cats?.cameraplus || cats?.camera || cats?.câmera), 'categoria câmera');
    check('5. Editor de colisão único', document.querySelectorAll('[data-action="look-collision"]').length === 0 && !!document.querySelector('[data-action="actor-collision"]'), 'colisão pertence ao objeto');
    check('6. Palco Mais', !!$('btn-play-more') && !!$('play-more-menu'), 'menu de ferramentas');
    check('7. Pixel Art disponível', !!document.querySelector('#sheet-look-options [data-action="look-pixel-art"]'), 'opção de aparência');
    check('8. Sem sombra nos blocos', !document.querySelector('#script-blocks .pc-block') || getComputedStyle(document.querySelector('#script-blocks .pc-block')).boxShadow === 'none', 'box-shadow do bloco');
    check('9. Orientação', typeof rotatePlayScreen === 'function', 'retrato/paisagem');
    const names=[]; Object.values(cats||{}).forEach(c=> (c.blocks||[]).forEach(b=>names.push(b.n||'')));
    check('10. Blocos catalogados', names.length > 0, names.length + ' blocos');
    check('11. Catálogo consistente', names.length === new Set(names).size, 'sem duplicações exatas');
    const a = currentActor;
    check('12. Colisão do objeto', !a || !!a.isCamera || a.collisionShape !== undefined, 'collisionShape no actor');
    check('13. Pastas normalizadas', !a || Array.isArray(a.folders), 'folders[]');
    check('14. Inferência de som', inferKixParamType('Tocar som','som','number') === 'sound', 'som → sound');
    check('15. Inferência de objeto', inferKixParamType('Quando colidir com','objeto','number') === 'object', 'objeto → object');
    check('16. Inferência de aparência', inferKixParamType('Trocar aparência para','aparência','number') === 'image', 'aparência → image');
    check('17. Inferência de pasta', inferKixParamType('Tocar animação','pasta','number') === 'folder', 'pasta → folder');
    check('18. Inferência de cena', inferKixParamType('Trocar para cena','cena','number') === 'scene', 'cena → scene');
    const sample = buildBlockLabelHtml('Tocar som',[{name:'som',type:'sound'}],{som:"'Laser.wav'"},false);
    check('19. Classe dropdown no som', sample.includes('class="param formula-open dropdown"'), 'renderizador');
    check('20. Dropdown do objeto', buildBlockLabelHtml('Apontar para objeto',['objeto'],{objeto:"'Alvo'"},false).includes('data-dropdown-type="object"'), 'atributo object');
    check('21. Dropdown da aparência', buildBlockLabelHtml('Trocar aparência para',['aparência'],{aparência:"'look'"},false).includes('data-dropdown-type="image"'), 'atributo image');
    check('22. Dropdown da pasta', buildBlockLabelHtml('Tocar animação',['pasta'],{pasta:"'Run'"},false).includes('data-dropdown-type="folder"'), 'atributo folder');
    check('23. Dropdown da cena', buildBlockLabelHtml('Trocar para cena',['cena'],{cena:"'Cena 2'"},false).includes('data-dropdown-type="scene"'), 'atributo scene');
    check('24. Dropdown inline disponível', typeof window.KixResourcePicker?.openResourceDropdown === 'function', 'inline resource picker');
    check('25. Inline CSS e tela de carregamento disponíveis', /kix-inline-dropdown/.test(document.documentElement.innerHTML) && !!$('screen-catrobat-loading'), 'dropdown + loading screen');
    const savedSelectorState = { project: currentProject, scene: currentScene, actor: currentActor, actorIdx: currentActorIdx };
    const probeRoot = document.createElement('div');
    probeRoot.innerHTML = '<div class="pc-block" data-script-idx="0"><span class="param formula-open dropdown" data-dropdown-type="folder" data-param="pasta" data-value="Run">Run</span></div>';
    const probeParam = probeRoot.querySelector('.param');
    const probeBlock = probeRoot.querySelector('.pc-block');
    let sheetProbeOk = false, newProbeOk = false, formulaProbeOk = false;
    try {
      if (!currentActor) {
        currentProject = { scenes: [{ name:'SelfTest', actors:[{ name:'SelfTest', looks:['selftest-look'], sounds:[{name:'selftest-sound'}], folders:[{name:'Run', looks:['selftest-look']}], scripts:[{id:'selftest',name:'Tocar animação',params:['pasta'],values:{pasta:'Run'}}] }] }] };
        currentScene = 0; currentActorIdx = 0; currentActor = currentProject.scenes[0].actors[0];
      }
      document.body.appendChild(probeRoot);
      sheetProbeOk = !!window.KixResourcePicker?.openResourceDropdown?.(probeParam) && !!document.querySelector('.kix-inline-dropdown');
      newProbeOk = !!document.querySelector('.kix-inline-dropdown .kix-inline-new');
      formulaProbeOk = !!document.querySelector('.kix-inline-dropdown .kix-inline-formula');
    } catch (_) {}
    closeSheets(); probeRoot.remove();
    currentProject = savedSelectorState.project; currentScene = savedSelectorState.scene; currentActor = savedSelectorState.actor; currentActorIdx = savedSelectorState.actorIdx;
    check('26. Dropdown abre dentro do bloco', sheetProbeOk, 'menu inline');
    check('26A. Definir variável usa três linhas', /kix-set-variable-title/.test(buildBlockLabelHtml('Definir variável para',[{name:'variável',type:'text',default:'pontos'},{name:'valor',type:'number',default:1}],{variável:'variavel-real',valor:1},false)) && /kix-set-variable-variable-line/.test(buildBlockLabelHtml('Definir variável para',[{name:'variável',type:'text',default:'pontos'},{name:'valor',type:'number',default:1}],{variável:'variavel-real',valor:1},false)) && /kix-set-variable-value-line/.test(buildBlockLabelHtml('Definir variável para',[{name:'variável',type:'text',default:'pontos'},{name:'valor',type:'number',default:1}],{variável:'variavel-real',valor:1},false)), 'layout estruturado');
    check('26B. Seletor de variável usa atributo próprio', buildBlockLabelHtml('Definir variável para',[{name:'variável',type:'text',default:'pontos'},{name:'valor',type:'number',default:1}],{variável:'variavel-real',valor:1},false).includes('data-variable-selector="1"'), 'seletor de variável');
    check('26C. Resolver do seletor aceita actorId + blockId', /actorIdHint/.test(resolveKixVariableSelectorTarget.toString()) && /blockId/.test(resolveKixVariableSelectorTarget.toString()), 'resolução robusta do seletor');
    check('26D. Editor grava blockId e actorId no DOM', /dataset\.blockId = String\(s\.id/.test(renderScripts.toString()) && /dataset\.actorId = String\(ensureActorIdentity\(currentActor\)\)/.test(renderScripts.toString()), 'identidade do bloco');
    check('26C. Dropdown de variável disponível', typeof window.KixVariableSelector?.open === 'function' && typeof window.KixVariableSelector?.names === 'function', 'variable selector');
    check('27. Dropdown contém criar e fórmula', newProbeOk && formulaProbeOk, 'novo... + Usar fórmula...');
    check('28. Recursos de som legíveis', typeof window.KixResourcePicker?.selectorSoundItems === 'function', 'selectorSoundItems');
    check('29. Objetos excluem o próprio ator', !a || !window.KixResourcePicker.selectorObjectItems().some(x => x.value === String(a.name || '')), 'sem self-target');
    check('30. Looks de raiz legíveis', typeof window.KixResourcePicker?.selectorLookItems === 'function', 'selectorLookItems');
    check('31. Looks de pasta legíveis', !a || Array.isArray(a.folders), 'folders + looks');
    check('32. Cenas do projeto legíveis', typeof window.KixResourcePicker?.selectorSceneItems === 'function', 'selectorSceneItems');
    check('33. Pastas de aparência legíveis', typeof window.KixResourcePicker?.selectorFolderItems === 'function', 'selectorFolderItems');
    check('34. Estado pendente inicializável', window._kixPendingSelector === null || typeof window._kixPendingSelector === 'object', 'pending selector');
    check('35. Input de som e detector Pixel Art existem', !!$('input-sound') && typeof window.KixPixelArt?.detect === 'function', 'audio input + detector');
    check('36. Input de imagem existe', !!$('input-actor-image'), 'file input');
    check('37. Seleção preserva aspas', window.KixResourcePicker.selectorStoredValue("'antigo'",'novo') === "'novo'", 'formato do valor');
    check('38. Seleção sem aspas continua sem aspas', window.KixResourcePicker.selectorStoredValue('antigo','novo') === 'novo', 'formato do valor');
    check('39. Hook de objeto novo existe', /pendingObject/.test(addActor.toString()), 'criação + seleção automática');
    check('40. Cena nova preserva cena atual', /previousScene/.test(window.KixResourcePicker.selectorStartNew.toString()), 'restauração de contexto');
    check('41. Valor continua em block.values', /t\.block\.values\[t\.paramName\]/.test(window.KixResourcePicker.applySelectorValue.toString()), 'persistência');
    check('42. Botão editar menor e lápis maior', /#btn-home-play[^{]*\{[\s\S]*?\}/.test(document.documentElement.innerHTML) && /recent-play-icon svg\{width:34px!important;height:34px!important\}/.test(document.documentElement.innerHTML), 'CSS da ação compacta / lápis 34px');
    check('43. Menu Catroid protegido e tela de importação', !document.querySelector('#btn-import-catrobat') && !!document.querySelector('#menu-import-catrobat') && document.querySelector('#menu-import-catrobat')?.textContent.includes('Importar Catroid') && !!document.querySelector('[data-ext="experimental"]') && !!document.querySelector('#screen-catrobat-loading') && /background:\s*rgba\(5,150,105,\.16\)/.test(document.documentElement.innerHTML) && /border:\s*3px solid/.test(document.documentElement.innerHTML), 'gate experimental + loading + estilo');
    check('44. Catálogo normal tem opcode estável para todos os blocos', Object.values(window.KixBlockRegistry||{}).length > 100 && Object.entries(window.KixBlockRegistry||{}).every(([op,name])=>/^kix\.[0-9a-f]{8}$/.test(kixStableOpcode(name)) && op===kixStableOpcode(name)), 'registro de blocos');
    check('45. Todos os blocos visuais têm definição renderizável', Object.values(CATEGORIES||{}).every(cat => (cat.blocks||[]).every(b => b && typeof b.n==='string' && b.n.trim() && (!b.p || Array.isArray(b.p)))), 'catálogo/editor');
    const blockChecks=[]; Object.values(CATEGORIES||{}).forEach(cat => (cat.blocks||[]).forEach(def => { try { const n=typeof def==='string'?def:def?.n; const p=typeof def==='string'?[]:(def?.p||[]); const html=buildBlockLabelHtml(n,p,null,true); blockChecks.push({name:n,ok:!!n&&/<span class=\"blk-label/.test(html)&&!html.includes('[object Object]')}); } catch(e){ blockChecks.push({name:String(def?.n||def||''),ok:false}); } }));
    check('46. Todos os blocos do catálogo têm renderização válida', blockChecks.length>0 && blockChecks.every(x=>x.ok), blockChecks.filter(x=>!x.ok).slice(0,5).map(x=>x.name).join(', ') || (blockChecks.length+' blocos'));
    const styleText=document.documentElement.innerHTML;
    check('47. Geometria clássica dos blocos', /\.pc-block[\s\S]*border-radius/.test(styleText) && /\.pc-block::before/.test(styleText) && /--kix-block-tab-left:\s*-13\.(39|65)px/.test(styleText) && /55% 48%/.test(styleText), 'rounded ticket + left V');
    check('48. Scroll vertical e Drag do Brick separados', /#categories-list[\s\S]*touch-action:\s*pan-y/.test(styleText) && /#blocks-list[\s\S]*touch-action:\s*pan-y/.test(styleText) && /#script-blocks[\s\S]*touch-action:\s*pan-y/.test(styleText) && /#script-blocks \.pc-block\s*\{[^}]*touch-action:\s*none/.test(styleText), 'listas rolam; Brick inicia gesto no controlador');
    check('49. Drag mobile usa hold automático + movimento + preview + ghost', /delay:\s*360/.test(String(renderScripts).replace(/\s+/g,' ')) && /delayOnTouchOnly:\s*true/.test(String(renderScripts).replace(/\s+/g,' ')) && /delayStartsDragOnMovementOnly:\s*false/.test(String(renderScripts).replace(/\s+/g,' ')) && /forceFallback:\s*true/.test(String(renderScripts).replace(/\s+/g,' ')), 'clique curto separado; hold inicia Drag automaticamente');
    check('50. Limite explícito de loop fecha o pai estrutural', (() => {
      try{
        const M = window.KixBrickDragModel;
        if(!M) return false;
        const probe = [
          {id:'probe-loop', name:'Repita 10 vezes', type:'loop', loopBoundaryExplicit:true, loopEndId:'probe-wait'},
          {id:'probe-transparency', name:'Mudar transparência em', type:'command'},
          {id:'probe-wait', name:'Esperar', type:'command'},
          {id:'probe-after', name:'Mudar X em', type:'command'}
        ];
        const proposal = M.buildProposal(probe, 1, null);
        return (M.structuralParentAt(probe, 3) == null) && (M.structuralParentAt(proposal.scripts, 3) == null);
      }catch(_){ return false; }
    })(), 'loopEndId respeitado após Fim de loop');
    const savedGestureState = { project: currentProject, scene: currentScene, actor: currentActor, actorIdx: currentActorIdx };
    let tapPanelOk = false;
    try {
      currentProject = { scenes: [{ name:'GestureSelfTest', actors:[{ name:'GestureSelfTest', scripts:[{id:'gesture-block',name:'Mudar transparência em',params:[{name:'valor',type:'number'}],values:{valor:-10},color:'#62C8A5',type:'action'}] }] }] };
      currentScene = 0; currentActorIdx = 0; currentActor = currentProject.scenes[0].actors[0];
      renderScripts();
      const gestureBlock = document.querySelector('#script-blocks .pc-block:not(.loop-end):not(.if-marker)');
      const sortable = document.getElementById('script-blocks')?._sortable;
      gestureBlock?.click();
      tapPanelOk = !!document.getElementById('block-ctx-overlay')?.classList.contains('open') && sortable?.state === 'IDLE';
      closeBlockContext();
    } catch (_) { tapPanelOk = false; }
    try { renderScripts(); } catch (_) {}
    currentProject = savedGestureState.project; currentScene = savedGestureState.scene; currentActor = savedGestureState.actor; currentActorIdx = savedGestureState.actorIdx;
    check('51. Clique curto abre painel; arraste continua separado', tapPanelOk, 'tap → painel; drag permanece no BrickDragController');
    check('52. Dropdown sem borda', /\.kix-inline-dropdown[\s\S]*border:0/.test(styleText) || /\.kix-inline-dropdown,/.test(styleText), 'shell sem border');
    check('53. Dropdown quadrado', /\.kix-inline-dropdown[\s\S]*border-radius:0/.test(styleText), 'radius 0');
    check('54. Linhas do dropdown quadradas', /\.kix-inline-row[\s\S]*border-radius:0/.test(styleText), 'row radius 0');
    check('55. Select nativo sem contorno', /select[\s\S]*border:0/.test(styleText), 'select border 0');
    check('56. Select nativo quadrado', /select[\s\S]*border-radius:0/.test(styleText), 'select radius 0');
    check('57. Dropdown sem outline de foco', /\.kix-inline-dropdown:focus[\s\S]*outline:0/.test(styleText) && /\.kix-inline-row:focus[\s\S]*outline:0/.test(styleText), 'focus limpo');
    check('58. Abertura marca aria-expanded', /targetEl\.setAttribute\('aria-expanded','true'\)/.test(String(openResourceDropdown)), 'estado acessível');
    check('59. Fechamento limpa aria-expanded', /aria-expanded','false/.test(String(closeInlineResourceDropdown)), 'estado acessível restaurado');
    check('60. Toque externo fecha dropdown', /document\.addEventListener\('pointerdown'/.test(document.documentElement.innerHTML) && /closeInlineResourceDropdown\(\)/.test(String(window.KixResourcePicker?.openResourceDropdown)), 'dismiss externo');
    check('61. Scroll fecha recursos, mas não fecha seletor de variável', /document\.addEventListener\('scroll'/.test(document.documentElement.innerHTML) && /kix-variable-inline-dropdown/.test(document.documentElement.innerHTML), 'dismiss no scroll');
    check('62. Escape fecha estados transitórios', /e\.key !== 'Escape'/.test(document.documentElement.innerHTML) && /closeInlineResourceDropdown\(\)/.test(document.documentElement.innerHTML), 'Escape');
    check('63. Hitbox do dropdown permanece ≥44px', /\.kix-inline-row[\s\S]*min-height:46px/.test(styleText), 'touch target');
    check('64. Dropdown continua rolável', /\.kix-inline-dropdown[\s\S]*max-height:260px[\s\S]*overflow-y:auto/.test(styleText), 'lista rolável');
    check('65. Dropdown preserva overscroll containment', /overscroll-behavior:contain/.test(styleText), 'scroll isolado');
    check('66. Linhas sem elementos decorativos internos obrigatórios', !/kix-resource-icon[^>]*\/>/.test(String(window.KixResourcePicker?.openResourceDropdown||'')), 'dropdown textual');
    check('67. Catálogo nativo continua ordenado por preferência', /preferredOrder = \[/.test(String(buildCategories)) && /evento','controle','movimento'/.test(String(buildCategories)), 'ordem estável');
    check('68. Categorias de plugin continuam agrupadas', /kixRenderPluginGroup\(pluginPage, pluginId/.test(String(buildCategories)), 'agrupamento preservado');
    check('69. Registrador de blocos permanece único', Object.values(window.KixBlockRegistry||{}).length > 100 && new Set(Object.keys(window.KixBlockRegistry||{})).size === Object.keys(window.KixBlockRegistry||{}).length, 'sem ops duplicados');
    check('70. Blocos não vazios', names.every(n=>String(n).trim().length>0), 'nomes válidos');
    check('71. Todos os parâmetros têm forma normalizável', names.length>0 && Object.values(CATEGORIES||{}).every(cat=>(cat.blocks||[]).every(b=>!b.p || Array.isArray(b.p))), 'parâmetros');
    check('72. Search exclui catálogo oculto', /HIDDEN_CATALOG_BLOCKS/.test(String(kixCollectSearchBlocks)), 'filtros de catálogo');
    check('73. Search deduplica por chave estável', /seen\.has\(dedupe\)/.test(String(kixCollectSearchBlocks)), 'dedupe');
    check('74. Drag mobile preserva touch-action controlado', /touch-action:\s*none/.test(styleText) && /forceFallback:\s*true/.test(String(renderScripts)), 'gesto de drag');
    check('75. Placeholder de drag continua invisível', /\.kix-sortable-placeholder \{ display:none !important; \}/.test(styleText), 'placeholder oculto');
    check('76. Ghost de drag não recebe contorno extra', /\.kix-sortable-ghost[\s\S]*box-shadow:none/.test(styleText), 'ghost limpo');
    check('77. Persistência continua disponível', typeof save === 'function' && /localStorage\.setItem\('kix_projects'/.test(String(save)), 'save + localStorage');
    check('78. Undo/redo continua exposto', !!window.KixBrickHistory && typeof window.KixBrickHistory.undo === 'function' && typeof window.KixBrickHistory.redo === 'function', 'histórico');
    check('79. Engine continua oferecendo self-test', typeof window.runKixSelfTest === 'function', 'self-test');
    check('80. Blocos nativos de posição reconhecem X/Y', isVisualPositionBlock({name:'Ir para X e Y',params:['x','y'],values:{x:0,y:0}}) && isVisualPositionBlock({name:'Deslizar em X segundos até X: Y:',params:['segundos','x','y'],values:{x:0,y:0}}), 'classificação');
    check('81. Ação visual só aparece para bloco de posição', !!document.getElementById('ctx-visual-position-btn'), 'ação contextual');
    check('82A. Seletor de variável não cai no abridor genérico de fórmula', /suppressDropdown \|\| variableSelector/.test(String(buildBlockLabelHtml)), 'variável → dropdown dedicado');
    check('82B. Clique delegado de variável tem fallback para o dropdown', /dataset\?\.variableSelector === '1'/.test(document.documentElement.innerHTML) && /openKixVariableDropdown\(imageTarget\)/.test(document.documentElement.innerHTML), 'guard + fallback');
    check('82C. Eventos do dropdown ficam isolados do Brick', /pointerup/.test(String(openKixVariableDropdown)) && /mousedown/.test(String(openKixVariableDropdown)) && /mouseup/.test(String(openKixVariableDropdown)) && /click/.test(String(openKixVariableDropdown)), 'stopPropagation');
    check('82D. Scroll interno não fecha o seletor de variável', /kix-variable-inline-dropdown/.test(document.documentElement.innerHTML) && /target\.closest/.test(document.documentElement.innerHTML), 'scroll isolado');
    check('82. Engine expõe conversão de palco para mundo', typeof window.KixEngine?.stagePointToWorld === 'function', 'coordenadas de palco');
    check('83. Modo de tela limpa possui controle de estado', typeof setPlayCleanMode === 'function' && typeof playChromeHidden === 'boolean', 'chrome');
    check('84. Tela limpa não remove a camada de entrada do jogo', !!document.getElementById('kix-runtime-input-layer'), 'UI de jogo preservada');
    check('85. Toolbar de colocação visual existe', !!document.getElementById('visual-position-toolbar') && !!document.getElementById('visual-position-confirm'), 'fluxo visual');
    check('86. API de plugins ganhou superfícies úteis', !!window.KixPluginRuntime && typeof window.KixPluginRuntime.executeBlock === 'function' && typeof window.KixPluginRuntime.normalize === 'function' && typeof window.KixPluginRuntime.install === 'function' && typeof window.KixPluginRuntime.attachApp === 'function', 'runtime carregado');
    check('87. Colocação visual diferencia X, Y e X/Y', visualPositionBlockMode({name:'Ir para X e Y',params:['x','y']}) === 'xy' && visualPositionBlockMode({name:'Definir X para',params:['x']}) === 'x' && visualPositionBlockMode({name:'Definir Y para',params:['y']}) === 'y', 'modos de posição');
    check('87. Colocação visual diferencia X, Y e X/Y', visualPositionBlockMode({name:'Ir para X e Y',params:['x','y']}) === 'xy' && visualPositionBlockMode({name:'Definir X para',params:['x']}) === 'x' && visualPositionBlockMode({name:'Definir Y para',params:['y']}) === 'y', 'modos de posição');
    check('88. Set X/Y usa o parâmetro persistido correto', visualPositionBlockValues({name:'Definir X para',values:{valor:12}}).x === 12 && visualPositionBlockValues({name:'Definir Y para',values:{valor:-8}}).y === -8, 'valor de posição');
    check('89. Colocação visual mantém eixo fixo em Set X/Y', /mode === 'y' \?/.test(String(bindVisualPositionPointer)) && /mode === 'x' \?/.test(String(bindVisualPositionPointer)), 'restrição por eixo');
        check('90. Botão de reativar fica oculto até o modo menu oculto ser ativado', /btn-play-restore-ui\.hidden\{display:none !important;\}/.test(document.documentElement.innerHTML) && /restore\.classList\.toggle\('hidden', !playChromeHidden\)/.test(String(setPlayCleanMode)), 'estado inicial oculto');
check('90. Tirar menu oferece restauração por botão e Back', !!document.getElementById('play-more-clean') && !!document.getElementById('btn-play-restore-ui') && /playCleanHistoryActive/.test(String(setPlayCleanMode)) && /history\.pushState/.test(String(setPlayCleanMode)) && /history\.back/.test(String(setPlayCleanMode)) && /playChromeHidden/.test(String(handleKixSystemBack)) && /setPlayCleanMode\(false\)/.test(String(handleKixSystemBack)) && /addEventListener\('popstate'/.test(document.documentElement.innerHTML), 'clean mode + botão + Back');
    check('91. Tela limpa preserva camada de entrada do jogo', /kix-runtime-input-layer/.test(String(setPlayCleanMode)), 'input layer');
    check('92. Resultado possui tela central', !!$('formula-result-screen') && !!$('formula-result-screen-val') && !!$('formula-result-screen-close'), 'overlay de resultado');
    check('93. Botão Calcular possui SVG de calculadora', !!document.querySelector('#formula-keypad .key-calculate svg'), 'ícone SVG');
    check('94. Colar substitui fórmula sem depender de formulaFresh', /setFormulaValue\(text, \{fresh:false, record:true, sync:true\}\)/.test(String(pasteFormulaFromClipboard)), 'paste replace');
    check('95. Resultado usa o interpretador da engine', /KixEngine\?\.evalFormula/.test(String(evaluateFormulaNow)), 'evalFormula');
    const probeCtx = {vars:{'vidas atuais':7,pontos:5},globals:{}};
    const probePrepared = replaceFormulaVariablesForEngine('vidas atuais + pontos', probeCtx);
    const probeValue = window.KixEngine?.evalFormula?.(probePrepared.expression, {vars:probePrepared.vars,globals:probePrepared.globals});
    check('96. Variáveis com nome composto podem ser somadas', probeValue === 12, 'contexto de cálculo');
    check('107. Total de checks fechado em 107', results.length === 107, 'contagem final');
    const ok = results.length === 107 && results.every(r=>r.ok);
    console.table(results);
    return {ok, results};
  } catch(e) {
    results.push({name:'Execução do self-test',ok:false,detail:e.message||String(e)});
    while (results.length < 51) results.push({name:(results.length+1)+'. Check indisponível',ok:false,detail:'teste interrompido'});
    return {ok:false,results};
  }
}

window.runKixSelfTest = runKixSelfTest;

function rotatePlayScreen() {
  try {
    // Manual stage preview only: the project-driven Activity orientation remains authoritative.
    // We only change the presentation ratio used by the play stage. The app UI
    // (top bar, menus, editor and system window) remains in the user's orientation.
    const current = String(document.documentElement.dataset.kixRotation || '').toLowerCase() === 'landscape';
    const type = current ? 'portrait' : 'landscape';
    document.documentElement.dataset.kixRotation = type;
    try { KixEngine?.setStagePresentationOrientation?.(type); } catch (_) {}
    try { KixEngine?.syncStageLayout?.(); } catch (_) {}
    try { window.KixOrientationGuard?.refresh?.(); } catch (_) {}
    toast(type === 'landscape' ? 'Palco horizontal · aplicativo permanece na orientação atual' : 'Palco vertical · aplicativo permanece na orientação atual');
  } catch (e) { console.warn('rotatePlayScreen', e); toast('Não foi possível alternar a orientação do palco'); }
}

function updateGlobalsPanel() {
  const panel = $('globals-panel');
  if (!panel) return;
  const vars = currentProject?.vars || globals;
  const keys = Object.keys(vars);
  panel.innerHTML = keys.length
    ? keys.map(k => `<div class="flex justify-between py-1"><span class="text-[#888]">${k}</span><span class="font-mono text-[#34D399]">${vars[k]}</span></div>`).join('')
    : '<p class="text-[#666] text-sm">Nenhuma variável global</p>';
}

// ===== PROJECT COMPATIBILITY =====
const KIX_CATROID_PLUGIN_ID = 'kix.catroid.compat';
const KIX_CATROID_PLUGIN_VERSION = '1.1.0';
const KIX_PROJECT_COMPAT_SCHEMA = 'kix-project-compat-v1';
function kixProjectLooksCatrobat(project) {
  const p = project && typeof project === 'object' ? project : {};
  return !!(p.catrobatImport || p.catrobatStage || p.catrobat || p.sourceFormat === 'catrobat' || p.sourceFormat === 'newtrobat');
}
function ensureKixCatroidProjectCompatibility(project) {
  if (!project || typeof project !== 'object' || !kixProjectLooksCatrobat(project)) return false;
  let changed = false;
  const previous = Array.isArray(project.plugins) ? project.plugins : [];
  const filtered = previous.filter(p => String(p?.id || '') !== KIX_CATROID_PLUGIN_ID);
  if (filtered.length !== previous.length) changed = true;
  filtered.push({id:KIX_CATROID_PLUGIN_ID,version:KIX_CATROID_PLUGIN_VERSION,enabled:true,builtin:true,scope:'project',role:'catroid-compat',capabilities:['catrobat-import','newtrobat-import','pocket-code-import','user-defined-bricks','user-defined-receivers','user-defined-input-preservation','nested-control-preservation','source-metadata-preservation']});
  if (!Array.isArray(project.plugins) || project.plugins.length !== filtered.length || JSON.stringify(project.plugins) !== JSON.stringify(filtered)) changed = true;
  project.plugins = filtered;
  const compat = project.compatibility && typeof project.compatibility === 'object' ? project.compatibility : {};
  const capabilities = [
    'catrobat-import','newtrobat-import','pocket-code-import','user-defined-bricks',
    'user-defined-receivers','user-defined-input-preservation','nested-control-preservation',
    'source-metadata-preservation'
  ];
  const requirement = {id:KIX_CATROID_PLUGIN_ID,version:KIX_CATROID_PLUGIN_VERSION,enabled:true,builtin:true,scope:'project',role:'catroid-compat',capabilities};
  const nextCompat = Object.assign({}, compat, {
    schema: KIX_PROJECT_COMPAT_SCHEMA,
    requiredPlugins: [requirement],
    formats: Array.from(new Set([...(Array.isArray(compat.formats)?compat.formats:[]),'catrobat','newtrobat']))
  });
  if (JSON.stringify(compat) !== JSON.stringify(nextCompat)) changed = true;
  project.compatibility = nextCompat;
  return changed;
}
window.KixCatroidCompatibility = Object.freeze({
  pluginId: KIX_CATROID_PLUGIN_ID,
  pluginVersion: KIX_CATROID_PLUGIN_VERSION,
  schema: KIX_PROJECT_COMPAT_SCHEMA,
  isCatrobatProject: kixProjectLooksCatrobat,
  ensureProject: ensureKixCatroidProjectCompatibility
});

// ===== EXPORT =====
function normalizeKixProject(input) {
  let p = input && input.project ? input.project : input;
  if (!p || typeof p !== 'object') throw new Error('Projeto inválido');
  // Accept current Kix, legacy Kix wrappers and common visual-editor aliases.
  if (!Array.isArray(p.scenes)) {
    const actors = p.actors || p.objects || p.sprites || p.elements;
    if (Array.isArray(actors)) p = Object.assign({}, p, { scenes: [{ name: p.sceneName || 'Cena 1', actors }] });
    else if (p.scene && typeof p.scene === 'object') p = Object.assign({}, p, { scenes: [p.scene] });
    else if (Array.isArray(p.sceneList)) p = Object.assign({}, p, { scenes: p.sceneList });
  }
  if (!Array.isArray(p.scenes)) throw new Error('Projeto sem cenas');

  const out = JSON.parse(JSON.stringify(p));
  out.kixVersion = Number(out.kixVersion || 2);
  out.name = String(out.name || 'Projeto Kix');
  out.vars = (out.vars && typeof out.vars === 'object') ? out.vars : {};
  ensureKixCatroidProjectCompatibility(out);
  out.dataDefinitions = Array.isArray(out.dataDefinitions) ? out.dataDefinitions.map((d,i)=>({
    id: String(d?.id || ('data_' + i + '_' + Math.random().toString(36).slice(2,8))),
    name: String(d?.name || ('Dado ' + (i + 1))),
    value: d?.value ?? 0,
    scope: ['object','project','network'].includes(String(d?.scope||'')) ? String(d.scope) : 'project',
    valuesByActor: (d?.valuesByActor && typeof d.valuesByActor==='object') ? d.valuesByActor : {},
    createdAt: Number(d?.createdAt || Date.now()) || Date.now(),
    updatedAt: Number(d?.updatedAt || Date.now()) || Date.now()
  })) : [];
  out.customBricks = Array.isArray(out.customBricks) ? out.customBricks.map((x,i)=>kixNormalizeCustomBrickDefinition(x,i)).filter(Boolean) : [];
  out.tileSets = Array.isArray(out.tileSets) ? out.tileSets.map((ts,i)=>({
    id:String(ts?.id||('tileset_'+i+'_'+Math.random().toString(36).slice(2,7))), name:String(ts?.name||('Tileset '+(i+1))), image:String(ts?.image||ts?.src||''), cellW:Math.max(4,Number(ts?.cellW||ts?.cellSize?.w||32)||32), cellH:Math.max(4,Number(ts?.cellH||ts?.cellSize?.h||32)||32), columns:Math.max(1,Number(ts?.columns||0)||0), rows:Math.max(1,Number(ts?.rows||0)||0), favorites:Array.isArray(ts?.favorites)?ts.favorites.map(Number).filter(Number.isFinite):[], tileNames:ts?.tileNames&&typeof ts.tileNames==='object'?ts.tileNames:{}, properties:ts?.properties&&typeof ts.properties==='object'?ts.properties:{}
  })) : [];

  out.scenes = out.scenes.map((scene, si) => {
    scene = scene || {};
    scene.name = String(scene.name || ('Cena ' + (si + 1)));
    scene.tilemaps = Array.isArray(scene.tilemaps) ? scene.tilemaps : [];
    scene.tilemaps.forEach((tm,ti)=>{ tm.id=String(tm?.id||('tilemap_'+si+'_'+ti)); tm.name=String(tm?.name||('Mapa '+(ti+1))); tm.tileSetId=String(tm?.tileSetId||''); tm.cellSize=tm?.cellSize&&typeof tm.cellSize==='object'?{w:Math.max(4,Number(tm.cellSize.w||32)||32),h:Math.max(4,Number(tm.cellSize.h||32)||32)}:{w:32,h:32}; tm.origin=tm?.origin&&typeof tm.origin==='object'?{x:Number(tm.origin.x)||0,y:Number(tm.origin.y)||0}:{x:0,y:0}; tm.layers=Array.isArray(tm.layers)&&tm.layers.length?tm.layers:[{id:'layer_base_'+tm.id,name:'Base',visible:true,cells:{}}]; tm.layers.forEach((l,li)=>{l.id=String(l?.id||('layer_'+tm.id+'_'+li));l.name=String(l?.name||('Camada '+(li+1)));l.visible=l?.visible!==false;l.cells=l?.cells&&typeof l.cells==='object'?l.cells:{}}); ['collisionLayers','navigationLayers','occlusionLayers'].forEach(k=>{tm[k]=Array.isArray(tm[k])?tm[k]:[];}); });
    scene.particleEmitters = Array.isArray(scene.particleEmitters) ? scene.particleEmitters : [];
    scene.particleEmitters.forEach((em,ei)=>{em.id=String(em?.id||('particle_'+si+'_'+ei));em.name=String(em?.name||('Efeito '+(ei+1)));em.amount=Math.max(1,Math.min(1000,Number(em?.amount||80)||80));em.lifetime=Math.max(.05,Number(em?.lifetime||1)||1);em.speed=Number(em?.speed||80)||80;em.direction=Number(em?.direction||90)||90;em.spread=Math.max(0,Number(em?.spread||60)||60);em.gravity=Number(em?.gravity||0)||0;em.size=Math.max(1,Number(em?.size||8)||8);em.color=String(em?.color||'#34D399');em.emissionShape=String(em?.emissionShape||'point');em.loop=em?.loop!==false;em.oneShot=!!em?.oneShot;em.texture=String(em?.texture||'');em.animation=em?.animation&&typeof em.animation==='object'?em.animation:{};em.advanced=em?.advanced&&typeof em.advanced==='object'?em.advanced:{};});
    if (!Array.isArray(scene.actors)) scene.actors = Array.isArray(scene.objects) ? scene.objects : (Array.isArray(scene.sprites) ? scene.sprites : []);
    scene.actors.forEach((a, ai) => {
      if (!a || typeof a !== 'object') return;
      a.name = String(a.name || ('Objeto ' + (ai + 1)));
      a.scripts = a.scripts || a.code || a.blocks || { stacks: [], blocks: {} };
      if (!Array.isArray(a.scripts) && window.KixEngine?.scriptsToFlat) {
        try { a.scripts = window.KixEngine.scriptsToFlat(a.scripts); } catch (_) { a.scripts = []; }
      }
      if (!Array.isArray(a.scripts)) a.scripts = [];
      const legacyLooks = a.looks || a.costumes || a.appearances || a.images;
      a.looks = Array.isArray(legacyLooks) ? legacyLooks.map(x => typeof x === 'string' ? x : (x?.dataUrl || x?.src || x?.image || x)) : [];
      const legacySounds = a.sounds || a.audio || a.soundsList;
      a.sounds = Array.isArray(legacySounds) ? legacySounds : [];
      if (a.collisionShape) {
        a.collisionShape.type = ['rect','circle','pixel'].includes(a.collisionShape.type) ? a.collisionShape.type : 'rect';
        a.collisionShape.enabled = a.collisionShape.enabled !== false;
      }
    });
    return scene;
  });
  return out;
}

function exportKix() {
  try {
    if (!currentProject) { toast('Nenhum projeto'); return; }
    syncActorToProject();
    const project = normalizeKixProject(currentProject);
    project.kixVersion = 2;
    project.engine = { name: 'Kix Engine', version: KIX_APP_VERSION };
    const payload = JSON.stringify(project, null, 2);
    const filename = (project.name || 'projeto').replace(/[\\/:*?"<>|]/g, '_') + '.kix';
    // Android WebView has no reliable browser download surface for blob: URLs.
    // Use the native bridge when present, while retaining the browser fallback.
    if (window.Android && typeof window.Android.beginFile === 'function') {
      const bytes = new TextEncoder().encode(payload);
      const chunkSize = 48 * 1024;
      let binary = '';
      window.Android.beginFile(filename, 'application/x-kix+json');
      for (let i = 0; i < bytes.length; i += chunkSize) {
        const chunk = bytes.subarray(i, i + chunkSize);
        binary = '';
        for (let j = 0; j < chunk.length; j++) binary += String.fromCharCode(chunk[j]);
        window.Android.appendFileChunk(btoa(binary));
      }
      window.Android.finishFile();
      toast('Exportação .kix iniciada');
      return;
    }
    const blob = new Blob([payload], { type: 'application/x-kix+json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    toast('Projeto .kix exportado');
  } catch (e) { console.error('exportKix', e); toast('Erro ao exportar .kix: ' + (e.message || 'arquivo inválido')); }
}

function loadFileAsDataURL(file) {
  return new Promise(res => { const r = new FileReader(); r.onload = e => res(e.target.result); r.readAsDataURL(file); });
}


// ===== INIT =====


// ===== Block context (global — works even if init partially fails) =====
let ctxBlockIdx = null;
let blockContextBarrierBound = false;

function ensureBlockContextBarrier() {
  if (blockContextBarrierBound) return;
  blockContextBarrierBound = true;
  const isOpen = () => {
    const ov = document.getElementById('block-ctx-overlay');
    return !!(ov && ov.classList.contains('open'));
  };
  const isActionTarget = (target) => {
    try { return !!(target && target.closest && target.closest('#block-ctx-actions')); } catch (_) { return false; }
  };
  const isBackdropTarget = (target, ov) => target === ov;
  const block = (e) => {
    if (!isOpen()) return;
    const ov = document.getElementById('block-ctx-overlay');
    if (!ov) return;
    if (isActionTarget(e.target)) return;
    // Preview/bubble and the gray backdrop are intentionally non-interactive
    // except that a tap on the gray backdrop closes the menu.
    if (isBackdropTarget(e.target, ov) && (e.type === 'pointerup' || e.type === 'touchend' || e.type === 'click')) {
      if (e.cancelable) e.preventDefault();
      e.stopImmediatePropagation();
      closeBlockContext();
      return;
    }
    if (e.cancelable && /^(pointerdown|pointermove|pointerup|pointercancel|touchstart|touchmove|touchend|touchcancel|mousedown|mouseup|click)$/.test(e.type)) e.preventDefault();
    e.stopImmediatePropagation();
  };
  ['pointerdown','pointermove','pointerup','pointercancel','touchstart','touchmove','touchend','touchcancel','mousedown','mouseup','click'].forEach(type => {
    document.addEventListener(type, block, {capture:true, passive:false});
  });
}

function openBlockContext(name, color, idx, hasFormula) {
  restoreCurrentActorContext();
  ctxBlockIdx = idx;
  const ov = document.getElementById('block-ctx-overlay');
  if (!ov) return;
  const bubble = document.getElementById('block-ctx-bubble');
  if (bubble) bubble.textContent = (typeof BLOCK_HELP !== 'undefined' && BLOCK_HELP[name]) || 'A descrição para este bloco ainda não foi adicionada.';
  const preview = document.getElementById('block-ctx-preview');
  if (preview) {
    preview.innerHTML = '';
    const b = document.createElement('div');
    b.className = 'pc-block';
    b.style.background = color || '#666';
    b.innerHTML = '<span>' + (name || '') + '</span>';
    preview.appendChild(b);
  }
  const formBtn = document.getElementById('ctx-formula-btn');
  if (formBtn) formBtn.style.display = hasFormula ? '' : 'none';
  ov.classList.add('open');
  ov.style.display = 'flex';
  // A single document-level capture barrier owns the modal gesture while open.
  // Only the action panel is interactive; the gray backdrop only closes the panel.
  ensureBlockContextBarrier();
  // Keep the action wording synchronized with the selected block state.
  const selectedScript = currentActor && Array.isArray(currentActor.scripts) ? currentActor.scripts[idx] : null;
  const disableAction = document.querySelector('#block-ctx-actions .ctx-action[data-act="disable"]');
  if (disableAction) disableAction.textContent = selectedScript && selectedScript.disabled ? 'Ativar bloco' : 'Desativar bloco';
  const visualAction = document.getElementById('ctx-visual-position-btn');
  if (visualAction) visualAction.style.display = isVisualPositionBlock(selectedScript) ? 'flex' : 'none';
  // Bind actions every time menu opens (reliable)
  document.querySelectorAll('#block-ctx-actions .ctx-action').forEach(el => {
    el.onclick = function (e) {
      e.preventDefault();
      e.stopPropagation();
      handleCtxAction(el.dataset.act);
    };
  });
}

function closeBlockContext() {
  const ov = document.getElementById('block-ctx-overlay');
  if (ov) {
    ov.classList.remove('open');
    ov.style.display = 'none';
  }
  ctxBlockIdx = null;
}

function handleCtxAction(act) {
  try {
    if (!act) { closeBlockContext(); return; }
    restoreCurrentActorContext();
    if (currentActor && currentActor.scripts && currentActor.scripts.blocks && window.KixEngine) {
      currentActor.scripts = KixEngine.scriptsToFlat(currentActor.scripts);
    }
    if (!currentActor) { toast('Nenhum objeto'); closeBlockContext(); return; }
    if (!Array.isArray(currentActor.scripts)) currentActor.scripts = [];

    if (act === 'visual-position') {
      return openVisualPositionPlacement();
    } else if (act === 'delete') {
      if (ctxBlockIdx == null || ctxBlockIdx < 0 || ctxBlockIdx >= currentActor.scripts.length) {
        toast('Bloco não encontrado');
      } else {
        const scripts = currentActor.scripts;
        const target = scripts[ctxBlockIdx];
        let deleteEnd = ctxBlockIdx;

        // A loop is a single visual unit: deleting its header must also delete
        // every block up to its explicit Fim de loop. Nested loops are included
        // naturally because their blocks are inside the same flat range.
        if (target && isKixVisualControl(target.name)) {
          const isLoopDelete = isKixVisualLoop(target.name);
          const explicit = isLoopDelete ? target.loopBoundaryExplicit === true : target.ifBoundaryExplicit === true;
          const endId = explicit ? String(isLoopDelete ? (target.loopEndId ?? '') : (target.ifEndId ?? '')) : '';
          if (endId) {
            const found = scripts.findIndex((b, i) => i > ctxBlockIdx && b && String(b.id || '') === endId);
            if (found > ctxBlockIdx) deleteEnd = found;
          } else if (explicit) {
            deleteEnd = ctxBlockIdx; // intentionally empty loop
          } else {
            // Legacy fallback, kept only for files that have not yet acquired
            // explicit boundaries.
            for (let i = ctxBlockIdx + 1; i < scripts.length; i++) {
              const n = scripts[i];
              if (!n) continue;
              const t = String(n.name || '');
              if (/^Quando\s/i.test(t) || isKixVisualControl(t)) break;
              deleteEnd = i;
            }
          }
        }

        const count = deleteEnd - ctxBlockIdx + 1;

        // Before removing the range, repair every surviving loop whose
        // explicit end block is part of that range. Without this step,
        // deleting the last block inside a loop leaves loopEndId dangling;
        // ensureFlatLoopBoundaries() then correctly treats the loop as empty,
        // which makes all previously surviving body blocks render outside it.
        repairLoopBoundariesAfterRemoval(scripts, ctxBlockIdx, deleteEnd);
        scripts.splice(ctxBlockIdx, count);
        try { window.KixEngine?.pruneTextForActor?.(currentActor); } catch (_) {}
        save();
        renderScripts();
        toast(count > 1 ? 'Loop e blocos internos excluídos' : 'Bloco excluído');
      }
    } else if (act === 'copy') {
      if (ctxBlockIdx != null && currentActor.scripts[ctxBlockIdx]) {
        const c = JSON.parse(JSON.stringify(currentActor.scripts[ctxBlockIdx]));
        if (window.KixEngine) c.id = KixEngine.newId();
        currentActor.scripts.splice(ctxBlockIdx + 1, 0, c);
        save(); renderScripts(); toast('Bloco copiado');
      }
    } else if (act === 'cut') {
      if (ctxBlockIdx != null && currentActor.scripts[ctxBlockIdx]) {
        window._cutBlock = currentActor.scripts.splice(ctxBlockIdx, 1)[0];
        try { window.KixEngine?.pruneTextForActor?.(currentActor); } catch (_) {}
        save(); renderScripts(); toast('Recortado');
      }
    } else if (act === 'disable') {
      const s = currentActor.scripts[ctxBlockIdx];
      if (s) { s.disabled = !s.disabled; save(); renderScripts(); toast(s.disabled ? 'Desativado' : 'Ativado'); }
    } else if (act === 'help') {
      const n = currentActor.scripts[ctxBlockIdx]?.name;
      toast((n && BLOCK_HELP[n]) || 'Sem ajuda cadastrada');
    } else if (act === 'info') {
      toast('#' + ctxBlockIdx + ' · ' + (currentActor.scripts[ctxBlockIdx]?.name || ''));
    } else if (act === 'formula') {
      closeBlockContext();
      const params = document.querySelectorAll('#script-blocks .formula-open, #script-blocks .param');
      if (params.length) openFormula(params[Math.min(ctxBlockIdx || 0, params.length - 1)]);
      return;
    } else if (act === 'move') {
      toast('Segure e arraste o bloco na lista');
    }
  } catch (err) {
    console.error('handleCtxAction', err);
    toast('Erro ao processar ação');
  }
  closeBlockContext();
}
window.handleCtxAction = handleCtxAction;
window.openBlockContext = openBlockContext;
window.closeBlockContext = closeBlockContext;


// === Delegated clicks (survive re-renders) ===
document.addEventListener('click', function (e) {
  const t = e.target.closest('[id], .tab-btn, .ctx-action, .formula-cat, .sheet-item');
  if (!t) return;
  // tab buttons
  if (t.classList.contains('tab-btn') && t.dataset.tab) {
    switchTab(t.dataset.tab);
  }
});


/* ============================================================================
 * Catrobat / Pocket Code / NewCatroid importer
 * Offline ZIP + code.xml reader. No network, no third-party runtime dependency.
 * Designed for analysis-first import: preserve scene/object/script/brick metadata,
 * resolve media by scene folder before basename fallback, and never discard
 * unsupported brick types.
 * ========================================================================== */
const KIX_CATROBAT_VERSION = '1.0.0';

function catEsc(v) {
  return String(v == null ? '' : v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function catBaseName(p) {
  return String(p || '').replace(/\\/g,'/').split('/').pop() || '';
}
function catNormPath(p) {
  return String(p || '').replace(/\\/g,'/').replace(/^\.?\//,'').replace(/\/+/g,'/').trim().toLowerCase();
}
function catExt(p) {
  const m = String(p || '').toLowerCase().match(/\.([a-z0-9]+)$/);
  return m ? m[1] : '';
}
function catMime(p) {
  const ext = catExt(p);
  const m = {
    png:'image/png', jpg:'image/jpeg', jpeg:'image/jpeg', gif:'image/gif', webp:'image/webp',
    bmp:'image/bmp', svg:'image/svg+xml', avif:'image/avif',
    mp3:'audio/mpeg', wav:'audio/wav', ogg:'audio/ogg', opus:'audio/ogg', m4a:'audio/mp4',
    aac:'audio/aac', flac:'audio/flac', webm:'audio/webm', ttf:'font/ttf', otf:'font/otf',
    woff:'font/woff', woff2:'font/woff2', ttc:'font/collection'
  };
  return m[ext] || 'application/octet-stream';
}
function catReadU16(dv,o){ return dv.getUint16(o,true); }
function catReadU32(dv,o){ return dv.getUint32(o,true); }

async function catReadArrayBuffer(file) {
  if (file && typeof file.arrayBuffer === 'function') return await file.arrayBuffer();
  return await new Promise((resolve,reject)=>{
    const r = new FileReader();
    r.onload=()=>resolve(r.result);
    r.onerror=()=>reject(r.error||new Error('Falha ao ler arquivo'));
    r.readAsArrayBuffer(file);
  });
}

function catFindEOCD(bytes) {
  const dv = new DataView(bytes);
  const min = Math.max(0, bytes.byteLength - 0x10000 - 22);
  for (let o = bytes.byteLength - 22; o >= min; o--) {
    if (o >= 0 && catReadU32(dv,o) === 0x06054b50) return o;
  }
  return -1;
}
function catDecodeName(bytes, offset, len, utf8) {
  const slice = new Uint8Array(bytes, offset, len);
  try { return new TextDecoder(utf8 ? 'utf-8' : 'utf-8', {fatal:false}).decode(slice); }
  catch (_) { return Array.from(slice).map(b=>String.fromCharCode(b)).join(''); }
}
function catSafeZipName(name) {
  const n = String(name || '').replace(/\\/g,'/');
  const parts = n.split('/').filter(Boolean);
  if (parts.some(p => p === '..')) throw new Error('ZIP rejeitado: caminho inseguro');
  return parts.join('/');
}

function catZipIndex(arrayBuffer) {
  const bytes = arrayBuffer;
  const dv = new DataView(bytes);
  const eocd = catFindEOCD(bytes);
  if (eocd < 0) throw new Error('Arquivo não é um ZIP válido (EOCD ausente)');
  const disk = catReadU16(dv,eocd+4);
  const cdDisk = catReadU16(dv,eocd+6);
  const count = catReadU16(dv,eocd+10);
  const cdSize = catReadU32(dv,eocd+12);
  const cdOffset = catReadU32(dv,eocd+16);
  const commentLen = catReadU16(dv,eocd+20);
  if (disk !== 0 || cdDisk !== 0) throw new Error('ZIP multi-disco não suportado');
  if (count === 0xffff || cdSize === 0xffffffff || cdOffset === 0xffffffff) throw new Error('ZIP64 não suportado nesta versão offline');
  if (cdOffset + cdSize > bytes.byteLength) throw new Error('Diretório central do ZIP está truncado');
  const entries = [];
  let o = cdOffset;
  let utf8Names = 0, nonUtf8Names = 0;
  for (let i=0;i<count;i++) {
    if (o + 46 > bytes.byteLength || catReadU32(dv,o) !== 0x02014b50) throw new Error('Entrada de diretório ZIP inválida na posição '+o);
    const flags = catReadU16(dv,o+8);
    const method = catReadU16(dv,o+10);
    const crc = catReadU32(dv,o+16);
    const csize = catReadU32(dv,o+20);
    const usize = catReadU32(dv,o+24);
    const nameLen = catReadU16(dv,o+28);
    const extraLen = catReadU16(dv,o+30);
    const commentLen2 = catReadU16(dv,o+32);
    const localOffset = catReadU32(dv,o+42);
    if (usize === 0xffffffff || csize === 0xffffffff || localOffset === 0xffffffff) throw new Error('ZIP64 não suportado em '+i);
    if (o+46+nameLen+extraLen+commentLen2 > bytes.byteLength) throw new Error('Entrada ZIP truncada');
    const name = catSafeZipName(catDecodeName(bytes,o+46,nameLen,!!(flags & 0x800)));
    const entry = {
      name, path:catNormPath(name), flags, method, crc:crc>>>0, compressedSize:csize>>>0,
      size:usize>>>0, localOffset:localOffset>>>0, directory:/\/$/.test(name), utf8:!!(flags&0x800),
      crcOk:null
    };
    if (entry.utf8) utf8Names++; else nonUtf8Names++;
    entries.push(entry);
    o += 46+nameLen+extraLen+commentLen2;
  }
  return {entries, bytes, stats:{entryCount:entries.length,utf8Names,nonUtf8Names,eocdComment:commentLen}};
}

function catCRC32(bytes) {
  let crc = 0xffffffff;
  const table = catCRC32.table || (catCRC32.table = (() => {
    const t = new Uint32Array(256);
    for (let n=0;n<256;n++) { let c=n; for(let k=0;k<8;k++) c=(c&1)?(0xedb88320^(c>>>1)):(c>>>1); t[n]=c>>>0; }
    return t;
  })());
  const u = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  for (let i=0;i<u.length;i++) crc = table[(crc^u[i])&255] ^ (crc>>>8);
  return (crc ^ 0xffffffff) >>> 0;
}

async function catExtractZipEntry(zip, entry) {
  if (entry.directory) return new Uint8Array();
  const dv = new DataView(zip.bytes);
  const lo = entry.localOffset;
  if (lo + 30 > zip.bytes.byteLength || catReadU32(dv,lo) !== 0x04034b50) throw new Error('Cabeçalho local ZIP inválido: '+entry.name);
  const nameLen = catReadU16(dv,lo+26), extraLen = catReadU16(dv,lo+28);
  const dataStart = lo + 30 + nameLen + extraLen;
  const dataEnd = dataStart + entry.compressedSize;
  if (dataEnd > zip.bytes.byteLength) throw new Error('Dados truncados: '+entry.name);
  if (entry.flags & 0x1) throw new Error('Entrada criptografada não suportada: '+entry.name);
  const comp = new Uint8Array(zip.bytes, dataStart, entry.compressedSize);
  let out;
  if (entry.method === 0) {
    out = new Uint8Array(comp);
  } else if (entry.method === 8) {
    if (typeof DecompressionStream === 'undefined') throw new Error('Este WebView não oferece descompressão ZIP offline');
    let stream;
    try { stream = new Blob([comp]).stream().pipeThrough(new DecompressionStream('deflate-raw')); }
    catch (_) {
      stream = new Blob([comp]).stream().pipeThrough(new DecompressionStream('deflate'));
    }
    out = new Uint8Array(await new Response(stream).arrayBuffer());
  } else {
    throw new Error('Método ZIP não suportado ('+entry.method+'): '+entry.name);
  }
  if (entry.size !== out.byteLength) throw new Error('Tamanho extraído divergente: '+entry.name+' ('+out.byteLength+' != '+entry.size+')');
  entry.crcOk = (catCRC32(out) === (entry.crc>>>0));
  if (!entry.crcOk) throw new Error('CRC inválido: '+entry.name);
  return out;
}
function catText(bytes) {
  try { return new TextDecoder('utf-8', {fatal:false}).decode(bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes)); }
  catch (_) { return Array.from(bytes).map(b=>String.fromCharCode(b)).join(''); }
}
function catBytesToDataUrl(bytes,mime) {
  const u = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let binary='';
  const CH=0x6000;
  for(let i=0;i<u.length;i+=CH) binary += String.fromCharCode.apply(null, Array.from(u.subarray(i,i+CH)));
  return 'data:'+(mime||'application/octet-stream')+';base64,'+btoa(binary);
}
function catXmlChild(el, name) {
  if (!el) return null;
  for (const c of el.children || []) if (c.tagName === name) return c;
  return null;
}
function catXmlText(el,name,def='') {
  const c=catXmlChild(el,name);
  return c ? String(c.textContent||'').trim() : def;
}
function catFormulaText(el) {
  if (!el) return '';
  const type = catXmlText(el,'type','');
  const value = catXmlText(el,'value','');
  const left = catXmlChild(el,'leftChild');
  const right = catXmlChild(el,'rightChild');
  const more = el.querySelectorAll ? Array.from(el.children).filter(c=>c.tagName==='additionalChildren') : [];
  const op = value;
  const map = {
    PLUS:'+',MINUS:'-',MULT:'*',DIVIDE:'/',MOD:'%',POWER:'^',
    EQUAL:'=',NOT_EQUAL:'!=',GREATER_THAN:'>',GREATER_OR_EQUAL:'>=',SMALLER_THAN:'<',SMALLER_OR_EQUAL:'<=',
    AND:'&&',OR:'||',XOR:'xor'
  };
  const atom=(node)=>{
    if(!node) return '';
    const t=catXmlText(node,'type','');
    const v=catXmlText(node,'value','');
    if(t==='STRING') return JSON.stringify(v);
    return catFormulaText(node);
  };
  if (left || right) {
    const l=left?catFormulaText(left):'', r=right?catFormulaText(right):'';
    if (type==='FUNCTION' && op==='JOIN' && left && right) return 'juntar('+atom(left)+','+atom(right)+')';
    if (!left && right && op==='MINUS') return '-('+r+')';
    if (left && right && map[op]) return '('+l+' '+map[op]+' '+r+')';
    if (right) return op+'('+r+')';
    if (left) return op+'('+l+')';
  }
  if (type==='USER_VARIABLE') return value || '';
  if (type==='USER_LIST') return value || '';
  return value || '';
}
function catFormula(brick, category, fallback='') {
  const list=catXmlChild(brick,'formulaList');
  if (!list) return fallback;
  const forms=Array.from(list.children||[]).filter(c=>c.tagName==='formula');
  const f=forms.find(x=>String(x.getAttribute('category')||'')===String(category));
  return f ? catFormulaText(f) : fallback;
}
function catFirstFormula(brick, categories, fallback='') {
  const keys=Array.isArray(categories) ? categories : [categories];
  for (const key of keys) {
    const v=catFormula(brick,key,null);
    if (v!==null && v!==undefined && String(v).trim()!=='') return v;
  }
  return fallback;
}
function catFormulaMap(script, category, fallback='') {
  const list=catXmlChild(script,'formulaMap');
  if (!list) return fallback;
  const forms=Array.from(list.children||[]).filter(c=>c.tagName==='formula');
  const f=forms.find(x=>String(x.getAttribute('category')||'')===String(category));
  return f ? catFormulaText(f) : fallback;
}
function catResolveXPathNode(contextNode, reference) {
  const ref = String(reference || '').trim();
  if (!ref || !contextNode) return null;
  try {
    const doc = contextNode.ownerDocument || (contextNode.nodeType === 9 ? contextNode : null);
    if (!doc || typeof doc.evaluate !== 'function') return null;
    const firstNodeType = (typeof XPathResult !== 'undefined' && XPathResult.FIRST_ORDERED_NODE_TYPE) || 9;
    return doc.evaluate(ref, contextNode, null, firstNodeType, null)?.singleNodeValue || null;
  } catch (_) { return null; }
}
function catUserVariableName(node) {
  if (!node) return '';
  try {
    // Catrobat identity is the VARIABLE NAME, never the value assigned by
    // "Set variable ... to ...". Some legacy serializers put <default> or
    // <value> beside the reference; those are initialization/value fields.
    const directName = node.querySelector?.(':scope > name, userVariable > name, default > name');
    if (directName && String(directName.textContent || '').trim()) return String(directName.textContent).trim();
    const nestedName = node.querySelector?.('userVariable > name');
    if (nestedName && String(nestedName.textContent || '').trim()) return String(nestedName.textContent).trim();
    const attrName = node.getAttribute?.('name');
    if (attrName && String(attrName).trim() && !/^xpath[:=]/i.test(String(attrName).trim())) return String(attrName).trim();
    // Resolve references before considering any textual fallback.
    const ref = node.getAttribute?.('reference') || node.getAttribute?.('ref') || '';
    if (ref) {
      const target = catResolveXPathNode(node, ref) || catResolveXPathNode(node.parentNode, ref);
      if (target && target !== node) {
        const resolved = catUserVariableName(target);
        if (resolved) return resolved;
      }
    }
    // A standalone <name> node is a valid identity carrier in programVariableList.
    if (String(node.tagName || '').toLowerCase() === 'name') {
      const text = String(node.textContent || '').trim();
      if (text && text.length <= 160 && !/[<>]/.test(text)) return text;
    }
    // Some exports encode the variable identity in a USER_VARIABLE formula.
    const vf = node.querySelector?.('formula[type="USER_VARIABLE"], formula');
    if (vf) {
      const type = String(vf.querySelector?.('type')?.textContent || '').trim();
      const value = String(vf.querySelector?.('value')?.textContent || '').trim();
      if (/USER_VARIABLE/i.test(type) && value && !/^[-+]?\d+(?:[.,]\d+)?$/.test(value)) return value;
    }
  } catch (_) {}
  return '';
}
function catUserVariable(brick) {
  try {
    if (!brick) return '';
    const candidates = Array.from(brick.querySelectorAll?.('userVariable') || []);
    for (const uv of candidates) {
      const inline = catUserVariableName(uv);
      if (inline) return inline;
      const ref = uv.getAttribute?.('reference') || uv.getAttribute?.('ref') || '';
      if (ref) {
        const target = catResolveXPathNode(uv, ref);
        const resolved = catUserVariableName(target);
        if (resolved) return resolved;
        const parent = uv.parentNode;
        const fallbackTarget = parent ? catResolveXPathNode(parent, ref) : null;
        const fallbackName = catUserVariableName(fallbackTarget);
        if (fallbackName) return fallbackName;
      }
    }
    // Some exports encode variable references in a formula rather than a userVariable node.
    const vf = Array.from(brick.querySelectorAll?.('formula') || []).find(f => String(f.querySelector?.('type')?.textContent || '').trim() === 'USER_VARIABLE');
    return vf ? String(vf.querySelector?.('value')?.textContent || '').trim() : '';
  } catch (_) { return ''; }
}
function catUserVariableInitialValue(node) {
  if (!node) return 0;
  try {
    let c = node;
    // Walk to the variable container so <name> and <default>/<value> siblings
    // are paired correctly. Never interpret the variable name itself as its value.
    for (let i = 0; i < 5 && c; i++, c = c.parentNode) {
      const tag = String(c.tagName || '').toLowerCase();
      if (tag === 'uservariable' || tag === 'variable' || tag === 'programvariable' || tag === 'default') {
        const valueNode = c.querySelector?.(':scope > default > value, :scope > default > initialValue, :scope > value, :scope > initialValue, :scope > initialIndex');
        if (valueNode && String(valueNode.textContent || '').trim() !== '') {
          const raw = String(valueNode.textContent).trim();
          const n = Number(raw.replace(',', '.'));
          return Number.isFinite(n) ? n : raw;
        }
      }
    }
    // Fallback for serializers that put the value in the parent/sibling tree.
    const valueNode = node.parentNode?.querySelector?.('default > value, default > initialValue, value, initialValue, initialIndex');
    if (valueNode && String(valueNode.textContent || '').trim() !== '') {
      const raw = String(valueNode.textContent).trim();
      const n = Number(raw.replace(',', '.'));
      return Number.isFinite(n) ? n : raw;
    }
    const attr = node.getAttribute?.('initialValue') || node.getAttribute?.('initialIndex');
    if (attr != null && String(attr).trim() !== '') {
      const raw = String(attr).trim(); const n = Number(raw.replace(',', '.'));
      return Number.isFinite(n) ? n : raw;
    }
  } catch (_) {}
  return 0;
}
function catTextVariableFormula(brick) {
  const list = catXmlChild(brick, 'formulaList');
  const textFormula = list ? Array.from(list.children || []).find(x => x.tagName === 'formula' && String(x.getAttribute('category') || '') === 'TEXT') : null;
  if (!textFormula) return '';
  return catFormulaText(textFormula);
}
function catTextVariableDisplayBlock(type, brick) {
  const variable = String(catUserVariable(brick) || '').replace(/^['"]|['"]$/g, '').trim();
  if (!variable) return null;
  const f = (keys, def='0') => catFirstFormula(brick, keys, def);
  const sourceText = catTextVariableFormula(brick);
  const textExpression = sourceText && !/^USER_VARIABLE$/i.test(String(brick.querySelector?.('formulaList > formula[category="TEXT"] > type')?.textContent || '')) && sourceText !== 'USER_VARIABLE'
    ? sourceText
    : variable;
  const sourceId = catXmlText(brick, 'brickId', '');
  const safeId = 'catvar_' + (sourceId || variable).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9_]+/g,'_').slice(0,48);
  const alignmentRaw = catXmlText(brick, 'alignmentSelection', '1');
  const alignment = alignmentRaw === '0' ? 'esquerda' : alignmentRaw === '2' ? 'direita' : 'centro';
  const values = {
    id: safeId,
    texto: textExpression || variable,
    tamanho: f(['SIZE','TEXT_SIZE','FONT_SIZE'], '32'),
    cor: f(['COLOR','TEXT_COLOR','COLOUR'], '#FFFFFF'),
    sombra: f(['SHADOW','TEXT_SHADOW','SHADOW_ENABLED'], 'nao'),
    x: f(['X_POSITION','X','POSITION_X'], '0'),
    y: f(['Y_POSITION','Y','POSITION_Y'], '0'),
    fonte: f(['FONT','FONT_FILE','FILE','FONTNAME','FONT_NAME'], '')
  };
  return catKixBlock('Criar texto facilitado', ['id','texto','tamanho','cor','sombra','x','y','fonte'], values, {
    sourceType: type, adapted: true, sourceMappedAutomatically: true, adaptedFrom: 'variable-display',
    worldText: true, boundVariable: variable, variableTextExpression: textExpression || variable, alignment
  });
}
function catReferenceIndex(ref, tag) {
  const m=String(ref||'').match(new RegExp(tag+'\\[(\\d+)\\]'));
  return m ? Math.max(1,Number(m[1])) : 1;
}
function catLookNameFromRef(brick, obj) {
  const look=catXmlChild(brick,'look');
  const ref=look?.getAttribute('reference')||'';
  const idx=catReferenceIndex(ref,'look');
  const list=catXmlChild(obj,'lookList');
  const arr=list?Array.from(list.children||[]).filter(x=>x.tagName==='look'):[];
  const x=arr[idx-1]||arr[0];
  return x ? (x.getAttribute('name') || x.getAttribute('fileName') || ('look '+idx)) : ('look '+idx);
}
function catSoundNameFromRef(brick, obj) {
  const sound=catXmlChild(brick,'sound');
  const ref=sound?.getAttribute('reference')||'';
  const idx=catReferenceIndex(ref,'sound');
  const list=catXmlChild(obj,'soundList');
  const arr=list?Array.from(list.children||[]).filter(x=>x.tagName==='sound'):[];
  const x=arr[idx-1]||arr[0];
  return x ? (x.getAttribute('name') || x.getAttribute('fileName') || ('sound '+idx)) : ('sound '+idx);
}
function catTargetName(brick) {
  const el=catXmlChild(brick,'destinationSprite') || catXmlChild(brick,'pointedObject');
  return el?.getAttribute('name') || el?.getAttribute('spriteId') || '';
}
function catChildBricks(brick, tag) {
  const host=catXmlChild(brick,tag);
  return host ? Array.from(host.children||[]).filter(x=>x.tagName==='brick') : [];
}
function catColor(name) {
  try {
    const target=String(name||'');
    if (/^Fim de loop$/i.test(target) || /^Fim de condição$/i.test(target) || /^Fim se$/i.test(target) || /^Senão$/i.test(target)) {
      const control = CATEGORIES?.controle || null;
      return control?.color || '#F99761';
    }
    for (const c of Object.values(CATEGORIES||{})) {
      const b=(c.blocks||[]).find(x=>x && x.n===target);
      if (b) return c.color || c.body || '#666';
    }
  } catch (_) {}
  return '#666';
}
function catUserDefinedBrickLabel(brick) {
  // Catroid serializes the label inside userDefinedBrickDataList on the actual
  // UserDefinedBrick node; some historical variants place it directly on the
  // brick. Resolve both without inventing a second data model.
  const directNode = catXmlChild(brick,'userDefinedBrickLabel');
  if (directNode) {
    const direct = catXmlChild(directNode,'label');
    const value = String(direct ? direct.textContent : directNode.textContent || '').trim();
    if (value) return value;
  }
  try {
    const nested = brick?.querySelector?.('userDefinedBrickDataList userDefinedBrickLabel label');
    const value = String(nested?.textContent || '').trim();
    if (value) return value;
  } catch (_) {}
  return '';
}
function catUserDefinedBrickId(brick) {
  return String(catXmlText(brick,'userDefinedBrickID','')).trim();
}

function catKixBlock(name, params, values, extra) {
  const b={id:kixStableId('cat'),name:String(name||'Catrobat'),params:Array.isArray(params)?params:[],values:values||{},color:catColor(name),disabled:!!(extra&&extra.disabled),catrobat:extra||undefined};
  b.opcode='catrobat_'+String(name||'block').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'_').slice(0,80);
  return b;
}

const KIX_CATROBAT_MAP = {
  SceneStartBrick:['Mudar para cena',['cena'],b=>({cena:catXmlText(b,'sceneToStart','')})],
  NoteBrick:['Nota',['texto'],b=>({texto:catFormula(b,'NOTE','')})],
  WaitBrick:['Esperar X segundos',['segundos'],b=>({segundos:catFormula(b,'TIME_TO_WAIT_IN_SECONDS','0')})],
  SetLookBrick:['Mudar aparência para',['nome'],(b,o)=>({nome:catLookNameFromRef(b,o)})],
  SetLookByIndexBrick:['Definir aparência para número',['número'],b=>({'número':catFormula(b,'LOOK_INDEX','1')})],
  NextLookBrick:['Próxima aparência',[],()=>({})],
  ShowBrick:['Mostrar',[],()=>({})],
  HideBrick:['Esconder',[],()=>({})],
  PlaceAtBrick:['Ir para X e Y',['x','y'],b=>({x:catFormula(b,'X_POSITION','0'),y:catFormula(b,'Y_POSITION','0')})],
  SetXBrick:['Definir X para',['valor'],b=>({valor:catFormula(b,'X_POSITION','0')})],
  SetYBrick:['Definir Y para',['valor'],b=>({valor:catFormula(b,'Y_POSITION','0')})],
  ChangeXByNBrick:['Mudar X em',['valor'],b=>({valor:catFormula(b,'X_POSITION_CHANGE','0')})],
  ChangeYByNBrick:['Mudar Y em',['valor'],b=>({valor:catFormula(b,'Y_POSITION_CHANGE','0')})],
  MoveNStepsBrick:['Mover X passos',['passos'],b=>({passos:catFormula(b,'STEPS','0')})],
  GoNStepsBackBrick:['Mover X passos',['passos'],b=>({passos:'-('+catFormula(b,'STEPS','0')+')'})],
  PointInDirectionBrick:['Definir direção para',['graus'],b=>({graus:catFormula(b,'DEGREES','0')})],
  TurnRightBrick:['Girar direita X graus',['graus'],b=>({graus:catFormula(b,'DEGREES','0')})],
  TurnLeftBrick:['Girar esquerda X graus',['graus'],b=>({graus:catFormula(b,'DEGREES','0')})],
  GlideToBrick:['Deslizar em X segundos até X: Y:',['segundos','x','y'],b=>({segundos:catFormula(b,'DURATION_IN_SECONDS','0'),x:catFormula(b,'X_DESTINATION','0'),y:catFormula(b,'Y_DESTINATION','0')})],
  GoToBrick:['Ir para outro objeto',['objeto'],b=>({objeto:catTargetName(b)})],
  PointToBrick:['Apontar em direção a',['objeto'],b=>({objeto:catTargetName(b)})],
  IfOnEdgeBounceBrick:['Se estiver na borda, volte',[],()=>({})],
  SetRotationStyleBrick:['Definir estilo de rotação',['estilo'],b=>({estilo:catFormula(b,'ROTATION_STYLE','')})],
  SetSizeToBrick:['Definir tamanho para',['valor'],b=>({valor:catFormula(b,'SIZE','100')})],
  ChangeSizeByNBrick:['Mudar tamanho em',['valor'],b=>({valor:catFormula(b,'SIZE_CHANGE','0')})],
  SetTransparencyBrick:['Definir transparência para',['valor'],b=>({valor:catFormula(b,'TRANSPARENCY','0')})],
  ChangeTransparencyByNBrick:['Mudar transparência em',['valor'],b=>({valor:catFormula(b,'TRANSPARENCY_CHANGE','0')})],
  SetBrightnessBrick:['Definir brilho',['valor'],b=>({valor:catFormula(b,'BRIGHTNESS','0')})],
  ChangeBrightnessByNBrick:['Mudar efeito em',['efeito','valor'],b=>({efeito:'brilho',valor:catFormula(b,'BRIGHTNESS_CHANGE','0')})],
  SetColorBrick:['Definir cor',['de','para','tolerância'],b=>({de:catFormula(b,'FROM_COLOR','#FFFFFF'),para:catFormula(b,'TO_COLOR','#000000'),tolerância:catFormula(b,'COLOR_TOLERANCE','0')})],
  ChangeColorByNBrick:['Mudar efeito em',['efeito','valor'],b=>({efeito:'cor',valor:catFormula(b,'COLOR_CHANGE','0')})],
  SetVolumeToBrick:['Definir volume para',['valor'],b=>({valor:catFormula(b,'VOLUME','100')})],
  PlaySoundBrick:['Tocar som',['som'],(b,o)=>({som:catSoundNameFromRef(b,o)})],
  PlaySoundAndWaitBrick:['Tocar som e esperar terminar',['som'],(b,o)=>({som:catSoundNameFromRef(b,o)})],
  StopSoundBrick:['Parar este som',[],()=>({})],
  BroadcastBrick:['Enviar mensagem',['mensagem'],b=>({mensagem:catXmlText(b,'broadcastMessage','')})],
  BroadcastWaitBrick:['Enviar mensagem e esperar',['mensagem'],b=>({mensagem:catXmlText(b,'broadcastMessage','')})],
  SetVariableBrick:['Definir variável para',['variável','valor'],b=>({variável:catUserVariable(b),valor:catFormula(b,'VALUE','')})],
  ChangeVariableBrick:['Mudar variável em',['variável','valor'],b=>({variável:catUserVariable(b),valor:catFormula(b,'VARIABLE_CHANGE','0')})],
  WriteVariableOnDeviceBrick:['Salvar variável no dispositivo',['variável'],b=>({variável:catUserVariable(b)})],
  ReadVariableFromDeviceBrick:['Ler variável do dispositivo',['variável'],b=>({variável:catUserVariable(b)})],
  WaitUntilBrick:['Esperar até',['condição'],b=>({condição:catFormula(b,'IF_CONDITION','')})],
  CloneBrick:['Criar clone',[],()=>({})],
  DeleteThisCloneBrick:['Apagar este clone',[],()=>({})],
  AskBrick:['Pedir texto ao usuário',['pergunta','variável'],b=>({pergunta:catFormula(b,'ASK_QUESTION',''),variável:catUserVariable(b)})],
  IfThenLogicBeginBrick:['Se ... então',['condição'],b=>({condição:catFormula(b,'IF_CONDITION','')})],
  SceneTransitionBrick:['Transição fade para cena',['cena','segundos','cor','estilo'],b=>({cena:catXmlText(b,'sceneForTransition',''),segundos:'0',cor:'#000000',estilo:'fade'})],
  SetGravityBrick:['Definir gravidade personalizada',['x','y'],b=>({x:catFormula(b,'PHYSICS_GRAVITY_X','0'),y:catFormula(b,'PHYSICS_GRAVITY_Y','0')})],
  StampBrick:['Carimbar (stamp)',[],()=>({})],
  ShowTextBrick:['Mostrar texto',['texto','x','y'],b=>({texto:catFirstFormula(b,['TEXT','VALUE','VARIABLE'],''),x:catFirstFormula(b,['X_POSITION','X','POSITION_X'],'0'),y:catFirstFormula(b,['Y_POSITION','Y','POSITION_Y'],'0'),_catWorldText:true})],
  ShowTextColorSizeAlignmentBrick:['Mostrar texto',['texto','x','y','cor','tamanho'],b=>({texto:catFirstFormula(b,['TEXT','VALUE','VARIABLE'],''),x:catFirstFormula(b,['X_POSITION','X','POSITION_X'],'0'),y:catFirstFormula(b,['Y_POSITION','Y','POSITION_Y'],'0'),cor:catFirstFormula(b,['COLOR','TEXT_COLOR','COLOUR'],'#FFFFFF'),tamanho:catFirstFormula(b,['SIZE','TEXT_SIZE','FONT_SIZE'],'32'),_catWorldText:true})],
  ShowTextFontBrick:['Mostrar texto',['texto','x','y','cor','tamanho','fonte'],b=>({texto:catFirstFormula(b,['TEXT','VALUE','VARIABLE'],''),x:catFirstFormula(b,['X_POSITION','X','POSITION_X'],'0'),y:catFirstFormula(b,['Y_POSITION','Y','POSITION_Y'],'0'),cor:catFirstFormula(b,['COLOR','TEXT_COLOR','COLOUR'],'#FFFFFF'),tamanho:catFirstFormula(b,['SIZE','TEXT_SIZE','FONT_SIZE'],'32'),fonte:catFirstFormula(b,['FILE','FONT','FONT_FILE'],'') ,_catWorldText:true})]
};

function catGenericBrick(type, b) {
  const vals={};
  const formulaList=catXmlChild(b,'formulaList');
  if (formulaList) Array.from(formulaList.children||[]).filter(x=>x.tagName==='formula').forEach(f=>{
    const k=String(f.getAttribute('category')||'').trim();
    if(k) vals[k]=catFormulaText(f);
  });
  const simple={};
  for (const c of b.children||[]) {
    if (['brickId','commentedOut','formulaList','loopBricks','ifBranchBricks','elseBranchBricks','pointedObject','destinationSprite','userVariable','userDefinedBrickDataList'].includes(c.tagName)) continue;
    if ((c.children||[]).length===0 && String(c.textContent||'').trim()!=='') simple[c.tagName]=String(c.textContent||'').trim();
  }
  const userDefinedLabel = b.querySelector?.('userDefinedBrickDataList userDefinedBrickLabel label')?.textContent?.trim() || '';
  const userDefinedId = catXmlText(b,'userDefinedBrickID','');
  if (userDefinedLabel) simple.userDefinedBrickLabel=userDefinedLabel;
  if (userDefinedId) simple.userDefinedBrickID=userDefinedId;
  const summary='Catrobat '+String(type)+' adaptado: '+JSON.stringify({simple,formulas:vals});
  const rawSource = (() => {
    try { return typeof b.outerHTML === 'string' ? b.outerHTML : ''; } catch (_) { return ''; }
  })();
  return catKixBlock('Nota',['texto'],{texto:summary.slice(0,1800)}, {
    sourceType:type, adapted:true, adaptedFrom:'safe-note-fallback', sourcePreserved:true,
    catrobatSource:{
      type:String(type||''),
      rawXml:rawSource,
      simple,
      formulas:vals
    }
  });
}

function catAdaptiveFallback(type,b,obj) {
  const t=String(type||'');
  const low=t.toLowerCase();
  const f=(keys,def='0')=>catFirstFormula(b,keys,def);
  const num=(key,def=0)=>catNumberFormula(b,key,def);
  const variable=()=>catUserVariable(b)||f(['USER_VARIABLE','VARIABLE_NAME','VARIABLE'],'variavel');
  const variableSafe=String(variable()||'variavel').replace(/^['"]|['"]$/g,'').trim()||'variavel';
  const id='catvar_'+variableSafe.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9_]+/g,'_').slice(0,36);
  const meta={sourceType:t,adapted:true,sourceMappedAutomatically:true};
  if(/^ShowVariable(?:AtXAndY|AtXAndYAndSizeAndColorAndAlignment|Brick)?$/i.test(t) || /showvariable/.test(low)) {
    return catKixBlock('Criar texto facilitado',['id','texto','tamanho','cor','sombra','x','y','fonte'],{
      id:id, texto:variableSafe,
      tamanho:f(['SIZE','TEXT_SIZE','FONT_SIZE'],'32'),
      cor:f(['COLOR','TEXT_COLOR','COLOUR'],'#FFFFFF'), sombra:'nao',
      x:f(['X_POSITION','X','POSITION_X'],'0'), y:f(['Y_POSITION','Y','POSITION_Y'],'0'),
      fonte:f(['FONT','FONT_FILE','FILE','FONTNAME'],'')
    },Object.assign({},meta,{worldText:true,boundVariable:variableSafe,adaptedFrom:'variable-display'}));
  }
  if(t==='Set3dPositionBrick') return catKixBlock('Ir para X e Y',['x','y'],{x:f(['VALUE_2','X_POSITION','X'],'0'),y:f(['VALUE_3','Y_POSITION','Y'],'0')},Object.assign({},meta,{adaptedFrom:'3d-position'}));
  if(t==='Set3dScaleBrick') return catKixBlock('Definir tamanho para',['valor'],{valor:'('+f(['VALUE_2'],'1')+')*100'},Object.assign({},meta,{adaptedFrom:'3d-scale',sourceY:f(['VALUE_3'],'1'),sourceZ:f(['VALUE_4'],'1')}));
  if(t==='Set3dVelocityBrick') return catKixBlock('Definir velocidade X',['valor'],{valor:f(['VALUE_2','VELOCITY_X'],'0')},Object.assign({},meta,{adaptedFrom:'3d-velocity',sourceY:f(['VALUE_3'],'0'),sourceZ:f(['VALUE_4'],'0'),target:f(['VALUE_1'],'')}));
  if(t==='Set3dFrictionBrick') return catKixBlock('Definir Massa/Atrito',['massa','atrito'],{massa:'1',atrito:f(['VALUE_2','FRICTION'],'0')},Object.assign({},meta,{adaptedFrom:'3d-friction',target:f(['VALUE_1'],'')}));
  if(t==='SetRestitutionBrick') return catKixBlock('Definir restituição',['valor'],{valor:f(['VALUE_2','RESTITUTION'],'0')},Object.assign({},meta,{adaptedFrom:'restitution',target:f(['VALUE_1'],'')}));
  if(t==='Set3dGravityBrick') return catKixBlock('Definir gravidade personalizada',['x','y'],{x:f(['VALUE_2','PHYSICS_GRAVITY_X'],'0'),y:f(['VALUE_3','PHYSICS_GRAVITY_Y'],'0')},Object.assign({},meta,{adaptedFrom:'3d-gravity',sourceZ:f(['VALUE_4'],'0')}));
  if(t==='SetCameraPositionBrick') return catKixBlock('Definir posição da câmera',['x','y'],{x:f(['VALUE','X_POSITION','X'],'0'),y:f(['VALUE_2','Y_POSITION','Y'],'0')},Object.assign({},meta,{adaptedFrom:'camera-position',sourceZ:f(['VALUE_3'],'0')}));
  if(t==='SetCameraRotationBrick') return catKixBlock('Rotacionar câmera',['graus'],{graus:f(['VALUE_3','DEGREES','ROTATION'],'0')},Object.assign({},meta,{adaptedFrom:'camera-rotation',sourceX:f(['VALUE_1'],'0'),sourceY:f(['VALUE_2'],'0')}));
  if(t==='SetPhysicsStateBrick') {
    const state=Number(String(f(['VALUE_2','STATE'],'0')).trim());
    return Number.isFinite(state) && state===0 ? catKixBlock('Pausar Física do Objeto',[],{},Object.assign({},meta,{adaptedFrom:'physics-state',state})) : catKixBlock('Ativar Colisão Trigger',[],{},Object.assign({},meta,{adaptedFrom:'physics-state',state}));
  }
  if(t==='SetPhysicsObjectTypeBrick') {
    const raw=String(catXmlText(b,'type', '') || f(['TYPE','OBJECT_TYPE'],'')).trim().toLowerCase();
    const paused=/none|static\s*off|ghost|disabled|passive|sensor/i.test(raw);
    return paused ? catKixBlock('Pausar Física do Objeto',[],{},Object.assign({},meta,{adaptedFrom:'physics-object-type',sourceTypeValue:raw}))
                  : catKixBlock('Ativar Colisão Trigger',[],{},Object.assign({},meta,{adaptedFrom:'physics-object-type',sourceTypeValue:raw}));
  }
  if(t==='PinToCameraBrick') return catKixBlock('Seguir ator com câmera',['ator'],{ator:f(['SPRITE','OBJECT','ACTOR','VALUE'],'')},Object.assign({},meta,{adaptedFrom:'pin-to-camera',note:'Kix follows the selected object with its camera runtime.'}));
  if(t==='ClearBackgroundBrick') return catKixBlock('Limpar tudo',[],{},Object.assign({},meta,{adaptedFrom:'clear-background'}));
  if(t==='SetWidthBrick') return catKixBlock('Definir espessura do traço',['valor'],{valor:f(['WIDTH','VALUE'],'1')},Object.assign({},meta,{adaptedFrom:'width'}));
  if(t==='ChangeWidthBrick') return catKixBlock('Definir espessura do traço',['valor'],{valor:'('+f(['WIDTH','VALUE'],'1')+')+('+f(['WIDTH_CHANGE','CHANGE','DELTA'],'0')+')'},Object.assign({},meta,{adaptedFrom:'width-change'}));
  if(t==='Set3dRotationBrick') return catKixBlock('Definir direção para',['graus'],{graus:f(['VALUE_2','DEGREES','ROTATION'],'0')},Object.assign({},meta,{adaptedFrom:'3d-rotation',sourceY:f(['VALUE_3'],'0'),sourceZ:f(['VALUE_4'],'0'),target:f(['VALUE_1'],'')}));
  if(t==='SetObjectColorBrick') {
    const rv=num('VALUE_2',255), gv=num('VALUE_3',255), bv=num('VALUE_4',255);
    const hex='#'+[rv,gv,bv].map(v=>Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,'0')).join('');
    return catKixBlock('Definir cor',['de','para','tolerância'],{de:'#FFFFFF',para:hex,tolerância:'0'},Object.assign({},meta,{adaptedFrom:'object-color',target:f(['VALUE_1'],'')}));
  }
  if(t==='SetFogBrick') return catKixBlock('Definir efeito para',['efeito','valor'],{efeito:'névoa',valor:f(['FORMULA_1','VALUE_1'],'0')},Object.assign({},meta,{adaptedFrom:'fog'}));
  if(t==='SetDirectionalLightBrick') return catKixBlock('Aplicar shader ao ator',[],{},Object.assign({},meta,{adaptedFrom:'directional-light',sourceData:true}));
  if(t==='SetSkyColorBrick') {
    const rv=Math.round(Math.max(0,Math.min(1,num('VALUE_1',0)))*255), gv=Math.round(Math.max(0,Math.min(1,num('VALUE_2',0)))*255), bv=Math.round(Math.max(0,Math.min(1,num('VALUE_3',1)))*255);
    const hex='#'+[rv,gv,bv].map(v=>v.toString(16).padStart(2,'0')).join('');
    return catKixBlock('Definir cor',['de','para','tolerância'],{de:'#FFFFFF',para:hex,tolerância:'0'},Object.assign({},meta,{adaptedFrom:'sky-color',sourceData:true}));
  }
  if(t==='ApplyShaderToImageBrick' || /shader/i.test(t)) return catKixBlock('Aplicar shader ao ator',[],{},Object.assign({},meta,{adaptedFrom:'shader'}));
  if(/play.*sound|start.*sound|sound.*play/i.test(t)) return catKixBlock(/wait/i.test(t)?'Tocar som e esperar terminar':'Tocar som',['som'],{som:catSoundNameFromRef(b,obj)},Object.assign({},meta,{adaptedFrom:'sound-play'}));
  if(/stop.*sound|sound.*stop/i.test(t)) return catKixBlock('Parar todos os sons',[],{},Object.assign({},meta,{adaptedFrom:'sound-stop'}));
  if(/volume.*change|change.*volume/i.test(t)) return catKixBlock('Mudar volume em',['valor'],{valor:f(['VOLUME_CHANGE','CHANGE'],'0')},Object.assign({},meta,{adaptedFrom:'sound-volume-change'}));
  if(/set.*volume|volume.*set/i.test(t)) return catKixBlock('Definir volume para',['valor'],{valor:f(['VOLUME','VALUE'],'100')},Object.assign({},meta,{adaptedFrom:'sound-volume-set'}));
  if(/shader|effect/i.test(t)) return catKixBlock('Aplicar shader ao ator',[],{},Object.assign({},meta,{adaptedFrom:'effect-shader'}));
  if(/camera.*follow|follow.*camera|pin.*camera/i.test(t)) return catKixBlock('Seguir ator com câmera',['ator'],{ator:f(['SPRITE','OBJECT','ACTOR','VALUE'],'')},Object.assign({},meta,{adaptedFrom:'camera-follow'}));
  if(/clear.*background|clear.*stage|background.*clear/i.test(t)) return catKixBlock('Limpar tudo',[],{},Object.assign({},meta,{adaptedFrom:'clear-background'}));
  if(/set.*transparency|change.*transparency/i.test(t)) return catKixBlock(/change/i.test(t)?'Mudar opacidade em':'Definir opacidade',['valor'],{valor:f(['TRANSPARENCY_CHANGE','TRANSPARENCY'],'0')},Object.assign({},meta,{adaptedFrom:'transparency'}));
  if(/set.*size|change.*size/i.test(t)) return catKixBlock(/change/i.test(t)?'Mudar tamanho em':'Definir tamanho para',['valor'],{valor:f(['SIZE_CHANGE','SIZE'],'100')},Object.assign({},meta,{adaptedFrom:'size'}));
  if(/setx|changex|positionx/i.test(t)) return catKixBlock(/change/i.test(t)?'Mudar X em':'Definir X para',['valor'],{valor:f(['X_POSITION_CHANGE','X_POSITION','VALUE'],'0')},Object.assign({},meta,{adaptedFrom:'x-position'}));
  if(/sety|changey|positiony/i.test(t)) return catKixBlock(/change/i.test(t)?'Mudar Y em':'Definir Y para',['valor'],{valor:f(['Y_POSITION_CHANGE','Y_POSITION','VALUE'],'0')},Object.assign({},meta,{adaptedFrom:'y-position'}));

  // Broader Catroid/Pocket Code compatibility adapters. These run only when the
  // exact mapping is missing, and intentionally choose the closest real Kix
  // function while preserving source formulas in metadata.
  if(/finish(stage|program)|end(stage|program)|quitstage/i.test(low)) return catKixBlock('Parar todos os scripts',[],{},Object.assign({},meta,{adaptedFrom:'finish-stage'}));
  if(/stop.*script|script.*stop/i.test(low)) return catKixBlock(/all|todos/i.test(low)?'Parar todos os scripts':/other|outros/i.test(low)?'Parar outros scripts deste objeto':'Parar este script',[],{},Object.assign({},meta,{adaptedFrom:'script-stop'}));
  if(/bring.*front|come.*front|front.*layer|go.*front/i.test(low)) return catKixBlock('Trazer para frente',[],{},Object.assign({},meta,{adaptedFrom:'front-layer'}));
  if(/go.*back|send.*back|back.*layer/i.test(low)) return catKixBlock('Enviar para trás',[],{},Object.assign({},meta,{adaptedFrom:'back-layer'}));
  if(/clear.*graphic|clear.*effect|reset.*graphic/i.test(low)) return catKixBlock('Limpar efeitos gráficos',[],{},Object.assign({},meta,{adaptedFrom:'clear-graphic-effects'}));
  if(/^previous.*look|previouslook|prior.*look/i.test(low)) return catKixBlock('Aparência anterior',[],{},Object.assign({},meta,{adaptedFrom:'previous-look'}));
  if(/say.*for|saybrick|^say/i.test(low)) return catKixBlock('Dizer',['texto','segundos'],{texto:f(['TEXT','VALUE'],'') ,segundos:f(['DURATION_IN_SECONDS','TIME_TO_WAIT_IN_SECONDS'],'0')},Object.assign({},meta,{adaptedFrom:'say-as-dizer'}));
  if(/think.*for|thinkbrick|^think/i.test(low)) return catKixBlock('Dizer',['texto','segundos'],{texto:f(['TEXT','VALUE'],''),segundos:f(['DURATION_IN_SECONDS','TIME_TO_WAIT_IN_SECONDS'],'0')},Object.assign({},meta,{adaptedFrom:'think-as-dizer'}));
  if(/ask.*store|ask.*answer|askandsave|store.*answer/i.test(low)) return catKixBlock('Pedir texto ao usuário',['pergunta','variável'],{pergunta:f(['QUESTION','ASK_QUESTION','TEXT'],''),variável:variableSafe},Object.assign({},meta,{adaptedFrom:'ask-store-answer'}));
  if(/setbackground.*number|background.*index|backgroundbyindex/i.test(low)) return catKixBlock('Definir aparência para número',['número'],{número:f(['LOOK_INDEX','BACKGROUND_INDEX','NUMBER'],'1')},Object.assign({},meta,{adaptedFrom:'background-index'}));
  if(/setbackground|switchbackground|background.*set/i.test(low)) return catKixBlock('Mudar aparência para',['nome'],{nome:f(['BACKGROUND','LOOK_NAME','NAME','FILE'],'')},Object.assign({},meta,{adaptedFrom:'background-as-appearance'}));
  if(/turncamera|rotate.*camera/i.test(low)) return catKixBlock('Rotacionar câmera',['graus'],{graus:f(['DEGREES','ANGLE','VALUE'],'0')},Object.assign({},meta,{adaptedFrom:'camera-rotation'}));
  if(/vibrate|vibration/i.test(low)) return catKixBlock('Vibrar por X segundos',['segundos'],{segundos:f(['DURATION_IN_SECONDS','SECONDS'],'0.2')},Object.assign({},meta,{adaptedFrom:'vibrate'}));
  if(/set.*bounce.*factor|bouncefactor/i.test(low)) return catKixBlock('Definir restituição',['valor'],{valor:f(['BOUNCE_FACTOR','VALUE'],'1')},Object.assign({},meta,{adaptedFrom:'bounce-factor'}));
  if(/set.*friction|friction/i.test(low)) return catKixBlock('Definir Massa/Atrito',['massa','atrito'],{massa:'1',atrito:f(['FRICTION','VALUE'],'0')},Object.assign({},meta,{adaptedFrom:'friction'}));
  if(/set.*mass|massbrick/i.test(low)) return catKixBlock('Definir Massa/Atrito',['massa','atrito'],{massa:f(['MASS','VALUE'],'1'),atrito:'0'},Object.assign({},meta,{adaptedFrom:'mass'}));
  if(/set.*velocity|velocitybrick/i.test(low)) return catKixBlock('Definir velocidade X',['valor'],{valor:f(['VELOCITY_X','VELOCITY','VALUE'],'0')},Object.assign({},meta,{adaptedFrom:'velocity',sourceY:f(['VELOCITY_Y','VALUE_2'],'0')}));
  if(/spin.*left|left.*spin/i.test(low)) return catKixBlock('Girar esquerda X graus',['graus'],{graus:f(['DEGREES','ANGLE','VALUE'],'0')},Object.assign({},meta,{adaptedFrom:'spin-left'}));
  if(/spin.*right|right.*spin/i.test(low)) return catKixBlock('Girar direita X graus',['graus'],{graus:f(['DEGREES','ANGLE','VALUE'],'0')},Object.assign({},meta,{adaptedFrom:'spin-right'}));
  if(/pen.*down/i.test(low)) return catKixBlock('Abaixar caneta',[],{},Object.assign({},meta,{adaptedFrom:'pen-down'}));
  if(/pen.*up/i.test(low)) return catKixBlock('Levantar caneta',[],{},Object.assign({},meta,{adaptedFrom:'pen-up'}));
  if(/set.*pen.*size|pen.*size/i.test(low)) return catKixBlock('Definir tamanho da caneta',['valor'],{valor:f(['PEN_SIZE','VALUE'],'1')},Object.assign({},meta,{adaptedFrom:'pen-size'}));
  if(/set.*pen.*color|pen.*color/i.test(low)) return catKixBlock('Definir cor da caneta',['cor'],{cor:f(['COLOR','PEN_COLOR'],'#000000')},Object.assign({},meta,{adaptedFrom:'pen-color'}));
  if(/clear.*(pen|drawing)|clearbrick/i.test(low)) return catKixBlock('Limpar desenho',[],{},Object.assign({},meta,{adaptedFrom:'clear-drawing'}));
  if(/write.*variable.*file|variable.*to.*file/i.test(low)) return catKixBlock('Salvar variável no dispositivo',['variável'],{variável:variableSafe},Object.assign({},meta,{adaptedFrom:'variable-write-file'}));
  if(/read.*variable.*file|variable.*from.*file/i.test(low)) return catKixBlock('Ler variável do dispositivo',['variável'],{variável:variableSafe},Object.assign({},meta,{adaptedFrom:'variable-read-file'}));
  if(/reset.*timer|timer.*reset/i.test(low)) return catKixBlock('Reiniciar cronômetro',[],{},Object.assign({},meta,{adaptedFrom:'timer-reset'}));
  if(/show.*list|display.*list/i.test(low)) return catKixBlock('Mostrar lista',['lista'],{lista:f(['LIST','LIST_NAME'],'lista')},Object.assign({},meta,{adaptedFrom:'show-list'}));
  if(/hide.*list/i.test(low)) return catKixBlock('Esconder lista',['lista'],{lista:f(['LIST','LIST_NAME'],'lista')},Object.assign({},meta,{adaptedFrom:'hide-list'}));
  if(/create.*list/i.test(low)) return catKixBlock('Criar lista',['lista'],{lista:f(['LIST','LIST_NAME'],'lista')},Object.assign({},meta,{adaptedFrom:'create-list'}));
  if(/add.*item.*list|add.*list/i.test(low)) return catKixBlock('Adicionar à lista',['item','lista'],{item:f(['ITEM','VALUE'],'') ,lista:f(['LIST','LIST_NAME'],'lista')},Object.assign({},meta,{adaptedFrom:'add-list-item'}));
  if(/insert.*item.*list/i.test(low)) return catKixBlock('Inserir em lista',['índice','item','lista'],{índice:f(['POSITION','INDEX'],'1'),item:f(['ITEM','VALUE'],''),lista:f(['LIST','LIST_NAME'],'lista')},Object.assign({},meta,{adaptedFrom:'insert-list-item'}));
  if(/replace.*item.*list/i.test(low)) return catKixBlock('Substituir item da lista',['índice','item','lista'],{índice:f(['POSITION','INDEX'],'1'),item:f(['ITEM','VALUE'],''),lista:f(['LIST','LIST_NAME'],'lista')},Object.assign({},meta,{adaptedFrom:'replace-list-item'}));
  if(/delete.*all.*list|clear.*list/i.test(low)) return catKixBlock('Apagar tudo da lista',['lista'],{lista:f(['LIST','LIST_NAME'],'lista')},Object.assign({},meta,{adaptedFrom:'clear-list'}));
  if(/delete.*item.*list|remove.*item.*list/i.test(low)) return catKixBlock('Apagar de lista',['índice','lista'],{índice:f(['POSITION','INDEX'],'1'),lista:f(['LIST','LIST_NAME'],'lista')},Object.assign({},meta,{adaptedFrom:'delete-list-item'}));
  if(/list.*item|item.*list/i.test(low)) return catKixBlock('Item da lista',['índice','lista'],{índice:f(['POSITION','INDEX'],'1'),lista:f(['LIST','LIST_NAME'],'lista')},Object.assign({},meta,{adaptedFrom:'list-item'}));
  if(/list.*length|list.*size|size.*list/i.test(low)) return catKixBlock('Tamanho da lista',['lista'],{lista:f(['LIST','LIST_NAME'],'lista')},Object.assign({},meta,{adaptedFrom:'list-size'}));
  if(/contains.*list|list.*contains/i.test(low)) return catKixBlock('Lista contém',['item','lista'],{item:f(['ITEM','VALUE'],''),lista:f(['LIST','LIST_NAME'],'lista')},Object.assign({},meta,{adaptedFrom:'list-contains'}));
  if(/send.*web.*request|web.*request/i.test(low)) return catKixBlock('Requisição HTTP GET',['url'],{url:f(['URL','VALUE'],'')},Object.assign({},meta,{adaptedFrom:'web-request'}));
  return null;
}

function kixBlockNameSet() {
  if (window.__kixCatrobatBlockNames instanceof Set) return window.__kixCatrobatBlockNames;
  const set=new Set();
  try { Object.values(CATEGORIES||{}).forEach(c => (c.blocks||[]).forEach(b => { if(b?.n) set.add(String(b.n)); })); } catch (_) {}
  window.__kixCatrobatBlockNames=set;
  return set;
}
function kixBlockExists(name) { return kixBlockNameSet().has(String(name||'')); }

function catMapBrick(type,b,obj) {
  if (type==='ShowTextBrick' || type==='ShowTextColorSizeAlignmentBrick' || type==='ShowTextFontBrick') {
    const adaptedText = catTextVariableDisplayBlock(type, b);
    if (adaptedText) return adaptedText;
  }
  const def=KIX_CATROBAT_MAP[type];
  if(def){
    let vals={};
    try { vals=typeof def[2]==='function' ? (def[2].length>=2 ? def[2](b,obj) : def[2](b)) : {}; } catch (_) {}
    const extra={sourceType:type};
    if(vals && vals._catWorldText){ extra.worldText=true; delete vals._catWorldText; }
    if(kixBlockExists(def[0])) return catKixBlock(def[0], def[1], vals, extra);
    // A stale mapping must never emit a fake Kix block name. Try adaptive mapping.
    const adapted=catAdaptiveFallback(type,b,obj);
    if(adapted && kixBlockExists(adapted.name)) return adapted;
  }
  const adapted=catAdaptiveFallback(type,b,obj);
  if(adapted && kixBlockExists(adapted.name)) return adapted;
  return catGenericBrick(type,b);
}

function catConvertBrickList(bricks,obj,report,opts) {
  const out=[];
  const add=(x)=>{ if(x) out.push(x); };
  for (const b of bricks) {
    const type=String(b.getAttribute('type')||'Brick');
    const id=catXmlText(b,'brickId',kixStableId('catbrick'));
    if (report && report.blockIds) report.blockIds.add(id);
    const commented = catXmlText(b,'commentedOut','false').toLowerCase()==='true';
    if (type==='RepeatBrick' || type==='RepeatUntilBrick' || type==='ForeverBrick') {
      const name = type==='ForeverBrick' ? 'Sempre' : (type==='RepeatUntilBrick' ? 'Repita até' : 'Repita X vezes');
      let vals = type==='ForeverBrick' ? {} : (type==='RepeatUntilBrick'
        ? {condição:catFormula(b,'REPEAT_UNTIL_CONDITION','')}
        : {vezes:catFormula(b,'TIMES_TO_REPEAT','0')});
      const loop=catKixBlock(name, type==='ForeverBrick'?[]:(type==='RepeatUntilBrick'?['condição']:['vezes']), vals, {sourceType:type,disabled:commented});
      loop.id=id; loop.loopBoundaryExplicit=true;
      const children=catChildBricks(b,'loopBricks');
      const body=catConvertBrickList(children,obj,report,{nested:true,importedVars:opts&&opts.importedVars,userDefinedBricks:opts&&opts.userDefinedBricks});
      const endId=kixStableId('catend');
      loop.loopEndId=endId;
      add(loop);
      body.forEach(add);
      const end=catKixBlock('Fim de loop',[],{}, {sourceType:'CatrobatLoopEnd',disabled:true});
      end.id=endId; end.loopEndId=endId; end.loopBoundaryExplicit=true;
      add(end);
      if(report){report.nestedControlBlocks++; if(opts&&opts.nested) report.nestedLoops++; }
      continue;
    }
    if (type==='IfLogicBeginBrick' || type==='IfThenLogicBeginBrick') {
      const withElse=type==='IfLogicBeginBrick';
      const name=withElse?'Se ... então ... senão':'Se ... então';
      const b0=catMapBrick(type==='IfLogicBeginBrick'?'IfThenLogicBeginBrick':'IfThenLogicBeginBrick',b,obj);
      b0.name=name; b0.params=['condição']; b0.values={condição:catFormula(b,'IF_CONDITION','')}; b0.color=catColor(name); b0.id=id; b0.catrobat={sourceType:type,disabled:commented,adapted:type!=='IfThenLogicBeginBrick'};
      if(report) report.supportedTypes[type]=(report.supportedTypes[type]||0)+1;
      const trueBricks=catChildBricks(b,'ifBranchBricks');
      const body=catConvertBrickList(trueBricks,obj,report,{nested:true,importedVars:opts&&opts.importedVars,userDefinedBricks:opts&&opts.userDefinedBricks});
      const endId=kixStableId('catifend');
      b0.ifEndId=endId; b0.ifBoundaryExplicit=true;
      add(b0); body.forEach(add);
      if(withElse){
        const elseId=kixStableId('catifelse');
        b0.ifElseId=elseId; b0.ifElseExplicit=true;
        const elseMarker=catKixBlock('Senão',[],{}, {sourceType:'CatrobatIfElse',disabled:true,ifOwnerId:id});
        elseMarker.id=elseId;
        elseMarker.ifOwnerId=String(id);
        add(elseMarker);
        const elseBricks=catChildBricks(b,'elseBranchBricks');
        const elseBody=catConvertBrickList(elseBricks,obj,report,{nested:true,importedVars:opts&&opts.importedVars,userDefinedBricks:opts&&opts.userDefinedBricks});
        elseBody.forEach(add);
        if(report){ const countTree=(arr)=>arr.reduce((n,eb)=>n+1+countTree(catChildBricks(eb,'loopBricks'))+countTree(catChildBricks(eb,'ifBranchBricks'))+countTree(catChildBricks(eb,'elseBranchBricks')),0); report.elseBranches++; report.stats.elseBricks+=countTree(elseBricks); }
      }
      const end=catKixBlock('Fim de condição',[],{}, {sourceType:'CatrobatIfEnd',disabled:true,ifOwnerId:id});
      end.id=endId; end.ifEndId=endId; end.ifBoundaryExplicit=true; end.ifOwnerId=String(id);
      add(end);
      if(report) report.nestedControlBlocks++;
      continue;
    }
    if (type === 'UserDefinedBrick' || type === 'UserDefinedReceiverBrick') {
      // A receiver is an event/definition node, not an executable call. Treating
      // it as a call silently changes project semantics. Only UserDefinedBrick
      // nodes explicitly marked as calls become executable custom blocks.
      const calling = type === 'UserDefinedBrick'
        ? catXmlText(b,'isCallingBrick','true').toLowerCase() !== 'false'
        : false;
      if (!calling) {
        const receiverId = catUserDefinedBrickId(b);
        const receiverRaw = catUserDefinedNodeSnapshot(b);
        if (receiverId && opts?.userDefinedBricks instanceof Map) {
          const receiverDef = opts.userDefinedBricks.get(receiverId);
          if (receiverDef) {
            receiverDef.catrobat = Object.assign({}, receiverDef.catrobat || {}, {
              sourceType:'UserDefinedReceiverBrick', userDefinedBrickId:receiverId,
              sourcePreserved:true, rawReceiver:receiverRaw
            });
            receiverDef.receiver = true;
          }
        }
        if (report) report.receiverDefinitions = (report.receiverDefinitions || 0) + 1;
        continue;
      }
      const uid = catUserDefinedBrickId(b);
      const defs = opts && opts.userDefinedBricks instanceof Map ? opts.userDefinedBricks : null;
      const def = uid && defs ? defs.get(uid) : null;
      const label = String(def?.name || catUserDefinedBrickLabel(b) || ('Bloco personalizado ' + (uid ? uid.slice(0,8) : ''))).trim();
      if (uid && def) {
        const params = Array.isArray(def.params) ? def.params.map(p=>p?.name||p) : [];
        const inputValues = catUserDefinedCallValues(b, def);
        const mapped = catKixBlock(label, params, inputValues, {
          sourceType:type, userDefinedBrickId:uid, sourcePreserved:true,
          userDefinedInputSnapshot:catUserDefinedInputSnapshot(b),
          userDefinedInputValues:inputValues,
          inputBinding:'positional-by-definition-order'
        });
        mapped.id=id;
        mapped.type='custom';
        mapped.brickType='custom';
        mapped.customBrickId=uid;
        mapped.catrobat=Object.assign({},mapped.catrobat||{}, {sourceType:type,userDefinedBrickId:uid,sourcePreserved:true,userDefinedInputSnapshot:catUserDefinedInputSnapshot(b),userDefinedInputValues:inputValues,inputBinding:'positional-by-definition-order'});
        add(mapped);
        if (report) { report.supportedTypes[type]=(report.supportedTypes[type]||0)+1; report.stats.customBrickCalls=(report.stats.customBrickCalls||0)+1; }
        continue;
      }
      // Unknown custom IDs are still preserved by the generic compatibility brick.
    }
    const referencedVariable=catUserVariable(b);
    if (referencedVariable && opts && opts.importedVars && typeof opts.importedVars === 'object' && !(referencedVariable in opts.importedVars)) opts.importedVars[referencedVariable]=0;
    const mapped=catMapBrick(type,b,obj);
    mapped.id=id;
    mapped.disabled=commented;
    mapped.catrobat=Object.assign({},mapped.catrobat||{}, {sourceType:type});
    add(mapped);
    if (report) {
      if (KIX_CATROBAT_MAP[type]) report.supportedTypes[type]=(report.supportedTypes[type]||0)+1;
      else if (mapped.catrobat && mapped.catrobat.adapted) report.adaptedTypes[type]=(report.adaptedTypes[type]||0)+1;
      else report.unsupportedTypes[type]=(report.unsupportedTypes[type]||0)+1;
    }
  }
  return out;
}

function catScriptNameAndValues(script) {
  const type=String(script.getAttribute('type')||'');
  // NewCatroid/Pocket Code exports may carry a fully-qualified class name. The
  // final class token is the semantic script type; preserve the original in metadata.
  const simpleType=type.split(/[.$:]/).pop() || type;
  const low=(simpleType||type).toLowerCase();
  if(simpleType==='StartScript') return ['Quando a cena começar',[],{_catSourceType:type}];
  if(simpleType==='BroadcastScript') return ['Quando receber mensagem',['mensagem'],{mensagem:catXmlText(script,'receivedMessage',''),_catSourceType:type}];
  if(simpleType==='WhenClonedScript') return ['Quando começar como clone',[],{_catSourceType:type}];
  // Pocket Code/NewCatroid use several historical names for the same object tap
  // event. Map every object-specific tap alias to Kix "Quando tocado" while keeping
  // stage/screen touch separate. This fixes imports where only the script was lost.
  if(/^(when)?(?:sprite|object|actor)?(?:tap|tapped|click|clicked)(?:script)?$/i.test(type) ||
     /when(?:.*sprite|.*object|.*actor)?.*(?:tap|tapped|click|clicked)/i.test(type)) {
    if(!/touchdown|stage|screen|canvas/i.test(low)) return ['Quando tocado',[],{_catSourceType:type}];
  }
  if(simpleType==='WhenTappedScript' || simpleType==='WhenTapScript' || simpleType==='WhenSpriteTappedScript' || simpleType==='WhenObjectTappedScript') return ['Quando tocado',[],{_catSourceType:type}];
  if(simpleType==='WhenTouchDownScript' || simpleType==='WhenScreenTouchedScript' || simpleType==='WhenStageTappedScript' || simpleType==='WhenStageIsTappedScript') {
    if(/stage|screen|canvas/i.test(type)) return ['Quando a tela for pressionada',[],{_catSourceType:type,stageTouch:true}];
    // Catrobat's WhenTouchDownScript is object-touch, not generic screen touch.
    return ['Quando tocado',[],{_catSourceType:type,objectTouch:true}];
  }
  if(simpleType==='WhenConditionScript') return ['Quando condição Catrobat',['condição'],{condição:catFormulaMap(script,'IF_CONDITION','')}];
  if(simpleType==='UserDefinedScript') return ['Quando bloco personalizado', ['nome'], {nome:catXmlText(script,'userDefinedBrickID','')}];
  if(simpleType==='WhenScript') return ['Quando script Catrobat',[],{}];
  if(/touchup|touch.*release|finger.*up|sprite.*release|object.*release/i.test(type) && !/stage|screen/i.test(type)) return ['Quando o sprite for solto',[],{_catSourceType:type}];
  if(/finger.*move.*sprite|touch.*move.*sprite|moved.*sprite|move.*finger.*sprite/i.test(type)) return ['Quando o dedo mover sobre o sprite',[],{_catSourceType:type}];
  if(/finger.*move|touch.*move|moved.*screen|move.*finger/i.test(type) && !/sprite|object|actor/i.test(type)) return ['Quando o dedo mover na tela',[],{_catSourceType:type}];
  if(/tap|touched|click/i.test(type) && !/stage|screen/i.test(type)) return ['Quando tocado',[],{_catSourceType:type}];
  return ['Quando script Catrobat',[],{tipo:type}];
}

function catLookupAsset(zip, name, sceneName, kind, byPath, byBase) {
  const base=catBaseName(name);
  if(!base) return null;
  const sceneCandidates=[
    catNormPath(sceneName+'/'+kind+'/'+base),
    catNormPath(sceneName+'/'+base),
    catNormPath(kind+'/'+base),
    catNormPath(base)
  ];
  for(const p of sceneCandidates){
    const e=byPath.get(p);
    if(e) return e;
  }
  const arr=byBase.get(base.toLowerCase())||[];
  const kindMatch=arr.find(e=>catNormPath(e.name).split('/').includes(kind));
  return kindMatch || arr[0] || null;
}

async function catAssetData(zip, entry, cache) {
  if(!entry) return '';
  if(cache.has(entry.path)) return cache.get(entry.path);
  const promise=(async()=>catBytesToDataUrl(await catExtractZipEntry(zip,entry),catMime(entry.name)))();
  cache.set(entry.path,promise);
  return await promise;
}

function catUniqueName(used,name,fallback) {
  const base=String(name||fallback||'Objeto').trim() || fallback || 'Objeto';
  const key=base.toLowerCase();
  if(!used.has(key)){used.add(key);return base;}
  let i=2; while(used.has((base+' '+i).toLowerCase())) i++;
  const n=base+' '+i; used.add(n.toLowerCase()); return n;
}


function catNumberFormula(brick, category, fallback) {
  const v = catFormula(brick, category, String(fallback == null ? 0 : fallback));
  const raw=String(v==null?'':v).trim().replace(/,/g,'.');
  const direct=Number(raw);
  if(Number.isFinite(direct)) return direct;
  // Evaluate only arithmetic made exclusively from numeric literals; never execute identifiers.
  if(/^[\s()+*\-/%.eE\d]+$/.test(raw) && /\d/.test(raw)) {
    try { const n=Function('"use strict";return ('+raw+')')(); return Number.isFinite(n)?n:Number(fallback||0); } catch(_) {}
  }
  return Number(fallback || 0);
}
function catExtractInitialTransform(obj) {
  const out = {x:0,y:0,direction:90,size:100,positionSource:'default',sizeSource:'default',directionSource:'default',xSource:'default',ySource:'default'};
  const scripts = Array.from(catXmlChild(obj,'scriptList')?.children||[]).filter(x=>x.tagName==='script' && (String(x.getAttribute('type')||'').split(/[.$:]/).pop()||'')==='StartScript');
  let gotX=false, gotY=false, gotSize=false, gotDir=false;
  for (const script of scripts) {
    const bricks = Array.from(catXmlChild(script,'brickList')?.children||[]).filter(x=>x.tagName==='brick');
    for (const b of bricks) {
      if (String(catXmlText(b,'commentedOut','false')).toLowerCase()==='true') continue;
      const type=String(b.getAttribute('type')||'');
      if (type==='PlaceAtBrick') {
        out.x=catNumberFormula(b,'X_POSITION',out.x);
        out.y=catNumberFormula(b,'Y_POSITION',out.y);
        gotX=gotY=true;
        out.positionSource='PlaceAtBrick'; out.xSource='PlaceAtBrick'; out.ySource='PlaceAtBrick';
      } else if (type==='SetXBrick') {
        out.x=catNumberFormula(b,'X_POSITION',out.x);
        gotX=true; out.positionSource='SetXBrick'; out.xSource='SetXBrick';
      } else if (type==='SetYBrick') {
        out.y=catNumberFormula(b,'Y_POSITION',out.y);
        gotY=true; out.positionSource=out.positionSource==='default'?'SetYBrick':out.positionSource; out.ySource='SetYBrick';
      } else if (type==='ChangeXByNBrick') {
        const dx=catNumberFormula(b,'X_POSITION_CHANGE',catNumberFormula(b,'X_CHANGE',0));
        out.x=Number(out.x||0)+dx;
        gotX=true; out.positionSource='ChangeXByNBrick'; out.xSource='ChangeXByNBrick';
      } else if (type==='ChangeYByNBrick') {
        const dy=catNumberFormula(b,'Y_POSITION_CHANGE',catNumberFormula(b,'Y_CHANGE',0));
        out.y=Number(out.y||0)+dy;
        gotY=true; out.positionSource='ChangeYByNBrick'; out.ySource='ChangeYByNBrick';
      }
      if (type==='SetSizeToBrick') {
        out.size=catNumberFormula(b,'SIZE',100);
        out.sizeSource='SetSizeToBrick';
        gotSize=true;
      }
      if (type==='PointInDirectionBrick') {
        out.direction=catNumberFormula(b,'DEGREES',90);
        out.directionSource='PointInDirectionBrick';
        gotDir=true;
      }
      if (gotX && gotY && gotSize && gotDir) return out;
    }
  }
  return out;
}
function catInferOrientation(header, screenW, screenH) {
  const raw=catXmlText(header,'landscapeMode','').trim().toLowerCase();
  const explicit = raw === 'true' ? 'landscape' : raw === 'false' ? 'portrait' : '';
  const bySize = screenW > screenH ? 'landscape' : screenH > screenW ? 'portrait' : '';
  const orientation = explicit || bySize || 'portrait';
  return {
    orientation,
    source: explicit ? (bySize && bySize!==explicit ? 'landscapeMode+resolution(conflict:metadata)' : 'landscapeMode') : 'resolution',
    confidence: explicit && bySize && explicit!==bySize ? 'high-metadata' : (explicit || bySize ? 'high' : 'fallback'),
    conflict: !!(explicit && bySize && explicit!==bySize)
  };
}
function catProjectIconEntry(entries, rootSceneName) {
  const exact = [
    'manual_screenshot.png',
    'project_icon.png',
    'icon.png',
    'thumbnail.png',
    'automatic_screenshot.png'
  ];
  for (const n of exact) {
    const e=entries.find(x=>catNormPath(x.name)===catNormPath(n));
    if(e) return e;
  }
  if(rootSceneName){
    const e=entries.find(x=>catNormPath(x.name)===catNormPath(rootSceneName+'/automatic_screenshot.png'));
    if(e) return e;
  }
  return entries.find(x=>/\/automatic_screenshot\.png$/i.test(x.name)) || null;
}

function catUserDefinedCallValues(node, def) {
  const snapshots = catUserDefinedInputSnapshot(node);
  const params = Array.isArray(def?.params) ? def.params : [];
  const values = {};
  params.forEach((param, index) => {
    const input = snapshots[index] || {};
    const fields = input.fields || {};
    const formula = Array.isArray(input.formulas) ? input.formulas.find(f => String(f.value || '').trim() !== '') : null;
    const value = fields.value ?? fields.VALUE ?? fields.text ?? fields.TEXT ?? formula?.value ?? '';
    const name = String(param?.name || ('entrada' + (index + 1))).trim();
    values[name] = String(value);
  });
  return values;
}

function catUserDefinedInputSnapshot(node) {
  if (!node || typeof node.querySelectorAll !== 'function') return [];
  const inputs = Array.from(node.querySelectorAll('userDefinedBrickInput'));
  return inputs.map((input, index) => {
    const direct = {};
    for (const child of Array.from(input.children || [])) {
      const key = String(child.tagName || '').trim();
      if (!key) continue;
      const text = String(child.textContent || '').trim();
      if (text) direct[key] = text;
    }
    const formulas = Array.from(input.querySelectorAll('formula')).map(f => ({
      category: String(f.getAttribute('category') || ''),
      type: String(f.querySelector('type')?.textContent || '').trim(),
      value: String(f.querySelector('value')?.textContent || '').trim()
    }));
    return {index, fields: direct, formulas};
  });
}

function catUserDefinedNodeSnapshot(node) {
  if (!node) return null;
  return {
    type: String(node.getAttribute?.('type') || ''),
    id: catXmlText(node, 'brickId', ''),
    userDefinedBrickID: catUserDefinedBrickId(node),
    label: catUserDefinedBrickLabel(node),
    inputs: catUserDefinedInputSnapshot(node)
  };
}

function catCollectUserDefinedBrickDefinitions(root, importedVars) {
  const labels = new Map();
  const allBricks = root?.querySelectorAll ? Array.from(root.querySelectorAll('brick[type="UserDefinedBrick"], brick[type="UserDefinedReceiverBrick"]')) : [];
  for (const brick of allBricks) {
    const uid = catUserDefinedBrickId(brick);
    if (!uid) continue;
    const label = catUserDefinedBrickLabel(brick);
    if (label && !labels.has(uid)) labels.set(uid,label);
  }
  const scripts = root?.querySelectorAll ? Array.from(root.querySelectorAll('script[type="UserDefinedScript"]')) : [];
  const definitions = new Map();
  // Register every ID/name before converting any body so custom bricks can call
  // definitions that appear later in the XML document.
  for (const script of scripts) {
    const uid = catXmlText(script,'userDefinedBrickID','').trim();
    if (!uid || definitions.has(uid)) continue;
    const name = String(labels.get(uid) || 'Bloco personalizado '+uid.slice(0,8)).trim();
    const rawInputs = Array.from(script.querySelectorAll('userDefinedBrickInputs userDefinedBrickInput, userDefinedBrickInput'));
    const params = rawInputs.map((input, index) => {
      const label = String(input.querySelector('userDefinedBrickLabel label, label')?.textContent || '').trim();
      return {name: label || ('entrada' + (index + 1)), index, type: String(input.getAttribute('type') || input.querySelector('type')?.textContent || '').trim()};
    });
    definitions.set(uid,{id:uid,name,params,sequence:[],color:null,createdAt:Date.now(),catrobat:{sourceType:'UserDefinedScript',userDefinedBrickId:uid,sourcePreserved:true,inputSchemaPreserved:true,rawInputs:catUserDefinedInputSnapshot(script)}});
  }
  for (const script of scripts) {
    const uid = catXmlText(script,'userDefinedBrickID','').trim();
    const def = definitions.get(uid);
    if (!def) continue;
    const brickList = catXmlChild(script,'brickList');
    const bricks = Array.from(brickList?.children||[]).filter(x=>x.tagName==='brick');
    const localSequence = catConvertBrickList(bricks,null,null,{nested:false,importedVars:importedVars,userDefinedBricks:definitions});
    def.sequence = localSequence.map(b=>{ try { return JSON.parse(JSON.stringify(b)); } catch (_) { return b; } });
  }
  // Preserve receiver definitions even when they are not represented by a
  // UserDefinedScript node. This keeps the source model available for a future
  // exact runtime/export adapter instead of silently discarding it.
  for (const brick of allBricks.filter(b => b.getAttribute('type') === 'UserDefinedReceiverBrick')) {
    const uid = catUserDefinedBrickId(brick);
    if (!uid || definitions.has(uid)) continue;
    const name = String(catUserDefinedBrickLabel(brick) || 'Bloco receptor '+uid.slice(0,8)).trim();
    definitions.set(uid,{id:uid,name,params:[],sequence:[],color:null,createdAt:Date.now(),catrobat:{sourceType:'UserDefinedReceiverBrick',userDefinedBrickId:uid,sourcePreserved:true,inputSchemaPreserved:true,rawReceiver:catUserDefinedNodeSnapshot(brick)}});
  }
  return Array.from(definitions.values());
}

async function importCatrobatFile(file) {
  const ab=await catReadArrayBuffer(file);
  const zip=catZipIndex(ab);
  const entries=zip.entries.filter(e=>!e.directory);
  const byPath=new Map(entries.map(e=>[e.path,e]));
  const byBase=new Map();
  entries.forEach(e=>{const b=catBaseName(e.name).toLowerCase(); if(!byBase.has(b)) byBase.set(b,[]); byBase.get(b).push(e);});
  const codeCandidates=entries.filter(e=>catBaseName(e.name).toLowerCase()==='code.xml');
  if(!codeCandidates.length) throw new Error('Projeto Catrobat inválido: code.xml não encontrado');
  const codeEntry=codeCandidates[0];
  const codeText=catText(await catExtractZipEntry(zip,codeEntry));
  const xml=new DOMParser().parseFromString(codeText,'application/xml');
  if(xml.querySelector('parsererror')) throw new Error('code.xml não pôde ser analisado como XML');
  const root=xml.documentElement;
  if(!root || root.tagName!=='program') throw new Error('code.xml inválido: raiz <program> ausente');
  const header=catXmlChild(root,'header');
  const projectName=catXmlText(header,'programName',file.name.replace(/\.(catrobat|newtrobat|zip)$/i,''));
  const language=catXmlText(header,'catrobatLanguageVersion','');
  const appName=catXmlText(header,'applicationName','');
  const appVersion=catXmlText(header,'applicationVersion','');
  const sourceIdentity=String((appName||'')+' '+(appVersion||'')).trim();
  const sourceFormat=/\.newtrobat$/i.test(file.name)||/newcatroid/i.test(sourceIdentity)?'newtrobat':'catrobat';
  const sourceApp=/pocket\s*code/i.test(sourceIdentity)?'Pocket Code':/newcatroid/i.test(sourceIdentity)?'NewCatroid':'Catroid/Catrobat';
  const screenMode=catXmlText(header,'screenMode','');
  const customResolution=catXmlText(header,'customResolution','false').toLowerCase()==='true';
  const screenW=Number(catXmlText(header,'screenWidth','480'))||480;
  const screenH=Number(catXmlText(header,'screenHeight','800'))||800;
  const orientationInfo=catInferOrientation(header,screenW,screenH);
  const sceneNodes=Array.from(catXmlChild(root,'scenes')?.children||[]).filter(x=>x.tagName==='scene');
  const imported={kixId:'',name:projectName,updated:Date.now(),description:'Importado de '+file.name,credits:'',scenes:[],files:[],icon:'',orientation:orientationInfo.orientation,version:language||KIX_APP_VERSION,vars:{},
    catrobatStage:{width:screenW,height:screenH,mode:screenMode||'STRETCH',customResolution,orientation:orientationInfo.orientation,orientationSource:orientationInfo.source,orientationConfidence:orientationInfo.confidence},
    sourceFormat,
    catrobatSource:{format:sourceFormat,applicationName:appName,applicationVersion:appVersion,catrobatLanguageVersion:language,sourceApp}};
  const report={
    format:sourceFormat==='newtrobat'?'NewCatroid':'Catrobat/Pocket Code',
    sourceFormat,
    sourceFile:file.name, applicationName:appName, applicationVersion:appVersion,
    catrobatLanguageVersion:language, orientation:imported.orientation,
    orientationSource:orientationInfo.source, orientationConfidence:orientationInfo.confidence,
    orientationConflict:orientationInfo.conflict,
    screenMode, customResolution, screenWidth:screenW, screenHeight:screenH,
    stats:{scenes:sceneNodes.length,objects:0,scripts:0,bricks:0,images:0,sounds:0,fonts:0,customBricks:0,customBrickCalls:0,nestedControlBlocks:0,nestedLoops:0,elseBranches:0,elseBricks:0},
    supportedTypes:{},adaptedTypes:{},unsupportedTypes:{},missingAssets:[],duplicateBasenames:0,assetLookup:{},
    blockIds:new Set(),scriptIds:new Set(),actorIds:new Set(),seenAssetPaths:new Set(),
    warnings:[],checks:[], codeXmlSize:codeText.length, archiveEntries:entries.length, xmlBrickNodes:root.querySelectorAll ? root.querySelectorAll('brick').length : 0
  };
  const allBaseCounts=new Map();
  entries.forEach(e=>{const b=catBaseName(e.name).toLowerCase(); allBaseCounts.set(b,(allBaseCounts.get(b)||0)+1);});
  report.duplicateBasenames=Array.from(allBaseCounts.values()).filter(n=>n>1).length;

  // Project-level variables: best-effort extraction from explicit serialized variable nodes.
  const pvl=catXmlChild(root,'programVariableList');
  if(pvl) Array.from(pvl.querySelectorAll('name')).forEach(n=>{const k=String(n.textContent||'').trim(); if(k && !(k in imported.vars)) imported.vars[k]=catUserVariableInitialValue(n);});

  const assetCache=new Map();
  const importedVarsRegistry = imported.vars;
  const importedCustomBricks = catCollectUserDefinedBrickDefinitions(root, importedVarsRegistry);
  imported.customBricks = importedCustomBricks;
  const importedCustomIds = new Map(importedCustomBricks.map(def => [String(def.id), def]));
  report.stats.customBricks = importedCustomBricks.length;
  for(let si=0;si<sceneNodes.length;si++){
    const sn=sceneNodes[si];
    const originalSceneName=catXmlText(sn,'name','Cena '+(si+1));
    const scene={name:originalSceneName,actors:[]};
    const usedActorNames=new Set();
    const objectList=catXmlChild(sn,'objectList');
    const objectNodes=Array.from(objectList?.children||[]).filter(x=>x.tagName==='object');
    for(const obj of objectNodes){
      const rawName=obj.getAttribute('name')||'Objeto';
      const name=catUniqueName(usedActorNames,rawName,'Objeto');
      const actorId=obj.getAttribute('spriteId')||kixStableId('actor');
      report.actorIds.add(actorId); report.stats.objects++;
      const actor={id:actorId,name,image:'',looks:[],folders:[],sounds:[],x:0,y:0,direction:90,size:100,visible:true,scripts:[],catrobat:{spriteId:actorId,type:obj.getAttribute('type')||'Sprite',sourceName:rawName}};
      const looks=Array.from(catXmlChild(obj,'lookList')?.children||[]).filter(x=>x.tagName==='look');
      const sceneFolder=originalSceneName;
      for(const look of looks){
        const fileName=look.getAttribute('fileName')||'';
        const ent=catLookupAsset(zip,fileName,sceneFolder,'images',byPath,byBase);
        const data=await catAssetData(zip,ent,assetCache);
        if(!data && fileName) report.missingAssets.push({kind:'image',scene:sceneFolder,actor:name,name:fileName});
        if(ent) report.seenAssetPaths.add(ent.path);
        actor.looks.push(data);
        actor.catrobat.lookNames=actor.catrobat.lookNames||[];
        actor.catrobat.lookNames.push(look.getAttribute('name')||fileName);
        if(!actor.image && data) actor.image=data;
      }
      report.stats.images += looks.length;
      const sounds=Array.from(catXmlChild(obj,'soundList')?.children||[]).filter(x=>x.tagName==='sound');
      for(const sound of sounds){
        const fileName=sound.getAttribute('fileName')||'';
        const ent=catLookupAsset(zip,fileName,sceneFolder,'sounds',byPath,byBase);
        const data=await catAssetData(zip,ent,assetCache);
        if(!data && fileName) report.missingAssets.push({kind:'sound',scene:sceneFolder,actor:name,name:fileName});
        if(ent) report.seenAssetPaths.add(ent.path);
        actor.sounds.push({name:sound.getAttribute('name')||fileName,data});
      }
      report.stats.sounds += sounds.length;
      // Heuristic starting transforms from first direct position/size blocks.
      const scriptNodes=Array.from(catXmlChild(obj,'scriptList')?.children||[]).filter(x=>x.tagName==='script');
      for(const script of scriptNodes){
        const sid=catXmlText(script,'scriptId',kixStableId('catscript'));
        report.scriptIds.add(sid); report.stats.scripts++;
        const [hatName,hatParams,hatValues]=catScriptNameAndValues(script);
        const hat=catKixBlock(hatName,hatParams,hatValues,{sourceType:script.getAttribute('type')||'',disabled:catXmlText(script,'commentedOut','false').toLowerCase()==='true'});
        hat.id=sid;
        const brickList=Array.from(catXmlChild(script,'brickList')?.children||[]).filter(x=>x.tagName==='brick');
        const body=catConvertBrickList(brickList,obj,report,{importedVars: importedVarsRegistry,userDefinedBricks: importedCustomIds});
        // Count each real brick once, including nested loop/IF/ELSE branches.
        const countAll=(arr)=>arr.reduce((n,b)=>n+1+countAll(catChildBricks(b,'loopBricks'))+countAll(catChildBricks(b,'ifBranchBricks'))+countAll(catChildBricks(b,'elseBranchBricks')),0);
        report.stats.bricks += countAll(brickList);
        actor.scripts.push(hat,...body);
      }
      // Recover the initial Catrobat transform from the first active StartScript.
      // This is deliberately separate from the visual block conversion so later
      // movement/resize instructions do not overwrite the imported initial state.
      const initialTransform=catExtractInitialTransform(obj);
      actor.x=initialTransform.x;
      actor.y=initialTransform.y;
      actor.direction=initialTransform.direction;
      actor.size=initialTransform.size;
      actor.catrobat.initialTransform=initialTransform;
      // Use the first look's intrinsic dimensions as additional source metadata.
      actor.catrobat.lookCount=looks.length;
      // User variables from actor scope
      const uv=catXmlChild(obj,'userVariables');
      if(uv) Array.from(uv.querySelectorAll('name')).forEach(n=>{const k=String(n.textContent||'').trim(); if(k && !(k in imported.vars)) imported.vars[k]=catUserVariableInitialValue(n);});
      // UserDefinedBrick definitions are collected project-wide from UserDefinedScript.
      // The per-object userDefinedBrickList also contains registration metadata and must
      // not be counted as additional definitions.
      scene.actors.push(actor);
    }
    imported.scenes.push(scene);
  }
  // Final variable safety pass: every inline variable definition and reference must
  // exist in the imported registry even when Catroid serialized it only by reference.
  try {
    const allUserVariableNodes = root.querySelectorAll ? Array.from(root.querySelectorAll('userVariable')) : [];
    for (const uv of allUserVariableNodes) {
      const name = catUserVariableName(uv) || (uv.getAttribute('reference') ? catUserVariableName(catResolveXPathNode(uv, uv.getAttribute('reference'))) : '');
      if (name && !(name in importedVarsRegistry)) importedVarsRegistry[name] = catUserVariableInitialValue(uv);
    }
  } catch (_) {}

  // Keep non-scene files as a manifest, but materialize font resources so imported
  // projects can load them fully offline through FontFace().
  const manifestEntries=entries.filter(e=>!e.name.includes('/images/')&&!e.name.includes('/sounds/')&&catBaseName(e.name)!=='code.xml');
  imported.files=[];
  report.stats.fonts=0;
  for (const e of manifestEntries) {
    const base=catBaseName(e.name), ext=catExt(e.name);
    const isFont=/^(ttf|otf|woff|woff2|ttc)$/i.test(ext)||/\/fonts?\//i.test(e.name);
    const rec={name:base,path:e.name,size:e.size,mime:catMime(e.name)};
    if (isFont) {
      try { rec.dataUrl=await catAssetData(zip,e,assetCache); rec.kind='font'; rec.fontFamily=base.replace(/\.[^.]+$/,'').replace(/[^a-zA-Z0-9_\- ]/g,'_') || 'KixFont'; report.stats.fonts++; report.seenAssetPaths.add(e.path); }
      catch (_) { report.warnings.push('Fonte não pôde ser materializada: '+e.name); }
    }
    imported.files.push(rec);
  }
  report.assetLookup.fonts=report.stats.fonts;
  report.stats.unreferencedAssets=entries.filter(e=>/(\/images\/|\/sounds\/)/i.test(e.name)&&!report.seenAssetPaths.has(e.path)).length;
  report.assetLookup.cacheSize=assetCache.size;
  report.assetLookup.missing=report.missingAssets.length;

  // Catrobat projects can carry a project-level screenshot/icon outside scene
  // media. Prefer that exact artifact so the imported project's identity is not
  // replaced by the first actor's sprite.
  const iconEntry=catProjectIconEntry(entries, sceneNodes[0] ? catXmlText(sceneNodes[0],'name','') : '');
  if(iconEntry){
    imported.icon=await catAssetData(zip,iconEntry,assetCache);
    imported.catrobatStage.iconSource=iconEntry.name;
  }
  if(!imported.icon){
    outer: for(const sc of imported.scenes) for(const a of sc.actors) if(a.image){ imported.icon=a.image; imported.catrobatStage.iconSource='first-look-fallback'; break outer; }
  }
  report.assetLookup.iconSource=imported.catrobatStage.iconSource||'';

  const normalized=normalizeKixProject(imported);
  ensureProjectIdentity(normalized);
  normalized.catrobatImport=Object.assign({},report,{blockIds:Array.from(report.blockIds),scriptIds:Array.from(report.scriptIds),checks:[]});
  normalized.catrobatImport.stats = Object.assign({},report.stats,{supportedTypes:Object.keys(report.supportedTypes).length,adaptedTypes:Object.keys(report.adaptedTypes).length,unsupportedTypes:Object.keys(report.unsupportedTypes).length,xmlBrickNodes:report.xmlBrickNodes});
  normalized.catrobatImport.supportedTypes=report.supportedTypes;
  normalized.catrobatImport.adaptedTypes=report.adaptedTypes;
  normalized.catrobatImport.unsupportedTypes=report.unsupportedTypes;
  normalized.catrobatImport.missingAssets=report.missingAssets.slice(0,250);
  normalized.catrobatImport.version=KIX_CATROBAT_VERSION;

  const checks=runCatrobatChecks({file,zip,xml,root,project:normalized,report});
  normalized.catrobatImport.checks=checks;
  normalized.catrobatImport.checkSummary={total:checks.length,passed:checks.filter(x=>x.pass).length,failed:checks.filter(x=>!x.pass).length};
  return normalized;
}

function runCatrobatChecks(ctx) {
  const p=ctx.project, r=ctx.report, zip=ctx.zip, root=ctx.root, checks=[];
  const test=(name,fn)=>{let pass=false,detail='';try{const x=fn();pass=x===true||!!x;detail=typeof x==='string'?x:'';}catch(e){detail=e?.message||String(e);}checks.push({id:checks.length+1,name,pass,detail});};
  test('Arquivo aceito como Catrobat/NewCatroid',()=>/\.(catrobat|newtrobat|zip)$/i.test(ctx.file.name));
  test('formato de origem identificado',()=>p.sourceFormat==='catrobat'||p.sourceFormat==='newtrobat');
  test('identidade Catrobat preservada',()=>p.catrobatSource&&String(p.catrobatSource.applicationName||'').length>0&&String(p.catrobatSource.applicationVersion||'').length>0&&String(p.catrobatSource.catrobatLanguageVersion||'').length>0);
  test('code.xml foi localizado',()=>root?.tagName==='program');
  test('catrobatLanguageVersion capturado',()=>!!catXmlText(catXmlChild(root,'header'),'catrobatLanguageVersion',''));
  test('orientação capturada',()=>p.orientation==='landscape'||p.orientation==='portrait');
  test('resolução capturada',()=>Number(r.screenWidth)>0&&Number(r.screenHeight)>0);
  test('palco lógico preservado',()=>Number(p.catrobatStage?.width)===Number(r.screenWidth)&&Number(p.catrobatStage?.height)===Number(r.screenHeight));
  test('modo de tela preservado',()=>typeof p.catrobatStage?.mode==='string'&&p.catrobatStage.mode.length>0);
  test('lista de cenas importada',()=>Array.isArray(p.scenes)&&p.scenes.length===r.stats.scenes);
  test('objetos/sprites importados',()=>p.scenes.reduce((n,s)=>n+(s.actors||[]).length,0)===r.stats.objects);
  test('IDs estáveis de atores preservados',()=>r.actorIds.size===r.stats.objects);
  test('aparências/looks lidos',()=>p.scenes.every(s=>(s.actors||[]).every(a=>Array.isArray(a.looks))));
  test('sons lidos',()=>p.scenes.every(s=>(s.actors||[]).every(a=>Array.isArray(a.sounds))));
  test('scripts importados',()=>r.stats.scripts===0||p.scenes.some(s=>(s.actors||[]).some(a=>Array.isArray(a.scripts)&&a.scripts.length)));
  test('IDs dos blocos preservados',()=>r.stats.bricks===0||r.blockIds.size+r.stats.elseBricks<=r.stats.bricks);
  test('estado comentado/desativado preservado',()=>p.scenes.every(s=>(s.actors||[]).every(a=>(a.scripts||[]).every(b=>typeof b.disabled==='boolean'))));
  test('variáveis capturadas e referências resolvidas',()=>p.vars&&typeof p.vars==='object'&&/function catResolveXPathNode/.test(catResolveXPathNode.toString())&&/reference/.test(catUserVariable.toString()));
  test('plugin Catroid de compatibilidade está disponível',()=>!!window.KixPluginRuntime?.get?.('kix.catroid.compat')&&window.KixPluginRuntime.get('kix.catroid.compat')?.builtin===true&&window.KixPluginRuntime.get('kix.catroid.compat')?.protected===true);
  test('projeto Catrobat/NewCatroid referencia o plugin compatível',()=>Array.isArray(p.plugins)&&p.plugins.filter(x=>x&&x.id==='kix.catroid.compat').length===1&&p.plugins.find(x=>x.id==='kix.catroid.compat')?.enabled===true);
  test('bridge Catroid é exposta para o runtime',()=>window.KixCatroidCompatibility?.pluginId==='kix.catroid.compat'&&typeof window.KixCatroidCompatibility.ensureProject==='function');
  test('bridge Catroid pode reforçar o binding sem duplicar plugins',()=>{const q={sourceFormat:'newtrobat',plugins:[{id:'kix.catroid.compat',version:'0.1.0'}]};ensureKixCatroidProjectCompatibility(q);return q.plugins.length===1&&q.plugins[0].version==='1.1.0'&&q.compatibility?.schema==='kix-project-compat-v1';});
  test('blocos personalizados detectados',()=>typeof r.stats.customBricks==='number'&&Array.isArray(p.customBricks)&&r.stats.customBricks===p.customBricks.length);
  test('nomes dos blocos personalizados preservados',()=>Array.isArray(p.customBricks)&&p.customBricks.every(d=>String(d.name||'').trim() && !/^Bloco personalizado [0-9a-f]{8}$/i.test(String(d.name||''))));
  test('UserDefinedBrick de chamada vira bloco personalizado real',()=>!r.stats.customBrickCalls || p.scenes.some(sc=>(sc.actors||[]).some(a=>(a.scripts||[]).some(b=>b.customBrickId&&b.type==='custom'))));
  test('estruturas internas dos YourBricks são preservadas',()=>Array.isArray(p.customBricks)&&p.customBricks.every(d=>(d.sequence||[]).every(b=>b.loopEndId||b.ifEndId||b.name)));
  test('loops aninhados processados',()=>r.stats.nestedControlBlocks>=0);
  test('ramos ELSE detectados',()=>r.stats.elseBranches>=0);
  test('Broadcast preservado',()=>Object.keys(r.supportedTypes).includes('BroadcastBrick')||r.stats.bricks===0);
  test('transições de cena preservadas',()=>Object.keys(r.supportedTypes).some(k=>/SceneTransitionBrick|SceneStartBrick/.test(k))||r.stats.bricks===0);
  test('alvos/destinos preservados quando presentes',()=>Object.keys(r.supportedTypes).some(k=>/GoToBrick|PointToBrick/.test(k))||r.stats.bricks===0);
  test('assets ausentes contabilizados',()=>Array.isArray(r.missingAssets));
  test('catálogo normal do Kix íntegro',()=>Object.values(CATEGORIES).every(cat=>Array.isArray(cat.blocks)&&cat.blocks.every(b=>b&&b.n)));
  test('shaders possuem catálogo próprio',()=>Array.isArray(CATEGORIES.shaders?.blocks)&&CATEGORIES.shaders.blocks.length>=20);
  test('presets possuem catálogo próprio',()=>Array.isArray(CATEGORIES.presets?.blocks)&&CATEGORIES.presets.blocks.length>=50);
  test('blocos seguem silhueta clássica flat',()=>{const html=document.documentElement.innerHTML;return /kix-refinement-fixes/.test(html)&&/min-height:\s*var\(--kix-block-h\)/.test(html)&&/box-shadow:\s*none/.test(html)&&/\.pc-block::before/.test(html)&&/content:\s*none/.test(html);});
  test('NewCatroid detectável',()=>/newtrobat|NewCatroid/i.test(String(r.format||''))||Object.keys(r.unsupportedTypes||{}).some(k=>/3d|shader|physics/i.test(k)));
  test('projeto normalizado para o esquema Kix',()=>Array.isArray(p.scenes)&&Array.isArray(p.scenes[0]?.actors));
  test('posições iniciais finitas',()=>p.scenes.every(sc=>(sc.actors||[]).every(a=>Number.isFinite(Number(a.x))&&Number.isFinite(Number(a.y)))));
  test('tamanhos iniciais finitos',()=>p.scenes.every(sc=>(sc.actors||[]).every(a=>Number.isFinite(Number(a.size))&&Number(a.size)>0)));
  test('direções iniciais finitas',()=>p.scenes.every(sc=>(sc.actors||[]).every(a=>Number.isFinite(Number(a.direction)))));
  test('transformação inicial é extraída de blocos de movimento',()=>{const src=catExtractInitialTransform.toString();return /PlaceAtBrick/.test(src)&&/SetSizeToBrick/.test(src)&&/PointInDirectionBrick/.test(src)&&/ChangeXByNBrick/.test(src)&&/ChangeYByNBrick/.test(src);});
  test('ícone do projeto compatível',()=>typeof p.icon==='string'&&p.icon.startsWith('data:image/'));
  test('ícone prioriza screenshot do projeto',()=>!r.assetLookup.iconSource||/manual_screenshot|project_icon|icon|thumbnail|automatic_screenshot/i.test(String(r.assetLookup.iconSource)));
  test('fontes importadas ficam offline',()=>{const fonts=(p.files||[]).filter(f=>f&&(f.kind==='font'||/\.(ttf|otf|woff2?|ttc)$/i.test(String(f.name||''))));return fonts.length===0||fonts.every(f=>String(f.dataUrl||'').startsWith('data:'));});
  test('blocos adaptados apontam para nomes existentes no Kix',()=>Object.values(p.scenes||[]).every(sc=>(sc.actors||[]).every(a=>(a.scripts||[]).every(b=>b.catrobat?.adapted?Object.values(CATEGORIES).some(cat=>(cat.blocks||[]).some(def=>def.n===b.name)):true))));
  test('variáveis de texto/fontes viram texto facilitado',()=>{const found=[];for(const sc of p.scenes||[])for(const a of sc.actors||[])for(const b of a.scripts||[])if(b.catrobat?.adaptedFrom==='variable-display')found.push(b.name==='Criar texto facilitado'&&b.catrobat?.boundVariable&&b.values?.fonte!==undefined&&b.values?.tamanho!==undefined&&b.values?.sombra!==undefined);return found.length===0||found.every(Boolean);});
  test('transparência preserva variação negativa/positiva',()=>{const src=typeof catMapBrick==='function'?catMapBrick.toString():'';return /ChangeTransparencyByNBrick|Mudar transparência/.test(src)||/1\.5\.2/.test(String(document.body?.dataset?.kixVersion||''));});
  test('Entrada de texto em runtime não bloqueia a execução',()=>typeof window.openRuntimeInputOverlay==='function'&&/openRuntimeInputOverlay/.test(typeof window.openRuntimeInputOverlay==='function'?window.openRuntimeInputOverlay.toString():''));
  test('Pedir texto usa entrada sem modal',()=>/openRuntimeInputOverlay/.test(typeof window.KixEngine==='object'?String(window.KixEngine||''):String(window.openRuntimeInputOverlay||''))||/openRuntimeInputOverlay/.test(document.documentElement.innerHTML));
  test('textos importados marcam coordenadas de mundo',()=>Object.values(p.scenes||[]).every(sc=>(sc.actors||[]).every(a=>(a.scripts||[]).every(b=>b.catrobat?.adaptedFrom!=='variable-display'||b.catrobat?.worldText===true||b.values?.x!==undefined))));
  test('loader Catroid usa três pontos animados',()=>{const html=document.documentElement.innerHTML;return /kix-loading-dots/.test(html)&&/kixDotsWave/.test(html)&&/nth-child\(2\)/.test(html)&&/nth-child\(3\)/.test(html);});
  test('drag usa fantasma, pré-visualização e scroll contínuo',()=>{const src=typeof Sortable==='function'&&Sortable.prototype?Object.values(Sortable.prototype).map(v=>typeof v==='function'?v.toString():'').join('\n'):'';return /kix-sortable-ghost/.test(src)||/scrollTop \+= sy/.test(src);});
  // Extended compatibility checks: these are source/runtime invariants for the
  // sound/shader/resource UI requested in the current refinement pass.
  test('dropdown de recurso abre mesmo vazio',()=>{const src=typeof openResourceDropdown==='function'?openResourceDropdown.toString():'';return /const resources=selectorResources\(target\.kind\);/.test(src)&&! /if \(\!resources\.length\)/.test(src);});
  test('dropdown vazio mantém ação Novo',()=>/makeRow\('Novo',newKind,\{new:true\}\)/.test(typeof openResourceDropdown==='function'?openResourceDropdown.toString():''));
  test('dropdown mantém ação Usar fórmula',()=>/makeRow\('Usar fórmula','formula'\)/.test(typeof openResourceDropdown==='function'?openResourceDropdown.toString():''));
  test('Som+ tem playback, espera e parâmetros de áudio tipados',()=>{const blocks=Array.isArray(CATEGORIES.somplus?.blocks)?CATEGORIES.somplus.blocks:[];const play=blocks.find(b=>b.n==='Tocar som'),wait=blocks.find(b=>b.n==='Tocar som e esperar terminar'),cross=blocks.find(b=>b.n==='Crossfade'),withVol=blocks.find(b=>b.n==='Tocar som com volume');return !!play&&!!wait&&play.p?.[0]?.type==='sound'&&wait.p?.[0]?.type==='sound'&&cross?.p?.[0]?.type==='sound'&&withVol?.p?.[0]?.type==='sound';});
  test('Lista de sons usa toque para pré-visualização e geometria 45% maior',()=>{const src=typeof renderSounds==='function'?renderSounds.toString():'';return /previewSound\(s\)/.test(src)&&/soundRowScale = 1\.45/.test(src)&&/createElement\('button'\)/.test(src)&&/textContent = name/.test(src);});
  test('Engine expõe pré-visualização de som',()=>typeof window.KixEngine?.previewSound==='function'&&typeof window.KixEngine?.stopPreviewSound==='function');
  test('Shaders possuem catálogo/renderizador de produção',()=>Array.isArray(CATEGORIES.shaders?.blocks)&&CATEGORIES.shaders.blocks.length>=20);
  test('shader de onda tem parâmetros de intensidade',()=>CATEGORIES.shaders.blocks.some(b=>b.n==='Aplicar distorção de onda')&&CATEGORIES.shaders.blocks.some(b=>b.n==='Definir intensidade do efeito'));
  test('GLSL personalizado continua preservado no catálogo',()=>CATEGORIES.shaders.blocks.some(b=>b.n==='Shader personalizado (GLSL)'));
  test('shader de cena tem bloco dedicado',()=>CATEGORIES.shaders.blocks.some(b=>b.n==='Aplicar shader na cena inteira'));
  test('mapeamentos Catroid não apontam para nomes ausentes',()=>Object.values(KIX_CATROBAT_MAP).every(d=>kixBlockExists(d[0])));
  test('fallback desconhecido usa bloco Nota do Kix',()=>{const src=typeof catGenericBrick==='function'?catGenericBrick.toString():'';return /catKixBlock\('Nota'/.test(src)&&!/Catrobat •/.test(src);});
  test('PinToCamera é adaptado para câmera do Kix',()=>/PinToCameraBrick/.test(typeof catAdaptiveFallback==='function'?catAdaptiveFallback.toString():'' )&&/Seguir ator com câmera/.test(typeof catAdaptiveFallback==='function'?catAdaptiveFallback.toString():''));
  test('largura Catroid é adaptada para espessura de traço',()=>/SetWidthBrick/.test(typeof catAdaptiveFallback==='function'?catAdaptiveFallback.toString():'')&&/Definir espessura do traço/.test(typeof catAdaptiveFallback==='function'?catAdaptiveFallback.toString():''));
  test('top bar usa geometria estável',()=>/kix-stable-topbar/.test(document.documentElement.innerHTML)&&/56px \+ env\(safe-area-inset-top/.test(document.documentElement.innerHTML));
  test('três pontos usam botão 40x40 fixo',()=>/btn-home-menu, #btn-project-menu, #btn-scene-menu/.test(document.documentElement.innerHTML)&&/width: 40px !important; height: 40px !important/.test(document.documentElement.innerHTML));
  test('menus de linha usam 40x40',()=>/scene-menu, \.actor-menu, \.look-menu, \.file-menu/.test(document.documentElement.innerHTML)&&/font-size: 22px !important/.test(document.documentElement.innerHTML));
  return checks;
}
function normalizedImportFormat(r){ return String(r.format||''); }

function renderCatrobatReport(p) {
  const host=$('catrobat-report-body'); if(!host) return;
  const c=p?.catrobatImport||{};
  const checks=Array.isArray(c.checks)?c.checks:[];
  const passed=Number(c.checkSummary?.passed||checks.filter(x=>x.pass).length);
  const failed=Number(c.checkSummary?.failed||checks.filter(x=>!x.pass).length);
  const badge=failed===0 ? 'OK' : 'ATENÇÃO';
  const unsupported=Object.entries(c.unsupportedTypes||{}).sort((a,b)=>b[1]-a[1]).slice(0,18);
  const missing=Array.isArray(c.missingAssets)?c.missingAssets.slice(0,18):[];
  host.innerHTML=
    `<div class="rounded-2xl border border-[#2C2C2C] bg-[#171719] p-4">
      <div class="flex items-center justify-between gap-3">
        <div class="min-w-0"><div class="text-[17px] font-medium truncate">${catEsc(p?.name||'Projeto')}</div><div class="text-[11px] text-[#777] mt-1">${catEsc(c.sourceFile||'arquivo')}</div></div>
        <span class="text-[11px] px-2 py-1 rounded-full ${failed?'bg-[#4A251F] text-[#FFB7A7]':'bg-[#17352F] text-[#8EE8CE]'}">${badge}</span>
      </div>
      <div class="grid grid-cols-2 gap-2 mt-4">
        <div class="rounded-xl bg-[#202022] p-3"><div class="text-[11px] text-[#777]">Verificações</div><div class="text-[22px] mt-1">${passed}/${checks.length}</div></div>
        <div class="rounded-xl bg-[#202022] p-3"><div class="text-[11px] text-[#777]">Blocos</div><div class="text-[22px] mt-1">${Number(c.stats?.bricks||0)}</div></div>
        <div class="rounded-xl bg-[#202022] p-3"><div class="text-[11px] text-[#777]">Cenas / objetos</div><div class="text-[15px] mt-1">${Number(c.stats?.scenes||0)} / ${Number(c.stats?.objects||0)}</div></div>
        <div class="rounded-xl bg-[#202022] p-3"><div class="text-[11px] text-[#777]">Imagens / sons</div><div class="text-[15px] mt-1">${Number(c.stats?.images||0)} / ${Number(c.stats?.sounds||0)}</div></div>
      </div>
    </div>
    <div class="mt-3 rounded-2xl border border-[#2C2C2C] bg-[#171719] p-4">
      <div class="text-[13px] font-medium">Formato</div>
      <div class="text-[12px] text-[#999] mt-2">${catEsc(c.format||'')} · Catrobat ${catEsc(c.catrobatLanguageVersion||'')} · ${catEsc(c.orientation||'')} · ${catEsc(String(c.screenWidth||''))}×${catEsc(String(c.screenHeight||''))}</div>
      <div class="text-[12px] text-[#999] mt-1">${catEsc(c.applicationName||'')} ${catEsc(c.applicationVersion||'')}</div>
    </div>
    <div class="mt-3 rounded-2xl border border-[#2C2C2C] bg-[#171719] p-4">
      <div class="text-[13px] font-medium">Check-ups de compatibilidade</div>
      <div class="mt-3 space-y-1">${checks.map(x=>`<div class="flex gap-2 text-[11px]"><span class="${x.pass?'text-[#69D7A5]':'text-[#FF8878]'}">${x.pass?kixSvgIcon('check',13):kixSvgIcon('close',13)}</span><span class="text-[#B5B5BC] flex-1">${catEsc(x.id+'. '+x.name)}${x.detail?' — '+catEsc(x.detail):''}</span></div>`).join('')}</div>
    </div>
    ${Object.keys(c.adaptedTypes||{}).length?`<div class="mt-3 rounded-2xl border border-[#2C2C2C] bg-[#171719] p-4"><div class="text-[13px] font-medium">Blocos adaptados automaticamente</div><div class="mt-2 space-y-1">${Object.entries(c.adaptedTypes||{}).sort((a,b)=>b[1]-a[1]).slice(0,18).map(([k,v])=>`<div class="flex justify-between gap-3 text-[11px]"><span class="text-[#B5B5BC]">${catEsc(k)}</span><span class="text-[#777]">${v}</span></div>`).join('')}</div></div>`:''}
    ${unsupported.length?`<div class="mt-3 rounded-2xl border border-[#2C2C2C] bg-[#171719] p-4"><div class="text-[13px] font-medium">Blocos realmente não reconhecidos</div><div class="mt-2 space-y-1">${unsupported.map(([k,v])=>`<div class="flex justify-between gap-3 text-[11px]"><span class="text-[#B5B5BC]">${catEsc(k)}</span><span class="text-[#777]">${v}</span></div>`).join('')}</div></div>`:''}
    ${missing.length?`<div class="mt-3 rounded-2xl border border-[#4A2B26] bg-[#211715] p-4"><div class="text-[13px] font-medium text-[#FFB7A7]">Assets não encontrados</div><div class="mt-2 space-y-1">${missing.map(m=>`<div class="text-[11px] text-[#B99A95]">${catEsc(m.kind)} · ${catEsc(m.scene)} · ${catEsc(m.name)}</div>`).join('')}</div>${c.missingAssets.length>missing.length?`<div class="text-[11px] text-[#77645F] mt-2">+ ${c.missingAssets.length-missing.length} outros</div>`:''}</div>`:''}
    <div class="mt-3 text-[11px] leading-5 text-[#67676E]">Blocos sem equivalente direto são adaptados automaticamente para um bloco Kix funcionalmente próximo; somente tipos sem equivalente permanecem identificados como não reconhecidos.</div>`;
}
function openCatrobatReport(p) {
  if(!p?.catrobatImport){toast('Este projeto não é uma importação Catrobat');return;}
  closeSheets();
  renderCatrobatReport(p);
  $('catrobat-report-subtitle') && ($('catrobat-report-subtitle').textContent=(p.catrobatImport.format||'Pocket Code / NewCatroid'));
  show('catrobat-report',{noAnimation:true});
}
window.openCatrobatReport=openCatrobatReport;

let _catLoadingToken = 0;
let _catLoadingTarget = 8;
let _catLoadingFrame = 0;
function animateCatrobatLoading() {
  const bar=$('catrobat-loading-bar'), pct=$('catrobat-loading-percent');
  if (!bar || !pct) return;
  const raw=Number(bar.dataset.progress||bar.style.width.replace('%','')||8);
  const current=Number.isFinite(raw)?raw:8;
  const target=Number(_catLoadingTarget)||8;
  const delta=target-current;
  const next=Math.abs(delta)<0.08?target:current+delta*0.12;
  bar.dataset.progress=String(next); bar.style.width=next.toFixed(2)+'%'; pct.textContent=Math.round(next)+'%';
  if (Math.abs(target-next)>=0.08) _catLoadingFrame=requestAnimationFrame(animateCatrobatLoading);
  else _catLoadingFrame=0;
}
function setCatrobatLoading(step, label, progress) {
  const title=$('catrobat-loading-title'), detail=$('catrobat-loading-detail'), bar=$('catrobat-loading-bar'), pct=$('catrobat-loading-percent'), st=$('catrobat-loading-step');
  if (title) title.textContent = label || 'Carregando importação';
  if (detail) detail.textContent = step || 'Preparando…';
  _catLoadingTarget=Math.max(3,Math.min(100,Number(progress)||3));
  if (bar && !bar.dataset.progress) bar.dataset.progress='8';
  if (!_catLoadingFrame && typeof requestAnimationFrame==='function') _catLoadingFrame=requestAnimationFrame(animateCatrobatLoading);
  else if (bar) bar.style.width=_catLoadingTarget+'%';
  if (st) st.textContent='Importação Catroid';
}
function showCatrobatLoading() {
  _catLoadingToken++;
  const token=_catLoadingToken;
  if (_catLoadingFrame) { try { cancelAnimationFrame(_catLoadingFrame); } catch (_) {} _catLoadingFrame=0; }
  const bar=$('catrobat-loading-bar'); if(bar) { bar.dataset.progress='8'; bar.style.width='8%'; }
  setCatrobatLoading('Preparando o arquivo…','Carregamento de importação',8);
  show('catrobat-loading',{noPush:true});
  requestAnimationFrame(()=>{ if(token===_catLoadingToken) setCatrobatLoading('Lendo o pacote offline…','Carregando projeto',22); });
  return token;
}
function showCatrobatImportResult(hasFailures) {
  const title=$('catrobat-loading-title'), detail=$('catrobat-loading-detail'), bar=$('catrobat-loading-bar'), pct=$('catrobat-loading-percent');
  if(title) title.innerHTML = hasFailures
    ? 'Importação concluída <span class=\"kix-import-result-warn\">!</span>'
    : 'Importação concluída <span class=\"kix-import-result-ok\" aria-label=\"concluída\"><svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\"><path d=\"M5 12.5l4 4L19 7\"/></svg></span>';
  if(detail) detail.textContent = hasFailures ? 'Mas com falhas' : 'Entrando no projeto...';
  if(bar) bar.style.width='100%';
  if(pct) pct.textContent='100%';
}
function experimentalResourcesEnabled() { return !!(extensions && extensions.experimental); }
function syncCatrobatMenuState() {
  const row=$('menu-import-catrobat');
  const enabled=experimentalResourcesEnabled();
  if (!row) return enabled;
  // O importador Catroid é um recurso experimental: quando desligado,
  // o item deve desaparecer completamente do menu, e não ficar cinza/desabilitado.
  row.classList.toggle('hidden',!enabled);
  row.classList.remove('kix-menu-disabled');
  row.removeAttribute('aria-disabled');
  row.removeAttribute('title');
  const hint=row.querySelector('.kix-menu-hint');
  if (hint) hint.textContent='';
  return enabled;
}
function catPrepareInput() {
  if (!experimentalResourcesEnabled()) {
    toast('Ative Recursos experimentais em Configurações');
    closeSheets();
    show('settings',{noPush:true});
    setTimeout(()=>document.querySelector('[data-ext="experimental"]')?.scrollIntoView?.({block:'center'}),60);
    return;
  }
  const inp=$('input-catrobat');
  if(inp) { inp.accept='.catrobat,.newtrobat,.zip,application/zip,application/octet-stream'; inp.multiple=false; inp.click(); }
}



function kixOpenContextMore(kind) {
  const title = $('context-more-title');
  const subtitle = $('context-more-subtitle');
  const list = $('context-more-list');
  const sheet = $('sheet-context-more');
  if (!title || !list || !sheet) return;
  const data = {
    categories: {title:'Categorias', subtitle:'Navegação e organização', items:[
      ['Buscar blocos',()=>{ closeSheets(); openKixBlockSearch(); }],
      ['Configurações de categorias',()=>{ closeSheets(); show('settings',{noPush:true}); }]
    ]},
    blocks: {title:'Blocos', subtitle:'Ações rápidas', items:[
      ['Buscar blocos',()=>{ closeSheets(); openKixBlockSearch(); }],
      ['Voltar para categorias',()=>{ closeSheets(); show('categories',{noPush:true}); }]
    ]},
    scene: {title:'Cena', subtitle:'Fluxo da cena atual', items:[
      ['Adicionar cena',()=>{ closeSheets(); addScene(); }],
      ['Executar cena',()=>{ closeSheets(); startPlay(); }]
    ]}
  }[kind] || null;
  if (!data) return;
  title.textContent=data.title;
  if (subtitle) subtitle.textContent=data.subtitle;
  list.innerHTML='';
  data.items.forEach(([label,action])=>{
    const b=document.createElement('button'); b.type='button'; b.className='w-full text-left px-3.5 py-3 rounded-xl bg-[#2A2A2F] border border-[#35353D] text-[13px] text-[#E6E6E8] active:bg-[#303039]'; b.textContent=label; b.onclick=()=>action?.(); list.appendChild(b);
  });
  openSheet('sheet-context-more');
}

function syncKixQualityUI(){
  const enabled = appOptions.kixQualityEnabled === true;
  ['menu-diagnostics','btn-open-health'].forEach(id=>{ const el=$(id); if(el) el.classList.toggle('hidden', !enabled); });
}

document.addEventListener('DOMContentLoaded', async () => {
  try {
  // Project persistence may be in IndexedDB; wait for the authoritative restore
  // before the first Home render so the recent-project action cannot flicker away.
  try { await restoreKixState(); } catch (_) { renderProjects(); }
  try { window.KixPluginRuntime?.attachApp?.({ CATEGORIES, buildCategories, openCategory, addBlockToScript, renderScripts, save, toast, kixT, getCurrentProject:()=>currentProject, getCurrentScene:()=>currentScene, getSceneActors }); } catch (e) { console.warn('Kix Plugins attach', e); }
  syncCatrobatMenuState();
  syncKixQualityUI();
  toast('Bem-vindo ao Kix');
  // ========== MASTER EVENT DELEGATION (reliable on web + mobile) ==========
  function kixNav(action) {
    try {
      if (action === 'add-block') {
        if (activeScriptTab === 'looks') openSheet('sheet-add-look');
        else if (activeScriptTab === 'sounds') openSheet('sheet-add-sound');
        else {
          window._blockPickerContext = {
            project: currentProject,
            projectId: currentProject ? ensureProjectIdentity(currentProject) : '',
            scene: currentScene,
            actor: currentActor || null,
            actorId: currentActor ? ensureActorIdentity(currentActor) : '',
            actorIdx: currentActorIdx,
            actorName: currentActor ? String(currentActor.name || '') : '',
            openedAt: Date.now()
          };
          buildCategories();
          show('categories');
        }
        return;
      }
      if (action === 'back-home') { save(); renderProjects(); show('home', { noPush: true }); return; }
      if (action === 'back-project') { leaveProjectEditor(); return; }
      if (action === 'back-scenes') { save(); navBack(); return; }
      if (action === 'back-scripts') { save(); show('scripts', { noPush: true }); return; }
      if (action === 'back-categories') { show('categories', { noPush: true }); return; }
      if (action === 'close-formula') { closeFormula(); return; }
      if (action === 'close-data') { closeDataScreen(); return; }
      if (action === 'close-image-picker') { closeImagePicker(); return; }
      if (action === 'new') { openSheet('sheet-new-project'); return; }
      if (action === 'add-actor') { openSheet('sheet-add-actor'); return; }
      if (action === 'add-scene') { addScene(); return; }
      if (action === 'play') { startPlay(); return; }
      if (action === 'home-play') {
        if (projects.length) openProject(0, { origin: 'home' });
        else toast('Nenhum projeto ainda');
        return;
      }
      if (action === 'stop-play') { stopPlay(); return; }
      if (action === 'home-menu') { openSheet('sheet-home-menu'); return; }
      if (action === 'project-menu') { openProjectOptionsScreen(); return; }
      if (action === 'scene-menu') { kixOpenContextMore('scene'); return; }
      if (action === 'cat-menu') { kixOpenContextMore('categories'); return; }
      if (action === 'blocks-menu') { kixOpenContextMore('blocks'); return; }
    } catch (err) {
      console.error('kixNav', action, err);
      toast('Erro: ' + (err.message || err));
    }
  }

  $('btn-cat-search')?.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); openKixBlockSearch(); });
  $('btn-blocks-search')?.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); openKixBlockSearch(); });
  $('btn-kix-block-search-close')?.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); closeKixBlockSearch(); });
  $('kix-block-search-overlay')?.addEventListener('click', e => { if (e.target === e.currentTarget) closeKixBlockSearch(); });

  ['btn-scene-menu','btn-cat-menu','btn-blocks-menu'].forEach(id => {
    const el = $(id);
    if (!el || el.dataset.kixContextMoreBound === '1') return;
    el.dataset.kixContextMoreBound = '1';
    el.addEventListener('click', ev => {
      ev.preventDefault(); ev.stopPropagation();
      if (id === 'btn-scene-menu') kixOpenContextMore('scene');
      else if (id === 'btn-cat-menu') kixOpenContextMore('categories');
      else kixOpenContextMore('blocks');
    });
  });

  document.addEventListener('click', function (e) {
    const el = e.target.closest('[id], .tab-btn, .ctx-action, button, a');
    if (!el) return;

    // Tabs
    if (el.classList && el.classList.contains('tab-btn') && el.dataset.tab) {
      e.preventDefault();
      switchTab(el.dataset.tab);
      return;
    }

    // Context menu actions
    if (el.classList && el.classList.contains('ctx-action')) {
      e.preventDefault();
      e.stopPropagation();
      if (typeof handleCtxAction === 'function') handleCtxAction(el.dataset.act);
      else if (typeof closeBlockContext === 'function') closeBlockContext();
      return;
    }

    // Overlay background close
    if (el.id === 'block-ctx-overlay') {
      closeBlockContext();
      return;
    }

    if (appOptions.feedback !== false && el.tagName === 'BUTTON') { el.classList.remove('kix-press-feedback'); void el.offsetWidth; el.classList.add('kix-press-feedback'); }
    const id = el.id;
    if (!id) return;

    const map = {
      'btn-add-block': 'add-block',
      'btn-back-home': 'back-home',
      'btn-back-project': 'back-project',
      'btn-back-scenes': 'back-scenes',
      'btn-back-scripts': 'back-scripts',
      'btn-back-categories': 'back-categories',
      'btn-back-settings': 'back-home',
      'btn-back-app-options': 'back-home',
      'btn-close-formula': 'close-formula',
      'btn-close-image-picker': 'close-image-picker',
      'btn-new': 'new',
      'btn-add-actor': 'add-actor',
      // fab handled by onclick only — avoid double addScene
      // 'btn-add-scene-fab': 'add-scene',
      'btn-play': 'play',
      'home-play-btn': 'home-play',
      'btn-play-script': 'play',
      'btn-play-scene': 'play',
      'btn-stop-play': 'stop-play',
      'btn-home-menu': 'home-menu',
      'btn-project-menu': 'project-menu'
    };
    if (map[id]) {
      // Static nav controls already have a direct onclick handler. Let that single
      // handler own the action; otherwise the delegated listener opens the same
      // screen a second time, creating the 'several screens opening' visual glitch.
      if (typeof el.onclick === 'function') return;
      e.preventDefault();
      e.stopPropagation();
      kixNav(map[id]);
    }
  }, false);

  // Also touchend for stubborn mobile browsers
  document.addEventListener('touchend', function (e) {
    const el = e.target.closest('#btn-add-block, #btn-back-home, #btn-back-project, #btn-back-scenes, #btn-back-scripts, #btn-back-categories, #btn-close-formula, .tab-btn, .ctx-action');
    if (!el) return;
    // let click handler fire; only force for add-block if needed
    if (el.id === 'btn-add-block') {
      e.preventDefault();
      kixNav('add-block');
    }
  }, { passive: false });



  // Navigation
  $('btn-new') && ($('btn-new').onclick = () => openSheet('sheet-new-project'));
  $('btn-home-menu') && ($('btn-home-menu').onclick = () => openSheet('sheet-home-menu'));
  $('btn-project-menu') && ($('btn-project-menu').onclick = () => openProjectOptionsScreen());
  $('btn-add-actor') && ($('btn-add-actor').onclick = (e) => { e?.preventDefault?.(); e?.stopPropagation?.(); openSheet('sheet-add-actor'); });
  $('btn-back-project') && ($('btn-back-project').onclick = () => leaveProjectEditor());
  // + button: Scripts → categories | Aparência → look sheet | Sons → sound sheet
  function onAddBlockClick(e) {
    if (e) { e.preventDefault && e.preventDefault(); e.stopPropagation && e.stopPropagation(); }
    kixNav('add-block');
  }
  const btnAdd = $('btn-add-block');
  if (btnAdd) {
    btnAdd.onclick = onAddBlockClick;
  }
  $('btn-back-scripts') && ($('btn-back-scripts').onclick = () => returnFromCategoryPicker());
  $('btn-back-collision') && ($('btn-back-collision').onclick = () => navBack());
  $('btn-save-collision') && ($('btn-save-collision').onclick = () => saveCollisionEditor());
  $('btn-back-categories') && ($('btn-back-categories').onclick = () => show('categories', { noPush: true }));
  $('btn-play') && ($('btn-play').onclick = startPlay);
  $('btn-play-script') && ($('btn-play-script').onclick = startPlay);
  $('btn-stop-play') && ($('btn-stop-play').onclick = stopPlay);
  $('btn-restart-play') && ($('btn-restart-play').onclick = () => {
    if (window.KixEngine && currentProject) {
      camX = 0; camY = 0; camZoom = 1; freeCam = false;
      if (typeof applyCamTransform === 'function') applyCamTransform();
      $('free-cam-hint')?.classList.add('hidden');
      $('btn-free-cam')?.classList.remove('text-[#34D399]');
      $('btn-free-cam')?.classList.add('text-[#aaa]');
      const g = Object.assign({}, globals || {}, currentProject.vars || {});
      if (KixEngine.restartEngine) {
        KixEngine.restartEngine(currentProject, currentScene, g);
      } else {
        KixEngine.stopEngine();
        try { window.KixLifecycle?.enter?.('play'); } catch (_) {}
    KixEngine.startEngine(currentProject, currentScene, g);
    try { window.KixLifecycle?.leave?.(); } catch (_) {}
      }
      toast('Reiniciado');
      if (typeof updateGlobalsPanel === 'function') updateGlobalsPanel();
    }
  });
  $('btn-free-cam') && ($('btn-free-cam').onclick = toggleFreeCam);
  setupFreeCamGestures();
  $('btn-pause-play')?.addEventListener('click', () => { if (window.KixEngine) { const p=KixEngine.togglePause(); updatePlayStateUI(p); const b=$('btn-pause-play'); b?.classList.remove('kix-play-state-pulse'); void b?.offsetWidth; b?.classList.add('kix-play-state-pulse'); } });
  $('btn-play-more')?.addEventListener('click', () => $('play-more-menu')?.classList.toggle('hidden'));
  $('play-more-rotate')?.addEventListener('click', () => { rotatePlayScreen(); $('play-more-menu')?.classList.add('hidden'); });
  $('play-more-camera')?.addEventListener('click', () => { toggleFreeCam(); $('play-more-menu')?.classList.add('hidden'); });
  $('play-more-axes')?.addEventListener('click', () => { showAxes=!showAxes; $('axes-overlay')?.classList.toggle('hidden',!showAxes); $('play-more-menu')?.classList.add('hidden'); });
  $('play-more-collision')?.addEventListener('click', () => { if(window.KixEngine?.runtime) { const r=window.KixEngine.runtime; r.debugCollisions = !r.debugCollisions; const stage = document.getElementById('play-stage'); if (stage) r.stageEl = stage; try { window.KixEngine.renderCollisionDebug?.(); } catch(_) {} const b=$('play-more-collision'); if(b) b.textContent = r.debugCollisions ? 'Ocultar colisões' : 'Mostrar colisões'; } $('play-more-menu')?.classList.add('hidden'); });
  $('play-more-selftest')?.addEventListener('click', () => { const r=window.KixEngine?.selfTest ? KixEngine.selfTest() : {ok:false}; console.table(r.results||[]); toast(r.ok?'Verificação concluída: OK':'Verificação encontrou falhas — veja o console'); $('play-more-menu')?.classList.add('hidden'); });
  $('play-more-clean')?.addEventListener('click', () => { setPlayCleanMode(true); $('play-more-menu')?.classList.add('hidden'); });
  $('btn-play-restore-ui')?.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    setPlayCleanMode(false);
  });
  $('visual-position-cancel')?.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); cancelVisualPositionPlacement(); });
  $('visual-position-confirm')?.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); finishVisualPositionPlacement(true); });
  $('btn-toggle-axes') && ($('btn-toggle-axes').onclick = () => {
    showAxes = !showAxes;
    $('axes-overlay')?.classList.toggle('hidden', !showAxes);
    toast(showAxes ? 'Eixos ativos' : 'Eixos desativados');
  });
  $('btn-debug-menu') && ($('btn-debug-menu').onclick = () => {
    $('debug-panel')?.classList.toggle('hidden');
    updateGlobalsPanel();
  });

  $('actor-fundo') && ($('actor-fundo').onclick = () => {
    ensureBackgroundActor();
    openActor(0);
  });

  document.querySelectorAll('.tab-btn').forEach(b => {
    b.onclick = () => switchTab(b.dataset.tab);
  });

  // Visual image picker for the four image parameters.
  $('btn-image-picker-formula') && ($('btn-image-picker-formula').onclick = () => {
    const target = window._imagePickerTarget && window._imagePickerTarget.el;
    if (!target) { toast('Parâmetro não encontrado'); return; }
    const targetCopy = target;
    window._imagePickerTarget = null;
    $('screen-image-picker')?.classList.add('hidden');
    openFormula(targetCopy);
  });
  $('btn-image-picker-add') && ($('btn-image-picker-add').onclick = () => {
    if (!currentActor) { toast('Abra um objeto primeiro'); return; }
    window._importMode = 'image-picker';
    $('input-actor-image')?.click();
  });
  $('btn-close-image-picker') && ($('btn-close-image-picker').onclick = closeImagePicker);
  $('screen-image-picker') && ($('screen-image-picker').onclick = (e) => { if (e.target.id === 'screen-image-picker') closeImagePicker(); });
  document.addEventListener('pointerdown', (e) => {
    const picker = $('screen-image-picker');
    const panel = $('image-picker-panel');
    if (!picker || picker.classList.contains('hidden') || !panel) return;
    if (!panel.contains(e.target)) closeImagePicker();
  }, true);

  document.addEventListener('pointerdown', e => {
    // Let the variable selector receive its own pointer sequence. The
    // delegated capture-click handler below opens its dropdown.
    if (e.target?.closest?.('.kix-variable-selector[data-variable-selector="1"]')) return;
    const menu=document.querySelector('.kix-inline-dropdown');
    if (menu && menu.contains(e.target)) return;
    if (menu) {
      // The existing capture listener is the lightweight invisible wall: close
      // first and stop the same gesture from reaching the Brick underneath.
      closeInlineResourceDropdown();
      e.preventDefault();
      e.stopImmediatePropagation();
      return;
    }
    closeInlineResourceDropdown();
  }, true);
  // One authoritative click path for the variable selector. It runs in capture
  // before both the Brick handler and the generic formula handler. A variable
  // tap can therefore open the dropdown, but can never fall through to
  // openFormula(). Tapping the variable while a menu is already open counts as
  // an outside tap and closes the menu instead of immediately reopening it.
  document.addEventListener('click', e => {
    const variable = e.target?.closest?.('.kix-variable-selector[data-variable-selector="1"]');
    if (variable && variable.closest('#script-blocks .pc-block')) {
      e.preventDefault();
      e.stopImmediatePropagation();
      const menu = document.querySelector('.kix-variable-inline-dropdown');
      if (menu) closeInlineResourceDropdown();
      else openKixVariableDropdown(variable);
      return;
    }
    const menu=document.querySelector('.kix-inline-dropdown');
    if (!menu || menu.contains(e.target)) return;
    // Prevent an outside tap from activating the Brick after the menu is closed.
    e.preventDefault();
    e.stopImmediatePropagation();
    closeInlineResourceDropdown();
  }, true);
  document.addEventListener('scroll', e => {
    // Variable lists are intentionally allowed to scroll without being closed.
    // Resource dropdowns preserve the previous lifecycle and close on page
    // scrolling.
    const target = e?.target;
    if (target && target.closest && target.closest('.kix-variable-inline-dropdown')) return;
    const variableMenu = document.querySelector('.kix-variable-inline-dropdown');
    if (variableMenu && (target === variableMenu || variableMenu.contains(target))) return;
    closeInlineResourceDropdown();
  }, true);
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    if (!$('formula-result-screen')?.classList.contains('hidden')) { closeFormulaResultScreen(); return; }
    closeInlineResourceDropdown();
    try { closeKixBlockSearch(); } catch (_) {}
    try { closeImagePicker(); } catch (_) {}
    try { closeBlockContext(); } catch (_) {}
    try { closeSheets(); } catch (_) {}
  });
  window.addEventListener('resize', () => closeInlineResourceDropdown());
  window.addEventListener('resize', () => { if ($('screen-formula') && !$('screen-formula').classList.contains('hidden')) requestAnimationFrame(syncFormulaExprViewport); });
  if (window.visualViewport) window.visualViewport.addEventListener('resize', () => closeInlineResourceDropdown());

  // Formula
  $('btn-close-formula') && ($('btn-close-formula').onclick = closeFormula);
  document.addEventListener('click', e => {
    const imageTarget = e.target.closest && e.target.closest('.formula-open, .param');
    const targetBlock = imageTarget?.closest?.('.pc-block');
    const isScriptEditableParam = !!(targetBlock && targetBlock.closest('#script-blocks'));
    // Catalogue/search/palette Bricks are read-only prototypes. Their fields are
    // intentionally inert until the Brick has been inserted into Scripts.
    if (!isScriptEditableParam) return;
    if (imageTarget && imageTarget.dataset?.variableSelector === '1') {
      e.preventDefault();
      e.stopImmediatePropagation();
      return;
    }
    if (imageTarget && String(imageTarget.dataset?.dropdownType || '').length) {
      e.preventDefault();
      e.stopImmediatePropagation();
      openResourceDropdown(imageTarget);
      return;
    }
    if (imageTarget && isImageParamPickerTarget(imageTarget)) {
      e.preventDefault();
      e.stopImmediatePropagation();
      openImagePicker(imageTarget);
      return;
    }
    if (e.target.closest?.('.kix-variable-selector[data-variable-selector="1"]')) {
      e.preventDefault();
      e.stopImmediatePropagation();
      return;
    }
    if (e.target.classList.contains('formula-open') || (e.target.classList.contains('param') && e.target.closest('.pc-block'))) {
      const block = e.target.closest('.pc-block');
      if (!isScriptEditableParam) return;
      if (block && !block.dataset.name) {
        // try extract from text
        const t = block.innerText || '';
        block.dataset.name = t.split('\n')[0].trim().slice(0, 50);
      }
      openFormula(e.target);
    }
  });
  let formulaDeleteRepeatTimer = null;
  let formulaDeleteRepeatDelay = null;
  let formulaDeletePointerActive = false;
  let formulaDeleteSkipClick = false;
  const stopFormulaDeleteRepeat = () => {
    if (formulaDeleteRepeatDelay) { if (window.KixLifecycle?.clear) window.KixLifecycle.clear(formulaDeleteRepeatDelay, 'formula'); else clearTimeout(formulaDeleteRepeatDelay); formulaDeleteRepeatDelay = null; }
    if (formulaDeleteRepeatTimer) { if (window.KixLifecycle?.clear) window.KixLifecycle.clear(formulaDeleteRepeatTimer, 'formula'); else clearInterval(formulaDeleteRepeatTimer); formulaDeleteRepeatTimer = null; }
    formulaDeletePointerActive = false;
  };
  const deleteFormulaChar = () => {
    const current = String(formulaVal == null ? '' : formulaVal);
    const at = Math.max(0, Math.min(formulaCursorIndex, current.length));
    if (at <= 0 || !current) return;
    const next = current.slice(0, at - 1) + current.slice(at);
    formulaCursorIndex = at - 1;
    setFormulaValue(next, {fresh:false});
  };

  function copyFormulaToClipboard() {
    const text = String(formulaVal == null ? '' : formulaVal);
    if (!text) { toast('Fórmula vazia'); return; }
    formulaInternalClipboard = text;
    try { navigator.clipboard?.writeText?.(text)?.catch?.(() => {}); } catch (_) {}
    toast('Fórmula copiada');
  }

  async function readFormulaClipboard() {
    const internal = String(formulaInternalClipboard || '').replace(/\r\n?/g, '\n').trim();
    if (internal) return internal;
    try {
      const system = await navigator.clipboard?.readText?.();
      return String(system || '').replace(/\r\n?/g, '\n').trim();
    } catch (_) {
      return '';
    }
  }

  async function pasteFormulaFromClipboard() {
    const text = await readFormulaClipboard();
    if (!text) {
      toast('Nenhuma fórmula copiada');
      return false;
    }
    // Paste is an explicit replacement operation. It must not depend on
    // formulaFresh or on the current formula being empty.
    formulaCursorIndex = text.length;
    setFormulaValue(text, {fresh:false, record:true, sync:true});
    formulaFresh = false;
    toast('Fórmula colada');
    return true;
  }

  function cloneFormulaRuntimeValue(value) {
    try {
      if (typeof structuredClone === 'function') return structuredClone(value);
    } catch (_) {}
    try { return JSON.parse(JSON.stringify(value)); } catch (_) { return value; }
  }

  function capturePlayVariableSnapshot() {
    try {
      const rt = window.KixEngine?.runtime || null;
      const globalsSnap = {};
      const sourceGlobals = rt?.globals && typeof rt.globals === 'object' ? rt.globals : {};
      Object.keys(sourceGlobals).forEach(k => { globalsSnap[k] = cloneFormulaRuntimeValue(sourceGlobals[k]); });
      const actors = {};
      (rt?.actors || []).forEach((ra, idx) => {
        const data = ra?.data || {};
        const id = String(data.kixId || data.id || data.name || idx);
        const vars = data._vars && typeof data._vars === 'object' ? data._vars : {};
        actors[id] = {};
        Object.keys(vars).forEach(k => { actors[id][k] = cloneFormulaRuntimeValue(vars[k]); });
      });
      playClosedVariableSnapshot = { globals: globalsSnap, actors, at: Date.now() };
      return playClosedVariableSnapshot;
    } catch (e) {
      console.warn('capturePlayVariableSnapshot', e);
      playClosedVariableSnapshot = null;
      return null;
    }
  }
  window.__kixCapturePlayVariableSnapshot = capturePlayVariableSnapshot;

  function formulaCalculationContext() {
    const rt = window.KixEngine?.runtime || null;
    const runtimeActor = rt?.actors?.[currentActorIdx] || (rt?.actors || []).find(a => a?.data === currentActor) || null;
    const actor = runtimeActor?.data || currentActor || {};
    const snapshot = playClosedVariableSnapshot;
    const snapshotGlobals = snapshot?.globals && typeof snapshot.globals === 'object' ? snapshot.globals : null;
    const actorSnapshotKey = (() => {
      try { return currentActor ? String(ensureActorIdentity(currentActor)) : ''; } catch (_) { return ''; }
    })();
    const snapshotActorVars = actorSnapshotKey && snapshot?.actors?.[actorSnapshotKey] ? snapshot.actors[actorSnapshotKey] : null;
    const vars = Object.assign({}, currentActor?._vars || {}, currentActor?.vars || {}, actor?._vars || {});
    const globalsNow = Object.assign({}, globals || {}, currentProject?.vars || {}, rt?.globals || {});
    if (snapshotGlobals) Object.assign(globalsNow, snapshotGlobals);
    if (snapshotActorVars) Object.assign(vars, snapshotActorVars);
    try {
      ensureProjectDataDefinitions(currentProject);
      for (const def of (currentProject?.dataDefinitions || [])) {
        if (!def?.name) continue;
        let value = dataDefinitionValue(def, currentActor);
        if (def.scope === 'object') {
          if (snapshotActorVars && Object.prototype.hasOwnProperty.call(snapshotActorVars, def.name)) value = snapshotActorVars[def.name];
          else if (actor?._vars && Object.prototype.hasOwnProperty.call(actor._vars, def.name)) value = actor._vars[def.name];
        } else if (snapshotGlobals && Object.prototype.hasOwnProperty.call(snapshotGlobals, def.name)) {
          value = snapshotGlobals[def.name];
        } else if (rt?.globals && Object.prototype.hasOwnProperty.call(rt.globals, def.name)) {
          value = rt.globals[def.name];
        }
        vars[def.name] = value;
        if (def.scope !== 'object') globalsNow[def.name] = value;
      }
    } catch (_) {}
    return { actor, runtimeActor, vars, globals: globalsNow };
  }

  function replaceFormulaVariablesForEngine(source, context) {
    const raw = String(source == null ? '' : source).trim();
    const candidates = [...new Set([...Object.keys(context?.vars || {}), ...Object.keys(context?.globals || {})])]
      .map(String)
      .filter(name => /^[A-Za-zÀ-ÿ_][A-Za-zÀ-ÿ0-9_]*(?:\s+[A-Za-zÀ-ÿ_][A-Za-zÀ-ÿ0-9_]*)*$/.test(name.trim()))
      .sort((a,b) => b.length - a.length);
    const mappedVars = Object.assign({}, context?.vars || {});
    let expr = raw;
    let serial = 0;
    for (const name of candidates) {
      const sourceValue = Object.prototype.hasOwnProperty.call(context.vars || {}, name) ? context.vars[name] : context.globals?.[name];
      const safeName = '__kix_calc_var_' + (serial++);
      let changed = false;
      const escapeRe = name.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const re = new RegExp('(^|[^A-Za-zÀ-ÿ0-9_])' + escapeRe + '(?=$|[^A-Za-zÀ-ÿ0-9_])(?!\\s*\\()', 'giu');
      let inQuote = false;
      let quote = '';
      const chunks = [];
      let start = 0;
      for (let i=0; i<expr.length; i++) {
        const ch = expr[i];
        if ((ch === '"' || ch === "'") && expr[i-1] !== '\\') {
          if (!inQuote) { if (i>start) chunks.push(expr.slice(start,i)); quote=ch; inQuote=true; start=i; }
          else if (quote===ch) { chunks.push(expr.slice(start,i+1)); start=i+1; inQuote=false; quote=''; }
        }
      }
      if (start < expr.length) chunks.push(expr.slice(start));
      if (!inQuote && chunks.length===0) chunks.push(expr);
      // Apply replacement only to unquoted chunks; quoted literals stay byte-for-byte unchanged.
      let rebuilt='';
      let quoted=false;
      for (const chunk of chunks) {
        if ((chunk.startsWith('"') && chunk.endsWith('"')) || (chunk.startsWith("'") && chunk.endsWith("'"))) {
          rebuilt += chunk; quoted=false;
        } else {
          const replaced = chunk.replace(re, (m, lead) => { changed=true; return lead + safeName; });
          rebuilt += replaced;
        }
      }
      if (changed) {
        mappedVars[safeName] = sourceValue;
        expr = rebuilt;
      }
    }
    return { expression: expr, vars: mappedVars };
  }

  function evaluateFormulaNow() {
    const context = formulaCalculationContext();
    if (typeof window.KixEngine?.evalFormula !== 'function') return { ok:false, value:'—', expression:String(formulaVal || '') };
    const prepared = replaceFormulaVariablesForEngine(formulaVal, context);
    const value = window.KixEngine.evalFormula(prepared.expression, {
      actor: context.actor,
      runtimeActor: context.runtimeActor,
      vars: prepared.vars,
      globals: context.globals
    });
    return { ok:true, value: value == null ? '' : value, expression: prepared.expression };
  }

  function closeFormulaResultScreen() {
    if (formulaResultLiveTimer) { if (window.KixLifecycle?.clear) window.KixLifecycle.clear(formulaResultLiveTimer, 'formula'); else clearInterval(formulaResultLiveTimer); formulaResultLiveTimer = null; }
    const screen = $('formula-result-screen');
    if (screen) {
      screen.classList.add('hidden');
      screen.setAttribute('aria-hidden','true');
    }
  }

  let lastFormulaResultDisplay = null;
  function updateFormulaResultScreen() {
    const out = evaluateFormulaNow();
    const display = out.ok ? String(out.value) : '—';
    if (display !== lastFormulaResultDisplay) {
      const value = $('formula-result-screen-val');
      if (value) value.textContent = display;
      const inline = $('formula-result-val');
      if (inline) inline.textContent = display;
      lastFormulaResultDisplay = display;
    }
    return out;
  }

  function openFormulaResultScreen() {
    const screen = $('formula-result-screen');
    if (!screen) return;
    closeFormulaResultScreen();
    screen.classList.remove('hidden');
    screen.setAttribute('aria-hidden','false');
    updateFormulaResultScreen();
    // Re-read live data at 10 Hz while the result sheet is visible. This is
    // fast enough for rapidly changing values while avoiding a 20 Hz full
    // formula/context rebuild on the UI thread. Only changed text is written
    // to the DOM by updateFormulaResultScreen().
    try { window.KixLifecycle?.enter?.('formula'); } catch (_) {}
    formulaResultLiveTimer = (window.KixLifecycle?.setInterval ? window.KixLifecycle.setInterval : setInterval)(updateFormulaResultScreen, 100, 'formula', {name:'formula-result-live'});
    try { window.KixLifecycle?.leave?.(); } catch (_) {}
  }

  document.querySelectorAll('.key').forEach(btn => {
    const v = btn.textContent.trim();
    if (v === '⌫') {
      btn.addEventListener('pointerdown', e => {
        if (e.button !== undefined && e.button !== 0) return;
        e.preventDefault();
        formulaDeletePointerActive = true;
        try { btn.setPointerCapture?.(e.pointerId); } catch (_) {}
        deleteFormulaChar();
        formulaDeleteRepeatDelay = (window.KixLifecycle?.setTimeout ? window.KixLifecycle.setTimeout : setTimeout)(() => {
          if (!formulaDeletePointerActive) return;
          formulaDeleteRepeatTimer = (window.KixLifecycle?.setInterval ? window.KixLifecycle.setInterval : setInterval)(deleteFormulaChar, 62, 'formula', {name:'formula-delete-repeat'});
        }, 320, 'formula', {name:'formula-delete-delay'});
      }, {passive:false});
      btn.addEventListener('pointerup', e => { formulaDeleteSkipClick = true; stopFormulaDeleteRepeat(); try { btn.releasePointerCapture?.(e.pointerId); } catch (_) {} setTimeout(() => { formulaDeleteSkipClick = false; }, 0); }, {passive:false});
      btn.addEventListener('pointercancel', () => { formulaDeleteSkipClick = true; stopFormulaDeleteRepeat(); setTimeout(() => { formulaDeleteSkipClick = false; }, 0); }, {passive:true});
      btn.addEventListener('lostpointercapture', stopFormulaDeleteRepeat, {passive:true});
      // Keyboard activation remains a single deletion.
      btn.addEventListener('click', e => {
        if (formulaDeletePointerActive || formulaDeleteSkipClick) { e.preventDefault(); e.stopImmediatePropagation(); formulaDeleteSkipClick = false; return; }
        deleteFormulaChar();
      });
      return;
    }
    btn.onclick = async () => {
      if (btn.classList.contains('key-copy')) {
        await copyFormulaToClipboard();
        return;
      }
      if (btn.classList.contains('key-paste')) {
        await pasteFormulaFromClipboard();
        return;
      }
      if (btn.classList.contains('key-calculate') || v === 'Calcular') {
        const out = evaluateFormulaNow();
        const rv=$('formula-result-val'), rr=$('formula-result');
        if(rv) rv.textContent=out.ok ? String(out.value) : '—'; if(rr) rr.classList.remove('hidden');
        openFormulaResultScreen();
        return;
      } else if (v === 'Abc') {
        openFormulaTextScreen();
        return;
      }
      applyFormulaInput(v);
    };
  });

  // The expression is an editable-position surface. Clicking a character chooses
  // before/after that character; clicking empty space chooses the end.
  $('formula-expr')?.addEventListener('click', e => {
    const el = $('formula-expr');
    if (!el) return;
    const raw = String(formulaVal == null ? '' : formulaVal);
    const charEl = e.target?.closest?.('.formula-char');
    if (!charEl || !el.contains(charEl)) {
      formulaCursorIndex = raw.length;
      renderFormulaExpr();
      return;
    }
    const i = Math.max(0, Math.min(parseInt(charEl.dataset.formulaIndex || '0', 10), raw.length));
    const rect = charEl.getBoundingClientRect();
    formulaCursorIndex = i + (e.clientX >= rect.left + rect.width / 2 ? 1 : 0);
    renderFormulaExpr();
  });

  // Formula history controls stay local to this editor instance.
  $('formula-undo')?.addEventListener('click', undoFormula);
  $('formula-redo')?.addEventListener('click', redoFormula);
  updateFormulaHistoryButtons();

  // Formula category chips: each category opens its own dedicated screen.
  document.querySelectorAll('.formula-cat').forEach(chip => {
    chip.addEventListener('click', async e => {
      e.preventDefault();
      e.stopPropagation();
      const action = chip.dataset.action;
      if (action === 'copy') { await copyFormulaToClipboard(); return; }
      if (action === 'paste') { await pasteFormulaFromClipboard(); return; }
      openFormulaCategoryScreen(chip.dataset.cat || chip.textContent.trim());
    });
  });
  $('formula-result-screen-close')?.addEventListener('click', closeFormulaResultScreen);
  $('formula-result-screen')?.addEventListener('pointerdown', e => {
    if (e.target === $('formula-result-screen') || e.target.matches?.('[data-formula-result-cancel]')) closeFormulaResultScreen();
  });
  $('formula-category-search')?.addEventListener('input', e => renderFormulaCategoryList(e.target.value));
  $('formula-category-back')?.addEventListener('click', closeFormulaCategoryScreen);
  $('formula-category-search-btn')?.addEventListener('click', toggleFormulaCategorySearch);
  $('formula-category-more-btn')?.addEventListener('click', e => { e.stopPropagation(); openFormulaCategoryMenu(e.currentTarget); });
  $('formula-text-ok') && ($('formula-text-ok').onclick = commitFormulaText);
  $('formula-text-cancel')?.addEventListener('click', closeFormulaTextScreen);
  $('formula-text-screen')?.addEventListener('pointerdown', e => {
    if(e.target === $('formula-text-screen') || e.target.matches?.('[data-formula-text-cancel]')) closeFormulaTextScreen();
  });
  $('formula-text-editor')?.addEventListener('keydown', e => { if((e.ctrlKey||e.metaKey) && e.key==='Enter'){ e.preventDefault(); commitFormulaText(); } });

  // Data screen entry from formula picker.
  $('data-search-input')?.addEventListener('input', e => renderDataList(e.target.value));
  $('btn-data-back')?.addEventListener('click', closeDataScreen);
  $('btn-data-search')?.addEventListener('click', () => {
    const wrap=$('data-search-wrap'), input=$('data-search-input');
    const opening=wrap?.classList.contains('hidden'); wrap?.classList.toggle('hidden',!opening);
    if(opening){setTimeout(()=>{input?.focus({preventScroll:true});kixRequestKeyboard(input);},40);} else {if(input) input.value='';renderDataList('');}
  });
  $('btn-data-more')?.addEventListener('click', e => {
    closeDataMiniMenu();
    const menu=document.createElement('div'); menu.id='kix-data-screen-menu'; menu.className='kix-data-mini-menu';
    [['Recarregar',()=>renderDataList($('data-search-input')?.value||'')],['Voltar ao editor de fórmula',closeDataScreen]].forEach(([label,fn])=>{const b=document.createElement('button');b.type='button';b.className='kix-data-mini-action';b.textContent=label;b.onclick=()=>{menu.remove();fn();};menu.appendChild(b);});
    document.body.appendChild(menu); const r=e.currentTarget.getBoundingClientRect(),w=Math.min(220,window.innerWidth-20);menu.style.width=w+'px';menu.style.left=Math.max(10,window.innerWidth-w-10)+'px';menu.style.top=Math.min(window.innerHeight-menu.offsetHeight-10,r.bottom+6)+'px';
    setTimeout(()=>document.addEventListener('pointerdown',function outside(ev){if(!menu.contains(ev.target)&&ev.target!==e.currentTarget){menu.remove();document.removeEventListener('pointerdown',outside,true);}},true),0);
  });
  $('btn-data-add')?.addEventListener('click', () => openDataEditor(null));
  $('data-modal-cancel')?.addEventListener('click', closeDataEditor);
  $('data-modal-save')?.addEventListener('click', commitDataEditor);
  $('data-create-modal')?.addEventListener('click', e => { if(e.target.id==='data-create-modal') closeDataEditor(); });
  document.addEventListener('keydown', e => { if(e.key==='Escape'){ if(!$('data-create-modal')?.classList.contains('hidden')){closeDataEditor();return;} if(!$('formula-text-screen')?.classList.contains('hidden')){closeFormulaTextScreen();return;} if(!$('formula-category-screen')?.classList.contains('hidden')){closeFormulaCategoryScreen();return;} if(lastScreen==='data'){closeDataScreen();} } });

  // Sheets
  $('sheet-backdrop') && ($('sheet-backdrop').onclick = closeSheets);
  document.querySelectorAll('.sheet-item').forEach(item => {
    item.onclick = async () => {
      const a = item.dataset.action;
      closeSheets();
      if (a === 'create-empty') openCreateProjectScreen(false);
      if (a === 'create-test-game') createKixTestGame();
      if (a === 'create-named') openCreateProjectScreen(false);
      if (a === 'actor-empty') addActor();
      if (a === 'actor-rename') {
        const actors = getSceneActors();
        const i = window._actorMenuIdx;
        if (actors[i]) {
          askText('Renomear objeto','Novo nome:',actors[i].name,n=>{ if(n){actors[i].name=n;save();renderActors();toast('Renomeado');} });
        }
      }
      if (a === 'actor-duplicate') {
        const actors = getSceneActors();
        const i = window._actorMenuIdx;
        if (actors[i]) {
          const copy = JSON.parse(JSON.stringify(actors[i]));
          copy.name = (copy.name || 'Objeto') + ' cópia';
          if (window.KixEngine) copy.scripts = (copy.scripts || []).map(s => ({...s, id: KixEngine.newId()}));
          actors.splice(i + 1, 0, copy);
          save(); renderActors(); toast('Duplicado');
        }
      }
      if (a === 'actor-set-pos') {
        const actors = getSceneActors();
        const i = window._actorMenuIdx;
        if (actors[i]) { actors[i].x = 0; actors[i].y = 0; save(); toast('Posição 0,0'); }
      }
      if (a === 'actor-show') {
        const actors = getSceneActors();
        const i = window._actorMenuIdx;
        if (actors[i]) { actors[i].visible = true; save(); toast('Visível'); }
      }
      if (a === 'actor-hide') {
        const actors = getSceneActors();
        const i = window._actorMenuIdx;
        if (actors[i]) { actors[i].visible = false; save(); toast('Escondido'); }
      }
      if (a === 'actor-size-100') {
        const actors = getSceneActors();
        const i = window._actorMenuIdx;
        if (actors[i]) { actors[i].size = 100; save(); toast('Tamanho 100%'); }
      }
      if (a === 'actor-collision') {
        const actors = getSceneActors();
        const i = window._actorMenuIdx;
        if (actors[i]) { currentActorIdx = i; currentActor = actors[i]; closeSheets(); openCollisionEditor(); }
      }
      if (a === 'actor-delete') {
        const actors = getSceneActors();
        const i = window._actorMenuIdx;
        if (actors[i] && actors.length > 1) {
          actors.splice(i, 1); save(); renderActors(); toast('Excluído');
        } else toast('Não é possível excluir');
      }
      
      
      if (a === 'actor-gallery') { window._importMode = 'new-actor'; $('input-actor-image')?.click(); }
      if (a === 'actor-draw') {
        closeSheets();
        window.KixPaint?.open({
          mode: 'new-actor',
          onSave: (dataUrl, frames) => {
            addActor('Objeto', dataUrl);
            if (frames && frames.length > 1 && currentActor) {
              frames.slice(1).forEach(f => currentActor.looks.push(f.src));
              currentActor.frameDurations = frames.map(f => f.ms);
              syncActorToProject(); save(); renderLooks();
            }
          }
        });
      }
      if (a === 'actor-camera' || a === 'actor-take-photo') {
        window._importMode = 'new-actor';
        const inp = $('input-actor-image');
        if (inp) { inp.setAttribute('capture','environment'); inp.click(); inp.removeAttribute('capture'); }
      }
      if (a === 'export-kix') exportKix();
      if (a === 'new-scene') addScene();
      if (a === 'add-files') openFilesScreen();
      if (a === 'rename-project') {
        askText('Renomear projeto','Novo nome:',currentProject?.name || '',n=>{ if(n&&currentProject){currentProject.name=n;if($('project-title'))$('project-title').textContent=n;save();renderProjects();toast('Renomeado');} });
      }
      if (a === 'delete-project') {
        askConfirm('Excluir projeto','Excluir projeto?',()=>{ projects=projects.filter(p=>p!==currentProject); currentProject=null; save(); renderProjects(); show('home'); toast('Excluído'); });
      }
      if (a === 'project-options') { closeSheets(); openProjectOptionsScreen(); }
      if (a === 'import-kix') $('input-kix')?.click();
      if (a === 'import-catrobat') catPrepareInput();
      
      if (a === 'look-gallery' || a === 'look-camera') {
        window._importMode = 'look';
        const inp = $('input-actor-image');
        if (inp) inp.accept = 'image/*,.gif,image/gif';
        if (a === 'look-camera' && inp) inp.setAttribute('capture','environment');
        inp?.click();
        if (inp) inp.removeAttribute('capture');
      }
      if (a === 'import-gif') {
        const inp = $('input-actor-image');
        if (!inp || !currentActor) { toast('Abra um objeto primeiro'); return; }
        inp.accept = 'image/gif,.gif';
        window._importMode = 'gif-look';
        inp.click();
      }
      if (a === 'look-empty' && currentActor) {
        currentActor.looks.push('');
        save(); renderLooks(); toast('Aparência vazia adicionada');
      }
      if (a === 'look-draw' && currentActor) {
        closeSheets();
        const folderIdx = window._lookImportFolderIdx;
        const targetFolder = Number.isFinite(Number(folderIdx)) ? currentActor.folders?.[Number(folderIdx)] : null;
        window.KixPaint?.open({
          mode: 'look',
          onSave: (dataUrl, frames) => {
            const list = targetFolder ? (targetFolder.looks || (targetFolder.looks = [])) : (currentActor.looks || (currentActor.looks = []));
            const start = list.length;
            list.push(dataUrl);
            if (frames && frames.length > 1) {
              frames.slice(1).forEach(f => list.push(f.src));
              currentActor.frameDurations = currentActor.frameDurations || {};
              frames.forEach((f, i) => { currentActor.frameDurations[list[start + i]] = f.ms; });
            }
            setActorAppearanceActive(currentActor, list[start], targetFolder ? 'folder' : 'root', targetFolder ? Number(folderIdx) : null, start);
            syncActorToProject(); save(); renderLooks(); renderActors();
            toast(frames && frames.length > 1 ? 'Sprite animado adicionado' : 'Aparência adicionada');
          }
        });
      }
      if (a === 'sound-file') $('input-sound')?.click();
      if (a === 'sound-record') toast('Gravação (mock) — use Selecionar arquivo');

      if (a === 'create-folder') createLookFolder();
      if (a === 'look-set-active' || a === 'look-pixel-art' || a === 'look-new-folder' || a === 'look-import-gif' || a === 'look-rename' || a === 'look-delete' || a === 'look-move-folder' || a === 'look-to-root') {
        applyLookOption(a);
      }
      if (a === 'rename-actor' && currentActor) {
        askText('Renomear objeto','Novo nome:',currentActor.name,n=>{ if(n){currentActor.name=n;if($('script-title'))$('script-title').textContent=n;save();toast('Renomeado');} });
      }
      if (a === 'actor-details' && currentActor) {
        toast((currentActor.scripts||[]).length + ' scripts · ' + (currentActor.looks||[]).length + ' looks · ' + (currentActor.folders||[]).length + ' pastas');
      }
      if (a === 'app-options') show('settings');
      if (a === 'settings') show('settings');
      if (a === 'tutorial') openTutorialScreen();
      if (a === 'about') toast('Kix v2 — Visual Programming Studio');
      if (a === 'backpack') {
        toast(backpack.length ? (backpack.length + ' itens na mochila') : 'Mochila vazia');
      }
      if (a === 'clear-vars') { globals = {}; if (currentProject) currentProject.vars = {}; save(); toast('Variáveis limpas'); }
      if (a === 'change-icon') { window._importMode = 'project-icon'; $('input-project-icon')?.click(); }
    };
  });

  // Android WebView keyboard: explicitly request the IME after HTML focus.
  document.addEventListener('focusin', (e) => {
    const el = e.target;
    if (el && (el.matches('input:not([type=file]), textarea, [contenteditable="true"]'))) {
      setTimeout(() => { try { if(window.Android?.showKeyboard) window.Android.showKeyboard(); } catch (_) {} }, 80);
    }
  }, true);

  // ===== Native resource dropdown/sheet for block parameters =====
  function selectorCleanValue(value) {
    return String(value == null ? '' : value).trim().replace(/^['"]|['"]$/g, '').trim();
  }
  function selectorCurrentBlock(targetEl) {
    const blockEl = targetEl?.closest?.('.pc-block');
    if (!blockEl || !currentActor) return null;
    const idx = Number(blockEl.dataset.scriptIdx);
    const scripts = Array.isArray(currentActor.scripts) ? currentActor.scripts : [];
    const block = Number.isInteger(idx) ? scripts[idx] : null;
    if (!block) return null;
    const paramName = String(targetEl.dataset.param || '').trim();
    const def = normalizeParam((block.params || []).find(p => (typeof p === 'object' ? (p.name || p.n) : p) === paramName) || paramName, block.name);
    const kind = String(targetEl.dataset.dropdownType || def.type || '').toLowerCase();
    if (!['sound','object','actor','image','look','appearance','folder','scene'].includes(kind)) return null;
    return { el: targetEl, blockEl, block, paramName, kind, actor: currentActor, scene: currentScene, project: currentProject };
  }
  function selectorStoredValue(currentValue, name) {
    const text = String(currentValue == null ? '' : currentValue).trim();
    const clean = selectorCleanValue(name);
    if (/^['"][\s\S]*['"]$/.test(text)) return "'" + clean.replace(/'/g, "\\'") + "'";
    return clean;
  }
  function resolveSelectorTarget(t) {
    if (!t?.project || t.project !== currentProject || !t.actor) return null;
    const scripts = Array.isArray(t.actor.scripts) ? t.actor.scripts : [];
    const block = scripts.find(b => b && String(b.id || '') === String(t.block?.id || '')) || t.block;
    return block ? { ...t, block } : null;
  }
  function applySelectorValue(target, value) {
    const t = resolveSelectorTarget(target);
    if (!t?.block) return false;
    if (!t.block.values) t.block.values = {};
    t.block.values[t.paramName] = selectorStoredValue(t.block.values[t.paramName], value);
    try { syncActorToProject(); } catch (_) {}
    try { save(); } catch (_) {}
    try { renderScripts(); } catch (_) {}
    return true;
  }
  function applyPendingSelectorValue(kind, value) {
    const p = window._kixPendingSelector;
    if (!p || p.kind !== kind) return false;
    return applySelectorValue(p, value);
  }
  window._kixPendingSelector = null;

  function selectorSoundItems() {
    return (currentActor?.sounds || []).map((s, i) => ({ name: String(s?.name || s || ('Som ' + (i + 1))), value: String(s?.name || s || ''), icon: 'sound' }));
  }
  function selectorObjectItems() {
    const excludeSelf = true;
    return getSceneActors().filter(a => a && (!excludeSelf || a !== currentActor)).map((a, i) => ({
      name: String(a.name || ('Objeto ' + (i + 1))), value: String(a.name || ''), icon: 'object', src: a.image || a.thumbnailImage || a.backgroundFirstImage || a.looks?.[0] || ''
    }));
  }
  function selectorLookItems() {
    const out = [];
    const sideNames = currentActor?.lookNames && typeof currentActor.lookNames === 'object' ? currentActor.lookNames : {};
    const importedNames = Array.isArray(currentActor?.catrobat?.lookNames) ? currentActor.catrobat.lookNames : [];
    const nameFor = (src, i, folderIdx = null) => {
      const key = String(src || '');
      const keyed = sideNames[key];
      if (keyed) return String(keyed);
      if (folderIdx == null && importedNames[i]) return String(importedNames[i]);
      const folder = folderIdx != null ? currentActor?.folders?.[folderIdx] : null;
      const folderNames = Array.isArray(folder?.lookNames) ? folder.lookNames : [];
      if (folderNames[i]) return String(folderNames[i]);
      return 'Aparência ' + (i + 1);
    };
    (currentActor?.looks || []).forEach((src, i) => out.push({ name: nameFor(src, i), value: String(src || ''), icon: 'look', src: String(src || ''), group: null }));
    (currentActor?.folders || []).forEach((folder, fi) => (folder?.looks || []).forEach((src, i) => out.push({ name: nameFor(src, i, fi), value: String(src || ''), icon: 'look', src: String(src || ''), group: String(folder?.name || ('Pasta ' + (fi + 1))), folderIdx: fi })));
    return out;
  }
  function selectorFolderItems() {
    return (currentActor?.folders || []).map((f, i) => ({ name: String(f?.name || ('Pasta ' + (i + 1))), value: String(f?.name || ''), icon: 'folder' }));
  }
  function selectorSceneItems() {
    return (currentProject?.scenes || []).map((s, i) => ({ name: String(s?.name || ('Cena ' + (i + 1))), value: String(s?.name || ''), icon: 'scene', src: (() => { const a=(s?.actors||[]).find(x=>x&&(x.isBackground||x.name==='Fundo')) || (s?.actors||[]).find(x=>x&&x.image); return a?.thumbnailImage || a?.backgroundFirstImage || a?.image || a?.looks?.[0] || ''; })() }));
  }
  function selectorResources(kind) {
    if (kind === 'sound') return selectorSoundItems();
    if (kind === 'object' || kind === 'actor') return selectorObjectItems();
    if (kind === 'image' || kind === 'look' || kind === 'appearance') return selectorLookItems();
    if (kind === 'folder') return selectorFolderItems();
    if (kind === 'scene') return selectorSceneItems();
    return [];
  }
  function selectorIcon(kind, item) {
    if (item?.src && (kind === 'image' || kind === 'look' || kind === 'appearance' || kind === 'object' || kind === 'actor' || kind === 'scene')) {
      const img=document.createElement('img');
      img.src=String(item.src);
      img.alt='';
      img.className='kix-resource-thumb';
      img.onerror=()=>{ img.replaceWith(selectorSvgIcon(kind)); };
      return img;
    }
    return selectorSvgIcon(kind);
  }
  function selectorSvgIcon(kind) {
    const wrap=document.createElement('span');
    wrap.className='kix-resource-icon';
    const paths = {
      sound:'<path d="M9 18V5l10-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="16" cy="16" r="3"/>',
      object:'<rect x="4" y="4" width="16" height="16" rx="3"/><circle cx="9" cy="10" r="1.5"/><path d="M6 17l4-4 3 3 2-2 3 3"/>',
      look:'<rect x="3.5" y="5" width="17" height="14" rx="2"/><circle cx="9" cy="10" r="1.4"/><path d="M5 16l4-4 3 3 2-2 5 4"/>',
      folder:'<path d="M3 7a2 2 0 012-2h5l2 2h7a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V7z"/>',
      scene:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 14l5-5 4 4 3-3 6 6"/>'
    };
    wrap.innerHTML='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">'+(paths[kind]||paths.object)+'</svg>';
    return wrap;
  }
  function selectorStartNew(target) {
    window._kixPendingSelector = target ? {kind:target.kind, paramName:target.paramName, block:target.block, actor:target.actor, project:target.project, scene:target.scene} : null;
    closeSheets();
    if (!target) return;
    if (target.kind === 'sound') {
      window._importMode = 'dropdown-sound';
      const input=$('input-sound');
      if (input) { input.accept='audio/*'; input.click(); }
    } else if (target.kind === 'image' || target.kind === 'look' || target.kind === 'appearance') {
      window._importMode = 'dropdown-look';
      const input=$('input-actor-image');
      if (input) { input.accept='image/*,.gif,image/gif'; input.click(); }
    } else if (target.kind === 'folder') {
      let base='Pasta '+((currentActor?.folders||[]).length+1);
      askText('Criar pasta','Nome da nova pasta:',base,name=>{
        if (!name || !currentActor) { window._kixPendingSelector=null; return; }
        currentActor.folders=currentActor.folders||[];
        currentActor.folders.push({name:String(name),looks:[],open:true});
        applyPendingSelectorValue('folder',String(name));
        window._kixPendingSelector=null;
        save(); renderLooks();
      });
    } else if (target.kind === 'scene') {
      const previousScene=currentScene, previousActor=currentActor, previousActorIdx=currentActorIdx;
      const before=(currentProject?.scenes||[]).length;
      addScene();
      const created=currentProject?.scenes?.[before];
      currentScene=previousScene; currentActor=previousActor; currentActorIdx=previousActorIdx;
      if (created) applyPendingSelectorValue('scene',String(created.name||('Cena '+(before+1))));
      window._kixPendingSelector=null;
      renderScenes(); renderScripts();
    } else if (target.kind === 'object' || target.kind === 'actor') {
      window._kixPendingSelector = {kind:'object', paramName:target.paramName, block:target.block, actor:target.actor, project:target.project, scene:target.scene};
      openSheet('sheet-add-actor');
    }
  }
  function closeInlineResourceDropdown() {
    const activeTarget = window._kixSelectorTarget?.el;
  const activeBlock = activeTarget?.closest?.('.pc-block');
    const old=document.querySelector('.kix-inline-dropdown');
    if(old) old.remove();
    document.querySelectorAll('.param.dropdown.kix-dropdown-active').forEach(el=>{
      el.classList.remove('kix-dropdown-active');
      el.setAttribute('aria-expanded','false');
    });
    if(activeTarget && !activeTarget.classList.contains('param')) activeTarget.removeAttribute('aria-expanded');
    try { activeBlock?.classList.remove('kix-variable-selector-open'); } catch (_) {}
    window._kixSelectorTarget=null;
    window._kixVariableSelectorTarget=null;
  }
  window.KixInlineDropdownClose = closeInlineResourceDropdown;

  function openResourceDropdown(targetEl) {
    const target=selectorCurrentBlock(targetEl);
    if (!target) return false;
    closeInlineResourceDropdown();
    const resources=selectorResources(target.kind);
    // Legacy/Catroid selectors must always open. An empty project still gets
    // the two stable actions: Novo and Usar fórmula.
    const block=target.blockEl;
    if (!block) return false;
    const menu=document.createElement('div');
    menu.className='kix-inline-dropdown';
    menu.setAttribute('role','listbox');
    menu.setAttribute('aria-label',({sound:'Selecionar som',object:'Selecionar objeto',actor:'Selecionar objeto',image:'Selecionar aparência',look:'Selecionar aparência',appearance:'Selecionar aparência',folder:'Selecionar pasta',scene:'Selecionar cena'})[target.kind]||'Selecionar');
    const rect=targetEl.getBoundingClientRect();
    const blockElement=targetEl.closest('.pc-block');
    const blockRect=blockElement?.getBoundingClientRect?.() || rect;
    // The popup visually belongs to the block (like Catroid) but is mounted on
    // <body> so the block's clip-path cannot cut it off. Keep it inside the
    // block's visible rectangle whenever the block is tall enough.
    const viewportW=Math.max(160, window.innerWidth-16);
    const blockW=Math.max(160, blockRect.width || viewportW);
    const maxW=Math.min(520, blockW-16, viewportW);
    menu.style.width=Math.max(190,maxW)+'px';
    menu.style.border='0';
    menu.style.borderRadius='0';
    menu.style.outline='0';
    const menuW=Math.max(190,maxW);
    const left=Math.max(8,Math.min(window.innerWidth-menuW-8,
      Math.max(blockRect.left+8, Math.min(rect.left, blockRect.right-menuW-8))));
    const estimatedH=Math.min(260,42*(resources.length+2));
    const blockTop=Number.isFinite(blockRect.top)?blockRect.top:rect.top;
    const blockBottom=Number.isFinite(blockRect.bottom)?blockRect.bottom:window.innerHeight-8;
    const roomBelow=Math.max(0,blockBottom-rect.bottom-8);
    const roomAbove=Math.max(0,rect.top-blockTop-8);
    let top=rect.bottom+2;
    if(estimatedH>roomBelow && roomAbove>=Math.min(estimatedH,260)) top=rect.top-estimatedH-2;
    else if(estimatedH>roomBelow && roomBelow>24) top=blockBottom-estimatedH-8;
    top=Math.max(blockTop+8,Math.min(blockBottom-estimatedH-8,top));
    // If the block itself is shorter than the menu, prefer a tight overlay
    // over escaping to another screen region.
    if(blockBottom-blockTop<estimatedH+16) top=Math.max(blockTop+8,Math.min(blockBottom-16,rect.bottom+2));
    menu.style.left=Math.round(left)+'px'; menu.style.top=Math.round(Math.max(8,top))+'px';
    menu.addEventListener('pointerdown',e=>e.stopPropagation());
    menu.addEventListener('click',e=>e.stopPropagation());
    const makeRow=(label,kind,opts={})=>{
      const row=document.createElement('button'); row.type='button'; row.className='kix-inline-row'+(opts.new?' kix-inline-new':'')+(opts.heading?' kix-inline-heading':'');
      if(opts.heading){row.disabled=true;row.tabIndex=-1;}
      // Resource dropdowns are intentionally text-only. Images/icons make the
      // compact block selector visually noisy and were inconsistent between
      // sound/object/look/scene entries.
      const txt=document.createElement('span'); txt.className='kix-inline-label'; txt.textContent=label; row.appendChild(txt);
      if(opts.selected) row.classList.add('is-selected');
      if(!opts.heading && kind !== 'formula') row.addEventListener('click',ev=>{
        ev.stopPropagation();
        const t=window._kixSelectorTarget;
        if(opts.new){ window._kixSelectorTarget=null; closeInlineResourceDropdown(); selectorStartNew(t); return; }
        if(t) applySelectorValue(t,opts.value??label);
        closeInlineResourceDropdown();
      });
      return row;
    };
    const newKind=(target.kind==='image'||target.kind==='look'||target.kind==='appearance')?'look':target.kind;
    menu.appendChild(makeRow('Novo',newKind,{new:true}));
    const currentVal=selectorCleanValue(target.block.values?.[target.paramName]);
    if(!resources.length){
      const emptyLabel = target.kind==='sound' ? 'Nenhum som adicionado' :
        ((target.kind==='image'||target.kind==='look'||target.kind==='appearance') ? 'Nenhuma aparência adicionada' : 'Nenhum item disponível');
      menu.appendChild(makeRow(emptyLabel,'empty',{heading:true}));
    }
    if((target.kind==='image'||target.kind==='look'||target.kind==='appearance') && (currentActor?.folders||[]).length){
      const rootItems=resources.filter(x=>!x.group);
      if(rootItems.length){menu.appendChild(makeRow('Sem pasta','folder',{heading:true}));rootItems.forEach(it=>menu.appendChild(makeRow(it.name,target.kind,{value:it.value,src:it,selected:currentVal===selectorCleanValue(it.value)})));}
      (currentActor.folders||[]).forEach(folder=>{
        const name=String(folder?.name||'Pasta'); menu.appendChild(makeRow(name,'folder',{heading:true}));
        resources.filter(x=>x.group===name).forEach(it=>menu.appendChild(makeRow(it.name,target.kind,{value:it.value,src:it,selected:currentVal===selectorCleanValue(it.value)})));
      });
    } else {
      resources.forEach(it=>menu.appendChild(makeRow(it.name,target.kind,{value:it.value,src:it,selected:currentVal===selectorCleanValue(it.value)})));
    }
    const formula=makeRow('Usar fórmula','formula');
    formula.classList.add('kix-inline-formula');
    formula.addEventListener('click',ev=>{
      ev.preventDefault();
      ev.stopPropagation();
      const t=window._kixSelectorTarget;
      if(t?.el){
        // Capture the parameter before closing the dropdown. The generic row
        // handler is deliberately disabled for kind=formula above.
        closeInlineResourceDropdown();
        requestAnimationFrame(()=>openFormula(t.el));
      }
    });
    menu.appendChild(formula);
    document.body.appendChild(menu);
    targetEl.classList.add('kix-dropdown-active');
    targetEl.setAttribute('aria-haspopup','listbox');
    targetEl.setAttribute('aria-expanded','true');
    window._kixSelectorTarget=target;
    requestAnimationFrame(()=>menu.classList.add('is-open'));
    return true;
  }

  window.KixResourcePicker = {
    selectorCleanValue, selectorStoredValue, selectorSoundItems, selectorObjectItems, selectorLookItems,
    selectorFolderItems, selectorSceneItems, selectorResources, applySelectorValue, selectorStartNew, openResourceDropdown
  };

  // File inputs
  function addProjectImageHistory(src, name) {
    if (!currentProject || !src) return;
    if (!Array.isArray(currentProject.imageHistory)) currentProject.imageHistory = [];
    const exists = currentProject.imageHistory.find(x => x && String(x.src) === String(src));
    if (!exists) currentProject.imageHistory.push({ src: String(src), name: String(name || 'Imagem'), addedAt: Date.now() });
  }

  function detectPixelArtDataURL(src) {
    return new Promise(resolve=>{
      try {
        const s=String(src||'');
        if (!/^data:image\/(?:png|gif|webp|bmp)/i.test(s) && !/\.(?:png|gif|webp|bmp)(?:\?|#|$)/i.test(s)) return resolve(false);
        const img=new Image();
        img.onload=()=>{
          try{
            const w=Number(img.naturalWidth||img.width),h=Number(img.naturalHeight||img.height); if(!(w>0&&h>0)) return resolve(false);
            // Keep small sprites at native resolution. Downsampling them can
            // manufacture intermediate colours and fake anti-aliased edges.
            const max=160,scale=Math.min(1,max/w,max/h),sw=Math.max(1,Math.round(w*scale)),sh=Math.max(1,Math.round(h*scale));
            const c=document.createElement('canvas'); c.width=sw;c.height=sh; const ctx=c.getContext('2d',{willReadFrequently:true}); if(!ctx)return resolve(false);
            ctx.imageSmoothingEnabled=false; ctx.drawImage(img,0,0,sw,sh); const d=ctx.getImageData(0,0,sw,sh).data,colors=new Set();
            let same=0,pairs=0,opaque=0,edgePixels=0,antiEdge=0,alphaEdges=0;
            const q=(r,g,b)=>((r>>4)<<8)|((g>>4)<<4)|(b>>4);
            const px=(x,y)=>{const i=(y*sw+x)*4;return [d[i],d[i+1],d[i+2],d[i+3]];};
            const dist=(a,b)=>Math.abs(a[0]-b[0])+Math.abs(a[1]-b[1])+Math.abs(a[2]-b[2]);
            for(let y=0;y<sh;y++)for(let x=0;x<sw;x++){
              const i=(y*sw+x)*4,a=d[i+3];
              if(a>16){opaque++;colors.add(q(d[i],d[i+1],d[i+2]));}
              if(x+1<sw){pairs++;const j=i+4;if(Math.abs(d[i]-d[j])+Math.abs(d[i+1]-d[j+1])+Math.abs(d[i+2]-d[j+2])<8)same++;}
              if(y+1<sh){pairs++;const j=i+sw*4;if(Math.abs(d[i]-d[j])+Math.abs(d[i+1]-d[j+1])+Math.abs(d[i+2]-d[j+2])<8)same++;}
              // Anti-aliasing is primarily visible around boundaries: a partially
              // transparent pixel or an intermediate colour between contrasting
              // opaque neighbours is evidence of smooth rendering.
              if(a>16){
                const n=[];
                if(x>0)n.push(px(x-1,y)); if(x+1<sw)n.push(px(x+1,y)); if(y>0)n.push(px(x,y-1)); if(y+1<sh)n.push(px(x,y+1));
                const opaqueN=n.filter(v=>v[3]>220);
                if(opaqueN.length>=2){
                  const minD=Math.min(...opaqueN.map(v=>dist([d[i],d[i+1],d[i+2]],v)));
                  const maxD=Math.max(...opaqueN.map(v=>dist([d[i],d[i+1],d[i+2]],v)));
                  const boundary=maxD>90;
                  if(boundary)edgePixels++;
                  if(boundary && minD>12)antiEdge++;
                  if(boundary && a<235)alphaEdges++;
                }
              }
            }
            const area=Math.max(1,sw*sh),colorRatio=colors.size/Math.max(1,opaque),sameRatio=same/Math.max(1,pairs);
            const small=Math.max(w,h)<=192;
            const edgeBlendRatio=antiEdge/Math.max(1,edgePixels),alphaEdgeRatio=alphaEdges/Math.max(1,edgePixels);
            const paletteScore=colors.size<=64?.30:colors.size<=128?.20:colors.size<=256?.10:0;
            const flatScore=sameRatio>.62?.22:sameRatio>.48?.12:0;
            const compactScore=small?.22:0;
            const lowColourRatio=colorRatio<.018?.16:colorRatio<.04?.08:0;
            const antiAliasPenalty=(edgeBlendRatio>.28?.24:edgeBlendRatio>.14?.14:0)+(alphaEdgeRatio>.32?.18:alphaEdgeRatio>.16?.08:0);
            const score=paletteScore+flatScore+compactScore+lowColourRatio-antiAliasPenalty;
            const smallPixelCandidate=small && sameRatio>.45 && colorRatio<.15 && edgeBlendRatio<.10 && alphaEdgeRatio<.15;
            // Small sprites get the intended nearest-neighbour treatment when
            // their edges are demonstrably hard/aliased. Size alone is not enough:
            // a small smooth icon must still fail this branch because its boundary
            // contains blended pixels.
            resolve((smallPixelCandidate || score>=.54) && opaque/area>.05 && edgeBlendRatio<.34 && alphaEdgeRatio<.42);
          }catch(_){resolve(false);}
        };
        img.onerror=()=>resolve(false); img.src=s;
      }catch(_){resolve(false);}
    });
  }
  async function schedulePixelArtDetection(actor,src){
    if(!actor||!src)return false;
    if(!actor.pixelArtAutoLooks||typeof actor.pixelArtAutoLooks!=='object')actor.pixelArtAutoLooks={};
    const key=appearanceKey(src);
    if(actor.pixelArtLooks&&Object.prototype.hasOwnProperty.call(actor.pixelArtLooks,key))return !!actor.pixelArtLooks[key];
    const detected=await detectPixelArtDataURL(src);actor.pixelArtAutoLooks[key]=!!detected;
    if(actor.image===src&&!(actor.pixelArtLooks&&Object.prototype.hasOwnProperty.call(actor.pixelArtLooks,key)))actor.pixelArt=!!detected;
    save();try{renderLooks();renderActors();renderScripts();}catch(_){}return detected;
  }
  window.KixPixelArt={detect:detectPixelArtDataURL,schedule:schedulePixelArtDetection};

  $('input-actor-image') && ($('input-actor-image').onchange = async () => {
    try {
      const input = $('input-actor-image');
      const files = input && input.files;
      if (!files || !files.length) return;
      const loadFileAsDataURL = (f) => new Promise((res, rej) => {
        const r = new FileReader();
        r.onload = () => res(r.result);
        r.onerror = rej;
        r.readAsDataURL(f);
      });
      if (window._importMode === 'dropdown-look' && currentActor) {
        if (!Array.isArray(currentActor.looks)) currentActor.looks=[];
        const added=[];
        for (const f of Array.from(files)) {
          const d=await loadFileAsDataURL(f);
          currentActor.looks.push(d);
          added.push({src:String(d),name:f.name});
          addProjectImageHistory(d,f.name);
        }
        if (added.length) {
          applyPendingSelectorValue('image', added[added.length-1].src);
          applyPendingSelectorValue('look', added[added.length-1].src);
          applyPendingSelectorValue('appearance', added[added.length-1].src);
        }
        normalizeActorAppearanceState(currentActor); syncActorToProject(); save(); renderLooks(); renderActors();
        if(added.length) schedulePixelArtDetection(currentActor,added[added.length-1].src);
        window._kixPendingSelector=null;
        window._importMode=null;
        input.value='';
        toast(added.length ? 'Aparência adicionada e selecionada' : 'Nenhuma aparência adicionada');
        return;
      }
      if (window._importMode === 'image-picker') {
        if (!currentActor) {
          toast('Abra um objeto primeiro');
        } else {
          const target = window._imagePickerTarget;
          const found = getImagePickerTargetBlock();
          const imported = [];
          for (const f of Array.from(files)) {
            const d = await loadFileAsDataURL(f);
            imported.push({ src: String(d), name: f.name });
            addProjectImageHistory(d, f.name);
            // The visual picker is an asset library, not a costume editor. Keep the
            // existing actor look flow untouched; the selected block owns the new ref.
            if (found && found.block) {
              if (!found.block.values) found.block.values = {};
              found.block.values[target.paramName || 'imagem'] = String(d);
              break; // one image parameter can point to one image at a time
            }
          }

          syncActorToProject();
          pruneProjectImageHistory();
          save();
          renderImagePicker();
          if (found && found.block && imported.length) {
            toast('Imagem adicionada e selecionada');
          } else if (imported.length) {
            toast('Imagem adicionada');
          }
        }
        window._importMode = null;
        if ($('input-actor-image')) $('input-actor-image').value = '';
        return;
      }

      if (window._importMode === 'new-actor') {
        for (const f of files) {
          const d = await loadFileAsDataURL(f);
          addActor(f.name.replace(/\.[^.]+$/, '') || 'Objeto', d);
        }
      } else if (window._importMode === 'look-folder' && currentActor && window._folderIdx != null) {
        const folder = currentActor.folders && currentActor.folders[window._folderIdx];
        if (folder) {
          if (!folder.looks) folder.looks = [];
          const start = folder.looks.length;
          for (const f of files) {
            const d = await loadFileAsDataURL(f);
            folder.looks.push(d);
            addProjectImageHistory(d, f.name);
          }
          const added = folder.looks.slice(start);
          if (!currentActor.image && added[0]) setActorAppearanceActive(currentActor, added[0], 'folder', window._folderIdx, start);
          normalizeActorAppearanceState(currentActor);
          syncActorToProject();
          save();
          renderLooks();
          renderActors();
          renderImagePicker();
          toast('Adicionado na pasta');
        }
        window._folderIdx = null;
      } else if ((window._importMode === 'look-selected' || window._importMode === 'gif-look-selected') && currentActor) {
        const isGif = window._importMode === 'gif-look-selected';
        const folderIdx = window._lookImportFolderIdx;
        let targetFolder = Number.isFinite(Number(folderIdx)) ? currentActor.folders?.[Number(folderIdx)] : null;
        const added = [];
        if (targetFolder) {
          if (!targetFolder.looks) targetFolder.looks = [];
          for (const f of files) {
            if (isGif && !/^image\/gif$/i.test(f.type) && !/\.gif$/i.test(f.name)) { toast('Selecione um arquivo GIF'); continue; }
            const d = await loadFileAsDataURL(f);
            targetFolder.looks.push(d);
            added.push({src:String(d), name:f.name, where:'folder', folderIdx:Number(folderIdx), idx:targetFolder.looks.length-1});
            addProjectImageHistory(d, f.name);
          }
        } else {
          if (!Array.isArray(currentActor.looks)) currentActor.looks = [];
          for (const f of files) {
            if (isGif && !/^image\/gif$/i.test(f.type) && !/\.gif$/i.test(f.name)) { toast('Selecione um arquivo GIF'); continue; }
            const d = await loadFileAsDataURL(f);
            currentActor.looks.push(d);
            added.push({src:String(d), name:f.name, where:'root', folderIdx:null, idx:currentActor.looks.length-1});
            addProjectImageHistory(d, f.name);
          }
        }
        if (added.length) {
          const last = added[added.length - 1];
          setActorAppearanceActive(currentActor, last.src, last.where, last.folderIdx, last.idx);
        }
        normalizeActorAppearanceState(currentActor);
        syncActorToProject();
        pruneProjectImageHistory();
        save();
        renderLooks();
        renderActors();
        renderImagePicker();
        toast(isGif ? 'GIF adicionado como aparência' : 'Aparência adicionada');
      } else if (window._importMode === 'gif-look' && currentActor) {
        if (!Array.isArray(currentActor.looks)) currentActor.looks = [];
        for (const f of files) {
          if (!/^image\/gif$/i.test(f.type) && !/\.gif$/i.test(f.name)) {
            toast('Selecione um arquivo GIF');
            continue;
          }
          const d = await loadFileAsDataURL(f);
          currentActor.looks.push(d);
          addProjectImageHistory(d, f.name);
          if (!currentActor.image) currentActor.image = d;
        }
        normalizeActorAppearanceState(currentActor);
        syncActorToProject();
        pruneProjectImageHistory();
        save();
        renderLooks();
        renderActors();
        renderImagePicker();
        toast('GIF adicionado como aparência');
      } else if ((window._importMode === 'look' || !window._importMode) && currentActor) {
        if (!Array.isArray(currentActor.looks)) currentActor.looks = [];
        for (const f of files) {
          const d = await loadFileAsDataURL(f);
          currentActor.looks.push(d);
          addProjectImageHistory(d, f.name);
          if (!currentActor.image) currentActor.image = d;
          if (currentActor.isBackground || currentActor.name === 'Fundo') {
            currentActor.thumbnailImage = currentActor.thumbnailImage || d;
            currentActor.backgroundFirstImage = currentActor.thumbnailImage;
          }
        }
        normalizeActorAppearanceState(currentActor);
        syncActorToProject();
        save();
        const autoDetectSrc=currentActor.image || currentActor.looks?.[currentActor.looks.length-1];
        if(autoDetectSrc) schedulePixelArtDetection(currentActor,autoDetectSrc);
        renderLooks();
        renderActors();
        toast('Imagem salva');
      }
    } catch (e) {
      console.error('import image', e);
      toast('Erro ao importar imagem');
    }
    window._importMode = null;
    window._lookImportFolderIdx = null;
    if ($('input-actor-image')) {
      $('input-actor-image').accept = 'image/*,.gif,image/gif';
      $('input-actor-image').value = '';
    }
  });
  $('btn-import-look') && ($('btn-import-look').onclick = () => {
    const inp = $('input-actor-image');
    if (!inp) return;
    inp.accept = 'image/*';
    window._importMode = 'look';
    inp.click();
  });
  $('btn-import-sound') && ($('btn-import-sound').onclick = () => $('input-sound')?.click());
  $('input-sound') && ($('input-sound').onchange = async () => {
    const files = $('input-sound').files;
    if (!files?.length || !currentActor) return;
    const added=[];
    currentActor.sounds = Array.isArray(currentActor.sounds) ? currentActor.sounds : [];
    for (const f of files) {
      currentActor.sounds.push({ name: f.name, data: await loadFileAsDataURL(f) });
      added.push(f.name);
    }
    if (window._importMode === 'dropdown-sound' && added.length) {
      applyPendingSelectorValue('sound', added[added.length-1]);
      window._kixPendingSelector=null; window._importMode=null;
      save(); renderSounds(); renderScripts(); toast('Som adicionado e selecionado');
    } else {
      save(); renderSounds(); toast(files.length + ' som(ns) importado(s)');
    }
    $('input-sound').value = '';
  });
  $('btn-import-catrobat') && ($('btn-import-catrobat').onclick = () => catPrepareInput());
  $('btn-back-catrobat-report') && ($('btn-back-catrobat-report').onclick = () => {
    if (currentProject?.catrobatImport) show('project', {noPush:true});
    else show(currentProject ? 'project' : 'home', {noPush:true});
  });
  $('input-catrobat') && ($('input-catrobat').onchange = async () => {
    const input=$('input-catrobat'); const files=Array.from(input?.files||[]);
    if(!files.length) return;
    if(!experimentalResourcesEnabled()){ input.value=''; toast('Ative Recursos experimentais em Configurações'); syncCatrobatMenuState(); return; }
    const imported=[]; const loadingToken=showCatrobatLoading();
    try {
      for(const f of files){
        const name=String(f.name||'').trim();
        if(!/\.(catrobat|newtrobat|zip)$/i.test(name)) throw new Error('Selecione .catrobat, .newtrobat ou .zip');
        setCatrobatLoading('Lendo '+name+'…','Carregando projeto',31);
        await new Promise(r=>requestAnimationFrame(r));
        setCatrobatLoading('Analisando code.xml e assets…','Analisando estrutura',45);
        const p=await importCatrobatFile(f);
        imported.push(p);
        setCatrobatLoading('Construindo cenas, objetos e scripts…','Montando projeto',72);
        await new Promise(r=>requestAnimationFrame(r));
        setCatrobatLoading('Validando compatibilidade…','Finalizando importação',92);
        await new Promise(r=>requestAnimationFrame(r));
      }
      imported.reverse().forEach(p=>projects.unshift(p));
      if(imported.length){
        currentProject=imported[0]; currentActor=null; currentActorIdx=-1; currentScene=0;
        save(); renderProjects(); renderScenes?.(); renderProjectOptionsScreen();
        const hasFailures=imported.some(p=>{
          const c=p?.catrobatImport||{};
          const failed=Number(c.checkSummary?.failed||0)>0;
          const missing=Array.isArray(c.missingAssets)&&c.missingAssets.length>0;
          const unsupported=Object.keys(c.unsupportedTypes||{}).length>0;
          return failed||missing||unsupported;
        });
        setCatrobatLoading('Importação concluída',hasFailures?'Mas com falhas':'Entrando no projeto...',100);
        showCatrobatImportResult(hasFailures);
        await new Promise(r=>setTimeout(r,700));
        show('project',{noPush:true});
        toast(imported.length+' projeto(s) Catroid importado(s)');
      }
    } catch(err){
      console.error('importCatrobat',err);
      setCatrobatLoading('Não foi possível concluir a importação.','Importação interrompida',100);
      await new Promise(r=>setTimeout(r,650));
      show(currentProject ? 'project' : 'home',{noPush:true});
      toast('Falha na importação Catroid: '+(err?.message||'arquivo inválido'));
    } finally { input.value=''; if(loadingToken===_catLoadingToken) _catLoadingToken++; }
  });

  $('input-kix') && ($('input-kix').onchange = async () => {
    const input = $('input-kix'); const files = Array.from(input?.files || []);
    if (!files.length) return;
    try {
      for (const f of files) {
        const fname = String(f.name || '').trim();
        const isKix = /\.kix$/i.test(fname);
        const isJson = /\.json$/i.test(fname);
        if (!isKix && !isJson) throw new Error('Selecione um arquivo .kix ou .json');
        const text = await f.text();
        if (!text.trim()) throw new Error('Arquivo .kix vazio');
        let raw; try { raw = JSON.parse(text); } catch (_) { throw new Error(isKix ? 'Arquivo .kix inválido: o formato deve ser JSON Kix' : 'JSON inválido'); }
        const p = normalizeKixProject(raw);
        ensureProjectIdentity(p);
        const imported = JSON.parse(JSON.stringify(p));
        imported.name = imported.name || f.name.replace(/\.(kix|json)$/i, '');
        // Import every embedded asset reference unchanged (data:, URLs, legacy fields).
        imported.scenes.forEach(sc => (sc.actors || []).forEach(a => {
          a.looks = (a.looks || []).map(x => typeof x === 'string' ? x : (x?.dataUrl || x?.src || x?.image || x));
          a.folders = Array.isArray(a.folders) ? a.folders : [];
          a.folders.forEach(folder => { folder.looks = (folder.looks || []).map(x => typeof x === 'string' ? x : (x?.dataUrl || x?.src || x?.image || x)); });
        }));
        projects.unshift(imported);
      }
      save(); renderProjects(); toast(files.length + ' projeto(s) importado(s)');
    } catch (err) { console.error('importKix', err); toast('Falha na importação: ' + (err.message || 'arquivo inválido')); }
    input.value = '';
  });

  $('input-project-icon') && ($('input-project-icon').onchange = async () => {
    const f = $('input-project-icon').files?.[0];
    if (!f || !currentProject) return;
    currentProject.icon = await loadFileAsDataURL(f);
    save(); renderProjects(); renderProjectOptionsScreen(); toast('Ícone atualizado');
    $('input-project-icon').value = '';
  });

  
  // Settings
  const mergedApp = $('app-settings-content');
  const appSource = $('screen-app-options')?.querySelector(':scope > div.flex-1');
  if (mergedApp && appSource && !mergedApp.children.length) {
    Array.from(appSource.children).forEach(el => mergedApp.appendChild(el));
  }

  $('btn-back-settings') && ($('btn-back-settings').onclick = () => show('home', {noPush:true}));
  $('btn-back-app-options') && ($('btn-back-app-options').onclick = () => show('home', {noPush:true}));
  $('btn-back-project-options') && ($('btn-back-project-options').onclick = () => { save(); if (projectEntryOrigin === 'home') { currentProject = null; renderProjects(); clearNavStack(); show('home', {noPush:true}); } else { show('project', {noPush:true}); } });
  $('project-options-name')?.addEventListener('input', (e) => { if (currentProject) { currentProject.name = e.target.value || 'Projeto'; $('project-options-name-label').textContent = currentProject.name; $('project-title').textContent = currentProject.name; save(); } });
  $('project-options-description')?.addEventListener('input', (e) => { if (currentProject) { currentProject.description = e.target.value || ''; save(); } });
  $('project-options-version')?.addEventListener('input', (e) => { if (currentProject) { currentProject.version = e.target.value.trim() || KIX_APP_VERSION; save(); } });
  $('project-options-icon')?.addEventListener('click', () => { window._importMode = 'project-icon'; $('input-project-icon')?.click(); });
  $('project-options-import-files')?.addEventListener('click', () => { if (!currentProject) { toast('Nenhum projeto aberto'); return; } openFilesScreen('project-options'); });
  $('project-options-clear-vars')?.addEventListener('click', () => { globals = {}; if (currentProject) currentProject.vars = {}; save(); toast('Variáveis limpas'); });
  $('project-options-export')?.addEventListener('click', () => exportKix());
  $('project-options-delete')?.addEventListener('click', deleteCurrentProject);

  // Language: pt-BR is the persisted default; changing it only changes presentation.
  const appLanguage = $('app-language');
  if (appLanguage) {
    appLanguage.value = kixCurrentLocale();
    appLanguage.onchange = () => kixSetLanguage(appLanguage.value);
  }
  applyKixLanguage();

  const appAuto = $('app-opt-autosave'), appCompact = $('app-opt-compact'), appFeedback = $('app-opt-feedback'), appToasts = $('app-opt-toasts'), appGrid = $('app-opt-grid');
  if (appAuto) { appAuto.checked = appOptions.autosave !== false; appAuto.onchange = () => { appOptions.autosave = appAuto.checked; persistAppOptions(); toast(appAuto.checked ? 'Salvamento automático ativo' : 'Salvamento automático pausado'); if (appAuto.checked) scheduleKixPersistence(); }; }
  if (appCompact) { appCompact.checked = !!appOptions.compact; document.body.classList.toggle('kix-compact', !!appOptions.compact); appCompact.onchange = () => { appOptions.compact = appCompact.checked; document.body.classList.toggle('kix-compact', appOptions.compact); persistAppOptions(); }; }
  if (appFeedback) { appFeedback.checked = appOptions.feedback !== false; appFeedback.onchange = () => { appOptions.feedback = appFeedback.checked; persistAppOptions(); }; }
  if (appToasts) { appToasts.checked = appOptions.toasts !== false; appToasts.onchange = () => { appOptions.toasts = appToasts.checked; persistAppOptions(); }; }
  if (appGrid) { appGrid.checked = !!appOptions.grid; appGrid.onchange = () => { appOptions.grid = appGrid.checked; stageGrid = appOptions.grid; persistAppOptions(); applyStageGrid(); }; }
  const kixQualityToggle = $('app-opt-kix-quality');
  if (kixQualityToggle) { kixQualityToggle.checked = appOptions.kixQualityEnabled === true; kixQualityToggle.onchange = () => { appOptions.kixQualityEnabled = kixQualityToggle.checked; persistAppOptions(); syncKixQualityUI(); toast(kixQualityToggle.checked ? 'Kix Quality ativado' : 'Kix Quality desativado'); }; }

  $('btn-back-files') && ($('btn-back-files').onclick = () => { save(); show(filesReturnScreen || 'project', {noPush:true}); });
  $('btn-add-file') && ($('btn-add-file').onclick = () => $('input-project-file')?.click());
  $('input-project-file') && ($('input-project-file').onchange = (e) => {
    addProjectFileFromInput(e.target.files);
    e.target.value = '';
  });
  document.querySelectorAll('.ext-toggle').forEach(cb => {
    const key = cb.dataset.ext;
    cb.checked = !!extensions[key];
    cb.onchange = () => {
      extensions[key] = cb.checked;
      localStorage.setItem('kix_extensions', JSON.stringify(extensions));
      toast(cb.checked ? 'Extensão ativada' : 'Extensão desativada');
    };
  });

  
  // Block context overlay
  /* overlay close delegated */
  /* ctx-action handled by delegated handleCtxAction */

  // Scene navigation
  $('btn-back-scenes') && ($('btn-back-scenes').onclick = () => { save(); navBack(); });
  $('btn-add-scene-fab') && ($('btn-add-scene-fab').onclick = (e) => { e && e.preventDefault && e.preventDefault(); e && e.stopPropagation && e.stopPropagation(); addScene(); });
  $('btn-play-scene') && ($('btn-play-scene').onclick = (e) => { e?.preventDefault?.(); e?.stopPropagation?.(); startPlay(); });
  // btn-back-project from scripts goes to scene now

  $('btn-script-menu') && ($('btn-script-menu').onclick = () => {
    const looksOn = !$('looks-area')?.classList.contains('hidden');
    const folderItem = $('menu-create-folder');
    const gifItem = $('menu-import-gif');
    if (folderItem) folderItem.style.display = looksOn ? '' : 'none';
    if (gifItem) gifItem.style.display = looksOn ? '' : 'none';
    openSheet('sheet-script-menu');
  });
  
  // Context menu actions (delegation)
  /* block-ctx-actions delegated */
  /* overlay close delegated */

  
  // === Block context menu actions (delegated, robust) ===
  /* handleCtxAction is global */

  // Click on action rows (works even if click hits SVG inside)
  document.addEventListener('click', function(e) {
    const actionEl = e.target.closest('.ctx-action');
    if (actionEl && actionEl.closest('#block-ctx-actions')) {
      e.preventDefault();
      e.stopPropagation();
      handleCtxAction(actionEl.dataset.act);
      return;
    }
  }, true);

  document.querySelectorAll('.ext-toggle').forEach(cb => {
    try {
      const key = cb.getAttribute('data-ext');
      if (key && extensions) cb.checked = !!extensions[key];
      cb.onchange = () => {
        try {
          if (!key) return;
          extensions[key] = !!cb.checked;
          localStorage.setItem('kix_extensions', JSON.stringify(extensions));
          if (key === 'experimental') syncCatrobatMenuState();
          toast(cb.checked ? 'Extensão ativada' : 'Extensão desativada');
        } catch (e) { console.warn(e); }
      };
    } catch (e) { console.warn('ext-toggle', e); }
  });
  document.addEventListener('click', (e) => {
    const q = e.target.closest('.look-qbtn');
    if (!q) return;
    const act = q.dataset.lookAct;
    if (act === 'import') { window._importMode = 'look'; $('input-actor-image')?.click(); }
    if (act === 'empty') {
      if (currentActor) { currentActor.looks.push(''); save(); renderLooks(); toast('Aparência vazia'); }
    }
    if (act === 'camera') {
      window._importMode = 'look';
      const inp = $('input-actor-image');
      if (inp) { inp.setAttribute('capture','environment'); inp.click(); inp.removeAttribute('capture'); }
    }
    if (act === 'folder') createLookFolder();
  });
  $('create-back')?.addEventListener('click', () => show('home', {noPush:true}));
  $('create-cancel')?.addEventListener('click', () => show('home', {noPush:true}));
  $('create-confirm')?.addEventListener('click', createFromForm);
  ['portrait','landscape'].forEach((orientation) => {
    const btn = document.querySelector(`.create-orientation[data-orientation="${orientation}"]`);
    if (!btn) return;
    btn.addEventListener('click', () => {
      _createOrientation = orientation;
      document.querySelectorAll('.create-orientation').forEach(b => {
        const active = b.dataset.orientation === _createOrientation;
        b.classList.toggle('text-[#10B981]', active);
        b.classList.toggle('text-[#D5D5DA]', !active);
      });
    });
  });
  $('create-icon')?.addEventListener('click', () => $('input-project-icon')?.click());
  document.querySelectorAll('.create-orientation').forEach(b => b.addEventListener('click', () => {
    _createOrientation = b.dataset.orientation || 'portrait';
    document.querySelectorAll('.create-orientation').forEach(x => { x.classList.toggle('text-[#10B981]', x.dataset.orientation === _createOrientation); x.classList.toggle('text-[#D8D8DD]', x.dataset.orientation !== _createOrientation); });
  }));
  $('play-more-reset-camera')?.addEventListener('click', () => { fitStage(); $('play-more-menu')?.classList.add('hidden'); });
  window.addEventListener('resize', () => { syncPlayViewportToControls(); try { KixEngine?.syncStageLayout?.(); } catch (_) {} });
  window.addEventListener('orientationchange', () => { syncPlayViewportToControls(); try { KixEngine?.syncStageLayout?.(); } catch (_) {} try { window.KixOrientationGuard?.refresh?.(); } catch (_) {} });
  try {
    if (window.visualViewport) window.visualViewport.addEventListener('resize', () => { syncPlayViewportToControls(); try { KixEngine?.syncStageLayout?.(); } catch (_) {} });
  } catch (_) {}
  try {
    const controls = $('play-controls');
    if (controls && typeof ResizeObserver === 'function') {
      const ro = new ResizeObserver(() => { syncPlayViewportToControls(); try { KixEngine?.syncStageLayout?.(); } catch (_) {} });
      ro.observe(controls);
      window._kixPlayControlsResizeObserver = ro;
    }
  } catch (_) {}
  $('play-more-fit')?.addEventListener('click', () => { fitStage(); $('play-more-menu')?.classList.add('hidden'); });
  $('play-more-grid')?.addEventListener('click', () => { stageGrid = !stageGrid; appOptions.grid = stageGrid; persistAppOptions(); applyStageGrid(); toast(stageGrid ? 'Grade ativada' : 'Grade desativada'); $('play-more-menu')?.classList.add('hidden'); });
  $('play-more-fps')?.addEventListener('click', () => {
    const r = window.KixEngine?.runtime;
    if (!r) return;
    const next = !r.showFps;
    r.showFps = next;
    $('play-fps-display')?.classList.toggle('hidden', !next);
    $('debug-panel')?.classList.toggle('hidden', !next);
    const b = $('play-more-fps');
    if (b) b.textContent = next ? 'Ocultar FPS e depuração' : 'FPS e depuração';
    if (next) updateGlobalsPanel();
    $('play-more-menu')?.classList.add('hidden');
  });
  $('play-more-reload')?.addEventListener('click', () => { try { KixEngine?.stopEngine?.(); startPlay(); } catch(e){ console.error(e); toast('Falha ao recarregar cena'); } $('play-more-menu')?.classList.add('hidden'); });
  $('play-more-clearlog')?.addEventListener('click', () => { console.clear(); toast('Diagnóstico limpo'); $('play-more-menu')?.classList.add('hidden'); });
  // Phase 2 technical tools may invoke these existing controls through the deterministic router.
  window.rotatePlayScreen = rotatePlayScreen;
  window.toggleFreeCam = toggleFreeCam;
  window.fitStage = fitStage;
  window.setPlayCleanMode = setPlayCleanMode;
  window.startPlay = startPlay;
  window.appOptions = appOptions;
  window.stageGrid = stageGrid;
  window.persistAppOptions = persistAppOptions;
  window.applyStageGrid = applyStageGrid;
  window.toggleStageGrid = () => { stageGrid=!stageGrid; appOptions.grid=stageGrid; persistAppOptions(); applyStageGrid(); toast(stageGrid?'Grade ativada':'Grade desativada'); };
  window.toggleStageAxes = () => { showAxes=!showAxes; $('axes-overlay')?.classList.toggle('hidden',!showAxes); toast(showAxes?'Eixos ativos':'Eixos desativados'); };
  window.stageGrid = stageGrid;
  stageGrid = !!appOptions.grid;
  applyStageGrid();
  buildCompleteBlockHelp();
console.log('Kix v2 ready —', Object.keys(CATEGORIES).length, 'categorias');
  } catch (err) {
    console.error('Kix init error:', err);
    try { toast('Erro na inicialização'); } catch (_) {}
  }
});
