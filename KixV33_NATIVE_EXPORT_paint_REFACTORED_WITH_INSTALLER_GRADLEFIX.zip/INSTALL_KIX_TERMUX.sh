#!/data/data/com.termux/files/usr/bin/bash
# Prepara o ambiente Termux para compilar o Kix. Não apaga projetos nem chaves.
set -Eeuo pipefail

say() { printf '\n==> %s\n' "$*"; }
warn() { printf 'AVISO: %s\n' "$*" >&2; }
die() { printf 'ERRO: %s\n' "$*" >&2; exit 1; }

[ -n "${PREFIX:-}" ] && [ -x "$PREFIX/bin/pkg" ] || die 'Este script precisa ser executado dentro do Termux no Android.'

say 'Atualizando pacotes do Termux'
pkg update -y
pkg upgrade -y

say 'Instalando ferramentas de compilação e diagnóstico'
# Instalação em grupos para identificar pacotes indisponíveis sem abortar tudo.
for package in git unzip zip curl wget python nodejs-lts openjdk-21 gradle; do
  if pkg install -y "$package"; then
    :
  else
    warn "Não foi possível instalar '$package' pelo nome padrão. Verifique os repositórios do Termux."
  fi
done

command -v node >/dev/null 2>&1 || die 'Node.js não foi instalado.'
command -v npm >/dev/null 2>&1 || die 'npm não está disponível após instalar Node.js.'
command -v java >/dev/null 2>&1 || die 'Java não foi instalado.'
command -v gradle >/dev/null 2>&1 || die 'Gradle não foi instalado. O pacote gradle é necessário para este projeto.'

say 'Verificando versões'
node --version
npm --version
java -version
gradle --version | sed -n '1,18p'

JAVA_MAJOR="$(java -version 2>&1 | sed -n '1s/.*version "\([0-9]*\).*/\1/p')"
[ -n "$JAVA_MAJOR" ] || die 'Não foi possível determinar a versão do Java.'
[ "$JAVA_MAJOR" -ge 17 ] || die "Java $JAVA_MAJOR é antigo demais; use Java 17 ou superior."

say 'Localizando Android SDK'
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [ -z "$SDK" ]; then
  for candidate in "$HOME/Android/Sdk" "$HOME/android-sdk" "$PREFIX/opt/android-sdk" "$HOME/.android/sdk"; do
    if [ -d "$candidate/platforms" ] || [ -d "$candidate/build-tools" ]; then SDK="$candidate"; break; fi
  done
fi

if [ -n "$SDK" ] && [ -d "$SDK" ]; then
  export ANDROID_HOME="$SDK"
  export ANDROID_SDK_ROOT="$SDK"
  printf 'SDK detectado: %s\n' "$SDK"
  if command -v sdkmanager >/dev/null 2>&1; then
    say 'Instalando plataforma e Build Tools exigidos pelo projeto (API 35)'
    yes | sdkmanager --sdk_root="$SDK" 'platforms;android-35' 'build-tools;35.0.0' || warn 'sdkmanager falhou ao instalar componentes. Confira rede, licenças e compatibilidade do SDK com Termux.'
  else
    warn 'sdkmanager não encontrado; não é possível baixar automaticamente a plataforma Android 35.'
  fi
else
  warn 'Android SDK não detectado. Gradle sozinho NÃO basta: este projeto requer platforms/android-35 e build-tools/35.0.0.'
  warn 'Configure ANDROID_SDK_ROOT/ANDROID_HOME para um SDK compatível antes de compilar.'
fi

say 'Configurando AAPT2 personalizado, se existir'
AAPT_CANDIDATE="${KIX_AAPT2:-$HOME/kix-aapt2-35-test/build-tools/35.0.0/aapt2}"
if [ -x "$AAPT_CANDIDATE" ]; then
  printf 'AAPT2 encontrado: %s\n' "$AAPT_CANDIDATE"
  printf '\nExportação recomendada para esta sessão:\nexport KIX_AAPT2=%q\n' "$AAPT_CANDIDATE"
else
  warn 'AAPT2 personalizado não encontrado. O Gradle tentará usar o AAPT2 padrão do Android SDK/Maven.'
fi

say 'Preparando dependências JavaScript do Kix, se o script estiver na raiz do projeto'
ROOT="$(pwd)"
if [ -f "$ROOT/package.json" ] && [ -f "$ROOT/BUILD_KIX_DEBUG_TERMUX.sh" ]; then
  npm install --no-audit --no-fund
else
  warn 'Não estou na raiz do Kix. Entre na pasta extraída do projeto e execute npm install --no-audit --no-fund.'
fi

say 'Resultado da preparação'
printf 'Node: %s\n' "$(node --version)"
printf 'npm: %s\n' "$(npm --version)"
printf 'Java: %s\n' "$JAVA_MAJOR"
printf 'Gradle: %s\n' "$(gradle --version | awk '/Gradle [0-9]/{print $2; exit}')"
if [ -n "$SDK" ] && [ -d "$SDK/platforms/android-35" ] && [ -d "$SDK/build-tools/35.0.0" ]; then
  printf 'Android SDK API 35: encontrado\n'
else
  warn 'Preparação parcial: os componentes Android API 35 ainda não foram confirmados.'
fi
printf '\nPróximo passo: entre na raiz do projeto e execute:\n  bash BUILD_KIX_DEBUG_TERMUX.sh\n'
